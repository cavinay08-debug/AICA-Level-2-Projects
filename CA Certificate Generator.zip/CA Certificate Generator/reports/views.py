import csv
from django.shortcuts import render
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views import View
from django.http import HttpResponse
from django.db.models import Count, Sum, Q
from django.core.paginator import Paginator


class ReportHomeView(LoginRequiredMixin, View):
    def get(self, request):
        from certificates.models import Certificate
        from firms.models import CAFirm

        firm_stats = []
        for firm in CAFirm.objects.filter(is_active=True):
            stats = Certificate.objects.filter(firm=firm).aggregate(
                total=Count('id'),
                drafts=Count('id', filter=Q(status='draft')),
                finals=Count('id', filter=Q(status='final')),
                udin_pending=Count('id', filter=Q(udin_status='pending')),
            )
            stats['firm'] = firm
            firm_stats.append(stats)

        type_stats = []
        for cert_type, label in Certificate.TYPE_CHOICES:
            count = Certificate.objects.filter(cert_type=cert_type).count()
            type_stats.append({'type': label, 'count': count})

        return render(request, 'reports/home.html', {
            'firm_stats': firm_stats,
            'type_stats': type_stats,
        })


class UDINPendingView(LoginRequiredMixin, View):
    def get(self, request):
        from certificates.models import Certificate
        certs = Certificate.objects.filter(
            udin_status='pending', status='final'
        ).select_related('firm', 'entity').order_by('issue_date')
        paginator = Paginator(certs, 25)
        page = paginator.get_page(request.GET.get('page', 1))
        return render(request, 'reports/udin_pending.html', {'page_obj': page})


class PaymentPendingView(LoginRequiredMixin, View):
    def get(self, request):
        from payments.models import PaymentRecord
        records = PaymentRecord.objects.filter(
            payment_status__in=['no', 'partial']
        ).select_related('certificate', 'certificate__firm', 'certificate__entity').order_by(
            'certificate__issue_date'
        )
        paginator = Paginator(records, 25)
        page = paginator.get_page(request.GET.get('page', 1))
        total_outstanding = records.aggregate(total=Sum('outstanding_amount'))['total'] or 0
        return render(request, 'reports/payment_pending.html', {
            'page_obj': page,
            'total_outstanding': total_outstanding
        })


class ByFirmView(LoginRequiredMixin, View):
    def get(self, request):
        from certificates.models import Certificate
        from firms.models import CAFirm
        firm_id = request.GET.get('firm')
        firm = None
        certs = Certificate.objects.none()
        if firm_id:
            from django.shortcuts import get_object_or_404
            firm = get_object_or_404(CAFirm, pk=firm_id)
            certs = Certificate.objects.filter(firm=firm).select_related('entity').order_by('-issue_date')
        paginator = Paginator(certs, 25)
        page = paginator.get_page(request.GET.get('page', 1))
        return render(request, 'reports/by_firm.html', {
            'page_obj': page,
            'firm': firm,
            'firms': CAFirm.objects.filter(is_active=True),
            'firm_id': firm_id or '',
        })


class RevenueView(LoginRequiredMixin, View):
    def get(self, request):
        from payments.models import PaymentRecord
        from firms.models import CAFirm

        firm_revenue = []
        for firm in CAFirm.objects.filter(is_active=True):
            records = PaymentRecord.objects.filter(certificate__firm=firm)
            agg = records.aggregate(
                billed=Sum('amount'),
                received=Sum('amount_received'),
                outstanding=Sum('outstanding_amount'),
            )
            agg['firm'] = firm
            firm_revenue.append(agg)

        return render(request, 'reports/revenue.html', {'firm_revenue': firm_revenue})


class ExportCSVView(LoginRequiredMixin, View):
    def get(self, request):
        from certificates.models import Certificate
        from payments.models import PaymentRecord

        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="certificate_register.csv"'

        writer = csv.writer(response)
        writer.writerow([
            'Certificate Number', 'Type', 'Entity Name', 'PAN', 'Firm', 'Status',
            'Issue Date', 'Financial Year', 'UDIN Status', 'UDIN Number',
            'Payment Status', 'Amount (₹)', 'Received (₹)', 'Outstanding (₹)',
            'Prepared By', 'Reviewed By', 'Created By', 'Created At'
        ])

        certs = Certificate.objects.select_related('firm', 'entity').prefetch_related('payment').all()

        # Apply filters
        cert_type = request.GET.get('cert_type')
        firm_id = request.GET.get('firm')
        status = request.GET.get('status')
        date_from = request.GET.get('date_from')
        date_to = request.GET.get('date_to')

        if cert_type:
            certs = certs.filter(cert_type=cert_type)
        if firm_id:
            certs = certs.filter(firm_id=firm_id)
        if status:
            certs = certs.filter(status=status)
        if date_from:
            certs = certs.filter(issue_date__gte=date_from)
        if date_to:
            certs = certs.filter(issue_date__lte=date_to)

        for cert in certs:
            try:
                payment = cert.payment
                pay_status = payment.get_payment_status_display()
                amount = payment.amount
                received = payment.amount_received
                outstanding = payment.outstanding_amount
            except Exception:
                pay_status = amount = received = outstanding = ''

            writer.writerow([
                cert.cert_number,
                cert.get_cert_type_display(),
                cert.entity_name_on_cert,
                cert.pan_on_cert,
                cert.firm.name,
                cert.get_status_display(),
                cert.issue_date.strftime('%d-%m-%Y'),
                cert.financial_year,
                cert.get_udin_status_display(),
                cert.udin_number,
                pay_status, amount, received, outstanding,
                cert.prepared_by, cert.reviewed_by,
                str(cert.created_by) if cert.created_by else '',
                cert.created_at.strftime('%d-%m-%Y %H:%M'),
            ])

        return response

from django.urls import path
from . import views

app_name = 'reports'

urlpatterns = [
    path('', views.ReportHomeView.as_view(), name='home'),
    path('udin-pending/', views.UDINPendingView.as_view(), name='udin_pending'),
    path('payment-pending/', views.PaymentPendingView.as_view(), name='payment_pending'),
    path('by-firm/', views.ByFirmView.as_view(), name='by_firm'),
    path('revenue/', views.RevenueView.as_view(), name='revenue'),
    path('export/csv/', views.ExportCSVView.as_view(), name='export_csv'),
]

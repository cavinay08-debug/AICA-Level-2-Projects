from django import forms
from .models import PaymentRecord


class PaymentForm(forms.ModelForm):
    class Meta:
        model = PaymentRecord
        fields = ['payment_status', 'amount', 'amount_received', 'received_date', 'payment_reference', 'remarks']
        widgets = {
            'received_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'remarks': forms.Textarea(attrs={'rows': 2, 'class': 'form-control'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for name, field in self.fields.items():
            if name not in ['received_date', 'remarks']:
                if isinstance(field.widget, forms.Select):
                    field.widget.attrs['class'] = 'form-select'
                else:
                    field.widget.attrs['class'] = 'form-control'

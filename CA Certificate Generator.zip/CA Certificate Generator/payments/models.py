from django.db import models
from certificates.models import Certificate


class PaymentRecord(models.Model):
    PAYMENT_YES = 'yes'
    PAYMENT_NO = 'no'
    PAYMENT_PARTIAL = 'partial'
    PAYMENT_NA = 'na'
    PAYMENT_STATUS_CHOICES = [
        (PAYMENT_YES, 'Received'),
        (PAYMENT_NO, 'Pending'),
        (PAYMENT_PARTIAL, 'Partially Received'),
        (PAYMENT_NA, 'Not Applicable'),
    ]

    certificate = models.OneToOneField(Certificate, on_delete=models.CASCADE, related_name='payment')
    payment_status = models.CharField(max_length=10, choices=PAYMENT_STATUS_CHOICES, default=PAYMENT_NO)
    amount = models.DecimalField(max_digits=15, decimal_places=2, default=0, verbose_name='Fee Amount (₹)')
    amount_received = models.DecimalField(max_digits=15, decimal_places=2, default=0, verbose_name='Amount Received (₹)')
    outstanding_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0, verbose_name='Outstanding Amount (₹)')
    received_date = models.DateField(null=True, blank=True, verbose_name='Payment Received Date')
    payment_reference = models.CharField(max_length=200, blank=True, verbose_name='Payment Reference / Remarks')
    remarks = models.TextField(blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'Payment Record'
        verbose_name_plural = 'Payment Records'

    def __str__(self):
        return f"{self.certificate.cert_number} — {self.get_payment_status_display()}"

    def save(self, *args, **kwargs):
        self.outstanding_amount = max(0, self.amount - self.amount_received)
        super().save(*args, **kwargs)

from django.urls import path
from . import views

app_name = 'payments'

urlpatterns = [
    path('<int:cert_pk>/update/', views.PaymentUpdateView.as_view(), name='update'),
    path('register/', views.PaymentRegisterView.as_view(), name='register'),
]

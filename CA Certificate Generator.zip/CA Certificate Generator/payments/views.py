from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib import messages
from django.views import View
from django.core.paginator import Paginator
from certificates.models import Certificate
from .models import PaymentRecord
from .forms import PaymentForm


class PaymentUpdateView(LoginRequiredMixin, View):
    template_name = 'payments/payment_form.html'

    def get_cert_and_payment(self, cert_pk):
        cert = get_object_or_404(Certificate, pk=cert_pk)
        payment, _ = PaymentRecord.objects.get_or_create(certificate=cert)
        return cert, payment

    def get(self, request, cert_pk):
        cert, payment = self.get_cert_and_payment(cert_pk)
        form = PaymentForm(instance=payment)
        return render(request, self.template_name, {'form': form, 'cert': cert, 'payment': payment})

    def post(self, request, cert_pk):
        cert, payment = self.get_cert_and_payment(cert_pk)
        form = PaymentForm(request.POST, instance=payment)
        if form.is_valid():
            form.save()
            messages.success(request, 'Payment record updated.')
            return redirect('certificates:detail', pk=cert_pk)
        return render(request, self.template_name, {'form': form, 'cert': cert, 'payment': payment})


class PaymentRegisterView(LoginRequiredMixin, View):
    template_name = 'payments/register.html'

    def get(self, request):
        status = request.GET.get('status', '')
        certs = Certificate.objects.select_related('entity', 'firm', 'payment').all()
        if status:
            certs = certs.filter(payment__payment_status=status)
        paginator = Paginator(certs, 25)
        page = paginator.get_page(request.GET.get('page', 1))
        return render(request, self.template_name, {'page_obj': page, 'status': status})

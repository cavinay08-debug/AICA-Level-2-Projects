# CA Certificate Manager — Setup Guide

## Prerequisites

- **Python 3.10+** (Python 3.12+ recommended)
- **pip** (comes with Python)

---

## Quick Start (Windows)

### Option A — Double-click to Start

Simply double-click **`start.bat`** in this folder. It will:
1. Install all dependencies
2. Apply database migrations
3. Seed the 3 CA firms
4. Create the admin user (if not already done)
5. Start the server and open the browser

> **Login credentials (first run):**
> - **Username:** `admin`
> - **Password:** `Admin@123`
> - _Please change your password after first login._

---

### Option B — Manual Setup

Open a **Command Prompt** or **PowerShell** in this folder and run:

```batch
# 1. Install dependencies
pip install -r requirements.txt

# 2. Apply database migrations
python manage.py migrate

# 3. Seed the 3 CA firms
python manage.py seed_firms

# 4. Create the admin user
python manage.py create_admin

# 5. Start the development server
python manage.py runserver 8000
```

Then open your browser and go to: **http://localhost:8000**

---

## Firm Master Data (Pre-configured)

The application comes pre-loaded with the following 3 CA firms:

| Short Code | Firm Name | FRN | Signing CA | M. No. |
|-----------|-----------|-----|-----------|--------|
| **AKG** | Arvinder Kumar Gupta & Co | 006878N | Arvinder Kumar Gupta | 085117 |
| **YV** | Yash Vijay & Co | 034378C | Yash Vijay | 450155 |
| **AKYV** | A K Y V and Co LLP | FNA269039 | Arvinder Kumar Gupta | 085117 |

---

## Certificate Number Format

Certificates are automatically numbered in the format:
```
{FIRM_CODE}/{FY}/{SEQ}
```
**Examples:** `AKG/2026-27/001`, `YV/2026-27/001`, `AKYV/2026-27/001`

The sequence resets every financial year (April 1).

---

## User Roles

| Role | Permissions |
|------|-------------|
| **Admin** | Full access — create/edit/delete all records, finalize certificates, manage users |
| **Staff** | Create & edit Draft certificates, view all records, generate PDF/DOCX |

---

## Adding Staff Users

1. Login as admin → **Administration > Users > Create User**
2. Set Role = Staff
3. (Optional) Restrict to specific firms using "Firm Access"

---

## Certificate Types Supported

1. **Net Worth Certificate** — Assets/liabilities table, net worth calculation
2. **Turnover Certificate** — Revenue by financial year
3. **List of Directors** — DIN, designation, appointment dates
4. **List of Shareholders** — Shareholding table with totals
5. **List of Partners** — Partnership/LLP partner details
6. **End-Use / Utilisation Certificate** — Utilisation details, balance
7. **General / Custom Certificate** — Free-form with guided statements

---

## Importing Director / Shareholder / Partner Data

Go to **Masters > Import Data** and upload an Excel/CSV file.

The system accepts the following columns:

**Directors:** DIN, Full Name, Father's Name, Address, PAN, DOB, Designation, Date of Appointment

**Shareholders:** Name, Father's Name, Address, PAN, Share Class, No. of Shares, % Holding, Folio/DP ID

**Partners:** Name, Father's Name, Address, PAN, Designation, Profit Sharing Ratio (%), Date of Joining

---

## UDIN Workflow

1. Create and **Finalize** the certificate in this system
2. Login to the **ICAI UDIN portal** (https://udin.icai.org) and generate the UDIN
3. Return to this system → Open the certificate → **Enter UDIN**
4. The UDIN will appear on all future PDF/DOCX downloads

---

## PDF & DOCX Generation

- **PDF** — Uses WeasyPrint for professional, print-ready output
- **DOCX** — Uses python-docx for editable Word documents
- Both include: ICAI logo letterhead, firm details, signature block, UDIN
- **Draft** certificates show a "DRAFT" watermark

---

## Database

The system uses **SQLite** by default — the database file is `db.sqlite3` in this folder.

**Backup:** Simply copy `db.sqlite3` to a safe location.

**For production deployment:** Switch to PostgreSQL by updating `DATABASES` in `ca_cert_project/settings.py`.

---

## Troubleshooting

**Port already in use?**
```batch
python manage.py runserver 8001
```
Then open http://localhost:8001

**Forgot admin password?**
```batch
python manage.py changepassword admin
```

**Database issues?**
```batch
del db.sqlite3
python manage.py migrate
python manage.py seed_firms
python manage.py create_admin
```

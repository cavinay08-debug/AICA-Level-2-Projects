from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate, update_session_auth_hash
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.forms import PasswordChangeForm
from django.views import View
from django.contrib import messages
from django.core.paginator import Paginator
from .models import User, AuditLog
from .forms import LoginForm, UserCreateForm, UserUpdateForm
from .middleware import AuditMiddleware


def admin_required(view_func):
    from functools import wraps
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated or not request.user.is_admin():
            messages.error(request, 'Administrator access required.')
            return redirect('dashboard:home')
        return view_func(request, *args, **kwargs)
    return wrapper


class LoginView(View):
    template_name = 'accounts/login.html'

    def get(self, request):
        if request.user.is_authenticated:
            return redirect('dashboard:home')
        return render(request, self.template_name, {'form': LoginForm()})

    def post(self, request):
        form = LoginForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            AuditMiddleware.log(user, AuditLog.ACTION_LOGIN, request=request)
            messages.success(request, f'Welcome back, {user.get_full_name() or user.username}!')
            return redirect(request.GET.get('next', 'dashboard:home'))
        messages.error(request, 'Invalid username or password.')
        return render(request, self.template_name, {'form': form})


class LogoutView(LoginRequiredMixin, View):
    def post(self, request):
        AuditMiddleware.log(request.user, AuditLog.ACTION_LOGOUT, request=request)
        logout(request)
        messages.info(request, 'You have been logged out.')
        return redirect('accounts:login')

    def get(self, request):
        return self.post(request)


class UserListView(LoginRequiredMixin, View):
    template_name = 'accounts/user_list.html'

    def get(self, request):
        if not request.user.is_admin():
            messages.error(request, 'Access denied.')
            return redirect('dashboard:home')
        users = User.objects.all().order_by('username')
        return render(request, self.template_name, {'users': users})


class UserCreateView(LoginRequiredMixin, View):
    template_name = 'accounts/user_form.html'

    def get(self, request):
        if not request.user.is_admin():
            return redirect('dashboard:home')
        return render(request, self.template_name, {'form': UserCreateForm(), 'title': 'Create User'})

    def post(self, request):
        if not request.user.is_admin():
            return redirect('dashboard:home')
        form = UserCreateForm(request.POST)
        if form.is_valid():
            user = form.save()
            AuditMiddleware.log(request.user, AuditLog.ACTION_CREATE, 'User', user.pk, str(user), request=request)
            messages.success(request, f'User {user.username} created successfully.')
            return redirect('accounts:user_list')
        return render(request, self.template_name, {'form': form, 'title': 'Create User'})


class UserUpdateView(LoginRequiredMixin, View):
    template_name = 'accounts/user_form.html'

    def get(self, request, pk):
        if not request.user.is_admin():
            return redirect('dashboard:home')
        user = get_object_or_404(User, pk=pk)
        return render(request, self.template_name, {'form': UserUpdateForm(instance=user), 'title': 'Edit User', 'obj': user})

    def post(self, request, pk):
        if not request.user.is_admin():
            return redirect('dashboard:home')
        user = get_object_or_404(User, pk=pk)
        form = UserUpdateForm(request.POST, instance=user)
        if form.is_valid():
            form.save()
            AuditMiddleware.log(request.user, AuditLog.ACTION_UPDATE, 'User', user.pk, str(user), request=request)
            messages.success(request, 'User updated successfully.')
            return redirect('accounts:user_list')
        return render(request, self.template_name, {'form': form, 'title': 'Edit User', 'obj': user})


class ChangePasswordView(LoginRequiredMixin, View):
    template_name = 'accounts/change_password.html'

    def get(self, request, pk):
        if not request.user.is_admin() and request.user.pk != pk:
            return redirect('dashboard:home')
        user = get_object_or_404(User, pk=pk)
        return render(request, self.template_name, {'form': PasswordChangeForm(user), 'obj': user})

    def post(self, request, pk):
        if not request.user.is_admin() and request.user.pk != pk:
            return redirect('dashboard:home')
        user = get_object_or_404(User, pk=pk)
        form = PasswordChangeForm(user, request.POST)
        if form.is_valid():
            form.save()
            if request.user.pk == pk:
                update_session_auth_hash(request, user)
            messages.success(request, 'Password changed successfully.')
            return redirect('accounts:user_list')
        return render(request, self.template_name, {'form': form, 'obj': user})


class AuditLogView(LoginRequiredMixin, View):
    template_name = 'accounts/audit_log.html'

    def get(self, request):
        if not request.user.is_admin():
            return redirect('dashboard:home')
        qs = AuditLog.objects.select_related('user').all()
        paginator = Paginator(qs, 50)
        page = paginator.get_page(request.GET.get('page', 1))
        return render(request, self.template_name, {'page_obj': page})

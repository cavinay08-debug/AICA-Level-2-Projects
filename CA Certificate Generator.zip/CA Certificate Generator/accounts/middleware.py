from django.utils.deprecation import MiddlewareMixin
from .models import AuditLog


def get_client_ip(request):
    x_forwarded = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded:
        return x_forwarded.split(',')[0].strip()
    return request.META.get('REMOTE_ADDR')


class AuditMiddleware(MiddlewareMixin):
    """Logs login/logout events."""

    def process_request(self, request):
        pass  # Additional per-request logging can go here

    @staticmethod
    def log(user, action, model_name='', object_id='', object_repr='', changes='', request=None):
        ip = get_client_ip(request) if request else None
        AuditLog.objects.create(
            user=user,
            action=action,
            model_name=model_name,
            object_id=str(object_id),
            object_repr=object_repr[:255],
            changes=changes[:5000],
            ip_address=ip,
        )

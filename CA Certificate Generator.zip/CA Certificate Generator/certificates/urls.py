from django.urls import path
from . import views

app_name = 'certificates'

urlpatterns = [
    path('', views.CertificateListView.as_view(), name='list'),
    path('create/', views.CertificateTypeSelectView.as_view(), name='create_select'),
    path('create/<str:cert_type>/', views.CertificateCreateView.as_view(), name='create'),
    path('<int:pk>/', views.CertificateDetailView.as_view(), name='detail'),
    path('<int:pk>/edit/', views.CertificateEditView.as_view(), name='edit'),
    path('<int:pk>/status/', views.CertificateStatusView.as_view(), name='status'),
    path('<int:pk>/pdf/', views.CertificatePDFView.as_view(), name='pdf'),
    path('<int:pk>/docx/', views.CertificateDOCXView.as_view(), name='docx'),
    path('<int:pk>/preview/', views.CertificatePreviewView.as_view(), name='preview'),
    path('<int:pk>/udin/', views.UDINUpdateView.as_view(), name='udin_update'),
    path('<int:pk>/versions/', views.CertificateVersionsView.as_view(), name='versions'),
]

"""
DOCX Certificate Generator using python-docx.
Generates editable Word documents mirroring the PDF layout.
"""
import json
import io
from pathlib import Path
from django.conf import settings
from docx import Document
from docx.shared import Pt, Inches, RGBColor, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement


FIRM_BLUE = RGBColor(0x1a, 0x3a, 0x6e)
DARK_GREY = RGBColor(0x44, 0x44, 0x44)


def add_hr(doc, color='1a3a6e', thickness=24):
    """Add a horizontal rule."""
    p = doc.add_paragraph()
    p_pr = p._p.get_or_add_pPr()
    p_bdr = OxmlElement('w:pBdr')
    bottom = OxmlElement('w:bottom')
    bottom.set(qn('w:val'), 'single')
    bottom.set(qn('w:sz'), str(thickness))
    bottom.set(qn('w:space'), '1')
    bottom.set(qn('w:color'), color)
    p_bdr.append(bottom)
    p_pr.append(p_bdr)
    p.paragraph_format.space_after = Pt(4)
    return p


def set_cell_bg(cell, hex_color):
    """Set table cell background color."""
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear')
    shd.set(qn('w:color'), 'auto')
    shd.set(qn('w:fill'), hex_color)
    tc_pr.append(shd)


def generate_docx(certificate):
    """Generate a DOCX document for the given Certificate."""
    doc = Document()

    # Page margins
    section = doc.sections[0]
    section.page_width = Cm(21)
    section.page_height = Cm(29.7)
    section.top_margin = Cm(2)
    section.bottom_margin = Cm(2.5)
    section.left_margin = Cm(2)
    section.right_margin = Cm(2)

    firm = certificate.firm
    detail = certificate.get_cert_detail()

    # ── LETTERHEAD ──────────────────────────────────────────────────
    logo_path = Path(settings.BASE_DIR) / 'static' / 'images' / 'icai_logo.jpg'

    # Centered Logo
    if logo_path.exists():
        logo_p = doc.add_paragraph()
        logo_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        logo_p.paragraph_format.space_after = Pt(2)
        logo_run = logo_p.add_run()
        logo_run.add_picture(str(logo_path), width=Cm(1.5))

    # Centered Firm details
    firm_p = doc.add_paragraph()
    firm_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    firm_p.paragraph_format.space_after = Pt(1)
    run = firm_p.add_run(firm.name.upper())
    run.bold = True
    run.font.size = Pt(13)
    run.font.color.rgb = FIRM_BLUE

    p2 = doc.add_paragraph(f"Chartered Accountant{'s' if firm.firm_type != 'proprietorship' else ''}")
    p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p2.paragraph_format.space_after = Pt(1)
    p2.runs[0].font.size = Pt(8.5)
    p2.runs[0].italic = True

    p3 = doc.add_paragraph(f"FRN: {firm.frn_number}")
    p3.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p3.paragraph_format.space_after = Pt(1)
    p3.runs[0].font.size = Pt(8.5)

    p4 = doc.add_paragraph(firm.address)
    p4.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p4.paragraph_format.space_after = Pt(4)
    p4.runs[0].font.size = Pt(8)
    p4.runs[0].font.color.rgb = DARK_GREY

    add_hr(doc)

    # Draft notice
    if certificate.is_draft():
        draft_p = doc.add_paragraph('DRAFT – NOT VALID FOR USE')
        draft_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = draft_p.runs[0]
        run.bold = True
        run.font.size = Pt(11)
        run.font.color.rgb = RGBColor(0xCC, 0x00, 0x00)

    # ── CERTIFICATE TITLE ───────────────────────────────────────────
    title_p = doc.add_paragraph()
    title_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title_p.paragraph_format.space_before = Pt(10)
    run = title_p.add_run(certificate.get_cert_type_display().upper())
    run.bold = True
    run.font.size = Pt(13)
    run.font.color.rgb = FIRM_BLUE
    run.underline = True

    num_p = doc.add_paragraph(f"Certificate No.: {certificate.cert_number}")
    num_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    num_p.runs[0].font.size = Pt(9.5)

    # ── META BOX ───────────────────────────────────────────────────
    doc.add_paragraph()
    meta_table = doc.add_table(rows=0, cols=2)
    meta_table.style = 'Table Grid'
    meta_table.autofit = False
    meta_table.columns[0].width = Cm(5)
    meta_table.columns[1].width = Cm(14)

    def add_meta_row(label, value):
        row = meta_table.add_row()
        cell_label = row.cells[0]
        cell_value = row.cells[1]
        set_cell_bg(cell_label, 'f8fafd')
        p = cell_label.paragraphs[0]
        run = p.add_run(label)
        run.bold = True
        run.font.size = Pt(9.5)
        run.font.color.rgb = FIRM_BLUE
        cell_value.paragraphs[0].add_run(str(value or '')).font.size = Pt(9.5)

    add_meta_row('Entity Name:', certificate.entity_name_on_cert)
    add_meta_row('Entity Type:', certificate.get_entity_type_display_on_cert())
    if certificate.pan_on_cert:
        add_meta_row('PAN:', certificate.pan_on_cert)
    if certificate.gstin_on_cert:
        add_meta_row('GSTIN:', certificate.gstin_on_cert)
    if certificate.cin_on_cert:
        add_meta_row('CIN:', certificate.cin_on_cert)
    if certificate.llpin_on_cert:
        add_meta_row('LLPIN:', certificate.llpin_on_cert)
    if certificate.address_on_cert:
        add_meta_row('Registered Address:', certificate.address_on_cert)
    add_meta_row('Financial Year / Period:', certificate.financial_year or '')
    add_meta_row('Date of Certificate:', certificate.issue_date.strftime('%d-%m-%Y'))
    add_meta_row('Place of Issue:', certificate.place_of_issue)

    doc.add_paragraph()

    # ── ADDRESSEE ──────────────────────────────────────────────────
    addr_p = doc.add_paragraph()
    addr_run = addr_p.add_run(certificate.addressee or 'To Whomsoever It May Concern')
    addr_run.bold = True
    addr_run.underline = True
    addr_run.font.size = Pt(10.5)

    # ── PURPOSE OF CERTIFICATE ──────────────────────────────────────
    if certificate.purpose:
        purpose_p = doc.add_paragraph()
        purpose_p.paragraph_format.space_before = Pt(6)
        purpose_p.paragraph_format.space_after = Pt(6)
        p_run_lbl = purpose_p.add_run('Purpose of Certificate: ')
        p_run_lbl.bold = True
        p_run_lbl.font.color.rgb = FIRM_BLUE
        p_run_lbl.font.size = Pt(9.5)
        p_run_val = purpose_p.add_run(certificate.purpose)
        p_run_val.font.size = Pt(9.5)

    doc.add_paragraph()

    # ── SPECIFIC CERT CONTENT ──────────────────────────────────────
    _add_cert_body(doc, certificate, detail)

    # ── SIGNATURE BLOCK ────────────────────────────────────────────
    doc.add_paragraph()
    doc.add_paragraph()
    sig_p = doc.add_paragraph('For ')
    run = sig_p.add_run(firm.name)
    run.bold = True
    run.font.color.rgb = FIRM_BLUE
    sig_p.add_run(f'\nFRN: {firm.frn_number}')

    # Signature space
    doc.add_paragraph()
    doc.add_paragraph()

    sig_line = doc.add_paragraph()
    run = sig_line.add_run(firm.signing_ca_name)
    run.bold = True
    run.font.size = Pt(10.5)
    sig_line.add_run(f'\nProprietor / Partner'
                     f'\nM. No.: {firm.membership_number}')

    udin_p = doc.add_paragraph()
    if certificate.udin_number:
        udin_p.add_run(f'UDIN: {certificate.udin_number}')
        udin_p.runs[-1].font.size = Pt(9)
    else:
        udin_p.add_run('UDIN: [To be filled after generation on ICAI portal]')
        udin_p.runs[-1].font.size = Pt(9)
        udin_p.runs[-1].font.color.rgb = RGBColor(0xAA, 0x00, 0x00)

    place_date_p = doc.add_paragraph(
        f"Place: {certificate.place_of_issue}     Date: {certificate.issue_date.strftime('%d-%m-%Y')}"
    )
    place_date_p.runs[0].font.size = Pt(9.5)

    # ── FOOTER ────────────────────────────────────────────────────
    add_hr(doc)
    footer_p = doc.add_paragraph(
        'This certificate is issued based on information and documents provided by the management. '
        'It is not to be used for any purpose other than the one stated herein.'
    )
    footer_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer_p.runs[0].font.size = Pt(8)
    footer_p.runs[0].font.color.rgb = DARK_GREY

    buf = io.BytesIO()
    doc.save(buf)
    buf.seek(0)
    return buf.read()


def _add_cert_body(doc, certificate, detail):
    """Add certificate-type-specific content."""
    cert_type = certificate.cert_type

    if cert_type == 'net_worth' and detail:
        _add_net_worth_body(doc, certificate, detail)
    elif cert_type == 'turnover' and detail:
        _add_turnover_body(doc, certificate, detail)
    elif cert_type == 'director_list' and detail:
        _add_director_list_body(doc, certificate, detail)
    elif cert_type == 'shareholder_list' and detail:
        _add_shareholder_list_body(doc, certificate, detail)
    elif cert_type == 'partner_list' and detail:
        _add_partner_list_body(doc, certificate, detail)
    elif cert_type == 'end_use' and detail:
        _add_end_use_body(doc, certificate, detail)
    elif cert_type == 'custom' and detail:
        _add_custom_body(doc, certificate, detail)


def _add_net_worth_body(doc, cert, detail):
    firm = cert.firm
    entity = cert.entity_name_on_cert

    p = doc.add_paragraph()
    p.add_run(
        f"This is to certify that based on the books of account, records, and documents "
        f"produced before us and as per information and explanations given to us, the Net Worth "
        f"of {entity} as at {detail.valuation_date.strftime('%d-%m-%Y')} is as under:"
    )

    # Assets table
    doc.add_paragraph('ASSETS', style='Heading 3')
    assets = detail.get_assets()
    if assets:
        tbl = doc.add_table(rows=1, cols=2)
        tbl.style = 'Table Grid'
        tbl.cell(0, 0).paragraphs[0].add_run('Particulars').bold = True
        tbl.cell(0, 1).paragraphs[0].add_run('Amount (₹)').bold = True
        set_cell_bg(tbl.cell(0, 0), '1a3a6e')
        set_cell_bg(tbl.cell(0, 1), '1a3a6e')
        total = 0
        for item in assets:
            row = tbl.add_row()
            row.cells[0].text = item.get('description', '')
            amt = float(item.get('amount', 0))
            row.cells[1].text = f"₹ {amt:,.2f}"
            row.cells[1].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT
            total += amt
        tr = tbl.add_row()
        tr.cells[0].paragraphs[0].add_run('Total Assets').bold = True
        tr.cells[1].paragraphs[0].add_run(f"₹ {total:,.2f}").bold = True

    # Liabilities table
    doc.add_paragraph('LIABILITIES', style='Heading 3')
    liabs = detail.get_liabilities()
    if liabs:
        tbl2 = doc.add_table(rows=1, cols=2)
        tbl2.style = 'Table Grid'
        tbl2.cell(0, 0).paragraphs[0].add_run('Particulars').bold = True
        tbl2.cell(0, 1).paragraphs[0].add_run('Amount (₹)').bold = True
        total_l = 0
        for item in liabs:
            row = tbl2.add_row()
            row.cells[0].text = item.get('description', '')
            amt = float(item.get('amount', 0))
            row.cells[1].text = f"₹ {amt:,.2f}"
            total_l += amt
        tr2 = tbl2.add_row()
        tr2.cells[0].paragraphs[0].add_run('Total Liabilities').bold = True
        tr2.cells[1].paragraphs[0].add_run(f"₹ {total_l:,.2f}").bold = True

    nw_p = doc.add_paragraph()
    nw_run = nw_p.add_run(f"NET WORTH (Total Assets – Total Liabilities): ₹ {detail.net_worth:,.2f}")
    nw_run.bold = True
    nw_run.font.size = Pt(11)

    if detail.certification_para:
        doc.add_paragraph(detail.certification_para)


def _add_turnover_body(doc, cert, detail):
    entity = cert.entity_name_on_cert
    data = detail.get_turnover_data()

    doc.add_paragraph(
        f"This is to certify that based on the books of account, audited financial statements, "
        f"and other records of {entity}, the turnover/revenue for the period(s) stated "
        f"hereunder is as follows:"
    )

    if data:
        cols = ['Financial Year', 'Total Turnover (₹)', 'GST Turnover (₹)', 'Source Records']
        tbl = doc.add_table(rows=1, cols=len(cols))
        tbl.style = 'Table Grid'
        for i, col in enumerate(cols):
            cell = tbl.cell(0, i)
            cell.paragraphs[0].add_run(col).bold = True
            set_cell_bg(cell, '1a3a6e')

        for item in data:
            row = tbl.add_row()
            row.cells[0].text = item.get('financial_year', '')
            turnover = float(item.get('turnover', 0))
            gst_turnover = float(item.get('gst_turnover', 0))
            row.cells[1].text = f"₹ {turnover:,.2f}"
            row.cells[2].text = f"₹ {gst_turnover:,.2f}" if gst_turnover else 'N/A'
            row.cells[3].text = item.get('source_records', '')

    if detail.certification_para:
        doc.add_paragraph(detail.certification_para)


def _add_director_list_body(doc, cert, detail):
    entity = cert.entity_name_on_cert
    directors = detail.get_directors_data()

    doc.add_paragraph(
        f"This is to certify that as per the records of {entity} and "
        f"documents produced before us, the following persons are Directors of the Company "
        f"as on {detail.source_date.strftime('%d-%m-%Y') if detail.source_date else 'date of certificate'}:"
    )

    if directors:
        cols = ['S.No.', 'DIN', 'Name of Director', "Father's Name", 'Designation', 'Date of Appointment', 'Address']
        tbl = doc.add_table(rows=1, cols=len(cols))
        tbl.style = 'Table Grid'
        for i, col in enumerate(cols):
            c = tbl.cell(0, i)
            c.paragraphs[0].add_run(col).bold = True
            set_cell_bg(c, '1a3a6e')

        for idx, d in enumerate(directors, 1):
            row = tbl.add_row()
            row.cells[0].text = str(idx)
            row.cells[1].text = d.get('din', '')
            row.cells[2].text = d.get('full_name', '')
            row.cells[3].text = d.get('father_name', '')
            row.cells[4].text = d.get('designation', '')
            row.cells[5].text = d.get('date_of_appointment', '')
            row.cells[6].text = d.get('address', '')

    if detail.certification_para:
        doc.add_paragraph(detail.certification_para)


def _add_shareholder_list_body(doc, cert, detail):
    entity = cert.entity_name_on_cert
    shareholders = detail.get_shareholders_data()

    doc.add_paragraph(
        f"This is to certify that as per the records of {entity} and "
        f"documents produced before us, the following persons are Shareholders of the Company:"
    )

    if shareholders:
        cols = ['S.No.', 'Name', "Father's Name", 'Address', 'PAN', 'Share Class', 'No. of Shares', '% Holding', 'Folio/DP ID']
        tbl = doc.add_table(rows=1, cols=len(cols))
        tbl.style = 'Table Grid'
        for i, col in enumerate(cols):
            c = tbl.cell(0, i)
            c.paragraphs[0].add_run(col).bold = True
            set_cell_bg(c, '1a3a6e')

        for idx, s in enumerate(shareholders, 1):
            row = tbl.add_row()
            row.cells[0].text = str(idx)
            row.cells[1].text = s.get('name', '')
            row.cells[2].text = s.get('father_name', '')
            row.cells[3].text = s.get('address', '')
            row.cells[4].text = s.get('pan', '')
            row.cells[5].text = s.get('share_class', '')
            row.cells[6].text = str(s.get('num_shares', ''))
            row.cells[7].text = f"{s.get('percentage_holding', '')}%"
            row.cells[8].text = s.get('folio_dp_id', '')

        # Totals row
        tr = tbl.add_row()
        tr.cells[0].paragraphs[0].add_run('TOTAL').bold = True
        tr.cells[6].paragraphs[0].add_run(str(detail.total_shares)).bold = True
        tr.cells[7].paragraphs[0].add_run('100%').bold = True

    if detail.certification_para:
        doc.add_paragraph(detail.certification_para)


def _add_partner_list_body(doc, cert, detail):
    entity = cert.entity_name_on_cert
    partners = detail.get_partners_data()

    doc.add_paragraph(
        f"This is to certify that as per the records of {entity} and "
        f"documents produced before us, the following persons are Partners / "
        f"Designated Partners of the Firm/LLP:"
    )

    if partners:
        cols = ['S.No.', 'Name', "Father's Name", 'Address', 'PAN', 'Designation', 'Profit Sharing Ratio (%)', 'Date of Joining']
        tbl = doc.add_table(rows=1, cols=len(cols))
        tbl.style = 'Table Grid'
        for i, col in enumerate(cols):
            c = tbl.cell(0, i)
            c.paragraphs[0].add_run(col).bold = True
            set_cell_bg(c, '1a3a6e')

        for idx, p in enumerate(partners, 1):
            row = tbl.add_row()
            row.cells[0].text = str(idx)
            row.cells[1].text = p.get('name', '')
            row.cells[2].text = p.get('father_name', '')
            row.cells[3].text = p.get('address', '')
            row.cells[4].text = p.get('pan', '')
            row.cells[5].text = p.get('designation', '')
            row.cells[6].text = f"{p.get('profit_sharing_ratio', '')}%"
            row.cells[7].text = p.get('date_of_joining', '')

    if detail.certification_para:
        doc.add_paragraph(detail.certification_para)


def _add_end_use_body(doc, cert, detail):
    entity = cert.entity_name_on_cert
    utilisation = detail.get_utilisation_data()

    doc.add_paragraph(
        f"This is to certify that {entity} has received an amount of "
        f"₹ {detail.amount_received:,.2f} from {detail.source_of_funds or '___'} "
        f"for the sanctioned purpose of: {detail.sanctioned_purpose or '___'}. "
        f"The said amount has been utilised as under:"
    )

    if utilisation:
        cols = ['S.No.', 'Particulars of Utilisation', 'Amount Utilised (₹)', 'Remarks']
        tbl = doc.add_table(rows=1, cols=len(cols))
        tbl.style = 'Table Grid'
        for i, col in enumerate(cols):
            c = tbl.cell(0, i)
            c.paragraphs[0].add_run(col).bold = True
            set_cell_bg(c, '1a3a6e')

        total = 0
        for idx, u in enumerate(utilisation, 1):
            row = tbl.add_row()
            row.cells[0].text = str(idx)
            row.cells[1].text = u.get('particulars', '')
            amt = float(u.get('amount_utilised', 0))
            row.cells[2].text = f"₹ {amt:,.2f}"
            row.cells[3].text = u.get('remarks', '')
            total += amt

        tr = tbl.add_row()
        tr.cells[1].paragraphs[0].add_run('Total Amount Utilised').bold = True
        tr.cells[2].paragraphs[0].add_run(f"₹ {total:,.2f}").bold = True

    bal_p = doc.add_paragraph()
    bal_p.add_run(f"Unutilised Balance: ₹ {detail.unutilised_balance:,.2f}").bold = True

    if detail.certification_para:
        doc.add_paragraph(detail.certification_para)


def _add_custom_body(doc, cert, detail):
    doc.add_paragraph(f"Subject: {detail.subject}")
    doc.add_paragraph()

    statements = detail.get_statements()
    for stmt in statements:
        doc.add_paragraph(stmt, style='List Number')

    schedules = detail.get_schedules()
    for sched in schedules:
        doc.add_paragraph(sched.get('title', 'Schedule'), style='Heading 3')
        rows_data = sched.get('rows', [])
        if rows_data and isinstance(rows_data, list) and isinstance(rows_data[0], dict):
            cols = list(rows_data[0].keys())
            tbl = doc.add_table(rows=1, cols=len(cols))
            tbl.style = 'Table Grid'
            for i, col in enumerate(cols):
                c = tbl.cell(0, i)
                c.paragraphs[0].add_run(col).bold = True
                set_cell_bg(c, '1a3a6e')
            for row_data in rows_data:
                row = tbl.add_row()
                for i, col in enumerate(cols):
                    row.cells[i].text = str(row_data.get(col, ''))

    if detail.qualifications:
        doc.add_paragraph('Qualifications / Disclaimers', style='Heading 3')
        doc.add_paragraph(detail.qualifications)

    if detail.certification_para:
        doc.add_paragraph(detail.certification_para)


def save_docx_to_cert(certificate):
    """Generate DOCX and save it to the Certificate record."""
    from django.core.files.base import ContentFile
    import datetime

    docx_bytes = generate_docx(certificate)
    filename = f"{certificate.cert_number.replace('/', '_')}_{datetime.date.today()}.docx"
    certificate.docx_file.save(filename, ContentFile(docx_bytes), save=True)
    return certificate.docx_file.url

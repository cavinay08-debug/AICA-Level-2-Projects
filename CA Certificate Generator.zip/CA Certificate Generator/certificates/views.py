import json
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib import messages
from django.views import View
from django.http import HttpResponse, JsonResponse
from django.core.paginator import Paginator
from django.db.models import Q
from .models import (Certificate, NetWorthCertificate, TurnoverCertificate,
                     DirectorListCertificate, ShareholderListCertificate,
                     PartnerListCertificate, EndUseCertificate, CustomCertificate,
                     CertificateVersion)
from .forms import (BaseCertificateForm, UDINForm, DETAIL_FORM_MAP)
from firms.models import CAFirm, CertificateNumberConfig
from clients.models import Entity
from payments.models import PaymentRecord


CERT_TYPE_LABELS = {
    'net_worth': 'Net Worth Certificate',
    'turnover': 'Turnover Certificate',
    'director_list': 'CA Certified List of Directors',
    'shareholder_list': 'CA Certified List of Shareholders',
    'partner_list': 'CA Certified List of Partners',
    'end_use': 'End-Use / Utilisation Certificate',
    'custom': 'General / Custom CA Certificate',
}

DETAIL_MODEL_MAP = {
    'net_worth': NetWorthCertificate,
    'turnover': TurnoverCertificate,
    'director_list': DirectorListCertificate,
    'shareholder_list': ShareholderListCertificate,
    'partner_list': PartnerListCertificate,
    'end_use': EndUseCertificate,
    'custom': CustomCertificate,
}

DETAIL_TEMPLATE_MAP = {
    'net_worth': 'certificates/forms/net_worth.html',
    'turnover': 'certificates/forms/turnover.html',
    'director_list': 'certificates/forms/director_list.html',
    'shareholder_list': 'certificates/forms/shareholder_list.html',
    'partner_list': 'certificates/forms/partner_list.html',
    'end_use': 'certificates/forms/end_use.html',
    'custom': 'certificates/forms/custom.html',
}


def generate_cert_number(firm):
    """Get next certificate number for a firm."""
    try:
        config = firm.number_config
    except Exception:
        import datetime
        today = datetime.date.today()
        if today.month >= 4:
            fy = f"{today.year}-{str(today.year+1)[2:]}"
        else:
            fy = f"{today.year-1}-{str(today.year)[2:]}"
        config = CertificateNumberConfig.objects.create(
            firm=firm,
            prefix=firm.short_code,
            current_fy=fy,
            current_sequence=0,
        )
    return config.get_next_number()


class CertificateListView(LoginRequiredMixin, View):
    template_name = 'certificates/list.html'

    def get(self, request):
        certs = Certificate.objects.select_related('firm', 'entity').all()

        # Filters
        q = request.GET.get('q', '')
        cert_type = request.GET.get('cert_type', '')
        firm_id = request.GET.get('firm', '')
        status = request.GET.get('status', '')
        udin_status = request.GET.get('udin_status', '')
        date_from = request.GET.get('date_from', '')
        date_to = request.GET.get('date_to', '')

        if q:
            certs = certs.filter(
                Q(cert_number__icontains=q) |
                Q(entity_name_on_cert__icontains=q) |
                Q(pan_on_cert__icontains=q)
            )
        if cert_type:
            certs = certs.filter(cert_type=cert_type)
        if firm_id:
            certs = certs.filter(firm_id=firm_id)
        if status:
            certs = certs.filter(status=status)
        if udin_status:
            certs = certs.filter(udin_status=udin_status)
        if date_from:
            certs = certs.filter(issue_date__gte=date_from)
        if date_to:
            certs = certs.filter(issue_date__lte=date_to)

        paginator = Paginator(certs, 25)
        page = paginator.get_page(request.GET.get('page', 1))

        return render(request, self.template_name, {
            'page_obj': page,
            'cert_types': Certificate.TYPE_CHOICES,
            'firms': CAFirm.objects.filter(is_active=True),
            'status_choices': Certificate.STATUS_CHOICES,
            'udin_choices': Certificate.UDIN_STATUS_CHOICES,
            'q': q, 'cert_type': cert_type, 'firm_id': firm_id,
            'status': status, 'udin_status': udin_status,
            'date_from': date_from, 'date_to': date_to,
        })


class CertificateTypeSelectView(LoginRequiredMixin, View):
    def get(self, request):
        return render(request, 'certificates/type_select.html', {
            'cert_types': CERT_TYPE_LABELS,
        })


class CertificateCreateView(LoginRequiredMixin, View):
    def get_template(self, cert_type):
        return DETAIL_TEMPLATE_MAP.get(cert_type, 'certificates/forms/custom.html')

    def get(self, request, cert_type):
        if cert_type not in CERT_TYPE_LABELS:
            messages.error(request, 'Invalid certificate type.')
            return redirect('certificates:create_select')

        base_form = BaseCertificateForm(cert_type=cert_type)
        detail_form_cls = DETAIL_FORM_MAP.get(cert_type)
        detail_form = detail_form_cls() if detail_form_cls else None

        # Auto-fill firm if only one
        firms = CAFirm.objects.filter(is_active=True)
        initial_firm = firms.first() if firms.count() == 1 else None

        return render(request, 'certificates/create.html', {
            'base_form': base_form,
            'detail_form': detail_form,
            'cert_type': cert_type,
            'cert_type_label': CERT_TYPE_LABELS[cert_type],
            'detail_template': self.get_template(cert_type),
            'initial_firm': initial_firm,
        })

    def post(self, request, cert_type):
        base_form = BaseCertificateForm(request.POST, cert_type=cert_type)
        detail_form_cls = DETAIL_FORM_MAP.get(cert_type)
        detail_form = detail_form_cls(request.POST) if detail_form_cls else None

        base_valid = base_form.is_valid()
        detail_valid = detail_form.is_valid() if detail_form else True

        if base_valid and detail_valid:
            cert = base_form.save(commit=False)
            cert.cert_type = cert_type

            # Auto-fill entity snapshot
            entity_id = request.POST.get('entity')
            if not entity_id:
                # Entity is required — show a friendly error
                base_form.add_error('entity', 'Please select a client / entity before saving the certificate.')
                return render(request, 'certificates/create.html', {
                    'base_form': base_form,
                    'detail_form': detail_form,
                    'cert_type': cert_type,
                    'cert_type_label': CERT_TYPE_LABELS[cert_type],
                    'detail_template': self.get_template(cert_type),
                })

            try:
                entity = Entity.objects.get(pk=entity_id)
                if not cert.entity_name_on_cert:
                    cert.entity_name_on_cert = entity.name
                if not cert.entity_type_on_cert:
                    cert.entity_type_on_cert = entity.entity_type
                if not cert.pan_on_cert:
                    cert.pan_on_cert = entity.pan
                if not cert.gstin_on_cert:
                    cert.gstin_on_cert = entity.gstin
                if not cert.cin_on_cert:
                    cert.cin_on_cert = entity.cin
                if not cert.llpin_on_cert:
                    cert.llpin_on_cert = entity.llpin
                if not cert.address_on_cert:
                    cert.address_on_cert = entity.registered_address
                cert.entity = entity
            except Entity.DoesNotExist:
                base_form.add_error('entity', 'Selected entity not found. Please choose a valid client.')
                return render(request, 'certificates/create.html', {
                    'base_form': base_form,
                    'detail_form': detail_form,
                    'cert_type': cert_type,
                    'cert_type_label': CERT_TYPE_LABELS[cert_type],
                    'detail_template': self.get_template(cert_type),
                })

            # Generate certificate number
            cert.cert_number = generate_cert_number(cert.firm)
            cert.created_by = request.user
            cert.save()

            # Save detail
            if detail_form:
                detail = detail_form.save(commit=False)
                detail.certificate = cert
                detail.save()

            # Create payment record
            PaymentRecord.objects.create(certificate=cert)

            # Save version snapshot
            cert.save_snapshot(changed_by=request.user, reason='Initial creation')

            messages.success(request, f'Certificate {cert.cert_number} created successfully.')
            return redirect('certificates:detail', pk=cert.pk)

        return render(request, 'certificates/create.html', {
            'base_form': base_form,
            'detail_form': detail_form,
            'cert_type': cert_type,
            'cert_type_label': CERT_TYPE_LABELS[cert_type],
            'detail_template': self.get_template(cert_type),
        })


class CertificateDetailView(LoginRequiredMixin, View):
    def get(self, request, pk):
        cert = get_object_or_404(Certificate, pk=pk)
        detail = cert.get_cert_detail()
        payment, _ = PaymentRecord.objects.get_or_create(certificate=cert)
        versions = cert.versions.all()[:10]
        return render(request, 'certificates/detail.html', {
            'cert': cert, 'detail': detail, 'payment': payment, 'versions': versions,
        })


class CertificateEditView(LoginRequiredMixin, View):
    def get_template(self, cert_type):
        return DETAIL_TEMPLATE_MAP.get(cert_type, 'certificates/forms/custom.html')

    def get(self, request, pk):
        cert = get_object_or_404(Certificate, pk=pk)
        if cert.status == Certificate.STATUS_FINAL and not request.user.is_admin():
            messages.error(request, 'Only Administrators can edit Final certificates.')
            return redirect('certificates:detail', pk=pk)
        detail = cert.get_cert_detail()
        base_form = BaseCertificateForm(instance=cert, cert_type=cert.cert_type)
        detail_form_cls = DETAIL_FORM_MAP.get(cert.cert_type)
        detail_form = detail_form_cls(instance=detail) if (detail_form_cls and detail) else (detail_form_cls() if detail_form_cls else None)
        return render(request, 'certificates/edit.html', {
            'base_form': base_form,
            'detail_form': detail_form,
            'cert': cert,
            'cert_type_label': CERT_TYPE_LABELS.get(cert.cert_type, ''),
            'detail_template': self.get_template(cert.cert_type),
        })

    def post(self, request, pk):
        cert = get_object_or_404(Certificate, pk=pk)
        if cert.status == Certificate.STATUS_FINAL and not request.user.is_admin():
            messages.error(request, 'Only Administrators can edit Final certificates.')
            return redirect('certificates:detail', pk=pk)

        old_version = cert.version
        base_form = BaseCertificateForm(request.POST, instance=cert, cert_type=cert.cert_type)
        detail = cert.get_cert_detail()
        detail_form_cls = DETAIL_FORM_MAP.get(cert.cert_type)
        detail_form = detail_form_cls(request.POST, instance=detail) if (detail_form_cls and detail) else (detail_form_cls(request.POST) if detail_form_cls else None)

        base_valid = base_form.is_valid()
        detail_valid = detail_form.is_valid() if detail_form else True

        if base_valid and detail_valid:
            cert = base_form.save(commit=False)
            cert.version = old_version + 1
            cert.save()

            if detail_form:
                d = detail_form.save(commit=False)
                d.certificate = cert
                d.save()

            reason = request.POST.get('revision_reason', '')
            cert.save_snapshot(changed_by=request.user, reason=reason)
            messages.success(request, 'Certificate updated successfully.')
            return redirect('certificates:detail', pk=cert.pk)

        return render(request, 'certificates/edit.html', {
            'base_form': base_form,
            'detail_form': detail_form,
            'cert': cert,
            'cert_type_label': CERT_TYPE_LABELS.get(cert.cert_type, ''),
            'detail_template': self.get_template(cert.cert_type),
        })


class CertificateStatusView(LoginRequiredMixin, View):
    def post(self, request, pk):
        cert = get_object_or_404(Certificate, pk=pk)
        new_status = request.POST.get('status')
        if new_status not in dict(Certificate.STATUS_CHOICES):
            messages.error(request, 'Invalid status.')
        else:
            if new_status == Certificate.STATUS_FINAL and not request.user.is_admin():
                messages.error(request, 'Only Administrators can finalise certificates.')
            else:
                cert.status = new_status
                cert.save()
                messages.success(request, f'Certificate status updated to {cert.get_status_display()}.')
        return redirect('certificates:detail', pk=pk)


class CertificatePDFView(LoginRequiredMixin, View):
    def get(self, request, pk):
        cert = get_object_or_404(Certificate, pk=pk)
        from .pdf_generator import generate_pdf
        from accounts.middleware import AuditMiddleware
        from accounts.models import AuditLog

        try:
            pdf_bytes = generate_pdf(cert)
            AuditMiddleware.log(request.user, AuditLog.ACTION_DOWNLOAD, 'Certificate',
                                cert.pk, cert.cert_number, 'PDF Download', request)
            response = HttpResponse(pdf_bytes, content_type='application/pdf')
            filename = f"{cert.cert_number.replace('/', '_')}.pdf"
            response['Content-Disposition'] = f'inline; filename="{filename}"'
            return response
        except Exception as e:
            messages.error(request, f'PDF generation failed: {e}')
            return redirect('certificates:detail', pk=pk)


class CertificateDOCXView(LoginRequiredMixin, View):
    def get(self, request, pk):
        cert = get_object_or_404(Certificate, pk=pk)
        from .docx_generator import generate_docx
        from accounts.middleware import AuditMiddleware
        from accounts.models import AuditLog

        try:
            docx_bytes = generate_docx(cert)
            AuditMiddleware.log(request.user, AuditLog.ACTION_DOWNLOAD, 'Certificate',
                                cert.pk, cert.cert_number, 'DOCX Download', request)
            response = HttpResponse(docx_bytes,
                                    content_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document')
            filename = f"{cert.cert_number.replace('/', '_')}.docx"
            response['Content-Disposition'] = f'attachment; filename="{filename}"'
            return response
        except Exception as e:
            messages.error(request, f'DOCX generation failed: {e}')
            return redirect('certificates:detail', pk=pk)


class CertificatePreviewView(LoginRequiredMixin, View):
    def get(self, request, pk):
        cert = get_object_or_404(Certificate, pk=pk)
        detail = cert.get_cert_detail()
        payment = getattr(cert, 'payment', None)

        from .pdf_generator import get_logo_base64
        import base64
        from pathlib import Path
        from django.conf import settings

        template_map = {
            'net_worth': 'certificates/pdf/net_worth.html',
            'turnover': 'certificates/pdf/turnover.html',
            'director_list': 'certificates/pdf/director_list.html',
            'shareholder_list': 'certificates/pdf/shareholder_list.html',
            'partner_list': 'certificates/pdf/partner_list.html',
            'end_use': 'certificates/pdf/end_use.html',
            'custom': 'certificates/pdf/custom.html',
        }
        template_name = template_map.get(cert.cert_type, 'certificates/pdf/custom.html')
        return render(request, template_name, {
            'cert': cert,
            'detail': detail,
            'firm': cert.firm,
            'entity': cert.entity,
            'payment': payment,
            'logo_base64': get_logo_base64(),
            'is_draft': cert.is_draft(),
            'PDF_MODE': False,
            'PREVIEW_MODE': True,
        })


class UDINUpdateView(LoginRequiredMixin, View):
    def get(self, request, pk):
        cert = get_object_or_404(Certificate, pk=pk)
        return render(request, 'certificates/udin_form.html', {
            'form': UDINForm(instance=cert), 'cert': cert
        })

    def post(self, request, pk):
        cert = get_object_or_404(Certificate, pk=pk)
        form = UDINForm(request.POST, instance=cert)
        if form.is_valid():
            form.save()
            messages.success(request, 'UDIN updated successfully.')
            return redirect('certificates:detail', pk=pk)
        return render(request, 'certificates/udin_form.html', {'form': form, 'cert': cert})


class CertificateVersionsView(LoginRequiredMixin, View):
    def get(self, request, pk):
        cert = get_object_or_404(Certificate, pk=pk)
        versions = cert.versions.all()
        return render(request, 'certificates/versions.html', {'cert': cert, 'versions': versions})

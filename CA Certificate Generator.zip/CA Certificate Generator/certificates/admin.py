from django.contrib import admin
from .models import (Certificate, NetWorthCertificate, TurnoverCertificate,
                     DirectorListCertificate, ShareholderListCertificate,
                     PartnerListCertificate, EndUseCertificate, CustomCertificate)


@admin.register(Certificate)
class CertificateAdmin(admin.ModelAdmin):
    list_display = ['cert_number', 'cert_type', 'entity_name_on_cert', 'firm', 'status',
                    'issue_date', 'udin_status', 'created_by']
    list_filter = ['cert_type', 'status', 'firm', 'udin_status']
    search_fields = ['cert_number', 'entity_name_on_cert', 'pan_on_cert']
    readonly_fields = ['cert_number', 'created_by', 'created_at', 'updated_at']
    date_hierarchy = 'issue_date'

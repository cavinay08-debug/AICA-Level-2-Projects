import json
from django.db import models
from django.utils import timezone
from firms.models import CAFirm
from clients.models import Entity
from masters.models import Director, Shareholder, Partner


class Certificate(models.Model):
    """Base certificate model — all certificate types link to this."""

    # Certificate types
    TYPE_NET_WORTH = 'net_worth'
    TYPE_TURNOVER = 'turnover'
    TYPE_DIRECTOR_LIST = 'director_list'
    TYPE_SHAREHOLDER_LIST = 'shareholder_list'
    TYPE_PARTNER_LIST = 'partner_list'
    TYPE_END_USE = 'end_use'
    TYPE_CUSTOM = 'custom'
    TYPE_CHOICES = [
        (TYPE_NET_WORTH, 'Net Worth Certificate'),
        (TYPE_TURNOVER, 'Turnover Certificate'),
        (TYPE_DIRECTOR_LIST, 'CA Certified List of Directors'),
        (TYPE_SHAREHOLDER_LIST, 'CA Certified List of Shareholders'),
        (TYPE_PARTNER_LIST, 'CA Certified List of Partners'),
        (TYPE_END_USE, 'End-Use / Utilisation Certificate'),
        (TYPE_CUSTOM, 'General / Custom CA Certificate'),
    ]

    # Status
    STATUS_DRAFT = 'draft'
    STATUS_FINAL = 'final'
    STATUS_CANCELLED = 'cancelled'
    STATUS_REVISED = 'revised'
    STATUS_CHOICES = [
        (STATUS_DRAFT, 'Draft'),
        (STATUS_FINAL, 'Final'),
        (STATUS_CANCELLED, 'Cancelled'),
        (STATUS_REVISED, 'Revised'),
    ]

    # UDIN status
    UDIN_PENDING = 'pending'
    UDIN_GENERATED = 'generated'
    UDIN_NA = 'na'
    UDIN_STATUS_CHOICES = [
        (UDIN_PENDING, 'Pending'),
        (UDIN_GENERATED, 'Generated'),
        (UDIN_NA, 'Not Applicable'),
    ]

    # Core fields
    cert_number = models.CharField(max_length=50, unique=True, verbose_name='Certificate Number')
    cert_type = models.CharField(max_length=30, choices=TYPE_CHOICES, verbose_name='Certificate Type')
    firm = models.ForeignKey(CAFirm, on_delete=models.PROTECT, related_name='certificates')
    entity = models.ForeignKey(Entity, on_delete=models.PROTECT, related_name='certificates')

    # Status & version
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default=STATUS_DRAFT)
    version = models.PositiveIntegerField(default=1)
    revision_reason = models.TextField(blank=True)

    # Purpose & addressee
    purpose = models.TextField(blank=True, verbose_name='Purpose of Certificate')
    addressee = models.CharField(max_length=300, blank=True,
                                  default='To Whomsoever It May Concern',
                                  verbose_name='Addressed To')
    is_to_whomsoever = models.BooleanField(default=True, verbose_name='"To Whomsoever It May Concern"')

    # Date & place
    issue_date = models.DateField(default=timezone.now, verbose_name='Date of Certificate')
    place_of_issue = models.CharField(max_length=100, default='Noida', verbose_name='Place of Issue')
    financial_year = models.CharField(max_length=10, blank=True, verbose_name='Financial Year / Period')

    # Entity details at time of cert (snapshot — may differ from master)
    entity_name_on_cert = models.CharField(max_length=300, blank=True,
                                            verbose_name='Entity Name (on certificate)')
    entity_type_on_cert = models.CharField(max_length=30, blank=True)
    pan_on_cert = models.CharField(max_length=10, blank=True, verbose_name='PAN on Certificate')
    gstin_on_cert = models.CharField(max_length=15, blank=True, verbose_name='GSTIN on Certificate')
    cin_on_cert = models.CharField(max_length=21, blank=True, verbose_name='CIN on Certificate')
    llpin_on_cert = models.CharField(max_length=10, blank=True, verbose_name='LLPIN on Certificate')
    address_on_cert = models.TextField(blank=True, verbose_name='Address on Certificate')

    # Supporting docs & notes
    supporting_docs_ref = models.TextField(blank=True, verbose_name='Supporting Documents Reference')
    notes = models.TextField(blank=True, verbose_name='Internal Notes')

    # Prepared by / reviewed by
    prepared_by = models.CharField(max_length=200, blank=True)
    reviewed_by = models.CharField(max_length=200, blank=True)

    # UDIN
    udin_status = models.CharField(max_length=15, choices=UDIN_STATUS_CHOICES, default=UDIN_PENDING)
    udin_number = models.CharField(max_length=30, blank=True, verbose_name='UDIN Number')
    udin_date = models.DateField(null=True, blank=True, verbose_name='UDIN Generation Date')

    # Saved PDF/DOCX paths
    pdf_file = models.FileField(upload_to='certificates/pdf/', null=True, blank=True)
    docx_file = models.FileField(upload_to='certificates/docx/', null=True, blank=True)

    # Audit
    created_by = models.ForeignKey('accounts.User', on_delete=models.SET_NULL, null=True,
                                    related_name='certificates_created')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Certificate'
        verbose_name_plural = 'Certificates'

    def __str__(self):
        return f"{self.cert_number} | {self.get_cert_type_display()} | {self.entity_name_on_cert}"

    def is_draft(self):
        return self.status == self.STATUS_DRAFT

    def is_final(self):
        return self.status == self.STATUS_FINAL

    def get_entity_type_display_on_cert(self):
        from clients.models import Entity as E
        choices = dict(E.ENTITY_TYPE_CHOICES)
        return choices.get(self.entity_type_on_cert, self.entity_type_on_cert)

    def get_cert_detail(self):
        """Return the related specific certificate object."""
        type_map = {
            self.TYPE_NET_WORTH: 'net_worth_detail',
            self.TYPE_TURNOVER: 'turnover_detail',
            self.TYPE_DIRECTOR_LIST: 'director_list_detail',
            self.TYPE_SHAREHOLDER_LIST: 'shareholder_list_detail',
            self.TYPE_PARTNER_LIST: 'partner_list_detail',
            self.TYPE_END_USE: 'end_use_detail',
            self.TYPE_CUSTOM: 'custom_detail',
        }
        attr = type_map.get(self.cert_type)
        if attr:
            try:
                return getattr(self, attr)
            except Exception:
                pass
        return None

    def save_snapshot(self, changed_by=None, reason=''):
        """Save a version snapshot."""
        import json
        data = {
            'cert_number': self.cert_number,
            'status': self.status,
            'issue_date': str(self.issue_date),
            'entity_name': self.entity_name_on_cert,
            'purpose': self.purpose,
        }
        CertificateVersion.objects.create(
            certificate=self,
            version_number=self.version,
            snapshot_json=json.dumps(data),
            changed_by=changed_by,
            reason=reason,
        )


class CertificateVersion(models.Model):
    certificate = models.ForeignKey(Certificate, on_delete=models.CASCADE, related_name='versions')
    version_number = models.PositiveIntegerField()
    snapshot_json = models.TextField()
    changed_by = models.ForeignKey('accounts.User', on_delete=models.SET_NULL, null=True, blank=True)
    changed_at = models.DateTimeField(auto_now_add=True)
    reason = models.TextField(blank=True)

    class Meta:
        ordering = ['-version_number']


# ─── Specific certificate type models ───────────────────────────────────────

class NetWorthCertificate(models.Model):
    certificate = models.OneToOneField(Certificate, on_delete=models.CASCADE, related_name='net_worth_detail')
    valuation_date = models.DateField(verbose_name='Date of Valuation / As at Date')
    valuation_basis = models.CharField(max_length=200, blank=True,
                                        default='As per books of account',
                                        verbose_name='Basis of Valuation')
    ownership_basis = models.CharField(max_length=200, blank=True,
                                        verbose_name='Ownership / Holding Basis')
    # Assets and liabilities stored as JSON list of {description, amount}
    assets_json = models.TextField(default='[]', verbose_name='Assets (JSON)')
    liabilities_json = models.TextField(default='[]', verbose_name='Liabilities (JSON)')
    net_worth = models.DecimalField(max_digits=20, decimal_places=2, default=0, verbose_name='Net Worth (₹)')
    certification_para = models.TextField(blank=True, verbose_name='Certification Paragraph')

    def get_assets(self):
        return json.loads(self.assets_json)

    def get_liabilities(self):
        return json.loads(self.liabilities_json)

    def calc_net_worth(self):
        assets = sum(float(a.get('amount', 0)) for a in self.get_assets())
        liabs = sum(float(l.get('amount', 0)) for l in self.get_liabilities())
        return assets - liabs

    def total_assets(self):
        return sum(float(a.get('amount', 0)) for a in self.get_assets())

    def total_liabilities(self):
        return sum(float(l.get('amount', 0)) for l in self.get_liabilities())


class TurnoverCertificate(models.Model):
    certificate = models.OneToOneField(Certificate, on_delete=models.CASCADE, related_name='turnover_detail')
    # JSON list of {financial_year, turnover, gst_turnover, source_records}
    turnover_data_json = models.TextField(default='[]', verbose_name='Turnover Data (JSON)')
    source_records_reviewed = models.TextField(blank=True,
                                                verbose_name='Source Records / Documents Reviewed')
    certification_para = models.TextField(blank=True)

    def get_turnover_data(self):
        return json.loads(self.turnover_data_json)


class DirectorListCertificate(models.Model):
    certificate = models.OneToOneField(Certificate, on_delete=models.CASCADE, related_name='director_list_detail')
    directors = models.ManyToManyField(Director, blank=True)
    # Snapshot JSON of director data at time of cert (editable without changing master)
    directors_snapshot_json = models.TextField(default='[]')
    source_date = models.DateField(null=True, blank=True, verbose_name='As per records dated')
    certification_para = models.TextField(blank=True)

    def get_directors_data(self):
        return json.loads(self.directors_snapshot_json)


class ShareholderListCertificate(models.Model):
    certificate = models.OneToOneField(Certificate, on_delete=models.CASCADE, related_name='shareholder_list_detail')
    shareholders = models.ManyToManyField(Shareholder, blank=True)
    shareholders_snapshot_json = models.TextField(default='[]')
    total_share_capital = models.DecimalField(max_digits=20, decimal_places=2, default=0,
                                               verbose_name='Total Share Capital (₹)')
    total_shares = models.DecimalField(max_digits=20, decimal_places=2, default=0,
                                        verbose_name='Total Number of Shares')
    source_date = models.DateField(null=True, blank=True)
    certification_para = models.TextField(blank=True)

    def get_shareholders_data(self):
        return json.loads(self.shareholders_snapshot_json)


class PartnerListCertificate(models.Model):
    certificate = models.OneToOneField(Certificate, on_delete=models.CASCADE, related_name='partner_list_detail')
    partners = models.ManyToManyField(Partner, blank=True)
    partners_snapshot_json = models.TextField(default='[]')
    source_date = models.DateField(null=True, blank=True)
    certification_para = models.TextField(blank=True)

    def get_partners_data(self):
        return json.loads(self.partners_snapshot_json)


class EndUseCertificate(models.Model):
    certificate = models.OneToOneField(Certificate, on_delete=models.CASCADE, related_name='end_use_detail')
    amount_received = models.DecimalField(max_digits=20, decimal_places=2, default=0,
                                           verbose_name='Amount Received (₹)')
    source_of_funds = models.CharField(max_length=300, blank=True)
    sanctioned_purpose = models.TextField(blank=True, verbose_name='Sanctioned / Approved Purpose')
    period_from = models.DateField(null=True, blank=True)
    period_to = models.DateField(null=True, blank=True)
    # JSON list of {particulars, amount_utilised, remarks}
    utilisation_json = models.TextField(default='[]', verbose_name='Utilisation Details (JSON)')
    unutilised_balance = models.DecimalField(max_digits=20, decimal_places=2, default=0,
                                              verbose_name='Unutilised Balance (₹)')
    supporting_evidence = models.TextField(blank=True)
    certification_para = models.TextField(blank=True)

    def get_utilisation_data(self):
        return json.loads(self.utilisation_json)


class CustomCertificate(models.Model):
    certificate = models.OneToOneField(Certificate, on_delete=models.CASCADE, related_name='custom_detail')
    subject = models.CharField(max_length=300, verbose_name='Subject of Certificate')
    recipient = models.CharField(max_length=300, blank=True,
                                  default='To Whomsoever It May Concern')
    # JSON list of factual statement strings
    statements_json = models.TextField(default='[]', verbose_name='Factual Statements (JSON)')
    # JSON list of {title, rows: [{col1, col2, ...}]}
    schedules_json = models.TextField(default='[]', verbose_name='Schedules / Tables (JSON)')
    qualifications = models.TextField(blank=True, verbose_name='Qualifications / Disclaimers')
    certification_para = models.TextField(blank=True)

    def get_statements(self):
        return json.loads(self.statements_json)

    def get_schedules(self):
        return json.loads(self.schedules_json)

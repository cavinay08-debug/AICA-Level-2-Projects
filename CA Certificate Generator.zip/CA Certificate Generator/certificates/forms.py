import json
from django import forms
from django.utils import timezone
from .models import (Certificate, NetWorthCertificate, TurnoverCertificate,
                     DirectorListCertificate, ShareholderListCertificate,
                     PartnerListCertificate, EndUseCertificate, CustomCertificate)
from firms.models import CAFirm
from clients.models import Entity


DATE_WIDGET = forms.DateInput(attrs={'type': 'date', 'class': 'form-control'})


def _style_form(form):
    for name, field in form.fields.items():
        if isinstance(field.widget, forms.CheckboxInput):
            field.widget.attrs['class'] = 'form-check-input'
        elif isinstance(field.widget, forms.Select):
            field.widget.attrs['class'] = 'form-select'
        elif isinstance(field.widget, forms.Textarea):
            field.widget.attrs['class'] = 'form-control'
            field.widget.attrs.setdefault('rows', 3)
        elif isinstance(field.widget, forms.DateInput):
            field.widget.attrs['class'] = 'form-control'
            field.widget.attrs['type'] = 'date'
        else:
            field.widget.attrs['class'] = 'form-control'


class BaseCertificateForm(forms.ModelForm):
    """Form for the base Certificate model fields."""

    class Meta:
        model = Certificate
        fields = [
            'firm', 'cert_type',
            'entity', 'entity_name_on_cert', 'entity_type_on_cert',
            'pan_on_cert', 'gstin_on_cert', 'cin_on_cert', 'llpin_on_cert', 'address_on_cert',
            'status', 'is_to_whomsoever', 'addressee',
            'issue_date', 'place_of_issue', 'financial_year',
            'purpose', 'supporting_docs_ref', 'notes',
            'prepared_by', 'reviewed_by',
            'udin_status', 'udin_number', 'udin_date',
            'revision_reason',
        ]
        widgets = {
            'issue_date': DATE_WIDGET,
            'udin_date': DATE_WIDGET,
            'address_on_cert': forms.Textarea(attrs={'rows': 2}),
            'purpose': forms.Textarea(attrs={'rows': 2}),
            'supporting_docs_ref': forms.Textarea(attrs={'rows': 2}),
            'notes': forms.Textarea(attrs={'rows': 2}),
            'revision_reason': forms.Textarea(attrs={'rows': 2}),
        }

    def __init__(self, *args, cert_type=None, **kwargs):
        super().__init__(*args, **kwargs)
        _style_form(self)
        if cert_type:
            self.fields['cert_type'].initial = cert_type
            self.fields['cert_type'].widget = forms.HiddenInput()
        self.fields['entity'].widget.attrs.update({'class': 'form-select entity-select'})
        self.fields['firm'].queryset = CAFirm.objects.filter(is_active=True)
        self.fields['entity'].required = False


# ─── NET WORTH FORM ─────────────────────────────────────────────────────────

class NetWorthForm(forms.ModelForm):
    assets_json_input = forms.CharField(
        widget=forms.HiddenInput(), required=False,
        label='Assets Data (JSON)'
    )
    liabilities_json_input = forms.CharField(
        widget=forms.HiddenInput(), required=False,
        label='Liabilities Data (JSON)'
    )

    class Meta:
        model = NetWorthCertificate
        fields = ['valuation_date', 'valuation_basis', 'ownership_basis',
                  'net_worth', 'certification_para']
        widgets = {
            'valuation_date': DATE_WIDGET,
            'certification_para': forms.Textarea(attrs={'rows': 4}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _style_form(self)

    def save(self, commit=True):
        obj = super().save(commit=False)
        assets_raw = self.data.get('assets_json_input', '[]')
        liabs_raw = self.data.get('liabilities_json_input', '[]')
        try:
            obj.assets_json = json.dumps(json.loads(assets_raw))
        except Exception:
            obj.assets_json = '[]'
        try:
            obj.liabilities_json = json.dumps(json.loads(liabs_raw))
        except Exception:
            obj.liabilities_json = '[]'
        if commit:
            obj.save()
        return obj


# ─── TURNOVER FORM ───────────────────────────────────────────────────────────

class TurnoverForm(forms.ModelForm):
    turnover_json_input = forms.CharField(widget=forms.HiddenInput(), required=False)

    class Meta:
        model = TurnoverCertificate
        fields = ['source_records_reviewed', 'certification_para']
        widgets = {
            'source_records_reviewed': forms.Textarea(attrs={'rows': 3}),
            'certification_para': forms.Textarea(attrs={'rows': 4}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _style_form(self)

    def save(self, commit=True):
        obj = super().save(commit=False)
        raw = self.data.get('turnover_json_input', '[]')
        try:
            obj.turnover_data_json = json.dumps(json.loads(raw))
        except Exception:
            obj.turnover_data_json = '[]'
        if commit:
            obj.save()
        return obj


# ─── DIRECTOR LIST FORM ──────────────────────────────────────────────────────

class DirectorListForm(forms.ModelForm):
    directors_json_input = forms.CharField(widget=forms.HiddenInput(), required=False)

    class Meta:
        model = DirectorListCertificate
        fields = ['source_date', 'certification_para']
        widgets = {
            'source_date': DATE_WIDGET,
            'certification_para': forms.Textarea(attrs={'rows': 4}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _style_form(self)

    def save(self, commit=True):
        obj = super().save(commit=False)
        raw = self.data.get('directors_json_input', '[]')
        try:
            obj.directors_snapshot_json = json.dumps(json.loads(raw))
        except Exception:
            obj.directors_snapshot_json = '[]'
        if commit:
            obj.save()
        return obj


# ─── SHAREHOLDER LIST FORM ───────────────────────────────────────────────────

class ShareholderListForm(forms.ModelForm):
    shareholders_json_input = forms.CharField(widget=forms.HiddenInput(), required=False)

    class Meta:
        model = ShareholderListCertificate
        fields = ['source_date', 'total_share_capital', 'total_shares', 'certification_para']
        widgets = {
            'source_date': DATE_WIDGET,
            'certification_para': forms.Textarea(attrs={'rows': 4}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _style_form(self)

    def save(self, commit=True):
        obj = super().save(commit=False)
        raw = self.data.get('shareholders_json_input', '[]')
        try:
            obj.shareholders_snapshot_json = json.dumps(json.loads(raw))
        except Exception:
            obj.shareholders_snapshot_json = '[]'
        if commit:
            obj.save()
        return obj


# ─── PARTNER LIST FORM ───────────────────────────────────────────────────────

class PartnerListForm(forms.ModelForm):
    partners_json_input = forms.CharField(widget=forms.HiddenInput(), required=False)

    class Meta:
        model = PartnerListCertificate
        fields = ['source_date', 'certification_para']
        widgets = {
            'source_date': DATE_WIDGET,
            'certification_para': forms.Textarea(attrs={'rows': 4}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _style_form(self)

    def save(self, commit=True):
        obj = super().save(commit=False)
        raw = self.data.get('partners_json_input', '[]')
        try:
            obj.partners_snapshot_json = json.dumps(json.loads(raw))
        except Exception:
            obj.partners_snapshot_json = '[]'
        if commit:
            obj.save()
        return obj


# ─── END USE FORM ────────────────────────────────────────────────────────────

class EndUseForm(forms.ModelForm):
    utilisation_json_input = forms.CharField(widget=forms.HiddenInput(), required=False)

    class Meta:
        model = EndUseCertificate
        fields = ['amount_received', 'source_of_funds', 'sanctioned_purpose',
                  'period_from', 'period_to', 'unutilised_balance',
                  'supporting_evidence', 'certification_para']
        widgets = {
            'period_from': DATE_WIDGET,
            'period_to': DATE_WIDGET,
            'sanctioned_purpose': forms.Textarea(attrs={'rows': 2}),
            'supporting_evidence': forms.Textarea(attrs={'rows': 2}),
            'certification_para': forms.Textarea(attrs={'rows': 4}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _style_form(self)

    def save(self, commit=True):
        obj = super().save(commit=False)
        raw = self.data.get('utilisation_json_input', '[]')
        try:
            obj.utilisation_json = json.dumps(json.loads(raw))
        except Exception:
            obj.utilisation_json = '[]'
        if commit:
            obj.save()
        return obj


# ─── CUSTOM FORM ─────────────────────────────────────────────────────────────

class CustomCertForm(forms.ModelForm):
    statements_json_input = forms.CharField(widget=forms.HiddenInput(), required=False)
    schedules_json_input = forms.CharField(widget=forms.HiddenInput(), required=False)

    class Meta:
        model = CustomCertificate
        fields = ['subject', 'recipient', 'qualifications', 'certification_para']
        widgets = {
            'qualifications': forms.Textarea(attrs={'rows': 3}),
            'certification_para': forms.Textarea(attrs={'rows': 4}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _style_form(self)

    def save(self, commit=True):
        obj = super().save(commit=False)
        for field, attr in [('statements_json_input', 'statements_json'),
                             ('schedules_json_input', 'schedules_json')]:
            raw = self.data.get(field, '[]')
            try:
                setattr(obj, attr, json.dumps(json.loads(raw)))
            except Exception:
                setattr(obj, attr, '[]')
        if commit:
            obj.save()
        return obj


# ─── UDIN FORM ───────────────────────────────────────────────────────────────

class UDINForm(forms.ModelForm):
    class Meta:
        model = Certificate
        fields = ['udin_status', 'udin_number', 'udin_date']
        widgets = {'udin_date': DATE_WIDGET}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _style_form(self)


DETAIL_FORM_MAP = {
    'net_worth': NetWorthForm,
    'turnover': TurnoverForm,
    'director_list': DirectorListForm,
    'shareholder_list': ShareholderListForm,
    'partner_list': PartnerListForm,
    'end_use': EndUseForm,
    'custom': CustomCertForm,
}

"""
PDF Certificate Generator using xhtml2pdf (works natively on Windows).
Renders the HTML certificate templates to PDF.
"""
import io
import base64
from pathlib import Path
from django.template.loader import render_to_string
from django.conf import settings


TEMPLATE_MAP = {
    'net_worth': 'certificates/pdf/net_worth.html',
    'turnover': 'certificates/pdf/turnover.html',
    'director_list': 'certificates/pdf/director_list.html',
    'shareholder_list': 'certificates/pdf/shareholder_list.html',
    'partner_list': 'certificates/pdf/partner_list.html',
    'end_use': 'certificates/pdf/end_use.html',
    'custom': 'certificates/pdf/custom.html',
}


def get_logo_base64():
    """Return the ICAI logo as a base64 data URI so xhtml2pdf can embed it."""
    logo_path = Path(settings.BASE_DIR) / 'static' / 'images' / 'icai_logo.jpg'
    if logo_path.exists():
        with open(logo_path, 'rb') as f:
            data = base64.b64encode(f.read()).decode('utf-8')
        return f'data:image/jpeg;base64,{data}'
    return ''


def get_pdf_css():
    """Return CSS for the PDF — professional CA certificate layout."""
    return """
    @page {
        size: a4;
        margin: 1.5cm;
        margin-bottom: 2.2cm;
        @frame footer_frame {
            -pdf-frame-content: footer_content;
            left: 1.5cm;
            right: 1.5cm;
            bottom: 0.5cm;
            height: 1.2cm;
        }
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
        font-family: Arial, sans-serif;
        font-size: 10pt;
        color: #1a1a1a;
        line-height: 1.5;
    }

    /* ─── DRAFT WATERMARK ─── */
    .draft-watermark {
        position: fixed;
        top: 40%;
        left: 10%;
        font-size: 90pt;
        color: rgba(220,0,0,0.10);
        font-weight: bold;
        transform: rotate(-35deg);
        z-index: -1;
        letter-spacing: 10pt;
        font-family: Arial, sans-serif;
    }
    .draft-notice {
        background: #fef2f2;
        border: 1.5pt solid #dc2626;
        color: #dc2626;
        padding: 6pt 12pt;
        text-align: center;
        font-weight: bold;
        font-size: 10pt;
        margin-bottom: 10pt;
        border-radius: 4pt;
    }

    /* ─── LETTERHEAD ─── */
    .letterhead {
        text-align: center;
        border-bottom: 2pt solid #1a3a6e;
        padding-bottom: 6pt;
        margin-bottom: 10pt;
    }
    .letterhead-logo {
        text-align: center;
        margin-bottom: 4pt;
    }
    .letterhead-logo img {
        width: 42pt;
        height: auto;
    }
    .letterhead-text {
        text-align: center;
    }
    .firm-name {
        font-size: 13.5pt;
        font-weight: bold;
        color: #1a3a6e;
        text-transform: uppercase;
        letter-spacing: 0.5pt;
        line-height: 1.2;
    }
    .firm-type {
        font-size: 8.5pt;
        color: #444;
        font-style: italic;
        margin-top: 1pt;
    }
    .firm-frn {
        font-size: 8pt;
        color: #333;
        margin-top: 1pt;
        font-weight: bold;
    }
    .firm-address {
        font-size: 7.5pt;
        color: #555;
        margin-top: 1pt;
        line-height: 1.3;
    }

    /* ─── CERT HEADER ─── */
    .cert-header {
        text-align: center;
        margin: 10pt 0 6pt;
    }
    .cert-title {
        font-size: 13pt;
        font-weight: bold;
        color: #1a3a6e;
        text-decoration: underline;
        text-transform: uppercase;
        letter-spacing: 0.3pt;
        string-set: cert-title content();
    }
    .cert-number-display {
        font-size: 9.5pt;
        color: #333;
        margin-top: 3pt;
        string-set: cert-number content();
    }

    /* ─── META BOX ─── */
    .cert-meta {
        background: #f8fafd;
        border: 1pt solid #c8d4e8;
        border-radius: 4pt;
        padding: 8pt 10pt;
        margin: 8pt 0;
    }
    .cert-meta table {
        width: 100%;
        border-collapse: collapse;
    }
    .cert-meta td {
        padding: 2pt 6pt;
        font-size: 9pt;
        vertical-align: top;
        border: none;
    }
    .cert-meta td:first-child {
        color: #1a3a6e;
        font-weight: bold;
        width: 38%;
        white-space: nowrap;
    }

    /* ─── PURPOSE BOX ─── */
    .purpose-box {
        background: #fffbea;
        border-left: 3pt solid #d4a017;
        padding: 6pt 10pt;
        margin: 6pt 0 8pt;
        font-size: 9pt;
        color: #333;
    }
    .purpose-box strong {
        color: #1a3a6e;
    }

    /* ─── ADDRESSEE ─── */
    .addressee-block {
        margin: 8pt 0 4pt;
    }
    .addressee-line {
        font-weight: bold;
        font-size: 10.5pt;
        text-decoration: underline;
        color: #1a1a1a;
    }

    /* ─── CERT BODY ─── */
    .cert-body {
        margin-top: 8pt;
    }
    .cert-para {
        text-align: justify;
        margin-bottom: 8pt;
        line-height: 1.6;
    }
    .cert-para.indent {
        margin-left: 20pt;
    }
    .mt-8 { margin-top: 8pt; }

    /* ─── SECTION TITLES ─── */
    .section-title {
        font-size: 10.5pt;
        font-weight: bold;
        color: #1a3a6e;
        background: #eef2fb;
        padding: 4pt 8pt;
        margin: 10pt 0 4pt;
        border-left: 3pt solid #1a3a6e;
    }

    /* ─── TABLES ─── */
    .cert-table {
        width: 100%;
        border-collapse: collapse;
        margin: 4pt 0 10pt;
        font-size: 9pt;
    }
    .cert-table th {
        background: #1a3a6e;
        color: white;
        padding: 5pt 7pt;
        text-align: left;
        font-size: 8.5pt;
        font-weight: bold;
    }
    .cert-table td {
        padding: 4pt 7pt;
        border: 0.5pt solid #c8d4e8;
        vertical-align: top;
    }
    .cert-table tr:nth-child(even) td {
        background: #f8fafd;
    }
    .cert-table .total-row td {
        background: #eef2fb;
        font-weight: bold;
        border-top: 1.5pt solid #1a3a6e;
    }
    .text-right { text-align: right; }
    .text-center { text-align: center; }

    /* ─── SIGNATURE BLOCK ─── */
    .signature-section {
        margin-top: 16pt;
        page-break-inside: avoid;
    }
    .signature-block {
        margin-top: 12pt;
    }
    .sig-firm-name {
        font-size: 11pt;
        font-weight: bold;
        color: #1a3a6e;
    }
    .sig-frn {
        font-size: 8.5pt;
        color: #555;
    }
    .signature-line {
        border-top: 1pt solid #1a1a1a;
        width: 140pt;
        margin: 36pt 0 4pt;
    }
    .sig-ca-name {
        font-size: 10.5pt;
        font-weight: bold;
        color: #1a1a1a;
    }
    .sig-membership {
        font-size: 9pt;
        color: #333;
    }
    .sig-place-date {
        font-size: 9pt;
        color: #555;
        margin-top: 4pt;
    }

    /* ─── UDIN BLOCK ─── */
    .udin-block {
        margin-top: 10pt;
        font-size: 8.5pt;
        color: #333;
        border-top: 0.5pt solid #ddd;
        padding-top: 6pt;
    }
    .udin-label { font-weight: bold; color: #1a3a6e; }

    /* ─── FOOTER ─── */
    .cert-footer {
        margin-top: 10pt;
        padding-top: 6pt;
        border-top: 0.5pt solid #ccc;
        font-size: 7.5pt;
        color: #777;
        text-align: center;
    }
    """


def generate_pdf(certificate):
    """Generate a PDF for the given Certificate using xhtml2pdf."""
    from xhtml2pdf import pisa

    template_name = TEMPLATE_MAP.get(certificate.cert_type, 'certificates/pdf/net_worth.html')
    detail = certificate.get_cert_detail()
    firm = certificate.firm
    logo_b64 = get_logo_base64()

    context = {
        'cert': certificate,
        'detail': detail,
        'firm': firm,
        'logo_base64': logo_b64,
        'is_draft': certificate.is_draft(),
    }

    html_content = render_to_string(template_name, context)

    # Prepend CSS into the HTML
    css = get_pdf_css()
    full_html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>
{css}
</style>
</head>
<body>
{html_content}
</body>
</html>"""

    buf = io.BytesIO()
    pisa_status = pisa.CreatePDF(full_html, dest=buf, encoding='utf-8')

    if pisa_status.err:
        raise RuntimeError(f"PDF generation failed: {pisa_status.err}")

    buf.seek(0)
    return buf.read()


def save_pdf_to_cert(certificate):
    """Generate PDF and save it to the Certificate record."""
    from django.core.files.base import ContentFile
    import datetime

    pdf_bytes = generate_pdf(certificate)
    filename = f"{certificate.cert_number.replace('/', '_')}_{datetime.date.today()}.pdf"
    certificate.pdf_file.save(filename, ContentFile(pdf_bytes), save=True)
    return certificate.pdf_file.url

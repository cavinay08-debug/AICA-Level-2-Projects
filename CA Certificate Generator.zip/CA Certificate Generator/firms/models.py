from django.db import models


class CAFirm(models.Model):
    FIRM_TYPE_PROPRIETORSHIP = 'proprietorship'
    FIRM_TYPE_PARTNERSHIP = 'partnership'
    FIRM_TYPE_LLP = 'llp'
    FIRM_TYPE_CHOICES = [
        (FIRM_TYPE_PROPRIETORSHIP, 'Sole Proprietorship'),
        (FIRM_TYPE_PARTNERSHIP, 'Partnership'),
        (FIRM_TYPE_LLP, 'LLP'),
    ]

    name = models.CharField(max_length=200)
    short_code = models.CharField(max_length=10, unique=True, help_text='Used in certificate number prefix e.g. AKG, YV, AKYV')
    firm_type = models.CharField(max_length=20, choices=FIRM_TYPE_CHOICES, default=FIRM_TYPE_PROPRIETORSHIP)
    frn_number = models.CharField(max_length=20, verbose_name='FRN Number')
    address = models.TextField()
    city = models.CharField(max_length=100, default='Noida')
    state = models.CharField(max_length=100, default='Uttar Pradesh')
    pin_code = models.CharField(max_length=10, blank=True)
    phone = models.CharField(max_length=20, blank=True)
    email = models.EmailField(blank=True)
    website = models.URLField(blank=True)
    signing_ca_name = models.CharField(max_length=200, verbose_name='Signing CA Name')
    membership_number = models.CharField(max_length=20, verbose_name='Membership Number (M. No.)')
    logo = models.ImageField(upload_to='firm_logos/', blank=True, null=True)
    icai_logo = models.ImageField(upload_to='firm_logos/', blank=True, null=True,
                                   help_text='ICAI CA India logo for letterhead')
    header_disclaimer = models.TextField(blank=True, help_text='Default disclaimer text for certificate headers')
    footer_text = models.TextField(blank=True, help_text='Footer text for certificates')
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['name']
        verbose_name = 'CA Firm'
        verbose_name_plural = 'CA Firms'

    def __str__(self):
        return self.name

    def get_letterhead_name(self):
        return self.name.upper()


class CertificateNumberConfig(models.Model):
    RESET_YEARLY = 'yearly'
    RESET_NEVER = 'never'
    RESET_CHOICES = [
        (RESET_YEARLY, 'Reset every financial year'),
        (RESET_NEVER, 'Never reset'),
    ]

    firm = models.OneToOneField(CAFirm, on_delete=models.CASCADE, related_name='number_config')
    prefix = models.CharField(max_length=20, help_text='e.g. AKG, YV, AKYV')
    current_fy = models.CharField(max_length=10, help_text='e.g. 2025-26')
    current_sequence = models.PositiveIntegerField(default=0)
    reset_frequency = models.CharField(max_length=10, choices=RESET_CHOICES, default=RESET_YEARLY)
    digits = models.PositiveSmallIntegerField(default=3, help_text='Number of digits in sequence e.g. 3 → 001')

    class Meta:
        verbose_name = 'Certificate Number Config'

    def __str__(self):
        return f"{self.firm.short_code} — {self.current_fy} — {self.current_sequence}"

    def get_next_number(self):
        from django.conf import settings
        import datetime

        today = datetime.date.today()
        if today.month >= 4:
            fy = f"{today.year}-{str(today.year+1)[2:]}"
        else:
            fy = f"{today.year-1}-{str(today.year)[2:]}"

        if self.reset_frequency == self.RESET_YEARLY and self.current_fy != fy:
            self.current_fy = fy
            self.current_sequence = 0

        self.current_sequence += 1
        self.save()
        seq_str = str(self.current_sequence).zfill(self.digits)
        return f"{self.prefix}/{self.current_fy}/{seq_str}"

from django.urls import path
from . import views

app_name = 'firms'

urlpatterns = [
    path('', views.FirmListView.as_view(), name='list'),
    path('<int:pk>/', views.FirmDetailView.as_view(), name='detail'),
    path('create/', views.FirmCreateView.as_view(), name='create'),
    path('<int:pk>/edit/', views.FirmUpdateView.as_view(), name='edit'),
]

"""
Management command to seed the database with the three CA firms.
Run: python manage.py seed_firms
"""
import shutil
import os
from pathlib import Path
from django.core.management.base import BaseCommand
from django.conf import settings
from firms.models import CAFirm, CertificateNumberConfig
import datetime


class Command(BaseCommand):
    help = 'Seed the database with the three CA firms and their configurations'

    FIRMS = [
        {
            'name': 'Arvinder Kumar Gupta & Co',
            'short_code': 'AKG',
            'firm_type': 'proprietorship',
            'frn_number': '006878N',
            'address': 'Z-331A Sector-12 Noida, G.B. Nagar, Uttar Pradesh - 201301',
            'city': 'Noida',
            'state': 'Uttar Pradesh',
            'pin_code': '201301',
            'signing_ca_name': 'Arvinder Kumar Gupta',
            'membership_number': '085117',
            'header_disclaimer': (
                'This certificate is issued based on information and documents produced before us '
                'and as per the representations made by the management. We have relied upon the '
                'accuracy and completeness of the information provided to us.'
            ),
            'footer_text': (
                'Note: This certificate is issued at the request of the management and should '
                'not be construed as an audit opinion. It is issued for the specific purpose '
                'mentioned herein and must not be used for any other purpose.'
            ),
        },
        {
            'name': 'Yash Vijay & Co',
            'short_code': 'YV',
            'firm_type': 'proprietorship',
            'frn_number': '034378C',
            'address': 'TS-1512, 14th Floor, Plot No. C-03, Galaxy Blue Sapphire Plaza, '
                       'Sector-4, Greater Noida, Gautam Buddha Nagar, Uttar Pradesh - 201318',
            'city': 'Greater Noida',
            'state': 'Uttar Pradesh',
            'pin_code': '201318',
            'signing_ca_name': 'Yash Vijay',
            'membership_number': '450155',
            'header_disclaimer': (
                'This certificate is issued based on information and documents produced before us '
                'and as per the representations made by the management.'
            ),
            'footer_text': (
                'This certificate is issued for the specific purpose mentioned herein and '
                'must not be used for any other purpose.'
            ),
        },
        {
            'name': 'A K Y V and Co LLP',
            'short_code': 'AKYV',
            'firm_type': 'llp',
            'frn_number': 'FNA269039',
            'address': 'TS-1512, 14th Floor, Plot No. C-03, Galaxy Blue Sapphire Plaza, '
                       'Sector-4, Greater Noida, Gautam Buddha Nagar, Uttar Pradesh - 201318',
            'city': 'Greater Noida',
            'state': 'Uttar Pradesh',
            'pin_code': '201318',
            'signing_ca_name': 'Arvinder Kumar Gupta',
            'membership_number': '085117',
            'header_disclaimer': (
                'This certificate is issued based on information and documents produced before us '
                'and as per the representations made by the management of the entity.'
            ),
            'footer_text': (
                'This certificate is issued for the specific purpose mentioned herein and '
                'must not be used for any other purpose.'
            ),
        },
    ]

    def handle(self, *args, **options):
        self.stdout.write(self.style.MIGRATE_HEADING('Seeding CA firms...'))

        today = datetime.date.today()
        if today.month >= 4:
            current_fy = f"{today.year}-{str(today.year + 1)[2:]}"
        else:
            current_fy = f"{today.year - 1}-{str(today.year)[2:]}"

        # Copy ICAI logo to media/firm_logos
        logo_src = Path(settings.BASE_DIR) / 'static' / 'images' / 'icai_logo.jpg'
        logo_dest_dir = Path(settings.MEDIA_ROOT) / 'firm_logos'
        logo_dest_dir.mkdir(parents=True, exist_ok=True)
        logo_dest = logo_dest_dir / 'icai_logo.jpg'
        if logo_src.exists() and not logo_dest.exists():
            shutil.copy2(logo_src, logo_dest)
            self.stdout.write('  Copied ICAI logo to media/firm_logos/')

        for firm_data in self.FIRMS:
            firm, created = CAFirm.objects.update_or_create(
                short_code=firm_data['short_code'],
                defaults=firm_data,
            )

            # Set ICAI logo on all firms
            if logo_dest.exists():
                firm.icai_logo = 'firm_logos/icai_logo.jpg'
                firm.save()

            # Create certificate number config
            CertificateNumberConfig.objects.get_or_create(
                firm=firm,
                defaults={
                    'prefix': firm.short_code,
                    'current_fy': current_fy,
                    'current_sequence': 0,
                    'reset_frequency': 'yearly',
                    'digits': 3,
                }
            )

            action = 'Created' if created else 'Updated'
            self.stdout.write(
                self.style.SUCCESS(f'  [OK] {action}: {firm.name} (FRN: {firm.frn_number})')
            )

        self.stdout.write(self.style.SUCCESS('\n[OK] All 3 CA firms seeded successfully!'))
        self.stdout.write(f'  Current FY: {current_fy}')
        self.stdout.write('')
        self.stdout.write('Next step: Create admin user with:')
        self.stdout.write('  python manage.py create_admin')

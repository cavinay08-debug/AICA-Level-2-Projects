"""
Management command to create the initial admin user.
Run: python manage.py create_admin
"""
from django.core.management.base import BaseCommand
from accounts.models import User


class Command(BaseCommand):
    help = 'Create the initial administrator user'

    def handle(self, *args, **options):
        if User.objects.filter(username='admin').exists():
            self.stdout.write(self.style.WARNING('Admin user already exists.'))
            return

        user = User.objects.create_superuser(
            username='admin',
            email='admin@cacertificates.local',
            password='Admin@123',
            first_name='Administrator',
            last_name='',
            role='admin',
        )
        self.stdout.write(self.style.SUCCESS('[OK] Admin user created!'))
        self.stdout.write('  Username: admin')
        self.stdout.write('  Password: Admin@123')
        self.stdout.write(self.style.WARNING('  [!] Please change the password immediately after first login.'))

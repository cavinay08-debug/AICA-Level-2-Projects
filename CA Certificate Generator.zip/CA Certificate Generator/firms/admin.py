from django.contrib import admin
from .models import CAFirm, CertificateNumberConfig


class CertNumberInline(admin.StackedInline):
    model = CertificateNumberConfig
    extra = 1


@admin.register(CAFirm)
class CAFirmAdmin(admin.ModelAdmin):
    list_display = ['name', 'short_code', 'frn_number', 'signing_ca_name', 'membership_number', 'is_active']
    inlines = [CertNumberInline]

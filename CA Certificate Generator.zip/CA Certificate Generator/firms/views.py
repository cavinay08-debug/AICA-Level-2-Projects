from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib import messages
from django.views import View
from .models import CAFirm, CertificateNumberConfig
from .forms import FirmForm


class FirmListView(LoginRequiredMixin, View):
    def get(self, request):
        firms = CAFirm.objects.all()
        return render(request, 'firms/list.html', {'firms': firms})


class FirmDetailView(LoginRequiredMixin, View):
    def get(self, request, pk):
        firm = get_object_or_404(CAFirm, pk=pk)
        return render(request, 'firms/detail.html', {'firm': firm})


class FirmCreateView(LoginRequiredMixin, View):
    def get(self, request):
        if not request.user.is_admin():
            return redirect('dashboard:home')
        return render(request, 'firms/form.html', {'form': FirmForm(), 'title': 'Add CA Firm'})

    def post(self, request):
        if not request.user.is_admin():
            return redirect('dashboard:home')
        form = FirmForm(request.POST, request.FILES)
        if form.is_valid():
            firm = form.save()
            messages.success(request, f'Firm "{firm.name}" created successfully.')
            return redirect('firms:list')
        return render(request, 'firms/form.html', {'form': form, 'title': 'Add CA Firm'})


class FirmUpdateView(LoginRequiredMixin, View):
    def get(self, request, pk):
        if not request.user.is_admin():
            return redirect('dashboard:home')
        firm = get_object_or_404(CAFirm, pk=pk)
        return render(request, 'firms/form.html', {'form': FirmForm(instance=firm), 'title': 'Edit Firm', 'obj': firm})

    def post(self, request, pk):
        if not request.user.is_admin():
            return redirect('dashboard:home')
        firm = get_object_or_404(CAFirm, pk=pk)
        form = FirmForm(request.POST, request.FILES, instance=firm)
        if form.is_valid():
            form.save()
            messages.success(request, 'Firm updated successfully.')
            return redirect('firms:list')
        return render(request, 'firms/form.html', {'form': form, 'title': 'Edit Firm', 'obj': firm})

from django.shortcuts import render, redirect
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views import View
from django.utils import timezone
from django.db.models import Count, Sum, Q
import json
import datetime


class DashboardView(LoginRequiredMixin, View):
    login_url = '/accounts/login/'

    def get(self, request):
        from certificates.models import Certificate
        from firms.models import CAFirm
        from clients.models import Entity
        from payments.models import PaymentRecord

        today = timezone.now().date()
        month_start = today.replace(day=1)

        # This month's certificates
        this_month = Certificate.objects.filter(created_at__date__gte=month_start)
        total_this_month = this_month.count()

        # All certs
        all_certs = Certificate.objects.all()
        pending_drafts = all_certs.filter(status='draft').count()
        udin_pending = all_certs.filter(udin_status='pending').count()
        payment_pending = PaymentRecord.objects.filter(
            payment_status__in=['no', 'partial']
        ).count()

        # Certificates by firm for chart
        firms = CAFirm.objects.filter(is_active=True)
        firm_data = []
        for firm in firms:
            firm_data.append({
                'name': firm.short_code,
                'count': all_certs.filter(firm=firm).count()
            })

        # Certificates by type for chart
        type_data = []
        for cert_type, label in Certificate.TYPE_CHOICES:
            count = all_certs.filter(cert_type=cert_type).count()
            if count:
                type_data.append({'type': label, 'count': count})

        # Recent certificates
        recent_certs = all_certs.select_related('firm', 'entity').order_by('-created_at')[:10]

        # Monthly trend (last 6 months)
        monthly_labels = []
        monthly_counts = []
        for i in range(5, -1, -1):
            month_date = today - datetime.timedelta(days=i*30)
            month_s = month_date.replace(day=1)
            if month_date.month == 12:
                month_e = month_date.replace(day=31)
            else:
                month_e = (month_s.replace(month=month_s.month+1) - datetime.timedelta(days=1))
            count = all_certs.filter(created_at__date__gte=month_s, created_at__date__lte=month_e).count()
            monthly_labels.append(month_s.strftime('%b %Y'))
            monthly_counts.append(count)

        # Total entities
        total_entities = Entity.objects.count()
        total_firms = firms.count()

        # Payment summary
        total_received = PaymentRecord.objects.filter(payment_status='yes').aggregate(
            total=Sum('amount_received'))['total'] or 0
        total_outstanding = PaymentRecord.objects.aggregate(
            total=Sum('outstanding_amount'))['total'] or 0

        return render(request, 'dashboard/home.html', {
            'total_this_month': total_this_month,
            'pending_drafts': pending_drafts,
            'udin_pending': udin_pending,
            'payment_pending': payment_pending,
            'recent_certs': recent_certs,
            'total_entities': total_entities,
            'total_firms': total_firms,
            'total_received': total_received,
            'total_outstanding': total_outstanding,
            'firm_data_json': json.dumps(firm_data),
            'type_data_json': json.dumps(type_data),
            'monthly_labels_json': json.dumps(monthly_labels),
            'monthly_counts_json': json.dumps(monthly_counts),
            'cert_types': Certificate.TYPE_CHOICES,
        })

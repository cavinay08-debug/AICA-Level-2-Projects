from django.db import models


class Entity(models.Model):
    ENTITY_INDIVIDUAL = 'individual'
    ENTITY_PROPRIETORSHIP = 'proprietorship'
    ENTITY_PARTNERSHIP = 'partnership'
    ENTITY_LLP = 'llp'
    ENTITY_PRIVATE = 'private_limited'
    ENTITY_PUBLIC = 'public_limited'
    ENTITY_TRUST = 'trust'
    ENTITY_SOCIETY = 'society'
    ENTITY_OTHER = 'other'

    ENTITY_TYPE_CHOICES = [
        (ENTITY_INDIVIDUAL, 'Individual'),
        (ENTITY_PROPRIETORSHIP, 'Proprietorship'),
        (ENTITY_PARTNERSHIP, 'Partnership Firm'),
        (ENTITY_LLP, 'LLP'),
        (ENTITY_PRIVATE, 'Private Limited Company'),
        (ENTITY_PUBLIC, 'Public Limited Company'),
        (ENTITY_TRUST, 'Trust'),
        (ENTITY_SOCIETY, 'Society'),
        (ENTITY_OTHER, 'Other'),
    ]

    name = models.CharField(max_length=300, verbose_name='Entity / Client Name')
    entity_type = models.CharField(max_length=30, choices=ENTITY_TYPE_CHOICES)
    pan = models.CharField(max_length=10, blank=True, verbose_name='PAN')
    gstin = models.CharField(max_length=15, blank=True, verbose_name='GSTIN')
    cin = models.CharField(max_length=21, blank=True, verbose_name='CIN')
    llpin = models.CharField(max_length=10, blank=True, verbose_name='LLPIN')
    registration_number = models.CharField(max_length=50, blank=True)
    registered_address = models.TextField(blank=True)
    correspondence_address = models.TextField(blank=True)
    contact_person = models.CharField(max_length=200, blank=True)
    email = models.EmailField(blank=True)
    phone = models.CharField(max_length=20, blank=True)
    notes = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['name']
        verbose_name = 'Client / Entity'
        verbose_name_plural = 'Clients / Entities'

    def __str__(self):
        return f"{self.name} ({self.get_entity_type_display()})"

    def get_applicable_ids(self):
        """Return a dict of non-empty IDs for display."""
        ids = {}
        if self.pan:
            ids['PAN'] = self.pan
        if self.gstin:
            ids['GSTIN'] = self.gstin
        if self.cin:
            ids['CIN'] = self.cin
        if self.llpin:
            ids['LLPIN'] = self.llpin
        if self.registration_number:
            ids['Reg. No.'] = self.registration_number
        return ids

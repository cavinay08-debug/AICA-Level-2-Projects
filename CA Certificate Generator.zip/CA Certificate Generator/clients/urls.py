from django.urls import path
from . import views

app_name = 'clients'

urlpatterns = [
    path('', views.EntityListView.as_view(), name='list'),
    path('create/', views.EntityCreateView.as_view(), name='create'),
    path('<int:pk>/', views.EntityDetailView.as_view(), name='detail'),
    path('<int:pk>/edit/', views.EntityUpdateView.as_view(), name='edit'),
    path('api/search/', views.entity_search_api, name='search_api'),
    path('api/<int:pk>/data/', views.entity_data_api, name='data_api'),
]

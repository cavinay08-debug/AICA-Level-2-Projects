from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib import messages
from django.views import View
from django.http import JsonResponse
from django.db.models import Q
from .models import Entity
from .forms import EntityForm


class EntityListView(LoginRequiredMixin, View):
    def get(self, request):
        q = request.GET.get('q', '')
        entities = Entity.objects.all()
        if q:
            entities = entities.filter(Q(name__icontains=q) | Q(pan__icontains=q) | Q(gstin__icontains=q))
        return render(request, 'clients/list.html', {'entities': entities, 'q': q})


class EntityCreateView(LoginRequiredMixin, View):
    def get(self, request):
        return render(request, 'clients/form.html', {'form': EntityForm(), 'title': 'Add Client / Entity'})

    def post(self, request):
        form = EntityForm(request.POST)
        if form.is_valid():
            entity = form.save()
            messages.success(request, f'Entity "{entity.name}" added successfully.')
            if request.GET.get('next'):
                return redirect(request.GET['next'])
            return redirect('clients:detail', pk=entity.pk)
        return render(request, 'clients/form.html', {'form': form, 'title': 'Add Client / Entity'})


class EntityDetailView(LoginRequiredMixin, View):
    def get(self, request, pk):
        entity = get_object_or_404(Entity, pk=pk)
        from certificates.models import Certificate
        certs = Certificate.objects.filter(entity=entity).order_by('-issue_date')[:10]
        return render(request, 'clients/detail.html', {'entity': entity, 'certs': certs})


class EntityUpdateView(LoginRequiredMixin, View):
    def get(self, request, pk):
        entity = get_object_or_404(Entity, pk=pk)
        return render(request, 'clients/form.html', {'form': EntityForm(instance=entity), 'title': 'Edit Entity', 'obj': entity})

    def post(self, request, pk):
        entity = get_object_or_404(Entity, pk=pk)
        form = EntityForm(request.POST, instance=entity)
        if form.is_valid():
            form.save()
            messages.success(request, 'Entity updated successfully.')
            return redirect('clients:detail', pk=entity.pk)
        return render(request, 'clients/form.html', {'form': form, 'title': 'Edit Entity', 'obj': entity})


def entity_search_api(request):
    """AJAX endpoint: search entities by name/PAN."""
    q = request.GET.get('q', '')
    results = Entity.objects.filter(
        Q(name__icontains=q) | Q(pan__icontains=q)
    )[:15]
    data = [{'id': e.pk, 'text': f"{e.name} ({e.get_entity_type_display()})"}
            for e in results]
    return JsonResponse({'results': data})


def entity_data_api(request, pk):
    """AJAX endpoint: return entity data for auto-fill."""
    entity = get_object_or_404(Entity, pk=pk)
    return JsonResponse({
        'id': entity.pk,
        'name': entity.name,
        'entity_type': entity.entity_type,
        'entity_type_display': entity.get_entity_type_display(),
        'pan': entity.pan,
        'gstin': entity.gstin,
        'cin': entity.cin,
        'llpin': entity.llpin,
        'registration_number': entity.registration_number,
        'registered_address': entity.registered_address,
        'contact_person': entity.contact_person,
        'email': entity.email,
        'phone': entity.phone,
    })

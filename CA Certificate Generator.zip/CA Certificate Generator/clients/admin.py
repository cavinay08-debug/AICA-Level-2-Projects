from django.contrib import admin
from .models import Entity


@admin.register(Entity)
class EntityAdmin(admin.ModelAdmin):
    list_display = ['name', 'entity_type', 'pan', 'gstin', 'contact_person', 'is_active']
    list_filter = ['entity_type', 'is_active']
    search_fields = ['name', 'pan', 'gstin', 'cin']

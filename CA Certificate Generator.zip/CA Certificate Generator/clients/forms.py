from django import forms
from .models import Entity


class EntityForm(forms.ModelForm):
    class Meta:
        model = Entity
        fields = '__all__'
        widgets = {
            'registered_address': forms.Textarea(attrs={'rows': 3}),
            'correspondence_address': forms.Textarea(attrs={'rows': 3}),
            'notes': forms.Textarea(attrs={'rows': 3}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for name, field in self.fields.items():
            if isinstance(field.widget, forms.CheckboxInput):
                field.widget.attrs['class'] = 'form-check-input'
            elif isinstance(field.widget, forms.Select):
                field.widget.attrs['class'] = 'form-select'
            else:
                field.widget.attrs['class'] = 'form-control'

    def clean_pan(self):
        pan = self.cleaned_data.get('pan', '').strip().upper()
        if pan and len(pan) != 10:
            raise forms.ValidationError('PAN must be exactly 10 characters.')
        return pan

    def clean_gstin(self):
        gstin = self.cleaned_data.get('gstin', '').strip().upper()
        if gstin and len(gstin) != 15:
            raise forms.ValidationError('GSTIN must be exactly 15 characters.')
        return gstin

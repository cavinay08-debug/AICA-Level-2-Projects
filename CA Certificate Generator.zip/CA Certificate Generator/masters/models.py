from django.db import models
from clients.models import Entity


class Director(models.Model):
    entity = models.ForeignKey(Entity, on_delete=models.CASCADE, related_name='directors')
    din = models.CharField(max_length=8, blank=True, verbose_name='DIN')
    full_name = models.CharField(max_length=200)
    father_name = models.CharField(max_length=200, blank=True, verbose_name="Father's Name")
    address = models.TextField(blank=True)
    pan = models.CharField(max_length=10, blank=True, verbose_name='PAN')
    date_of_birth = models.DateField(null=True, blank=True)
    designation = models.CharField(max_length=100, blank=True, default='Director')
    date_of_appointment = models.DateField(null=True, blank=True)
    is_active = models.BooleanField(default=True, verbose_name='Currently Active')
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ['full_name']
        verbose_name = 'Director'
        verbose_name_plural = 'Directors'

    def __str__(self):
        return f"{self.full_name} (DIN: {self.din or 'N/A'}) — {self.entity.name}"


class Shareholder(models.Model):
    entity = models.ForeignKey(Entity, on_delete=models.CASCADE, related_name='shareholders')
    name = models.CharField(max_length=200)
    father_name = models.CharField(max_length=200, blank=True, verbose_name="Father's Name")
    address = models.TextField(blank=True)
    pan = models.CharField(max_length=10, blank=True, verbose_name='PAN')
    share_class = models.CharField(max_length=100, blank=True, default='Equity', verbose_name='Share Class / Type')
    num_shares = models.DecimalField(max_digits=15, decimal_places=2, default=0, verbose_name='Number of Shares')
    percentage_holding = models.DecimalField(max_digits=6, decimal_places=4, default=0, verbose_name='% Holding')
    folio_dp_id = models.CharField(max_length=100, blank=True, verbose_name='Folio / DP ID / Client ID')
    is_active = models.BooleanField(default=True)
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ['-percentage_holding', 'name']
        verbose_name = 'Shareholder'
        verbose_name_plural = 'Shareholders'

    def __str__(self):
        return f"{self.name} ({self.percentage_holding}%) — {self.entity.name}"


class Partner(models.Model):
    DESIGNATION_MANAGING = 'Managing Partner'
    DESIGNATION_PARTNER = 'Partner'
    DESIGNATION_DESIGNATED = 'Designated Partner'
    DESIGNATION_SLEEPING = 'Sleeping Partner'
    DESIGNATION_CHOICES = [
        (DESIGNATION_MANAGING, 'Managing Partner'),
        (DESIGNATION_PARTNER, 'Partner'),
        (DESIGNATION_DESIGNATED, 'Designated Partner (LLP)'),
        (DESIGNATION_SLEEPING, 'Sleeping Partner'),
    ]

    entity = models.ForeignKey(Entity, on_delete=models.CASCADE, related_name='partners')
    name = models.CharField(max_length=200)
    father_name = models.CharField(max_length=200, blank=True, verbose_name="Father's Name")
    address = models.TextField(blank=True)
    pan = models.CharField(max_length=10, blank=True, verbose_name='PAN')
    designation = models.CharField(max_length=30, choices=DESIGNATION_CHOICES, default=DESIGNATION_PARTNER)
    profit_sharing_ratio = models.DecimalField(max_digits=6, decimal_places=4, default=0,
                                                verbose_name='Profit Sharing Ratio (%)')
    date_of_joining = models.DateField(null=True, blank=True)
    is_active = models.BooleanField(default=True)
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ['-profit_sharing_ratio', 'name']
        verbose_name = 'Partner'
        verbose_name_plural = 'Partners'

    def __str__(self):
        return f"{self.name} ({self.profit_sharing_ratio}%) — {self.entity.name}"

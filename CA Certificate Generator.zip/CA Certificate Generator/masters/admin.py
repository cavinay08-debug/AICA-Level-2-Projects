from django.contrib import admin
from .models import Director, Shareholder, Partner


@admin.register(Director)
class DirectorAdmin(admin.ModelAdmin):
    list_display = ['full_name', 'din', 'designation', 'entity', 'is_active']
    list_filter = ['is_active', 'designation']
    search_fields = ['full_name', 'din', 'pan', 'entity__name']


@admin.register(Shareholder)
class ShareholderAdmin(admin.ModelAdmin):
    list_display = ['name', 'entity', 'share_class', 'num_shares', 'percentage_holding']
    search_fields = ['name', 'pan', 'entity__name']


@admin.register(Partner)
class PartnerAdmin(admin.ModelAdmin):
    list_display = ['name', 'entity', 'designation', 'profit_sharing_ratio']
    search_fields = ['name', 'pan', 'entity__name']

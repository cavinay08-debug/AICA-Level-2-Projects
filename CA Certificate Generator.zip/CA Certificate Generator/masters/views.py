from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib import messages
from django.views import View
from django.http import JsonResponse
from .models import Director, Shareholder, Partner
from .forms import DirectorForm, ShareholderForm, PartnerForm
from clients.models import Entity
import openpyxl


class DirectorListView(LoginRequiredMixin, View):
    def get(self, request):
        entity_id = request.GET.get('entity')
        directors = Director.objects.select_related('entity').all()
        if entity_id:
            directors = directors.filter(entity_id=entity_id)
        entities = Entity.objects.filter(entity_type__in=['private_limited', 'public_limited'])
        return render(request, 'masters/director_list.html', {
            'directors': directors, 'entities': entities, 'selected_entity': entity_id
        })


class DirectorCreateView(LoginRequiredMixin, View):
    def get(self, request):
        form = DirectorForm(initial={'entity': request.GET.get('entity')})
        return render(request, 'masters/director_form.html', {'form': form, 'title': 'Add Director'})

    def post(self, request):
        form = DirectorForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Director added successfully.')
            return redirect('masters:director_list')
        return render(request, 'masters/director_form.html', {'form': form, 'title': 'Add Director'})


class DirectorUpdateView(LoginRequiredMixin, View):
    def get(self, request, pk):
        obj = get_object_or_404(Director, pk=pk)
        return render(request, 'masters/director_form.html', {'form': DirectorForm(instance=obj), 'title': 'Edit Director', 'obj': obj})

    def post(self, request, pk):
        obj = get_object_or_404(Director, pk=pk)
        form = DirectorForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Director updated.')
            return redirect('masters:director_list')
        return render(request, 'masters/director_form.html', {'form': form, 'title': 'Edit Director', 'obj': obj})


class ShareholderListView(LoginRequiredMixin, View):
    def get(self, request):
        entity_id = request.GET.get('entity')
        shareholders = Shareholder.objects.select_related('entity').all()
        if entity_id:
            shareholders = shareholders.filter(entity_id=entity_id)
        entities = Entity.objects.filter(entity_type__in=['private_limited', 'public_limited'])
        return render(request, 'masters/shareholder_list.html', {
            'shareholders': shareholders, 'entities': entities, 'selected_entity': entity_id
        })


class ShareholderCreateView(LoginRequiredMixin, View):
    def get(self, request):
        return render(request, 'masters/shareholder_form.html', {'form': ShareholderForm(), 'title': 'Add Shareholder'})

    def post(self, request):
        form = ShareholderForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Shareholder added.')
            return redirect('masters:shareholder_list')
        return render(request, 'masters/shareholder_form.html', {'form': form, 'title': 'Add Shareholder'})


class ShareholderUpdateView(LoginRequiredMixin, View):
    def get(self, request, pk):
        obj = get_object_or_404(Shareholder, pk=pk)
        return render(request, 'masters/shareholder_form.html', {'form': ShareholderForm(instance=obj), 'title': 'Edit Shareholder', 'obj': obj})

    def post(self, request, pk):
        obj = get_object_or_404(Shareholder, pk=pk)
        form = ShareholderForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Shareholder updated.')
            return redirect('masters:shareholder_list')
        return render(request, 'masters/shareholder_form.html', {'form': form, 'title': 'Edit Shareholder', 'obj': obj})


class PartnerListView(LoginRequiredMixin, View):
    def get(self, request):
        entity_id = request.GET.get('entity')
        partners = Partner.objects.select_related('entity').all()
        if entity_id:
            partners = partners.filter(entity_id=entity_id)
        entities = Entity.objects.filter(entity_type__in=['partnership', 'llp'])
        return render(request, 'masters/partner_list.html', {
            'partners': partners, 'entities': entities, 'selected_entity': entity_id
        })


class PartnerCreateView(LoginRequiredMixin, View):
    def get(self, request):
        return render(request, 'masters/partner_form.html', {'form': PartnerForm(), 'title': 'Add Partner'})

    def post(self, request):
        form = PartnerForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Partner added.')
            return redirect('masters:partner_list')
        return render(request, 'masters/partner_form.html', {'form': form, 'title': 'Add Partner'})


class PartnerUpdateView(LoginRequiredMixin, View):
    def get(self, request, pk):
        obj = get_object_or_404(Partner, pk=pk)
        return render(request, 'masters/partner_form.html', {'form': PartnerForm(instance=obj), 'title': 'Edit Partner', 'obj': obj})

    def post(self, request, pk):
        obj = get_object_or_404(Partner, pk=pk)
        form = PartnerForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Partner updated.')
            return redirect('masters:partner_list')
        return render(request, 'masters/partner_form.html', {'form': form, 'title': 'Edit Partner', 'obj': obj})


class ImportMastersView(LoginRequiredMixin, View):
    """Import Directors/Shareholders/Partners from Excel."""

    def get(self, request):
        entities = Entity.objects.all()
        return render(request, 'masters/import.html', {'entities': entities})

    def post(self, request):
        if not request.user.is_admin():
            messages.error(request, 'Access denied.')
            return redirect('dashboard:home')

        file = request.FILES.get('excel_file')
        import_type = request.POST.get('import_type')
        entity_id = request.POST.get('entity_id')

        if not file or not import_type or not entity_id:
            messages.error(request, 'Please provide all required fields.')
            return render(request, 'masters/import.html', {})

        try:
            entity = Entity.objects.get(pk=entity_id)
            wb = openpyxl.load_workbook(file)
            ws = wb.active
            rows = list(ws.iter_rows(values_only=True))
            if not rows:
                messages.error(request, 'Excel file is empty.')
                return redirect('masters:import')

            headers = [str(h).strip().lower().replace(' ', '_') if h else '' for h in rows[0]]
            created = 0
            errors = []

            def get_col(row, key):
                if key in headers:
                    val = row[headers.index(key)]
                    return str(val).strip() if val else ''
                return ''

            for i, row in enumerate(rows[1:], 2):
                try:
                    if import_type == 'directors':
                        Director.objects.create(
                            entity=entity,
                            din=get_col(row, 'din'),
                            full_name=get_col(row, 'full_name') or get_col(row, 'name'),
                            father_name=get_col(row, 'father_name'),
                            address=get_col(row, 'address'),
                            pan=get_col(row, 'pan'),
                            designation=get_col(row, 'designation') or 'Director',
                        )
                        created += 1
                    elif import_type == 'shareholders':
                        Shareholder.objects.create(
                            entity=entity,
                            name=get_col(row, 'name') or get_col(row, 'full_name'),
                            father_name=get_col(row, 'father_name'),
                            address=get_col(row, 'address'),
                            pan=get_col(row, 'pan'),
                            share_class=get_col(row, 'share_class') or 'Equity',
                            num_shares=float(get_col(row, 'num_shares') or 0),
                            percentage_holding=float(get_col(row, 'percentage_holding') or get_col(row, 'percentage') or 0),
                            folio_dp_id=get_col(row, 'folio_dp_id'),
                        )
                        created += 1
                    elif import_type == 'partners':
                        Partner.objects.create(
                            entity=entity,
                            name=get_col(row, 'name') or get_col(row, 'full_name'),
                            father_name=get_col(row, 'father_name'),
                            address=get_col(row, 'address'),
                            pan=get_col(row, 'pan'),
                            designation=get_col(row, 'designation') or 'Partner',
                            profit_sharing_ratio=float(get_col(row, 'profit_sharing_ratio') or get_col(row, 'ratio') or 0),
                        )
                        created += 1
                except Exception as e:
                    errors.append(f"Row {i}: {str(e)}")

            messages.success(request, f'Successfully imported {created} records.')
            if errors:
                messages.warning(request, f'Errors in {len(errors)} rows: ' + '; '.join(errors[:5]))
        except Exception as e:
            messages.error(request, f'Import failed: {str(e)}')

        return redirect('masters:import')


def directors_api(request):
    entity_id = request.GET.get('entity_id')
    if not entity_id:
        return JsonResponse({'results': []})
    directors = Director.objects.filter(entity_id=entity_id, is_active=True)
    data = [{
        'id': d.pk,
        'text': f"{d.full_name} (DIN: {d.din or 'N/A'})",
        'din': d.din, 'full_name': d.full_name, 'father_name': d.father_name,
        'address': d.address, 'pan': d.pan, 'designation': d.designation,
        'date_of_appointment': d.date_of_appointment.strftime('%d-%m-%Y') if d.date_of_appointment else '',
    } for d in directors]
    return JsonResponse({'results': data})


def shareholders_api(request):
    entity_id = request.GET.get('entity_id')
    if not entity_id:
        return JsonResponse({'results': []})
    shareholders = Shareholder.objects.filter(entity_id=entity_id, is_active=True)
    data = [{
        'id': s.pk,
        'text': f"{s.name} ({s.percentage_holding}%)",
        'name': s.name, 'father_name': s.father_name, 'address': s.address,
        'pan': s.pan, 'share_class': s.share_class, 'num_shares': str(s.num_shares),
        'percentage_holding': str(s.percentage_holding), 'folio_dp_id': s.folio_dp_id,
    } for s in shareholders]
    return JsonResponse({'results': data})


def partners_api(request):
    entity_id = request.GET.get('entity_id')
    if not entity_id:
        return JsonResponse({'results': []})
    partners = Partner.objects.filter(entity_id=entity_id, is_active=True)
    data = [{
        'id': p.pk,
        'text': f"{p.name} ({p.profit_sharing_ratio}%)",
        'name': p.name, 'father_name': p.father_name, 'address': p.address,
        'pan': p.pan, 'designation': p.designation,
        'profit_sharing_ratio': str(p.profit_sharing_ratio),
        'date_of_joining': p.date_of_joining.strftime('%d-%m-%Y') if p.date_of_joining else '',
    } for p in partners]
    return JsonResponse({'results': data})

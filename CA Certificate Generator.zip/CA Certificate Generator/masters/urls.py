from django.urls import path
from . import views

app_name = 'masters'

urlpatterns = [
    # Directors
    path('directors/', views.DirectorListView.as_view(), name='director_list'),
    path('directors/create/', views.DirectorCreateView.as_view(), name='director_create'),
    path('directors/<int:pk>/edit/', views.DirectorUpdateView.as_view(), name='director_edit'),
    # Shareholders
    path('shareholders/', views.ShareholderListView.as_view(), name='shareholder_list'),
    path('shareholders/create/', views.ShareholderCreateView.as_view(), name='shareholder_create'),
    path('shareholders/<int:pk>/edit/', views.ShareholderUpdateView.as_view(), name='shareholder_edit'),
    # Partners
    path('partners/', views.PartnerListView.as_view(), name='partner_list'),
    path('partners/create/', views.PartnerCreateView.as_view(), name='partner_create'),
    path('partners/<int:pk>/edit/', views.PartnerUpdateView.as_view(), name='partner_edit'),
    # Import
    path('import/', views.ImportMastersView.as_view(), name='import'),
    # AJAX APIs
    path('api/directors/', views.directors_api, name='directors_api'),
    path('api/shareholders/', views.shareholders_api, name='shareholders_api'),
    path('api/partners/', views.partners_api, name='partners_api'),
]

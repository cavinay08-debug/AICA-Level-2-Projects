def global_context(request):
    """Global context processor to add common vars to all templates."""
    from firms.models import CAFirm
    try:
        firms = CAFirm.objects.filter(is_active=True)
    except Exception:
        firms = []
    return {
        'all_firms': firms,
        'app_name': 'CA Certificate Manager',
    }

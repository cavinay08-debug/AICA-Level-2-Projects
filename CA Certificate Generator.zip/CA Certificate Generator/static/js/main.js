/**
 * CA Certificate Manager — Main JavaScript
 * Handles: Dynamic tables, entity auto-fill, director/shareholder/partner pickers,
 *          toast messages, sidebar toggle, form interactions.
 */

'use strict';

// ── TOAST MESSAGES ─────────────────────────────────────────────────────────

function showToast(message, type = 'info', duration = 4000) {
    const container = document.querySelector('.messages-container') || (() => {
        const c = document.createElement('div');
        c.className = 'messages-container';
        document.body.appendChild(c);
        return c;
    })();

    const toast = document.createElement('div');
    const icons = { success: '✓', error: '✕', warning: '⚠', info: 'ℹ' };
    toast.className = `toast-msg ${type}`;
    toast.innerHTML = `<span>${icons[type] || 'ℹ'}</span><span>${message}</span>`;
    toast.onclick = () => toast.remove();
    container.appendChild(toast);

    setTimeout(() => {
        toast.style.animation = 'fadeOut 0.3s ease forwards';
        setTimeout(() => toast.remove(), 300);
    }, duration);
}

// Auto-dismiss Django messages
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.toast-msg').forEach((el, i) => {
        setTimeout(() => {
            el.style.animation = 'fadeOut 0.3s ease forwards';
            setTimeout(() => el.remove(), 300);
        }, 4000 + i * 500);
    });
});


// ── ENTITY AUTOFILL ────────────────────────────────────────────────────────

function initEntityAutofill() {
    const entitySelect = document.getElementById('id_entity');
    if (!entitySelect) return;

    entitySelect.addEventListener('change', async () => {
        const entityId = entitySelect.value;
        if (!entityId) return;

        try {
            const response = await fetch(`/clients/api/${entityId}/data/`);
            const data = await response.json();

            const map = {
                'id_entity_name_on_cert': data.name,
                'id_entity_type_on_cert': data.entity_type,
                'id_pan_on_cert': data.pan,
                'id_gstin_on_cert': data.gstin,
                'id_cin_on_cert': data.cin,
                'id_llpin_on_cert': data.llpin,
                'id_address_on_cert': data.registered_address,
            };

            for (const [id, value] of Object.entries(map)) {
                const el = document.getElementById(id);
                if (el && !el.value) {
                    el.value = value || '';
                    el.style.background = '#f0f8e8';
                    setTimeout(() => el.style.background = '', 1500);
                }
            }
        } catch (err) {
            console.error('Entity autofill failed:', err);
        }
    });
}


// ── DYNAMIC JSON TABLE BUILDER ─────────────────────────────────────────────
// Generic function for tables whose data is stored as JSON

function DynamicTable(options) {
    /**
     * options:
     *  - containerId: ID of the wrapper div
     *  - hiddenInputId: ID of the hidden JSON input
     *  - columns: [{key, label, type?, placeholder?}, ...]
     *  - initialData: array of objects from server (for edit mode)
     */
    const { containerId, hiddenInputId, columns, initialData = [] } = options;
    const container = document.getElementById(containerId);
    const hiddenInput = document.getElementById(hiddenInputId);
    if (!container || !hiddenInput) return;

    let rows = [...initialData];

    function render() {
        container.innerHTML = '';
        const table = document.createElement('table');
        table.className = 'w-full border-collapse text-sm';
        table.style.cssText = 'width:100%; border-collapse:collapse; font-size:0.875rem;';

        // Header
        const thead = table.createTHead();
        const tr = thead.insertRow();
        tr.style.background = '#0f2444';
        columns.forEach(col => {
            const th = document.createElement('th');
            th.textContent = col.label;
            th.style.cssText = 'padding:7px 10px; color:white; text-align:left; font-size:0.78rem; font-weight:600;';
            tr.appendChild(th);
        });
        const thDel = document.createElement('th');
        thDel.textContent = '';
        thDel.style.width = '30px';
        tr.appendChild(thDel);

        // Body
        const tbody = table.createTBody();
        rows.forEach((row, idx) => {
            const tr = tbody.insertRow();
            tr.style.borderBottom = '1px solid #dce3f0';
            columns.forEach(col => {
                const td = tr.insertCell();
                td.style.cssText = 'border:1px solid #dce3f0; padding:0;';
                const input = document.createElement(col.type === 'textarea' ? 'textarea' : 'input');
                input.value = row[col.key] || '';
                input.placeholder = col.placeholder || col.label;
                input.style.cssText = 'width:100%; border:none; padding:6px 8px; font-size:0.875rem; font-family:inherit; outline:none; background:transparent; resize:none;';
                if (col.type === 'number') input.type = 'number';
                input.addEventListener('input', () => {
                    rows[idx][col.key] = input.value;
                    updateHidden();
                });
                td.appendChild(input);
            });
            const tdDel = tr.insertCell();
            tdDel.textContent = '✕';
            tdDel.style.cssText = 'text-align:center; cursor:pointer; color:#dc2626; font-weight:bold; padding:4px 8px; border:1px solid #dce3f0;';
            tdDel.onclick = () => { rows.splice(idx, 1); render(); };
        });

        container.appendChild(table);
        updateHidden();
    }

    function updateHidden() {
        hiddenInput.value = JSON.stringify(rows);
    }

    // Add row button
    const addBtn = container.parentElement?.querySelector('.add-row-btn');
    if (addBtn) {
        addBtn.onclick = () => {
            const newRow = {};
            columns.forEach(col => newRow[col.key] = '');
            rows.push(newRow);
            render();
        };
    }

    render();
    return { rows, render };
}


// ── NET WORTH TABLE ────────────────────────────────────────────────────────

function initNetWorthTables() {
    const assetsEl = document.getElementById('assets-container');
    const liabsEl = document.getElementById('liabilities-container');
    if (!assetsEl && !liabsEl) return;

    const cols = [
        { key: 'description', label: 'Particulars / Description', placeholder: 'e.g. Fixed Assets' },
        { key: 'amount', label: 'Amount (₹)', type: 'number', placeholder: '0.00' },
    ];

    const getInitial = id => {
        try {
            const el = document.getElementById(id);
            return el ? JSON.parse(el.value || '[]') : [];
        } catch { return []; }
    };

    DynamicTable({
        containerId: 'assets-container',
        hiddenInputId: 'assets_json_input',
        columns: cols,
        initialData: getInitial('assets_json_input'),
    });

    DynamicTable({
        containerId: 'liabilities-container',
        hiddenInputId: 'liabilities_json_input',
        columns: cols,
        initialData: getInitial('liabilities_json_input'),
    });
}


// ── TURNOVER TABLE ─────────────────────────────────────────────────────────

function initTurnoverTable() {
    const el = document.getElementById('turnover-container');
    if (!el) return;

    const cols = [
        { key: 'financial_year', label: 'Financial Year', placeholder: 'e.g. 2024-25' },
        { key: 'turnover', label: 'Total Turnover (₹)', type: 'number' },
        { key: 'gst_turnover', label: 'GST Turnover (₹)', type: 'number' },
        { key: 'source_records', label: 'Source Records Reviewed' },
    ];

    const getInitial = () => {
        try { return JSON.parse(document.getElementById('turnover_json_input')?.value || '[]'); }
        catch { return []; }
    };

    DynamicTable({
        containerId: 'turnover-container',
        hiddenInputId: 'turnover_json_input',
        columns: cols,
        initialData: getInitial(),
    });
}


// Pickers are now self-contained inside their respective template forms.


// ── END USE TABLE ──────────────────────────────────────────────────────────

function initEndUseTable() {
    const el = document.getElementById('utilisation-container');
    if (!el) return;

    const cols = [
        { key: 'particulars', label: 'Particulars of Utilisation' },
        { key: 'amount_utilised', label: 'Amount Utilised (₹)', type: 'number' },
        { key: 'remarks', label: 'Remarks' },
    ];

    const getInitial = () => {
        try { return JSON.parse(document.getElementById('utilisation_json_input')?.value || '[]'); }
        catch { return []; }
    };

    DynamicTable({
        containerId: 'utilisation-container',
        hiddenInputId: 'utilisation_json_input',
        columns: cols,
        initialData: getInitial(),
    });
}


// ── CUSTOM CERT STATEMENTS ─────────────────────────────────────────────────

function initCustomStatementsTable() {
    const container = document.getElementById('statements-container');
    const jsonInput = document.getElementById('statements_json_input');
    if (!container || !jsonInput) return;

    let statements = [];
    try { statements = JSON.parse(jsonInput.value || '[]'); } catch {}

    function render() {
        container.innerHTML = '';
        statements.forEach((s, idx) => {
            const row = document.createElement('div');
            row.style.cssText = 'display:flex;gap:8px;margin-bottom:8px;align-items:flex-start;';
            row.innerHTML = `
                <span style="min-width:24px;font-weight:600;color:#4a5568;padding-top:8px;">${idx+1}.</span>
                <textarea class="form-control" rows="2" style="flex:1;">${s}</textarea>
                <button type="button" style="background:none;border:none;color:#dc2626;cursor:pointer;font-size:1.2rem;padding:6px;" onclick="removeStatement(${idx})">✕</button>
            `;
            row.querySelector('textarea').addEventListener('input', (e) => {
                statements[idx] = e.target.value;
                jsonInput.value = JSON.stringify(statements);
            });
            container.appendChild(row);
        });
        jsonInput.value = JSON.stringify(statements);
    }

    window.removeStatement = (idx) => { statements.splice(idx, 1); render(); };
    window.addStatement = () => { statements.push(''); render(); };

    render();
}


// ── SIDEBAR TOGGLE ─────────────────────────────────────────────────────────

function initSidebarToggle() {
    const toggle = document.querySelector('.sidebar-toggle');
    const sidebar = document.querySelector('.sidebar');
    if (!toggle || !sidebar) return;

    toggle.addEventListener('click', () => {
        sidebar.classList.toggle('mobile-open');
    });

    document.addEventListener('click', (e) => {
        if (!sidebar.contains(e.target) && !toggle.contains(e.target)) {
            sidebar.classList.remove('mobile-open');
        }
    });
}


// ── ACTIVE NAV LINK ────────────────────────────────────────────────────────

function initActiveNavLink() {
    const currentPath = window.location.pathname;
    document.querySelectorAll('.sidebar-link').forEach(link => {
        const href = link.getAttribute('href');
        if (href && href !== '/' && currentPath.startsWith(href)) {
            link.classList.add('active');
        } else if (href === '/' && currentPath === '/') {
            link.classList.add('active');
        }
    });
}


// ── CONFIRM DIALOGS ────────────────────────────────────────────────────────

document.addEventListener('click', (e) => {
    const el = e.target.closest('[data-confirm]');
    if (el) {
        const msg = el.dataset.confirm;
        if (!confirm(msg)) e.preventDefault();
    }
});


// ── CURRENCY FORMATTING ────────────────────────────────────────────────────

function formatINR(amount) {
    return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        minimumFractionDigits: 2,
    }).format(amount);
}


// ── INIT ───────────────────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', () => {
    initEntityAutofill();
    initNetWorthTables();
    initTurnoverTable();
    initEndUseTable();
    initCustomStatementsTable();
    initSidebarToggle();
    initActiveNavLink();
});

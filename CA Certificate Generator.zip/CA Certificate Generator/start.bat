@echo off
title CA Certificate Manager
color 1F
echo.
echo  ============================================================
echo   CA Certificate Manager — Professional Suite
echo  ============================================================
echo.

:: Install dependencies
echo [1/5] Checking and installing dependencies...
pip install -r requirements.txt --quiet
if errorlevel 1 (
    echo ERROR: pip install failed. Make sure Python is installed.
    pause
    exit /b 1
)
echo        Done.
echo.

:: Run migrations
echo [2/5] Applying database migrations...
python manage.py migrate --run-syncdb --no-input
echo        Done.
echo.

:: Seed firms
echo [3/5] Seeding CA firm data...
python manage.py seed_firms
echo.

:: Create admin user
echo [4/5] Creating admin user (if not exists)...
python manage.py create_admin
echo.

:: Open browser
echo [5/5] Starting server and opening browser...
echo.
echo  ============================================================
echo   Server running at:  http://localhost:8000
echo   Login:  admin / Admin@123
echo   Press Ctrl+C to stop the server.
echo  ============================================================
echo.
start http://localhost:8000
python manage.py runserver 8000

pause

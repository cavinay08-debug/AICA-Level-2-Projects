export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.15"
  }
  public: {
    Tables: {
      audit_log: {
        Row: {
          action: string
          actor_email: string | null
          actor_id: string | null
          created_at: string
          details: Json | null
          entity: string
          entity_id: string | null
          entity_label: string | null
          id: string
        }
        Insert: {
          action: string
          actor_email?: string | null
          actor_id?: string | null
          created_at?: string
          details?: Json | null
          entity: string
          entity_id?: string | null
          entity_label?: string | null
          id?: string
        }
        Update: {
          action?: string
          actor_email?: string | null
          actor_id?: string | null
          created_at?: string
          details?: Json | null
          entity?: string
          entity_id?: string | null
          entity_label?: string | null
          id?: string
        }
        Relationships: []
      }
      bols: {
        Row: {
          bol_number: string
          created_at: string
          created_by: string | null
          file_reference_number: string | null
          id: string
          notes: string | null
          po_id: string | null
          shipment_date: string | null
          supplier: string
        }
        Insert: {
          bol_number: string
          created_at?: string
          created_by?: string | null
          file_reference_number?: string | null
          id?: string
          notes?: string | null
          po_id?: string | null
          shipment_date?: string | null
          supplier: string
        }
        Update: {
          bol_number?: string
          created_at?: string
          created_by?: string | null
          file_reference_number?: string | null
          id?: string
          notes?: string | null
          po_id?: string | null
          shipment_date?: string | null
          supplier?: string
        }
        Relationships: [
          {
            foreignKeyName: "bols_po_id_fkey"
            columns: ["po_id"]
            isOneToOne: false
            referencedRelation: "purchase_orders"
            referencedColumns: ["id"]
          },
        ]
      }
      chassis: {
        Row: {
          allocated_at: string | null
          at_plant_at: string | null
          at_port_at: string | null
          bol_id: string
          chassis_number: string | null
          created_at: string
          customer_id: string | null
          delivered_at: string | null
          delivery_authorized_at: string | null
          engine_number: string
          id: string
          in_transit_at: string | null
          invoice_id: string | null
          invoiced_at: string | null
          model: string | null
          paid_at: string | null
          produced_at: string | null
          registration_date: string | null
          registration_number: string | null
          shipped_at: string | null
          status: Database["public"]["Enums"]["chassis_status"]
          updated_at: string
        }
        Insert: {
          allocated_at?: string | null
          at_plant_at?: string | null
          at_port_at?: string | null
          bol_id: string
          chassis_number?: string | null
          created_at?: string
          customer_id?: string | null
          delivered_at?: string | null
          delivery_authorized_at?: string | null
          engine_number: string
          id?: string
          in_transit_at?: string | null
          invoice_id?: string | null
          invoiced_at?: string | null
          model?: string | null
          paid_at?: string | null
          produced_at?: string | null
          registration_date?: string | null
          registration_number?: string | null
          shipped_at?: string | null
          status?: Database["public"]["Enums"]["chassis_status"]
          updated_at?: string
        }
        Update: {
          allocated_at?: string | null
          at_plant_at?: string | null
          at_port_at?: string | null
          bol_id?: string
          chassis_number?: string | null
          created_at?: string
          customer_id?: string | null
          delivered_at?: string | null
          delivery_authorized_at?: string | null
          engine_number?: string
          id?: string
          in_transit_at?: string | null
          invoice_id?: string | null
          invoiced_at?: string | null
          model?: string | null
          paid_at?: string | null
          produced_at?: string | null
          registration_date?: string | null
          registration_number?: string | null
          shipped_at?: string | null
          status?: Database["public"]["Enums"]["chassis_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "chassis_bol_id_fkey"
            columns: ["bol_id"]
            isOneToOne: false
            referencedRelation: "bols"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "chassis_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "chassis_invoice_id_fkey"
            columns: ["invoice_id"]
            isOneToOne: false
            referencedRelation: "invoices"
            referencedColumns: ["id"]
          },
        ]
      }
      customers: {
        Row: {
          contact_person: string | null
          created_at: string
          email: string | null
          id: string
          id_proof: string | null
          name: string
          phone: string | null
          tin: string | null
          vrn: string | null
        }
        Insert: {
          contact_person?: string | null
          created_at?: string
          email?: string | null
          id?: string
          id_proof?: string | null
          name: string
          phone?: string | null
          tin?: string | null
          vrn?: string | null
        }
        Update: {
          contact_person?: string | null
          created_at?: string
          email?: string | null
          id?: string
          id_proof?: string | null
          name?: string
          phone?: string | null
          tin?: string | null
          vrn?: string | null
        }
        Relationships: []
      }
      gate_passes: {
        Row: {
          chassis_id: string
          created_at: string
          delivery_date: string
          gate_pass_number: string
          id: string
          issued_by: string | null
          receiver_id_proof: string
          receiver_name: string
          signature_verified: boolean
        }
        Insert: {
          chassis_id: string
          created_at?: string
          delivery_date?: string
          gate_pass_number: string
          id?: string
          issued_by?: string | null
          receiver_id_proof: string
          receiver_name: string
          signature_verified?: boolean
        }
        Update: {
          chassis_id?: string
          created_at?: string
          delivery_date?: string
          gate_pass_number?: string
          id?: string
          issued_by?: string | null
          receiver_id_proof?: string
          receiver_name?: string
          signature_verified?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "gate_passes_chassis_id_fkey"
            columns: ["chassis_id"]
            isOneToOne: true
            referencedRelation: "chassis"
            referencedColumns: ["id"]
          },
        ]
      }
      invoices: {
        Row: {
          created_at: string
          created_by: string | null
          customer_id: string | null
          id: string
          invoice_date: string
          invoice_number: string
          payment_confirmed: boolean
          payment_confirmed_at: string | null
          payment_method: string | null
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          customer_id?: string | null
          id?: string
          invoice_date?: string
          invoice_number: string
          payment_confirmed?: boolean
          payment_confirmed_at?: string | null
          payment_method?: string | null
        }
        Update: {
          created_at?: string
          created_by?: string | null
          customer_id?: string | null
          id?: string
          invoice_date?: string
          invoice_number?: string
          payment_confirmed?: boolean
          payment_confirmed_at?: string | null
          payment_method?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "invoices_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          created_at: string
          department: string | null
          email: string
          full_name: string | null
          id: string
          status: Database["public"]["Enums"]["approval_status"]
          updated_at: string
        }
        Insert: {
          created_at?: string
          department?: string | null
          email: string
          full_name?: string | null
          id: string
          status?: Database["public"]["Enums"]["approval_status"]
          updated_at?: string
        }
        Update: {
          created_at?: string
          department?: string | null
          email?: string
          full_name?: string | null
          id?: string
          status?: Database["public"]["Enums"]["approval_status"]
          updated_at?: string
        }
        Relationships: []
      }
      purchase_orders: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          model: string | null
          notes: string | null
          order_date: string
          po_number: string
          quantity: number
          supplier: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          model?: string | null
          notes?: string | null
          order_date?: string
          po_number: string
          quantity: number
          supplier: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          model?: string | null
          notes?: string | null
          order_date?: string
          po_number?: string
          quantity?: number
          supplier?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      can_act: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_approved: { Args: { _user_id: string }; Returns: boolean }
      status_rank: {
        Args: { _s: Database["public"]["Enums"]["chassis_status"] }
        Returns: number
      }
    }
    Enums: {
      app_role:
        | "super_admin"
        | "procurement"
        | "clearing"
        | "production"
        | "sales"
        | "accounts"
        | "store"
        | "management"
      approval_status: "pending" | "approved" | "rejected" | "deactivated"
      chassis_status:
        | "ordered"
        | "shipped"
        | "in_transit"
        | "at_port"
        | "at_plant"
        | "produced"
        | "allocated"
        | "invoiced"
        | "paid"
        | "delivery_authorized"
        | "delivered"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: [
        "super_admin",
        "procurement",
        "clearing",
        "production",
        "sales",
        "accounts",
        "store",
        "management",
      ],
      approval_status: ["pending", "approved", "rejected", "deactivated"],
      chassis_status: [
        "ordered",
        "shipped",
        "in_transit",
        "at_port",
        "at_plant",
        "produced",
        "allocated",
        "invoiced",
        "paid",
        "delivery_authorized",
        "delivered",
      ],
    },
  },
} as const

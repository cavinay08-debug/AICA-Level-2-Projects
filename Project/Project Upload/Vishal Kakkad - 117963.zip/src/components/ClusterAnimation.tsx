import type { ClusterKey } from "@/lib/ckd";

/**
 * Department-specific automotive animations.
 * Ordering  — kit crates loaded by a crane hook
 * Inbound   — truck driving left to right off the port
 * Production— truck halves joining + spinning bearings on the assembly line
 * Commercial— invoice stamp pressing down
 * Dispatch  — gate boom lifting as the vehicle rolls out
 */
export function ClusterAnimation({
  cluster,
  className = "",
}: {
  cluster: ClusterKey;
  className?: string;
}) {
  return (
    <div
      aria-hidden="true"
      className={`relative h-10 w-28 overflow-hidden rounded-sm border border-border bg-muted/60 ${className}`}
    >
      {cluster === "ordering" ? <Ordering /> : null}
      {cluster === "inbound" ? <Inbound /> : null}
      {cluster === "production" ? <Production /> : null}
      {cluster === "commercial" ? <Commercial /> : null}
      {cluster === "dispatch" ? <Dispatch /> : null}
    </div>
  );
}

const stroke = "currentColor";

function Ground() {
  return (
    <div className="absolute bottom-1.5 left-0 h-px w-full bg-border-strong/70" />
  );
}

function Ordering() {
  return (
    <div className="absolute inset-0 text-primary">
      <Ground />
      {/* gantry rail */}
      <div className="absolute top-1.5 left-2 h-px w-24 bg-border-strong" />
      <svg className="anim-crane absolute top-1.5 left-9" width="26" height="26" viewBox="0 0 26 26">
        <line x1="13" y1="0" x2="13" y2="8" stroke={stroke} strokeWidth="1" />
        <rect x="5" y="8" width="16" height="11" fill="none" stroke={stroke} strokeWidth="1.4" />
        <line x1="5" y1="13.5" x2="21" y2="13.5" stroke={stroke} strokeWidth="0.8" />
      </svg>
      <svg className="absolute bottom-1.5 left-2 text-muted-foreground" width="18" height="12" viewBox="0 0 18 12">
        <rect x="0.7" y="0.7" width="16.6" height="10.6" fill="none" stroke={stroke} strokeWidth="1.2" />
      </svg>
      <svg className="absolute bottom-1.5 right-2 text-muted-foreground" width="18" height="12" viewBox="0 0 18 12">
        <rect x="0.7" y="0.7" width="16.6" height="10.6" fill="none" stroke={stroke} strokeWidth="1.2" />
      </svg>
    </div>
  );
}

function Truck({ className = "" }: { className?: string }) {
  return (
    <svg className={className} width="40" height="18" viewBox="0 0 40 18">
      <rect x="0.8" y="2" width="21" height="11" fill="none" stroke={stroke} strokeWidth="1.4" />
      <path d="M22 6h7l4 4v3H22z" fill="none" stroke={stroke} strokeWidth="1.4" />
      <circle cx="7" cy="15" r="2.4" fill="none" stroke={stroke} strokeWidth="1.3" />
      <circle cx="27" cy="15" r="2.4" fill="none" stroke={stroke} strokeWidth="1.3" />
    </svg>
  );
}

function Inbound() {
  return (
    <div className="absolute inset-0 text-primary">
      <Ground />
      <Truck className="anim-drive absolute bottom-0.5 left-0" />
    </div>
  );
}

function Bearing({ className }: { className: string }) {
  return (
    <svg className={className} width="16" height="16" viewBox="0 0 16 16">
      <circle cx="8" cy="8" r="6.6" fill="none" stroke={stroke} strokeWidth="1.2" />
      <circle cx="8" cy="8" r="2.2" fill="none" stroke={stroke} strokeWidth="1.2" />
      <circle cx="8" cy="2.4" r="1" fill={stroke} />
      <circle cx="13.6" cy="8" r="1" fill={stroke} />
      <circle cx="8" cy="13.6" r="1" fill={stroke} />
      <circle cx="2.4" cy="8" r="1" fill={stroke} />
    </svg>
  );
}

function Production() {
  return (
    <div className="absolute inset-0 text-primary">
      {/* joining truck halves */}
      <svg className="anim-join-left absolute top-1 left-3" width="24" height="14" viewBox="0 0 24 14">
        <rect x="0.8" y="1" width="22" height="10" fill="none" stroke={stroke} strokeWidth="1.3" />
        <circle cx="7" cy="12.5" r="1.3" fill={stroke} />
      </svg>
      <svg className="anim-join-right absolute top-1 right-3" width="20" height="14" viewBox="0 0 20 14">
        <path d="M0.8 4h11l7 7v0h-18z" fill="none" stroke={stroke} strokeWidth="1.3" />
        <circle cx="13" cy="12.5" r="1.3" fill={stroke} />
      </svg>
      {/* conveyor + bearings */}
      <div
        className="anim-belt absolute bottom-1 left-0 h-1 w-full"
        style={{
          backgroundImage:
            "repeating-linear-gradient(90deg, var(--color-border-strong) 0 6px, transparent 6px 16px)",
        }}
      />
      <Bearing className="anim-spin-slow absolute bottom-2.5 left-2 text-accent" />
      <Bearing className="anim-spin-rev absolute bottom-2.5 right-2 text-accent" />
    </div>
  );
}

function Commercial() {
  return (
    <div className="absolute inset-0 text-primary">
      <svg className="absolute bottom-1.5 left-1/2 -translate-x-1/2 text-muted-foreground" width="26" height="18" viewBox="0 0 26 18">
        <rect x="0.7" y="0.7" width="24.6" height="16.6" fill="none" stroke={stroke} strokeWidth="1.2" />
        <line x1="4" y1="5" x2="20" y2="5" stroke={stroke} strokeWidth="1" />
        <line x1="4" y1="9" x2="16" y2="9" stroke={stroke} strokeWidth="1" />
        <line x1="4" y1="13" x2="18" y2="13" stroke={stroke} strokeWidth="1" />
      </svg>
      <svg className="anim-stamp absolute top-1 left-1/2 -translate-x-1/2 text-accent" width="22" height="20" viewBox="0 0 22 20">
        <rect x="4" y="12" width="14" height="5" fill="none" stroke={stroke} strokeWidth="1.4" />
        <rect x="8" y="2" width="6" height="10" fill="none" stroke={stroke} strokeWidth="1.4" />
      </svg>
    </div>
  );
}

function Dispatch() {
  return (
    <div className="absolute inset-0 text-primary">
      <Ground />
      <div className="absolute bottom-1.5 left-16 h-6 w-px bg-border-strong" />
      <div className="anim-gate absolute bottom-6 left-16 h-px w-10 origin-left bg-accent" />
      <Truck className="anim-drive absolute bottom-0.5 left-0" />
      <span className="anim-pulse-soft absolute top-1 right-1 size-1.5 rounded-full bg-success" />
    </div>
  );
}

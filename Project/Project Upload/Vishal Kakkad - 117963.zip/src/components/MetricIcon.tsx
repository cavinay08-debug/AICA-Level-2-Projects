import {
  Anchor,
  BadgeCheck,
  Boxes,
  ClipboardList,
  Clock,
  Factory,
  FileText,
  Hourglass,
  PackageCheck,
  PackageX,
  Receipt,
  Ship,
  Truck,
  UserCheck,
  Warehouse,
} from "lucide-react";
import type { MetricIcon as MetricIconKey } from "@/lib/ckd";

const ICONS: Record<MetricIconKey, typeof Ship> = {
  purchase: ClipboardList,
  ship: Ship,
  "pending-ship": Hourglass,
  port: Anchor,
  plant: Warehouse,
  produced: Factory,
  billed: Receipt,
  allocated: UserCheck,
  invoice: FileText,
  "pending-bill": Clock,
  unallocated: PackageX,
  unsold: Boxes,
  undelivered: Truck,
  stock: PackageCheck,
  delivered: BadgeCheck,
};

export function MetricIcon({ icon, className }: { icon: MetricIconKey; className?: string }) {
  const Icon = ICONS[icon];
  return <Icon className={className} aria-hidden />;
}

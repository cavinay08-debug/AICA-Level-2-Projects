import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";

export function Guard({ children }: { children: ReactNode }) {
  const { loading, session, profile, signOut } = useAuth();

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <span className="label-caps animate-pulse">Loading plant data…</span>
      </div>
    );
  }

  if (!session) {
    return (
      <Centered
        title="Authorisation required"
        body="Sign in with your department account to view the chassis register."
      >
        <Button asChild>
          <Link to="/auth">Go to sign in</Link>
        </Button>
      </Centered>
    );
  }

  if (profile?.status !== "approved") {
    return (
      <Centered
        title={profile?.status === "pending" ? "Awaiting approval" : "Access unavailable"}
        body={
          profile?.status === "pending"
            ? "Your access request has been logged. A Super Admin must approve your department and permitted tasks before plant data becomes visible."
            : "This account is not active. Contact a Super Admin to restore access."
        }
      >
        <Button variant="outline" onClick={() => void signOut()}>
          Sign out
        </Button>
      </Centered>
    );
  }

  return <>{children}</>;
}

function Centered({
  title,
  body,
  children,
}: {
  title: string;
  body: string;
  children: ReactNode;
}) {
  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <div className="panel-grid max-w-md rounded-md border border-border bg-card p-6 text-center">
        <div className="label-caps">CKD Assembly Control</div>
        <h1 className="mt-2 text-2xl font-semibold uppercase">{title}</h1>
        <p className="mt-3 text-sm text-muted-foreground">{body}</p>
        <div className="mt-5 flex justify-center">{children}</div>
      </div>
    </div>
  );
}

import { Link, useRouter } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { useAuth } from "@/hooks/useAuth";
import { CLUSTERS, COMPANY, ROLE_LABEL, type AppRole } from "@/lib/ckd";
import { Button } from "@/components/ui/button";
import {
  LayoutDashboard,
  Wrench,
  ClipboardList,
  Ship,
  UsersRound,
  ScrollText,
  BarChart3,
  Factory,
  Anchor,
  Receipt,
  Truck,
  Contact,
} from "lucide-react";

type NavItem = {
  to: string;
  label: string;
  icon: typeof Ship;
  search?: Record<string, string>;
  roles?: AppRole[];
};

type NavGroup = { heading: string; items: NavItem[] };

const NAV_GROUPS: NavGroup[] = [
  {
    heading: "Command",
    items: [
      { to: "/", label: "Control Dashboard", icon: LayoutDashboard },
      { to: "/reports", label: "Management Reports", icon: BarChart3 },
      { to: "/chassis", label: "Chassis Register", icon: Wrench },
    ],
  },
  {
    heading: "Ordering & Supply",
    items: [
      { to: "/purchase-orders", label: "Purchase Orders", icon: ClipboardList, roles: ["procurement"] },
      { to: "/shipments", label: "Bills of Lading", icon: Ship, roles: ["procurement", "clearing"] },
    ],
  },
  {
    heading: "Clearing & Production",
    items: [
      {
        to: "/chassis",
        label: "Port & Clearing Desk",
        icon: Anchor,
        search: { cluster: "inbound" },
        roles: ["clearing"],
      },
      {
        to: "/chassis",
        label: "Assembly Floor",
        icon: Factory,
        search: { cluster: "production" },
        roles: ["production"],
      },
    ],
  },
  {
    heading: "Commercial & Dispatch",
    items: [
      {
        to: "/customers",
        label: "Customer Master",
        icon: Contact,
        roles: ["sales", "accounts"],
      },
      {
        to: "/chassis",
        label: "Sales & Billing Desk",
        icon: Receipt,
        search: { cluster: "commercial" },
        roles: ["sales", "accounts"],
      },
      {
        to: "/chassis",
        label: "Dispatch & Gate Pass",
        icon: Truck,
        search: { cluster: "dispatch" },
        roles: ["store"],
      },
    ],
  },
  {
    heading: "Administration",
    items: [
      { to: "/admin", label: "Users & Access", icon: UsersRound, roles: ["super_admin"] },
      { to: "/audit", label: "Audit Trail", icon: ScrollText, roles: ["super_admin"] },
    ],
  },
];

const linkClass =
  "flex items-center gap-2.5 rounded-md px-3 py-2 font-mono text-[11px] tracking-wider whitespace-nowrap text-sidebar-foreground/65 uppercase transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground";

export function AppShell({
  title,
  subtitle,
  children,
  actions,
}: {
  title: string;
  subtitle?: string;
  children: ReactNode;
  actions?: ReactNode;
}) {
  const { profile, roles, signOut, can } = useAuth();
  const router = useRouter();
  const isSuper = roles.includes("super_admin");
  const isManagement = roles.includes("management");
  const myClusters = CLUSTERS.filter(
    (c) => isSuper || isManagement || c.roles.some((r) => roles.includes(r)),
  );


  return (
    <div className="min-h-screen bg-background lg:flex">
      <aside className="border-b border-sidebar-border bg-sidebar lg:h-screen lg:w-64 lg:shrink-0 lg:overflow-y-auto lg:border-b-0 lg:border-r">
        <div className="flex items-center gap-3 border-b border-sidebar-border px-4 py-4">
          <div className="grid size-9 shrink-0 place-items-center rounded-md bg-sidebar-primary/15 font-display text-sm font-bold text-sidebar-primary">
            VK
          </div>
          <div className="min-w-0">
            <div className="font-display text-[15px] leading-none font-semibold tracking-wide text-sidebar-foreground uppercase">
              VKJG
            </div>
            <div className="label-caps mt-1 truncate text-[10px]">
              {COMPANY.region}
            </div>
          </div>
        </div>

        <nav className="space-y-4 px-2 py-4">
          {NAV_GROUPS.map((group) => {
            const items = group.items.filter(
              (item) => !item.roles || item.roles.some((r) => can(r)),
            );

            if (items.length === 0) return null;
            return (
              <div key={group.heading}>
                <div className="label-caps px-3 pb-1.5 text-[10px] text-sidebar-foreground/40">
                  {group.heading}
                </div>
                <div className="flex flex-col gap-0.5">
                  {items.map((item) => (
                    <Link
                      key={`${group.heading}-${item.label}`}
                      to={item.to}
                      search={item.search ?? {}}
                      className={linkClass}
                      activeOptions={{ exact: item.to === "/", includeSearch: Boolean(item.search) }}
                      activeProps={{
                        className:
                          "bg-sidebar-accent text-sidebar-primary border-l-2 border-sidebar-primary",
                      }}
                    >
                      <item.icon className="size-3.5 shrink-0" />
                      {item.label}
                    </Link>
                  ))}
                </div>
              </div>
            );
          })}
        </nav>

        <div className="hidden border-t border-sidebar-border px-4 py-4 lg:block">
          <div className="label-caps">Signed in</div>
          <div className="mt-1 truncate text-sm text-sidebar-foreground">
            {profile?.full_name || profile?.email}
          </div>
          <div className="mt-2 flex flex-wrap gap-1">
            {roles.map((r) => (
              <span
                key={r}
                className="rounded-sm bg-sidebar-accent px-1.5 py-0.5 font-mono text-[10px] tracking-wider text-sidebar-primary uppercase"
              >
                {ROLE_LABEL[r]}
              </span>
            ))}
          </div>
          {myClusters.length > 0 ? (
            <div className="label-caps mt-3 text-[10px] leading-relaxed">
              Duty clusters: {myClusters.map((c) => c.short).join(" · ")}
            </div>
          ) : null}
          <Button
            variant="outline"
            size="sm"
            className="mt-3 w-full"
            onClick={async () => {
              await signOut();
              void router.navigate({ to: "/auth" });
            }}
          >
            Sign out
          </Button>
        </div>
      </aside>

      <main className="flex-1 lg:h-screen lg:overflow-y-auto">
        <header className="panel-grid surface-raised flex flex-wrap items-end justify-between gap-4 border-b border-border bg-card px-5 py-5">
          <div>
            <div className="label-caps">
              {COMPANY.name} — {COMPANY.region}
            </div>
            <h1 className="mt-1.5 text-2xl leading-none font-semibold uppercase">{title}</h1>
            {subtitle ? <p className="mt-2 text-sm text-muted-foreground">{subtitle}</p> : null}
          </div>
          <div className="flex items-center gap-2">{actions}</div>
        </header>
        <div className="px-5 py-6">{children}</div>
      </main>
    </div>
  );
}

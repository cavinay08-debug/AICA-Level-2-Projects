import { jsPDF } from "jspdf";

export type GatePassData = {
  gatePassNumber: string;
  engineNumber: string;
  chassisNumber: string | null;
  model: string | null;
  registrationNumber: string | null;
  customerName: string | null;
  invoiceNumber: string | null;
  receiverName: string;
  receiverIdProof: string;
  issuedBy: string;
  deliveryDate: string;
};

/** Builds the gate pass PDF and triggers a browser download. */
export function downloadGatePassPdf(d: GatePassData) {
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const pageWidth = doc.internal.pageSize.getWidth();
  const left = 56;
  const right = pageWidth - 56;

  doc.setFont("helvetica", "bold");
  doc.setFontSize(18);
  doc.text("CKD ASSEMBLY PLANT", left, 70);
  doc.setFontSize(13);
  doc.text("VEHICLE GATE PASS", left, 92);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.text(`Gate pass no.  ${d.gatePassNumber}`, right, 70, { align: "right" });
  doc.text(`Date  ${d.deliveryDate}`, right, 86, { align: "right" });

  doc.setLineWidth(1);
  doc.line(left, 106, right, 106);

  const rows: [string, string][] = [
    ["Engine number", d.engineNumber],
    ["Chassis number", d.chassisNumber ?? "Not assigned"],
    ["Model", d.model ?? "-"],
    ["Registration number", d.registrationNumber ?? "-"],
    ["Customer", d.customerName ?? "-"],
    ["Invoice number", d.invoiceNumber ?? "-"],
    ["Receiving representative", d.receiverName],
    ["ID proof verified", d.receiverIdProof],
    ["Issued by", d.issuedBy],
  ];

  let y = 136;
  rows.forEach(([label, value]) => {
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.setTextColor(110);
    doc.text(label.toUpperCase(), left, y);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.setTextColor(20);
    doc.text(String(value), left + 200, y);
    doc.setDrawColor(220);
    doc.setLineWidth(0.5);
    doc.line(left, y + 10, right, y + 10);
    y += 34;
  });

  doc.setTextColor(90);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  y += 16;
  doc.text(
    "This gate pass authorises the release of the vehicle described above from the plant premises.",
    left,
    y,
    { maxWidth: right - left },
  );

  y += 70;
  doc.setDrawColor(60);
  doc.line(left, y, left + 180, y);
  doc.line(right - 180, y, right, y);
  doc.setFontSize(8);
  doc.text("STORE MANAGER", left, y + 14);
  doc.text("RECEIVER SIGNATURE", right - 180, y + 14);

  doc.save(`${d.gatePassNumber}.pdf`);
}

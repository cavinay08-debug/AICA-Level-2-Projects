import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { ChassisRow } from "@/lib/ckd";

export type Bol = {
  id: string;
  bol_number: string;
  file_reference_number: string | null;
  supplier: string;
  shipment_date: string | null;
  notes: string | null;
  po_id: string | null;
  created_at: string;
};

export type PurchaseOrder = {
  id: string;
  po_number: string;
  supplier: string;
  model: string | null;
  quantity: number;
  order_date: string;
  notes: string | null;
  created_at: string;
};

export const purchaseOrdersQuery = queryOptions({
  queryKey: ["purchase_orders"],
  queryFn: async (): Promise<PurchaseOrder[]> => {
    const { data, error } = await supabase
      .from("purchase_orders")
      .select("*")
      .order("order_date", { ascending: false });
    if (error) throw error;
    return (data ?? []) as PurchaseOrder[];
  },
});


export type Customer = {
  id: string;
  name: string;
  contact_person: string | null;
  phone: string | null;
  email: string | null;
  id_proof: string | null;
  tin: string | null;
  vrn: string | null;
};

export type Invoice = {
  id: string;
  invoice_number: string;
  customer_id: string | null;
  invoice_date: string;
  payment_method: string | null;
  payment_confirmed: boolean;
};

export const chassisQuery = queryOptions({
  queryKey: ["chassis"],
  queryFn: async (): Promise<ChassisRow[]> => {
    const { data, error } = await supabase
      .from("chassis")
      .select(
        "id,chassis_number,engine_number,bol_id,model,status,customer_id,invoice_id,registration_number,registration_date,created_at,updated_at,delivered_at",
      )
      .order("chassis_number");
    if (error) throw error;
    return (data ?? []) as ChassisRow[];
  },
});

export const bolsQuery = queryOptions({
  queryKey: ["bols"],
  queryFn: async (): Promise<Bol[]> => {
    const { data, error } = await supabase
      .from("bols")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw error;
    return (data ?? []) as Bol[];
  },
});

export const customersQuery = queryOptions({
  queryKey: ["customers"],
  queryFn: async (): Promise<Customer[]> => {
    const { data, error } = await supabase.from("customers").select("*").order("name");
    if (error) throw error;
    return (data ?? []) as Customer[];
  },
});

export const invoicesQuery = queryOptions({
  queryKey: ["invoices"],
  queryFn: async (): Promise<Invoice[]> => {
    const { data, error } = await supabase
      .from("invoices")
      .select("*")
      .order("invoice_date", { ascending: false });
    if (error) throw error;
    return (data ?? []) as Invoice[];
  },
});

export const auditQuery = queryOptions({
  queryKey: ["audit"],
  queryFn: async () => {
    const { data, error } = await supabase
      .from("audit_log")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(30);
    if (error) throw error;
    return data ?? [];
  },
});

export const fullAuditQuery = queryOptions({
  queryKey: ["audit", "full"],
  queryFn: async () => {
    const { data, error } = await supabase
      .from("audit_log")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(1000);
    if (error) throw error;
    return data ?? [];
  },
});

export const usersQuery = queryOptions({
  queryKey: ["users"],
  queryFn: async () => {
    const [{ data: profiles, error: pe }, { data: roles, error: re }] = await Promise.all([
      supabase.from("profiles").select("*").order("created_at", { ascending: false }),
      supabase.from("user_roles").select("*"),
    ]);
    if (pe) throw pe;
    if (re) throw re;
    return { profiles: profiles ?? [], roles: roles ?? [] };
  },
});

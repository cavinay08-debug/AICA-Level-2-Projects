import * as XLSX from "xlsx";

/** Reads a CSV/XLS/XLSX file into a matrix of trimmed cell strings. */
async function readMatrix(file: File): Promise<string[][]> {
  const buffer = await file.arrayBuffer();
  const wb = XLSX.read(buffer, { type: "array" });
  const first = wb.SheetNames[0];
  if (!first) return [];
  const sheet = wb.Sheets[first];
  if (!sheet) return [];
  const rows = XLSX.utils.sheet_to_json<unknown[]>(sheet, { header: 1, blankrows: false });
  return rows.map((r) => (r ?? []).map((c) => (c == null ? "" : String(c).trim())));
}

const HEADERISH = /engine|chassis|serial|no\.?$|number/i;

/** Single-column import: one identifier per row (engine numbers). */
export async function parseNumberList(file: File): Promise<string[]> {
  const rows = await readMatrix(file);
  const out: string[] = [];
  rows.forEach((row, i) => {
    const value = row.find((c) => c.length > 0);
    if (!value) return;
    if (i === 0 && HEADERISH.test(value) && !/\d/.test(value)) return;
    out.push(value);
  });
  return Array.from(new Set(out));
}

export type EnginePair = { engine: string; chassis: string };

/** Two-column import: engine number, chassis number. */
export async function parseEnginePairs(file: File): Promise<EnginePair[]> {
  const rows = await readMatrix(file);
  const out: EnginePair[] = [];
  rows.forEach((row, i) => {
    const engine = (row[0] ?? "").trim();
    const chassis = (row[1] ?? "").trim();
    if (!engine || !chassis) return;
    if (i === 0 && HEADERISH.test(engine) && HEADERISH.test(chassis) && !/\d/.test(engine)) return;
    out.push({ engine, chassis });
  });
  return out;
}


import * as XLSX from "xlsx";

type Row = Record<string, string | number | null>;

/** Writes rows to an .xlsx workbook and triggers a browser download. */
export function downloadSheet(rows: Row[], filename: string, sheetName = "Sheet1") {
  const sheet = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, sheet, sheetName);
  XLSX.writeFile(wb, filename);
}

/** Blank/importable template for a bill-of-lading engine manifest. */
export function downloadBolTemplate(sample?: { model?: string }) {
  downloadSheet(
    [
      { "Engine Number": "ENG0001J", Model: sample?.model ?? "" },
      { "Engine Number": "ENG0002J", Model: sample?.model ?? "" },
      { "Engine Number": "", Model: "" },
    ],
    "bol-engine-manifest-template.xlsx",
    "Engine Manifest",
  );
}

/** Template for Clearing to map engine numbers to chassis numbers. */
export function downloadChassisAssignTemplate(
  engines: { engine_number: string; model: string | null }[],
) {
  const rows: Row[] = engines.length
    ? engines.map((e) => ({
        "Engine Number": e.engine_number,
        "Chassis Number": "",
        Model: e.model ?? "",
      }))
    : [
        { "Engine Number": "ENG0001J", "Chassis Number": "", Model: "" },
        { "Engine Number": "", "Chassis Number": "", Model: "" },
      ];
  downloadSheet(rows, "engine-chassis-assignment-template.xlsx", "Chassis Assignment");
}

/** Full export of the engine manifest registered on a bill of lading. */
export function downloadBolManifest(
  bolNumber: string,
  rows: { engine_number: string; chassis_number: string | null; model: string | null; status: string }[],
) {
  downloadSheet(
    rows.map((r) => ({
      "Engine Number": r.engine_number,
      "Chassis Number": r.chassis_number ?? "",
      Model: r.model ?? "",
      Status: r.status,
    })),
    `${bolNumber.replace(/[^\w.-]+/g, "_")}-manifest.xlsx`,
    "Manifest",
  );
}

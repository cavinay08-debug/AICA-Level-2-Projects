export const STATUS_ORDER = [
  "ordered",
  "shipped",
  "at_port",
  "at_plant",
  "produced",
  "allocated",
  "invoiced",
  "paid",
  "delivery_authorized",
  "delivered",
] as const;

export type ChassisStatus = (typeof STATUS_ORDER)[number];

export type AppRole =
  | "super_admin"
  | "management"
  | "procurement"
  | "clearing"
  | "production"
  | "sales"
  | "accounts"
  | "store";

export const STATUS_LABEL: Record<ChassisStatus, string> = {
  ordered: "Ordered (on BOL)",
  shipped: "CKD shipped by supplier",
  at_port: "At port",
  at_plant: "At plant (cleared)",
  produced: "Finished good produced",
  allocated: "Allocated to customer",
  invoiced: "Invoiced / billed",
  paid: "Payment confirmed",
  delivery_authorized: "Cargo delivery authorised",
  delivered: "Delivered (gate pass)",
};

export const ROLE_LABEL: Record<AppRole, string> = {
  super_admin: "Super Admin (IT)",
  management: "Management",
  procurement: "Procurement Manager",
  clearing: "Clearing Manager",
  production: "Production Manager",
  sales: "Sales Manager",
  accounts: "Accounts Department",
  store: "Store Manager",
};


export const rank = (s: ChassisStatus) => STATUS_ORDER.indexOf(s);

export type ChassisRow = {
  id: string;
  chassis_number: string | null;
  engine_number: string;
  bol_id: string;
  model: string | null;
  status: ChassisStatus;
  customer_id: string | null;
  invoice_id: string | null;
  registration_number: string | null;
  registration_date: string | null;
  created_at: string;
  updated_at: string;
  delivered_at: string | null;
};

export type MetricIcon =
  | "purchase"
  | "ship"
  | "pending-ship"
  | "port"
  | "plant"
  | "produced"
  | "billed"
  | "allocated"
  | "invoice"
  | "pending-bill"
  | "unallocated"
  | "unsold"
  | "undelivered"
  | "stock"
  | "delivered";

export type Metric = {
  key: string;
  index: number;
  label: string;
  value: number;
  hint: string;
  icon: MetricIcon;
  filter?: (c: ChassisRow) => boolean;
};

const at = (s: ChassisStatus) => (c: ChassisRow) => c.status === s;
const from = (s: ChassisStatus) => (c: ChassisRow) => rank(c.status) >= rank(s);
const between = (a: ChassisStatus, b: ChassisStatus) => (c: ChassisRow) =>
  rank(c.status) >= rank(a) && rank(c.status) <= rank(b);

type Def = Omit<Metric, "value" | "index">;

const DEFS: Def[] = [
  {
    key: "shipped",
    label: "CKD Shipped by Supplier",
    hint: "Engine numbers registered on a bill of lading",
    icon: "ship",
    filter: from("shipped"),
  },
  { key: "port", label: "CKD at Port", hint: "Awaiting customs clearance", icon: "port", filter: at("at_port") },
  { key: "plant", label: "CKD at Plant", hint: "Cleared, awaiting assembly", icon: "plant", filter: at("at_plant") },
  {
    key: "produced",
    label: "Finished Goods Produced",
    hint: "Assembly confirmed",
    icon: "produced",
    filter: from("produced"),
  },
  {
    key: "fg_billed",
    label: "Finished Goods Billed",
    hint: "Invoice number issued",
    icon: "billed",
    filter: from("invoiced"),
  },
  {
    key: "fg_allocated",
    label: "Finished Goods Allocated",
    hint: "Reserved for a customer",
    icon: "allocated",
    filter: from("allocated"),
  },
  {
    key: "qty_billed",
    label: "Total Qty Billed",
    hint: "Invoiced through Accounts",
    icon: "invoice",
    filter: from("invoiced"),
  },
  {
    key: "alloc_pending_bill",
    label: "Allocated, Bill Pending",
    hint: "Allocated with no invoice number yet",
    icon: "pending-bill",
    filter: at("allocated"),
  },
  {
    key: "unallocated",
    label: "Qty Unallocated",
    hint: "Produced, no customer assigned",
    icon: "unallocated",
    filter: at("produced"),
  },
  {
    key: "unsold",
    label: "Finished Goods Unsold",
    hint: "At plant with no buyer",
    icon: "unsold",
    filter: at("produced"),
  },
  {
    key: "sold_undelivered",
    label: "Sold, Not Delivered",
    hint: "Billed but gate pass not issued",
    icon: "undelivered",
    filter: between("invoiced", "delivery_authorized"),
  },
  {
    key: "fg_at_plant",
    label: "Total Finished Goods at Plant",
    hint: "Unsold + allocated pending bill + billed pending delivery",
    icon: "stock",
    filter: between("produced", "delivery_authorized"),
  },
  {
    key: "delivered",
    label: "Total Delivered from Plant",
    hint: "Gate pass issued and unit handed over",
    icon: "delivered",
    filter: at("delivered"),
  },
];

export function computeMetrics(rows: ChassisRow[], orderedQty = rows.length): Metric[] {
  const shipped = rows.length;
  const head: Def[] = [
    {
      key: "ordered",
      label: "CKD Qty Ordered",
      hint: "Total quantity on all purchase orders",
      icon: "purchase",
    },
    {
      key: "yet_to_ship",
      label: "CKD Qty Yet to be Shipped",
      hint: "Ordered quantity with no bill of lading yet",
      icon: "pending-ship",
    },
  ];
  const values: Record<string, number> = {
    ordered: orderedQty,
    yet_to_ship: Math.max(orderedQty - shipped, 0),
  };
  return [...head, ...DEFS].map((d, i) => ({
    ...d,
    index: i + 1,
    value: d.filter ? rows.filter(d.filter).length : (values[d.key] ?? 0),
  }));
}


export const FUNNEL: { status: ChassisStatus; short: string }[] = [
  { status: "ordered", short: "Ordered" },
  { status: "shipped", short: "Shipped" },
  { status: "at_port", short: "Port" },
  { status: "at_plant", short: "Plant" },
  { status: "produced", short: "Produced" },
  { status: "allocated", short: "Allocated" },
  { status: "invoiced", short: "Billed" },
  { status: "delivered", short: "Delivered" },
];

/** The action each department can take next, per chassis status. */
export const NEXT_ACTION: Partial<
  Record<ChassisStatus, { role: AppRole; next: ChassisStatus; verb: string }>
> = {
  ordered: { role: "procurement", next: "shipped", verb: "Mark shipped by supplier" },
  shipped: { role: "clearing", next: "at_port", verb: "Mark arrived at port" },
  at_port: { role: "clearing", next: "at_plant", verb: "Assign chassis no. & clear" },
  at_plant: { role: "production", next: "produced", verb: "Confirm production complete" },
  produced: { role: "sales", next: "allocated", verb: "Allocate to customer" },
  allocated: { role: "accounts", next: "invoiced", verb: "Issue invoice" },
  invoiced: { role: "accounts", next: "paid", verb: "Confirm payment received" },
  paid: { role: "sales", next: "delivery_authorized", verb: "Authorise cargo delivery" },
  delivery_authorized: { role: "store", next: "delivered", verb: "Issue gate pass" },
};

export const TIMESTAMP_FIELD: Record<ChassisStatus, string | null> = {
  ordered: null,
  shipped: "shipped_at",
  
  at_port: "at_port_at",
  at_plant: "at_plant_at",
  produced: "produced_at",
  allocated: "allocated_at",
  invoiced: "invoiced_at",
  paid: "paid_at",
  delivery_authorized: "delivery_authorized_at",
  delivered: "delivered_at",
};

/** The workflow duties each role unlocks — a user may hold many roles. */
export const ROLE_DUTIES: Record<AppRole, string[]> = {
  super_admin: [
    "IT administration: approve users and assign department roles",
    "Full access to every workflow",
  ],
  management: [
    "Full visibility and action rights across every department workflow",
    "No user management or role assignment (IT function stays separate)",
  ],

  procurement: [
    "Raise purchase orders (CKD qty ordered)",
    "Create bills of lading and engine-number manifests",
  ],
  clearing: [
    "Add the clearing-house file reference number",
    "Assign chassis numbers to engine numbers, clear port to plant",
  ],
  production: ["Confirm assembly and finished-goods production"],
  sales: [
    "Allocate finished goods to customers",
    "Authorise cargo delivery after payment",
  ],
  accounts: ["Issue invoices", "Confirm payment received"],
  store: ["Issue gate passes and generate the gate pass PDF"],
};

/* ---------------------------------------------------------------
 * Activity clusters — how the plant floor is actually organised.
 * Each cluster groups lifecycle stages, dashboard metrics and the
 * departments that own the work, so managers read one block at a time.
 * ------------------------------------------------------------- */

export type ClusterKey = "ordering" | "inbound" | "production" | "commercial" | "dispatch";

export type Cluster = {
  key: ClusterKey;
  label: string;
  short: string;
  blurb: string;
  roles: AppRole[];
  statuses: ChassisStatus[];
  metrics: string[];
};

export const CLUSTERS: Cluster[] = [
  {
    key: "ordering",
    label: "Ordering & Supply",
    short: "Ordering",
    blurb: "Purchase orders raised and CKD kits despatched by the supplier",
    roles: ["procurement"],
    statuses: ["ordered", "shipped"],
    metrics: ["ordered", "yet_to_ship", "shipped"],
  },
  {
    key: "inbound",
    label: "Clearing & Inbound Logistics",
    short: "Clearing",
    blurb: "Port arrival, file references, chassis numbering and release to plant",
    roles: ["clearing"],
    statuses: ["at_port", "at_plant"],
    metrics: ["port", "plant"],
  },
  {
    key: "production",
    label: "Assembly & Production",
    short: "Production",
    blurb: "Kits assembled into finished vehicles held at the plant",
    roles: ["production"],
    statuses: ["produced"],
    metrics: ["produced", "fg_at_plant", "unsold"],
  },
  {
    key: "commercial",
    label: "Sales, Allocation & Billing",
    short: "Commercial",
    blurb: "Customer allocation, invoicing and payment confirmation",
    roles: ["sales", "accounts"],
    statuses: ["allocated", "invoiced", "paid"],
    metrics: ["fg_allocated", "unallocated", "alloc_pending_bill", "fg_billed", "qty_billed"],
  },
  {
    key: "dispatch",
    label: "Dispatch & Delivery",
    short: "Dispatch",
    blurb: "Delivery authorisation, gate passes and vehicles handed to customers",
    roles: ["store"],
    statuses: ["delivery_authorized", "delivered"],
    metrics: ["sold_undelivered", "delivered"],
  },
];

export const CLUSTER_OF_STATUS: Record<ChassisStatus, ClusterKey> = STATUS_ORDER.reduce(
  (acc, s) => {
    acc[s] = CLUSTERS.find((c) => c.statuses.includes(s))?.key ?? "ordering";
    return acc;
  },
  {} as Record<ChassisStatus, ClusterKey>,
);

export const COMPANY = {
  name: "VKJG Vehicle Assembly Plant",
  region: "Tanzania",
  system: "CKD Inventory & Coordination System",
};

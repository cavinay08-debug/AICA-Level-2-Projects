import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { Guard } from "@/components/Guard";
import { useAuth } from "@/hooks/useAuth";
import { bolsQuery, chassisQuery, purchaseOrdersQuery, type Bol } from "@/lib/queries";
import { rank } from "@/lib/ckd";
import { parseNumberList } from "@/lib/sheet-import";
import { downloadBolManifest, downloadBolTemplate } from "@/lib/sheet-export";
import type { ChassisRow } from "@/lib/ckd";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "sonner";

export const Route = createFileRoute("/shipments")({
  head: () => ({
    meta: [
      { title: "Bills of Lading — CKD Assembly Control" },
      {
        name: "description",
        content:
          "Register CKD bills of lading with the engine-number manifest, import engine numbers from Excel or CSV, and let Clearing add the file reference number.",
      },
      { property: "og:title", content: "Bills of Lading — CKD Assembly Control" },
      {
        property: "og:description",
        content: "CKD shipment manifests: supplier, engine numbers and clearing file reference.",
      },
    ],
  }),
  component: () => (
    <Guard>
      <ShipmentsPage />
    </Guard>
  ),
});

function ShipmentsPage() {
  const { can, user } = useAuth();
  const qc = useQueryClient();
  const { data: bols = [] } = useQuery(bolsQuery);
  const { data: chassis = [] } = useQuery(chassisQuery);
  const { data: orders = [] } = useQuery(purchaseOrdersQuery);
  const [open, setOpen] = useState(false);
  const [refTarget, setRefTarget] = useState<Bol | null>(null);
  const [editTarget, setEditTarget] = useState<Bol | null>(null);

  const invalidate = () => {
    void qc.invalidateQueries({ queryKey: ["bols"] });
    void qc.invalidateQueries({ queryKey: ["chassis"] });
  };

  return (
    <AppShell
      title="Bills of Lading"
      subtitle="Procurement registers the engine-number manifest; Clearing adds the clearing-house file reference number"
      actions={
        <div className="flex items-center gap-2">
          <Button size="sm" variant="outline" onClick={() => downloadBolTemplate()}>
            Excel template
          </Button>
          {can("procurement") ? (
            <Button size="sm" onClick={() => setOpen(true)}>
              New bill of lading
            </Button>
          ) : null}
        </div>
      }
    >
      <div className="grid gap-4 md:grid-cols-2">
        {bols.map((b) => {
          const kits = chassis.filter((c) => c.bol_id === b.id);
          const atPlant = kits.filter((c) => rank(c.status) >= 4).length;
          const numbered = kits.filter((c) => c.chassis_number).length;
          const movedOn = kits.filter((c) => rank(c.status) >= rank("at_port")).length;
          const editable = movedOn === 0;
          return (
            <div key={b.id} className="panel-grid rounded-md border border-border bg-card p-5">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="font-mono text-sm text-primary">{b.bol_number}</div>
                  <div className="mt-1 text-lg font-semibold uppercase">{b.supplier}</div>
                </div>
                <div className="text-right">
                  <div className="label-caps">Engines</div>
                  <div className="font-mono text-2xl tabular-nums">{kits.length}</div>
                </div>
              </div>
              <dl className="mt-4 grid grid-cols-2 gap-3 text-xs">
                <Row
                  label="Purchase order"
                  value={orders.find((o) => o.id === b.po_id)?.po_number ?? "—"}
                  mono
                />
                <Row label="File reference" value={b.file_reference_number ?? "Pending clearing"} mono />
                <Row label="Shipment date" value={b.shipment_date ?? "—"} />
                <Row label="Chassis nos. assigned" value={`${numbered} / ${kits.length}`} mono />
                <Row label="Cleared to plant" value={`${atPlant} / ${kits.length}`} mono />
                <Row
                  label="Amendable"
                  value={editable ? "Yes — before port arrival" : "Locked (arrived at port)"}
                />
              </dl>

              <div className="mt-4 flex flex-wrap gap-2">
                {can("clearing") ? (
                  <Button
                    size="sm"
                    variant={b.file_reference_number ? "outline" : "default"}
                    onClick={() => setRefTarget(b)}
                  >
                    {b.file_reference_number ? "Edit file reference" : "Add file reference"}
                  </Button>
                ) : null}
                {can("procurement") ? (
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={!editable}
                    onClick={() => setEditTarget(b)}
                  >
                    {editable ? "Modify BOL" : "Locked after port"}
                  </Button>
                ) : null}
                <Button
                  size="sm"
                  variant="ghost"
                  disabled={kits.length === 0}
                  onClick={() => downloadBolManifest(b.bol_number, kits)}
                >
                  Export manifest
                </Button>
              </div>
            </div>
          );
        })}
        {bols.length === 0 ? (
          <p className="text-sm text-muted-foreground">No bills of lading recorded yet.</p>
        ) : null}
      </div>

      {open ? (
        <NewBolDialog
          userId={user?.id ?? null}
          onClose={() => setOpen(false)}
          onDone={() => {
            setOpen(false);
            invalidate();
          }}
        />
      ) : null}

      {editTarget ? (
        <EditBolDialog
          bol={editTarget}
          kits={chassis.filter((c) => c.bol_id === editTarget.id)}
          onClose={() => setEditTarget(null)}
          onDone={() => {
            setEditTarget(null);
            invalidate();
          }}
        />
      ) : null}

      {refTarget ? (
        <FileRefDialog
          bol={refTarget}
          onClose={() => setRefTarget(null)}
          onDone={() => {
            setRefTarget(null);
            void qc.invalidateQueries({ queryKey: ["bols"] });
          }}
        />
      ) : null}
    </AppShell>
  );
}


function Row({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div>
      <dt className="label-caps">{label}</dt>
      <dd className={`mt-1 ${mono ? "font-mono" : ""}`}>{value}</dd>
    </div>
  );
}

function FileRefDialog({
  bol,
  onClose,
  onDone,
}: {
  bol: Bol;
  onClose: () => void;
  onDone: () => void;
}) {
  const [value, setValue] = useState(bol.file_reference_number ?? "");
  const [busy, setBusy] = useState(false);

  const save = async () => {
    setBusy(true);
    try {
      const ref = value.trim();
      if (!ref) throw new Error("Enter the clearing-house file reference number.");
      const { error } = await supabase
        .from("bols")
        .update({ file_reference_number: ref })
        .eq("id", bol.id);
      if (error) throw error;
      toast.success(`File reference ${ref} saved to ${bol.bol_number}`);
      onDone();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not save the file reference");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open onOpenChange={(o) => (o ? null : onClose())}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="uppercase">Clearing file reference</DialogTitle>
          <DialogDescription>
            Clearing issues the file reference number for {bol.bol_number} once the bill of lading is
            received.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-2">
          <Label htmlFor="fileref">File reference number</Label>
          <Input id="fileref" value={value} onChange={(e) => setValue(e.target.value)} />
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={save} disabled={busy}>
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function NewBolDialog({
  userId,
  onClose,
  onDone,
}: {
  userId: string | null;
  onClose: () => void;
  onDone: () => void;
}) {
  const { data: orders = [] } = useQuery(purchaseOrdersQuery);
  const [poId, setPoId] = useState("");
  const [bolNumber, setBolNumber] = useState("");
  const [supplier, setSupplier] = useState("");
  const [shipmentDate, setShipmentDate] = useState("");
  const [model, setModel] = useState("");
  const [manifest, setManifest] = useState("");
  const [busy, setBusy] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);

  const onFile = async (file: File | undefined) => {
    if (!file) return;
    try {
      const numbers = await parseNumberList(file);
      if (!numbers.length) throw new Error("No engine numbers found in that file.");
      setManifest((prev) => [prev.trim(), numbers.join("\n")].filter(Boolean).join("\n"));
      toast.success(`${numbers.length} engine numbers imported from ${file.name}`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not read that file");
    } finally {
      if (fileInput.current) fileInput.current.value = "";
    }
  };

  const save = async () => {
    setBusy(true);
    try {
      const numbers = Array.from(
        new Set(
          manifest
            .split(/[\s,;]+/)
            .map((s) => s.trim())
            .filter(Boolean),
        ),
      );
      if (!numbers.length) throw new Error("Add at least one engine number to the manifest.");

      const { data: bol, error } = await supabase
        .from("bols")
        .insert({
          bol_number: bolNumber.trim(),
          supplier: supplier.trim(),
          shipment_date: shipmentDate || null,
          po_id: poId || null,
          created_by: userId,
        })
        .select()
        .single();
      if (error) throw error;

      const { error: ce } = await supabase.from("chassis").insert(
        numbers.map((n) => ({
          engine_number: n,
          bol_id: bol.id,
          model: model.trim() || null,
          status: "shipped" as const,
          shipped_at: new Date().toISOString(),
        })),
      );
      if (ce) throw ce;

      toast.success(`${bolNumber} created — ${numbers.length} engines shipped by supplier`);
      onDone();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not create the bill of lading");
    } finally {
      setBusy(false);
    }
  };


  return (
    <Dialog open onOpenChange={(o) => (o ? null : onClose())}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="uppercase">New bill of lading</DialogTitle>
          <DialogDescription>
            Engine numbers registered here are counted as CKD shipped by supplier. Clearing adds the file
            reference number and assigns chassis numbers later.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2 sm:col-span-2">
            <Label htmlFor="po">Against purchase order</Label>
            <select
              id="po"
              value={poId}
              onChange={(e) => {
                setPoId(e.target.value);
                const po = orders.find((o) => o.id === e.target.value);
                if (po) {
                  setSupplier((s) => s || po.supplier);
                  setModel((m) => m || (po.model ?? ""));
                }
              }}
              className="h-9 w-full rounded-md border border-input bg-transparent px-3 text-sm"
            >
              <option value="">No purchase order</option>
              {orders.map((o) => (
                <option key={o.id} value={o.id}>
                  {o.po_number} — {o.supplier} ({o.quantity} units)
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="bol">BOL number</Label>
            <Input id="bol" value={bolNumber} onChange={(e) => setBolNumber(e.target.value)} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="sup">Supplier</Label>
            <Input id="sup" value={supplier} onChange={(e) => setSupplier(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="date">Shipment date</Label>
            <Input
              id="date"
              type="date"
              value={shipmentDate}
              onChange={(e) => setShipmentDate(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="model">Model</Label>
            <Input id="model" value={model} onChange={(e) => setModel(e.target.value)} />
          </div>
          <div className="space-y-2 sm:col-span-2">
            <div className="flex items-end justify-between gap-3">
              <Label htmlFor="man">Engine number manifest</Label>
              <div className="flex items-center gap-2">
                <Button
                  type="button"
                  size="sm"
                  variant="ghost"
                  onClick={() => downloadBolTemplate({ model })}
                >
                  Download template
                </Button>
                <input

                  ref={fileInput}
                  type="file"
                  accept=".csv,.xls,.xlsx"
                  className="hidden"
                  onChange={(e) => void onFile(e.target.files?.[0])}
                />
                <Button type="button" size="sm" variant="outline" onClick={() => fileInput.current?.click()}>
                  Import Excel / CSV
                </Button>
              </div>
            </div>
            <Textarea
              id="man"
              rows={5}
              value={manifest}
              onChange={(e) => setManifest(e.target.value)}
              placeholder="ENG0101J, ENG0102J, ENG0103J"
            />
            <p className="text-xs text-muted-foreground">
              One engine number per row in the first column of the spreadsheet, or paste them separated by
              commas or new lines.
            </p>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={save} disabled={busy}>
            Create BOL
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function EditBolDialog({
  bol,
  kits,
  onClose,
  onDone,
}: {
  bol: Bol;
  kits: ChassisRow[];
  onClose: () => void;
  onDone: () => void;
}) {
  const { data: orders = [] } = useQuery(purchaseOrdersQuery);
  const [poId, setPoId] = useState(bol.po_id ?? "");
  const [bolNumber, setBolNumber] = useState(bol.bol_number);
  const [supplier, setSupplier] = useState(bol.supplier);
  const [shipmentDate, setShipmentDate] = useState(bol.shipment_date ?? "");
  const [extra, setExtra] = useState("");
  const [removed, setRemoved] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);

  const onFile = async (file: File | undefined) => {
    if (!file) return;
    try {
      const numbers = await parseNumberList(file);
      if (!numbers.length) throw new Error("No engine numbers found in that file.");
      setExtra((prev) => [prev.trim(), numbers.join("\n")].filter(Boolean).join("\n"));
      toast.success(`${numbers.length} engine numbers imported from ${file.name}`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not read that file");
    } finally {
      if (fileInput.current) fileInput.current.value = "";
    }
  };

  const save = async () => {
    setBusy(true);
    try {
      const { error } = await supabase
        .from("bols")
        .update({
          bol_number: bolNumber.trim(),
          supplier: supplier.trim(),
          shipment_date: shipmentDate || null,
          po_id: poId || null,
        })
        .eq("id", bol.id);
      if (error) throw error;

      if (removed.length) {
        const { error: de } = await supabase.from("chassis").delete().in("id", removed);
        if (de) throw de;
      }

      const existing = new Set(kits.map((k) => k.engine_number));
      const added = Array.from(
        new Set(
          extra
            .split(/[\s,;]+/)
            .map((s) => s.trim())
            .filter((s) => s && !existing.has(s)),
        ),
      );
      if (added.length) {
        const { error: ie } = await supabase.from("chassis").insert(
          added.map((n) => ({
            engine_number: n,
            bol_id: bol.id,
            model: kits[0]?.model ?? null,
            status: "shipped" as const,
            shipped_at: new Date().toISOString(),
          })),
        );
        if (ie) throw ie;
      }

      toast.success(`${bolNumber} updated`);
      onDone();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not modify the bill of lading");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open onOpenChange={(o) => (o ? null : onClose())}>
      <DialogContent className="max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="uppercase">Modify bill of lading</DialogTitle>
          <DialogDescription>
            A bill of lading can be amended until the first engine on it is marked as arrived at port.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2 sm:col-span-2">
            <Label htmlFor="epo">Against purchase order</Label>
            <select
              id="epo"
              value={poId}
              onChange={(e) => setPoId(e.target.value)}
              className="h-9 w-full rounded-md border border-input bg-transparent px-3 text-sm"
            >
              <option value="">No purchase order</option>
              {orders.map((o) => (
                <option key={o.id} value={o.id}>
                  {o.po_number} — {o.supplier} ({o.quantity} units)
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="ebol">BOL number</Label>
            <Input id="ebol" value={bolNumber} onChange={(e) => setBolNumber(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="esup">Supplier</Label>
            <Input id="esup" value={supplier} onChange={(e) => setSupplier(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="edate">Shipment date</Label>
            <Input
              id="edate"
              type="date"
              value={shipmentDate}
              onChange={(e) => setShipmentDate(e.target.value)}
            />
          </div>
          <div className="space-y-2 sm:col-span-2">
            <div className="flex items-end justify-between gap-3">
              <Label htmlFor="eman">Add engine numbers</Label>
              <div className="flex items-center gap-2">
                <Button type="button" size="sm" variant="ghost" onClick={() => downloadBolTemplate()}>
                  Template
                </Button>
                <input
                  ref={fileInput}
                  type="file"
                  accept=".csv,.xls,.xlsx"
                  className="hidden"
                  onChange={(e) => void onFile(e.target.files?.[0])}
                />
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  onClick={() => fileInput.current?.click()}
                >
                  Import Excel / CSV
                </Button>
              </div>
            </div>
            <Textarea
              id="eman"
              rows={3}
              value={extra}
              onChange={(e) => setExtra(e.target.value)}
              placeholder="ENG0104J, ENG0105J"
            />
          </div>
          <div className="space-y-2 sm:col-span-2">
            <Label>Registered engines ({kits.length})</Label>
            <ul className="max-h-48 overflow-y-auto rounded-md border border-border p-2 font-mono text-xs">
              {kits.map((k) => {
                const gone = removed.includes(k.id);
                return (
                  <li key={k.id} className="flex items-center justify-between gap-3 py-0.5">
                    <span className={gone ? "line-through opacity-50" : ""}>{k.engine_number}</span>
                    <button
                      type="button"
                      className="label-caps text-destructive"
                      onClick={() =>
                        setRemoved((r) => (gone ? r.filter((id) => id !== k.id) : [...r, k.id]))
                      }
                    >
                      {gone ? "Undo" : "Remove"}
                    </button>
                  </li>
                );
              })}
              {kits.length === 0 ? <li className="text-muted-foreground">None yet</li> : null}
            </ul>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={save} disabled={busy}>
            Save changes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { Guard } from "@/components/Guard";
import { useAuth } from "@/hooks/useAuth";
import { chassisQuery, customersQuery, type Customer } from "@/lib/queries";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "sonner";

export const Route = createFileRoute("/customers")({
  head: () => ({
    meta: [
      { title: "Customer Master — VKJG Assembly Control" },
      {
        name: "description",
        content:
          "Maintain the VKJG customer master: TIN, VAT registration number, contact person, mobile number and e-mail, with full edit history of allocated units.",
      },
      { property: "og:title", content: "Customer Master — VKJG Assembly Control" },
      {
        property: "og:description",
        content: "Create and modify customer masters used for vehicle allocation and invoicing.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <Guard>
      <CustomersPage />
    </Guard>
  ),
});

type FormState = {
  name: string;
  tin: string;
  vrn: string;
  contact_person: string;
  phone: string;
  email: string;
};

const emptyForm: FormState = {
  name: "",
  tin: "",
  vrn: "",
  contact_person: "",
  phone: "",
  email: "",
};

function CustomersPage() {
  const { can } = useAuth();
  const qc = useQueryClient();
  const { data: customers = [] } = useQuery(customersQuery);
  const { data: chassis = [] } = useQuery(chassisQuery);
  const [target, setTarget] = useState<Customer | "new" | null>(null);
  const [search, setSearch] = useState("");

  const editable = can("sales");
  const term = search.trim().toLowerCase();
  const rows = term
    ? customers.filter((c) =>
        [c.name, c.tin, c.vrn, c.contact_person, c.phone, c.email]
          .filter(Boolean)
          .some((v) => String(v).toLowerCase().includes(term)),
      )
    : customers;

  return (
    <AppShell
      title="Customer Master"
      subtitle="Sales maintains customer records — TIN is mandatory, VRN and e-mail are optional. Existing details can be modified at any time."
      actions={
        editable ? (
          <Button size="sm" onClick={() => setTarget("new")}>
            New customer
          </Button>
        ) : null
      }
    >
      <div className="mb-4 max-w-sm">
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by name, TIN, VRN, contact or phone"
        />
      </div>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {rows.map((c) => {
          const units = chassis.filter((k) => k.customer_id === c.id);
          return (
            <div key={c.id} className="surface-raised rounded-lg border border-border p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="text-sm font-semibold uppercase tracking-wide">{c.name}</h3>
                  <p className="font-mono text-[11px] text-muted-foreground">
                    TIN {c.tin ?? "—"}
                    {c.vrn ? ` · VRN ${c.vrn}` : ""}
                  </p>
                </div>
                {editable ? (
                  <Button size="sm" variant="outline" onClick={() => setTarget(c)}>
                    Modify
                  </Button>
                ) : null}
              </div>
              <dl className="mt-3 space-y-1 text-xs text-muted-foreground">
                <div>Contact: {c.contact_person || "—"}</div>
                <div>Mobile: {c.phone || "—"}</div>
                <div>E-mail: {c.email || "—"}</div>
                <div>Units allocated: {units.length}</div>
              </dl>
            </div>
          );
        })}
        {rows.length === 0 ? (
          <p className="text-sm text-muted-foreground">No customer records match this search.</p>
        ) : null}
      </div>

      {target ? (
        <CustomerDialog
          customer={target === "new" ? null : target}
          onClose={() => setTarget(null)}
          onDone={() => {
            setTarget(null);
            void qc.invalidateQueries({ queryKey: ["customers"] });
          }}
        />
      ) : null}
    </AppShell>
  );
}

function CustomerDialog({
  customer,
  onClose,
  onDone,
}: {
  customer: Customer | null;
  onClose: () => void;
  onDone: () => void;
}) {
  const [form, setForm] = useState<FormState>(
    customer
      ? {
          name: customer.name ?? "",
          tin: customer.tin ?? "",
          vrn: customer.vrn ?? "",
          contact_person: customer.contact_person ?? "",
          phone: customer.phone ?? "",
          email: customer.email ?? "",
        }
      : emptyForm,
  );
  const [busy, setBusy] = useState(false);

  const save = async () => {
    setBusy(true);
    try {
      const name = form.name.trim();
      const tin = form.tin.trim();
      const contact = form.contact_person.trim();
      const phone = form.phone.trim();
      if (!name) throw new Error("Enter the customer name.");
      if (!tin) throw new Error("A Tax Identification Number (TIN) is required.");
      if (!contact) throw new Error("Enter the contact person name.");
      if (!phone) throw new Error("Enter the customer mobile number.");

      const payload = {
        name,
        tin,
        vrn: form.vrn.trim() || null,
        contact_person: contact,
        phone,
        email: form.email.trim() || null,
      };

      if (customer) {
        const { error } = await supabase.from("customers").update(payload).eq("id", customer.id);
        if (error) throw error;
        toast.success(`${name} updated`);
      } else {
        const { error } = await supabase.from("customers").insert(payload);
        if (error) throw error;
        toast.success(`${name} added to the customer master`);
      }
      onDone();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not save the customer");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open onOpenChange={(o) => (o ? null : onClose())}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="uppercase">
            {customer ? "Modify customer" : "New customer master"}
          </DialogTitle>
          <DialogDescription>
            TIN, contact person and mobile number are mandatory. VRN and e-mail are optional.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <Field label="Customer name">
            <Input
              value={form.name}
              onChange={(e) => setForm((s) => ({ ...s, name: e.target.value }))}
            />
          </Field>
          <Field label="Tax Identification Number (TIN)">
            <Input
              value={form.tin}
              onChange={(e) => setForm((s) => ({ ...s, tin: e.target.value }))}
            />
          </Field>
          <Field label="VAT Registration Number (VRN) — optional">
            <Input
              value={form.vrn}
              onChange={(e) => setForm((s) => ({ ...s, vrn: e.target.value }))}
            />
          </Field>
          <Field label="Contact person name">
            <Input
              value={form.contact_person}
              onChange={(e) => setForm((s) => ({ ...s, contact_person: e.target.value }))}
            />
          </Field>
          <Field label="Customer mobile number">
            <Input
              value={form.phone}
              onChange={(e) => setForm((s) => ({ ...s, phone: e.target.value }))}
            />
          </Field>
          <Field label="Customer e-mail (optional)">
            <Input
              type="email"
              value={form.email}
              onChange={(e) => setForm((s) => ({ ...s, email: e.target.value }))}
            />
          </Field>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={save} disabled={busy}>
            {customer ? "Save changes" : "Create customer"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">
        {label}
      </Label>
      {children}
    </div>
  );
}

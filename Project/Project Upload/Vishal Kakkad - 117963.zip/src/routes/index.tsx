import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { Guard } from "@/components/Guard";
import { MetricIcon } from "@/components/MetricIcon";
import { ClusterAnimation } from "@/components/ClusterAnimation";
import { useAuth } from "@/hooks/useAuth";
import { chassisQuery, purchaseOrdersQuery } from "@/lib/queries";
import {
  CLUSTERS,
  COMPANY,
  computeMetrics,
  FUNNEL,
  NEXT_ACTION,
  rank,
  type Metric,
} from "@/lib/ckd";
import { Button } from "@/components/ui/button";


export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Control Dashboard — VKJG Vehicle Assembly Plant" },
      {
        name: "description",
        content:
          "Live chassis-level visibility across CKD ordering, transit, clearing, production, allocation, billing and delivery for a vehicle assembly plant.",
      },
      { property: "og:title", content: "Control Dashboard — VKJG Vehicle Assembly Plant" },
      {
        property: "og:description",
        content:
          "Fourteen live pipeline metrics derived from chassis-level transactions, auditable to a single chassis number.",
      },
    ],
  }),
  component: () => (
    <Guard>
      <Dashboard />
    </Guard>
  ),
});

function Dashboard() {
  const { profile, roles } = useAuth();
  const { data: rows = [], refetch } = useQuery(chassisQuery);
  const { data: orders = [] } = useQuery(purchaseOrdersQuery);
  const orderedQty = orders.reduce((sum, o) => sum + o.quantity, 0);
  const metrics = computeMetrics(rows, orders.length ? orderedQty : rows.length);


  useEffect(() => {
    const channel = supabase
      .channel("chassis-dashboard")
      .on("postgres_changes", { event: "*", schema: "public", table: "chassis" }, () => {
        void refetch();
      })
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [refetch]);

  const myQueue = rows.filter((c) => {
    const action = NEXT_ACTION[c.status];
    if (!action) return false;
    return roles.includes("super_admin") || roles.includes(action.role);
  });

  const maxFunnel = Math.max(...FUNNEL.map((f) => rows.filter((c) => rank(c.status) >= rank(f.status)).length), 1);

  return (
    <AppShell
      title="Control Dashboard"
      subtitle={`${COMPANY.name} — ${COMPANY.region} · live pipeline for ${rows.length} chassis records · every figure drills back to a chassis number`}
      actions={
        <Button asChild variant="outline" size="sm">
          <Link to="/chassis">Open chassis register</Link>
        </Button>
      }
    >
      <div className="space-y-6">
        {CLUSTERS.map((cl) => {
          const cards = cl.metrics
            .map((k) => metrics.find((m) => m.key === k))
            .filter((m): m is Metric => Boolean(m));
          const inStage = rows.filter((c) => cl.statuses.includes(c.status)).length;
          const mine = roles.includes("super_admin") || cl.roles.some((r) => roles.includes(r));
          return (
            <section key={cl.key}>
              <div className="mb-3 flex flex-wrap items-end justify-between gap-2 border-b border-border pb-2">
                <div>
                  <h2 className="font-display text-base font-semibold tracking-wide uppercase">
                    {cl.label}
                    {mine ? (
                      <span className="ml-2 rounded-sm bg-primary/15 px-1.5 py-0.5 font-mono text-[10px] tracking-wider text-primary">
                        YOUR DESK
                      </span>
                    ) : null}
                  </h2>
                  <p className="text-xs text-muted-foreground">{cl.blurb}</p>
                </div>
                <div className="flex items-center gap-3">
                  <ClusterAnimation cluster={cl.key} />
                  <Link
                    to="/chassis"
                    search={{ cluster: cl.key }}
                    className="label-caps hover:text-primary"
                  >
                    {inStage} units in stage →
                  </Link>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
                {cards.map((m) =>
                  m.filter ? (
                    <Link
                      key={m.key}
                      to="/chassis"
                      search={{ metric: m.key }}
                      className="group surface-raised panel-grid rounded-md border border-border bg-card p-4 transition-colors hover:border-primary"
                    >
                      <MetricCardBody metric={m} />
                    </Link>
                  ) : (
                    <div
                      key={m.key}
                      className="surface-raised panel-grid rounded-md border border-border bg-card p-4"
                    >
                      <MetricCardBody metric={m} />
                    </div>
                  ),
                )}
              </div>
            </section>
          );
        })}
      </div>

      <section className="mt-6 grid gap-4 lg:grid-cols-3">
        <div className="rounded-md border border-border bg-card p-5 lg:col-span-2">
          <h2 className="text-lg font-semibold uppercase">Pipeline flow</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Cumulative quantity that has reached each lifecycle stage.
          </p>
          <div className="mt-5 space-y-2">
            {FUNNEL.map((f) => {
              const count = rows.filter((c) => rank(c.status) >= rank(f.status)).length;
              return (
                <div key={f.status} className="flex items-center gap-3">
                  <span className="label-caps w-20 shrink-0">{f.short}</span>
                  <div className="h-6 flex-1 bg-muted">
                    <div
                      className="h-full bg-primary/80"
                      style={{ width: `${(count / maxFunnel) * 100}%` }}
                    />
                  </div>
                  <span className="w-10 shrink-0 text-right font-mono text-sm tabular-nums">
                    {count}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        <div className="rounded-md border border-border bg-card p-5">
          <h2 className="text-lg font-semibold uppercase">My task queue</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            {profile?.department ? `${profile.department} department · ` : ""}
            {myQueue.length} units awaiting your action
          </p>
          <ul className="mt-4 max-h-72 space-y-2 overflow-y-auto">
            {myQueue.slice(0, 40).map((c) => (
              <li key={c.id} className="border-b border-border pb-2 last:border-0">
                <Link
                  to="/chassis"
                  search={{ q: c.chassis_number ?? c.engine_number }}
                  className="font-mono text-sm text-foreground hover:text-primary"
                >
                  {c.chassis_number ?? c.engine_number}
                </Link>
                <div className="text-[11px] text-muted-foreground">
                  {NEXT_ACTION[c.status]?.verb}
                </div>
              </li>
            ))}
            {myQueue.length === 0 ? (
              <li className="text-sm text-muted-foreground">
                Nothing is waiting on your department right now.
              </li>
            ) : null}
          </ul>
        </div>
      </section>

      {roles.includes("super_admin") ? (
        <section className="mt-6 flex flex-wrap items-center justify-between gap-3 rounded-md border border-border bg-card p-5">
          <div>
            <h2 className="text-lg font-semibold uppercase">Audit trail</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              The full chassis change history now lives on its own Super Admin tab.
            </p>
          </div>
          <Button asChild variant="outline" size="sm">
            <Link to="/audit">Open audit trail</Link>
          </Button>
        </section>
      ) : null}
    </AppShell>
  );
}

function MetricCardBody({ metric: m }: { metric: Metric }) {
  return (
    <>
      <div className="flex items-start justify-between gap-2">
        <span className="label-caps leading-snug">{m.label}</span>
        <MetricIcon icon={m.icon} className="size-4 shrink-0 text-primary/70" />
      </div>
      <div className="figure-xl mt-3 text-primary">{m.value}</div>
      <div className="mt-1 text-[11px] leading-snug text-muted-foreground">{m.hint}</div>
    </>
  );
}


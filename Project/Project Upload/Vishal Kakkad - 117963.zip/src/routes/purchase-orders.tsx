import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { Guard } from "@/components/Guard";
import { useAuth } from "@/hooks/useAuth";
import { bolsQuery, chassisQuery, purchaseOrdersQuery } from "@/lib/queries";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import { ClipboardList } from "lucide-react";

export const Route = createFileRoute("/purchase-orders")({
  head: () => ({
    meta: [
      { title: "Purchase Orders — CKD Assembly Control" },
      {
        name: "description",
        content:
          "Procurement raises CKD purchase orders; the ordered quantity feeds the CKD Qty Ordered and CKD Qty Yet to be Shipped dashboard figures.",
      },
      { property: "og:title", content: "Purchase Orders — CKD Assembly Control" },
      {
        property: "og:description",
        content: "CKD purchase orders with shipped and outstanding quantity per order.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <Guard>
      <PurchaseOrdersPage />
    </Guard>
  ),
});

function PurchaseOrdersPage() {
  const { can, user } = useAuth();
  const qc = useQueryClient();
  const { data: orders = [] } = useQuery(purchaseOrdersQuery);
  const { data: bols = [] } = useQuery(bolsQuery);
  const { data: chassis = [] } = useQuery(chassisQuery);
  const [open, setOpen] = useState(false);

  const shippedFor = (poId: string) => {
    const ids = bols.filter((b) => b.po_id === poId).map((b) => b.id);
    return chassis.filter((c) => ids.includes(c.bol_id)).length;
  };

  const totalOrdered = orders.reduce((sum, o) => sum + o.quantity, 0);
  const totalShipped = orders.reduce((sum, o) => sum + shippedFor(o.id), 0);

  return (
    <AppShell
      title="Purchase Orders"
      subtitle="Procurement raises the CKD order; the quantity ordered here drives CKD Qty Ordered and CKD Qty Yet to be Shipped"
      actions={
        can("procurement") ? (
          <Button size="sm" onClick={() => setOpen(true)}>
            <ClipboardList className="mr-1.5 size-4" /> New purchase order
          </Button>
        ) : null
      }
    >
      <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
        <Stat label="Qty ordered" value={totalOrdered} />
        <Stat label="Qty shipped on BOL" value={totalShipped} />
        <Stat label="Qty yet to be shipped" value={Math.max(totalOrdered - totalShipped, 0)} />
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {orders.map((o) => {
          const shipped = shippedFor(o.id);
          const pending = Math.max(o.quantity - shipped, 0);
          return (
            <div key={o.id} className="panel-grid rounded-md border border-border bg-card p-5">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="font-mono text-sm text-primary">{o.po_number}</div>
                  <div className="mt-1 text-lg font-semibold uppercase">{o.supplier}</div>
                </div>
                <div className="text-right">
                  <div className="label-caps">Qty ordered</div>
                  <div className="font-mono text-2xl tabular-nums">{o.quantity}</div>
                </div>
              </div>
              <dl className="mt-4 grid grid-cols-2 gap-3 text-xs">
                <Row label="Order date" value={o.order_date} />
                <Row label="Model" value={o.model ?? "—"} />
                <Row label="Shipped on BOL" value={`${shipped} / ${o.quantity}`} mono />
                <Row label="Yet to be shipped" value={String(pending)} mono />
              </dl>
              {o.notes ? (
                <p className="mt-3 text-xs text-muted-foreground">{o.notes}</p>
              ) : null}
            </div>
          );
        })}
        {orders.length === 0 ? (
          <p className="text-sm text-muted-foreground">No purchase orders raised yet.</p>
        ) : null}
      </div>

      {open ? (
        <NewPoDialog
          userId={user?.id ?? null}
          onClose={() => setOpen(false)}
          onDone={() => {
            setOpen(false);
            void qc.invalidateQueries({ queryKey: ["purchase_orders"] });
          }}
        />
      ) : null}
    </AppShell>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-md border border-border bg-card p-4">
      <div className="label-caps">{label}</div>
      <div className="figure-xl mt-2 text-primary">{value}</div>
    </div>
  );
}

function Row({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div>
      <dt className="label-caps">{label}</dt>
      <dd className={`mt-1 ${mono ? "font-mono" : ""}`}>{value}</dd>
    </div>
  );
}

function NewPoDialog({
  userId,
  onClose,
  onDone,
}: {
  userId: string | null;
  onClose: () => void;
  onDone: () => void;
}) {
  const [poNumber, setPoNumber] = useState("");
  const [supplier, setSupplier] = useState("");
  const [model, setModel] = useState("");
  const [quantity, setQuantity] = useState("");
  const [orderDate, setOrderDate] = useState(new Date().toISOString().slice(0, 10));
  const [notes, setNotes] = useState("");
  const [busy, setBusy] = useState(false);

  const save = async () => {
    setBusy(true);
    try {
      const qty = Number(quantity);
      if (!poNumber.trim()) throw new Error("Enter the purchase order number.");
      if (!supplier.trim()) throw new Error("Enter the supplier.");
      if (!Number.isFinite(qty) || qty <= 0) throw new Error("Enter a quantity greater than zero.");
      const { error } = await supabase.from("purchase_orders").insert({
        po_number: poNumber.trim(),
        supplier: supplier.trim(),
        model: model.trim() || null,
        quantity: Math.floor(qty),
        order_date: orderDate,
        notes: notes.trim() || null,
        created_by: userId,
      });
      if (error) throw error;
      toast.success(`${poNumber} raised for ${Math.floor(qty)} CKD units`);
      onDone();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not create the purchase order");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open onOpenChange={(o) => (o ? null : onClose())}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="uppercase">New purchase order</DialogTitle>
          <DialogDescription>
            The ordered quantity is added to CKD Qty Ordered. Anything not yet covered by a bill of lading
            stays in CKD Qty Yet to be Shipped.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="po">PO number</Label>
            <Input id="po" value={poNumber} onChange={(e) => setPoNumber(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="posup">Supplier</Label>
            <Input id="posup" value={supplier} onChange={(e) => setSupplier(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="poqty">Quantity ordered</Label>
            <Input
              id="poqty"
              type="number"
              min={1}
              value={quantity}
              onChange={(e) => setQuantity(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="podate">Order date</Label>
            <Input
              id="podate"
              type="date"
              value={orderDate}
              onChange={(e) => setOrderDate(e.target.value)}
            />
          </div>
          <div className="space-y-2 sm:col-span-2">
            <Label htmlFor="pomodel">Model</Label>
            <Input id="pomodel" value={model} onChange={(e) => setModel(e.target.value)} />
          </div>
          <div className="space-y-2 sm:col-span-2">
            <Label htmlFor="ponotes">Notes</Label>
            <Textarea id="ponotes" rows={3} value={notes} onChange={(e) => setNotes(e.target.value)} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={save} disabled={busy}>
            Create purchase order
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

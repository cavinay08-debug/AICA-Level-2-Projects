import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { Guard } from "@/components/Guard";
import { useAuth } from "@/hooks/useAuth";
import { bolsQuery, chassisQuery, customersQuery, invoicesQuery } from "@/lib/queries";
import {
  computeMetrics,
  NEXT_ACTION,
  STATUS_LABEL,
  STATUS_ORDER,
  CLUSTERS,
  TIMESTAMP_FIELD,
  type ChassisRow,
  type ChassisStatus,
} from "@/lib/ckd";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { parseEnginePairs } from "@/lib/sheet-import";
import { downloadChassisAssignTemplate } from "@/lib/sheet-export";

import { downloadGatePassPdf, type GatePassData } from "@/lib/gate-pass-pdf";

const unitLabel = (c: ChassisRow) => c.chassis_number ?? c.engine_number;

type Search = { metric?: string; q?: string; status?: string; cluster?: string };

export const Route = createFileRoute("/chassis")({
  validateSearch: (search: Record<string, unknown>): Search => {
    const out: Search = {};
    if (typeof search["metric"] === "string") out.metric = search["metric"];
    if (typeof search["q"] === "string") out.q = search["q"];
    if (typeof search["status"] === "string") out.status = search["status"];
    if (typeof search["cluster"] === "string") out.cluster = search["cluster"];
    return out;
  },
  head: () => ({
    meta: [
      { title: "Chassis Register — CKD Assembly Control" },
      {
        name: "description",
        content:
          "Search, filter and progress every chassis number through clearing, production, allocation, billing and gate-pass delivery.",
      },
      { property: "og:title", content: "Chassis Register — CKD Assembly Control" },
      {
        property: "og:description",
        content: "Chassis-level transactional register driving every dashboard metric.",
      },
    ],
  }),
  component: () => (
    <Guard>
      <ChassisPage />
    </Guard>
  ),
});

function ChassisPage() {
  const search = Route.useSearch();
  const navigate = useNavigate({ from: Route.fullPath });
  const qc = useQueryClient();
  const { can } = useAuth();

  const { data: rows = [] } = useQuery(chassisQuery);
  const { data: bols = [] } = useQuery(bolsQuery);
  const { data: customers = [] } = useQuery(customersQuery);
  const { data: invoices = [] } = useQuery(invoicesQuery);

  const [text, setText] = useState(search.q ?? "");
  const [target, setTarget] = useState<ChassisRow | null>(null);
  const [recall, setRecall] = useState<ChassisRow | null>(null);
  const [regTarget, setRegTarget] = useState<ChassisRow | null>(null);
  const [bulkOpen, setBulkOpen] = useState(false);

  const metric = useMemo(
    () => computeMetrics(rows).find((m) => m.key === search.metric),
    [rows, search.metric],
  );

  const cluster = CLUSTERS.find((c) => c.key === search.cluster);

  const filtered = rows.filter((c) => {
    if (metric?.filter && !metric.filter(c)) return false;
    if (cluster && !cluster.statuses.includes(c.status)) return false;
    if (search.status && c.status !== search.status) return false;
    const term = text.trim().toLowerCase();
    if (!term) return true;
    const invoice = invoices.find((i) => i.id === c.invoice_id);
    const customer = customers.find((x) => x.id === c.customer_id);
    const bol = bols.find((b) => b.id === c.bol_id);
    return [
      c.engine_number,
      c.chassis_number,
      c.registration_number,
      invoice?.invoice_number,
      customer?.name,
      bol?.bol_number,
      bol?.file_reference_number,
    ]
      .filter(Boolean)
      .some((v) => String(v).toLowerCase().includes(term));
  });

  const clearFilters = () => {
    setText("");
    void navigate({ search: {} });
  };

  const invalidate = () => {
    void qc.invalidateQueries({ queryKey: ["chassis"] });
    void qc.invalidateQueries({ queryKey: ["invoices"] });
    void qc.invalidateQueries({ queryKey: ["customers"] });
    void qc.invalidateQueries({ queryKey: ["audit"] });
  };

  return (
    <AppShell
      title="Chassis Register"
      subtitle={
        cluster
          ? `${cluster.label} — ${cluster.blurb}`
          : metric
          ? `Filtered by metric ${String(metric.index).padStart(2, "0")} — ${metric.label}`
          : "Every chassis number, its current lifecycle stage and its next department action"
      }
      actions={
        <>
          <Input
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Engine, chassis, invoice, customer, BOL…"
            className="w-64"
          />
          <Select
            value={search.status ?? "all"}
            onValueChange={(v) =>
              void navigate({
                search: (prev) => {
                  const next: Search = { ...prev };
                  if (v === "all") delete next.status;
                  else next.status = v;
                  return next;
                },
              })
            }
          >
            <SelectTrigger className="w-52">
              <SelectValue placeholder="All stages" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All stages</SelectItem>
              {STATUS_ORDER.map((s) => (
                <SelectItem key={s} value={s}>
                  {STATUS_LABEL[s]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {can("clearing") ? (
            <Button size="sm" variant="outline" onClick={() => setBulkOpen(true)}>
              Assign chassis nos. (Excel / CSV)
            </Button>
          ) : null}
          {metric || search.status || text || cluster ? (
            <Button variant="outline" size="sm" onClick={clearFilters}>
              Clear
            </Button>
          ) : null}
        </>
      }
    >
      <div className="mb-4 flex flex-wrap gap-1.5">
        <button
          type="button"
          onClick={() => void navigate({ search: (prev) => { const n: Search = { ...prev }; delete n.cluster; return n; } })}
          className={`rounded-md border px-3 py-1.5 font-mono text-[11px] tracking-wider uppercase transition-colors ${
            cluster
              ? "border-border bg-card text-muted-foreground hover:border-border-strong"
              : "border-primary bg-primary/10 text-primary"
          }`}
        >
          All activity
        </button>
        {CLUSTERS.map((cl) => {
          const count = rows.filter((r) => cl.statuses.includes(r.status)).length;
          const active = cluster?.key === cl.key;
          return (
            <button
              key={cl.key}
              type="button"
              onClick={() =>
                void navigate({ search: (prev) => ({ ...prev, cluster: cl.key }) })
              }
              className={`rounded-md border px-3 py-1.5 font-mono text-[11px] tracking-wider uppercase transition-colors ${
                active
                  ? "border-primary bg-primary/10 text-primary"
                  : "border-border bg-card text-muted-foreground hover:border-border-strong"
              }`}
            >
              {cl.short}
              <span className="ml-2 text-foreground/80 tabular-nums">{count}</span>
            </button>
          );
        })}
      </div>

      <div className="rounded-md border border-border bg-card">
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <span className="label-caps">{filtered.length} chassis shown</span>
          <span className="label-caps">of {rows.length} total</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[880px] text-sm">
            <thead>
              <tr className="border-b border-border text-left">
                {["Engine", "Chassis", "Model", "Stage", "Customer", "Invoice", "Reg. no.", ""].map(
                  (h) => (
                    <th key={h} className="label-caps px-4 py-2">
                      {h}
                    </th>
                  ),
                )}
              </tr>
            </thead>
            <tbody>
              {filtered.map((c) => {
                const action = NEXT_ACTION[c.status];
                const allowed = action ? can(action.role) : false;
                return (
                  <tr key={c.id} className="border-b border-border/60 last:border-0 hover:bg-muted/40">
                    <td className="px-4 py-2 font-mono text-xs">{c.engine_number}</td>
                    <td className="px-4 py-2 font-mono text-xs text-muted-foreground">
                      {c.chassis_number ?? "Not assigned"}
                    </td>
                    <td className="px-4 py-2 text-xs">{c.model ?? "—"}</td>
                    <td className="px-4 py-2">
                      <Badge variant="outline" className="font-mono text-[10px] tracking-wider uppercase">
                        {STATUS_LABEL[c.status]}
                      </Badge>
                    </td>
                    <td className="px-4 py-2 text-xs">
                      {customers.find((x) => x.id === c.customer_id)?.name ?? "—"}
                    </td>
                    <td className="px-4 py-2 font-mono text-xs">
                      {invoices.find((i) => i.id === c.invoice_id)?.invoice_number ?? "—"}
                    </td>
                    <td className="px-4 py-2 font-mono text-xs">{c.registration_number ?? "—"}</td>
                    <td className="px-4 py-2 text-right">
                      <div className="flex items-center justify-end gap-2">
                        {can("sales") && c.invoice_id ? (
                          <Button size="sm" variant="outline" onClick={() => setRegTarget(c)}>
                            {c.registration_number ? "Edit registration" : "Add registration"}
                          </Button>
                        ) : null}
                        {c.status === "delivery_authorized" && can("sales") ? (
                          <Button size="sm" variant="outline" onClick={() => setRecall(c)}>
                            Recall authorisation
                          </Button>
                        ) : null}
                        {action ? (
                          <Button
                            size="sm"
                            variant={allowed ? "default" : "outline"}
                            disabled={!allowed}
                            onClick={() => setTarget(c)}
                          >
                            {allowed ? action.verb : "Locked"}
                          </Button>
                        ) : (
                          <span className="label-caps">
                            {c.status === "delivered" ? "Gate pass issued" : "Complete"}
                          </span>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-4 py-6 text-center text-muted-foreground">
                    No chassis match these filters.
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </div>

      {bulkOpen ? (
        <BulkAssignDialog
          rows={rows}
          onClose={() => setBulkOpen(false)}
          onDone={() => {
            setBulkOpen(false);
            invalidate();
          }}
        />
      ) : null}

      {target ? (
        <ActionDialog
          chassis={target}
          onClose={() => setTarget(null)}
          onDone={() => {
            setTarget(null);
            invalidate();
          }}
        />
      ) : null}

      {recall ? (
        <RecallDialog
          chassis={recall}
          onClose={() => setRecall(null)}
          onDone={() => {
            setRecall(null);
            invalidate();
          }}
        />
      ) : null}

      {regTarget ? (
        <RegistrationDialog
          chassis={regTarget}
          onClose={() => setRegTarget(null)}
          onDone={() => {
            setRegTarget(null);
            invalidate();
          }}
        />
      ) : null}
    </AppShell>
  );
}

function RegistrationDialog({
  chassis,
  onClose,
  onDone,
}: {
  chassis: ChassisRow;
  onClose: () => void;
  onDone: () => void;
}) {
  const [number, setNumber] = useState(chassis.registration_number ?? "");
  const [date, setDate] = useState(
    chassis.registration_date ?? new Date().toISOString().slice(0, 10),
  );
  const [busy, setBusy] = useState(false);

  const run = async () => {
    setBusy(true);
    try {
      if (!chassis.invoice_id)
        throw new Error("An invoice must be issued before a vehicle registration number is added.");
      const { error } = await supabase
        .from("chassis")
        .update({
          registration_number: number.trim() || null,
          registration_date: number.trim() ? date || null : null,
        })
        .eq("id", chassis.id);
      if (error) throw error;
      toast.success(`${unitLabel(chassis)} — registration details saved`);
      onDone();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not save the registration details");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open onOpenChange={(o) => (o ? null : onClose())}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="uppercase">Vehicle registration</DialogTitle>
          <DialogDescription>
            Optional. Recorded by Sales after the invoice is issued for engine{" "}
            <span className="font-mono">{chassis.engine_number}</span>.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <Field label="Vehicle registration number">
            <Input
              value={number}
              onChange={(e) => setNumber(e.target.value)}
              placeholder="T 123 ABC"
            />
          </Field>
          <Field label="Vehicle registration date">
            <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </Field>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={run} disabled={busy}>
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function RecallDialog({
  chassis,
  onClose,
  onDone,
}: {
  chassis: ChassisRow;
  onClose: () => void;
  onDone: () => void;
}) {
  const [busy, setBusy] = useState(false);

  const run = async () => {
    setBusy(true);
    try {
      const { count, error: ge } = await supabase
        .from("gate_passes")
        .select("id", { count: "exact", head: true })
        .eq("chassis_id", chassis.id);
      if (ge) throw ge;
      if (count && count > 0)
        throw new Error(
          "A gate pass has already been issued for this unit — the authorisation can no longer be revoked.",
        );

      const { error } = await supabase
        .from("chassis")
        .update({ status: "paid", delivery_authorized_at: null })
        .eq("id", chassis.id);
      if (error) throw error;
      toast.success(`${unitLabel(chassis)} — delivery authorisation recalled`);
      onDone();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not recall the authorisation");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open onOpenChange={(o) => (o ? null : onClose())}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="uppercase">Recall cargo delivery authorisation</DialogTitle>
          <DialogDescription>
            Engine <span className="font-mono">{chassis.engine_number}</span> returns to{" "}
            {STATUS_LABEL["paid"]}. This is only possible while Store has not yet issued a gate
            pass; once a gate pass exists the authorisation is final.
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button variant="destructive" onClick={run} disabled={busy}>
            Recall authorisation
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}


function BulkAssignDialog({
  rows,
  onClose,
  onDone,
}: {
  rows: ChassisRow[];
  onClose: () => void;
  onDone: () => void;
}) {
  const fileInput = useRef<HTMLInputElement>(null);
  const [pairs, setPairs] = useState<{ engine: string; chassis: string }[]>([]);
  const [busy, setBusy] = useState(false);

  const onFile = async (file: File | undefined) => {
    if (!file) return;
    try {
      const parsed = await parseEnginePairs(file);
      if (!parsed.length)
        throw new Error("Expected two columns: engine number in the first, chassis number in the second.");
      setPairs(parsed);
      toast.success(`${parsed.length} rows read from ${file.name}`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not read that file");
    } finally {
      if (fileInput.current) fileInput.current.value = "";
    }
  };

  const matched = pairs
    .map((p) => ({ pair: p, row: rows.find((r) => r.engine_number === p.engine) }))
    .filter((m): m is { pair: { engine: string; chassis: string }; row: ChassisRow } => Boolean(m.row));
  const unmatched = pairs.length - matched.length;

  const apply = async () => {
    setBusy(true);
    let ok = 0;
    const failed: string[] = [];
    for (const m of matched) {
      const { error } = await supabase
        .from("chassis")
        .update({ chassis_number: m.pair.chassis })
        .eq("id", m.row.id);
      if (error) failed.push(m.pair.engine);
      else ok += 1;
    }
    setBusy(false);
    if (ok) toast.success(`${ok} chassis numbers assigned`);
    if (failed.length) toast.error(`${failed.length} could not be updated (${failed.slice(0, 3).join(", ")})`);
    onDone();
  };

  return (
    <Dialog open onOpenChange={(o) => (o ? null : onClose())}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="uppercase">Assign chassis numbers</DialogTitle>
          <DialogDescription>
            Clearing matches each engine number to its chassis number. Upload a spreadsheet with engine
            number in the first column and chassis number in the second.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <input
            ref={fileInput}
            type="file"
            accept=".csv,.xls,.xlsx"
            className="hidden"
            onChange={(e) => void onFile(e.target.files?.[0])}
          />
          <div className="flex flex-wrap gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() =>
                downloadChassisAssignTemplate(
                  rows
                    .filter((r) => !r.chassis_number)
                    .map((r) => ({ engine_number: r.engine_number, model: r.model })),
                )
              }
            >
              Download Excel template
            </Button>
            <Button type="button" variant="outline" onClick={() => fileInput.current?.click()}>
              Choose Excel / CSV file
            </Button>
          </div>

          {pairs.length ? (
            <div className="rounded-md border border-border">
              <div className="flex items-center justify-between border-b border-border px-3 py-2">
                <span className="label-caps">{matched.length} engine numbers matched</span>
                {unmatched > 0 ? (
                  <span className="label-caps text-destructive">{unmatched} not found</span>
                ) : null}
              </div>
              <ul className="max-h-56 overflow-y-auto p-3 font-mono text-xs">
                {matched.slice(0, 100).map((m) => (
                  <li key={m.row.id} className="flex justify-between gap-3 py-0.5">
                    <span>{m.pair.engine}</span>
                    <span className="text-primary">{m.pair.chassis}</span>
                  </li>
                ))}
              </ul>
            </div>
          ) : null}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={apply} disabled={busy || !matched.length}>
            Assign {matched.length || ""}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function ActionDialog({
  chassis,
  onClose,
  onDone,
}: {
  chassis: ChassisRow;
  onClose: () => void;
  onDone: () => void;
}) {
  const action = NEXT_ACTION[chassis.status]!;
  const { user, profile } = useAuth();
  const { data: customers = [] } = useQuery(customersQuery);
  const { data: invoices = [] } = useQuery(invoicesQuery);

  const [chassisNumber, setChassisNumber] = useState(chassis.chassis_number ?? "");
  const [customerId, setCustomerId] = useState(chassis.customer_id ?? "");
  const [invoiceNumber, setInvoiceNumber] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("Full Payment");
  const [creatingCustomer, setCreatingCustomer] = useState(false);
  const [newCustomer, setNewCustomer] = useState({
    name: "",
    tin: "",
    vrn: "",
    contact_person: "",
    phone: "",
    email: "",
  });
  const [receiver, setReceiver] = useState("");
  const [idProof, setIdProof] = useState("");
  const [busy, setBusy] = useState(false);

  const next = action.next;

  const run = async () => {
    setBusy(true);
    let pdf: GatePassData | null = null;
    try {

      const patch: {
        status: ChassisStatus;
        chassis_number?: string;
        shipped_at?: string;
        customer_id?: string;
        invoice_id?: string;
        registration_number?: string;
        registration_date?: string;
        [key: string]: unknown;
      } = { status: next };
      const stamp = TIMESTAMP_FIELD[next];
      if (stamp) patch[stamp] = new Date().toISOString();

      if (next === "shipped") patch['shipped_at'] = new Date().toISOString();

      if (next === "at_plant") {
        if (!chassisNumber.trim())
          throw new Error("Assign a chassis number to this engine number before clearing.");
        patch['chassis_number'] = chassisNumber.trim();
      } else if (chassisNumber.trim() && chassisNumber.trim() !== (chassis.chassis_number ?? "")) {
        patch['chassis_number'] = chassisNumber.trim();
      }

      if (next === "allocated") {
        let allocateTo = customerId;
        if (creatingCustomer) {
          const name = newCustomer.name.trim();
          const tin = newCustomer.tin.trim();
          const contact = newCustomer.contact_person.trim();
          const phone = newCustomer.phone.trim();
          if (!name) throw new Error("Enter the customer name for the new customer master.");
          if (!tin) throw new Error("A Tax Identification Number (TIN) is required.");
          if (!contact) throw new Error("Enter the contact person name.");
          if (!phone) throw new Error("Enter the customer mobile number.");
          const { data, error } = await supabase
            .from("customers")
            .insert({
              name,
              tin,
              vrn: newCustomer.vrn.trim() || null,
              contact_person: contact,
              phone,
              email: newCustomer.email.trim() || null,
            })
            .select("id")
            .single();
          if (error) throw error;
          allocateTo = data.id;
        }
        if (!allocateTo)
          throw new Error("Select an existing customer, or create a new customer master.");
        patch['customer_id'] = allocateTo;
      }

      if (next === "invoiced") {
        const num = invoiceNumber.trim();
        if (!num) throw new Error("Enter the invoice number issued by Accounts.");
        let invoice = invoices.find((i) => i.invoice_number === num);
        if (!invoice) {
          const { data, error } = await supabase
            .from("invoices")
            .insert({
              invoice_number: num,
              customer_id: chassis.customer_id,
              payment_method: paymentMethod,
              created_by: user?.id ?? null,
            })
            .select()
            .single();
          if (error) throw error;
          invoice = data as NonNullable<typeof invoice>;
        }
        patch['invoice_id'] = invoice!.id;
      }

      if (next === "paid" && chassis.invoice_id) {
        const { error } = await supabase
          .from("invoices")
          .update({
            payment_confirmed: true,
            payment_confirmed_at: new Date().toISOString(),
            payment_method: paymentMethod,
          })
          .eq("id", chassis.invoice_id);
        if (error) throw error;
      }

      if (next === "delivered") {
        if (!receiver.trim() || !idProof.trim())
          throw new Error("Receiver name and verified ID proof are required for a gate pass.");
        const gatePassNumber = `GP-${new Date().getFullYear()}-${chassis.chassis_number ?? chassis.engine_number}`;
        const deliveryDate = new Date().toISOString().slice(0, 10);
        const { error } = await supabase.from("gate_passes").insert({
          gate_pass_number: gatePassNumber,
          chassis_id: chassis.id,
          receiver_name: receiver.trim(),
          receiver_id_proof: idProof.trim(),
          signature_verified: true,
          delivery_date: deliveryDate,
          issued_by: user?.id ?? null,
        });
        if (error) throw error;
        pdf = {
          gatePassNumber,
          engineNumber: chassis.engine_number,
          chassisNumber: chassis.chassis_number,
          model: chassis.model,
          registrationNumber: chassis.registration_number,
          customerName: customers.find((c) => c.id === chassis.customer_id)?.name ?? null,
          invoiceNumber: invoices.find((i) => i.id === chassis.invoice_id)?.invoice_number ?? null,
          receiverName: receiver.trim(),
          receiverIdProof: idProof.trim(),
          issuedBy: profile?.full_name || profile?.email || "Store",
          deliveryDate,
        };
      }


      const { error } = await supabase.from("chassis").update(patch as never).eq("id", chassis.id);
      if (error) throw error;
      if (pdf) {
        downloadGatePassPdf(pdf);
        toast.success(`Gate pass ${pdf.gatePassNumber} generated as PDF`);
      }
      toast.success(`${unitLabel(chassis)} → ${STATUS_LABEL[next]}`);
      onDone();

    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Action failed");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open onOpenChange={(o) => (o ? null : onClose())}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="uppercase">{action.verb}</DialogTitle>
          <DialogDescription>
            Engine <span className="font-mono">{chassis.engine_number}</span> moves from{" "}
            {STATUS_LABEL[chassis.status]} to {STATUS_LABEL[next]}.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {next === "at_port" || next === "at_plant" ? (
            <Field label="Chassis number assigned to this engine">
              <Input
                value={chassisNumber}
                onChange={(e) => setChassisNumber(e.target.value)}
                placeholder="CKD0101X"
              />
            </Field>
          ) : null}

          {next === "allocated" ? (
            <div className="space-y-4">
              {creatingCustomer ? null : (
                <Field label="Allocate to existing customer">
                  <Select value={customerId} onValueChange={setCustomerId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select customer" />
                    </SelectTrigger>
                    <SelectContent>
                      {customers.map((c) => (
                        <SelectItem key={c.id} value={c.id}>
                          {c.name}
                          {c.tin ? ` — TIN ${c.tin}` : ""}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </Field>
              )}

              <Button
                type="button"
                size="sm"
                variant="outline"
                onClick={() => setCreatingCustomer((v) => !v)}
              >
                {creatingCustomer ? "Use an existing customer" : "Create new customer master"}
              </Button>

              {creatingCustomer ? (
                <div className="space-y-4 rounded-md border border-border bg-muted/30 p-4">
                  <Field label="Customer name">
                    <Input
                      value={newCustomer.name}
                      onChange={(e) => setNewCustomer((s) => ({ ...s, name: e.target.value }))}
                    />
                  </Field>
                  <Field label="Tax Identification Number (TIN)">
                    <Input
                      value={newCustomer.tin}
                      onChange={(e) => setNewCustomer((s) => ({ ...s, tin: e.target.value }))}
                    />
                  </Field>
                  <Field label="VAT Registration Number (VRN) — optional">
                    <Input
                      value={newCustomer.vrn}
                      onChange={(e) => setNewCustomer((s) => ({ ...s, vrn: e.target.value }))}
                    />
                  </Field>
                  <Field label="Contact person name">
                    <Input
                      value={newCustomer.contact_person}
                      onChange={(e) =>
                        setNewCustomer((s) => ({ ...s, contact_person: e.target.value }))
                      }
                    />
                  </Field>
                  <Field label="Customer mobile number">
                    <Input
                      value={newCustomer.phone}
                      onChange={(e) => setNewCustomer((s) => ({ ...s, phone: e.target.value }))}
                    />
                  </Field>
                  <Field label="Customer e-mail (optional)">
                    <Input
                      type="email"
                      value={newCustomer.email}
                      onChange={(e) => setNewCustomer((s) => ({ ...s, email: e.target.value }))}
                    />
                  </Field>
                </div>
              ) : null}
            </div>
          ) : null}

          {next === "invoiced" ? (
            <>
              <Field label="Invoice number">
                <Input
                  value={invoiceNumber}
                  onChange={(e) => setInvoiceNumber(e.target.value)}
                  placeholder="INV-2026-0120"
                />
              </Field>
              <Field label="Payment terms">
                <PaymentSelect value={paymentMethod} onChange={setPaymentMethod} />
              </Field>
              <p className="text-xs text-muted-foreground">
                Sales can record the vehicle registration number and date once this invoice is
                issued.
              </p>
            </>
          ) : null}

          {next === "paid" ? (
            <Field label="Confirmed payment method">
              <PaymentSelect value={paymentMethod} onChange={setPaymentMethod} />
            </Field>
          ) : null}

          {next === "delivered" ? (
            <>
              <Field label="Receiving representative">
                <Input value={receiver} onChange={(e) => setReceiver(e.target.value)} />
              </Field>
              <Field label="Verified ID proof">
                <Input value={idProof} onChange={(e) => setIdProof(e.target.value)} />
              </Field>
            </>
          ) : null}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={run} disabled={busy}>
            Confirm
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-2">
      <Label>{label}</Label>
      {children}
    </div>
  );
}

function PaymentSelect({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger>
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        {["Full Payment", "Letter of Credit", "Approved Credit Terms"].map((m) => (
          <SelectItem key={m} value={m}>
            {m}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

export type { ChassisStatus };

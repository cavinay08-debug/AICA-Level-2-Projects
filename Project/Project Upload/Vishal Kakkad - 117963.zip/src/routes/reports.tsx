import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AppShell } from "@/components/AppShell";
import { Guard } from "@/components/Guard";
import { MetricIcon } from "@/components/MetricIcon";
import { ClusterAnimation } from "@/components/ClusterAnimation";
import {
  chassisQuery,
  purchaseOrdersQuery,
  bolsQuery,
  customersQuery,
  invoicesQuery,
} from "@/lib/queries";
import {
  CLUSTERS,
  COMPANY,
  computeMetrics,
  FUNNEL,
  rank,
  STATUS_LABEL,
  STATUS_ORDER,
  type ChassisRow,
  type Metric,
} from "@/lib/ckd";

export const Route = createFileRoute("/reports")({
  head: () => ({
    meta: [
      { title: "Management Reports — VKJG Vehicle Assembly Plant" },
      {
        name: "description",
        content:
          "Management reporting for VKJG Vehicle Assembly Plant Tanzania: stage conversion, department workload, model mix, billing and delivery performance.",
      },
      { property: "og:title", content: "Management Reports — VKJG Vehicle Assembly Plant" },
      {
        property: "og:description",
        content:
          "Infographic reporting across ordering, clearing, assembly, commercial and dispatch clusters.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <Guard>
      <ReportsPage />
    </Guard>
  ),
});

const CLUSTER_TONE: Record<string, string> = {
  ordering: "var(--chart-1)",
  inbound: "var(--chart-2)",
  production: "var(--chart-3)",
  commercial: "var(--chart-5)",
  dispatch: "var(--chart-4)",
};

function ReportsPage() {
  const { data: rows = [] } = useQuery(chassisQuery);
  const { data: orders = [] } = useQuery(purchaseOrdersQuery);
  const { data: bols = [] } = useQuery(bolsQuery);
  const { data: customers = [] } = useQuery(customersQuery);
  const { data: invoices = [] } = useQuery(invoicesQuery);

  const orderedQty = orders.reduce((s, o) => s + o.quantity, 0);
  const metrics = computeMetrics(rows, orders.length ? orderedQty : rows.length);
  const byKey = (k: string) => metrics.find((m) => m.key === k);

  const total = rows.length || 1;
  const delivered = rows.filter((c) => c.status === "delivered").length;
  const billed = rows.filter((c) => rank(c.status) >= rank("invoiced")).length;
  const producedCount = rows.filter((c) => rank(c.status) >= rank("produced")).length;

  const models = group(rows, (c) => c.model ?? "Unspecified");
  const stageCounts = STATUS_ORDER.map((s) => ({
    status: s,
    count: rows.filter((c) => c.status === s).length,
  }));
  const maxStage = Math.max(...stageCounts.map((s) => s.count), 1);
  const maxFunnel = Math.max(
    ...FUNNEL.map((f) => rows.filter((c) => rank(c.status) >= rank(f.status)).length),
    1,
  );

  const supplierRows = group(rows, (c) => bols.find((b) => b.id === c.bol_id)?.supplier ?? "—");
  const customerRows = group(
    rows.filter((c) => c.customer_id),
    (c) => customers.find((x) => x.id === c.customer_id)?.name ?? "—",
  );
  const paid = invoices.filter((i) => i.payment_confirmed).length;

  return (
    <AppShell
      title="Management Reports"
      subtitle={`${COMPANY.name} — ${COMPANY.region} · consolidated performance across all five activity clusters`}
    >
      <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="CKD ordered" value={orderedQty} hint="Total purchase-order quantity" tone="var(--chart-1)" />
        <Kpi
          label="Assembly conversion"
          value={`${pct(producedCount, total)}%`}
          hint={`${producedCount} of ${rows.length} kits assembled`}
          tone="var(--chart-3)"
        />
        <Kpi
          label="Billing conversion"
          value={`${pct(billed, total)}%`}
          hint={`${billed} units invoiced · ${paid} invoices paid`}
          tone="var(--chart-5)"
        />
        <Kpi
          label="Delivery conversion"
          value={`${pct(delivered, total)}%`}
          hint={`${delivered} vehicles handed over`}
          tone="var(--chart-4)"
        />
      </section>

      <section className="mt-6">
        <SectionHead
          title="Cluster scorecard"
          note="Each cluster is owned by a department; figures drill into the chassis register."
        />
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {CLUSTERS.map((cl) => {
            const inStage = rows.filter((c) => cl.statuses.includes(c.status)).length;
            const tone = CLUSTER_TONE[cl.key] ?? "var(--chart-1)";
            return (
              <Link
                key={cl.key}
                to="/chassis"
                search={{ cluster: cl.key }}
                className="surface-raised rounded-md border border-border bg-card p-4 transition-colors hover:border-border-strong"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="label-caps" style={{ color: tone }}>
                      {cl.short}
                    </div>
                    <div className="mt-1 font-display text-base font-semibold uppercase">
                      {cl.label}
                    </div>
                  </div>
                  <div className="figure-lg" style={{ color: tone }}>
                    {inStage}
                  </div>
                </div>
                <p className="mt-2 text-[11px] leading-snug text-muted-foreground">{cl.blurb}</p>
                <ClusterAnimation cluster={cl.key} className="mt-3 w-full" />
                <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-muted">
                  <div
                    className="h-full rounded-full"
                    style={{ width: `${(inStage / total) * 100}%`, background: tone }}
                  />
                </div>
                <div className="mt-3 space-y-1.5">
                  {cl.metrics
                    .map(byKey)
                    .filter((m): m is Metric => Boolean(m))
                    .map((m) => (
                      <div key={m.key} className="flex items-center gap-2 text-xs">
                        <MetricIcon icon={m.icon} className="size-3.5 shrink-0 text-muted-foreground" />
                        <span className="flex-1 truncate text-muted-foreground">{m.label}</span>
                        <span className="font-mono tabular-nums">{m.value}</span>
                      </div>
                    ))}
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      <section className="mt-6 grid gap-4 lg:grid-cols-2">
        <Panel title="Lifecycle conversion funnel" note="Cumulative units that reached each stage">
          <div className="space-y-2.5">
            {FUNNEL.map((f) => {
              const count = rows.filter((c) => rank(c.status) >= rank(f.status)).length;
              return (
                <div key={f.status} className="flex items-center gap-3">
                  <span className="label-caps w-20 shrink-0">{f.short}</span>
                  <div className="h-5 flex-1 overflow-hidden rounded-sm bg-muted">
                    <div
                      className="h-full rounded-sm bg-primary/80"
                      style={{ width: `${(count / maxFunnel) * 100}%` }}
                    />
                  </div>
                  <span className="w-16 shrink-0 text-right font-mono text-xs tabular-nums text-muted-foreground">
                    {count} · {pct(count, maxFunnel)}%
                  </span>
                </div>
              );
            })}
          </div>
        </Panel>

        <Panel title="Where stock is standing now" note="Live count per lifecycle stage">
          <div className="space-y-2">
            {stageCounts.map((s) => (
              <div key={s.status} className="flex items-center gap-3">
                <span className="w-40 shrink-0 truncate text-xs text-muted-foreground">
                  {STATUS_LABEL[s.status]}
                </span>
                <div className="h-4 flex-1 overflow-hidden rounded-sm bg-muted">
                  <div
                    className="h-full rounded-sm"
                    style={{
                      width: `${(s.count / maxStage) * 100}%`,
                      background: CLUSTER_TONE[clusterOf(s.status)] ?? "var(--chart-1)",
                    }}
                  />
                </div>
                <span className="w-8 shrink-0 text-right font-mono text-xs tabular-nums">
                  {s.count}
                </span>
              </div>
            ))}
          </div>
        </Panel>
      </section>

      <section className="mt-6 grid gap-4 lg:grid-cols-3">
        <Panel title="Model mix" note="Units by vehicle model">
          <BreakdownList data={models} total={total} tone="var(--chart-2)" />
        </Panel>
        <Panel title="Supplier inflow" note="Units received per supplier consignment">
          <BreakdownList data={supplierRows} total={total} tone="var(--chart-1)" />
        </Panel>
        <Panel title="Customer allocation" note="Allocated units by customer">
          {customerRows.length ? (
            <BreakdownList data={customerRows} total={total} tone="var(--chart-5)" />
          ) : (
            <p className="text-sm text-muted-foreground">No allocations recorded yet.</p>
          )}
        </Panel>
      </section>

      <section className="mt-6">
        <Panel
          title="Full metric ledger"
          note="All dashboard measures in one management report line-up"
        >
          <div className="overflow-x-auto">
            <table className="w-full min-w-[560px] text-sm">
              <thead>
                <tr className="border-b border-border text-left">
                  <th className="label-caps py-2">#</th>
                  <th className="label-caps py-2">Measure</th>
                  <th className="label-caps py-2">Cluster</th>
                  <th className="label-caps py-2 text-right">Qty</th>
                  <th className="label-caps py-2 text-right">Share</th>
                </tr>
              </thead>
              <tbody>
                {metrics.map((m) => {
                  const cl = CLUSTERS.find((c) => c.metrics.includes(m.key));
                  return (
                    <tr key={m.key} className="border-b border-border/60 last:border-0">
                      <td className="py-2 font-mono text-xs text-muted-foreground">
                        {String(m.index).padStart(2, "0")}
                      </td>
                      <td className="py-2">
                        <div className="flex items-center gap-2">
                          <MetricIcon icon={m.icon} className="size-3.5 text-primary/70" />
                          {m.label}
                        </div>
                      </td>
                      <td className="py-2 text-xs text-muted-foreground">{cl?.short ?? "—"}</td>
                      <td className="py-2 text-right font-mono tabular-nums">{m.value}</td>
                      <td className="py-2 text-right font-mono text-xs tabular-nums text-muted-foreground">
                        {pct(m.value, Math.max(orderedQty, total))}%
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Panel>
      </section>
    </AppShell>
  );
}

function clusterOf(status: ChassisRow["status"]) {
  return CLUSTERS.find((c) => c.statuses.includes(status))?.key ?? "ordering";
}

function pct(a: number, b: number) {
  if (!b) return 0;
  return Math.round((a / b) * 100);
}

function group(rows: ChassisRow[], key: (c: ChassisRow) => string) {
  const map = new Map<string, number>();
  rows.forEach((r) => map.set(key(r), (map.get(key(r)) ?? 0) + 1));
  return [...map.entries()].sort((a, b) => b[1] - a[1]).map(([label, count]) => ({ label, count }));
}

function BreakdownList({
  data,
  total,
  tone,
}: {
  data: { label: string; count: number }[];
  total: number;
  tone: string;
}) {
  const max = Math.max(...data.map((d) => d.count), 1);
  return (
    <div className="space-y-2.5">
      {data.slice(0, 8).map((d) => (
        <div key={d.label}>
          <div className="flex items-baseline justify-between gap-2 text-xs">
            <span className="truncate">{d.label}</span>
            <span className="font-mono tabular-nums text-muted-foreground">
              {d.count} · {pct(d.count, total)}%
            </span>
          </div>
          <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-muted">
            <div
              className="h-full rounded-full"
              style={{ width: `${(d.count / max) * 100}%`, background: tone }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}

function Kpi({
  label,
  value,
  hint,
  tone,
}: {
  label: string;
  value: string | number;
  hint: string;
  tone: string;
}) {
  return (
    <div className="surface-raised panel-grid rounded-md border border-border bg-card p-4">
      <div className="label-caps">{label}</div>
      <div className="figure-xl mt-2" style={{ color: tone }}>
        {value}
      </div>
      <div className="mt-1 text-[11px] leading-snug text-muted-foreground">{hint}</div>
    </div>
  );
}

function Panel({
  title,
  note,
  children,
}: {
  title: string;
  note: string;
  children: React.ReactNode;
}) {
  return (
    <div className="surface-raised rounded-md border border-border bg-card p-5">
      <h2 className="text-lg font-semibold uppercase">{title}</h2>
      <p className="mt-1 mb-4 text-sm text-muted-foreground">{note}</p>
      {children}
    </div>
  );
}

function SectionHead({ title, note }: { title: string; note: string }) {
  return (
    <div className="mb-3">
      <h2 className="text-lg font-semibold uppercase">{title}</h2>
      <p className="text-sm text-muted-foreground">{note}</p>
    </div>
  );
}

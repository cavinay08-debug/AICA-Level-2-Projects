import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { AppShell } from "@/components/AppShell";
import { Guard } from "@/components/Guard";
import { useAuth } from "@/hooks/useAuth";
import { fullAuditQuery } from "@/lib/queries";
import { COMPANY, STATUS_LABEL, type ChassisStatus } from "@/lib/ckd";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/audit")({
  head: () => ({
    meta: [
      { title: "Audit Trail — VKJG Vehicle Assembly Plant" },
      {
        name: "description",
        content:
          "Super Admin audit trail of every chassis lifecycle change at the VKJG assembly plant, with actor, timestamp and status transition.",
      },
      { property: "og:title", content: "Audit Trail — VKJG Vehicle Assembly Plant" },
      {
        property: "og:description",
        content: "Full immutable record of chassis status changes with the user who made each change.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <Guard>
      <AuditPage />
    </Guard>
  ),
});

function label(status?: string) {
  if (!status) return "—";
  return STATUS_LABEL[status as ChassisStatus] ?? status;
}

function AuditPage() {
  const { roles } = useAuth();
  const isSuper = roles.includes("super_admin");
  const { data: rows = [], isLoading } = useQuery({ ...fullAuditQuery, enabled: isSuper });
  const [q, setQ] = useState("");

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase();
    if (!term) return rows;
    return rows.filter((r) =>
      [r.entity_label, r.actor_email, r.action, r.entity]
        .filter(Boolean)
        .some((v) => String(v).toLowerCase().includes(term)),
    );
  }, [rows, q]);

  if (!isSuper) {
    return (
      <AppShell title="Audit Trail" subtitle="Restricted area">
        <div className="rounded-md border border-border bg-card p-8 text-center">
          <h2 className="text-lg font-semibold uppercase">Super Admin only</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            The full audit trail is visible to Super Admins only. Contact plant administration if you
            need an extract for your department.
          </p>
        </div>
      </AppShell>
    );
  }

  const exportCsv = () => {
    const header = ["When", "Entity", "Reference", "Action", "From", "To", "User"];
    const lines = filtered.map((a) => {
      const d = (a.details ?? {}) as { old_status?: string; new_status?: string };
      return [
        new Date(a.created_at).toISOString(),
        a.entity,
        a.entity_label ?? "",
        a.action,
        label(d.old_status),
        label(d.new_status),
        a.actor_email ?? "System",
      ]
        .map((c) => `"${String(c).replace(/"/g, '""')}"`)
        .join(",");
    });
    const blob = new Blob([[header.join(","), ...lines].join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `vkjg-audit-trail-${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <AppShell
      title="Audit Trail"
      subtitle={`${COMPANY.name} — ${COMPANY.region} · ${filtered.length} recorded events · immutable chassis-level history`}
      actions={
        <Button variant="outline" size="sm" onClick={exportCsv}>
          Export CSV
        </Button>
      }
    >
      <div className="rounded-md border border-border bg-card p-5">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <h2 className="text-lg font-semibold uppercase">Full change history</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Every lifecycle change with the acting user, timestamp and status transition.
            </p>
          </div>
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search chassis, engine or user"
            className="w-full max-w-xs"
          />
        </div>

        <div className="mt-4 overflow-x-auto">
          <table className="w-full min-w-[720px] text-sm">
            <thead>
              <tr className="border-b border-border text-left">
                <th className="label-caps py-2">When</th>
                <th className="label-caps py-2">Reference</th>
                <th className="label-caps py-2">Action</th>
                <th className="label-caps py-2">Change</th>
                <th className="label-caps py-2">User</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((a) => {
                const d = (a.details ?? {}) as { old_status?: string; new_status?: string };
                return (
                  <tr key={a.id} className="border-b border-border/60 last:border-0">
                    <td className="py-2 font-mono text-xs whitespace-nowrap text-muted-foreground">
                      {new Date(a.created_at).toLocaleString()}
                    </td>
                    <td className="py-2 font-mono text-xs">{a.entity_label ?? "—"}</td>
                    <td className="py-2 text-xs uppercase">{a.action}</td>
                    <td className="py-2 text-xs">
                      {d.old_status ? `${label(d.old_status)} → ` : ""}
                      {label(d.new_status)}
                    </td>
                    <td className="py-2 text-xs text-muted-foreground">{a.actor_email ?? "System"}</td>
                  </tr>
                );
              })}
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-4 text-muted-foreground">
                    {isLoading ? "Loading audit events…" : "No matching audit events."}
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </div>
    </AppShell>
  );
}

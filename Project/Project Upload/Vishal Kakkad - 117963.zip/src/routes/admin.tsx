import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { Guard } from "@/components/Guard";
import { useAuth } from "@/hooks/useAuth";
import { usersQuery } from "@/lib/queries";
import { ROLE_LABEL, ROLE_DUTIES, type AppRole } from "@/lib/ckd";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

const ROLES = Object.keys(ROLE_LABEL) as AppRole[];

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Users & Access — CKD Assembly Control" },
      {
        name: "description",
        content:
          "Super Admin approval of signup requests, department role assignment and account deactivation for the CKD tracking system.",
      },
      { property: "og:title", content: "Users & Access — CKD Assembly Control" },
      {
        property: "og:description",
        content: "Approve access requests and assign department tasks per user.",
      },
    ],
  }),
  component: () => (
    <Guard>
      <AdminPage />
    </Guard>
  ),
});

function AdminPage() {
  const { roles } = useAuth();
  const qc = useQueryClient();
  const { data } = useQuery(usersQuery);
  const isAdmin = roles.includes("super_admin");

  const refresh = () => void qc.invalidateQueries({ queryKey: ["users"] });

  const setStatus = async (id: string, status: string) => {
    const { error } = await supabase
      .from("profiles")
      .update({ status: status as "approved" })
      .eq("id", id);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(`Account ${status}`);
    refresh();
  };

  const toggleRole = async (userId: string, role: AppRole, active: boolean) => {
    const { error } = active
      ? await supabase.from("user_roles").delete().eq("user_id", userId).eq("role", role)
      : await supabase.from("user_roles").insert({ user_id: userId, role });
    if (error) {
      toast.error(error.message);
      return;
    }
    refresh();
  };

  if (!isAdmin) {
    return (
      <AppShell title="Users & Access" subtitle="Super Admin only">
        <p className="text-sm text-muted-foreground">
          Only a Super Admin can approve accounts and assign department tasks.
        </p>
      </AppShell>
    );
  }

  const rank = (s: string) => (s === "pending" ? 0 : s === "approved" ? 1 : 2);
  const profiles = [...(data?.profiles ?? [])].sort((a, b) => rank(a.status) - rank(b.status));
  const userRoles = data?.roles ?? [];
  const pendingCount = profiles.filter((p) => p.status === "pending").length;

  return (
    <AppShell
      title="Users & Access"
      subtitle="Approve signup requests, then grant the exact department tasks each user may perform"
    >
      {pendingCount > 0 ? (
        <div className="mb-4 rounded-md border border-primary/50 bg-primary/10 p-3 font-mono text-[11px] tracking-wider uppercase">
          {pendingCount} access request{pendingCount > 1 ? "s" : ""} awaiting approval
        </div>
      ) : null}
      <div className="space-y-3">

        {profiles.map((p) => {
          const assigned = userRoles.filter((r) => r.user_id === p.id).map((r) => r.role as AppRole);
          return (
            <div key={p.id} className="rounded-md border border-border bg-card p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <div className="text-base font-semibold">{p.full_name || p.email}</div>
                  <div className="font-mono text-xs text-muted-foreground">{p.email}</div>
                  <div className="label-caps mt-1">{p.department ?? "No department"}</div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge
                    variant={p.status === "approved" ? "default" : "outline"}
                    className="font-mono text-[10px] tracking-wider uppercase"
                  >
                    {p.status}
                  </Badge>
                  {p.status !== "approved" ? (
                    <Button size="sm" onClick={() => void setStatus(p.id, "approved")}>
                      Approve
                    </Button>
                  ) : (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => void setStatus(p.id, "deactivated")}
                    >
                      Deactivate
                    </Button>
                  )}
                  {p.status === "pending" ? (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => void setStatus(p.id, "rejected")}
                    >
                      Reject
                    </Button>
                  ) : null}
                </div>
              </div>

              <div className="mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
                {ROLES.map((r) => {
                  const active = assigned.includes(r);
                  return (
                    <button
                      key={r}
                      type="button"
                      onClick={() => void toggleRole(p.id, r, active)}
                      className={`rounded-sm border p-3 text-left transition-colors ${
                        active
                          ? "border-primary bg-primary/10"
                          : "border-border hover:border-border-strong"
                      }`}
                    >
                      <span
                        className={`font-mono text-[10px] tracking-wider uppercase ${
                          active ? "text-primary" : "text-muted-foreground"
                        }`}
                      >
                        {active ? "✓ " : ""}
                        {ROLE_LABEL[r]}
                      </span>
                      <ul className="mt-2 space-y-0.5 text-[11px] leading-snug text-muted-foreground">
                        {ROLE_DUTIES[r].map((d) => (
                          <li key={d}>· {d}</li>
                        ))}
                      </ul>
                    </button>
                  );
                })}
              </div>

            </div>
          );
        })}
      </div>
    </AppShell>
  );
}

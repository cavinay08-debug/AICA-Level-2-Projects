ALTER TABLE public.customers
  ADD COLUMN IF NOT EXISTS tin text,
  ADD COLUMN IF NOT EXISTS vrn text;
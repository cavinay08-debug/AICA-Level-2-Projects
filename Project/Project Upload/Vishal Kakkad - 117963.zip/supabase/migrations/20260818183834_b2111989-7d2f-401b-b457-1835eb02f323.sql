CREATE OR REPLACE FUNCTION public.enforce_chassis_rules()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path TO 'public'
AS $function$
DECLARE old_rank int; new_rank int;
BEGIN
  NEW.updated_at := now();
  old_rank := public.status_rank(OLD.status);
  new_rank := public.status_rank(NEW.status);
  -- shipped by supplier goes straight to port; 'in_transit' is retired
  IF new_rank > old_rank + 1
     AND NOT (OLD.status = 'ordered' AND NEW.status = 'in_transit')
     AND NOT (OLD.status = 'shipped' AND NEW.status = 'at_port') THEN
    RAISE EXCEPTION 'A chassis cannot skip a lifecycle stage (% -> %)', OLD.status, NEW.status;
  END IF;
  IF new_rank >= 4 AND (NEW.chassis_number IS NULL OR NEW.chassis_number = '') THEN
    RAISE EXCEPTION 'A chassis number must be assigned to this engine number before clearing';
  END IF;
  IF OLD.invoice_id IS NOT NULL AND NEW.invoice_id IS DISTINCT FROM OLD.invoice_id THEN
    RAISE EXCEPTION 'This unit is already assigned to an invoice.';
  END IF;
  IF OLD.invoice_id IS NOT NULL AND NEW.customer_id IS DISTINCT FROM OLD.customer_id THEN
    RAISE EXCEPTION 'This unit is invoiced and can no longer be re-allocated.';
  END IF;
  IF new_rank >= 7 AND NEW.invoice_id IS NULL THEN
    RAISE EXCEPTION 'An invoice number is required before billing this unit';
  END IF;
  RETURN NEW;
END; $function$;
REVOKE ALL ON FUNCTION public.log_chassis_change() FROM public, anon, authenticated;
REVOKE ALL ON FUNCTION public.handle_new_user() FROM public, anon, authenticated;
REVOKE ALL ON FUNCTION public.enforce_chassis_rules() FROM public, anon, authenticated;
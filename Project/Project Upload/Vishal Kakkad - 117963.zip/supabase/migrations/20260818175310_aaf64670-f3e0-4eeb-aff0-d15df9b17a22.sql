CREATE OR REPLACE FUNCTION public.status_rank(_s public.chassis_status)
RETURNS int LANGUAGE sql IMMUTABLE SET search_path = public AS $$
  SELECT CASE _s
    WHEN 'ordered' THEN 0 WHEN 'shipped' THEN 1 WHEN 'in_transit' THEN 2 WHEN 'at_port' THEN 3
    WHEN 'at_plant' THEN 4 WHEN 'produced' THEN 5 WHEN 'allocated' THEN 6 WHEN 'invoiced' THEN 7
    WHEN 'paid' THEN 8 WHEN 'delivery_authorized' THEN 9 WHEN 'delivered' THEN 10 END;
$$;

REVOKE ALL ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.log_chassis_change() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.enforce_chassis_rules() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.is_approved(uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.can_act(uuid, public.app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_approved(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.can_act(uuid, public.app_role) TO authenticated;
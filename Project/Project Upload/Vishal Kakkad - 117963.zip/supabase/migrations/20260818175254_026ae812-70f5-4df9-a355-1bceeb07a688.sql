-- ENUMS
CREATE TYPE public.app_role AS ENUM ('super_admin','procurement','clearing','production','sales','accounts','store');
CREATE TYPE public.chassis_status AS ENUM ('ordered','shipped','in_transit','at_port','at_plant','produced','allocated','invoiced','paid','delivery_authorized','delivered');
CREATE TYPE public.approval_status AS ENUM ('pending','approved','rejected','deactivated');

-- PROFILES
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL,
  full_name text,
  department text,
  status public.approval_status NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role);
$$;

CREATE OR REPLACE FUNCTION public.is_approved(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.profiles WHERE id = _user_id AND status = 'approved');
$$;

CREATE OR REPLACE FUNCTION public.can_act(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT public.is_approved(_user_id)
    AND (public.has_role(_user_id,'super_admin') OR public.has_role(_user_id,_role));
$$;

-- Signup handler: create profile; first ever user becomes approved super admin
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE first_user boolean;
BEGIN
  SELECT NOT EXISTS (SELECT 1 FROM public.user_roles WHERE role = 'super_admin') INTO first_user;
  INSERT INTO public.profiles (id, email, full_name, department, status)
  VALUES (NEW.id, NEW.email, NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'department',
    CASE WHEN first_user THEN 'approved'::public.approval_status ELSE 'pending'::public.approval_status END);
  IF first_user THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'super_admin');
  END IF;
  RETURN NEW;
END; $$;

CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE POLICY "own profile read" ON public.profiles FOR SELECT TO authenticated
USING (id = auth.uid() OR public.is_approved(auth.uid()));
CREATE POLICY "own profile update" ON public.profiles FOR UPDATE TO authenticated
USING (id = auth.uid() OR public.has_role(auth.uid(),'super_admin'))
WITH CHECK (id = auth.uid() OR public.has_role(auth.uid(),'super_admin'));
CREATE POLICY "admin delete profiles" ON public.profiles FOR DELETE TO authenticated
USING (public.has_role(auth.uid(),'super_admin'));

CREATE POLICY "roles read" ON public.user_roles FOR SELECT TO authenticated
USING (user_id = auth.uid() OR public.is_approved(auth.uid()));
CREATE POLICY "roles admin write" ON public.user_roles FOR ALL TO authenticated
USING (public.has_role(auth.uid(),'super_admin'))
WITH CHECK (public.has_role(auth.uid(),'super_admin'));

-- CUSTOMERS
CREATE TABLE public.customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  contact_person text,
  phone text,
  email text,
  id_proof text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.customers TO authenticated;
GRANT ALL ON public.customers TO service_role;
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "customers read" ON public.customers FOR SELECT TO authenticated USING (public.is_approved(auth.uid()));
CREATE POLICY "customers write" ON public.customers FOR ALL TO authenticated
USING (public.can_act(auth.uid(),'sales')) WITH CHECK (public.can_act(auth.uid(),'sales'));

-- BOLS
CREATE TABLE public.bols (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bol_number text NOT NULL UNIQUE,
  file_reference_number text NOT NULL,
  supplier text NOT NULL,
  shipment_date date,
  notes text,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.bols TO authenticated;
GRANT ALL ON public.bols TO service_role;
ALTER TABLE public.bols ENABLE ROW LEVEL SECURITY;
CREATE POLICY "bols read" ON public.bols FOR SELECT TO authenticated USING (public.is_approved(auth.uid()));
CREATE POLICY "bols write" ON public.bols FOR ALL TO authenticated
USING (public.can_act(auth.uid(),'procurement')) WITH CHECK (public.can_act(auth.uid(),'procurement'));

-- INVOICES
CREATE TABLE public.invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_number text NOT NULL UNIQUE,
  customer_id uuid REFERENCES public.customers(id),
  invoice_date date NOT NULL DEFAULT CURRENT_DATE,
  payment_method text,
  payment_confirmed boolean NOT NULL DEFAULT false,
  payment_confirmed_at timestamptz,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.invoices TO authenticated;
GRANT ALL ON public.invoices TO service_role;
ALTER TABLE public.invoices ENABLE ROW LEVEL SECURITY;
CREATE POLICY "invoices read" ON public.invoices FOR SELECT TO authenticated USING (public.is_approved(auth.uid()));
CREATE POLICY "invoices write" ON public.invoices FOR ALL TO authenticated
USING (public.can_act(auth.uid(),'accounts')) WITH CHECK (public.can_act(auth.uid(),'accounts'));

-- CHASSIS
CREATE TABLE public.chassis (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chassis_number text NOT NULL UNIQUE,
  engine_number text UNIQUE,
  bol_id uuid NOT NULL REFERENCES public.bols(id) ON DELETE CASCADE,
  status public.chassis_status NOT NULL DEFAULT 'ordered',
  model text,
  customer_id uuid REFERENCES public.customers(id),
  invoice_id uuid REFERENCES public.invoices(id),
  registration_number text,
  registration_date date,
  shipped_at timestamptz,
  in_transit_at timestamptz,
  at_port_at timestamptz,
  at_plant_at timestamptz,
  produced_at timestamptz,
  allocated_at timestamptz,
  invoiced_at timestamptz,
  paid_at timestamptz,
  delivery_authorized_at timestamptz,
  delivered_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.chassis TO authenticated;
GRANT ALL ON public.chassis TO service_role;
ALTER TABLE public.chassis ENABLE ROW LEVEL SECURITY;
CREATE POLICY "chassis read" ON public.chassis FOR SELECT TO authenticated USING (public.is_approved(auth.uid()));
CREATE POLICY "chassis insert" ON public.chassis FOR INSERT TO authenticated
WITH CHECK (public.can_act(auth.uid(),'procurement'));
CREATE POLICY "chassis update" ON public.chassis FOR UPDATE TO authenticated
USING (
  public.can_act(auth.uid(),'procurement') OR public.can_act(auth.uid(),'clearing')
  OR public.can_act(auth.uid(),'production') OR public.can_act(auth.uid(),'sales')
  OR public.can_act(auth.uid(),'accounts') OR public.can_act(auth.uid(),'store')
) WITH CHECK (public.is_approved(auth.uid()));
CREATE POLICY "chassis delete" ON public.chassis FOR DELETE TO authenticated
USING (public.has_role(auth.uid(),'super_admin'));

CREATE INDEX chassis_status_idx ON public.chassis(status);
CREATE INDEX chassis_bol_idx ON public.chassis(bol_id);

-- GATE PASSES
CREATE TABLE public.gate_passes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  gate_pass_number text NOT NULL UNIQUE,
  chassis_id uuid NOT NULL UNIQUE REFERENCES public.chassis(id) ON DELETE CASCADE,
  receiver_name text NOT NULL,
  receiver_id_proof text NOT NULL,
  signature_verified boolean NOT NULL DEFAULT false,
  delivery_date date NOT NULL DEFAULT CURRENT_DATE,
  issued_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.gate_passes TO authenticated;
GRANT ALL ON public.gate_passes TO service_role;
ALTER TABLE public.gate_passes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "gate passes read" ON public.gate_passes FOR SELECT TO authenticated USING (public.is_approved(auth.uid()));
CREATE POLICY "gate passes write" ON public.gate_passes FOR ALL TO authenticated
USING (public.can_act(auth.uid(),'store')) WITH CHECK (public.can_act(auth.uid(),'store'));

-- AUDIT LOG
CREATE TABLE public.audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id uuid,
  actor_email text,
  entity text NOT NULL,
  entity_id uuid,
  entity_label text,
  action text NOT NULL,
  details jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.audit_log TO authenticated;
GRANT ALL ON public.audit_log TO service_role;
ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY "audit read" ON public.audit_log FOR SELECT TO authenticated USING (public.is_approved(auth.uid()));
CREATE POLICY "audit insert" ON public.audit_log FOR INSERT TO authenticated WITH CHECK (public.is_approved(auth.uid()));

-- lifecycle rank helper
CREATE OR REPLACE FUNCTION public.status_rank(_s public.chassis_status)
RETURNS int LANGUAGE sql IMMUTABLE AS $$
  SELECT CASE _s
    WHEN 'ordered' THEN 0 WHEN 'shipped' THEN 1 WHEN 'in_transit' THEN 2 WHEN 'at_port' THEN 3
    WHEN 'at_plant' THEN 4 WHEN 'produced' THEN 5 WHEN 'allocated' THEN 6 WHEN 'invoiced' THEN 7
    WHEN 'paid' THEN 8 WHEN 'delivery_authorized' THEN 9 WHEN 'delivered' THEN 10 END;
$$;

CREATE OR REPLACE FUNCTION public.enforce_chassis_rules()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
DECLARE old_rank int; new_rank int; existing uuid;
BEGIN
  NEW.updated_at := now();
  old_rank := public.status_rank(OLD.status);
  new_rank := public.status_rank(NEW.status);
  -- no skipping forward stages
  IF new_rank > old_rank + 1 THEN
    RAISE EXCEPTION 'A chassis cannot skip a lifecycle stage (% -> %)', OLD.status, NEW.status;
  END IF;
  -- clearing requires engine number
  IF new_rank >= 4 AND NEW.engine_number IS NULL THEN
    RAISE EXCEPTION 'Engine number must be assigned before the chassis can be cleared';
  END IF;
  -- one chassis can never move between invoices
  IF OLD.invoice_id IS NOT NULL AND NEW.invoice_id IS DISTINCT FROM OLD.invoice_id THEN
    SELECT invoice_number INTO existing FROM public.invoices WHERE id = OLD.invoice_id;
    RAISE EXCEPTION 'This chassis number is already assigned to an invoice.';
  END IF;
  -- re-allocation only before invoicing
  IF OLD.invoice_id IS NOT NULL AND NEW.customer_id IS DISTINCT FROM OLD.customer_id THEN
    RAISE EXCEPTION 'This chassis is invoiced and can no longer be re-allocated.';
  END IF;
  IF new_rank >= 7 AND NEW.invoice_id IS NULL THEN
    RAISE EXCEPTION 'An invoice number is required before billing this chassis';
  END IF;
  RETURN NEW;
END; $$;

CREATE TRIGGER chassis_rules BEFORE UPDATE ON public.chassis
FOR EACH ROW EXECUTE FUNCTION public.enforce_chassis_rules();

CREATE OR REPLACE FUNCTION public.log_chassis_change()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.audit_log (actor_id, actor_email, entity, entity_id, entity_label, action, details)
  VALUES (
    auth.uid(),
    (SELECT email FROM public.profiles WHERE id = auth.uid()),
    'chassis', NEW.id, NEW.chassis_number,
    CASE WHEN TG_OP = 'INSERT' THEN 'created' ELSE 'updated' END,
    jsonb_build_object(
      'old_status', CASE WHEN TG_OP='UPDATE' THEN OLD.status::text ELSE NULL END,
      'new_status', NEW.status::text,
      'engine_number', NEW.engine_number,
      'invoice_id', NEW.invoice_id,
      'customer_id', NEW.customer_id
    )
  );
  RETURN NEW;
END; $$;

CREATE TRIGGER chassis_audit AFTER INSERT OR UPDATE ON public.chassis
FOR EACH ROW EXECUTE FUNCTION public.log_chassis_change();

-- realtime
ALTER TABLE public.chassis REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.chassis;

-- ============ DEMO SEED ============
INSERT INTO public.customers (id, name, contact_person, phone, email, id_proof) VALUES
 ('11111111-1111-4111-8111-111111111101','Sunrise Transporters Ltd','Peter Kimani','+254700111222','peter@sunrisetrans.co.ke','ID 22114455'),
 ('11111111-1111-4111-8111-111111111102','Rift Valley Logistics','Amina Yusuf','+254700333444','amina@rvlogistics.com','ID 30991122'),
 ('11111111-1111-4111-8111-111111111103','Coastal Freight Co','Daniel Otieno','+254700555666','daniel@coastalfreight.co','ID 28773344'),
 ('11111111-1111-4111-8111-111111111104','Mount Kenya Motors','Grace Wanjiru','+254700777888','grace@mkmotors.co.ke','ID 31556677');

INSERT INTO public.bols (id, bol_number, file_reference_number, supplier, shipment_date, notes) VALUES
 ('22222222-2222-4222-8222-222222222201','BOL-2026-0041','CHA/FR/2026/0041','Hino Motors Japan','2026-05-12','40 x FG8J CKD kits'),
 ('22222222-2222-4222-8222-222222222202','BOL-2026-0042','CHA/FR/2026/0042','Isuzu East Africa CKD','2026-06-03','NQR 500 kits'),
 ('22222222-2222-4222-8222-222222222203','BOL-2026-0043','CHA/FR/2026/0043','Hino Motors Japan','2026-07-18','300 series kits'),
 ('22222222-2222-4222-8222-222222222204','BOL-2026-0044','CHA/FR/2026/0044','Tata Motors CKD Div','2026-08-09','LPT 1618 kits');

INSERT INTO public.invoices (id, invoice_number, customer_id, invoice_date, payment_method, payment_confirmed, payment_confirmed_at) VALUES
 ('33333333-3333-4333-8333-333333333301','INV-2026-0117','11111111-1111-4111-8111-111111111101','2026-07-22','Letter of Credit',true,'2026-07-28 09:00+00'),
 ('33333333-3333-4333-8333-333333333302','INV-2026-0118','11111111-1111-4111-8111-111111111102','2026-08-01','Full Payment',true,'2026-08-04 11:30+00'),
 ('33333333-3333-4333-8333-333333333303','INV-2026-0119','11111111-1111-4111-8111-111111111103','2026-08-11','Approved Credit Terms',false,NULL);

-- chassis: generated across lifecycle stages
INSERT INTO public.chassis (chassis_number, engine_number, bol_id, model, status, customer_id, invoice_id, registration_number, registration_date,
  shipped_at, in_transit_at, at_port_at, at_plant_at, produced_at, allocated_at, invoiced_at, paid_at, delivery_authorized_at, delivered_at)
SELECT
  'CKD' || to_char(g, 'FM0000') || 'X',
  CASE WHEN st >= 3 THEN 'ENG' || to_char(g,'FM0000') || 'J' ELSE NULL END,
  b.id,
  b.model,
  st_name,
  CASE WHEN st >= 6 THEN cust END,
  CASE WHEN st >= 7 THEN inv END,
  CASE WHEN st >= 7 THEN 'KDL ' || to_char(g,'FM000') || 'Q' END,
  CASE WHEN st >= 7 THEN date '2026-08-01' + g END,
  CASE WHEN st >= 1 THEN timestamptz '2026-06-01 08:00+00' + (g || ' hours')::interval END,
  CASE WHEN st >= 2 THEN timestamptz '2026-06-06 08:00+00' + (g || ' hours')::interval END,
  CASE WHEN st >= 3 THEN timestamptz '2026-06-20 08:00+00' + (g || ' hours')::interval END,
  CASE WHEN st >= 4 THEN timestamptz '2026-06-27 08:00+00' + (g || ' hours')::interval END,
  CASE WHEN st >= 5 THEN timestamptz '2026-07-05 08:00+00' + (g || ' hours')::interval END,
  CASE WHEN st >= 6 THEN timestamptz '2026-07-20 08:00+00' + (g || ' hours')::interval END,
  CASE WHEN st >= 7 THEN timestamptz '2026-07-28 08:00+00' + (g || ' hours')::interval END,
  CASE WHEN st >= 8 THEN timestamptz '2026-08-02 08:00+00' + (g || ' hours')::interval END,
  CASE WHEN st >= 9 THEN timestamptz '2026-08-08 08:00+00' + (g || ' hours')::interval END,
  CASE WHEN st >= 10 THEN timestamptz '2026-08-14 08:00+00' + (g || ' hours')::interval END
FROM generate_series(1, 64) AS g
CROSS JOIN LATERAL (
  SELECT CASE
    WHEN g <= 6 THEN 0 WHEN g <= 12 THEN 1 WHEN g <= 20 THEN 2 WHEN g <= 26 THEN 3
    WHEN g <= 34 THEN 4 WHEN g <= 42 THEN 5 WHEN g <= 47 THEN 6 WHEN g <= 52 THEN 7
    WHEN g <= 56 THEN 8 WHEN g <= 59 THEN 9 ELSE 10 END AS st
) s
CROSS JOIN LATERAL (
  SELECT (ARRAY['ordered','shipped','in_transit','at_port','at_plant','produced','allocated','invoiced','paid','delivery_authorized','delivered']::public.chassis_status[])[s.st + 1] AS st_name
) sn
CROSS JOIN LATERAL (
  SELECT id, (ARRAY['Hino FG8J','Isuzu NQR 500','Hino 300 Series','Tata LPT 1618'])[1 + (g % 4)] AS model
  FROM public.bols ORDER BY bol_number OFFSET (g % 4) LIMIT 1
) b
CROSS JOIN LATERAL (
  SELECT (ARRAY['11111111-1111-4111-8111-111111111101','11111111-1111-4111-8111-111111111102','11111111-1111-4111-8111-111111111103','11111111-1111-4111-8111-111111111104'])[1 + (g % 4)]::uuid AS cust
) c
CROSS JOIN LATERAL (
  SELECT (ARRAY['33333333-3333-4333-8333-333333333301','33333333-3333-4333-8333-333333333302','33333333-3333-4333-8333-333333333303'])[1 + (g % 3)]::uuid AS inv
) i;

INSERT INTO public.gate_passes (gate_pass_number, chassis_id, receiver_name, receiver_id_proof, signature_verified, delivery_date, issued_by)
SELECT 'GP-2026-' || to_char(row_number() OVER (ORDER BY chassis_number), 'FM000'), id, 'Authorized Representative', 'ID 2299' || to_char(row_number() OVER (ORDER BY chassis_number),'FM00'), true, delivered_at::date, NULL
FROM public.chassis WHERE status = 'delivered';
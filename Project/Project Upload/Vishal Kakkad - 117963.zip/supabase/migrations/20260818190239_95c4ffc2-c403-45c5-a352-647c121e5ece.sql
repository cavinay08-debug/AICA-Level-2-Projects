CREATE TABLE public.purchase_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  po_number text NOT NULL UNIQUE,
  supplier text NOT NULL,
  model text,
  quantity integer NOT NULL CHECK (quantity > 0),
  order_date date NOT NULL DEFAULT CURRENT_DATE,
  notes text,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.purchase_orders TO authenticated;
GRANT ALL ON public.purchase_orders TO service_role;

ALTER TABLE public.purchase_orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "purchase orders read" ON public.purchase_orders
  FOR SELECT TO authenticated USING (public.is_approved(auth.uid()));
CREATE POLICY "purchase orders write" ON public.purchase_orders
  FOR ALL TO authenticated
  USING (public.can_act(auth.uid(), 'procurement'::app_role))
  WITH CHECK (public.can_act(auth.uid(), 'procurement'::app_role));

ALTER TABLE public.bols ADD COLUMN po_id uuid REFERENCES public.purchase_orders(id);
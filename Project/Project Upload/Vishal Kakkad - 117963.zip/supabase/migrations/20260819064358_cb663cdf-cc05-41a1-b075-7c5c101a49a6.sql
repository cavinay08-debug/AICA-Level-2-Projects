CREATE OR REPLACE FUNCTION public.can_act(_user_id uuid, _role app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
  SELECT public.is_approved(_user_id)
    AND (
      public.has_role(_user_id,'super_admin')
      OR (public.has_role(_user_id,'management') AND _role <> 'super_admin')
      OR public.has_role(_user_id,_role)
    );
$$;
REVOKE ALL ON FUNCTION public.can_act(uuid, app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.can_act(uuid, app_role) TO authenticated, service_role;

DROP POLICY IF EXISTS "customers read" ON public.customers;
CREATE POLICY "customers read" ON public.customers FOR SELECT TO authenticated
USING (
  public.has_role(auth.uid(),'super_admin')
  OR public.can_act(auth.uid(),'sales')
  OR public.can_act(auth.uid(),'accounts')
  OR public.can_act(auth.uid(),'store')
);

DROP POLICY IF EXISTS "gate passes read" ON public.gate_passes;
CREATE POLICY "gate passes read" ON public.gate_passes FOR SELECT TO authenticated
USING (
  public.has_role(auth.uid(),'super_admin')
  OR public.can_act(auth.uid(),'store')
  OR public.can_act(auth.uid(),'sales')
);

DROP POLICY IF EXISTS "roles read" ON public.user_roles;
CREATE POLICY "roles read" ON public.user_roles FOR SELECT TO authenticated
USING (user_id = auth.uid() OR public.has_role(auth.uid(),'super_admin'));

REVOKE ALL ON FUNCTION public.status_rank(chassis_status) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.status_rank(chassis_status) TO authenticated, service_role;
REVOKE ALL ON FUNCTION public.has_role(uuid, app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, app_role) TO authenticated, service_role;
REVOKE ALL ON FUNCTION public.is_approved(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_approved(uuid) TO authenticated, service_role;
-- Engine number becomes the primary identifier at ordering time; chassis number is assigned later by clearing.
UPDATE public.chassis SET engine_number = 'ENG-' || chassis_number WHERE engine_number IS NULL;
ALTER TABLE public.chassis ALTER COLUMN engine_number SET NOT NULL;
ALTER TABLE public.chassis ALTER COLUMN chassis_number DROP NOT NULL;
ALTER TABLE public.bols ALTER COLUMN file_reference_number DROP NOT NULL;

CREATE OR REPLACE FUNCTION public.enforce_chassis_rules()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path TO 'public'
AS $function$
DECLARE old_rank int; new_rank int;
BEGIN
  NEW.updated_at := now();
  old_rank := public.status_rank(OLD.status);
  new_rank := public.status_rank(NEW.status);
  -- shipped by supplier and in transit are the same operational stage
  IF new_rank > old_rank + 1 AND NOT (OLD.status = 'ordered' AND NEW.status = 'in_transit') THEN
    RAISE EXCEPTION 'A chassis cannot skip a lifecycle stage (% -> %)', OLD.status, NEW.status;
  END IF;
  -- clearing must assign a chassis number to the engine before it moves to the plant
  IF new_rank >= 4 AND (NEW.chassis_number IS NULL OR NEW.chassis_number = '') THEN
    RAISE EXCEPTION 'A chassis number must be assigned to this engine number before clearing';
  END IF;
  IF OLD.invoice_id IS NOT NULL AND NEW.invoice_id IS DISTINCT FROM OLD.invoice_id THEN
    RAISE EXCEPTION 'This unit is already assigned to an invoice.';
  END IF;
  IF OLD.invoice_id IS NOT NULL AND NEW.customer_id IS DISTINCT FROM OLD.customer_id THEN
    RAISE EXCEPTION 'This unit is invoiced and can no longer be re-allocated.';
  END IF;
  IF new_rank >= 7 AND NEW.invoice_id IS NULL THEN
    RAISE EXCEPTION 'An invoice number is required before billing this unit';
  END IF;
  RETURN NEW;
END; $function$;

CREATE OR REPLACE FUNCTION public.log_chassis_change()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  INSERT INTO public.audit_log (actor_id, actor_email, entity, entity_id, entity_label, action, details)
  VALUES (
    auth.uid(),
    (SELECT email FROM public.profiles WHERE id = auth.uid()),
    'chassis', NEW.id, COALESCE(NEW.chassis_number, NEW.engine_number),
    CASE WHEN TG_OP = 'INSERT' THEN 'created' ELSE 'updated' END,
    jsonb_build_object(
      'old_status', CASE WHEN TG_OP='UPDATE' THEN OLD.status::text ELSE NULL END,
      'new_status', NEW.status::text,
      'engine_number', NEW.engine_number,
      'chassis_number', NEW.chassis_number,
      'invoice_id', NEW.invoice_id,
      'customer_id', NEW.customer_id
    )
  );
  RETURN NEW;
END; $function$;
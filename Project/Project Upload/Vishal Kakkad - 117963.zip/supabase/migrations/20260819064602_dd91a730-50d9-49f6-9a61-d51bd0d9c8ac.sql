DROP POLICY IF EXISTS "chassis delete" ON public.chassis;
CREATE POLICY "chassis delete" ON public.chassis FOR DELETE TO authenticated
USING (
  public.has_role(auth.uid(),'super_admin')
  OR (public.can_act(auth.uid(),'procurement') AND status IN ('ordered','shipped'))
);
# Sample files for a demonstration

Three workbooks that stand in for a real month, so the tool can be shown working
without opening anybody's actual books.

| File | Stands in for |
|---|---|
| `Sample 1 Tally Books.xlsx` | the GSTR-3B working exported from Tally |
| `Sample 2 GSTR2B.xlsx` | the GSTR-2B downloaded from the GST portal |
| `Sample 3 Pending Master.xlsx` | last month's pending master |
| `Sample 4 Credit Ledger.xlsx` | the electronic credit ledger from the portal (optional) |
| `Sample 5 GST Ledgers.xlsx` | the nine GST ledgers from Tally (optional) |

**Everything in them is invented.** The company is *Meridian Traders Private Limited*, the
suppliers do not exist, and no figure comes from the client's books. The month is
**August 2026**, and the pending master carries items from June and July 2026 plus one
from April 2024.

---

## Running the demonstration

In the window: press **Browse** for each of the three files above, or use **Pick a folder
containing all three** and choose this `Sample` folder. Set the month to **August / 2026**
if you want to show the period cross-check. Choose any output folder.

From the command line, in the folder above this one:

```bash
python -m gstrecon --input Sample --output Sample\Output --folder --no-open --ledger "Sample\Sample 4 Credit Ledger.xlsx" --ledgers "Sample\Sample 5 GST Ledgers.xlsx"
```

---

## What the demonstration shows

The figures are small enough to follow by eye but the file set is built to make every
part of the tool do something.

**Matching**
- 19 invoices match exactly
- one matches only after the document number is cleaned up (`SP-2627-0461` against `SP26270461`)
- one matches on the last six characters (`TL/AUG/2026/0031` against `TLG/AUG/2026/0031`)
- two are **probable matches** with nothing in common but the supplier, the tax and the
  date, waiting on the `Confirmed` column
- one document number is used on two vouchers and is compared on the group total

**Exceptions, all on Require Correction**
- a supplier GSTIN captured for Maharashtra when the portal shows Delhi
- tax booked as CGST and SGST that the supplier reported as IGST
- the same invoice at two different values, Rs 1,080 apart
- one invoice released from April 2024, now **time barred under section 16(4)**

Note the GSTIN case is listed twice, once from each side. That is deliberate: the books
row and the GSTR-2B row each need looking at.

**Credit**
- six eligible invoices are missing from GSTR-2B, so the credit is **deferred**
- blocked credit under section 17(5) (catering, cab hire, travel) is claimed in 4(A)(5)
  and reversed in 4(B)(1), including one that never reached GSTR-2B at all
- a credit note is carried **negative**
- reverse charge, import of goods, import of services and **ISD credit** all appear, so
  Tables 4(A)(1) to 4(A)(4) are populated and each has its own schedule

**Across months**
- two invoices deferred in June and July turn up in this month's GSTR-2B and are claimed
- one blocked-credit item clears with no add back
- one GSTR-2B document carried from July is finally booked this month
- a probable match **rejected last July** is remembered and no longer suggested; it shows
  in the second block at the foot of the Probable Matches sheet
- Yamuna Chemicals has failed to report in three separate months, so it comes out
  **Critical** on the Supplier Watchlist

---

## Changing the demonstration

`make_sample_files.py` builds all three files. Edit the tables near the top of it and run:

```bash
python Sample\make_sample_files.py
```

The `fate` column on each purchase row decides what GSTR-2B will contain for it, which is
how the exceptions above are produced.

"""
Builds the three demo workbooks in this folder.

Everything here is invented. No real supplier, GSTIN or figure from the client's
books appears anywhere in it. The point is a file set that exercises every part
of the tool, so a demonstration shows the exception handling rather than a page
of clean matches.

Run it with:   python Sample\\make_sample_files.py

What the demo deliberately contains:

  exact, cleaned and partial document-number matches, and two probable matches
  a document number used twice in the books, compared on the group total
  a supplier GSTIN captured for the wrong state
  tax booked under the wrong head
  the same invoice at two different values
  eligible credit missing from GSTR-2B, so it is deferred
  blocked credit missing from GSTR-2B, which is claimed and reversed instead
  a credit note, carried negative
  reverse charge, import of goods, import of services and ISD credit
  two invoices deferred in earlier months that turn up in this month's GSTR-2B
  one deferred in April 2024, now time barred under section 16(4)
  a supplier who has failed to report in three separate months
  a decision already taken on a probable match last month
"""

from __future__ import annotations

import datetime as dt
import os

import openpyxl
from openpyxl.styles import Font

HERE = os.path.dirname(os.path.abspath(__file__))

COMPANY = "MERIDIAN TRADERS PRIVATE LIMITED"
ADDRESS = ["PLOT 14, OKHLA INDUSTRIAL AREA PHASE II", "NEW DELHI-110020",
           "CIN: U51909DL2004PTC123456", "E-Mail : accounts@meridiantraders.example"]
GSTIN = "07AABCM1234K1ZP"
PERIOD = "1-Aug-26 to 31-Aug-26"
PERIOD_END = dt.date(2026, 8, 31)

BOLD = Font(bold=True)


def d(day, month=8, year=2026):
    return dt.date(year, month, day)


def ddmmyyyy(date):
    return date.strftime("%d/%m/%Y")


def tax(gstin, taxable, rate):
    """Delhi supplier to a Delhi buyer is CGST plus SGST; anyone else is IGST."""
    total = round(taxable * rate / 100.0, 2)
    if str(gstin).startswith("07"):
        half = round(total / 2.0, 2)
        return 0.0, half, half
    return total, 0.0, 0.0


# --------------------------------------------------------------------------
# Suppliers
# --------------------------------------------------------------------------

S = {
    "pragati":  ("PRAGATI STATIONERS PVT LTD", "07AAACP1234K1ZV", "Delhi"),
    "sunrise":  ("SUNRISE PACKAGING LLP", "07AABCS5678L1ZQ", "Delhi"),
    "tara":     ("TARA LOGISTICS PVT LTD", "07AACCT9012M1ZR", "Delhi"),
    "urban":    ("URBAN OFFICE SOLUTIONS", "07AADCU3456N1ZS", "Delhi"),
    "vista":    ("VISTA ELECTRICALS PVT LTD", "27AAECV7890P1ZT", "Maharashtra"),
    "western":  ("WESTERN COMPONENTS LTD", "29AAFCW1234Q1ZU", "Karnataka"),
    "xenon":    ("XENON INDUSTRIES PVT LTD", "06AAGCX5678R1ZW", "Haryana"),
    "yamuna":   ("YAMUNA CHEMICALS PVT LTD", "09AAHCY9012S1ZX", "Uttar Pradesh"),
    "zenith":   ("ZENITH POLYMERS PVT LTD", "24AAJCZ3456T1ZY", "Gujarat"),
    "ananth":   ("ANANTH TEXTILES PVT LTD", "33AAKCA7890U1ZZ", "Tamil Nadu"),
    "bluebird": ("BLUEBIRD CATERERS", "07AALCB1234V1ZA", "Delhi"),
    "citycab":  ("CITY CAB SERVICES", "19AAMCC5678W1ZB", "West Bengal"),
    "delhitrv": ("DELHI TRAVELS", "07AANCD9012X1ZC", "Delhi"),
    "eastern":  ("EASTERN ROADWAYS", "08AAOCE3456Y1ZD", "Rajasthan"),
    "falcon":   ("FALCON SECURITY SERVICES", "07AAPCF7890Z1ZE", "Delhi"),
    "globe":    ("GLOBE FREIGHT SOLUTIONS", "27AAQCG1234A1ZF", "Maharashtra"),
    "isd":      ("MERIDIAN SHARED SERVICES", "07AARCH5678B1ZG", "Delhi"),
}


# --------------------------------------------------------------------------
# This month's purchase register
# --------------------------------------------------------------------------
# fate says what GSTR-2B should contain for the row:
#   exact       the same document number
#   norm        the same number with the separators stripped out
#   tail        a different prefix, same ending
#   probable    an unrelated number, same tax, a nearby date
#   none        nothing at all
#   wrong_gstin the same document under the supplier's other state code
#   wrong_head  the same document with the tax under the other head
#   value_diff  the same document at a different value

BOOKS = [
    # vch,  supplier,   doc no,              date,     taxable,  rate, fate,     alt 2B doc
    (1001, "pragati",  "PS/26-27/0112",      d(4),      45000,   18, "exact",    None),
    (1002, "pragati",  "PS/26-27/0118",      d(9),      26000,   18, "exact",    None),
    (1003, "sunrise",  "SP-2627-0455",       d(5),     132000,   18, "exact",    None),
    (1004, "sunrise",  "SP-2627-0461",       d(12),     88000,   18, "norm",     "SP26270461"),
    (1005, "tara",     "TL/AUG/2026/0031",   d(6),      61000,   18, "tail",     "TLG/AUG/2026/0031"),
    (1006, "urban",    "UOS/1290",           d(7),      34000,   18, "probable", "INV-77410"),
    (1007, "vista",    "VE/26-27/778",       d(8),     210000,   18, "exact",    None),
    (1008, "western",  "WC-4471",            d(11),    156000,   18, "exact",    None),
    (1009, "xenon",    "XI/2026/0912",       d(13),     98000,   18, "none",     None),
    (1010, "yamuna",   "YC-8823",            d(14),     74000,   18, "none",     None),
    (1011, "zenith",   "ZP/26-27/155",       d(15),    187000,   18, "exact",    None),
    (1012, "ananth",   "AT-2026-0338",       d(18),    245000,    5, "exact",    None),
    (1013, "globe",    "GF/26-27/0091",      d(19),     52000,   18, "wrong_gstin", None),
    (1014, "pragati",  "PS/26-27/0125",      d(20),     18000,   18, "wrong_head",  None),
    (1015, "sunrise",  "SP-2627-0470",       d(21),     66000,   18, "value_diff",  None),
    (1016, "vista",    "VE/26-27/802",       d(22),     41000,   18, "exact",    None),
    (1017, "tara",     "TL/AUG/2026/0044",   d(24),     29500,   18, "exact",    None),
    (1018, "western",  "WC-4502",            d(25),     63000,   18, "exact",    None),
    # the same document number on two vouchers, compared on the group total
    (1019, "zenith",   "ZP/26-27/160",       d(26),     40000,   18, "group",    None),
    (1020, "zenith",   "ZP/26-27/160",       d(26),     35000,   18, "group",    None),
    (1021, "xenon",    "XI/2026/0940",       d(27),    112000,   18, "exact",    None),
    (1022, "ananth",   "AT-2026-0351",       d(28),     89000,    5, "none",     None),
    (1023, "vista",    "VE/CN/26-27/12",     d(29),    -15000,   18, "credit",   None),
    (1024, "bluebird", "BC/2026/221",        d(26),     28000,    5, "exact",    None),
    (1025, "citycab",  "CCS-7781",           d(17),     36000,    5, "exact",    None),
    (1026, "delhitrv", "DT/26-27/318",       d(23),     22000,    5, "none",     None),
    (1027, "pragati",  "PS/26-27/0131",      d(29),     12000,   18, "probable", "INV-88213"),
    # booked this month against a GSTR-2B document carried from July
    (1028, "urban",    "UOS/1250",           d(3),      31000,   18, "none",     None),
]

INELIGIBLE_VCH = {1024, 1025, 1026}      # section 17(5) - food, cab hire, travel

# Reverse charge register. The last two are blocked credit as well, which is why
# Tally's Ineligible ITC register carries them too.
RCM = [
    (1501, "eastern", "ER/GTA/26-27/210", d(10),  85000,  5),
    (1502, "falcon",  "FS/26-27/077",     d(16),  60000, 18),
    (1503, "eastern", "ER/GTA/26-27/241", d(27),  47000,  5),
]
RCM_INELIGIBLE_VCH = {1503}

IMPS = [(1601, "OVERSEAS DESIGN STUDIO", "OD-2026-114", d(12), 260000, 18)]
IMPG = [(1701, "IMPORT OF GOODS - BILL OF ENTRY 3312455", "3312455", d(9), 1450000, 18)]

# Outward supplies, needed only so Table 3.1(a) has a schedule behind it
SALES = [
    (2001, "AURORA RETAIL PVT LTD",  "27AASCA1111B1ZH", d(5),  3250000, 18),
    (2002, "BENGAL DISTRIBUTORS",    "19AATCB2222C1ZI", d(11), 1875000, 18),
    (2003, "CAPITAL WHOLESALE",      "07AAUCC3333D1ZJ", d(18), 2410000, 18),
    (2004, "DECCAN TRADING CO",      "36AAVCD4444E1ZK", d(25), 1640000, 12),
]

ISD_2B = [("ISD/26-27/044", d(20), 0.0, 4500.0, 4500.0)]


def book_rows():
    """The All Other ITC register, as canonical dicts."""
    out = []
    for vch, key, doc, date, taxable, rate, fate, alt in BOOKS:
        name, gst, _ = S[key]
        i, c, sg = tax(gst, taxable, rate)
        out.append({"vch": vch, "key": key, "name": name, "gstin": gst, "doc": doc,
                    "date": date, "taxable": round(taxable, 2), "rate": rate,
                    "igst": i, "cgst": c, "sgst": sg, "fate": fate, "alt": alt})
    return out


# --------------------------------------------------------------------------
# The pending master carried in from July
# --------------------------------------------------------------------------
# released True means this month's GSTR-2B contains it, so the credit comes back

MASTER_BOOKS = [
    # month,   supplier,  doc,               date,          taxable, rate, released, ineligible
    ("Jul-26", "xenon",   "XI/2026/0855",    d(14, 7),        54000, 18,  True,  False),
    ("Jun-26", "western", "WC-4390",         d(21, 6),        42000, 18,  True,  False),
    ("Jul-26", "citycab", "CCS-7602",        d(9, 7),         24000,  5,  True,  True),
    ("Apr-24", "ananth",  "AT-2024-0077",    d(18, 4, 2024),  30000,  5,  True,  False),
    ("Jun-26", "yamuna",  "YC-8590",         d(12, 6),        51000, 18,  False, False),
    ("Jul-26", "yamuna",  "YC-8701",         d(23, 7),        47000, 18,  False, False),
    ("Jun-26", "zenith",  "ZP/26-27/090",    d(8, 6),         22000, 18,  False, False),
    ("Jul-26", "globe",   "GF/26-27/0080",   d(28, 7),        18000, 18,  False, False),
    ("Jul-26", "bluebird", "BC/2026/198",    d(30, 7),        14000,  5,  False, True),
]

# cleared in an earlier month, kept for history and greyed out by the tool
MASTER_BOOKS_CLEARED = [
    ("Jun-26", "pragati", "PS/26-27/0061", d(6, 6), 38000, 18, "Jul'26"),
    ("Jun-26", "vista",   "VE/26-27/640",  d(17, 6), 95000, 18, "Jul'26"),
]

MASTER_2B = [
    # month,   supplier,  doc,          date,      taxable, rate, booked_this_month
    ("Jul-26", "urban",   "UOS/1250",   d(28, 7),    31000, 18, True),
    ("Jul-26", "tara",    "TL/JUL/0019", d(19, 7),   26000, 18, False),
    ("Jun-26", "ananth",  "AT-2026-0210", d(11, 6),  73000,  5, False),
    ("Jun-26", "yamuna",  "YC-8455",    d(4, 6),     33000, 18, False),
    ("Jul-26", "zenith",  "ZP/26-27/121", d(25, 7),  58000, 18, False),
]


def master_book_rows():
    out = []
    for month, key, doc, date, taxable, rate, released, inelig in MASTER_BOOKS:
        name, gst, _ = S[key]
        i, c, sg = tax(gst, taxable, rate)
        out.append({"month": month, "name": name, "gstin": gst, "doc": doc, "date": date,
                    "taxable": round(taxable, 2), "igst": i, "cgst": c, "sgst": sg,
                    "released": released, "inelig": inelig})
    return out


def master_2b_rows():
    out = []
    for month, key, doc, date, taxable, rate, booked in MASTER_2B:
        name, gst, _ = S[key]
        i, c, sg = tax(gst, taxable, rate)
        out.append({"month": month, "name": name, "gstin": gst, "doc": doc, "date": date,
                    "taxable": round(taxable, 2), "igst": i, "cgst": c, "sgst": sg,
                    "booked": booked})
    return out


# --------------------------------------------------------------------------
# File 1 - the Tally export
# --------------------------------------------------------------------------

REG_COLS = ["Date", "Particulars", "Party GSTIN/UIN", "Vch Type", "Vch No.", "Doc No.",
            "Doc", "Taxable", "IGST", "CGST", "SGST/", "Cess", "Tax"]
REG_COLS2 = ["", "", "", "", "", "", "Date", "Amount", "", "", "UTGST", "", "Amount"]


def _preamble(ws, subtitle):
    ws.cell(row=1, column=1, value=COMPANY)
    for i, line in enumerate(ADDRESS, start=2):
        ws.cell(row=i, column=1, value=line)
    ws.cell(row=6, column=1, value="GSTR-3B - Voucher Register")
    ws.cell(row=7, column=1, value=PERIOD)
    ws.cell(row=8, column=1, value="GST Registration:")
    ws.cell(row=8, column=2, value=GSTIN)
    ws.cell(row=9, column=1, value="Vouchers of:")
    ws.cell(row=9, column=2, value=subtitle)


def _register(ws, subtitle, rows, with_gstin=True, with_doc=True):
    """A Tally voucher register: preamble, two-row heading, rows, then a Total."""
    _preamble(ws, subtitle)
    cols = list(REG_COLS)
    cols2 = list(REG_COLS2)
    if not with_gstin:
        cols.pop(2)
        cols2.pop(2)
    if not with_doc:
        i = cols.index("Doc No.")
        cols.pop(i)
        cols2.pop(i)
    for c, (a, b) in enumerate(zip(cols, cols2), start=1):
        ws.cell(row=10, column=c, value=a).font = BOLD
        ws.cell(row=11, column=c, value=b).font = BOLD

    r = 12
    tot = [0.0] * 5
    for rec in rows:
        vals = [rec["date"], rec["name"]]
        if with_gstin:
            vals.append(rec.get("gstin", ""))
        vals.append(rec.get("vch_type", "Purchase"))
        vals.append(str(rec["vch"]))
        if with_doc:
            vals.append(rec.get("doc", ""))
        vals.append(rec.get("doc_date") or rec["date"])
        amounts = [rec["taxable"], rec["igst"], rec["cgst"], rec["sgst"], None]
        line = vals + amounts + [round(rec["igst"] + rec["cgst"] + rec["sgst"], 2)]
        for c, v in enumerate(line, start=1):
            ws.cell(row=r, column=c, value=v)
        for i, v in enumerate((rec["taxable"], rec["igst"], rec["cgst"], rec["sgst"])):
            tot[i] += v
        tot[4] += rec["igst"] + rec["cgst"] + rec["sgst"]
        r += 1

    ws.cell(row=r, column=2, value="Total").font = BOLD
    base = len(cols) - 6
    for i, v in enumerate(tot[:4]):
        ws.cell(row=r, column=base + 1 + i, value=round(v, 2)).font = BOLD
    ws.cell(row=r, column=base + 6, value=round(tot[4], 2)).font = BOLD
    return {"taxable": round(tot[0], 2), "igst": round(tot[1], 2),
            "cgst": round(tot[2], 2), "sgst": round(tot[3], 2),
            "tax": round(tot[4], 2)}


def build_file1(path, books, rcm, imps, impg, sales):
    wb = openpyxl.Workbook()
    wb.remove(wb.active)

    ws3b = wb.create_sheet("GSTR-3B")
    wsinel = wb.create_sheet("Ineligible ITC")
    wsall = wb.create_sheet("All Other ITC")
    wsrcm = wb.create_sheet("RCM ITC Book")
    wsimps = wb.create_sheet("IMPS Books")
    wsimpg = wb.create_sheet("IMPG Books")
    ws31a = wb.create_sheet("Table 3.1a")
    ws31d = wb.create_sheet("Table 3.1d")

    for rec in books:
        rec.setdefault("vch_type", "Credit Note" if rec["taxable"] < 0 else "Purchase")
    t_all = _register(wsall, "All other Input Tax Credit", books)
    t_rcm = _register(wsrcm, "Inward Supplies applicable for Reverse Charge "
                             "(other than lines 1 & 2)", rcm)
    t_imps = _register(wsimps, "Import of Services", imps, with_gstin=False)
    t_impg = _register(wsimpg, "Import of Goods", impg, with_gstin=False)
    t_31a = _register(ws31a, "Outward Taxable Supplies (other than Zero Rated, "
                             "Nil Rated, and Exempted Supplies)", sales, with_doc=False)
    # Table 3.1(d) is import of services plus reverse charge, which is what the
    # tool checks it against.
    t_31d = _register(ws31d, "Inward Supplies (applicable for Reverse Charge)",
                      imps + rcm, with_gstin=False)

    # The blocked-credit register keeps its own shorter layout, the way Tally
    # produces it, so the sample exercises that reader path too.
    inelig = [r for r in books if r["vch"] in INELIGIBLE_VCH] + \
             [r for r in rcm if r["vch"] in RCM_INELIGIBLE_VCH]
    wsinel.cell(row=2, column=1, value="All other ITC")
    hdr = ["Date", "Particulars", "Party GSTIN/UIN", "Vch Type", "Vch No.",
           "Taxable", "IGST", "CGST", "SGST/", "Cess", "Tax"]
    for c, h in enumerate(hdr, start=1):
        wsinel.cell(row=3, column=c, value=h).font = BOLD
    r = 4
    tot = [0.0] * 5
    for rec in inelig:
        line = [rec["date"], rec["name"], rec["gstin"], rec.get("vch_type", "Purchase"),
                str(rec["vch"]), rec["taxable"], rec["igst"], rec["cgst"], rec["sgst"],
                None, round(rec["igst"] + rec["cgst"] + rec["sgst"], 2)]
        for c, v in enumerate(line, start=1):
            wsinel.cell(row=r, column=c, value=v)
        for i, v in enumerate((rec["taxable"], rec["igst"], rec["cgst"], rec["sgst"])):
            tot[i] += v
        tot[4] += rec["igst"] + rec["cgst"] + rec["sgst"]
        r += 1
    for i, v in enumerate(tot[:4]):
        wsinel.cell(row=r, column=6 + i, value=round(v, 2)).font = BOLD
    wsinel.cell(row=r, column=11, value=round(tot[4], 2)).font = BOLD

    # ---- the GSTR-3B summary page ---------------------------------------
    _preamble(ws3b, "")
    ws3b.cell(row=6, column=1, value="GSTR-3B")
    ws3b.cell(row=9, column=1, value="Status:")
    ws3b.cell(row=9, column=2, value="Not Filed")
    ws3b.cell(row=12, column=1, value="Particulars")
    ws3b.cell(row=12, column=2, value="Voucher Count")
    ws3b.cell(row=13, column=1, value="Total Vouchers")
    ws3b.cell(row=13, column=2, value=len(books) + len(rcm) + len(sales) + 2)
    for c, h in enumerate(["Particulars", "Taxable", "IGST", "CGST", "SGST/", "Cess", "Tax"],
                          start=1):
        ws3b.cell(row=17, column=c, value=h).font = BOLD
    ws3b.cell(row=18, column=2, value="Amount")
    ws3b.cell(row=18, column=5, value="UTGST")
    ws3b.cell(row=18, column=7, value="Amount")

    nil = {"taxable": 0, "igst": 0, "cgst": 0, "sgst": 0, "tax": 0}
    lines = [
        ("3.1 Tax on Outward and Reverse Charge Inward Supplies",
         {k: round(t_31a[k] + t_31d[k], 2) for k in t_31a}),
        ("3.1a. Outward Taxable Supplies (other than Zero Rated, Nil Rated and Exempted)",
         t_31a),
        ("3.1b. Outward Taxable Supplies (Zero Rated)", nil),
        ("3.1c. Other Outward Supplies (Nil Rated and Exempted)", nil),
        ("3.1d. Inward Supplies (applicable for Reverse Charge)", t_31d),
        ("3.1e. Non-GST Outward Supplies", nil),
    ]
    r = 20
    for label, t in lines:
        ws3b.cell(row=r, column=1, value=label)
        for i, k in enumerate(("taxable", "igst", "cgst", "sgst")):
            ws3b.cell(row=r, column=2 + i, value=t[k] or None)
        ws3b.cell(row=r, column=7, value=t["tax"] or None)
        r += 1
    r += 1
    ws3b.cell(row=r, column=1, value="5 Exempt, Nil Rated, and Non-GST Inward Supplies")
    ws3b.cell(row=r, column=2, value=48200)

    for ws in wb.worksheets:
        ws.column_dimensions["A"].width = 22
        ws.column_dimensions["B"].width = 42
        ws.column_dimensions["C"].width = 20
        for col in "DEFGHIJKLM":
            ws.column_dimensions[col].width = 15
    wb.save(path)
    return t_all, t_rcm, t_imps, t_impg, t_31a, t_31d


# --------------------------------------------------------------------------
# File 2 - the GSTR-2B download
# --------------------------------------------------------------------------

B2B_HDR = ["GSTIN of supplier", "Trade/Legal name", "Invoice number", "Invoice type",
           "Invoice Date", "Invoice Value(Rs)", "Place of supply",
           "Supply Attract Reverse Charge", "Taxable Value (Rs)", "Integrated Tax(Rs)",
           "Central Tax(Rs)", "State/UT Tax(Rs)", "Cess(Rs)",
           "GSTR-1/1A/IFF/GSTR-5 Period", "GSTR-1/1A/IFF/GSTR-5 Filing Date",
           "ITC Availability", "Reason", "Applicable % of Tax Rate", "Source",
           "IRN", "IRN Date"]


def b2b_line(gstin, name, doc, date, taxable, igst, cgst, sgst, pos, eligible="Yes",
             reason="", filed=None):
    value = round(taxable + igst + cgst + sgst, 2)
    return [gstin, name, doc, "Regular", ddmmyyyy(date), value, pos, "No",
            round(taxable, 2), igst, cgst, sgst, 0, "Aug'26",
            ddmmyyyy(filed or dt.date(2026, 9, 11)), eligible, reason, None,
            "e-Invoice", None, None]


def build_file2(path, books, mbooks):
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    wsread = wb.create_sheet("Read me")
    wsav = wb.create_sheet("ITC Available")
    wsb2b = wb.create_sheet("B2B")
    wscdnr = wb.create_sheet("B2B-CDNR")
    wsisd = wb.create_sheet("ISD")
    wsimpg = wb.create_sheet("IMPG")

    wsread.cell(row=1, column=1, value="FORM GSTR-2B")
    wsread.cell(row=2, column=1,
                value="Auto-drafted ITC statement. Sample data for demonstration only.")

    rows = []
    for rec in books:
        name, gst, pos = S[rec["key"]], None, None
        name, gst, pos = S[rec["key"]]
        elig = "No" if rec["vch"] in INELIGIBLE_VCH else "Yes"
        reason = "Others" if elig == "No" else ""
        fate = rec["fate"]
        if fate == "none":
            continue
        if fate == "credit":
            continue                                   # goes on the credit-note sheet
        if fate == "group":
            continue                                   # handled once, below
        doc = rec["doc"]
        gstin = gst
        i, c, sg = rec["igst"], rec["cgst"], rec["sgst"]
        taxable = rec["taxable"]
        if fate in ("norm", "tail", "probable"):
            doc = rec["alt"]
        elif fate == "wrong_gstin":
            gstin = "07" + gst[2:]                     # same PAN, wrong state captured
        elif fate == "wrong_head":
            i, c, sg = round(c + sg, 2), 0.0, 0.0      # booked as IGST by the supplier
        elif fate == "value_diff":
            taxable = 60000
            i, c, sg = tax(gst, taxable, rec["rate"])
        date = rec["date"] if fate != "probable" else rec["date"] - dt.timedelta(days=9)
        rows.append(b2b_line(gstin, name, doc, date, taxable, i, c, sg, pos, elig, reason))

    # the repeated document number, reported once by the supplier for the full value
    grp = [r for r in books if r["fate"] == "group"]
    if grp:
        name, gst, pos = S[grp[0]["key"]]
        taxable = round(sum(r["taxable"] for r in grp), 2)
        i, c, sg = tax(gst, taxable, grp[0]["rate"])
        rows.append(b2b_line(gst, name, grp[0]["doc"], grp[0]["date"], taxable,
                             i, c, sg, pos))

    # invoices deferred in earlier months that the supplier has now reported
    for rec in mbooks:
        if not rec["released"]:
            continue
        pos = S[[k for k, v in S.items() if v[1] == rec["gstin"]][0]][2]
        elig = "No" if rec["inelig"] else "Yes"
        rows.append(b2b_line(rec["gstin"], rec["name"], rec["doc"], rec["date"],
                             rec["taxable"], rec["igst"], rec["cgst"], rec["sgst"],
                             pos, elig, "Others" if elig == "No" else ""))

    # reported by suppliers but never booked
    extras = [
        ("zenith",  "ZP/26-27/171", d(23), 64000, 18),
        ("ananth",  "AT-2026-0362", d(26), 51000,  5),
        ("western", "WC-4530",      d(29), 38000, 18),
        ("pragati", "PS/26-27/0140", d(30), 9500, 18),
        ("tara",    "TL/AUG/2026/0052", d(31), 15500, 18),
    ]
    for key, doc, date, taxable, rate in extras:
        name, gst, pos = S[key]
        i, c, sg = tax(gst, taxable, rate)
        rows.append(b2b_line(gst, name, doc, date, taxable, i, c, sg, pos))

    for c, h in enumerate(B2B_HDR, start=1):
        wsb2b.cell(row=1, column=c, value=h).font = BOLD
    for r, line in enumerate(rows, start=2):
        for c, v in enumerate(line, start=1):
            wsb2b.cell(row=r, column=c, value=v)

    # ---- credit and debit notes -----------------------------------------
    wscdnr.cell(row=1, column=1, value="Goods and Services Tax - GSTR-2B")
    wscdnr.cell(row=4, column=1, value="Debit/Credit notes")
    top = ["GSTIN of supplier", "Trade/Legal name", "Credit note/Debit note details",
           "", "", "", "", "Place of supply", "Supply Attract Reverse Charge",
           "Taxable Value (Rs)", "Tax Amount", "", "", "", "ITC Availability", "Reason"]
    sub = ["", "", "Note number", "Note type", "Note Supply type", "Note date",
           "Note Value (Rs)", "", "", "", "Integrated Tax(Rs)", "Central Tax(Rs)",
           "State/UT Tax(Rs)", "Cess(Rs)", "", ""]
    for c, (a, b) in enumerate(zip(top, sub), start=1):
        wscdnr.cell(row=5, column=c, value=a or None).font = BOLD
        wscdnr.cell(row=6, column=c, value=b or None).font = BOLD
    cn = [r for r in books if r["fate"] == "credit"]
    r = 7
    for rec in cn:
        name, gst, pos = S[rec["key"]]
        wscdnr.cell(row=r, column=1, value=gst)
        wscdnr.cell(row=r, column=2, value=name)
        wscdnr.cell(row=r, column=3, value=rec["doc"])
        wscdnr.cell(row=r, column=4, value="Credit Note")
        wscdnr.cell(row=r, column=5, value="Regular")
        wscdnr.cell(row=r, column=6, value=ddmmyyyy(rec["date"]))
        wscdnr.cell(row=r, column=7, value=abs(round(rec["taxable"] + rec["igst"]
                                                     + rec["cgst"] + rec["sgst"], 2)))
        wscdnr.cell(row=r, column=8, value=pos)
        wscdnr.cell(row=r, column=9, value="No")
        wscdnr.cell(row=r, column=10, value=abs(rec["taxable"]))
        wscdnr.cell(row=r, column=11, value=abs(rec["igst"]))
        wscdnr.cell(row=r, column=12, value=abs(rec["cgst"]))
        wscdnr.cell(row=r, column=13, value=abs(rec["sgst"]))
        wscdnr.cell(row=r, column=14, value=0)
        wscdnr.cell(row=r, column=15, value="Yes")
        r += 1

    # ---- ISD credit ------------------------------------------------------
    wsisd.cell(row=1, column=1, value="Goods and Services Tax - GSTR-2B")
    wsisd.cell(row=4, column=1, value="ISD Credits")
    itop = ["GSTIN of ISD", "Trade/Legal name", "ISD Document type", "ISD Document number",
            "ISD Document date", "Original Invoice Number", "Original invoice date",
            "Input tax distribution by ISD", "", "", "", "ISD GSTR-6 Period",
            "ISD GSTR-6 Filing Date", "Eligibility of ITC"]
    isub = ["", "", "", "", "", "", "", "Integrated Tax(Rs)", "Central Tax(Rs)",
            "State/UT Tax(Rs)", "Cess(Rs)", "", "", ""]
    for c, (a, b) in enumerate(zip(itop, isub), start=1):
        wsisd.cell(row=5, column=c, value=a or None).font = BOLD
        wsisd.cell(row=6, column=c, value=b or None).font = BOLD
    r = 7
    for doc, date, i, c_, sg in ISD_2B:
        name, gst, _ = S["isd"]
        vals = [gst, name, "ISD Invoice", doc, ddmmyyyy(date), None, None,
                i, c_, sg, 0, "Aug'26", ddmmyyyy(dt.date(2026, 9, 13)), "Yes"]
        for c, v in enumerate(vals, start=1):
            wsisd.cell(row=r, column=c, value=v)
        r += 1

    # ---- imports ---------------------------------------------------------
    wsimpg.cell(row=1, column=1, value="Goods and Services Tax - GSTR-2B")
    wsimpg.cell(row=4, column=1, value="Import of goods from overseas")
    for c, (a, b) in enumerate(zip(
            ["Icegate Reference Date", "Port Code", "Bill of Entry Details", "", "",
             "Amount of tax (Rs)", ""],
            ["", "", "Number", "Date", "Taxable Value", "Integrated Tax(Rs)",
             "Cess(Rs)"]), start=1):
        wsimpg.cell(row=5, column=c, value=a or None).font = BOLD
        wsimpg.cell(row=6, column=c, value=b or None).font = BOLD
    for r, (vch, name, doc, date, taxable, rate) in enumerate(IMPG, start=7):
        igst = round(taxable * rate / 100.0, 2)
        for c, v in enumerate([ddmmyyyy(date + dt.timedelta(days=2)), "INDEL4", doc,
                               ddmmyyyy(date), round(taxable, 2), igst, 0], start=1):
            wsimpg.cell(row=r, column=c, value=v)

    # ---- the portal's own summary, for tie-out ---------------------------
    wsav.cell(row=1, column=1, value="FORM GSTR-2B")
    wsav.cell(row=5, column=1, value="FORM SUMMARY - ITC AVAILABLE")
    for c, h in enumerate(["S.no.", "Heading", "GSTR-3B table", "Integrated Tax (Rs)",
                           "Central Tax (Rs)", "State/UT Tax (Rs)", "Cess (Rs)",
                           "Advisory"], start=1):
        wsav.cell(row=6, column=c, value=h).font = BOLD
    tot_i = round(sum(r[9] or 0 for r in rows), 2)
    tot_c = round(sum(r[10] or 0 for r in rows), 2)
    tot_s = round(sum(r[11] or 0 for r in rows), 2)
    wsav.cell(row=7, column=1, value="Part A")
    wsav.cell(row=7, column=2, value="ITC Available - Credit which may be availed")
    wsav.cell(row=8, column=1, value="I")
    wsav.cell(row=8, column=2, value="All other ITC - Supplies from registered persons")
    wsav.cell(row=8, column=3, value="Table 4(A)(5)")
    wsav.cell(row=8, column=4, value=tot_i)
    wsav.cell(row=8, column=5, value=tot_c)
    wsav.cell(row=8, column=6, value=tot_s)
    wsav.cell(row=8, column=7, value=0)

    for ws in wb.worksheets:
        ws.column_dimensions["A"].width = 20
        ws.column_dimensions["B"].width = 32
        ws.column_dimensions["C"].width = 22
        for col in "DEFGHIJKLMNOPQ":
            ws.column_dimensions[col].width = 15
    wb.save(path)


# --------------------------------------------------------------------------
# File 3 - last month's pending master
# --------------------------------------------------------------------------

MB_COLS = ["Month", "Date", "Particulars", "Party GSTIN/UIN", "Vch Type", "Vch No.",
           "Doc No.", "Updated Doc No.", "Doc Date", "Taxable amt", "IGST", "CGST",
           "SGST/UTGST", "Cess", "Tax amt", "Remark", "Remark 2", "Status",
           "Invoice month", "Matched in month", "Matched against", "Ageing (months)",
           "Notes"]

M2_COLS = ["Tax Period", "Doc Type", "Purchase Type", "Doc No", "Doc Date",
           "Supplier GSTIN", "Supplier Name", "Place of Supply", "Reverse Charge",
           "Doc Value", "Item Taxable Value", "IGST", "CGST", "SGST", "Cess",
           "GSTR-1 Filing Period", "GSTR-1 Filing Date", "ITC Eligible",
           "ITC Ineligible Reason", "Remark", "Remark 2", "Status", "Invoice month",
           "Matched in month", "Matched against", "Ageing (months)", "Notes"]


def _sheet_head(ws, title, cols):
    ws.cell(row=1, column=1, value=title).font = Font(bold=True, size=13)
    ws.cell(row=2, column=1,
            value="Updated after Jul'26. 'Open' rows are still pending; 'Cleared' rows "
                  "have been matched and are kept for history.")
    for c, h in enumerate(cols, start=1):
        ws.cell(row=4, column=c, value=h).font = BOLD


def build_file3(path, mbooks, m2b):
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    ws_b_2425 = wb.create_sheet("Only in books; Not in 2B 24-25")
    ws_b = wb.create_sheet("Only in books; Not in 2B 26-27")
    ws_2 = wb.create_sheet("Only in 2B; Not in books 26-27")
    wsdec = wb.create_sheet("Probable Match Decisions")
    wsreg = wb.create_sheet("Registers Seen")

    _sheet_head(ws_b_2425, "Only in books; Not in 2B 24-25", MB_COLS)
    _sheet_head(ws_b, "Only in books; Not in 2B 26-27", MB_COLS)
    _sheet_head(ws_2, "Only in 2B; Not in books 26-27", M2_COLS)

    def book_line(ws, r, rec, status, remark, matched_in="", against="", note=""):
        vals = [rec["month"], rec["date"], rec["name"], rec["gstin"], "Purchase",
                str(9000 + r), rec["doc"], rec["doc"], rec["date"], rec["taxable"],
                rec["igst"] or None, rec["cgst"] or None, rec["sgst"] or None, None,
                round(rec["igst"] + rec["cgst"] + rec["sgst"], 2), remark,
                "Ineligible" if rec.get("inelig") else "", status, rec["month"],
                matched_in, against, None, note]
        for c, v in enumerate(vals, start=1):
            ws.cell(row=r, column=c, value=v)

    r_old, r_new = 5, 5
    for rec in mbooks:
        if rec["month"].endswith("-24"):
            book_line(ws_b_2425, r_old, rec, "Open", "Not Matched")
            r_old += 1
        else:
            book_line(ws_b, r_new, rec, "Open", "Not Matched")
            r_new += 1
    for month, key, doc, date, taxable, rate, cleared_in in MASTER_BOOKS_CLEARED:
        name, gst, _ = S[key]
        i, c, sg = tax(gst, taxable, rate)
        rec = {"month": month, "name": name, "gstin": gst, "doc": doc, "date": date,
               "taxable": round(taxable, 2), "igst": i, "cgst": c, "sgst": sg}
        book_line(ws_b, r_new, rec, "Cleared", "Matched with month July 2026",
                  cleared_in, "GSTR-2B of Jul'26")
        r_new += 1

    r = 5
    for rec in m2b:
        vals = [rec["month"], "Invoice", "B2B", rec["doc"], rec["date"], rec["gstin"],
                rec["name"], "07-Delhi", "No", None, rec["taxable"],
                rec["igst"] or None, rec["cgst"] or None, rec["sgst"] or None, None,
                None, None, "Yes", "", "Not Matched", "", "Open", rec["month"],
                "", "", None, ""]
        for c, v in enumerate(vals, start=1):
            ws_2.cell(row=r, column=c, value=v)
        r += 1

    # ---- decisions already taken on probable matches ---------------------
    dec_cols = ["Supplier GSTIN", "Supplier name", "Invoice month", "Doc No. as booked",
                "Matched against document", "IGST", "CGST", "SGST/UTGST", "Confirmed",
                "Decided in"]
    wsdec.cell(row=1, column=1, value="Probable matches you have already decided"
               ).font = Font(bold=True, size=13)
    wsdec.cell(row=2, column=1,
               value="Kept so the same suggestion is not put to you twice. A row marked "
                     "No is never suggested again and no credit is taken on it.")
    for c, h in enumerate(dec_cols, start=1):
        wsdec.cell(row=4, column=c, value=h).font = BOLD
    decisions = [
        (S["tara"][1], S["tara"][0], "Jul-26", "TL/JUL/2026/0012", "TLX/2026/0012",
         None, 1890.0, 1890.0, "Yes", "Jul'26"),
        (S["globe"][1], S["globe"][0], "Jul-26", "GF/26-27/0074", "GFS-2026-0074",
         2340.0, None, None, "No", "Jul'26"),
    ]
    for r, row in enumerate(decisions, start=5):
        for c, v in enumerate(row, start=1):
            wsdec.cell(row=r, column=c, value=v)

    # ---- what each Tally register held in earlier months ------------------
    reg_cols = ["Month", "Register", "Sheet in Tally", "Vouchers", "IGST", "CGST",
                "SGST/UTGST", "Cess"]
    wsreg.cell(row=1, column=1, value="Tally registers seen each month"
               ).font = Font(bold=True, size=13)
    wsreg.cell(row=2, column=1,
               value="Kept so that a register which stops being exported can be spotted.")
    for c, h in enumerate(reg_cols, start=1):
        wsreg.cell(row=4, column=c, value=h).font = BOLD
    history = [
        ("all_other_itc", "All Other ITC", 26, 512000.0, 96000.0, 96000.0),
        ("ineligible_itc", "Ineligible ITC", 4, 2100.0, 1450.0, 1450.0),
        ("rcm_itc", "RCM ITC Book", 3, 5900.0, 5400.0, 5400.0),
        ("imps", "IMPS Books", 1, 41400.0, 0.0, 0.0),
        ("impg", "IMPG Books", 1, 238000.0, 0.0, 0.0),
        ("t31a", "Table 3.1a", 4, 1420000.0, 210000.0, 210000.0),
        ("t31d", "Table 3.1d", 4, 47300.0, 5400.0, 5400.0),
    ]
    r = 5
    for month in ("Jun-26", "Jul-26"):
        for key, sheet, n, i, c_, sg in history:
            for col, v in enumerate([month, key, sheet, n, i, c_, sg, 0.0], start=1):
                wsreg.cell(row=r, column=col, value=v)
            r += 1

    for ws in wb.worksheets:
        ws.column_dimensions["A"].width = 14
        ws.column_dimensions["B"].width = 20
        ws.column_dimensions["C"].width = 34
        for col in "DEFGHIJKLMNOPQRSTUVW":
            ws.column_dimensions[col].width = 15
    wb.save(path)


# --------------------------------------------------------------------------

def main():
    books = book_rows()
    mbooks = master_book_rows()
    m2b = master_2b_rows()

    rcm = [{"vch": v, "name": S[k][0], "gstin": S[k][1], "doc": doc, "date": date,
            "taxable": round(t, 2), "vch_type": "Purchase",
            **dict(zip(("igst", "cgst", "sgst"), tax(S[k][1], t, r)))}
           for v, k, doc, date, t, r in RCM]
    imps = [{"vch": v, "name": n, "doc": doc, "date": date, "taxable": round(t, 2),
             "vch_type": "Purchase", "gstin": "",
             "igst": round(t * r / 100.0, 2), "cgst": 0.0, "sgst": 0.0}
            for v, n, doc, date, t, r in IMPS]
    impg = [{"vch": v, "name": n, "doc": doc, "date": date, "taxable": round(t, 2),
             "vch_type": "Purchase", "gstin": "",
             "igst": round(t * r / 100.0, 2), "cgst": 0.0, "sgst": 0.0}
            for v, n, doc, date, t, r in IMPG]
    sales = [{"vch": v, "name": n, "gstin": g, "date": date, "taxable": round(t, 2),
              "vch_type": "Sales",
              **dict(zip(("igst", "cgst", "sgst"), tax(g, t, r)))}
             for v, n, g, date, t, r in SALES]

    f1 = os.path.join(HERE, "Sample 1 Tally Books.xlsx")
    f2 = os.path.join(HERE, "Sample 2 GSTR2B.xlsx")
    f3 = os.path.join(HERE, "Sample 3 Pending Master.xlsx")

    build_file1(f1, books, rcm, imps, impg, sales)
    build_file2(f2, books, mbooks)
    build_file3(f3, mbooks, m2b)

    for p in (f1, f2, f3):
        print("written:", os.path.basename(p))


if __name__ == "__main__":
    main()

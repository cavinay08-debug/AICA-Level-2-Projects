"""Works out which workbook in the Input folder is which, by looking at the
sheets inside rather than trusting the file name."""

from __future__ import annotations

import os

import openpyxl

TALLY_MARKERS = ("all other itc", "gstr-3b", "rcm itc", "table 3.1a", "ineligible itc")
B2B_MARKERS = ("b2b", "itc available", "read me", "b2b-cdnr", "impg", "itc not available")
MASTER_MARKERS = ("only in books", "only in 2b", "not in 2b", "not in books", "pending")

EXTS = (".xlsx", ".xlsm", ".xlsb")


def _sheet_names(path):
    try:
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        names = [n.lower().strip() for n in wb.sheetnames]
        wb.close()
        return names
    except Exception:
        return []


def _score(names, markers):
    return sum(1 for m in markers if any(m in n for n in names))


def classify(folder: str) -> dict:
    """Return {'tally':path,'gstr2b':path,'master':path,'candidates':[...]}"""
    files = []
    for fn in sorted(os.listdir(folder)):
        if fn.startswith("~$") or not fn.lower().endswith(EXTS):
            continue
        files.append(os.path.join(folder, fn))

    scored = []
    for path in files:
        names = _sheet_names(path)
        if not names:
            continue
        base = os.path.basename(path).lower()
        s_master = _score(names, MASTER_MARKERS) * 3
        s_tally = _score(names, TALLY_MARKERS)
        s_2b = _score(names, B2B_MARKERS)
        # A pending master also contains words like "2b"; the sheet-name score
        # above already weights it, the file name only breaks ties.
        if "master" in base or "pending" in base:
            s_master += 2
        if "tally" in base or "book" in base:
            s_tally += 1
        if "2b" in base and "not in" not in base and "master" not in base:
            s_2b += 1
        scored.append({"path": path, "names": names,
                       "tally": s_tally, "gstr2b": s_2b, "master": s_master})

    picked, used = {}, set()
    for role in ("master", "gstr2b", "tally"):
        best, best_s = None, 0
        for row in scored:
            if row["path"] in used:
                continue
            if row[role] > best_s:
                best, best_s = row, row[role]
        if best:
            picked[role] = best["path"]
            used.add(best["path"])
    picked["candidates"] = [r["path"] for r in scored]
    return picked

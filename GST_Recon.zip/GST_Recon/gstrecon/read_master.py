"""Reader for File 3 - the running pending master.

Handles the several column layouts that have accumulated across financial years.
A row is treated as still OPEN unless its remark already records a match.
"""

from __future__ import annotations

import re

import openpyxl

from . import decisions
from .sheetutil import (build_map, cell, find_header, grid, is_blank_row,
                        is_total_row, merged_header, trim_grid)
from .util import (clean_text, fy_of, month_key, month_sort_key, norm_gstin,
                   num, r2, to_date)

BOOKS_ALIASES = {
    "month":       ["month", "tax period"],
    "date":        ["date"],
    "particulars": ["particulars", "party name", "ledger"],
    "gstin":       ["party gstin uin", "supplier gstin", "gstin uin", "gstin"],
    "vch_type":    ["vch type", "voucher type"],
    "vch_no":      ["vch no", "voucher no"],
    "doc_no":      ["doc no", "document no"],
    "upd_doc_no":  ["updated doc no", "update doc no", "updated doc", "revised doc no"],
    "doc_date":    ["doc date", "document date"],
    "taxable":     ["taxable amt", "taxable amount", "taxable value", "taxable"],
    "igst":        ["igst"],
    "cgst":        ["cgst"],
    "sgst":        ["sgst utgst", "sgst", "utgst"],
    "cess":        ["cess"],
    "tax":         ["tax amt", "total tax", "tax amount"],
    "remark":      ["remark", "matching status", "rem"],
    "remark2":     ["remark 2", "eligibility status", "rem 2"],
    "status":      ["status"],
    "cleared_in":  ["cleared in"],
    "matched_in":  ["matched in month"],
    "matched_against": ["matched against"],
    "note":        ["notes", "remarks", "subsequent adjustment", "narration"],
}

B2B_ALIASES = {
    "month":        ["tax period", "month"],
    "doc_type":     ["doc type", "document type"],
    "purchase_type": ["purchase type"],
    "doc_no":       ["doc no", "document no", "invoice no"],
    "doc_date":     ["doc date", "document date", "invoice date"],
    "gstin":        ["supplier gstin", "gstin of supplier", "gstin"],
    "supplier":     ["supplier name", "trade legal name"],
    "supplier_state": ["supplier state"],
    "pos":          ["place of supply", "pos"],
    "rev_charge":   ["reverse charge"],
    "itc_eligible": ["itc eligible", "itc availability"],
    "doc_value":    ["doc value", "document value"],
    "taxable":      ["item taxable value", "taxable value", "taxable"],
    "rate":         ["gst rate", "rate"],
    "igst":         ["igst"],
    "cgst":         ["cgst"],
    "sgst":         ["sgst"],
    "cess":         ["cess"],
    "remark":       ["remark", "rem"],
    "remark2":      ["remark 2", "rem 2"],
    "status":       ["status"],
    "cleared_in":   ["cleared in"],
    "matched_in":   ["matched in month"],
    "matched_against": ["matched against"],
    "note":         ["notes", "remarks"],
    "itc_reason":   ["itc ineligible reason type", "reason"],
    "gstr1_period": ["gstr 1 filing period"],
    "gstr1_filed":  ["gstr 1 filing date"],
}

MATCH_PREFIXES = ("matched", "cleared", "adjusted", "reversed", "settled")

REGISTER_SHEET = "Registers Seen"


def _slug(value) -> str:
    return re.sub(r"[^a-z0-9]+", " ", clean_text(value).lower()).strip()


REGISTER_COLS = ["Month", "Register", "Sheet in Tally", "Vouchers", "IGST", "CGST",
                 "SGST/UTGST", "Cess"]


def _read_registers_seen(ws) -> list[dict]:
    """
    What each Tally register held in earlier months.

    Carried so the tool can notice a register that has quietly stopped being
    exported. A register that used to have vouchers and now has none reads as a
    genuine nil, which is the one thing this file cannot otherwise tell us.
    """
    rows = trim_grid(grid(ws))
    hdr = None
    for i, row in enumerate(rows[:12]):
        cells = [_slug(c) for c in row]
        if "register" in cells and "vouchers" in cells:
            hdr = i
            break
    if hdr is None:
        return []
    pos = {_slug(c): i for i, c in enumerate(rows[hdr])}
    out = []
    for row in rows[hdr + 1:]:
        if is_blank_row(row):
            continue
        key = clean_text(cell(row, pos.get("register")))
        month = clean_text(cell(row, pos.get("month")))
        if not key or not month:
            continue
        out.append({
            "month": month,
            "register": key,
            "sheet": clean_text(cell(row, pos.get("sheet in tally"))),
            "rows": int(num(cell(row, pos.get("vouchers")))),
            "igst": num(cell(row, pos.get("igst"))),
            "cgst": num(cell(row, pos.get("cgst"))),
            "sgst": num(cell(row, pos.get("sgst utgst"))),
            "cess": num(cell(row, pos.get("cess"))),
        })
    return out



def is_cleared(remark: str) -> bool:
    r = clean_text(remark).lower()
    if not r:
        return False
    if r.startswith("not "):
        return False
    return any(r.startswith(p) for p in MATCH_PREFIXES)


def _side_of(headers: list[str], sheet_name: str) -> str:
    joined = " | ".join(h.lower() for h in headers)
    name = sheet_name.lower()
    if "vch no" in joined or "voucher no" in joined:
        return "books"
    if "supplier gstin" in joined or "purchase type" in joined or "tax period" in joined:
        return "b2b"
    if "not in 2b" in name or "only in books" in name:
        return "books"
    return "b2b"


def _read_sheet(ws) -> tuple[str, list[dict]]:
    rows = trim_grid(grid(ws))
    if not rows:
        return "", []

    hdr = None
    for i, row in enumerate(rows[:12]):
        joined = " | ".join(clean_text(c).lower() for c in row)
        if ("vch no" in joined and "doc no" in joined) or \
           ("doc no" in joined and ("supplier gstin" in joined or "tax period" in joined)):
            hdr = i
            break
    if hdr is None:
        hdr = find_header(rows, ["doc no"], search_rows=12)
    if hdr is None:
        return "", []

    headers = merged_header(rows, hdr, depth=1)
    side = _side_of(headers, ws.title)
    cmap = build_map(headers, BOOKS_ALIASES if side == "books" else B2B_ALIASES)

    # Older sheets carry two 'Particulars' columns - a Tally To/By marker and the
    # actual ledger name. Keep whichever one actually holds names.
    name_key = "particulars" if side == "books" else "supplier"
    twins = [i for i, h in enumerate(headers)
             if "particular" in h.lower() or "name" in h.lower()]
    if len(twins) > 1:
        def richness(idx):
            vals = [clean_text(cell(r, idx)) for r in rows[hdr + 1:hdr + 60]]
            vals = [v for v in vals if v and v.lower() not in {"to", "by", "dr", "cr"}]
            return (len(vals), sum(len(v) for v in vals) / max(1, len(vals)))
        best = max(twins, key=richness)
        if richness(best) > richness(cmap.get(name_key, best)):
            cmap[name_key] = best

    out = []
    for i in range(hdr + 1, len(rows)):
        row = rows[i]
        if is_blank_row(row) or is_total_row(row):
            continue
        doc_no = clean_text(cell(row, cmap.get("doc_no")))
        gstin = norm_gstin(cell(row, cmap.get("gstin")))
        igst = num(cell(row, cmap.get("igst")))
        cgst = num(cell(row, cmap.get("cgst")))
        sgst = num(cell(row, cmap.get("sgst")))
        cess = num(cell(row, cmap.get("cess")))
        tax = num(cell(row, cmap.get("tax"))) if side == "books" else 0.0
        if not doc_no and not gstin and not (igst or cgst or sgst):
            continue
        # Some legacy sheets omit the SGST column -- derive it from the total.
        if side == "books" and tax and not sgst and abs(tax - igst - cgst - cess) > 0.01:
            sgst = round(tax - igst - cgst - cess, 2)
        if not tax:
            tax = igst + cgst + sgst + cess

        remark = clean_text(cell(row, cmap.get("remark")))
        remark2 = clean_text(cell(row, cmap.get("remark2")))
        d = to_date(cell(row, cmap.get("date"))) if side == "books" else None
        doc_date = to_date(cell(row, cmap.get("doc_date")))
        m = clean_text(cell(row, cmap.get("month")))
        if not m or m.lower() in {"none", "#n/a"}:
            m = month_key(d or doc_date)
        elif to_date(m):
            m = month_key(to_date(m))

        rec = {
            "side": side,
            "month": m,
            "date": d or doc_date,
            "particulars": clean_text(cell(row, cmap.get("particulars"))) if side == "books"
                           else clean_text(cell(row, cmap.get("supplier"))),
            "gstin": gstin,
            "vch_type": clean_text(cell(row, cmap.get("vch_type"))) if side == "books" else "",
            "vch_no": clean_text(cell(row, cmap.get("vch_no"))) if side == "books" else "",
            "doc_no": doc_no,
            "upd_doc_no": clean_text(cell(row, cmap.get("upd_doc_no"))) or doc_no,
            "doc_date": doc_date or d,
            "taxable": num(cell(row, cmap.get("taxable"))),
            "igst": igst, "cgst": cgst, "sgst": sgst, "cess": cess, "tax": tax,
            "remark": remark,
            "remark2": remark2,
            "note": clean_text(cell(row, cmap.get("note"))),
            "_cleared_in": clean_text(cell(row, cmap.get("cleared_in"))),
            "_matched_in_prev": clean_text(cell(row, cmap.get("matched_in"))),
            "_matched_against_prev": clean_text(cell(row, cmap.get("matched_against"))),
            "cleared": (clean_text(cell(row, cmap.get("status"))).lower() == "cleared"
                        or is_cleared(remark)),
            "src_sheet": ws.title,
            "src_row": i + 1,
            "fy": "",
        }
        if side == "b2b":
            rec.update({
                "doc_type": clean_text(cell(row, cmap.get("doc_type"))) or "Invoice",
                "purchase_type": clean_text(cell(row, cmap.get("purchase_type"))) or "B2B",
                "supplier": rec["particulars"],
                "supplier_state": clean_text(cell(row, cmap.get("supplier_state"))),
                "pos": clean_text(cell(row, cmap.get("pos"))),
                "rev_charge": clean_text(cell(row, cmap.get("rev_charge"))),
                "itc_eligible": clean_text(cell(row, cmap.get("itc_eligible"))),
                "doc_value": num(cell(row, cmap.get("doc_value"))),
                "rate": clean_text(cell(row, cmap.get("rate"))),
                "itc_reason": clean_text(cell(row, cmap.get("itc_reason"))),
                "gstr1_period": to_date(cell(row, cmap.get("gstr1_period"))),
                "gstr1_filed": to_date(cell(row, cmap.get("gstr1_filed"))),
                "upd_doc_no": doc_no,
            })
        rec["fy"] = fy_of(rec["date"] or rec["doc_date"])
        out.append(rec)
    return side, out


def _cleared_month(rec) -> str:
    """The month in which a row was recorded as matched, however it was written."""
    for v in (rec.get("_matched_in_prev"), rec.get("_cleared_in")):
        tag = clean_text(v)
        if tag:
            return tag
    m = re.search(r"matched with month\s+([A-Za-z]{3,})\s*(\d{2,4})",
                  str(rec.get("remark") or ""), re.IGNORECASE)
    return f"{m.group(1)[:3]}-{m.group(2)[-2:]}" if m else ""


def cleared_in_period(master: dict, period_end) -> dict:
    """
    Rows the master already says were matched in the month being processed, or later.

    A correct pending master comes from the month before, so nothing in it can yet
    have been cleared in this month. If something has, the master is the one this
    tool produced for this same month. Those rows are excluded from re-matching, so
    credit that ought to be released now is quietly left out of the return.
    """
    out = {"rows": [], "months": set(), "igst": 0.0, "cgst": 0.0, "sgst": 0.0, "cess": 0.0}
    if not period_end:
        return out
    cur = month_sort_key(month_key(period_end))
    for rec in master.get("books", []) + master.get("b2b", []):
        if not rec.get("cleared"):
            continue
        tag = _cleared_month(rec)
        key = month_sort_key(tag)
        if key == (0, 0) or key < cur:
            continue
        out["rows"].append(rec)
        out["months"].add(tag)
        for h in ("igst", "cgst", "sgst", "cess"):
            out[h] += rec.get(h, 0.0) or 0.0
    for h in ("igst", "cgst", "sgst", "cess"):
        out[h] = r2(out[h])
    return out


def read(path: str | None) -> dict:
    result = {"path": path, "books": [], "b2b": [], "sheets": {},
              "registers_seen": []}
    if not path:
        return result
    wb = openpyxl.load_workbook(path, data_only=True, read_only=False)
    for name in wb.sheetnames:
        # These two carry document numbers and amounts of their own, and would
        # otherwise be read back as a fresh set of pending invoices.
        low = name.strip().lower()
        if low == decisions.SHEET_NAME.lower():
            continue
        if low == REGISTER_SHEET.lower():
            result["registers_seen"] = _read_registers_seen(wb[name])
            continue
        side, recs = _read_sheet(wb[name])
        if not recs:
            continue
        result["sheets"][name] = {"side": side, "count": len(recs)}
        result[side].extend(recs)
    wb.close()
    return result

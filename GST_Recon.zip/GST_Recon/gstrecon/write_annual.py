"""
Writes the annual reconciliation workbook.

It is the ordinary working paper, built over the whole year rather than a month,
with three sheets in front of it that only make sense annually: the year read
month by month, the figures set against GSTR-9, and the input tax credit
reconciliation in the shape GSTR-9C uses.

Kept apart from the monthly output on purpose. Different file, different name,
different tab in the window.
"""

from __future__ import annotations

from openpyxl.styles import Alignment, Font

from . import brand as B
from . import write_working as W
from .engine import totals
from .util import month_sort_key, r2
from .xlstyle import (BORDER, F_ALERT, FILL_AMBER, FILL_GREEN, FILL_LIGHT,
                      F_BODY, F_BOLD, F_SECTION, F_SUB, F_TITLE, MONEY,
                      header_row, stamp_row, widths)

HEADS = ("igst", "cgst", "sgst")


def _head(ws, R, title, note=""):
    ws.cell(row=1, column=1, value=title).font = F_TITLE
    ws.cell(row=2, column=1,
            value=f"{R['company_name']} | {R['company_gstin']} | "
                  f"financial year {R.get('fy', '')}").font = F_SUB
    if note:
        c = ws.cell(row=3, column=1, value=note)
        c.font = F_SUB
        c.alignment = Alignment(wrap_text=True, vertical="top")


def _money_row(ws, r, label, vals, bold=False, fill=None, indent=0):
    c = ws.cell(row=r, column=1, value=("    " * indent) + label)
    c.font = F_BOLD if bold else F_BODY
    for i, h in enumerate(HEADS):
        x = ws.cell(row=r, column=2 + i, value=r2((vals or {}).get(h, 0.0))
                    if vals else None)
        x.number_format = MONEY
        if bold:
            x.font = F_BOLD
    t = ws.cell(row=r, column=5, value=f"=SUM(B{r}:D{r})")
    t.number_format = MONEY
    if bold:
        t.font = F_BOLD
    if fill:
        for col in range(1, 6):
            ws.cell(row=r, column=col).fill = fill
    for col in range(1, 6):
        ws.cell(row=r, column=col).border = BORDER


def _summary(ws, R):
    _head(ws, R, "Annual reconciliation",
          "Every book voucher for the year is matched against every GSTR-2B row for "
          "the year, so an invoice booked in one month and reported by the supplier "
          "in another counts as matched. That is what makes the annual position "
          "different from adding up twelve monthly runs.")
    W._brandmark(ws, "J1")

    books = R["books"]
    matched = [x for x in books if x.get("_matched")]
    pct = (100.0 * len(matched) / len(books)) if books else 0.0

    r = 5
    ws.cell(row=r, column=1, value="The year at a glance").font = F_SECTION
    r += 1
    header_row(ws, r, ["Particulars", "IGST", "CGST", "SGST/UTGST", "Total"])
    r += 1
    for label, vals, bold, fill in (
            ("Books, all other ITC for the year", R["t_books"], True, FILL_LIGHT),
            ("   matched with GSTR-2B somewhere in the year",
             totals(matched), False, None),
            ("   never matched, still open at the year end",
             totals(R["only_books"]), False, None),
            ("GSTR-2B for the year", totals(R["b2b"]), True, FILL_LIGHT),
            ("   never matched to the books", totals(R["only_2b"]), False, None),
            ("Table 4(A)(5) for the year", R["t4a5"], True, FILL_GREEN),
            ("Table 4(B)(1) for the year", R["t4b1"], True, FILL_GREEN),
            ("Table 4(C) net ITC for the year", R["t4c"], True, FILL_GREEN)):
        _money_row(ws, r, label, vals, bold=bold, fill=fill)
        r += 1

    ws.cell(row=r, column=1,
            value=f"{len(matched)} of {len(books)} vouchers matched, {pct:.0f} per cent, "
                  f"across {len(R.get('twob_files', []))} GSTR-2B download(s).").font = F_SUB
    r += 2

    ws.cell(row=r, column=1, value="Month by month").font = F_SECTION
    r += 1
    ws.cell(row=r, column=1,
            value="Books are shown in the month the voucher was booked, GSTR-2B in the "
                  "period the supplier reported it. The gap between the two is the lag "
                  "being financed.").font = F_SUB
    r += 1
    header_row(ws, r, ["Month", "Vouchers", "Matched", "Books tax", "GSTR-2B rows",
                       "GSTR-2B tax", "Only in books", "Only in GSTR-2B"])
    r += 1
    first = r
    for m in R.get("months", []):
        stamp_row(ws, r, [
            m["month"], m["n_books"], m["n_matched"], m["books"]["tax"],
            m["n_twob"], m["twob"]["tax"], m["only_books"]["tax"],
            m["only_2b"]["tax"]],
            fmts={4: MONEY, 6: MONEY, 7: MONEY, 8: MONEY})
        r += 1
    if R.get("months"):
        ws.cell(row=r, column=1, value="Year").font = F_BOLD
        for c in (2, 3, 4, 5, 6, 7, 8):
            cell = ws.cell(row=r, column=c,
                           value=f"=SUM({W.CL(c)}{first}:{W.CL(c)}{r - 1})")
            cell.font = F_BOLD
            cell.fill = FILL_LIGHT
            cell.number_format = MONEY if c in (4, 6, 7, 8) else "#,##0"
        r += 2

    barred = [x for g in R.get("released_timebarred", {}).values() for x in g]
    if barred:
        c = ws.cell(row=r, column=1,
                    value=f"{len(barred)} item(s) matched during the year are time "
                          f"barred under section 16(4) and have not been claimed. "
                          f"See Require Correction.")
        c.font = F_ALERT
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=8)

    widths(ws, {"A": 52, "B": 16, "C": 16, "D": 18, "E": 16, "F": 18, "G": 18, "H": 18})
    ws.freeze_panes = "B7"


def _gstr9(ws, R):
    g = R.get("gstr9") or {}
    _head(ws, R, "Figures for GSTR-9",
          "The year's figures set against the tables of the annual return. Lines this "
          "tool has no basis for are left blank for you rather than guessed at, and "
          "the last column says where each figure comes from.")

    r = 5
    for title, key, note in (
            ("Table 6  -  ITC availed as declared in the returns", "six", ""),
            ("Table 7  -  ITC reversed", "seven", ""),
            ("Table 8  -  ITC as per GSTR-2B against ITC availed", "eight",
             "8D and 8I are differences the return computes; they follow from the "
             "lines above.")):
        ws.cell(row=r, column=1, value=title).font = F_SECTION
        r += 1
        if note:
            ws.cell(row=r, column=1, value=note).font = F_SUB
            r += 1
        header_row(ws, r, ["", "Particulars", "IGST", "CGST", "SGST/UTGST", "Total",
                           "Where it comes from"])
        r += 1
        for code, label, vals, source in g.get(key, []):
            ws.cell(row=r, column=1, value=code).font = F_BOLD
            ws.cell(row=r, column=2, value=label).font = F_BODY
            for i, h in enumerate(HEADS):
                x = ws.cell(row=r, column=3 + i,
                            value=(r2(vals.get(h, 0.0)) if vals else None))
                x.number_format = MONEY
            ws.cell(row=r, column=6, value=f"=SUM(C{r}:E{r})").number_format = MONEY
            src = ws.cell(row=r, column=7,
                          value=source if vals else "Not derived. " + source)
            src.font = F_SUB
            if not vals:
                for col in range(1, 8):
                    ws.cell(row=r, column=col).fill = FILL_AMBER
            for col in range(1, 8):
                ws.cell(row=r, column=col).border = BORDER
            r += 1
        r += 2

    widths(ws, {"A": 7, "B": 62, "C": 18, "D": 16, "E": 16, "F": 18, "G": 52})
    ws.freeze_panes = "C6"


def _gstr9c(ws, R):
    c9 = R.get("gstr9c") or {}
    _head(ws, R, "Input tax credit reconciliation for GSTR-9C",
          "Table 12: the credit in the books against the credit claimed. This is the "
          "same deferral the monthly run tracks, read over a year. Credit booked this "
          "year but still waiting on a supplier is 12C; credit released this year that "
          "was booked in an earlier year is 12B.")

    r = 5
    header_row(ws, r, ["", "Particulars", "IGST", "CGST", "SGST/UTGST", "Total"])
    r += 1
    for code, label, vals, negative in c9.get("rows", []):
        ws.cell(row=r, column=1, value=code).font = F_BOLD
        bold = code in ("12D", "12E", "12F")
        ws.cell(row=r, column=2, value=label).font = F_BOLD if bold else F_BODY
        for i, h in enumerate(HEADS):
            x = ws.cell(row=r, column=3 + i, value=r2(vals.get(h, 0.0)))
            x.number_format = MONEY
            if bold:
                x.font = F_BOLD
        t = ws.cell(row=r, column=6, value=f"=SUM(C{r}:E{r})")
        t.number_format = MONEY
        if bold:
            t.font = F_BOLD
        if code == "12F":
            fill = FILL_GREEN if c9.get("ties") else FILL_AMBER
            for col in range(1, 7):
                ws.cell(row=r, column=col).fill = fill
        for col in range(1, 7):
            ws.cell(row=r, column=col).border = BORDER
        r += 1

    r += 1
    verdict = ("The books and the return agree for the year."
               if c9.get("ties") else "There is a difference to explain.")
    ws.cell(row=r, column=1, value=verdict).font = F_BOLD
    r += 1
    c = ws.cell(row=r, column=1, value=c9.get("note", ""))
    c.font = F_SUB
    c.alignment = Alignment(wrap_text=True, vertical="top")
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=6)
    ws.row_dimensions[r].height = 30

    widths(ws, {"A": 7, "B": 62, "C": 18, "D": 16, "E": 16, "F": 18})
    ws.freeze_panes = "C6"


def _annual_sheets(wb, sheets, R):
    """Inserted in front of the ordinary working paper."""
    for i, (name, fn) in enumerate((("Annual Summary", _summary),
                                    ("GSTR-9", _gstr9),
                                    ("GSTR-9C ITC", _gstr9c))):
        ws = wb.create_sheet(name[:31], i)
        fn(ws, R)
        ws.sheet_view.showGridLines = False


def build(R: dict, path: str) -> str:
    return W.build(R, path, extra=_annual_sheets)

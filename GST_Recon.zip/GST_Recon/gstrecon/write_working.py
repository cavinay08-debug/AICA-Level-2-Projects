"""Writes Output 1 - the monthly GST working paper."""

from __future__ import annotations

from collections import defaultdict

import openpyxl
from openpyxl.chart import BarChart, Reference
from openpyxl.chart.label import DataLabelList
from openpyxl.formatting.rule import CellIsRule, FormulaRule
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.utils import get_column_letter as CL
from openpyxl.worksheet.hyperlink import Hyperlink

from . import brand as B

# EXI brand colours. Blue leads, brown supports; the two differ in hue rather
# than only in lightness, so they stay apart for a reader with a colour-vision
# deficiency. Red is kept for exceptions, which is the accent use the guide
# allows.
SERIES_1 = B.BLUE
SERIES_2 = B.BROWN
SERIES_ALERT = B.RED
LINK_BLUE = B.BLUE


def _link(ws, row, col, sheet, text=None, anchor="A1", bold=False):
    """
    Make a cell jump to the sheet that holds the underlying rows.

    This has to be a Hyperlink with `location` set. Assigning a plain string
    gives it a `target` instead, which Excel reads as a link out to another file.
    """
    c = ws.cell(row=row, column=col)
    if text is not None:
        c.value = text
    c.hyperlink = Hyperlink(ref=c.coordinate, location=f"'{sheet}'!{anchor}",
                            tooltip=f"Go to {sheet}")
    c.font = Font(name="Calibri", size=10, color=LINK_BLUE, underline="single", bold=bold)
    return c

from . import ledgers as LG
from . import setoff
from .engine import _lbl, totals
from .util import month_sort_key, r2
from .xlstyle import (BORDER, DATE, F_ALERT, FILL_AMBER, FILL_GREEN, FILL_GREY,
                      FILL_HDR, FILL_LIGHT, FILL_ORANGE, FILL_RED, F_BODY,
                      F_BOLD, F_HDR, F_SECTION, F_SUB, F_TITLE, MONEY,
                      TOP_LINE, autofilter, header_row, stamp_row, widths)

SHEET_ORDER = [
    "Dashboard",
    "Summary",
    "GSTR-3B",
    "All other ITC-4A(5)-Calculation",
    "ITC Set-off",
    "Entries",
    "Ledgers Reconciliation",
    "Supplier Watchlist",
    "Require Correction",
    "Probable Matches",
    "Cleaned Doc No Matches",
    "Deferred ITC",
    "Deferred ITC Reversal",
    "ITC only in books; Not in 2B",
    "ITC only in 2b; Not in Books",
    "Ineligible ITC",
    "All other ITC",
    "GSTR 2B",
    "RCM ITC Books",
    "RCM-2B",
    "IMPS Books",
    "IMPG Books",
    "IMPG-2B",
    "ISD-2B",
    "Table 3.1a",
    "Table 3.1b",
    "Table 3.1c",
    "Table 3.1d",
    "Table 3.1e",
]

BOOK_COLS = ["Date", "Particulars", "Party GSTIN/UIN", "Vch Type", "Vch No.", "Doc No.",
             "Update Doc. No.", "Doc Date", "Taxable Amount", "IGST", "CGST", "SGST/UTGST",
             "Cess", "Tax Amt", "IGST CHECK", "DIFF", "REM", "CGST CHECK", "DIFF", "REM",
             "Remark 1", "Remark 2", "Match Type", "Notes"]

B2B_COLS = ["Tax Period", "Doc Type", "Purchase Type", "Doc No", "Doc Date", "Supplier GSTIN",
            "Supplier Name", "Supplier State", "Place of Supply", "Port Code", "Reverse Charge",
            "Doc Value", "Item Taxable Value", "GST Rate", "IGST", "CGST", "SGST",
            "IGST CHECK", "DIFF", "REM", "CGST CHECK", "DIFF", "REM", "Remark 1", "Remark 2",
            "Cess", "Is Amendment", "GSTR-1 Filing Period", "GSTR-1 Filing Date",
            "ITC Eligible", "ITC Ineligible Reason", "Match Type", "Notes"]

PLAIN_BOOK_COLS = ["Date", "Particulars", "Party GSTIN/UIN", "Vch Type", "Vch No.", "Doc No.",
                   "Update Doc. No.", "Doc Date", "Taxable Amount", "IGST", "CGST",
                   "SGST/UTGST", "Cess", "Tax Amt", "Remark 1", "Remark 2"]

PLAIN_2B_COLS = ["Tax Period", "Doc Type", "Purchase Type", "Doc No", "Doc Date",
                 "Supplier GSTIN", "Supplier Name", "Place of Supply", "Reverse Charge",
                 "Doc Value", "Item Taxable Value", "IGST", "CGST", "SGST", "Cess",
                 "GSTR-1 Filing Period", "GSTR-1 Filing Date", "ITC Eligible",
                 "ITC Ineligible Reason", "Remark 1", "Remark 2"]

BOOK_W = {"A": 11, "B": 38, "C": 18, "D": 14, "E": 12, "F": 20, "G": 20, "H": 11,
          "I": 15, "J": 13, "K": 13, "L": 13, "M": 10, "N": 13, "O": 13, "P": 11,
          "Q": 13, "R": 13, "S": 11, "T": 13, "U": 22, "V": 12, "W": 18, "X": 46}

B2B_W = {"A": 11, "B": 13, "C": 14, "D": 22, "E": 11, "F": 18, "G": 34, "H": 20, "I": 18,
         "J": 10, "K": 9, "L": 13, "M": 15, "N": 9, "O": 13, "P": 13, "Q": 13, "R": 13,
         "S": 11, "T": 13, "U": 13, "V": 11, "W": 13, "X": 22, "Y": 12, "Z": 9, "AA": 12,
         "AB": 15, "AC": 15, "AD": 11, "AE": 34, "AF": 18, "AG": 40}


THREEB_COLS = ["Particulars", "Taxable Value", "IGST", "CGST", "SGST/UTGST",
               "Cess", "Total Tax", "Source"]

HEAD_NAMES = {
    "taxable": ("taxable amount", "item taxable value", "taxable"),
    "igst": ("igst",),
    "cgst": ("cgst",),
    "sgst": ("sgst/utgst", "sgst"),
    "cess": ("cess",),
}


def _head_col(anchor, head):
    """Column letter for a tax head on a schedule, found by its heading."""
    if not anchor:
        return None
    low = [str(c).strip().lower() for c in anchor.get("cols", [])]
    for name in HEAD_NAMES.get(head, ()):
        if name in low:
            return CL(low.index(name) + 1)
    return None


def _ref(anchor, head):
    """A formula pointing at that head's total on the schedule behind the figure."""
    col = _head_col(anchor, head)
    if not col:
        return None
    return f"='{anchor['sheet']}'!{col}{anchor['total']}"


def _sumifs(anchor, head, crit_head, criterion):
    """Same, for a figure that is a filtered part of a schedule."""
    col = _head_col(anchor, head)
    ccol = _head_col_named(anchor, crit_head)
    if not col or not ccol:
        return None
    rng = f"'{anchor['sheet']}'!${col}${anchor['first']}:${col}${anchor['last']}"
    crng = f"'{anchor['sheet']}'!${ccol}${anchor['first']}:${ccol}${anchor['last']}"
    return f'=SUMIFS({rng},{crng},"{criterion}")'


def _countifs(anchor, crit_head, criterion):
    ccol = _head_col_named(anchor, crit_head)
    if not ccol:
        return None
    crng = f"'{anchor['sheet']}'!${ccol}${anchor['first']}:${ccol}${anchor['last']}"
    return f'=COUNTIFS({crng},"{criterion}")'


def _count(anchor):
    col = _head_col(anchor, "igst") or "A"
    rng = f"'{anchor['sheet']}'!${col}${anchor['first']}:${col}${anchor['last']}"
    return f"=COUNT({rng})"


def _head_col_named(anchor, heading):
    if not anchor:
        return None
    low = [str(c).strip().lower() for c in anchor.get("cols", [])]
    h = heading.strip().lower()
    return CL(low.index(h) + 1) if h in low else None


def _observation(x) -> str:
    """Everything the reader needs to know about why a row sits where it does."""
    bits = [x.get("_issue", ""), x.get("_confirm_note", "")]
    return " | ".join(b for b in bits if b)


def _awaiting(R) -> list:
    """Probable matches nobody has marked Yes or No yet."""
    return [p["row"] for p in R.get("probable", []) if not p["mark"]]


def _fmts_book():
    f = {i: MONEY for i in range(9, 21)}
    f[1] = DATE
    f[8] = DATE
    return f


def _fmts_2b():
    f = {i: MONEY for i in [12, 13, 15, 16, 17, 18, 19, 21, 22, 26]}
    f[1] = DATE
    f[5] = DATE
    f[28] = DATE
    f[29] = DATE
    return f


# ==========================================================================
# Detail sheets carrying the live SUMIFS grid
# ==========================================================================

def _write_books(ws, R, n2b_last):
    rows = R["books"]
    tol = float(R["cfg"].get("tolerance_rupees", 1.0))
    first, last = 11, 10 + len(rows)

    ws.cell(row=1, column=1, value=R["company_name"]).font = F_TITLE
    ws.cell(row=2, column=1, value=f"GSTIN: {R['company_gstin']}").font = F_SUB
    ws.cell(row=3, column=1, value="GSTR-3B - Voucher Register").font = F_SUB
    ws.cell(row=4, column=1, value=f"Period: {R['month_label']}").font = F_SUB
    ws.cell(row=6, column=1, value="All other Input Tax Credit (Table 4A(5)) - Books").font = F_SECTION
    ws.cell(row=9, column=1, value="Totals").font = F_BOLD
    for c in range(9, 15):
        cell = ws.cell(row=9, column=c,
                       value=f"=SUBTOTAL(9,{CL(c)}{first}:{CL(c)}{max(first,last)})")
        cell.font = F_BOLD
        cell.number_format = MONEY
        cell.fill = FILL_LIGHT

    header_row(ws, 10, BOOK_COLS)
    fmts = _fmts_book()
    r = first
    for rec in rows:
        vals = [
            rec["date"], rec["particulars"], rec["gstin"], rec["vch_type"], rec["vch_no"],
            rec["doc_no"], rec["upd_doc_no"], rec["doc_date"], rec["taxable"],
            rec["igst"], rec["cgst"], rec["sgst"], rec["cess"], rec["tax"],
        ]
        stamp_row(ws, r, vals, fmts=fmts)

        b2b_rng = f"'GSTR 2B'!$O$4:$O${n2b_last}"
        b2b_c = f"'GSTR 2B'!$P$4:$P${n2b_last}"
        g_rng = f"'GSTR 2B'!$F$4:$F${n2b_last}"
        d_rng = f"'GSTR 2B'!$D$4:$D${n2b_last}"
        own_g = f"$C${first}:$C${last}"
        own_d = f"$G${first}:$G${last}"

        ws.cell(row=r, column=15, value=f"=SUMIFS({b2b_rng},{g_rng},$C{r},{d_rng},$G{r})")
        ws.cell(row=r, column=16,
                value=f"=SUMIFS($J${first}:$J${last},{own_g},$C{r},{own_d},$G{r})-O{r}")
        ws.cell(row=r, column=17, value=f'=IF(ABS(P{r})<={tol},"Matched","Not Matched")')
        ws.cell(row=r, column=18, value=f"=SUMIFS({b2b_c},{g_rng},$C{r},{d_rng},$G{r})")
        ws.cell(row=r, column=19,
                value=f"=SUMIFS($K${first}:$K${last},{own_g},$C{r},{own_d},$G{r})-R{r}")
        ws.cell(row=r, column=20, value=f'=IF(ABS(S{r})<={tol},"Matched","Not Matched")')

        if rec.get("cross_remark"):
            ws.cell(row=r, column=21, value=rec["cross_remark"])
        else:
            own_s = f"SUMIFS($L${first}:$L${last},{own_g},$C{r},{own_d},$G{r})"
            two_s = f"SUMIFS('GSTR 2B'!$Q$4:$Q${n2b_last},{g_rng},$C{r},{d_rng},$G{r})"
            own_z = f"SUMIFS($M${first}:$M${last},{own_g},$C{r},{own_d},$G{r})"
            two_z = f"SUMIFS('GSTR 2B'!$Z$4:$Z${n2b_last},{g_rng},$C{r},{d_rng},$G{r})"
            ws.cell(row=r, column=21, value=_verdict_formula(
                have=f"COUNTIFS({g_rng},$C{r},{d_rng},$G{r})",
                diffs=[f"P{r}", f"S{r}", f"({own_s}-{two_s})", f"({own_z}-{two_z})"],
                pairs=[(f"(P{r}+O{r})", f"O{r}"), (f"(S{r}+R{r})", f"R{r}"),
                       (own_s, two_s), (own_z, two_z)],
                tol=tol, books_side=True))
        ws.cell(row=r, column=22, value=rec.get("remark2", ""))
        ws.cell(row=r, column=23, value=rec.get("_match_type", ""))
        note = rec.get("_issue", "")
        if rec.get("_dup_count", 1) > 1:
            note = (note + " | " if note else "") + \
                   f"Document number appears {rec['_dup_count']} times in books - compared on group total"
        if rec.get("_confirm_note"):
            note = (note + " | " if note else "") + rec["_confirm_note"]
        ws.cell(row=r, column=24, value=note)

        for c in range(15, 25):
            cell = ws.cell(row=r, column=c)
            cell.font = F_BODY
            cell.border = BORDER
            if c in (15, 16, 18, 19):
                cell.number_format = MONEY
        r += 1

    widths(ws, BOOK_W)
    autofilter(ws, 10, max(10, last), len(BOOK_COLS))
    ws.freeze_panes = "C11"
    _paint_status(ws, first, last, ["Q", "T", "U"], "W")
    return first, max(first, last)


def _write_2b(ws, R, nbook_last):
    rows = R["b2b"]
    tol = float(R["cfg"].get("tolerance_rupees", 1.0))
    first, last = 4, 3 + len(rows)

    ws.cell(row=1, column=1, value="GSTR-2B (consolidated: B2B, credit/debit notes, "
                                   "amendments, ECO)").font = F_SECTION
    for c in [12, 13, 15, 16, 17, 26]:
        cell = ws.cell(row=2, column=c,
                       value=f"=SUBTOTAL(9,{CL(c)}{first}:{CL(c)}{max(first,last)})")
        cell.font = F_BOLD
        cell.number_format = MONEY
        cell.fill = FILL_LIGHT
    ws.cell(row=2, column=1, value="Totals").font = F_BOLD

    header_row(ws, 3, B2B_COLS)
    fmts = _fmts_2b()
    r = first
    for rec in rows:
        vals = [
            rec.get("gstr1_period") or rec.get("tax_period"), rec["doc_type"],
            rec["purchase_type"], rec["doc_no"], rec["doc_date"], rec["gstin"],
            rec["supplier"], rec.get("supplier_state", ""), rec["pos"], rec["port_code"],
            rec["rev_charge"], rec["doc_value"], rec["taxable"], rec["rate"],
            rec["igst"], rec["cgst"], rec["sgst"],
        ]
        stamp_row(ws, r, vals, fmts=fmts)

        bk_i = f"'All other ITC'!$J${nbook_last[0]}:$J${nbook_last[1]}"
        bk_c = f"'All other ITC'!$K${nbook_last[0]}:$K${nbook_last[1]}"
        bk_g = f"'All other ITC'!$C${nbook_last[0]}:$C${nbook_last[1]}"
        bk_d = f"'All other ITC'!$G${nbook_last[0]}:$G${nbook_last[1]}"
        own_g = f"$F${first}:$F${last}"
        own_d = f"$D${first}:$D${last}"

        ws.cell(row=r, column=18, value=f"=SUMIFS({bk_i},{bk_g},$F{r},{bk_d},$D{r})")
        ws.cell(row=r, column=19,
                value=f"=SUMIFS($O${first}:$O${last},{own_g},$F{r},{own_d},$D{r})-R{r}")
        ws.cell(row=r, column=20, value=f'=IF(ABS(S{r})<={tol},"Matched","Not Matched")')
        ws.cell(row=r, column=21, value=f"=SUMIFS({bk_c},{bk_g},$F{r},{bk_d},$D{r})")
        ws.cell(row=r, column=22,
                value=f"=SUMIFS($P${first}:$P${last},{own_g},$F{r},{own_d},$D{r})-U{r}")
        ws.cell(row=r, column=23, value=f'=IF(ABS(V{r})<={tol},"Matched","Not Matched")')

        if rec.get("cross_remark"):
            ws.cell(row=r, column=24, value=rec["cross_remark"])
        else:
            bk_s = f"'All other ITC'!$L${nbook_last[0]}:$L${nbook_last[1]}"
            bk_m = f"'All other ITC'!$M${nbook_last[0]}:$M${nbook_last[1]}"
            own_s = f"SUMIFS($Q${first}:$Q${last},{own_g},$F{r},{own_d},$D{r})"
            two_s = f"SUMIFS({bk_s},{bk_g},$F{r},{bk_d},$D{r})"
            own_z = f"SUMIFS($Z${first}:$Z${last},{own_g},$F{r},{own_d},$D{r})"
            two_z = f"SUMIFS({bk_m},{bk_g},$F{r},{bk_d},$D{r})"
            ws.cell(row=r, column=24, value=_verdict_formula(
                have=f"COUNTIFS({bk_g},$F{r},{bk_d},$D{r})",
                diffs=[f"S{r}", f"V{r}", f"({own_s}-{two_s})", f"({own_z}-{two_z})"],
                pairs=[(f"(S{r}+R{r})", f"R{r}"), (f"(V{r}+U{r})", f"U{r}"),
                       (own_s, two_s), (own_z, two_z)],
                tol=tol, books_side=False))
        ws.cell(row=r, column=25, value=rec.get("remark2", ""))
        tail = [rec["cess"], rec["is_amendment"], rec["gstr1_period"], rec["gstr1_filed"],
                rec["itc_eligible"], rec["itc_reason"], rec.get("_match_type", ""),
                rec.get("_issue", "")]
        for i, v in enumerate(tail):
            ws.cell(row=r, column=26 + i, value=v)
        for c in range(18, 34):
            cell = ws.cell(row=r, column=c)
            cell.font = F_BODY
            cell.border = BORDER
            if c in (18, 19, 21, 22, 26):
                cell.number_format = MONEY
            if c in (28, 29):
                cell.number_format = DATE
        r += 1

    widths(ws, B2B_W)
    autofilter(ws, 3, max(3, last), len(B2B_COLS))
    ws.freeze_panes = "D4"
    _paint_status(ws, first, last, ["T", "W", "X"], "AF")
    return first, max(first, last)


SHORT_VERDICT = "Matched - GSTR-2B higher"


def _verdict_formula(have, diffs, pairs, tol, books_side):
    """
    The verdict, written so Excel reaches it without help from Python.

    Three outcomes: the two sides agree, or GSTR-2B is the higher of the two and
    the credit taken is limited to the books, or they do not agree at all. The
    sign test keeps a debit note from matching the invoice it reverses.

    diffs are books minus GSTR-2B on the books sheet, and the other way round on
    the GSTR-2B sheet, which is why the one-sided test flips.
    """
    exact = ",".join(f"ABS({d})<={tol}" for d in diffs)
    if books_side:
        within = ",".join(f"{d}<={tol}" for d in diffs)
    else:
        within = ",".join(f"{d}>=-{tol}" for d in diffs)
    signs = ",".join(f"{a}*{b}>=0" for a, b in pairs)
    return (f'=IF({have}=0,"Not Matched",'
            f'IF(AND({exact}),"Matched",'
            f'IF(AND({within},{signs}),"{SHORT_VERDICT}","Not Matched")))')


def _paint_status(ws, first, last, rem_cols, match_col):
    if last < first:
        return
    for c in rem_cols:
        rng = f"{c}{first}:{c}{last}"
        ws.conditional_formatting.add(rng, FormulaRule(
            formula=[f'ISNUMBER(SEARCH("Not Matched",{c}{first}))'],
            fill=FILL_RED, stopIfTrue=False))
        ws.conditional_formatting.add(rng, FormulaRule(
            formula=[f'AND({c}{first}<>"",LEFT({c}{first},7)="Matched")'],
            fill=FILL_GREEN, stopIfTrue=False))
    rng = f"{match_col}{first}:{match_col}{last}"
    for c in rem_cols:
        ws.conditional_formatting.add(f"{c}{first}:{c}{last}", FormulaRule(
            formula=[f'ISNUMBER(SEARCH("GSTR-2B higher",{c}{first}))'],
            fill=FILL_AMBER, stopIfTrue=False))
    ws.conditional_formatting.add(rng, FormulaRule(
        formula=[f'ISNUMBER(SEARCH("Probable",{match_col}{first}))'],
        fill=FILL_ORANGE, stopIfTrue=False))
    ws.conditional_formatting.add(rng, FormulaRule(
        formula=[f'OR(ISNUMBER(SEARCH("Normalised",{match_col}{first})),'
                 f'ISNUMBER(SEARCH("Partial",{match_col}{first})))'],
        fill=FILL_AMBER, stopIfTrue=False))


# ==========================================================================
# Plain listing sheets
# ==========================================================================

def _book_vals(rec):
    return [rec.get("date"), rec.get("particulars"), rec.get("gstin"), rec.get("vch_type"),
            rec.get("vch_no"), rec.get("doc_no"), rec.get("upd_doc_no"), rec.get("doc_date"),
            rec.get("taxable"), rec.get("igst"), rec.get("cgst"), rec.get("sgst"),
            rec.get("cess"), rec.get("tax"), rec.get("remark1") or rec.get("remark", ""),
            rec.get("remark2", "")]


def _b2b_vals(rec):
    return [rec.get("gstr1_period") or rec.get("month"), rec.get("doc_type"),
            rec.get("purchase_type"), rec.get("doc_no"), rec.get("doc_date"),
            rec.get("gstin"), rec.get("supplier") or rec.get("particulars"), rec.get("pos"),
            rec.get("rev_charge"), rec.get("doc_value"), rec.get("taxable"),
            rec.get("igst"), rec.get("cgst"), rec.get("sgst"), rec.get("cess"),
            rec.get("gstr1_period"), rec.get("gstr1_filed"), rec.get("itc_eligible"),
            rec.get("itc_reason"), rec.get("remark1") or rec.get("remark", ""),
            rec.get("remark2", "")]


def _listing(ws, R, title, cols, rows, val_fn, money_cols, date_cols,
             start=4, extra_cols=None, extra_fn=None, note=""):
    ws.cell(row=1, column=1, value=title).font = F_TITLE
    ws.cell(row=2, column=1,
            value=f"{R['company_name']} | {R['company_gstin']} | {R['month_label']}"
                  + (f" | {note}" if note else "")).font = F_SUB
    all_cols = list(cols) + list(extra_cols or [])
    header_row(ws, start - 1, all_cols)

    fmts = {i: MONEY for i in money_cols}
    for i in date_cols:
        fmts[i] = DATE

    r = start
    for rec in rows:
        vals = val_fn(rec)
        if extra_fn:
            vals = vals + extra_fn(rec)
        stamp_row(ws, r, vals, fmts=fmts)
        r += 1

    tot = r
    last = r - 1
    if rows:
        ws.cell(row=tot, column=1, value="Total").font = F_BOLD
        for c in money_cols:
            cell = ws.cell(row=tot, column=c, value=f"=SUBTOTAL(9,{CL(c)}{start}:{CL(c)}{r-1})")
            cell.font = F_BOLD
            cell.number_format = MONEY
            cell.fill = FILL_LIGHT
            cell.border = TOP_LINE
    else:
        ws.cell(row=tot, column=1, value="Nil").font = F_SUB

    for i, _ in enumerate(all_cols, start=1):
        ws.column_dimensions[CL(i)].width = 30 if i == 2 else (20 if i in (3, 6, 7) else 14)
    ws.column_dimensions["A"].width = 12
    autofilter(ws, start - 1, max(start - 1, r - 1), len(all_cols))
    ws.freeze_panes = f"A{start}"
    return {"sheet": ws.title, "total": tot, "first": start, "last": last,
            "cols": all_cols}


BOOK_MONEY = [9, 10, 11, 12, 13, 14]
BOOK_DATE = [1, 8]
B2B_MONEY = [10, 11, 12, 13, 14, 15]
B2B_DATE = [1, 5, 16, 17]


# ==========================================================================
# Deferred ITC Reversal (multi-block)
# ==========================================================================

def _write_reversal(ws, R):
    ws.cell(row=1, column=1, value="Deferred ITC now released").font = F_TITLE
    ws.cell(row=2, column=1,
            value="Invoices carried in the pending master from earlier months that "
                  f"appear in the GSTR-2B of {R['month_label']}.").font = F_SUB
    cols = ["Month", "Date", "Particulars", "Party GSTIN/UIN", "Vch Type", "Vch No.",
            "Doc No.", "Update Doc. No.", "Doc Date", "Taxable Amount", "IGST", "CGST",
            "SGST/UTGST", "Cess", "Tax Amt", "Remark", "Remark 2"]
    money_cols = [10, 11, 12, 13, 14, 15]
    anchors = {}
    r = 4

    def block(heading, groups, add_back: bool):
        nonlocal r
        if not groups:
            return
        ws.cell(row=r, column=1, value=heading).font = F_SECTION
        ws.cell(row=r, column=1).fill = FILL_LIGHT
        r += 1
        for m in sorted(groups, key=month_sort_key):
            recs = groups[m]
            ws.cell(row=r, column=1, value=f"{_lbl(m)}  ({len(recs)} invoices)").font = F_BOLD
            r += 1
            header_row(ws, r, cols)
            r += 1
            start = r
            for rec in recs:
                vals = [rec.get("month"), rec.get("date"), rec.get("particulars"),
                        rec.get("gstin"), rec.get("vch_type"), rec.get("vch_no"),
                        rec.get("doc_no"), rec.get("upd_doc_no"), rec.get("doc_date"),
                        rec.get("taxable"), rec.get("igst"), rec.get("cgst"),
                        rec.get("sgst"), rec.get("cess"), rec.get("tax"),
                        rec.get("remark"), rec.get("remark2")]
                stamp_row(ws, r, vals,
                          fmts={**{i: MONEY for i in money_cols}, 2: DATE, 9: DATE})
                r += 1
            ws.cell(row=r, column=1, value="Total").font = F_BOLD
            for c in money_cols:
                cell = ws.cell(row=r, column=c, value=f"=SUM({CL(c)}{start}:{CL(c)}{r-1})")
                cell.font = F_BOLD
                cell.number_format = MONEY
                cell.fill = FILL_LIGHT
                cell.border = TOP_LINE
            if add_back:
                anchors[m] = r
            r += 2

    block("A. Eligible ITC released - added back to Table 4(A)(5)",
          R["released_eligible"], True)
    block("B. Blocked credit now matched - no add back (already reversed under 4(B)(1))",
          R["released_ineligible"], False)
    block("C. Matched but time barred under section 16(4) - NOT claimed, see Require Correction",
          R.get("released_timebarred", {}), False)

    if not R["released_eligible"] and not R["released_ineligible"]:
        ws.cell(row=4, column=1, value="No pending items were cleared this month.").font = F_SUB

    for i in range(1, len(cols) + 1):
        ws.column_dimensions[CL(i)].width = 30 if i == 3 else (20 if i in (4, 7, 8, 16) else 14)
    ws.freeze_panes = "A4"
    return anchors


# ==========================================================================
# Calculation sheet
# ==========================================================================

def _write_calc(ws, R, rev_anchors, book_rows):
    tol = float(R["cfg"].get("tolerance_rupees", 1.0))
    ws.cell(row=1, column=1, value="Table 4(A)(5) and 4(B)(1) build-up").font = F_TITLE
    ws.cell(row=2, column=1,
            value=f"{R['company_name']} | {R['company_gstin']} | {R['month_label']}").font = F_SUB

    header_row(ws, 4, ["Particulars", "IGST", "CGST", "SGST/UTGST", "Cess", "Source"])
    fm = {2: MONEY, 3: MONEY, 4: MONEY, 5: MONEY}

    bs, be = book_rows
    r = 5
    ws.cell(row=r, column=1, value="All other ITC as per books").font = F_BOLD
    for i, c in enumerate("JKLM"):
        cell = ws.cell(row=r, column=2 + i, value=f"='All other ITC'!{c}9")
        cell.number_format = MONEY
        cell.font = F_BOLD
    ws.cell(row=r, column=6, value="Tally - All other ITC register")
    row_books = r
    r += 1

    ws.cell(row=r, column=1, value="Less: ITC only in books, not in GSTR-2B (deferred)")
    for i, c in enumerate("JKLM"):
        cell = ws.cell(row=r, column=2 + i,
                       value=f"=-'Deferred ITC'!{c}{R['_anchor_def_total']}")
        cell.number_format = MONEY
    ws.cell(row=r, column=6, value="Deferred ITC sheet")
    r += 1

    rev_rows = []
    for m in sorted(rev_anchors, key=month_sort_key):
        ws.cell(row=r, column=1, value=f"Add: Deferred ITC of {_lbl(m)} released this month")
        for i, c in enumerate("KLMN"):
            cell = ws.cell(row=r, column=2 + i,
                           value=f"='Deferred ITC Reversal'!{c}{rev_anchors[m]}")
            cell.number_format = MONEY
        ws.cell(row=r, column=6, value="Deferred ITC Reversal sheet")
        rev_rows.append(r)
        r += 1

    if not rev_anchors:
        ws.cell(row=r, column=1, value="Add: Deferred ITC released this month")
        for c in range(2, 6):
            ws.cell(row=r, column=c, value=0).number_format = MONEY
        rev_rows.append(r)
        r += 1

    r += 1
    t45 = r
    ws.cell(row=r, column=1, value="Amount to be reported in Table 4(A)(5)").font = F_BOLD
    for c in range(2, 6):
        L = CL(c)
        parts = "+".join(f"{L}{x}" for x in rev_rows)
        cell = ws.cell(row=r, column=c, value=f"={L}{row_books}+{L}{row_books+1}+{parts}")
        cell.font = F_BOLD
        cell.fill = FILL_LIGHT
        cell.number_format = MONEY
    r += 2

    header_row(ws, r, ["Particulars", "IGST", "CGST", "SGST/UTGST", "Cess", "Source"])
    r += 1
    ib = r
    ws.cell(row=r, column=1, value="Ineligible ITC - all other ITC (section 17(5))")
    for i, h in enumerate(("igst", "cgst", "sgst", "cess")):
        ws.cell(row=r, column=2 + i, value=R["t_ineligible_books"][h]).number_format = MONEY
    ws.cell(row=r, column=6, value="Tally - Ineligible ITC register")
    r += 1
    ws.cell(row=r, column=1, value="Ineligible ITC - reverse charge")
    for i, h in enumerate(("igst", "cgst", "sgst", "cess")):
        ws.cell(row=r, column=2 + i, value=R["t_rcm_ineligible"][h]).number_format = MONEY
    ws.cell(row=r, column=6, value="Tally - Ineligible ITC register (RCM lines)")
    r += 1
    if R["t_ineligible_other"]["tax"]:
        ws.cell(row=r, column=1, value="Ineligible ITC - other")
        for i, h in enumerate(("igst", "cgst", "sgst", "cess")):
            ws.cell(row=r, column=2 + i, value=R["t_ineligible_other"][h]).number_format = MONEY
        r += 1
    ie = r - 1
    t4b = r
    ws.cell(row=r, column=1, value="Amount to be reported in Table 4(B)(1)").font = F_BOLD
    for c in range(2, 6):
        L = CL(c)
        cell = ws.cell(row=r, column=c, value=f"=SUM({L}{ib}:{L}{ie})")
        cell.font = F_BOLD
        cell.fill = FILL_LIGHT
        cell.number_format = MONEY
    r += 2

    # ---- full Table 4 -----------------------------------------------------
    header_row(ws, r, ["Table 4 - Eligible ITC", "IGST", "CGST", "SGST/UTGST", "Cess", "Source"])
    r += 1
    rows4 = [
        ("(A)(1) Import of goods", R["t4a1"],
         "GSTR-2B" if str(R["cfg"].get("import_of_goods_source", "2B")).upper() == "2B" else "Books"),
        ("(A)(2) Import of services", R["t4a2"], "Books"),
        ("(A)(3) Inward supplies liable to reverse charge", R["t4a3"], "Books"),
        ("(A)(4) Inward supplies from ISD", R["t4a4"], "GSTR-2B"),
    ]
    a_start = r
    for label, t, src in rows4:
        ws.cell(row=r, column=1, value=label)
        for i, h in enumerate(("igst", "cgst", "sgst", "cess")):
            ws.cell(row=r, column=2 + i, value=t[h]).number_format = MONEY
        ws.cell(row=r, column=6, value=src)
        r += 1
    ws.cell(row=r, column=1, value="(A)(5) All other ITC")
    for c in range(2, 6):
        ws.cell(row=r, column=c, value=f"={CL(c)}{t45}").number_format = MONEY
    ws.cell(row=r, column=6, value="Calculated above")
    a_end = r
    r += 1
    ws.cell(row=r, column=1, value="(A) Total ITC available").font = F_BOLD
    for c in range(2, 6):
        cell = ws.cell(row=r, column=c, value=f"=SUM({CL(c)}{a_start}:{CL(c)}{a_end})")
        cell.font = F_BOLD
        cell.number_format = MONEY
        cell.fill = FILL_LIGHT
    tot_a = r
    r += 1
    ws.cell(row=r, column=1, value="(B)(1) ITC reversed - rules 38, 42, 43 and section 17(5)")
    for c in range(2, 6):
        ws.cell(row=r, column=c, value=f"={CL(c)}{t4b}").number_format = MONEY
    tot_b = r
    r += 1
    ws.cell(row=r, column=1, value="(C) Net ITC available").font = F_BOLD
    for c in range(2, 6):
        cell = ws.cell(row=r, column=c, value=f"={CL(c)}{tot_a}-{CL(c)}{tot_b}")
        cell.font = F_BOLD
        cell.number_format = MONEY
        cell.fill = FILL_GREEN
    r += 2

    ws.cell(row=r, column=1, value="Notes").font = F_SECTION
    r += 1
    ws.cell(row=r, column=1,
            value="Every figure above is a live formula. Change a row on a detail sheet and "
                  "this build-up updates with it.").font = F_SUB
    r += 1
    ws.cell(row=r, column=1,
            value=f"Matching tolerance in use: Rs {tol:,.2f} per tax head.").font = F_SUB

    widths(ws, {"A": 56, "B": 17, "C": 16, "D": 16, "E": 13, "F": 40})
    ws.freeze_panes = "B5"
    return t45, t4b


# ==========================================================================
# Entries
# ==========================================================================

REVERSAL_HEAD_COL = {"taxable": "J", "igst": "K", "cgst": "L", "sgst": "M", "cess": "N"}
THREEB_HEAD_COL = {"taxable": "B", "igst": "C", "cgst": "D", "sgst": "E", "cess": "F"}


def _entry_ref(src, head, anchors, rev_anchors, rows_3b, rows_so=None, sub=None):
    """Where an entry's amount comes from, as a formula on the schedule behind it."""
    if not src or not head:
        return None, None
    rows_so = rows_so or {}
    kind, key = src
    if kind == "sheet":
        a = anchors.get(key)
        if not a:
            return None, None
        if head == "all":
            parts = [_head_col(a, h) for h in ("igst", "cgst", "sgst", "cess")]
            parts = [f"'{a['sheet']}'!{c}{a['total']}" for c in parts if c]
            return (f"={'+'.join(parts)}" if parts else None), a["sheet"]
        return _ref(a, head), a["sheet"]
    if kind == "reversal":
        row = rev_anchors.get(key)
        col = REVERSAL_HEAD_COL.get(head)
        if not row or not col:
            return None, None
        return f"='Deferred ITC Reversal'!{col}{row}", "Deferred ITC Reversal"
    if kind == "setoff":
        row = rows_so.get(sub)
        col = SETOFF_HEAD_COL.get(head)
        if not row or not col:
            return None, None
        return f"='ITC Set-off'!{col}{row}", "ITC Set-off"
    if kind == "3b":
        row = rows_3b.get(key)
        if not row:
            return None, None
        if head == "all":
            cols = [THREEB_HEAD_COL[h] for h in ("igst", "cgst", "sgst", "cess")]
            return "=" + "+".join(f"'GSTR-3B'!{c}{row}" for c in cols), "GSTR-3B"
        col = THREEB_HEAD_COL.get(head)
        return (f"='GSTR-3B'!{col}{row}" if col else None), "GSTR-3B"
    return None, None


SETOFF_HEAD_COL = {"igst": "B", "cgst": "C", "sgst": "D"}


def _write_setoff(ws, R, rows_3b):
    """
    How the credit was used, in the order the law fixes.

    Every figure here either points at where it came from or is worked out from
    the rows above it. Only two things are typed: the opening credit ledger,
    which comes from outside the workbook, and the three allocation rows, which
    are the result of the statutory order and cannot be expressed as a cell
    formula. Everything else follows from those.

    Reverse charge is shown separately and never set off: section 49(4) allows
    credit against output tax only, and tax paid under reverse charge is not the
    recipient's output tax.
    """
    so = R.get("setoff") or {}
    used = so.get("used", {})
    ws.cell(row=1, column=1, value="Utilisation of input tax credit").font = F_TITLE
    ws.cell(row=2, column=1,
            value=f"{R['company_name']} | {R['company_gstin']} | {R['month_label']}"
            ).font = F_SUB
    ws.cell(row=3, column=1,
            value="Sections 49(5), 49A and rule 88A. The IGST balance is used first and "
                  f"in full, and is applied {so.get('order', 'CGST first')} once the IGST "
                  "liability is met. CGST credit can never pay SGST, nor SGST pay CGST."
            ).font = F_SUB

    header_row(ws, 5, ["Particulars", "IGST", "CGST", "SGST/UTGST", "Total"])
    heads = ("igst", "cgst", "sgst")
    cols = {"igst": "B", "cgst": "C", "sgst": "D"}

    def line(r, label, values, bold=False, fill=None, fmt_only=False):
        cell = ws.cell(row=r, column=1, value=label)
        cell.font = F_BOLD if bold else F_BODY
        for i, h in enumerate(heads):
            v = values.get(h)
            x = ws.cell(row=r, column=2 + i, value=v)
            x.number_format = MONEY
            if bold:
                x.font = F_BOLD
        tot = ws.cell(row=r, column=5, value=f"=SUM(B{r}:D{r})")
        tot.number_format = MONEY
        if bold:
            tot.font = F_BOLD
        if fill:
            for col in range(1, 6):
                ws.cell(row=r, column=col).fill = fill

    r_open, r_add, r_avail = 6, 7, 8
    r_liab, r_i, r_c, r_s, r_cash = 10, 11, 12, 13, 14
    r_util, r_close = 16, 17
    r_disc, r_rcm = 19, 21

    # The one figure that genuinely comes from outside this workbook.
    line(r_open, "Opening balance in the electronic credit ledger",
         {h: r2((so.get("opening") or {}).get(h, 0.0)) for h in heads})

    t4c = rows_3b.get("t4c")
    line(r_add, "Add: net input tax credit for the month, Table 4(C)",
         {h: (f"='GSTR-3B'!{THREEB_HEAD_COL[h]}{t4c}" if t4c
              else r2((so.get("added") or {}).get(h, 0.0))) for h in heads})
    line(r_avail, "Credit available",
         {h: f"=SUM({cols[h]}{r_open}:{cols[h]}{r_add})" for h in heads},
         bold=True, fill=FILL_LIGHT)

    t31a = rows_3b.get("t31a")
    line(r_liab, "Output tax payable",
         {h: (f"='GSTR-3B'!{THREEB_HEAD_COL[h]}{t31a}" if t31a
              else r2((so.get("liability") or {}).get(h, 0.0))) for h in heads},
         bold=True)

    def cross(use, against):
        return r2(used.get((use, against), 0.0))

    line(r_i, "Less: paid from IGST credit",
         {"igst": cross("igst", "igst"), "cgst": cross("igst", "cgst"),
          "sgst": cross("igst", "sgst")})
    line(r_c, "Less: paid from CGST credit",
         {"igst": cross("cgst", "igst"), "cgst": cross("cgst", "cgst"), "sgst": None})
    line(r_s, "Less: paid from SGST/UTGST credit",
         {"igst": cross("sgst", "igst"), "cgst": None, "sgst": cross("sgst", "sgst")})

    line(r_cash, "Payable in cash",
         {h: (f"={cols[h]}{r_liab}-{cols[h]}{r_i}-{cols[h]}{r_c}-{cols[h]}{r_s}")
          for h in heads}, bold=True, fill=FILL_LIGHT)

    # Each head's own allocation row read across, which is what that head paid.
    util_rows = {"igst": r_i, "cgst": r_c, "sgst": r_s}
    line(r_util, "Credit utilised out of each head",
         {h: f"=SUM(B{util_rows[h]}:D{util_rows[h]})" for h in heads},
         bold=True, fill=FILL_LIGHT)
    line(r_close, "Closing balance in the electronic credit ledger",
         {h: f"={cols[h]}{r_avail}-{cols[h]}{r_util}" for h in heads},
         bold=True, fill=FILL_LIGHT)

    # The entry debits the liability discharged, which is the liability less the
    # cash still to be paid, so it needs a line of its own to point at.
    line(r_disc, "Output liability met out of credit",
         {h: f"={cols[h]}{r_liab}-{cols[h]}{r_cash}" for h in heads},
         bold=True, fill=FILL_GREEN)

    t31d = rows_3b.get("t31d")
    line(r_rcm, "Reverse charge under Table 3.1(d), payable in cash",
         {h: (f"='GSTR-3B'!{THREEB_HEAD_COL[h]}{t31d}" if t31d
              else r2((so.get("rcm_cash") or {}).get(h, 0.0))) for h in heads},
         bold=True, fill=FILL_AMBER)

    ws.cell(row=r_rcm + 2, column=1,
            value="Only the opening balance and the three allocation rows are typed in. "
                  "The opening balance comes from the electronic credit ledger, entered "
                  "on the Inputs tab or read from the portal download. Everything else "
                  "on this sheet is worked out from the rows above or points at the "
                  "GSTR-3B sheet.").font = F_SUB

    widths(ws, {"A": 56, "B": 20, "C": 18, "D": 18, "E": 20})
    ws.freeze_panes = "B6"
    return {"available": r_avail, "liability": r_liab, "cash": r_cash,
            "utilised": r_util, "closing": r_close, "discharged": r_disc,
            "rcm": r_rcm, "opening": r_open}


def _write_entries(ws, R, anchors, rev_anchors, rows_3b, rows_so):
    ws.cell(row=1, column=1, value="Journal entries to be passed in Tally").font = F_TITLE
    ws.cell(row=2, column=1,
            value=f"{R['company_name']} | {R['company_gstin']} | {R['month_label']}").font = F_SUB
    ws.cell(row=3, column=1,
            value="Every amount below is linked to the working it comes from. Click the "
                  "entry heading to open that working, or press Ctrl and [ on an amount "
                  "to jump straight to the cell behind it.").font = F_SUB
    header_row(ws, 4, ["#", "Particulars", "Debit", "Credit", "Narration", "Backup working"])
    r = 5
    for i, e in enumerate(R["entries"], start=1):
        ws.cell(row=r, column=1, value=i).font = F_BOLD
        c = ws.cell(row=r, column=2, value=e["title"])
        c.font = F_BOLD
        c.fill = FILL_LIGHT
        ws.cell(row=r, column=5, value=e["narration"]).alignment = Alignment(wrap_text=True, vertical="top")
        ws.cell(row=r, column=5).font = F_SUB
        _, src_sheet = _entry_ref(e.get("src"), "igst", anchors, rev_anchors, rows_3b,
                                  rows_so, "discharged")
        if src_sheet:
            _link(ws, r, 6, src_sheet, src_sheet, bold=True)
        r += 1
        start = r
        for line in e["lines"]:
            name, dr, cr = line[0], line[1], line[2]
            head = line[3] if len(line) > 3 else None
            sub = line[4] if len(line) > 4 else None
            ref, _ = _entry_ref(e.get("src"), head, anchors, rev_anchors, rows_3b,
                                rows_so, sub)
            stamp_row(ws, r, ["", name,
                              (ref if (ref and dr) else (dr or None)),
                              (ref if (ref and cr) else (cr or None))],
                      fmts={3: MONEY, 4: MONEY})
            r += 1
        for c_ in (3, 4):
            cell = ws.cell(row=r, column=c_, value=f"=SUM({CL(c_)}{start}:{CL(c_)}{r-1})")
            cell.font = F_BOLD
            cell.number_format = MONEY
            cell.border = TOP_LINE
        ws.cell(row=r, column=2, value="Total").font = F_BOLD
        r += 2
    widths(ws, {"A": 5, "B": 40, "C": 16, "D": 16, "E": 70, "F": 26})
    ws.freeze_panes = "A5"
    return 5, max(5, r - 1)


# ==========================================================================
# GSTR-3B
# ==========================================================================

TABLE4_MAP = {
    "4a1": ("1. Import of Goods", "t4a1"),
    "4a2": ("2. Import of Services", "t4a2"),
    "4a3": ("3. Inward Supplies applicable", "t4a3"),
    "4a4": ("4. Inward Supplies from ISD", "t4a4"),
    "4a5": ("5. All other Input Tax Credit", "t4a5"),
}


def _ties(a: dict, b: dict, tol: float) -> bool:
    """Does a schedule total agree with the figure being reported off it?"""
    for h in ("taxable", "igst", "cgst", "sgst", "cess"):
        if abs(float(a.get(h) or 0.0) - float(b.get(h) or 0.0)) > tol:
            return False
    return True


def _write_3b(ws, R, calc_t45_row, calc_t4b_row, anchors):
    ws.cell(row=1, column=1, value="GSTR-3B").font = F_TITLE
    ws.cell(row=2, column=1,
            value=f"{R['company_name']} | {R['company_gstin']} | {R['month_label']}").font = F_SUB
    header_row(ws, 4, ["Particulars", "Taxable Value", "IGST", "CGST", "SGST/UTGST",
                       "Cess", "Total Tax", "Source"])

    t = R["tally"]["gstr3b"]["summary"]

    def tally_of(prefix):
        for k, v in t.items():
            if k.lower().startswith(prefix.lower()):
                return v
        return None

    def line(r, label, vals, source, bold=False, fill=None, anchor=None):
        ws.cell(row=r, column=1, value=label).font = F_BOLD if bold else F_BODY
        if anchor:
            _link(ws, r, 1, anchor["sheet"], label, bold=bold)
        for i, key in enumerate(("taxable", "igst", "cgst", "sgst", "cess")):
            ref = _ref(anchor, key) if anchor else None
            c = ws.cell(row=r, column=2 + i, value=ref or (vals.get(key) or None))
            c.number_format = MONEY
            if bold:
                c.font = F_BOLD
        c = ws.cell(row=r, column=7, value=f"=SUM(C{r}:F{r})")
        c.number_format = MONEY
        if bold:
            c.font = F_BOLD
        ws.cell(row=r, column=8, value=source).font = F_SUB
        for cc in range(1, 9):
            cell = ws.cell(row=r, column=cc)
            cell.border = BORDER
            if fill:
                cell.fill = fill
        return r + 1

    r = 5
    ws.cell(row=r, column=1, value="3.1 Tax on outward and reverse charge inward supplies").font = F_SECTION
    r += 1
    tol = float(R["cfg"].get("tolerance_rupees", 1.0))
    rows_3b = {}
    for prefix, key, sheet, label in (
            ("3.1a", "t31a", "Table 3.1a",
             "3.1(a) Outward taxable supplies (other than zero rated, nil rated, exempted)"),
            ("3.1b", "t31b", "Table 3.1b", "3.1(b) Outward taxable supplies (zero rated)"),
            ("3.1c", "t31c", "Table 3.1c", "3.1(c) Other outward supplies (nil rated, exempted)"),
            ("3.1d", "t31d", "Table 3.1d", "3.1(d) Inward supplies liable to reverse charge"),
            ("3.1e", "t31e", "Table 3.1e", "3.1(e) Non-GST outward supplies")):
        v = dict(R["t31d"]) if prefix == "3.1d" else (tally_of(prefix) or {})
        reg = totals(R["tally"]["registers"].get(key, []))
        # Only point the return at the schedule when the two actually agree. A
        # figure must never move because it was linked.
        anchor = anchors.get(sheet) if _ties(reg, v, tol) else None
        src = ("Tally - Table 3.1(d) register" if prefix == "3.1d" else "Tally")
        if not anchor and any(abs(float(v.get(h) or 0)) > tol
                              for h in ("taxable", "igst", "cgst", "sgst", "cess")):
            src += " (does not tie to its schedule, see the Summary)"
            R.setdefault("_tieout_gaps", []).append((label, sheet, dict(v), dict(reg)))
        rows_3b[prefix.replace("3.1", "t31")] = r
        r = line(r, label, v, src, anchor=anchor)

    r += 1
    ws.cell(row=r, column=1, value="4 Eligible ITC").font = F_SECTION
    r += 1
    a_start = r
    use_2b = str(R["cfg"].get("import_of_goods_source", "2B")).upper() == "2B"
    impg_sheet = "IMPG-2B" if (use_2b and R["impg_2b"]) else "IMPG Books"
    for key, label, src, sheet in (
            ("t4a1", "(A)(1) Import of goods", "GSTR-2B" if use_2b else "Tally", impg_sheet),
            ("t4a2", "(A)(2) Import of services", "Tally", "IMPS Books"),
            ("t4a3", "(A)(3) Inward supplies liable to reverse charge", "Tally", "RCM ITC Books"),
            ("t4a4", "(A)(4) Inward supplies from ISD", "GSTR-2B", "ISD-2B")):
        rows_3b[key] = r
        r = line(r, label, R[key], src, anchor=anchors.get(sheet))
    ws.cell(row=r, column=1, value="(A)(5) All other ITC")
    for i, c in enumerate("BCDE"):
        cell = ws.cell(row=r, column=3 + i,
                       value=f"='All other ITC-4A(5)-Calculation'!{c}{calc_t45_row}")
        cell.number_format = MONEY
    ws.cell(row=r, column=7, value=f"=SUM(C{r}:F{r})").number_format = MONEY
    ws.cell(row=r, column=8, value="Reconciliation build-up").font = F_SUB
    for cc in range(1, 9):
        ws.cell(row=r, column=cc).border = BORDER
    rows_3b["t4a5"] = r
    a_end = r
    r += 1

    ws.cell(row=r, column=1, value="(A) Total ITC available").font = F_BOLD
    for c in range(3, 8):
        cell = ws.cell(row=r, column=c, value=f"=SUM({CL(c)}{a_start}:{CL(c)}{a_end})")
        cell.font = F_BOLD
        cell.number_format = MONEY
        cell.fill = FILL_LIGHT
        cell.border = BORDER
    rows_3b["t4a"] = r
    tot_a = r
    r += 1
    ws.cell(row=r, column=1, value="(B)(1) ITC reversed - rules 38, 42, 43 and section 17(5)")
    for i, c in enumerate("BCDE"):
        cell = ws.cell(row=r, column=3 + i,
                       value=f"='All other ITC-4A(5)-Calculation'!{c}{calc_t4b_row}")
        cell.number_format = MONEY
        cell.border = BORDER
    ws.cell(row=r, column=7, value=f"=SUM(C{r}:F{r})").number_format = MONEY
    rows_3b["t4b1"] = r
    tot_b = r
    r += 1
    ws.cell(row=r, column=1, value="(B)(2) ITC reversed - others")
    for c in range(3, 8):
        ws.cell(row=r, column=c, value=0).number_format = MONEY
    rows_3b["t4b2"] = r
    tot_b2 = r
    r += 1
    ws.cell(row=r, column=1, value="(C) Net ITC available (A - B)").font = F_BOLD
    for c in range(3, 8):
        cell = ws.cell(row=r, column=c,
                       value=f"={CL(c)}{tot_a}-{CL(c)}{tot_b}-{CL(c)}{tot_b2}")
        cell.font = F_BOLD
        cell.number_format = MONEY
        cell.fill = FILL_GREEN
        cell.border = BORDER
    rows_3b["t4c"] = r
    r += 2

    v = tally_of("5 Exempt") or tally_of("5.")
    if v:
        r = line(r, "5 Exempt, nil rated and non-GST inward supplies", v, "Tally")

    ws.cell(row=r + 1, column=1,
            value="Table 4 above is the reconciled position. The Tally figure for each line is "
                  "shown on the Summary sheet against the reconciled figure.").font = F_SUB
    widths(ws, {"A": 60, "B": 18, "C": 16, "D": 15, "E": 15, "F": 12, "G": 16, "H": 30})
    ws.freeze_panes = "B5"
    return rows_3b


# ==========================================================================
# Supplier watchlist
# ==========================================================================

STATUS_FILL = {"Critical": FILL_RED, "Serious": FILL_ORANGE,
               "Watch": FILL_AMBER, "Monitor": None}


def _write_watchlist(ws, R):
    rows = R.get("watchlist", [])
    ws.cell(row=1, column=1, value="Supplier watchlist").font = F_TITLE
    ws.cell(row=2, column=1,
            value="Suppliers whose invoices we have booked but who have not reported them "
                  "in GSTR-1, so the credit sits blocked. Ranked by how many separate "
                  "months they keep appearing and how much tax is held up.").font = F_SUB

    crit = [w for w in rows if w["status"] == "Critical"]
    act = [w for w in rows if w["status"] in ("Critical", "Serious", "Watch")]
    held = r2(sum(w["open_tax"] for w in act))
    ws.cell(row=4, column=1,
            value=f"{len(act)} suppliers need action, {len(crit)} of them critical.   "
                  f"Rs {held:,.2f} of credit is held up."
            ).font = F_SECTION

    cols = ["Status", "Supplier", "GSTIN", "Open items", "Months appearing",
            "IGST", "CGST", "SGST/UTGST", "Total tax held up", "Oldest invoice",
            "Ageing (months)", "Cleared to date", "Avg days to file",
            "% filed late", "Why this supplier is listed", "Section 16(4) risk"]
    fmts = {6: MONEY, 7: MONEY, 8: MONEY, 9: MONEY, 10: DATE, 14: "0%"}

    def block(start_row, group):
        r = start_row
        header_row(ws, r, cols)
        r += 1
        first = r
        for w in group:
            stamp_row(ws, r, [
                w["status"], w["name"], w["gstin"], w["open_n"], w["open_months"],
                w["open_igst"], w["open_cgst"], w["open_sgst"], w["open_tax"],
                w["oldest"], w["ageing"] or None, w["cleared_n"],
                w["avg_delay"], (w["late_pct"] / 100.0) if w["seen_2b"] else None,
                w["why"], w.get("risk", "")], fmts=fmts)
            fill = STATUS_FILL.get(w["status"])
            c = ws.cell(row=r, column=1)
            c.font = F_BOLD
            if fill:
                c.fill = fill
            r += 1
        if group:
            ws.cell(row=r, column=2, value="Total").font = F_BOLD
            for cc in (4, 6, 7, 8, 9):
                cell = ws.cell(row=r, column=cc,
                               value=f"=SUM({CL(cc)}{first}:{CL(cc)}{r-1})")
                cell.font = F_BOLD
                cell.number_format = MONEY if cc >= 6 else "#,##0"
                cell.fill = FILL_LIGHT
                cell.border = TOP_LINE
            r += 1
        return r

    # Management reads the short list; the rest is kept for reference below it.
    action = [w for w in rows if w["status"] in ("Critical", "Serious", "Watch")]
    rest = [w for w in rows if w["status"] == "Monitor"]

    r = 6
    ws.cell(row=r, column=1,
            value=f"A.  Needs action - {len(action)} suppliers").font = F_SECTION
    ws.cell(row=r, column=1).fill = FILL_LIGHT
    r = block(r + 1, action)
    if not action:
        ws.cell(row=r, column=1, value="Nothing needs chasing this month.").font = F_SUB
        r += 1

    r += 2
    ws.cell(row=r, column=1,
            value=f"B.  For reference - {len(rest)} suppliers with an occasional "
                  f"delay").font = F_SECTION
    ws.cell(row=r, column=1).fill = FILL_GREY
    r = block(r + 1, rest)

    widths(ws, {"A": 11, "B": 40, "C": 18, "D": 11, "E": 16, "F": 14, "G": 14, "H": 15,
                "I": 18, "J": 14, "K": 15, "L": 15, "M": 15, "N": 12, "O": 62, "P": 46})
    ws.freeze_panes = "C8"


# ==========================================================================
# Dashboard
# ==========================================================================

def _tile(ws, row, col, span, label, value, note="", fill=FILL_LIGHT, fmt=None,
          accent=None):
    ws.merge_cells(start_row=row, start_column=col, end_row=row, end_column=col + span - 1)
    ws.merge_cells(start_row=row + 1, start_column=col, end_row=row + 1, end_column=col + span - 1)
    ws.merge_cells(start_row=row + 2, start_column=col, end_row=row + 2, end_column=col + span - 1)
    c = ws.cell(row=row, column=col, value=label)
    c.font = Font(name=B.FONT_EXCEL, size=9, bold=True, color=B.MUTED)
    c.alignment = Alignment(horizontal="left", vertical="center")
    v = ws.cell(row=row + 1, column=col, value=value)
    v.font = Font(name=B.FONT_EXCEL, size=20, bold=True, color=accent or NAVY_HEX)
    v.alignment = Alignment(horizontal="left", vertical="center")
    if fmt:
        v.number_format = fmt
    n = ws.cell(row=row + 2, column=col, value=note)
    n.font = Font(name=B.FONT_EXCEL, size=9, color=B.MUTED)
    n.alignment = Alignment(horizontal="left", vertical="top")
    for rr in range(row, row + 3):
        for cc in range(col, col + span):
            ws.cell(row=rr, column=cc).fill = fill
    # A rule in the tile's own colour, on the row above. Angular, no borders
    # drawn round the tile itself, which keeps the grid clean.
    for cc in range(col, col + span):
        r = ws.cell(row=row - 1, column=cc)
        r.fill = PatternFill("solid", fgColor=accent or B.BLUE)
    ws.row_dimensions[row - 1].height = 4
    ws.row_dimensions[row].height = 15
    ws.row_dimensions[row + 1].height = 26
    ws.row_dimensions[row + 2].height = 15


def _bar(dsheet, ws, anchor, title, first_row, n_rows, n_series=1,
         horizontal=False, height=7.4, width=15.2, labels=True, num_fmt="#,##0"):
    ch = BarChart()
    ch.type = "bar" if horizontal else "col"
    ch.title = title
    ch.height, ch.width = height, width
    ch.gapWidth = 60
    # The guide is explicit: no rounded edges. Excel rounds chart frames by
    # default, so it has to be turned off on every chart.
    ch.roundedCorners = False
    if ch.title is not None:
        ch.title.overlay = False
    data = Reference(dsheet, min_col=2, max_col=1 + n_series,
                     min_row=first_row, max_row=first_row + n_rows)
    cats = Reference(dsheet, min_col=1, min_row=first_row + 1, max_row=first_row + n_rows)
    ch.add_data(data, titles_from_data=True)
    ch.set_categories(cats)
    for i, colour in enumerate((SERIES_1, SERIES_2)[:n_series]):
        s = ch.series[i]
        s.graphicalProperties.solidFill = colour
        s.graphicalProperties.line.noFill = True
    for ser in ch.series:
        ser.invertIfNegative = False   # a negative bar keeps the series hue
    if labels:
        ch.dLbls = DataLabelList()
        ch.dLbls.showVal = True
        ch.dLbls.numFmt = num_fmt
        ch.dLbls.showSerName = False
        ch.dLbls.showCatName = False
        ch.dLbls.showLegendKey = False
        # The chart-level format is not always honoured; set it per series too,
        # or the labels print as raw figures with decimals.
        for ser in ch.series:
            ser.dLbls = DataLabelList()
            ser.dLbls.showVal = True
            ser.dLbls.numFmt = num_fmt
            ser.dLbls.showSerName = False
            ser.dLbls.showCatName = False
            ser.dLbls.showLegendKey = False
    if n_series == 1:
        ch.legend = None          # one series: the title already names it
    else:
        ch.legend.position = "b"
        ch.legend.overlay = False
    ch.y_axis.numFmt = num_fmt
    ch.x_axis.delete = False
    ch.y_axis.delete = False
    # force every category label to print rather than every other one
    ch.x_axis.tickLblSkip = 1
    ch.x_axis.tickMarkSkip = 1
    ws.add_chart(ch, anchor)
    return ch


NAVY_HEX = B.BLUE


def _brandmark(ws, anchor):
    """
    The EXI logo, where the workbook can carry it.

    openpyxl needs Pillow to place an image, and this tool is meant to run with
    nothing but openpyxl. So the logo is a bonus: without Pillow the sheet
    carries the name in type instead, and nothing fails.
    """
    path = B.asset("exi_logo_colour_240")
    if path:
        try:
            from openpyxl.drawing.image import Image as XLImage
            img = XLImage(path)
            # Sized to the two title rows, so it never reaches the tiles below.
            img.width, img.height = 60, 42
            ws.add_image(img, anchor)
            return True
        except Exception:
            pass
    c = ws[anchor]
    c.value = "EXACTITUDE INTERNATIONAL"
    c.font = Font(name=B.FONT_EXCEL, size=10, bold=True, color=B.BLUE)
    c.alignment = Alignment(horizontal="right", vertical="center")
    return False


def _write_dashboard(ws, R, dsheet, dsheet_rows_3b=None, deferred_ref=None, rows_so_cash=None):
    money_all = lambda t: r2(t["igst"] + t["cgst"] + t["sgst"] + t.get("cess", 0))

    ws.sheet_view.showGridLines = False
    ws.row_dimensions[1].height = 30
    ws.row_dimensions[2].height = 17
    _brandmark(ws, "O1")
    ws.cell(row=1, column=1, value=R["company_name"] or "GST Reconciliation").font = \
        Font(name=B.FONT_EXCEL, size=18, bold=True, color=NAVY_HEX)
    ws.cell(row=2, column=1,
            value=f"GSTR-2B vs books   |   GSTIN {R['company_gstin']}   |   "
                  f"{R['month_label']}").font = F_SUB

    books_n = len(R["books"])
    matched_n = sum(1 for x in R["books"] if x["_matched"])
    pct = (100.0 * matched_n / books_n) if books_n else 0
    hot = [w for w in R.get("watchlist", []) if w["status"] in ("Critical", "Serious")]
    probable = _awaiting(R)

    # Blue carries the figures being reported, brown what is waiting, red the
    # one tile that asks for a decision. That is the guide's own proportion.
    # Every money tile points at the sheet that carries the figure, so the
    # dashboard cannot drift away from the working behind it.
    g3 = dsheet_rows_3b or {}
    def at3b(key):
        row = g3.get(key)
        return f"='GSTR-3B'!G{row}" if row else None

    _tile(ws, 4, 1, 3, "NET ITC TO CLAIM  -  TABLE 4(C)",
          at3b("t4c") or money_all(R["t4c"]),
          "IGST + CGST + SGST", FILL_LIGHT, MONEY, accent=B.BLUE)
    # A real number, not the text "90%", or Excel flags every one of these tiles
    _tile(ws, 4, 5, 3, "MATCHED WITH GSTR-2B", round(pct / 100.0, 4),
          f"{matched_n} of {books_n} vouchers", FILL_LIGHT, "0%", accent=B.BLUE)
    _tile(ws, 4, 9, 3, "CREDIT DEFERRED THIS MONTH", deferred_ref or money_all(R["t_deferred"]),
          f"{len(R['deferred'])} invoices not yet in GSTR-2B", FILL_AMBER, MONEY,
          accent=B.BROWN)
    _tile(ws, 4, 13, 3, "SUPPLIERS TO CHASE", len(hot),
          f"Rs {r2(sum(w['open_tax'] for w in hot)):,.0f} held up", FILL_AMBER,
          accent=B.BROWN)

    _tile(ws, 8, 1, 3, "TABLE 4(A)(5)  ALL OTHER ITC", at3b("t4a5") or money_all(R["t4a5"]),
          "after reconciliation", FILL_LIGHT, MONEY, accent=B.BLUE)
    _tile(ws, 8, 5, 3, "TABLE 4(B)(1)  BLOCKED CREDIT", at3b("t4b1") or money_all(R["t4b1"]),
          f"{len(R['ineligible_register'])} vouchers reversed", FILL_LIGHT, MONEY,
          accent=B.BLUE)
    _tile(ws, 8, 9, 3, "PAYABLE IN CASH AFTER SET-OFF",
          (f"='ITC Set-off'!E{rows_so_cash}" if rows_so_cash
           else money_all((R.get("setoff") or {}).get("cash", {}))),
          "besides reverse charge, which is paid in cash", FILL_LIGHT, MONEY,
          accent=B.BLUE_MID)
    _tile(ws, 8, 13, 3, "NEEDS A DECISION", len(R["require_correction"]) + len(probable),
          f"{len(probable)} probable matches, "
          f"{len(R['require_correction'])} corrections", FILL_RED, accent=B.RED)

    r = 12
    ws.cell(row=r, column=1, value="Jump to").font = F_SECTION
    links = [("Summary", "Summary"), ("Return figures", "GSTR-3B"),
             ("4(A)(5) build-up", "All other ITC-4A(5)-Calculation"),
             ("Journal entries", "Entries"), ("Supplier watchlist", "Supplier Watchlist"),
             ("Needs correction", "Require Correction"),
             ("Probable matches", "Probable Matches")]
    for i, (text, sheet) in enumerate(links):
        _link(ws, r, 3 + i * 2, sheet, text)
    r += 2

    # ---- chart source data (kept on a hidden sheet) ----------------------
    # Amounts across the return differ by three orders of magnitude, so the
    # position chart counts documents (comparable) and the money chart shows only
    # the exception buckets (also comparable). Putting the 21m matched figure on a
    # bar chart beside a 90k one just draws one bar and four slivers.
    d = dsheet
    d["A1"], d["B1"] = "Position", "Documents"
    pos = [("Matched", sum(1 for x in R["books"] if x["_matched"])),
           ("Only in books", len(R["only_books"])),
           ("Only in GSTR-2B", len(R["only_2b"])),
           ("Blocked credit", len(R["ineligible_register"]))]
    for i, (k, v) in enumerate(pos):
        d.cell(row=2 + i, column=1, value=k)
        d.cell(row=2 + i, column=2, value=v)

    base = 8
    barred = [x for g in R.get("released_timebarred", {}).values() for x in g]
    d.cell(row=base, column=1, value="Exception")
    d.cell(row=base, column=2, value="Tax")
    risk = [("Deferred to later", money_all(R["t_deferred"])),
            ("In 2B, not booked", money_all(totals(R["only_2b"]))),
            ("Blocked - 4(B)(1)", money_all(R["t4b1"])),
            ("Released this month", money_all(R["t_released"])),
            ("Time barred", money_all(totals(barred)))]
    for i, (k, v) in enumerate(risk):
        d.cell(row=base + 1 + i, column=1, value=k)
        d.cell(row=base + 1 + i, column=2, value=v)

    # Ageing profile of everything still open, keyed on a real month so that
    # 'Dec-2025' and 'Dec-25' from different sheets land in the same bar.
    ageing = defaultdict(lambda: [0.0, 0.0])

    def _bucket(rec, slot):
        if rec.get("_cleared_now"):
            return
        key = month_sort_key(rec.get("month")) or (0, 0)
        if key == (0, 0):
            key = month_sort_key(R["month"])
        ageing[key][slot] += (rec.get("igst", 0) or 0) + (rec.get("cgst", 0) or 0) \
            + (rec.get("sgst", 0) or 0)

    for rec in R["open_books_master"] + R["only_books"]:
        _bucket(rec, 0)
    for rec in R["open_b2b_master"] + R["only_2b"]:
        _bucket(rec, 1)
    months = sorted(ageing)[-9:]
    abase = base + 8
    d.cell(row=abase, column=1, value="Month")
    d.cell(row=abase, column=2, value="Not in GSTR-2B")
    d.cell(row=abase, column=3, value="Not in books")
    _MON = ("", "Jan", "Feb", "Mar", "Apr", "May", "Jun",
            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
    for i, key in enumerate(months):
        yr, mn = key
        d.cell(row=abase + 1 + i, column=1,
               value=f"{_MON[mn]}'{str(yr)[2:]}" if 1 <= mn <= 12 else "Earlier")
        d.cell(row=abase + 1 + i, column=2, value=r2(ageing[key][0]))
        d.cell(row=abase + 1 + i, column=3, value=r2(ageing[key][1]))

    top = [w for w in R.get("watchlist", []) if w["open_tax"] > 0][:6]
    sbase = abase + 16
    d.cell(row=sbase, column=1, value="Supplier")
    d.cell(row=sbase, column=2, value="Tax held up")
    for i, w in enumerate(reversed(top)):
        d.cell(row=sbase + 1 + i, column=1, value=w["name"][:24])
        d.cell(row=sbase + 1 + i, column=2, value=w["open_tax"])

    _bar(d, ws, "A15", "Reconciliation position  (number of documents)", 1, len(pos))
    _bar(d, ws, "I15", "Credit at stake  (Rs of tax)", base, len(risk))
    if months:
        _bar(d, ws, "A31", "Still unmatched, by month of invoice  (Rs of tax)",
             abase, len(months), n_series=2, labels=False)
    if top:
        _bar(d, ws, "I31", "Suppliers holding up the most credit  (Rs of tax)",
             sbase, len(top), horizontal=True, height=8.0)

    ws.cell(row=47, column=1,
            value="Every figure on this page is explained on the Summary sheet, and every "
                  "count there links to the rows behind it.").font = F_SUB
    widths(ws, {c: 11 for c in "ABCDEFGHIJKLMNOP"})
    ws.column_dimensions["A"].width = 15
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True


# ==========================================================================
# Summary
# ==========================================================================

def _apply_links(ws, row, link, t, count_col=2, first_money=3):
    """
    Replace the typed figures on a Summary row with formulas off the schedule.

    Only the three tax heads and the count are linked; the total column is
    already a sum of the row. A figure is left as typed when the schedule has no
    column for it, so nothing can silently become zero.
    """
    if not link:
        return
    anchor, crit_head, criterion = link
    if not anchor:
        return
    for i, head in enumerate(("igst", "cgst", "sgst")):
        ref = (_sumifs(anchor, head, crit_head, criterion) if crit_head
               else _ref(anchor, head))
        if ref:
            c = ws.cell(row=row, column=first_money + i, value=ref)
            c.number_format = MONEY
    countable = anchor.get("first", 0) > 0 and anchor.get("last", 0) >= anchor["first"]
    if count_col and countable:
        cnt = (_countifs(anchor, crit_head, criterion) if crit_head else _count(anchor))
        if cnt:
            ws.cell(row=row, column=count_col, value=cnt)


def _awaiting_links(ws, row, anchor):
    """
    Probable matches still waiting for an answer: the whole schedule less the
    rows already marked. Stated as a subtraction because a blank cell is not
    something SUMIFS can be trusted to test for.
    """
    if not anchor or anchor.get("last", 0) < anchor.get("first", 1):
        return
    for i, head in enumerate(("igst", "cgst", "sgst")):
        col = _head_col(anchor, head)
        ccol = _head_col_named(anchor, "Confirmed")
        if not col or not ccol:
            continue
        rng = f"'{anchor['sheet']}'!${col}${anchor['first']}:${col}${anchor['last']}"
        crng = f"'{anchor['sheet']}'!${ccol}${anchor['first']}:${ccol}${anchor['last']}"
        c = ws.cell(row=row, column=3 + i,
                    value=f'=SUM({rng})-SUMIFS({rng},{crng},"Yes")'
                          f'-SUMIFS({rng},{crng},"No")')
        c.number_format = MONEY
    ccol = _head_col_named(anchor, "Confirmed")
    icol = _head_col(anchor, "igst")
    if ccol and icol:
        irng = f"'{anchor['sheet']}'!${icol}${anchor['first']}:${icol}${anchor['last']}"
        crng = f"'{anchor['sheet']}'!${ccol}${anchor['first']}:${ccol}${anchor['last']}"
        ws.cell(row=row, column=2,
                value=f'=COUNT({irng})-COUNTIFS({crng},"Yes")-COUNTIFS({crng},"No")')


def _pseudo(sheet, total, first, last, cols):
    """An anchor for a sheet that is not written by _listing."""
    return {"sheet": sheet, "total": total, "first": first, "last": last, "cols": cols}


def _write_summary(ws, R, anchors, rows_3b, book_range, b2b_last, rev_anchors):
    ws.cell(row=1, column=1, value="GSTR-2B vs Books - Reconciliation Summary").font = F_TITLE
    ws.cell(row=2, column=1,
            value=f"{R['company_name']}  |  GSTIN {R['company_gstin']}  |  "
                  f"Period {R['month_label']}").font = F_SUB

    r = 4
    alerts = R.get("alerts", [])
    if alerts:
        ws.cell(row=r, column=1,
                value="CHECK THESE BEFORE YOU FILE").font = Font(
                    name="Calibri", size=12, bold=True, color="9C0006")
        r += 1
        for line in alerts:
            c = ws.cell(row=r, column=1, value=line)
            c.font = Font(name="Calibri", size=10, color="9C0006")
            c.fill = FILL_RED
            c.alignment = Alignment(wrap_text=True, vertical="top")
            ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=6)
            ws.row_dimensions[r].height = 44
            r += 1
        r += 1

    ws.cell(row=r, column=1, value="Where the credit went").font = F_SECTION
    r += 1
    header_row(ws, r, ["Particulars", "Invoices", "IGST", "CGST", "SGST/UTGST", "Total tax"])
    r += 1

    def blk(label, rows_or_tot, bold=False, fill=None, goto=None, link=None):
        """
        link is (anchor, criterion_heading, criterion) or (anchor, None, None) for
        a whole schedule. The figure becomes a formula off that schedule so the
        Summary ties to its backup instead of restating a number.
        """
        t = rows_or_tot if isinstance(rows_or_tot, dict) else totals(rows_or_tot)
        vals = [label, t.get("n"), t["igst"], t["cgst"], t["sgst"],
                r2(t["igst"] + t["cgst"] + t["sgst"] + t.get("cess", 0))]
        stamp_row(ws, r, vals, fmts={3: MONEY, 4: MONEY, 5: MONEY, 6: MONEY},
                  font=F_BOLD if bold else F_BODY, fill=fill)
        _apply_links(ws, r, link, t)
        if goto:
            _link(ws, r, 1, goto, label, bold=bold)
        return r + 1

    a_books = _pseudo("All other ITC", 9, book_range[0], book_range[1], BOOK_COLS)
    a_2b = _pseudo("GSTR 2B", 2, 4, b2b_last, B2B_COLS)
    a_3b = _pseudo("GSTR-3B", 0, 0, 0, THREEB_COLS)

    def at_3b(key):
        return _pseudo("GSTR-3B", rows_3b.get(key, 0), 0, 0, THREEB_COLS)

    matched_books = [x for x in R["books"] if x["_matched"]]
    r = blk("Books - All other ITC", R["t_books"], bold=True, fill=FILL_LIGHT,
            goto="All other ITC", link=(a_books, None, None))
    # A cross-month match reads "Matched with GSTR-2B of Jun'26", so the test has
    # to be the same one a reader would apply by eye.
    r = blk("   matched with GSTR-2B", matched_books, goto="All other ITC",
            link=(a_books, "Remark 1", "Matched*"))
    r = blk("   only in books, not in GSTR-2B", R["only_books"],
            goto="ITC only in books; Not in 2B",
            link=(anchors.get("ITC only in books; Not in 2B"), None, None))
    r = blk("      of which eligible - ITC deferred", R["deferred"], goto="Deferred ITC",
            link=(anchors.get("Deferred ITC"), None, None))
    r = blk("      of which blocked credit",
            [x for x in R["only_books"] if x.get("ineligible")], goto="Ineligible ITC",
            link=(anchors.get("ITC only in books; Not in 2B"), "Remark 2", "Ineligible"))
    r += 1
    r = blk("GSTR-2B - all other ITC", totals(R["b2b"]), bold=True, fill=FILL_LIGHT,
            goto="GSTR 2B", link=(a_2b, None, None))
    r = blk("   matched with books", [x for x in R["b2b"] if x["_matched"]], goto="GSTR 2B",
            link=(a_2b, "Remark 1", "Matched*"))
    r = blk("   only in GSTR-2B, not in books", R["only_2b"],
            goto="ITC only in 2b; Not in Books",
            link=(anchors.get("ITC only in 2b; Not in Books"), None, None))
    r += 1
    rel_row = r
    r = blk("Deferred ITC released from earlier months",
            [x for g in R["released_eligible"].values() for x in g], bold=True,
            goto="Deferred ITC Reversal")
    # The reversal sheet is one block per month, so the figure is the sum of the
    # per-month totals rather than a single cell.
    if rev_anchors:
        for i, head in enumerate(("igst", "cgst", "sgst")):
            col = REVERSAL_HEAD_COL[head]
            parts = "+".join(f"'Deferred ITC Reversal'!{col}{row}"
                             for row in rev_anchors.values())
            c = ws.cell(row=rel_row, column=3 + i, value="=" + parts)
            c.number_format = MONEY
            c.font = F_BOLD
    r = blk("Blocked credit cleared from earlier months",
            [x for g in R["released_ineligible"].values() for x in g],
            goto="Deferred ITC Reversal")
    r += 1
    r = blk("Table 4(A)(5) to be reported", R["t4a5"], bold=True, fill=FILL_GREEN,
            goto="GSTR-3B", link=(at_3b("t4a5"), None, None))
    r = blk("Table 4(B)(1) to be reported", R["t4b1"], bold=True, fill=FILL_GREEN,
            goto="GSTR-3B", link=(at_3b("t4b1"), None, None))
    r = blk("Table 4(C) net ITC", R["t4c"], bold=True, fill=FILL_GREEN, goto="GSTR-3B",
            link=(at_3b("t4c"), None, None))

    r += 2
    ws.cell(row=r, column=1, value="Needs your attention").font = F_SECTION
    r += 1
    header_row(ws, r, ["Item", "Count", "IGST", "CGST", "SGST/UTGST", "What to do"])
    r += 1

    def att(label, rows, action, goto=None, link=None):
        t = totals(rows)
        stamp_row(ws, r, [label, len(rows), t["igst"], t["cgst"], t["sgst"], action],
                  fmts={3: MONEY, 4: MONEY, 5: MONEY},
                  fill=FILL_AMBER if rows else None)
        _apply_links(ws, r, link, t, count_col=2)
        if goto:
            _link(ws, r, 1, goto, label)
        return r + 1

    probable = _awaiting(R)
    loose = [x for x in R["books"] + R["b2b"]
             if (x.get("_match_type") or "") in ("Normalised doc no.", "Partial doc no.")]
    hot = [w for w in R.get("watchlist", []) if w["status"] in ("Critical", "Serious")]
    prob_row = r
    r = att("Probable matches - not confirmed", probable,
            "Confirm each one before filing - click to see them", "Probable Matches")
    _awaiting_links(ws, prob_row, anchors.get("Probable Matches"))
    r = att("Matched after cleaning the document number", loose,
            "Review; update the Doc No. in Tally so next month matches first time",
            "Cleaned Doc No Matches",
            link=(anchors.get("Cleaned Doc No Matches"), None, None))
    r = att("Document numbers needing correction", R["require_correction"],
            "Correct in Tally, or ask the supplier to amend", "Require Correction",
            link=(anchors.get("Require Correction"), None, None))
    r = att("Blocked credit reversed under 4(B)(1)", R["ineligible_register"],
            "Confirm the section 17(5) classification in Tally", "Ineligible ITC",
            link=(anchors.get("Ineligible ITC"), None, None))
    r = att("Eligible ITC deferred to a later month", R["deferred"],
            "Follow up with the supplier to file their GSTR-1", "Deferred ITC",
            link=(anchors.get("Deferred ITC"), None, None))
    r = att("In GSTR-2B but not booked", R["only_2b"],
            "Book the invoice, or it stays in the pending master",
            "ITC only in 2b; Not in Books",
            link=(anchors.get("ITC only in 2b; Not in Books"), None, None))
    short = [x for x in R["require_correction"] if x.get("_issue_kind") == "GSTR-2B higher"]
    r = att("GSTR-2B higher than the books - claimed to the extent booked", short,
            "Check whether the purchase was booked short", "Require Correction",
            link=(anchors.get("Require Correction"), "Kind", "GSTR-2B higher"))
    barred = [x for g in R.get("released_timebarred", {}).values() for x in g]
    r = att("Time barred under section 16(4) - not claimed", barred,
            "Credit has lapsed; write it off rather than claiming it", "Require Correction",
            link=(anchors.get("Require Correction"), "Kind", "Time barred"))
    t_hot = {"igst": r2(sum(w["open_igst"] for w in hot)),
             "cgst": r2(sum(w["open_cgst"] for w in hot)),
             "sgst": r2(sum(w["open_sgst"] for w in hot))}
    stamp_row(ws, r, ["Suppliers repeatedly not filing", len(hot), t_hot["igst"],
                      t_hot["cgst"], t_hot["sgst"],
                      "Chase these suppliers - credit stays blocked until they file"],
              fmts={3: MONEY, 4: MONEY, 5: MONEY}, fill=FILL_RED if hot else None)
    _link(ws, r, 1, "Supplier Watchlist", "Suppliers repeatedly not filing")
    r += 1

    warn = R.get("warnings", [])
    if warn:
        r += 1
        ws.cell(row=r, column=1, value="Warnings from reading the inputs").font = F_SECTION
        r += 1
        for w in warn:
            c = ws.cell(row=r, column=1, value=w)
            c.fill = FILL_RED
            ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=6)
            r += 1

    r += 2
    ws.cell(row=r, column=1, value="How the inputs were read").font = F_SECTION
    r += 1
    header_row(ws, r, ["Input", "Detail", "", "", "", ""])
    r += 1
    st = R["stats"]
    info = [
        ("File 1 - Tally books", f"{len(R['books'])} all-other-ITC vouchers, "
                                 f"{len(R['ineligible_register'])} blocked-credit vouchers, "
                                 f"{len(R['rcm_books'])} reverse-charge vouchers"),
        ("File 2 - GSTR-2B", ", ".join(f"{k}: {v}" for k, v in
                                       R["gstr2b"]["sections_read"].items() if v)),
        ("   sections ignored", ", ".join(R["gstr2b"]["sections_skipped"]) or "none"),
        ("File 3 - Pending master", f"{len(R['open_books_master'])} open book items, "
                                    f"{len(R['open_b2b_master'])} open GSTR-2B items brought forward"),
        ("Matching - this month", ", ".join(f"{k}: {v}" for k, v in st["primary"].items())),
        ("Matching - books vs earlier 2B", ", ".join(f"{k}: {v}" for k, v in
                                                     st["books_vs_prior_2b"].items())),
        ("Matching - 2B vs earlier books", ", ".join(f"{k}: {v}" for k, v in
                                                     st["b2b_vs_prior_books"].items())),
        ("Blocked credit determined from", R["ineligible_basis"]),
        ("Tolerance", f"Rs {float(R['cfg'].get('tolerance_rupees',1)):,.2f} per tax head"),
    ]
    for label, detail in info:
        ws.cell(row=r, column=1, value=label).font = F_BOLD
        c = ws.cell(row=r, column=2, value=detail)
        c.alignment = Alignment(wrap_text=True, vertical="top")
        ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=6)
        r += 1

    r += 1
    ws.cell(row=r, column=1, value="GSTR-2B portal summary (for tie-out)").font = F_SECTION
    r += 1
    header_row(ws, r, ["Heading", "3B table", "IGST", "CGST", "SGST/UTGST", "Cess"])
    r += 1
    for row in R["gstr2b"]["summaries"].get("available", []):
        if row["sno"] in ("S.no.", ""):
            continue
        stamp_row(ws, r, [row["heading"], row["table"], row["igst"], row["cgst"],
                          row["sgst"], row["cess"]],
                  fmts={3: MONEY, 4: MONEY, 5: MONEY, 6: MONEY})
        r += 1

    widths(ws, {"A": 52, "B": 14, "C": 17, "D": 16, "E": 16, "F": 58})
    ws.freeze_panes = "A4"


# ==========================================================================
# Driver
# ==========================================================================

PROB_COLS = ["Side", "Date", "Party", "GSTIN", "Vch No.", "Doc No. as booked",
             "Doc No. used for matching", "Matched against document", "Its date",
             "Taxable", "IGST", "CGST", "SGST/UTGST", "Tax", "Match Type", "Verdict",
             "Confirmed", "Decided in", "Effect on this return"]

CONFIRM_COL = PROB_COLS.index("Confirmed") + 1


def _effect(p) -> str:
    if not p["adopted"]:
        return "Not claimed - treated as not matched"
    if p["mark"] == "Yes":
        return "Confirmed by you - credit claimed"
    return "Claimed, but still waiting for your decision"


def _write_probable(ws, R):
    """
    The one sheet that asks something of the reader. Everything else reports.

    The Confirmed column is read back on the next run, so the wording has to make
    clear that leaving it blank is itself a decision about credit already taken.
    """
    entries = R.get("probable", [])
    rejected_now = {p["key"] for p in entries}
    history = [(k, v) for k, v in (R.get("decisions") or {}).items()
               if v.get("mark") == "No" and k not in rejected_now]
    history.sort(key=lambda kv: (kv[1].get("gstin", ""), kv[1].get("booked", "")))

    ws.cell(row=1, column=1, value="Probable matches - please confirm before filing").font = F_TITLE
    ws.cell(row=2, column=1,
            value=f"{R['company_name']} | {R['company_gstin']} | {R['month_label']} | "
                  "Same supplier, same tax and a nearby date, but the document numbers "
                  "differ. Nothing here was matched on the document number.").font = F_SUB
    ws.cell(row=3, column=1,
            value="Mark each row Yes or No in the Confirmed column and save this file. The "
                  "next run reads your marks back. A row left blank is claimed in Table "
                  "4(A)(5) on the tool's suggestion alone.").font = F_SUB

    header_row(ws, 5, PROB_COLS)
    fmts = {i: MONEY for i in (10, 11, 12, 13, 14)}
    fmts[2] = DATE
    fmts[9] = DATE

    r = 6
    first = r
    for p in entries:
        x, other = p["row"], p["other"]
        stamp_row(ws, r, [
            "Books", x.get("date") or x.get("doc_date"), x.get("particulars"),
            x.get("gstin"), x.get("vch_no", ""), x.get("doc_no"),
            x.get("upd_doc_no") or x.get("doc_no"), other.get("doc_no", ""),
            other.get("doc_date"), x.get("taxable"), x.get("igst"), x.get("cgst"),
            x.get("sgst"), x.get("tax"), "Probable - verify", x.get("remark1", ""),
            p["mark"], p["decided_in"], _effect(p)], fmts=fmts)
        r += 1
    last = r - 1

    tot_row = r
    if entries:
        ws.cell(row=r, column=1, value="Total").font = F_BOLD
        for c in (10, 11, 12, 13, 14):
            cell = ws.cell(row=r, column=c, value=f"=SUBTOTAL(9,{CL(c)}{first}:{CL(c)}{last})")
            cell.font = F_BOLD
            cell.number_format = MONEY
            cell.fill = FILL_LIGHT
            cell.border = TOP_LINE
    else:
        ws.cell(row=r, column=1, value="Nil - nothing needs confirming this month").font = F_SUB
    r += 2

    hist_first = hist_last = 0
    if history:
        ws.cell(row=r, column=1, value="Previously rejected - kept so you can change your mind"
                ).font = F_SECTION
        r += 1
        ws.cell(row=r, column=1,
                value="These pairs were marked No in an earlier month, so they are no longer "
                      "suggested and no credit is taken on them. Change a No to Yes here and "
                      "the next run will match them.").font = F_SUB
        r += 1
        header_row(ws, r, PROB_COLS)
        r += 1
        hist_first = r
        for k, v in history:
            stamp_row(ws, r, ["Books", None, "", v.get("gstin", ""), "", v.get("booked", ""),
                              "", v.get("against", ""), None, None, None, None, None, None,
                              "Probable - rejected", "", v.get("mark", ""),
                              v.get("decided_in", ""), "Not claimed - rejected earlier"],
                      fmts=fmts)
            r += 1
        hist_last = r - 1

    pick = DataValidation(type="list", formula1='"Yes,No"', allow_blank=True,
                          showDropDown=False)
    pick.error = "Please choose Yes or No."
    pick.errorTitle = "Yes or No"
    pick.prompt = ("Yes confirms the match. No rejects it, and it will not be suggested "
                   "again. Blank means the credit is claimed but nobody has looked at it.")
    pick.promptTitle = "Confirm this match"
    ws.add_data_validation(pick)
    col = CL(CONFIRM_COL)
    if entries:
        pick.add(f"{col}{first}:{col}{last}")
        ws.conditional_formatting.add(
            f"{col}{first}:{col}{last}",
            FormulaRule(formula=[f'{col}{first}=""'], fill=FILL_ORANGE, stopIfTrue=False))
        ws.conditional_formatting.add(
            f"{col}{first}:{col}{last}",
            FormulaRule(formula=[f'{col}{first}="Yes"'], fill=FILL_GREEN, stopIfTrue=False))
        ws.conditional_formatting.add(
            f"{col}{first}:{col}{last}",
            FormulaRule(formula=[f'{col}{first}="No"'], fill=FILL_GREY, stopIfTrue=False))
    if hist_first:
        pick.add(f"{col}{hist_first}:{col}{hist_last}")

    for i, _ in enumerate(PROB_COLS, start=1):
        ws.column_dimensions[CL(i)].width = 30 if i == 3 else (
            22 if i in (4, 6, 7, 8) else (34 if i == 19 else 14))
    ws.column_dimensions["A"].width = 12
    autofilter(ws, 5, max(5, last), len(PROB_COLS))
    ws.freeze_panes = "A6"
    return {"sheet": ws.title, "total": tot_row, "first": first, "last": last,
            "cols": PROB_COLS}


LEDGER_COLS = ["Ledger", "Closing balance per Tally", "Effect of the entries",
               "After the entries", "What it should be", "Difference", "Read from"]

HEADS3 = ("igst", "cgst", "sgst")


def _write_ledger_recon(ws, R, entries_rows, rows_so=None):
    """
    The nine GST ledgers, before and after the entries this tool proposes.

    The movement column is a live SUMIF over the Entries sheet rather than a
    figure repeated from Python, so if an entry is edited the reconciliation
    follows it.
    """
    rec = R.get("ledger_recon") or {}
    rows = rec.get("rows", [])
    rows_so = rows_so or {}
    first_e, last_e = entries_rows
    deferred_cells = []

    ws.cell(row=1, column=1, value="Ledgers reconciliation").font = F_TITLE
    ws.cell(row=2, column=1,
            value=f"{R['company_name']} | {R['company_gstin']} | {R['month_label']}"
            ).font = F_SUB
    ws.cell(row=3, column=1,
            value="Closing balance per the ledgers, plus the effect of the entries on "
                  "the Entries sheet, against what each ledger should stand at once "
                  "those entries are passed. Figures are debit positive; a credit "
                  "balance is shown in brackets.").font = F_SUB

    header_row(ws, 5, LEDGER_COLS)
    r = 6
    for group in LG.read_gl.GROUPS:
        ws.cell(row=r, column=1, value=group).font = F_SECTION
        for c in range(1, len(LEDGER_COLS) + 1):
            ws.cell(row=r, column=c).fill = FILL_LIGHT
        r += 1
        first = r
        for row in [x for x in rows if x["group"] == group]:
            name = LG.ENTRY_NAME.get(row["key"], "")
            rng_n = f"Entries!$B${first_e}:$B${last_e}"
            rng_d = f"Entries!$C${first_e}:$C${last_e}"
            rng_c = f"Entries!$D${first_e}:$D${last_e}"
            movement = ('=SUMIF(' + rng_n + ',"' + name + '",' + rng_d + ')'
                        '-SUMIF(' + rng_n + ',"To ' + name + '",' + rng_c + ')')
            ws.cell(row=r, column=1, value=row["label"]).font = F_BODY
            if row["found"]:
                ws.cell(row=r, column=2, value=row["closing"]).number_format = MONEY
            else:
                c = ws.cell(row=r, column=2, value="not found")
                c.font = Font(name=B.FONT_EXCEL, size=10, italic=True, color=B.RED)
            ws.cell(row=r, column=3, value=movement).number_format = MONEY
            if row["found"]:
                ws.cell(row=r, column=4, value=f"=B{r}+C{r}").number_format = MONEY
                ws.cell(row=r, column=6, value=f"=D{r}-E{r}").number_format = MONEY
            # The expected figure points at its source rather than repeating it.
            col_so = SETOFF_HEAD_COL.get(row["head"])
            ref = None
            if col_so and row["key"].startswith("input_") and rows_so.get("closing"):
                ref = f"='ITC Set-off'!{col_so}{rows_so['closing']}"
            elif col_so and row["key"].startswith("payable_") and rows_so.get("cash"):
                ref = f"=-'ITC Set-off'!{col_so}{rows_so['cash']}"
            elif row["key"].startswith("deferred_"):
                deferred_cells.append((r, row["head"]))
            ws.cell(row=r, column=5,
                    value=ref if ref else row["expected"]).number_format = MONEY
            ws.cell(row=r, column=7, value=row.get("where", "")).font = F_SUB
            for c in range(1, len(LEDGER_COLS) + 1):
                ws.cell(row=r, column=c).border = BORDER
            r += 1
        ws.cell(row=r, column=1, value="Total  " + group).font = F_BOLD
        for c in range(2, 7):
            cell = ws.cell(row=r, column=c,
                           value=f"=SUM({CL(c)}{first}:{CL(c)}{r-1})")
            cell.font = F_BOLD
            cell.number_format = MONEY
            cell.border = TOP_LINE
        r += 2

    ws.cell(row=r, column=1,
            value="What the deferred ledgers should stand at").font = F_SECTION
    r += 1
    header_row(ws, r, ["Particulars", "IGST", "CGST", "SGST/UTGST", "Total"])
    r += 1
    for label, key in (("Open eligible items carried in the pending master", "carried"),
                       ("Add: eligible ITC deferred this month", "new_deferred"),
                       ("Add: credit time barred this month, not yet written off",
                        "timebarred")):
        d = rec.get(key) or {}
        ws.cell(row=r, column=1, value=label).font = F_BODY
        for i, h in enumerate(HEADS3):
            ws.cell(row=r, column=2 + i, value=r2(d.get(h, 0.0))).number_format = MONEY
        ws.cell(row=r, column=5, value=f"=SUM(B{r}:D{r})").number_format = MONEY
        r += 1
    ws.cell(row=r, column=1,
            value="Expected balance on the deferred ledgers").font = F_BOLD
    for i, h in enumerate(HEADS3):
        cell = ws.cell(row=r, column=2 + i,
                       value=r2((rec.get("expected_deferred") or {}).get(h, 0.0)))
        cell.number_format = MONEY
        cell.font = F_BOLD
        cell.fill = FILL_LIGHT
    ws.cell(row=r, column=5, value=f"=SUM(B{r}:D{r})").number_format = MONEY
    # Now that the block exists, point each deferred ledger's expected figure at it.
    for cell_row, head in deferred_cells:
        col = {"igst": "B", "cgst": "C", "sgst": "D"}[head]
        c = ws.cell(row=cell_row, column=5, value=f"={col}{r}")
        c.number_format = MONEY
    r += 2

    if rec.get("n_timebarred"):
        c = ws.cell(row=r, column=1,
                    value=f"{rec['n_timebarred']} item(s) released this month are time "
                          "barred under section 16(4). They have left the pending master, "
                          "but no entry takes them out of the deferred ledger, so they "
                          "are shown above as a reconciling item. Write them off to clear "
                          "the ledger.")
        c.font = F_ALERT
        c.alignment = Alignment(wrap_text=True, vertical="top")
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=7)
        ws.row_dimensions[r].height = 30
        r += 2

    extra = rec.get("extra", [])
    if extra:
        ws.cell(row=r, column=1,
                value="Other ledgers the entries touch").font = F_SECTION
        r += 1
        header_row(ws, r, ["Ledger", "Effect of the entries"])
        r += 1
        for e in extra:
            ws.cell(row=r, column=1, value=e["label"]).font = F_BODY
            ws.cell(row=r, column=2, value=e["movement"]).number_format = MONEY
            for c in (1, 2):
                ws.cell(row=r, column=c).border = BORDER
            r += 1
        r += 1
        ws.cell(row=r, column=1,
                value="Reverse charge payables and the expense account are moved by the "
                      "entries but sit outside the nine ledgers being reconciled.").font = F_SUB
        r += 2

    missing = [x["label"] for x in rows if not x["found"]]
    if missing:
        c = ws.cell(row=r, column=1,
                    value="Not found in the ledgers workbook: " + ", ".join(missing) +
                          ". They are shown as not found rather than as nil. Check the "
                          "spellings under 'ledger_names' in settings.json.")
        c.font = F_ALERT
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=7)
        r += 1
    if not rec.get("any_found"):
        c = ws.cell(row=r, column=1,
                    value="No ledgers workbook was given, so only the effect of the "
                          "entries and the expected balances are shown. Choose the GST "
                          "ledgers file on the Run tab to complete this reconciliation.")
        c.font = F_SUB
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=7)

    widths(ws, {"A": 52, "B": 24, "C": 22, "D": 20, "E": 22, "F": 18, "G": 26})
    ws.freeze_panes = "B6"


def build(R: dict, path: str, extra=None) -> str:
    """extra lets the annual run add its own sheets without reopening the
    file, which would drop the charts."""
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    sheets = {}
    for name in SHEET_ORDER:
        sheets[name] = wb.create_sheet(name[:31])

    n_books = len(R["books"])
    n_2b = len(R["b2b"])
    book_range = (11, max(11, 10 + n_books))
    b2b_last = max(4, 3 + n_2b)

    _write_books(sheets["All other ITC"], R, b2b_last)
    _write_2b(sheets["GSTR 2B"], R, book_range)

    # Deferred ITC -------------------------------------------------------
    anchors = {}
    anchors["Deferred ITC"] = _listing(sheets["Deferred ITC"], R,
                   "Deferred ITC - eligible credit booked but not in GSTR-2B",
                   PLAIN_BOOK_COLS, R["deferred"], _book_vals, BOOK_MONEY, BOOK_DATE,
                   note="ITC not claimed this month; carried to the pending master",
                   extra_cols=["Observation"], extra_fn=lambda x: [_observation(x)])
    R["_anchor_def_total"] = anchors["Deferred ITC"]["total"]

    rev_anchors = _write_reversal(sheets["Deferred ITC Reversal"], R)

    anchors["ITC only in books; Not in 2B"] = _listing(sheets["ITC only in books; Not in 2B"], R,
             "ITC only in books, not in GSTR-2B", PLAIN_BOOK_COLS, R["only_books"],
             _book_vals, BOOK_MONEY, BOOK_DATE,
             extra_cols=["Match Type", "Observation"],
             extra_fn=lambda x: [x.get("_match_type", ""), _observation(x)])

    anchors["ITC only in 2b; Not in Books"] = _listing(sheets["ITC only in 2b; Not in Books"], R,
             "ITC only in GSTR-2B, not in books", PLAIN_2B_COLS, R["only_2b"],
             _b2b_vals, B2B_MONEY, B2B_DATE,
             extra_cols=["Match Type", "Observation"],
             extra_fn=lambda x: [x.get("_match_type", ""), x.get("_issue", "")])

    anchors["Ineligible ITC"] = _listing(sheets["Ineligible ITC"], R,
             "Ineligible ITC - blocked credit reversed in Table 4(B)(1)",
             PLAIN_BOOK_COLS, R["ineligible_register"], _book_vals, BOOK_MONEY, BOOK_DATE,
             note="Source: Tally Ineligible ITC register")

    anchors["Require Correction"] = _listing(sheets["Require Correction"], R,
             "Entries requiring correction or management attention",
             ["Side", "Date", "Particulars", "GSTIN", "Vch No.", "Doc No.", "Doc Date",
              "Taxable", "IGST", "CGST", "SGST/UTGST", "Tax", "Kind", "Issue",
              "Suggested action"],
             R["require_correction"],
             lambda x: [x.get("_side", ""), x.get("date") or x.get("doc_date"),
                        x.get("particulars") or x.get("supplier"), x.get("gstin"),
                        x.get("vch_no", ""), x.get("doc_no"), x.get("doc_date"),
                        x.get("taxable"), x.get("igst"), x.get("cgst"), x.get("sgst"),
                        x.get("tax"), x.get("_issue_kind", ""), x.get("_issue", ""),
                        _action(x)],
             [8, 9, 10, 11, 12], [2, 7])

    loose = [x for x in R["books"] + R["b2b"]
             if (x.get("_match_type") or "") in ("Normalised doc no.", "Partial doc no.")]
    book_ids = {id(x) for x in R["books"]}

    def _pair_vals(x):
        other = x.get("_match_row") or {}
        return [("Books" if id(x) in book_ids else "GSTR-2B"),
                x.get("date") or x.get("doc_date"),
                x.get("particulars") or x.get("supplier"), x.get("gstin"),
                x.get("vch_no", ""), x.get("doc_no"), x.get("upd_doc_no") or x.get("doc_no"),
                other.get("doc_no", ""), other.get("doc_date"),
                x.get("taxable"), x.get("igst"), x.get("cgst"), x.get("sgst"), x.get("tax"),
                x.get("_match_type", ""), x.get("remark1", "")]

    PAIR_COLS = ["Side", "Date", "Party", "GSTIN", "Vch No.", "Doc No. as booked",
                 "Doc No. used for matching", "Matched against document",
                 "Its date", "Taxable", "IGST", "CGST", "SGST/UTGST", "Tax",
                 "Match Type", "Verdict"]

    anchors["Probable Matches"] = _write_probable(sheets["Probable Matches"], R)

    anchors["Cleaned Doc No Matches"] = _listing(sheets["Cleaned Doc No Matches"], R,
             "Matched after cleaning up the document number",
             PAIR_COLS, loose, _pair_vals, [10, 11, 12, 13, 14], [2, 9],
             note="Matched once case, spaces, slashes and leading zeros were ignored. "
                  "Correcting the Doc No. in Tally makes these match first time next month.")

    _write_watchlist(sheets["Supplier Watchlist"], R)

    anchors["RCM ITC Books"] = _listing(sheets["RCM ITC Books"], R, "Reverse charge - books (Table 4(A)(3))",
             PLAIN_BOOK_COLS, R["rcm_books"], _book_vals, BOOK_MONEY, BOOK_DATE,
             extra_cols=["Blocked credit?"],
             extra_fn=lambda x: ["Yes - reversed in 4(B)(1)" if x.get("ineligible") else "No"])
    anchors["RCM-2B"] = _listing(sheets["RCM-2B"], R, "Reverse charge - as reported in GSTR-2B",
             PLAIN_2B_COLS, R["rcm_2b"], _b2b_vals, B2B_MONEY, B2B_DATE)
    anchors["IMPS Books"] = _listing(sheets["IMPS Books"], R, "Import of services - books (Table 4(A)(2))",
             PLAIN_BOOK_COLS, R["imps_books"], _book_vals, BOOK_MONEY, BOOK_DATE)
    anchors["IMPG Books"] = _listing(sheets["IMPG Books"], R, "Import of goods - books",
             PLAIN_BOOK_COLS, R["impg_books"], _book_vals, BOOK_MONEY, BOOK_DATE)
    anchors["IMPG-2B"] = _listing(sheets["IMPG-2B"], R, "Import of goods - GSTR-2B (Table 4(A)(1))",
             PLAIN_2B_COLS, R["impg_2b"], _b2b_vals, B2B_MONEY, B2B_DATE)

    for key, name, title in (("t31a", "Table 3.1a", "Outward taxable supplies"),
                             ("t31b", "Table 3.1b", "Outward taxable supplies (zero rated)"),
                             ("t31c", "Table 3.1c", "Other outward supplies (nil rated, exempted)"),
                             ("t31d", "Table 3.1d", "Inward supplies liable to reverse charge"),
                             ("t31e", "Table 3.1e", "Non-GST outward supplies")):
        anchors[name] = _listing(sheets[name], R, f"Table 3.1({name[-1]}) - {title}",
                                 PLAIN_BOOK_COLS, R["tally"]["registers"].get(key, []),
                                 _book_vals, BOOK_MONEY, BOOK_DATE)

    # Table 4(A)(4) is reported in the return, so it needs a schedule of its own
    # to be traceable, even in a month where there is no ISD credit at all.
    anchors["ISD-2B"] = _listing(
        sheets["ISD-2B"], R, "Input Service Distributor credit - GSTR-2B (Table 4(A)(4))",
        PLAIN_2B_COLS, R["isd_2b"], _b2b_vals, B2B_MONEY, B2B_DATE)

    t45_row, t4b_row = _write_calc(sheets["All other ITC-4A(5)-Calculation"], R,
                                   rev_anchors, book_range)
    rows_3b = _write_3b(sheets["GSTR-3B"], R, t45_row, t4b_row, anchors)
    rows_so = _write_setoff(sheets["ITC Set-off"], R, rows_3b)
    entries_rows = _write_entries(sheets["Entries"], R, anchors, rev_anchors,
                                 rows_3b, rows_so)
    _write_ledger_recon(sheets["Ledgers Reconciliation"], R, entries_rows,
                        rows_so)
    _write_summary(sheets["Summary"], R, anchors, rows_3b, book_range,
                   b2b_last, rev_anchors)

    dsheet = wb.create_sheet("_ChartData")
    a_def = anchors.get("Deferred ITC")
    deferred_ref = None
    if a_def:
        j = _head_col(a_def, "igst")
        m = _head_col(a_def, "cess") or _head_col(a_def, "sgst")
        if j and m:
            deferred_ref = (f"=SUM('{a_def['sheet']}'!{j}{a_def['total']}:"
                            f"{m}{a_def['total']})")
    _write_dashboard(sheets["Dashboard"], R, dsheet, rows_3b,
                     deferred_ref, rows_so.get("cash"))
    # Excel takes a data label's format from the cell behind it, not from the
    # chart, so the money columns have to be formatted here or the labels print
    # as raw figures with decimals.
    for row in dsheet.iter_rows(min_col=2, max_col=4):
        for cell in row:
            if isinstance(cell.value, (int, float)):
                cell.number_format = "#,##0" if abs(cell.value) < 1000 else "#,##0"
    dsheet.sheet_state = "hidden"

    for ws in wb.worksheets:
        ws.sheet_view.showGridLines = False
    if extra:
        extra(wb, sheets, R)
    wb.active = 0
    wb.save(path)
    return path


def _action(x) -> str:
    kind = x.get("_issue_kind", "")
    if kind == "GSTR-2B higher":
        return ("Credit already claimed to the extent booked. Check whether the "
                "purchase was booked short, and book the difference if so")
    if kind == "Wrong GSTIN":
        return "Correct the supplier GSTIN in Tally, or ask the supplier to amend GSTR-1"
    if kind == "Wrong tax head":
        return "Correct the tax head in Tally, or ask the supplier to amend GSTR-1"
    if kind == "Value difference":
        return "Check the invoice; raise a debit or credit note, or ask for an amendment"
    return "Review"

"""
Prepares the EXI logo files this tool ships with.

The source artwork comes from EXI_Brand_Guidelines.pptx. Nothing here alters the
logo: it is trimmed to its own bounds and scaled, and the white version is the
black one with the ink turned white, which the guide lists as an approved format
("Black and White versions"). No stretching, no rotation, no recolouring of the
brand colours themselves.

Pillow is used here, at preparation time only. The tool itself never needs it:
tkinter reads these PNGs directly.

Run from the project root:  python gstrecon\\assets\\make_assets.py <pptx>
"""

from __future__ import annotations

import os
import sys
import zipfile

from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))

# media part -> (name, what it is)
SOURCES = {
    "ppt/media/image3.png": ("exi_logo_colour", "primary logo, symbol and wordmark"),
    "ppt/media/image4.png": ("exi_logo_black", "primary logo, black"),
    "ppt/media/image1.png": ("exi_symbol_colour", "symbol"),
    "ppt/media/image5.png": ("exi_symbol_black", "symbol, black"),
}


def trimmed(im: Image.Image) -> Image.Image:
    box = im.split()[3].getbbox()
    return im.crop(box) if box else im


def to_white(im: Image.Image) -> Image.Image:
    """The approved white version: same shape, ink turned white."""
    out = Image.new("RGBA", im.size, (255, 255, 255, 0))
    out.putalpha(im.split()[3])
    return out


def scaled(im: Image.Image, height: int) -> Image.Image:
    w = max(1, round(im.width * height / im.height))
    return im.resize((w, height), Image.LANCZOS)


def main(pptx: str) -> None:
    with zipfile.ZipFile(pptx) as z:
        raw = {part: z.read(part) for part in SOURCES}

    import io
    art = {}
    for part, (name, _) in SOURCES.items():
        art[name] = trimmed(Image.open(io.BytesIO(raw[part])).convert("RGBA"))

    made = []

    def save(im, name):
        path = os.path.join(HERE, name + ".png")
        im.save(path)
        made.append((name, im.size))

    # the window header, on brand blue
    save(scaled(to_white(art["exi_logo_black"]), 74), "exi_logo_white_74")
    save(scaled(to_white(art["exi_symbol_black"]), 96), "exi_symbol_white_96")
    # the workbook and anything on white
    save(scaled(art["exi_logo_colour"], 240), "exi_logo_colour_240")
    save(scaled(art["exi_symbol_colour"], 128), "exi_symbol_colour_128")

    for name, size in made:
        print(f"  {name}.png  {size[0]}x{size[1]}")


if __name__ == "__main__":
    src = sys.argv[1] if len(sys.argv) > 1 else \
        os.path.expanduser(r"~\Downloads\EXI_Brand_Guidelines.pptx")
    main(src)

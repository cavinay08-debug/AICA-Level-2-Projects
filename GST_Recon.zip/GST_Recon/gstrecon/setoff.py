"""
Utilisation of input tax credit against output liability.

The order is not a matter of preference. Section 49(5) fixes which credit may
pay which liability, section 49A requires the IGST balance to be exhausted
before CGST or SGST credit is touched at all, and rule 88A allows the IGST
balance to be applied to CGST and SGST in any order once the IGST liability is
met. That last freedom is the only choice in the whole calculation, and it lives
in settings.json as `igst_credit_order`.

Two things that are deliberately kept out of the set-off:

  Reverse charge liability under Table 3.1(d) is payable in cash. Section 49(4)
  allows credit to be used for output tax only, and tax under reverse charge is
  not output tax of the recipient.

  CGST credit can never pay SGST, and SGST credit can never pay CGST.
"""

from __future__ import annotations

from .util import r2

HEADS = ("igst", "cgst", "sgst")


def _take(credit: dict, liability: dict, use: str, against: str, used: dict) -> None:
    """Apply as much of one credit head as the liability will absorb."""
    amount = min(credit[use], liability[against])
    if amount <= 0:
        return
    credit[use] = r2(credit[use] - amount)
    liability[against] = r2(liability[against] - amount)
    used[(use, against)] = r2(used.get((use, against), 0.0) + amount)


def compute(opening: dict, credit_this_month: dict, liability: dict,
            cfg: dict | None = None) -> dict:
    """
    Work out how the credit is used, what is left, and what has to be paid.

    opening            electronic credit ledger brought forward
    credit_this_month  Table 4(C) for the month
    liability          output tax payable, Table 3.1(a) and any other output tax
    """
    cfg = cfg or {}
    order = str(cfg.get("igst_credit_order", "CGST_FIRST")).upper()
    second = ["cgst", "sgst"] if order != "SGST_FIRST" else ["sgst", "cgst"]

    avail = {h: r2(float(opening.get(h, 0) or 0) + float(credit_this_month.get(h, 0) or 0))
             for h in HEADS}
    # Credit cannot be negative. A net credit note position for the month reduces
    # the ledger, it does not create a liability.
    start = dict(avail)
    due = {h: max(0.0, r2(float(liability.get(h, 0) or 0))) for h in HEADS}
    start_due = dict(due)
    used: dict = {}

    # Section 49A: the IGST balance goes first, and must be exhausted before any
    # other credit is used.
    _take(avail, due, "igst", "igst", used)
    for head in second:
        _take(avail, due, "igst", head, used)

    # CGST credit: its own head, then IGST.
    _take(avail, due, "cgst", "cgst", used)
    _take(avail, due, "cgst", "igst", used)

    # SGST credit: its own head, then IGST, and only once CGST credit is gone.
    _take(avail, due, "sgst", "sgst", used)
    if avail["cgst"] <= 0.005:
        _take(avail, due, "sgst", "igst", used)

    return {
        "opening": {h: r2(float(opening.get(h, 0) or 0)) for h in HEADS},
        "added": {h: r2(float(credit_this_month.get(h, 0) or 0)) for h in HEADS},
        "available": {h: r2(start[h]) for h in HEADS},
        "liability": start_due,
        "used": used,
        "utilised_by_credit": {h: r2(sum(v for (u, _a), v in used.items() if u == h))
                               for h in HEADS},
        "discharged_by_head": {h: r2(sum(v for (_u, a), v in used.items() if a == h))
                               for h in HEADS},
        "cash": {h: r2(due[h]) for h in HEADS},
        "closing": {h: r2(avail[h]) for h in HEADS},
        "order": "CGST first" if second[0] == "cgst" else "SGST first",
    }


def rows_for_sheet(s: dict) -> list[tuple]:
    """The set-off laid out the way it is read, top to bottom."""
    u = s["used"]

    def line(label, d, bold=False):
        return (label, d.get("igst", 0.0), d.get("cgst", 0.0), d.get("sgst", 0.0), bold)

    def cross(use, against):
        return r2(u.get((use, against), 0.0))

    return [
        line("Opening balance in the electronic credit ledger", s["opening"]),
        line("Add: net input tax credit for the month, Table 4(C)", s["added"]),
        line("Credit available", s["available"], True),
        ("", None, None, None, False),
        line("Output tax payable", s["liability"], True),
        ("Less: paid from IGST credit", cross("igst", "igst"), cross("igst", "cgst"),
         cross("igst", "sgst"), False),
        ("Less: paid from CGST credit", cross("cgst", "igst"), cross("cgst", "cgst"),
         None, False),
        ("Less: paid from SGST/UTGST credit", cross("sgst", "igst"), None,
         cross("sgst", "sgst"), False),
        line("Payable in cash", s["cash"], True),
        ("", None, None, None, False),
        line("Credit utilised out of each head", s["utilised_by_credit"], True),
        line("Closing balance in the electronic credit ledger", s["closing"], True),
    ]

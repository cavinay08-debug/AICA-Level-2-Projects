"""Shared helpers: number/date coercion, GSTIN and document-number normalisation."""

from __future__ import annotations

import datetime as _dt
import re
import unicodedata

# --------------------------------------------------------------------------
# Numbers
# --------------------------------------------------------------------------

_NUM_CLEAN = re.compile(r"[,\s₹Rs\.]", re.IGNORECASE)


def num(value) -> float:
    """Coerce any cell value to a float. Blank / junk -> 0.0."""
    if value is None:
        return 0.0
    if isinstance(value, bool):
        return 0.0
    if isinstance(value, (int, float)):
        try:
            f = float(value)
        except (TypeError, ValueError):
            return 0.0
        return 0.0 if f != f else f  # NaN guard
    s = str(value).strip()
    if not s:
        return 0.0
    neg = s.startswith("(") and s.endswith(")")
    if neg:
        s = s[1:-1]
    s = s.replace(",", "").replace("₹", "").replace("Rs.", "").replace("Rs", "").strip()
    s = s.replace(" ", "")
    if s in {"-", "--", "NA", "N/A", "#N/A", "nan", "None"}:
        return 0.0
    try:
        f = float(s)
    except ValueError:
        return 0.0
    return -f if neg else f


def r2(value) -> float:
    """Round to 2 dp, killing float noise like 486098.8599999996."""
    return round(num(value) + 0.0, 2)


def is_zero(value, tol: float = 0.005) -> bool:
    return abs(num(value)) <= tol


# --------------------------------------------------------------------------
# Dates
# --------------------------------------------------------------------------

_DATE_FORMATS = (
    "%d/%m/%Y", "%d-%m-%Y", "%d/%m/%y", "%d-%m-%y",
    "%Y-%m-%d", "%Y/%m/%d", "%d-%b-%Y", "%d-%b-%y",
    "%d %b %Y", "%b %d, %Y", "%m/%d/%Y",
)

_MONTHS = {
    "jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6,
    "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12,
}


def to_date(value):
    """Coerce a cell value to datetime.date, or None."""
    if value is None:
        return None
    if isinstance(value, _dt.datetime):
        return value.date()
    if isinstance(value, _dt.date):
        return value
    s = str(value).strip()
    if not s or s in {"#N/A", "NA", "N/A", "-"}:
        return None
    if s.endswith(" 00:00:00"):
        s = s[:-9]
    for fmt in _DATE_FORMATS:
        try:
            return _dt.datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    # Excel serial number
    try:
        serial = float(s)
        if 20000 < serial < 80000:
            return (_dt.date(1899, 12, 30) + _dt.timedelta(days=int(serial)))
    except ValueError:
        pass
    return None


def month_key(d) -> str:
    """date -> 'Jul-26' style tag used throughout the working papers."""
    d = to_date(d)
    if d is None:
        return ""
    return f"{d.strftime('%b')}-{d.strftime('%y')}"


def month_label(d) -> str:
    """date -> \"Jul'26\" style tag used inside remark text."""
    d = to_date(d)
    if d is None:
        return ""
    return f"{d.strftime('%b')}'{d.strftime('%y')}"


def fy_of(d) -> str:
    """Indian financial year label for a date -> '26-27'."""
    d = to_date(d)
    if d is None:
        return ""
    y = d.year if d.month >= 4 else d.year - 1
    return f"{str(y)[2:]}-{str(y + 1)[2:]}"


def parse_period_text(text: str):
    """Read Tally's '1-Jul-26 to 31-Jul-26' banner and return the period end date."""
    if not text:
        return None
    s = str(text)
    m = re.findall(r"(\d{1,2})[-/\s]([A-Za-z]{3,9})[-/\s](\d{2,4})", s)
    if not m:
        return None
    day, mon, yr = m[-1]
    mon_n = _MONTHS.get(mon[:3].lower())
    if not mon_n:
        return None
    yr_n = int(yr)
    if yr_n < 100:
        yr_n += 2000
    try:
        return _dt.date(yr_n, mon_n, int(day))
    except ValueError:
        return None


def month_start(d):
    d = to_date(d)
    return None if d is None else d.replace(day=1)


def month_sort_key(tag: str):
    """'Jul-26' -> (2026, 7) so month tags sort chronologically."""
    if not tag:
        return (0, 0)
    m = re.match(r"([A-Za-z]{3})[-'\s]*(\d{2,4})", str(tag).strip())
    if not m:
        return (0, 0)
    mon = _MONTHS.get(m.group(1).lower(), 0)
    yr = int(m.group(2))
    if yr < 100:
        yr += 2000
    return (yr, mon)


# --------------------------------------------------------------------------
# Text / keys
# --------------------------------------------------------------------------

_GSTIN_RE = re.compile(r"[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[0-9A-Z]{1}[Z]{1}[0-9A-Z]{1}")


def clean_text(value) -> str:
    if value is None:
        return ""
    s = str(value)
    s = unicodedata.normalize("NFKD", s)
    s = s.replace(" ", " ")
    return re.sub(r"\s+", " ", s).strip()


def norm_gstin(value) -> str:
    """Uppercase, strip everything non-alphanumeric. Returns '' for junk."""
    s = clean_text(value).upper()
    s = re.sub(r"[^0-9A-Z]", "", s)
    if len(s) != 15:
        return s if s and s not in {"NA", "NONE", "N/A"} else ""
    return s


def gstin_pan(gstin: str) -> str:
    """Characters 3-12 of a GSTIN = the supplier's PAN."""
    g = norm_gstin(gstin)
    return g[2:12] if len(g) == 15 else ""


def gstin_state(gstin: str) -> str:
    g = norm_gstin(gstin)
    return g[:2] if len(g) >= 2 else ""


def doc_key_exact(value) -> str:
    """Exact-match key: what Excel's SUMIFS would compare (trim + case-insensitive)."""
    return clean_text(value).upper()


def doc_key_norm(value) -> str:
    """
    Forgiving key. Removes every separator and drops leading zeros from each
    numeric run, so 'SS/26-27/00158', 'ss 26 27 158' and 'SS26270158' collapse
    to the same key.
    """
    s = clean_text(value).upper()
    s = re.sub(r"[^0-9A-Z]", "", s)
    if not s:
        return ""
    s = re.sub(r"0+(\d)", r"\1", s)
    return s


def doc_key_tail(value, length: int = 6) -> str:
    """Last N alphanumeric characters -- catches prefix-only differences."""
    s = doc_key_norm(value)
    return s[-length:] if len(s) >= length else s


def yes_no(value) -> str:
    s = clean_text(value).lower()
    if s in {"y", "yes", "true", "1"}:
        return "Yes"
    if s in {"n", "no", "false", "0"}:
        return "No"
    return clean_text(value)


def col_letter(idx: int) -> str:
    """1-based column index -> Excel column letter."""
    out = ""
    while idx > 0:
        idx, rem = divmod(idx - 1, 26)
        out = chr(65 + rem) + out
    return out

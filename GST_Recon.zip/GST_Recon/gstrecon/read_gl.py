"""
Reader for the GST ledgers exported from Tally.

One workbook carrying the nine ledgers: the three GST input ledgers, the three
deferred input ledgers and the three payable ledgers. Two shapes are accepted,
because Tally will give you either depending on how the export is taken:

  a sheet per ledger, each a normal Tally ledger ending in a Closing Balance
  a single sheet listing ledger names against their closing balances

Which name belongs to which ledger is a matter for the chart of accounts, not
for this code, so the spellings live in settings.json under `ledger_names`.

A ledger that cannot be found is reported, never assumed to be nil. A nil
deferred ledger would look like nothing is pending and quietly agree with an
empty master.
"""

from __future__ import annotations

import os
import re

import openpyxl

from .sheetutil import grid, trim_grid
from .util import clean_text, num, r2

# canonical key -> (group, head, label used on the sheet)
LEDGERS = [
    ("input_igst", "GST Inputs", "igst", "IGST Input"),
    ("input_cgst", "GST Inputs", "cgst", "CGST Input"),
    ("input_sgst", "GST Inputs", "sgst", "SGST Input"),
    ("deferred_igst", "GST Deferred Inputs", "igst", "IGST Deferred"),
    ("deferred_cgst", "GST Deferred Inputs", "cgst", "CGST Deferred"),
    ("deferred_sgst", "GST Deferred Inputs", "sgst", "SGST Deferred"),
    ("payable_igst", "GST Payables", "igst", "IGST Payable"),
    ("payable_cgst", "GST Payables", "cgst", "CGST Payable"),
    ("payable_sgst", "GST Payables", "sgst", "SGST Payable"),
]

GROUPS = ("GST Inputs", "GST Deferred Inputs", "GST Payables")

CLOSING_WORDS = ("closing balance", "closing bal", "balance c/f", "carried forward")
OPENING_WORDS = ("opening balance", "opening bal", "balance b/f", "brought forward")

_DR = ("debit", "dr")
_CR = ("credit", "cr")


def _slug(v) -> str:
    return re.sub(r"[^a-z0-9]+", " ", clean_text(v).lower()).strip()


def _match_ledger(text: str, aliases: dict) -> str | None:
    """Which of the nine, if any, this name refers to."""
    t = _slug(text)
    if not t:
        return None
    best, best_len = None, 0
    for key, names in aliases.items():
        for n in names:
            ns = _slug(n)
            if not ns:
                continue
            # "IGST Payable (RCM)" contains "IGST Payable" but is a different
            # ledger: reverse charge is paid in cash and never set off.
            if ("rcm" in t) != ("rcm" in ns):
                continue
            if t == ns:
                return key
            if (t.startswith(ns) or ns in t) and len(ns) > best_len:
                best, best_len = key, len(ns)
    return best


def _dr_cr_columns(row) -> tuple:
    dr = cr = None
    for i, cell in enumerate(row):
        s = _slug(cell)
        if not s:
            continue
        if dr is None and s in _DR:
            dr = i
        elif cr is None and s in _CR:
            cr = i
    return dr, cr


def _present(row, idx) -> bool:
    """Is there a figure in that cell at all? Zero is an answer; blank is not."""
    if idx is None or idx >= len(row):
        return False
    v = row[idx]
    return v is not None and clean_text(v) != ""


def _signed(dr_val: float, cr_val: float) -> float:
    """Debit positive. An input or deferred ledger runs debit, a payable credit."""
    return r2(dr_val - cr_val)


def _from_ledger_sheet(ws, aliases: dict) -> tuple:
    """A Tally ledger: find its name, then its closing balance."""
    rows = trim_grid(grid(ws))
    if not rows:
        return None, None, ""

    key = _match_ledger(ws.title, aliases)
    if key is None:
        for row in rows[:10]:
            for cell in row[:4]:
                key = _match_ledger(cell, aliases)
                if key:
                    break
            if key:
                break
    if key is None:
        return None, None, ""

    dr_col = cr_col = None
    for row in rows[:25]:
        d, c = _dr_cr_columns(row)
        if d is not None or c is not None:
            dr_col, cr_col = d, c
            break

    for i in range(len(rows) - 1, -1, -1):
        label = " ".join(_slug(c) for c in rows[i][:4])
        if not any(w in label for w in CLOSING_WORDS):
            continue
        row = rows[i]
        if dr_col is not None or cr_col is not None:
            d = num(row[dr_col]) if dr_col is not None and dr_col < len(row) else 0.0
            c = num(row[cr_col]) if cr_col is not None and cr_col < len(row) else 0.0
            if _present(row, dr_col) or _present(row, cr_col):
                return key, _signed(d, c), f"'{ws.title}' row {i + 1}"
        # No Debit/Credit heading: take the last figure on the line and read the
        # Dr or Cr marker sitting beside it.
        nums = [(j, num(v)) for j, v in enumerate(row) if isinstance(v, (int, float))]
        if nums:
            j, v = nums[-1]
            marker = " ".join(_slug(x) for x in row[max(0, j - 2):j + 3])
            sign = -1.0 if re.search(r"\bcr\b|credit", marker) else 1.0
            return key, r2(v * sign), f"'{ws.title}' row {i + 1}"
    return None, None, ""


def _from_table(ws, aliases: dict) -> dict:
    """A single sheet listing ledger names against balances."""
    rows = trim_grid(grid(ws))
    out = {}
    if not rows:
        return out

    hdr = None
    dr_col = cr_col = bal_col = None
    for i, row in enumerate(rows[:20]):
        d, c = _dr_cr_columns(row)
        b = None
        for j, cell in enumerate(row):
            sl = _slug(cell)
            # A heading, not a sentence. "closing balances as at 31-Aug" is prose
            # sitting above the table and must not be taken for the header row.
            if len(sl) > 24:
                continue
            if "closing" in sl or sl in ("balance", "amount"):
                b = j
        if d is not None or c is not None or b is not None:
            hdr, dr_col, cr_col, bal_col = i, d, c, b
            break
    if hdr is None:
        return out

    for row in rows[hdr + 1:]:
        key = None
        for cell in row[:3]:
            key = _match_ledger(cell, aliases)
            if key:
                break
        if not key or key in out:
            continue
        if dr_col is not None or cr_col is not None:
            d = num(row[dr_col]) if dr_col is not None and dr_col < len(row) else 0.0
            c = num(row[cr_col]) if cr_col is not None and cr_col < len(row) else 0.0
            # A ledger standing at nil is a reading, not a ledger that is absent.
            if _present(row, dr_col) or _present(row, cr_col):
                out[key] = (_signed(d, c), f"'{ws.title}'")
                continue
        if bal_col is not None and bal_col < len(row):
            v = num(row[bal_col])
            if v:
                joined = " ".join(_slug(x) for x in row)
                sign = -1.0 if re.search(r"\bcr\b|credit", joined) else 1.0
                out[key] = (r2(v * sign), f"'{ws.title}'")
    return out


def read(path: str | None, cfg: dict | None = None) -> tuple[dict, list]:
    """
    Return {ledger key: {"balance": Dr-positive figure, "where": ...}} and warnings.

    A missing ledger is simply absent from the result. The caller must show it as
    not found rather than treating it as nil.
    """
    cfg = cfg or {}
    aliases = cfg.get("ledger_names") or {}
    if not aliases:
        return {}, ["No ledger names are set in settings.json, so the GST ledgers "
                    "could not be identified."]
    if not path:
        return {}, []
    if not os.path.isfile(path):
        return {}, [f"The GST ledgers workbook '{os.path.basename(path)}' could not "
                    f"be found, so the Ledgers Reconciliation has been left empty."]
    try:
        wb = openpyxl.load_workbook(path, data_only=True, read_only=False)
    except Exception as exc:
        return {}, [f"The GST ledgers workbook could not be opened ({exc}). The "
                    f"Ledgers Reconciliation has been left empty."]

    found: dict = {}
    warnings: list = []
    try:
        for name in wb.sheetnames:
            ws = wb[name]
            key, bal, where = _from_ledger_sheet(ws, aliases)
            if key and key not in found:
                found[key] = {"balance": bal, "where": where}
            for k, (v, where2) in _from_table(ws, aliases).items():
                found.setdefault(k, {"balance": v, "where": where2})
    finally:
        wb.close()

    missing = [lbl for key, _g, _h, lbl in LEDGERS if key not in found]
    if missing and found:
        warnings.append(
            f"{len(missing)} of the nine GST ledgers could not be found in "
            f"'{os.path.basename(path)}': {', '.join(missing)}. They are shown as not "
            f"found on the Ledgers Reconciliation rather than as nil. Check the "
            f"spellings under 'ledger_names' in settings.json if the names differ.")
    elif not found:
        warnings.append(
            f"None of the nine GST ledgers could be recognised in "
            f"'{os.path.basename(path)}'. Nothing has been assumed. Check that this is "
            f"the ledgers export, and that the names match 'ledger_names' in "
            f"settings.json.")
    return found, warnings

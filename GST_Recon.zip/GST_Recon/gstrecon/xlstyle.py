"""Shared Excel formatting helpers."""

from __future__ import annotations

from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from . import brand as B

MONEY = '#,##0.00;[Red](#,##0.00);"-"'
MONEY0 = '#,##0;[Red](#,##0);"-"'
DATE = "dd-mmm-yy"

# EXI brand values; see brand.py. The workbook keeps Calibri, which the guide
# names as the fallback for Office, since Fira Sans cannot be relied on to be
# installed wherever this workbook is opened.
NAVY = B.BLUE
BLUE = B.BLUE
BROWN = B.BROWN
LIGHT = B.BLUE_TINT
GREY = B.GREY_TINT
AMBER = B.BROWN_TINT
RED = B.RED_TINT
GREEN = B.BLUE_TINT          # agreed reads blue; the brand owns no green
ORANGE = B.BROWN_TINT_2

FONT = B.FONT_EXCEL

F_TITLE = Font(name=FONT, size=14, bold=True, color=NAVY)
F_SUB = Font(name=FONT, size=10, italic=True, color=B.MUTED)
F_HDR = Font(name=FONT, size=10, bold=True, color="FFFFFF")
F_BOLD = Font(name=FONT, size=10, bold=True)
F_BODY = Font(name=FONT, size=10)
F_SECTION = Font(name=FONT, size=11, bold=True, color=NAVY)
F_BRAND = Font(name=FONT, size=9, bold=True, color=B.BLUE)
F_ALERT = Font(name=FONT, size=10, bold=True, color=B.RED)

FILL_HDR = PatternFill("solid", fgColor=BLUE)
FILL_LIGHT = PatternFill("solid", fgColor=LIGHT)
FILL_GREY = PatternFill("solid", fgColor=GREY)
FILL_AMBER = PatternFill("solid", fgColor=AMBER)
FILL_RED = PatternFill("solid", fgColor=RED)
FILL_GREEN = PatternFill("solid", fgColor=GREEN)
FILL_ORANGE = PatternFill("solid", fgColor=ORANGE)
FILL_BRAND = PatternFill("solid", fgColor=B.BLUE)
FILL_BROWN = PatternFill("solid", fgColor=B.BROWN)

_thin = Side(style="thin", color=B.RULE)
BORDER = Border(left=_thin, right=_thin, top=_thin, bottom=_thin)
TOP_LINE = Border(top=Side(style="thin", color=B.BLUE_TINT_2))


def header_row(ws, row: int, values: list[str], start_col: int = 1,
               fill=FILL_HDR, font=F_HDR, height: float = 28):
    for i, v in enumerate(values):
        c = ws.cell(row=row, column=start_col + i, value=v)
        c.font = font
        c.fill = fill
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        c.border = BORDER
    ws.row_dimensions[row].height = height


def title_block(ws, R: dict, subtitle: str, width: int = 12):
    ws.cell(row=1, column=1, value=R.get("company_name") or "GST Reconciliation").font = F_TITLE
    ws.cell(row=2, column=1,
            value=f"GSTIN {R.get('company_gstin','')}   |   {subtitle}   |   "
                  f"Period: {R.get('month_label','')}").font = F_SUB
    ws.freeze_panes = "A4"


def widths(ws, spec: dict):
    for col, w in spec.items():
        letter = col if isinstance(col, str) else get_column_letter(col)
        ws.column_dimensions[letter].width = w


def money(ws, row: int, cols, fmt: str = MONEY):
    for c in cols:
        ws.cell(row=row, column=c).number_format = fmt


def stamp_row(ws, row: int, values: list, start_col: int = 1, fmts: dict | None = None,
              font=F_BODY, fill=None, border: bool = True):
    for i, v in enumerate(values):
        c = ws.cell(row=row, column=start_col + i, value=v)
        c.font = font
        if fill:
            c.fill = fill
        if border:
            c.border = BORDER
        if fmts and (start_col + i) in fmts:
            c.number_format = fmts[start_col + i]
    return row + 1


def autofilter(ws, first_row: int, last_row: int, last_col: int):
    if last_row >= first_row:
        ws.auto_filter.ref = f"A{first_row}:{get_column_letter(last_col)}{last_row}"


def col(idx: int) -> str:
    return get_column_letter(idx)

"""One code path for doing the work, shared by the window and the console."""

from __future__ import annotations

import datetime as dt
import os

from . import (annual, decisions, ledgers, read_2b, read_gl, read_ledger,
               read_master, read_tally, write_annual, write_master,
               write_working)
from .engine import build_watchlist, journal_entries, reconcile
from .util import month_key, month_label, month_sort_key


class InputError(Exception):
    """Something about the chosen files stops the run before it starts."""


def _noop(_msg, _pct=None):
    pass


def stamp(period_end) -> str:
    if not period_end:
        return dt.date.today().strftime("%b%y")
    return period_end.strftime("%b%y")


def check_inputs(file1, file2, file3, out_dir) -> list[str]:
    """Return a list of problems, empty if everything is usable."""
    problems = []
    for label, path, needed in (("Books (Tally)", file1, True),
                                ("GSTR-2B", file2, True),
                                ("Pending master", file3, False)):
        if not path:
            if needed:
                problems.append(f"{label}: no file chosen.")
            continue
        if not os.path.isfile(path):
            problems.append(f"{label}: '{os.path.basename(path)}' could not be found.")
            continue
        if not path.lower().endswith((".xlsx", ".xlsm", ".xlsb")):
            problems.append(f"{label}: '{os.path.basename(path)}' is not an Excel workbook.")
        lock = os.path.join(os.path.dirname(path), "~$" + os.path.basename(path))
        if os.path.exists(lock):
            problems.append(f"{label}: '{os.path.basename(path)}' looks like it is open in "
                            f"Excel. Please close it first.")

    chosen = [p for p in (file1, file2, file3) if p]
    if len(set(os.path.abspath(p) for p in chosen)) != len(chosen):
        problems.append("The same workbook has been chosen more than once.")

    if not out_dir:
        problems.append("No output folder chosen.")
    else:
        try:
            os.makedirs(out_dir, exist_ok=True)
            probe = os.path.join(out_dir, ".gstrecon_write_test")
            with open(probe, "w") as fh:
                fh.write("x")
            os.remove(probe)
        except OSError:
            problems.append(f"The output folder cannot be written to:\n{out_dir}")
    return problems


def identify(file1, file2, file3) -> list[str]:
    """Warn when a workbook does not look like the role it was chosen for."""
    import openpyxl
    notes = []

    def names(path):
        try:
            wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
            out = [n.lower() for n in wb.sheetnames]
            wb.close()
            return out
        except Exception:
            return []

    if file1 and not any("all other itc" in n or "gstr-3b" in n for n in names(file1)):
        notes.append("The books file has no 'All Other ITC' or 'GSTR-3B' sheet. "
                     "Have the first two files been swapped?")
    if file2 and not any(n == "b2b" or "itc available" in n for n in names(file2)):
        notes.append("The GSTR-2B file has no 'B2B' or 'ITC Available' sheet. "
                     "Is this the workbook downloaded from the portal?")
    if file3 and not any("only in" in n or "not in" in n for n in names(file3)):
        notes.append("The pending master has none of the usual 'Only in ...' sheets.")
    return notes


def _master_period_alert(master, period_end, file3) -> list[str]:
    """
    Re-running a month with the master this tool produced for that same month is
    the one input mistake that makes the return too small rather than too large,
    and it leaves no trace in the figures. Say so in as many words.
    """
    if not file3 or not period_end:
        return []
    hit = read_master.cleared_in_period(master, period_end)
    if not hit["rows"]:
        return []

    label = month_label(period_end)
    months = ", ".join(sorted(hit["months"])) or label
    return [
        f"The pending master '{os.path.basename(file3)}' already records "
        f"{len(hit['rows'])} items as matched in {months}, which is the period being "
        f"worked on. It looks like the master this tool produced for {label}, not the "
        f"one carried in from the month before.",

        f"Rows marked as matched are not offered for matching again, so up to "
        f"Rs {hit['igst']:,.2f} IGST, Rs {hit['cgst']:,.2f} CGST and "
        f"Rs {hit['sgst']:,.2f} SGST of credit that should be released this month "
        f"will be missing from Table 4(A)(5). The return would be understated.",

        f"Choose the pending master from the month before {label} and run again. "
        f"If you are certain this is the right file, the figures above stand.",
    ]


def _register_gap_alerts(tally, master, period_end) -> list[str]:
    """
    A register that used to hold vouchers and now holds none.

    Nothing in this month's export can tell a genuine nil from a register Tally
    has stopped producing, so the answer has to come from what earlier months
    held, which the pending master carries.
    """
    history = master.get("registers_seen") or []
    if not history:
        return []
    cur = month_key(period_end)

    by_reg = {}
    for h in history:
        if h.get("month") == cur or not h.get("rows"):
            continue
        by_reg.setdefault(h.get("register"), []).append(h)

    out = []
    for key, spec in read_tally.REGISTERS.items():
        if not spec["critical"] or tally["registers"].get(key):
            continue
        seen = by_reg.get(key) or []
        if not seen:
            continue
        seen.sort(key=lambda h: month_sort_key(h.get("month")))
        last = seen[-1]
        months = "one earlier month" if len(seen) == 1 else f"{len(seen)} earlier months"
        out.append(
            f"The '{spec['label']}' register has no vouchers at all this month, but it "
            f"held them in {months}, most recently {last['month']} with {last['rows']} "
            f"vouchers and Rs {last['igst']:,.2f} IGST, Rs {last['cgst']:,.2f} CGST and "
            f"Rs {last['sgst']:,.2f} SGST. If Tally has stopped exporting it, "
            f"{spec['feeds']} will be nil in this return when it should not be.")
    return out


MONTH_NAMES = ["January", "February", "March", "April", "May", "June", "July",
               "August", "September", "October", "November", "December"]


def _period_check(tally, expect_period):
    """
    The month the accountant says they are filing, against the month the export
    actually covers. Tally is the authority; the choice is a cross-check, because
    exporting the wrong month is easy and leaves no other trace.
    """
    if not expect_period:
        return None
    year, month = expect_period
    chosen = f"{MONTH_NAMES[month - 1]} {year}"
    pe = tally.get("period_end")
    if not pe:
        return (f"You chose {chosen}, but no period could be read from the Tally export, "
                f"so the two cannot be checked against each other.\n\n"
                f"Re-export the GSTR-3B working from Tally so it carries its usual "
                f"period banner, or clear the month box to carry on without the check.")
    if (pe.year, pe.month) == (year, month):
        return None
    return (f"You chose {chosen}, but this Tally export covers the period ending "
            f"{pe:%d-%b-%Y}, which is {MONTH_NAMES[pe.month - 1]} {pe.year}.\n\n"
            f"Nothing has been written. Either export {chosen} from Tally, or change "
            f"the month in the window to match the export you have.")


def execute(file1, file2, file3, out_dir, cfg, log=_noop, expect_period=None,
            ledger_file=None, gl_file=None) -> dict:
    """Read, reconcile, write. Returns the result bundle plus the output paths."""
    problems = check_inputs(file1, file2, file3, out_dir)
    if problems:
        raise InputError("\n".join(problems))

    log("Reading the books export...", 5)
    tally = read_tally.read(file1)
    if not tally["sheets_found"].get("all_other_itc"):
        raise InputError(
            "The books workbook has no 'All Other ITC' sheet, so there is nothing to "
            "reconcile and Table 4(A)(5) would come out as nil.\n\n"
            "Please re-export the GSTR-3B working from Tally with all registers included.")
    mismatch = _period_check(tally, expect_period)
    if mismatch:
        raise InputError(mismatch)
    if tally.get("errors"):
        raise InputError(
            "This Tally export is not laid out the way the tool expects, and the "
            "registers below could not be read properly.\n\n"
            + "\n\n".join(tally["errors"])
            + "\n\nNothing has been written, because a register that reads as "
              "zero would understate the return without anything looking wrong.\n\n"
              "Either re-export from Tally with the usual column headings, or add the "
              "new headings to VOUCHER_ALIASES in read_tally.py so the tool knows them.")
    n_books = len(tally["registers"]["all_other_itc"])
    log(f"   {n_books} vouchers in All other ITC, period ending "
        f"{tally['period_end']:%d-%b-%Y}." if tally["period_end"]
        else f"   {n_books} vouchers in All other ITC.", 20)

    log("Reading GSTR-2B...", 25)
    gstr2b = read_2b.read(file2, tally.get("company_gstin", ""))
    read_counts = ", ".join(f"{k} {v}" for k, v in gstr2b["sections_read"].items() if v)
    log(f"   {read_counts or 'no rows found'}.", 40)

    log("Reading the pending master..." if file3 else
        "No pending master given - starting a fresh one.", 45)
    master = read_master.read(file3)
    if file3:
        op_b = sum(1 for r in master["books"] if not r["cleared"])
        op_2 = sum(1 for r in master["b2b"] if not r["cleared"])
        log(f"   {op_b} open book items and {op_2} open GSTR-2B items brought forward.", 55)

    alerts = _master_period_alert(master, tally.get("period_end"), file3)
    alerts += _register_gap_alerts(tally, master, tally.get("period_end"))
    for line in alerts:
        log(f"   ! {line}")

    tag = stamp(tally.get("period_end"))
    out_work = os.path.join(out_dir, f"{cfg.get('output_prefix','GSTR_Working')}_{tag}.xlsx")
    out_master = os.path.join(out_dir, f"{cfg.get('master_prefix','Pending_Master')}_{tag}.xlsx")

    decided, dec_warnings, dec_counts = decisions.read(
        file3, out_work if os.path.isfile(out_work) else None,
        month_label(tally.get("period_end")),
        carried_path=out_master if os.path.isfile(out_master) else None)
    if any(dec_counts.values()):
        log(f"   {len(decided)} confirmed or rejected probable "
            f"{'match' if len(decided) == 1 else 'matches'} carried in.", 58)

    # A ledger file, where one is given, is the better authority than a figure
    # typed in last month and not revisited.
    ledger_warnings = []
    if ledger_file:
        found, ledger_warnings = read_ledger.read(ledger_file)
        if found:
            cfg = dict(cfg)
            cfg["itc_ledger_opening"] = {h: found.get(h, 0.0)
                                         for h in ("igst", "cgst", "sgst", "cess")}
            log("   Opening credit ledger taken from the file supplied.", 59)

    log("Matching...", 60)
    R = reconcile(tally, gstr2b, master, cfg, decided)
    R["warnings"] = list(R.get("warnings", [])) + dec_warnings
    R["alerts"] = alerts

    # The GST ledgers out of Tally, and what the entries will do to them.
    gl, gl_warnings = read_gl.read(gl_file, cfg)
    R["gl"] = gl
    R["ledger_recon"] = ledgers.build(R, gl)
    R["warnings"] = list(R.get("warnings", [])) + gl_warnings
    if gl:
        log(f"   {len(gl)} of 9 GST ledgers read from the ledgers workbook.", 80)
    R["warnings"] = list(R.get("warnings", [])) + ledger_warnings
    R["entries"] = journal_entries(R)
    R["watchlist"] = build_watchlist(R, cfg)
    hot = [w for w in R["watchlist"] if w["status"] in ("Critical", "Serious")]
    if hot:
        log(f"   {len(hot)} suppliers need chasing (see the Supplier Watchlist).", 79)
    matched = sum(1 for x in R["books"] if x["_matched"])
    log(f"   {matched} of {len(R['books'])} vouchers matched.", 75)
    log(f"   {len(R['only_books'])} only in books, {len(R['only_2b'])} only in GSTR-2B.", 78)

    for w in R.get("warnings", []):
        log(f"   ! {w}")

    log("Writing the working paper...", 82)
    try:
        write_working.build(R, out_work)
    except PermissionError:
        raise InputError(f"Could not write:\n{out_work}\n\n"
                         f"The file is open in Excel. Please close it and run again.")
    log("Writing the updated pending master...", 93)
    try:
        write_master.build(R, out_master)
    except PermissionError:
        raise InputError(f"Could not write:\n{out_master}\n\n"
                         f"The file is open in Excel. Please close it and run again.")

    log("Done.", 100)
    R["out_work"] = out_work
    R["out_master"] = out_master
    return R

def execute_annual(books_file, twob_files, master_file, out_dir, cfg, log=_noop) -> dict:
    """
    The annual run, kept apart from the monthly one.

    It writes one workbook of its own and never touches the monthly outputs or
    the pending master, so a year can be looked at without disturbing the months
    that have already been filed.
    """
    problems = []
    if not books_file or not os.path.isfile(books_file):
        problems.append("The year books export could not be found.")
    for p in twob_files or []:
        if not os.path.isfile(p):
            problems.append(f"'{os.path.basename(p)}' could not be found.")
    if not twob_files:
        problems.append("No GSTR-2B downloads were chosen.")
    if master_file and not os.path.isfile(master_file):
        problems.append("The opening pending master could not be found.")
    if not out_dir:
        problems.append("No output folder chosen.")
    else:
        try:
            os.makedirs(out_dir, exist_ok=True)
        except OSError:
            problems.append(f"The output folder cannot be written to:{chr(10)}{out_dir}")
    if problems:
        raise InputError(chr(10).join(problems))

    log(f"Reading the year's books export...", 5)
    log(f"Reading {len(twob_files)} GSTR-2B download(s)...", 20)
    R = annual.run(books_file, twob_files, master_file, cfg)

    n_books = len(R["books"])
    matched = sum(1 for x in R["books"] if x["_matched"])
    log(f"   {n_books} vouchers for the year, period ending "
        f"{R['period_end']:%d-%b-%Y}." if R.get("period_end")
        else f"   {n_books} vouchers for the year.", 45)
    log(f"   {len(R['b2b'])} GSTR-2B rows across {len(R['twob_files'])} file(s).", 55)
    log("Matching the whole year in one pass...", 65)
    log(f"   {matched} of {n_books} vouchers matched somewhere in the year.", 80)
    log(f"   {len(R['only_books'])} never matched, {len(R['only_2b'])} in GSTR-2B "
        f"never booked.", 85)
    for w in R.get("warnings", []):
        log(f"   ! {w}")

    fy = (R.get("fy") or "").replace("-", "")
    name = f"Annual_Reconciliation_FY{fy}.xlsx" if fy else "Annual_Reconciliation.xlsx"
    out = os.path.join(out_dir, name)
    log("Writing the annual workbook...", 92)
    try:
        write_annual.build(R, out)
    except PermissionError:
        raise InputError(f"Could not write:{chr(10)}{out}{chr(10)}{chr(10)}"
                         f"The file is open in Excel. Please close it and run again.")
    log("Done.", 100)
    R["out_annual"] = out
    return R

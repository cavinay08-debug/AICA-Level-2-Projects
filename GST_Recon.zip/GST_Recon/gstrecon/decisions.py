"""Your Yes / No decisions on the probable matches.

A probable match is only a suggestion: same supplier, same tax, a nearby date,
but the document numbers do not agree. Somebody has to look at it. This module
remembers what you decided so the same suggestion is not put to you twice and a
rejected one never comes back.

Decisions are read from two places, in this order:

  1. the 'Probable Match Decisions' sheet carried in the pending master, which
     holds every decision made in earlier months
  2. the 'Confirmed' column of the working paper already sitting in the output
     folder for this period, which is where you actually type

The working paper wins, so re-running a month picks up what you have just marked.
"""

from __future__ import annotations

import openpyxl

from .util import clean_text, doc_key_exact, norm_gstin

SHEET_NAME = "Probable Match Decisions"
WORK_SHEET = "Probable Matches"

YES = "Yes"
NO = "No"

_YES = {"y", "yes", "true", "1"}
_NO = {"n", "no", "false", "0"}


def key(gstin, booked_doc, matched_doc) -> tuple:
    """
    Identify the pair, not the row. Built from the supplier and the two document
    numbers so it survives re-runs, re-sorting and next month's file.
    """
    return (norm_gstin(gstin), doc_key_exact(booked_doc), doc_key_exact(matched_doc))


def verdict(value) -> str:
    """Read what was typed in the Confirmed cell. Anything else means undecided."""
    s = clean_text(value).lower()
    if s in _YES:
        return YES
    if s in _NO:
        return NO
    return ""


def _header_row(ws, wanted: str, limit: int = 12):
    for r in range(1, min(limit, ws.max_row or 1) + 1):
        for c in range(1, (ws.max_column or 1) + 1):
            if clean_text(ws.cell(row=r, column=c).value).lower() == wanted:
                return r
    return None


def _columns(ws, hdr: int) -> dict:
    out = {}
    for c in range(1, (ws.max_column or 1) + 1):
        out[clean_text(ws.cell(row=hdr, column=c).value).lower()] = c
    return out


def _is_header_repeat(ws, row: int, cols: dict) -> bool:
    """The sheet repeats its headings above the second block. Those are not answers."""
    return all(clean_text(ws.cell(row=row, column=c).value).lower() == label
               for label, c in cols.items() if label)


def _from_master(path: str, store: dict, warnings: list) -> int:
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    try:
        if SHEET_NAME not in wb.sheetnames:
            return 0
        ws = wb[SHEET_NAME]
        hdr = _header_row(ws, "confirmed")
        if hdr is None:
            warnings.append(
                f"The pending master has a '{SHEET_NAME}' sheet but no 'Confirmed' column, "
                f"so earlier decisions on probable matches could not be read. They will be "
                f"put to you again.")
            return 0
        cols = _columns(ws, hdr)
        need = ("supplier gstin", "doc no. as booked", "matched against document")
        if any(n not in cols for n in need):
            warnings.append(
                f"The '{SHEET_NAME}' sheet in the pending master is missing one of its "
                f"identifying columns, so earlier decisions could not be read. They will be "
                f"put to you again.")
            return 0
        n = 0
        for r in range(hdr + 1, (ws.max_row or hdr) + 1):
            g = ws.cell(row=r, column=cols["supplier gstin"]).value
            booked = ws.cell(row=r, column=cols["doc no. as booked"]).value
            against = ws.cell(row=r, column=cols["matched against document"]).value
            mark = verdict(ws.cell(row=r, column=cols["confirmed"]).value)
            if not mark or not (clean_text(g) or clean_text(booked)):
                continue
            if _is_header_repeat(ws, r, cols):
                continue
            k = key(g, booked, against)
            store[k] = {
                "mark": mark,
                "decided_in": clean_text(ws.cell(row=r, column=cols["decided in"]).value)
                if "decided in" in cols else "",
                "gstin": norm_gstin(g),
                "booked": clean_text(booked),
                "against": clean_text(against),
                "source": "pending master",
            }
            n += 1
        return n
    finally:
        wb.close()


def _from_working(path: str, store: dict, warnings: list, period_label: str) -> int:
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    try:
        if WORK_SHEET not in wb.sheetnames:
            warnings.append(
                f"The working paper already in the output folder has no '{WORK_SHEET}' sheet, "
                f"so no Yes or No marks could be read from it.")
            return 0
        ws = wb[WORK_SHEET]
        hdr = _header_row(ws, "confirmed")
        if hdr is None:
            warnings.append(
                f"The working paper already in the output folder has a '{WORK_SHEET}' sheet "
                f"with no 'Confirmed' column. It was produced before this column existed, so "
                f"there is nothing to read back. Marks made on the new one will be picked up.")
            return 0
        cols = _columns(ws, hdr)
        need = ("gstin", "doc no. as booked", "matched against document")
        if any(n not in cols for n in need):
            warnings.append(
                f"The '{WORK_SHEET}' sheet in the existing working paper does not have the "
                f"columns this tool writes, so your marks could not be read back. Please check "
                f"nobody has deleted or reordered its columns.")
            return 0
        n = 0
        for r in range(hdr + 1, (ws.max_row or hdr) + 1):
            g = ws.cell(row=r, column=cols["gstin"]).value
            booked = ws.cell(row=r, column=cols["doc no. as booked"]).value
            against = ws.cell(row=r, column=cols["matched against document"]).value
            raw = ws.cell(row=r, column=cols["confirmed"]).value
            if not (clean_text(g) or clean_text(booked)):
                continue
            if _is_header_repeat(ws, r, cols):
                continue
            mark = verdict(raw)
            if not mark:
                # Anything other than Yes or No is a typo, not a decision. Say so
                # rather than quietly treating it as unconfirmed.
                if clean_text(raw):
                    warnings.append(
                        f"'{clean_text(raw)}' was typed against {clean_text(booked)} in the "
                        f"Confirmed column and is neither Yes nor No, so it has been ignored. "
                        f"That match is still waiting for a decision.")
                continue
            k = key(g, booked, against)
            store[k] = {
                "mark": mark,
                "decided_in": period_label,
                "gstin": norm_gstin(g),
                "booked": clean_text(booked),
                "against": clean_text(against),
                "source": "working paper",
            }
            n += 1
        return n
    finally:
        wb.close()


def read(master_path: str | None, work_path: str | None,
         period_label: str = "", carried_path: str | None = None) -> tuple[dict, list, dict]:
    """
    Collect every decision made so far, weakest source first so the freshest wins.

    Returns the store, any warnings to show, and a count of where the decisions
    came from. A missing file is normal on a first run and is silent; a file that
    exists but cannot be read is reported loudly, because treating a rejected
    match as undecided would quietly claim credit you have turned down.

    carried_path is the master this tool wrote for the same period on an earlier
    run. Reading it means a decision survives the working paper being deleted.
    Only the decisions sheet is taken from it, never the pending items.
    """
    store: dict = {}
    warnings: list = []
    counts = {"master": 0, "carried": 0, "working": 0}

    if master_path:
        try:
            counts["master"] = _from_master(master_path, store, warnings)
        except Exception as exc:
            warnings.append(
                f"Earlier decisions on probable matches could not be read from the pending "
                f"master ({exc}). Every probable match will be put to you again, and anything "
                f"you had rejected may be claimed. Please check the file before filing.")

    if carried_path:
        try:
            counts["carried"] = _from_master(carried_path, store, warnings)
        except Exception as exc:
            warnings.append(
                f"The pending master this tool wrote earlier for the same period could not be "
                f"read ({exc}), so decisions recorded in it were not picked up. If it is open "
                f"in Excel, close it and run again.")

    if work_path:
        try:
            counts["working"] = _from_working(work_path, store, warnings, period_label)
        except Exception as exc:
            warnings.append(
                f"The working paper already in the output folder could not be opened to read "
                f"your Yes and No marks ({exc}). If it is open in Excel, close it and run "
                f"again. Until then any match you have rejected will still be claimed.")

    return store, warnings, counts


def blocked(store: dict) -> set:
    """Pairs marked No. These are never suggested again."""
    return {k for k, v in store.items() if v.get("mark") == NO}


def rows_for_master(store: dict, live: list) -> list[dict]:
    """
    Every decision worth carrying forward: the ones made this month, plus the
    history, so a rejection made a year ago still holds.
    """
    out = []
    seen = set()
    for rec in live:
        k = rec["key"]
        seen.add(k)
        out.append(rec)
    for k, v in store.items():
        if k in seen:
            continue
        out.append({"key": k, "gstin": v.get("gstin", ""), "name": "",
                    "booked": v.get("booked", ""), "against": v.get("against", ""),
                    "igst": None, "cgst": None, "sgst": None,
                    "mark": v.get("mark", ""), "decided_in": v.get("decided_in", ""),
                    "month": ""})
    out.sort(key=lambda x: (x.get("gstin") or "", x.get("booked") or ""))
    return out

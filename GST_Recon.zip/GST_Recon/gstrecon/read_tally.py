"""Reader for File 1 - the GSTR-3B voucher registers exported from Tally."""

from __future__ import annotations

import openpyxl

from .sheetutil import (build_map, cell, find_header, grid, is_blank_row,
                        is_total_row, merged_header, trim_grid)
from .util import (clean_text, month_key, norm_gstin, num, parse_period_text,
                   to_date)

# Canonical field -> header spellings seen in Tally exports
VOUCHER_ALIASES = {
    "date":        ["date"],
    "particulars": ["particulars", "party name", "ledger"],
    "gstin":       ["party gstin uin", "gstin uin", "party gstin", "gstin"],
    "vch_type":    ["vch type", "voucher type"],
    "vch_no":      ["vch no", "voucher no"],
    "doc_no":      ["doc no", "document no", "supplier invoice no", "invoice no"],
    "doc_date":    ["doc date", "document date", "supplier invoice date"],
    "taxable":     ["taxable amount", "taxable value", "taxable"],
    "igst":        ["igst"],
    "cgst":        ["cgst"],
    "sgst":        ["sgst utgst", "sgst", "utgst"],
    "cess":        ["cess"],
    "tax":         ["tax amount", "total tax"],
}

# Logical register -> sheet-name spellings seen in the wild
SHEET_HINTS = {
    "all_other_itc":  ["all other itc", "all other input"],
    "ineligible_itc": ["ineligible itc", "ineligible"],
    "rcm_itc":        ["rcm itc book", "rcm itc", "rcm"],
    "imps":           ["imps books", "imps", "import of services"],
    "impg":           ["impg books", "impg", "import of goods"],
    "t31a":           ["table 3.1a", "3.1a"],
    "t31b":           ["table 3.1b", "3.1b"],
    "t31c":           ["table 3.1c", "3.1c"],
    "t31d":           ["table 3.1d", "3.1d"],
    "t31e":           ["table 3.1e", "3.1e"],
    "gstr3b":         ["gstr-3b", "gstr 3b"],
}

# What each register must yield before its figures can be trusted.
#
# A column that cannot be identified is not an absence, it is a zero on every
# row, and a zero is indistinguishable from a genuine nil once it reaches the
# return. So a register that feeds Table 4 stops the run rather than quietly
# understating a table. The Table 3.1 sheets only warn: they are supporting
# schedules, and 3.1(d) has a fallback of its own.
REGISTERS = {
    "all_other_itc":  {"label": "All Other ITC", "feeds": "Table 4(A)(5)",
                       "critical": True, "warn_if_missing": True,
                       "needs": ("date", "igst", "cgst", "sgst", "gstin"),
                       "needs_one_of": ("doc_no", "vch_no")},
    "ineligible_itc": {"label": "Ineligible ITC", "feeds": "Table 4(B)(1)",
                       "critical": True, "warn_if_missing": True,
                       "needs": ("date", "igst", "cgst", "sgst"),
                       "needs_one_of": ("vch_no", "doc_no")},
    "rcm_itc":        {"label": "RCM ITC Book", "feeds": "Table 4(A)(3)",
                       "critical": True, "warn_if_missing": True,
                       "needs": ("date", "igst", "cgst", "sgst"),
                       "needs_one_of": ()},
    "imps":           {"label": "IMPS Books", "feeds": "Table 4(A)(2)",
                       "critical": True, "warn_if_missing": True,
                       "needs": ("date", "igst", "cgst", "sgst"),
                       "needs_one_of": ()},
    "impg":           {"label": "IMPG Books", "feeds": "Table 4(A)(1) when taken from books",
                       "critical": True, "warn_if_missing": True,
                       "needs": ("date", "igst", "cgst", "sgst"),
                       "needs_one_of": ()},
    "t31a":           {"label": "Table 3.1a", "feeds": "outward supplies",
                       "critical": False, "warn_if_missing": True,
                       "needs": ("date", "igst", "cgst", "sgst"),
                       "needs_one_of": ()},
    "t31b":           {"label": "Table 3.1b", "feeds": "zero rated supplies",
                       "critical": False, "warn_if_missing": False,
                       "needs": ("date",), "needs_one_of": ()},
    "t31d":           {"label": "Table 3.1d", "feeds": "reverse charge liability",
                       "critical": False, "warn_if_missing": True,
                       "needs": ("date", "igst", "cgst", "sgst"),
                       "needs_one_of": ()},
}

FIELD_LABELS = {
    "date": "Date", "particulars": "Particulars", "gstin": "Party GSTIN/UIN",
    "vch_type": "Vch Type", "vch_no": "Vch No.", "doc_no": "Doc No.",
    "doc_date": "Doc Date", "taxable": "Taxable Amount", "igst": "IGST",
    "cgst": "CGST", "sgst": "SGST/UTGST", "cess": "Cess", "tax": "Tax Amount",
}


def _field_list(fields) -> str:
    return ", ".join(FIELD_LABELS.get(f, f) for f in fields)


def _pick_sheet(wb, hints):
    names = wb.sheetnames
    low = {n: n.lower().strip() for n in names}
    for hint in hints:
        for n in names:
            if low[n] == hint:
                return n
    for hint in hints:
        for n in names:
            if low[n].startswith(hint):
                return n
    for hint in hints:
        for n in names:
            if hint in low[n]:
                return n
    return None


def _read_register(ws, source: str) -> tuple[list[dict], dict, int | None]:
    """Return the vouchers, the column map that produced them, and the header row."""
    rows = trim_grid(grid(ws))
    hdr = find_header(rows, ["date"], search_rows=30)
    if hdr is None:
        return [], {}, None
    headers = merged_header(rows, hdr, depth=2)
    cmap = build_map(headers, VOUCHER_ALIASES)
    if "date" not in cmap:
        return [], cmap, hdr

    # If the row below the header is a continuation ("Amount", "UTGST", "Date"),
    # data starts one row further down.
    start = hdr + 1
    nxt = rows[start] if start < len(rows) else []
    nxt_txt = [clean_text(c).lower() for c in nxt]
    if nxt_txt and any(t in {"amount", "utgst", "date"} for t in nxt_txt if t) and \
       not to_date(cell(nxt, cmap.get("date"))):
        start += 1

    out = []
    for i in range(start, len(rows)):
        row = rows[i]
        if is_blank_row(row):
            continue
        if is_total_row(row):
            continue
        d = to_date(cell(row, cmap.get("date")))
        particulars = clean_text(cell(row, cmap.get("particulars")))
        if d is None and not particulars:
            continue
        rec = {
            "date": d,
            "particulars": particulars,
            "gstin": norm_gstin(cell(row, cmap.get("gstin"))),
            "vch_type": clean_text(cell(row, cmap.get("vch_type"))),
            "vch_no": clean_text(cell(row, cmap.get("vch_no"))),
            "doc_no": clean_text(cell(row, cmap.get("doc_no"))),
            "doc_date": to_date(cell(row, cmap.get("doc_date"))),
            "taxable": num(cell(row, cmap.get("taxable"))),
            "igst": num(cell(row, cmap.get("igst"))),
            "cgst": num(cell(row, cmap.get("cgst"))),
            "sgst": num(cell(row, cmap.get("sgst"))),
            "cess": num(cell(row, cmap.get("cess"))),
            "tax": num(cell(row, cmap.get("tax"))),
            "source": source,
            "src_row": i + 1,
        }
        if not rec["tax"]:
            rec["tax"] = rec["igst"] + rec["cgst"] + rec["sgst"] + rec["cess"]
        if not rec["doc_no"]:
            rec["doc_no"] = rec["vch_no"]
        if rec["doc_date"] is None:
            rec["doc_date"] = rec["date"]
        rec["month"] = month_key(rec["date"])
        out.append(rec)
    return out, cmap, hdr


def _read_3b_summary(ws) -> dict:
    """Return {row_label: {taxable, igst, cgst, sgst, cess, tax}} plus the raw grid."""
    rows = trim_grid(grid(ws))
    summary, order = {}, []
    for row in rows:
        label = clean_text(row[0] if row else "")
        if not label:
            continue
        vals = [num(c) for c in row[1:7]] + [0.0] * 6
        summary[label] = {
            "label": label,
            "taxable": vals[0], "igst": vals[1], "cgst": vals[2],
            "sgst": vals[3], "cess": vals[4], "tax": vals[5],
        }
        order.append(label)
    return {"rows": rows, "summary": summary, "order": order}


def read(path: str) -> dict:
    wb = openpyxl.load_workbook(path, data_only=True, read_only=False)
    out = {"path": path, "sheets_found": {}, "registers": {}}

    for key, hints in SHEET_HINTS.items():
        name = _pick_sheet(wb, hints)
        out["sheets_found"][key] = name

    # Period from the Tally banner on any register
    period_end = None
    company = gstin = ""
    for key in ("gstr3b", "all_other_itc", "t31a"):
        name = out["sheets_found"].get(key)
        if not name:
            continue
        rows = grid(wb[name], max_col=4)[:10]
        for row in rows:
            txt = clean_text(row[0] if row else "")
            if period_end is None and " to " in txt.lower():
                period_end = parse_period_text(txt)
            if not company and txt and "gst registration" not in txt.lower() and row and row[0] and len(txt) > 5:
                if not any(k in txt.lower() for k in ("gstr", "e-mail", "cin:", " to ")):
                    company = company or txt
            if txt.lower().startswith("gst registration"):
                gstin = norm_gstin(row[1] if len(row) > 1 else "")
        if period_end:
            break

    out["period_end"] = period_end
    out["company_name"] = company
    out["company_gstin"] = gstin

    # A register that is missing, or present but unreadable, must never pass
    # silently as zero -- it would understate a table in the return.
    warnings, errors = [], []
    out["register_info"] = {}

    for key in ("all_other_itc", "ineligible_itc", "rcm_itc", "imps", "impg",
                "t31a", "t31b", "t31c", "t31d", "t31e"):
        name = out["sheets_found"].get(key)
        rows, cmap, hdr = _read_register(wb[name], key) if name else ([], {}, None)
        out["registers"][key] = rows
        spec = REGISTERS.get(key)
        out["register_info"][key] = {
            "sheet": name, "rows": len(rows), "header_row": hdr,
            "label": spec["label"] if spec else key,
            "columns_found": sorted(cmap), "columns_missing": [],
        }
        if not spec:
            continue

        label, feeds = spec["label"], spec["feeds"]
        if not name:
            # A missing sheet is a supported situation for some registers, so it
            # is reported rather than fatal. Nothing reads as zero unnoticed.
            if spec["warn_if_missing"]:
                warnings.append(f"No '{label}' sheet was found in the Tally export, so "
                                f"{feeds} is taken as nil. Re-export the GSTR-3B working "
                                f"from Tally with all registers included if that is wrong.")
            continue

        if hdr is None:
            problem = (f"The sheet '{name}' was found but none of its rows look like "
                       f"column headings, so not one voucher could be read from it.")
        else:
            missing = [f for f in spec["needs"] if f not in cmap]
            if spec["needs_one_of"] and not any(f in cmap for f in spec["needs_one_of"]):
                missing.append(spec["needs_one_of"][0])
            out["register_info"][key]["columns_missing"] = missing
            problem = ""
            if missing:
                problem = (f"The sheet '{name}' was found, but these columns could not "
                           f"be identified in it: {_field_list(missing)}. Every one of "
                           f"them would be read as zero on every row.")

        if problem:
            consequence = (f"{feeds} would be reported as nil, or close to it, and "
                           f"nothing else in the working paper would look wrong.")
            if spec["critical"]:
                errors.append(f"{problem} {consequence}")
            else:
                warnings.append(f"{problem} {feeds.capitalize()} is affected.")
                # Better to fall back to the derived figure than to publish a zero.
                out["registers"][key] = []
        elif not rows and spec["warn_if_missing"]:
            warnings.append(f"The sheet '{name}' was found and read, but it holds no "
                            f"voucher rows at all, so {feeds} is nil this month.")

    out["warnings"] = warnings
    out["errors"] = errors

    name = out["sheets_found"].get("gstr3b")
    out["gstr3b"] = _read_3b_summary(wb[name]) if name else {"rows": [], "summary": {}, "order": []}
    out["gstr3b_sheet_name"] = name

    wb.close()
    return out

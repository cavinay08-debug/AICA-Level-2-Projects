"""Generic worksheet helpers: load a sheet as a grid, find its header row,
and map real-world header text onto canonical field names."""

from __future__ import annotations

import re

from .util import clean_text


def grid(ws, max_col: int | None = None) -> list[list]:
    """Whole worksheet as a list of lists (None-padded)."""
    out = []
    for row in ws.iter_rows(values_only=True):
        cells = list(row)
        if max_col:
            cells = cells[:max_col]
        out.append(cells)
    return out


def row_text(row) -> list[str]:
    return [clean_text(c) for c in row]


def trim_grid(rows: list[list]) -> list[list]:
    """Drop trailing all-blank rows and columns (Excel loves phantom ranges)."""
    while rows and all(c is None or clean_text(c) == "" for c in rows[-1]):
        rows.pop()
    if not rows:
        return rows
    width = 0
    for r in rows:
        for i, c in enumerate(r):
            if c is not None and clean_text(c) != "":
                width = max(width, i + 1)
    return [r[:width] + [None] * max(0, width - len(r)) for r in rows]


def find_header(rows: list[list], must_have, search_rows: int = 25):
    """
    Return the index of the first row containing every token in `must_have`
    (case-insensitive substring test against that row's cells).
    """
    wanted = [w.lower() for w in must_have]
    for i, row in enumerate(rows[:search_rows]):
        cells = [clean_text(c).lower() for c in row]
        joined = " | ".join(cells)
        if all(any(w == c for c in cells) or w in joined for w in wanted):
            return i
    return None


def merged_header(rows: list[list], hdr_idx: int, depth: int = 2) -> list[str]:
    """
    GST portal exports use two-row headers where the top row is a merged group
    label. Combine `depth` rows into one label per column, preferring the more
    specific (lower) row.
    """
    width = max(len(rows[hdr_idx + k]) for k in range(depth) if hdr_idx + k < len(rows))
    out = []
    for c in range(width):
        parts = []
        top = ""
        for k in range(depth):
            r = hdr_idx + k
            if r >= len(rows):
                continue
            val = clean_text(rows[r][c]) if c < len(rows[r]) else ""
            if k == 0:
                top = val
            if val:
                parts.append(val)
        if len(parts) >= 2 and top:
            out.append(f"{parts[0]} {parts[-1]}")
        else:
            out.append(parts[-1] if parts else "")
    # forward-fill merged group labels across blank top cells
    return out


def forward_fill(labels: list[str]) -> list[str]:
    out, last = [], ""
    for v in labels:
        if v:
            last = v
        out.append(v or last)
    return out


_PUNCT = re.compile(r"[^a-z0-9]+")


def _slug(text: str) -> str:
    return _PUNCT.sub(" ", clean_text(text).lower()).strip()


def build_map(headers: list[str], aliases: dict) -> dict:
    """
    headers : header text per column (index 0 = column A)
    aliases : {canonical_field: [accepted header spellings...]}

    Matching is: exact slug, then 'starts with', then 'contains'.
    First column to claim a field wins, so put distinctive spellings first.
    """
    slugs = [_slug(h) for h in headers]
    used, out = set(), {}

    for field, options in aliases.items():
        opts = [_slug(o) for o in options]
        found = None
        for stage in (0, 1, 2):
            for opt in opts:
                if not opt:
                    continue
                for idx, s in enumerate(slugs):
                    if idx in used or not s:
                        continue
                    hit = (
                        (stage == 0 and s == opt)
                        or (stage == 1 and s.startswith(opt))
                        or (stage == 2 and opt in s)
                    )
                    if hit:
                        found = idx
                        break
                if found is not None:
                    break
            if found is not None:
                break
        if found is not None:
            used.add(found)
            out[field] = found
    return out


def cell(row: list, idx) -> object:
    if idx is None or idx < 0 or idx >= len(row):
        return None
    return row[idx]


def is_total_row(row: list) -> bool:
    """Tally closes every register with a 'Total' line -- never treat it as data."""
    for c in row[:4]:
        t = clean_text(c).lower().strip(" :")
        if t in {"total", "grand total", "closing balance"}:
            return True
    return False


def is_blank_row(row: list) -> bool:
    return all(c is None or clean_text(c) == "" for c in row)

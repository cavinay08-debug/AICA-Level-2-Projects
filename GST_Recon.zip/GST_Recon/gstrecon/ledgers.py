"""
Reconciliation of the nine GST ledgers.

Closing balance per Tally, plus the effect of the entries this tool proposes,
gives the position those ledgers will stand at once the entries are passed. That
figure is then compared with what each ledger ought to be:

  the input ledgers      the credit still available, per the electronic
                         credit ledger after the set-off
  the deferred ledgers   the credit still unclaimed, which is the eligible open
                         book items carried in the pending master
  the payable ledgers    the tax still payable in cash after the set-off

Everything here is held debit positive. An input or deferred ledger runs debit,
a payable runs credit, so a payable shows as a negative figure internally and is
presented as Cr on the sheet.
"""

from __future__ import annotations

import re

from . import read_gl
from .engine import totals
from .util import clean_text, r2

HEADS = ("igst", "cgst", "sgst")


def _slug(v) -> str:
    return re.sub(r"[^a-z0-9]+", " ", clean_text(v).lower()).strip()


# The entry line names are written by engine.journal_entries, so they are matched
# exactly rather than guessed at. Anything not on this list is reported as a
# ledger the entries touch but the reconciliation does not cover, which is better
# than folding it silently into one of the nine.
ENTRY_LEDGERS = {
    "igst deferred a c": "deferred_igst",
    "cgst deferred a c": "deferred_cgst",
    "sgst deferred a c": "deferred_sgst",
    "igst input": "input_igst",
    "cgst input": "input_cgst",
    "sgst input": "input_sgst",
    "igst payable": "payable_igst",
    "cgst payable": "payable_cgst",
    "sgst payable": "payable_sgst",
    "igst payable rcm": "rcm_igst",
    "cgst payable rcm": "rcm_cgst",
    "sgst payable rcm": "rcm_sgst",
    "gst expense": "gst_expense",
}

# How each ledger is named on the Entries sheet, so the movement column can be
# a live SUMIF over it rather than a figure repeated from Python.
ENTRY_NAME = {
    "input_igst": "IGST-Input", "input_cgst": "CGST-Input",
    "input_sgst": "SGST-Input",
    "deferred_igst": "IGST Deferred A/c", "deferred_cgst": "CGST Deferred A/c",
    "deferred_sgst": "SGST Deferred A/c",
    "payable_igst": "IGST Payable", "payable_cgst": "CGST Payable",
    "payable_sgst": "SGST Payable",
}

EXTRA_LABELS = {
    "rcm_igst": "IGST Payable (RCM)",
    "rcm_cgst": "CGST Payable (RCM)",
    "rcm_sgst": "SGST Payable (RCM)",
    "gst_expense": "GST Expense",
}


def effect_of_entries(entries: list[dict]) -> dict:
    """Net movement per ledger, debit positive, across every entry."""
    out: dict = {}
    unknown: set = set()
    for e in entries or []:
        for line in e.get("lines", []):
            name, dr, cr = line[0], line[1], line[2]
            # "To IGST-Input" is the credit side of the same ledger; the leading
            # "To" is bookkeeping convention, not part of the name.
            slug = _slug(name)
            if slug.startswith("to "):
                slug = slug[3:]
            key = ENTRY_LEDGERS.get(slug)
            if key is None:
                unknown.add(clean_text(name))
                continue
            out[key] = r2(out.get(key, 0.0) + (dr or 0.0) - (cr or 0.0))
    out["_unknown"] = sorted(unknown)
    return out


def open_eligible_by_head(R: dict) -> dict:
    """
    The credit still unclaimed once this month is done.

    Items carried in the master that have not cleared, plus what is being
    deferred now. Blocked credit is excluded: it is claimed and reversed rather
    than deferred, so it never reaches the deferred ledger.
    """
    still = [r for r in R.get("open_books_master", []) if not r.get("_cleared_now")]
    eligible = [r for r in still
                if str(r.get("remark2", "")).lower() != "ineligible"]
    t_carried = totals(eligible)
    t_new = totals(R.get("deferred", []))
    return ({h: r2(t_carried[h] + t_new[h]) for h in HEADS},
            t_carried, t_new)


def timebarred_by_head(R: dict) -> dict:
    """
    Credit released this month but lapsed under section 16(4).

    It leaves the master, because it has been matched, but no entry takes it out
    of the deferred ledger, so it sits there until somebody writes it off. That
    makes it a reconciling item rather than a difference.
    """
    rows = [x for g in R.get("released_timebarred", {}).values() for x in g]
    t = totals(rows)
    return {h: r2(t[h]) for h in HEADS}, len(rows)


def build(R: dict, gl: dict) -> dict:
    """The reconciliation, one row per ledger, plus the supporting figures."""
    eff = effect_of_entries(R.get("entries", []))
    so = R.get("setoff") or {}
    expected_open, t_carried, t_new = open_eligible_by_head(R)
    barred, n_barred = timebarred_by_head(R)
    # The deferred ledger still carries anything time barred, since nothing has
    # been posted to take it out.
    expected_deferred = {h: r2(expected_open[h] + barred[h]) for h in HEADS}

    def expected_for(key, head):
        if key.startswith("input_"):
            return r2((so.get("closing") or {}).get(head, 0.0))
        if key.startswith("deferred_"):
            return expected_deferred[head]
        return r2(-(so.get("cash") or {}).get(head, 0.0))

    rows = []
    for key, group, head, label in read_gl.LEDGERS:
        entry = gl.get(key)
        closing = entry["balance"] if entry else None
        movement = r2(eff.get(key, 0.0))
        final = None if closing is None else r2(closing + movement)
        expected = expected_for(key, head)
        diff = None if final is None else r2(final - expected)
        rows.append({
            "key": key, "group": group, "head": head, "label": label,
            "closing": closing, "movement": movement, "final": final,
            "expected": expected, "diff": diff,
            "found": entry is not None,
            "where": entry.get("where", "") if entry else "",
        })

    extra = []
    for key, label in EXTRA_LABELS.items():
        movement = r2(eff.get(key, 0.0))
        if abs(movement) > 0.004:
            extra.append({"key": key, "label": label, "movement": movement})

    return {
        "rows": rows,
        "extra": extra,
        "unknown": eff.get("_unknown", []),
        "carried": {h: r2(t_carried[h]) for h in HEADS},
        "new_deferred": {h: r2(t_new[h]) for h in HEADS},
        "timebarred": barred,
        "n_timebarred": n_barred,
        "expected_deferred": expected_deferred,
        "any_found": any(r["found"] for r in rows),
        "worst": max((abs(r["diff"]) for r in rows if r["diff"] is not None),
                     default=None),
    }

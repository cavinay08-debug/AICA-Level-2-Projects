"""
Reader for the electronic credit ledger downloaded from the GST portal.

This is the one reader in the tool written without a real file to work from, so
it is deliberately suspicious. It looks for a heading row carrying the tax heads
and then for a closing balance beneath it. If it cannot find both it says so and
returns nothing, rather than handing back zeros that would silently be treated
as an empty credit ledger and overstate the cash payable.

If the portal's layout does not match, the balances can always be typed into the
window instead.
"""

from __future__ import annotations

import os
import re

import openpyxl

from .sheetutil import grid, trim_grid
from .util import clean_text, num, r2

HEAD_WORDS = {
    "igst": ("integrated tax", "integrated", "igst"),
    "cgst": ("central tax", "central", "cgst"),
    "sgst": ("state/ut tax", "state ut tax", "state tax", "sgst", "utgst"),
    "cess": ("cess",),
}

BALANCE_WORDS = ("closing balance", "balance available", "closing bal",
                 "total balance", "balance")

LEDGER_MARKERS = ("electronic credit ledger", "credit ledger", "itc ledger")


def _looks_like_ledger(wb) -> bool:
    """Is this the credit ledger at all? Anything else must be refused."""
    for name in wb.sheetnames:
        if any(m in name.lower() for m in LEDGER_MARKERS):
            return True
    for name in wb.sheetnames[:3]:
        ws = wb[name]
        for row in list(ws.iter_rows(values_only=True))[:12]:
            joined = " ".join(clean_text(c).lower() for c in row if c is not None)
            if any(m in joined for m in LEDGER_MARKERS):
                return True
    return False


def _slug(v) -> str:
    return re.sub(r"[^a-z0-9]+", " ", clean_text(v).lower()).strip()


def _find_heads(row) -> dict:
    """Column index per tax head, from a candidate heading row."""
    found = {}
    for idx, cell in enumerate(row):
        s = _slug(cell)
        if not s:
            continue
        for head, words in HEAD_WORDS.items():
            if head in found:
                continue
            if any(w in s for w in words):
                found[head] = idx
                break
    return found


def _from_sheet(ws) -> tuple[dict, str]:
    rows = trim_grid(grid(ws))
    if not rows:
        return {}, ""
    best, best_row = {}, None
    for i, row in enumerate(rows[:40]):
        heads = _find_heads(row)
        if len(heads) >= 2 and len(heads) > len(best):
            best, best_row = heads, i
    if best_row is None:
        return {}, ""

    # The row has to say it is a balance. Taking the last numeric row instead
    # would read any workbook at all as a credit ledger, which is worse than
    # reading none.
    pick = None
    for i in range(best_row + 1, len(rows)):
        # the portal puts the description a few columns in, after the date
        # and the reference number
        label = " ".join(_slug(c) for c in rows[i][:6])
        if any(w in label for w in BALANCE_WORDS):
            pick = i
    if pick is None:
        return {}, ""

    out = {}
    for head, col in best.items():
        out[head] = r2(num(rows[pick][col]) if col < len(rows[pick]) else 0.0)
    label = clean_text(rows[pick][0]) if rows[pick] else ""
    return out, f"'{ws.title}' row {pick + 1}" + (f" ({label})" if label else "")


def read(path: str | None) -> tuple[dict, list]:
    """
    Return the opening balances and any warnings.

    An empty dict means nothing usable was found, and the caller must not treat
    that as a nil ledger.
    """
    if not path:
        return {}, []
    try:
        wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    except Exception as exc:
        return {}, [f"The credit ledger workbook could not be opened ({exc}). "
                    f"The opening balances typed into the window have been used instead."]
    try:
        if not _looks_like_ledger(wb):
            return {}, [
                f"'{os.path.basename(path)}' does not look like an electronic credit "
                f"ledger, so nothing has been read from it. Nothing has been assumed "
                f"about the opening balance. Download the credit ledger from the portal, "
                f"or type the opening balances into the window."]
        for name in wb.sheetnames:
            found, where = _from_sheet(wb[name])
            if found:
                return found, [f"Opening credit ledger read from {where}. Please check it "
                               f"against the portal before filing."]
        return {}, [
            "The credit ledger workbook was opened but no closing balance could be found "
            "in it. Nothing has been assumed. Type the opening balances into the window "
            "instead, or check that this is the electronic credit ledger downloaded from "
            "the portal."]
    finally:
        wb.close()

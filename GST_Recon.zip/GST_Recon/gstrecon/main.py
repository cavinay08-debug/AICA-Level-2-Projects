"""Command-line entry point. Reads everything from the Input folder and writes
both outputs into the Output folder."""

from __future__ import annotations

import argparse
import datetime as dt
import os
import subprocess
import sys
import textwrap
import traceback

from . import config, detect, pipeline


def _root():
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _stamp(period_end) -> str:
    if not period_end:
        return dt.date.today().strftime("%b%y")
    return period_end.strftime("%b%y")


def _open(path):
    try:
        if sys.platform.startswith("win"):
            os.startfile(path)  # noqa: S606
        elif sys.platform == "darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])
    except Exception:
        pass


def _say(msg=""):
    print(msg, flush=True)


def run(argv=None) -> int:
    ap = argparse.ArgumentParser(
        prog="GST Reconciliation",
        description="Reconcile GSTR-2B with the GSTR-3B working from Tally.")
    ap.add_argument("--input", default=os.path.join(_root(), "Input"))
    ap.add_argument("--output", default=os.path.join(_root(), "Output"))
    ap.add_argument("--file1", help="Tally books workbook (overrides auto-detection)")
    ap.add_argument("--file2", help="GSTR-2B workbook")
    ap.add_argument("--file3", help="Pending master workbook")
    ap.add_argument("--settings", help="Path to settings.json")
    ap.add_argument("--month", help="Cross-check the period, as YYYY-MM (e.g. 2026-07). "
                                    "The run stops if the Tally export is for another month.")
    ap.add_argument("--ledger", help="Electronic credit ledger workbook, for the "
                                     "opening balance used in the set-off")
    ap.add_argument("--ledgers", help="Workbook holding the nine GST ledgers "
                                      "(inputs, deferred inputs and payables)")
    ap.add_argument("--annual", action="store_true",
                    help="Run the annual reconciliation instead of a month")
    ap.add_argument("--twob", nargs="+",
                    help="For --annual: every GSTR-2B download for the year")
    ap.add_argument("--no-open", action="store_true")
    ap.add_argument("--gui", action="store_true", help="Open the window (default)")
    ap.add_argument("--folder", action="store_true",
                    help="Run without the window, reading from the Input folder")
    args = ap.parse_args(argv)

    cfg = config.load(args.settings)

    explicit = any([args.file1, args.file2, args.file3])
    if args.gui or not (args.folder or explicit):
        from . import gui
        return gui.launch(cfg)
    os.makedirs(args.input, exist_ok=True)
    os.makedirs(args.output, exist_ok=True)

    _say("=" * 74)
    _say("  GSTR-2B  vs  BOOKS   RECONCILIATION")
    _say("=" * 74)
    _say()

    if args.annual:
        return _run_annual(args, cfg)

    found = detect.classify(args.input)
    f1 = args.file1 or found.get("tally")
    f2 = args.file2 or found.get("gstr2b")
    f3 = args.file3 or found.get("master")

    if not f1 or not f2:
        _say("  Could not find the files I need in:")
        _say(f"    {args.input}")
        _say()
        _say("  Please put these in that folder and run again:")
        _say("    1. the GSTR-3B working exported from Tally")
        _say("    2. the GSTR-2B workbook downloaded from the GST portal")
        _say("    3. last month's pending master (optional for the first run)")
        if found.get("candidates"):
            _say()
            _say("  What I did find:")
            for c in found["candidates"]:
                _say(f"    - {os.path.basename(c)}")
        return 2

    _say(f"  Books        : {os.path.basename(f1)}")
    _say(f"  GSTR-2B      : {os.path.basename(f2)}")
    _say(f"  Pending master: {os.path.basename(f3) if f3 else '(none - treating this as the first month)'}")
    _say()
    _say("  Reading and reconciling...")

    expect_period = None
    if args.month:
        try:
            y, m = str(args.month).split("-")[:2]
            expect_period = (int(y), int(m))
            if not (1 <= expect_period[1] <= 12):
                raise ValueError
        except ValueError:
            _say(f"  '{args.month}' is not a month I understand. Use YYYY-MM, "
                 f"for example 2026-07.")
            return 2

    try:
        R = pipeline.execute(f1, f2, f3, args.output, cfg,
                             log=lambda m, p=None: _say("  " + m),
                             expect_period=expect_period, ledger_file=args.ledger,
                             gl_file=args.ledgers)
    except pipeline.InputError as exc:
        _say()
        _say("  STOPPED.")
        for line in str(exc).splitlines():
            _say("  " + line)
        return 3

    out_work, out_master = R["out_work"], R["out_master"]
    t = R["t4a5"]
    b = R["t4b1"]
    c = R["t4c"]
    _say()
    _say(f"  Period                     : {R['month_label']}")
    _say(f"  Books - all other ITC      : {R['t_books']['igst']:>16,.2f} IGST"
         f" {R['t_books']['cgst']:>14,.2f} CGST")
    _say(f"  Matched with GSTR-2B       : {sum(1 for x in R['books'] if x['_matched'])} of {len(R['books'])} vouchers")
    _say(f"  Only in books, not in 2B   : {len(R['only_books'])}"
         f"   (of which {len(R['deferred'])} eligible - ITC deferred)")
    _say(f"  Only in 2B, not in books   : {len(R['only_2b'])}")
    _say(f"  Needing correction         : {len(R['require_correction'])}")
    probable = sum(1 for p in R.get("probable", []) if not p["mark"])
    if probable:
        held = str(R["cfg"].get("probable_match_unconfirmed", "claim")).lower() == "hold"
        _say(f"  Probable matches to confirm: {probable}   <-- please review before filing")
        _say("                               Credit on these is being held back until you "
             "confirm them."
             if held else
             "                               Credit on these is already claimed in 4(A)(5).")
        _say("                               Mark each Yes or No on the Probable Matches "
             "sheet, then run again.")
    _say()
    _say(f"  Table 4(A)(5)              : {t['igst']:>16,.2f} IGST {t['cgst']:>14,.2f} CGST {t['sgst']:>14,.2f} SGST")
    _say(f"  Table 4(B)(1)              : {b['igst']:>16,.2f} IGST {b['cgst']:>14,.2f} CGST {b['sgst']:>14,.2f} SGST")
    _say(f"  Table 4(C) net ITC         : {c['igst']:>16,.2f} IGST {c['cgst']:>14,.2f} CGST {c['sgst']:>14,.2f} SGST")
    if R.get("alerts"):
        _say()
        _say("  " + "=" * 70)
        _say("  CHECK THESE BEFORE YOU FILE")
        _say("  " + "=" * 70)
        for line in R["alerts"]:
            for part in textwrap.wrap(line, 68):
                _say("  " + part)
            _say()
        _say("  " + "=" * 70)

    _say()
    _say("  Written:")
    _say(f"    {os.path.basename(out_work)}   (GST working for the month)")
    _say(f"    {os.path.basename(out_master)}   (updated pending master)")
    _say()
    _say("  Start on the Summary sheet, then Require Correction, then Entries.")
    _say("=" * 74)

    mode = str(cfg.get("open_output", "file")).lower()
    if not args.no_open:
        if mode == "file":
            _open(out_work)
        elif mode == "folder":
            _open(args.output)
    return 0


def _run_annual(args, cfg) -> int:
    """The annual run. Separate inputs, separate workbook, nothing shared."""
    books = args.file1
    twob = list(args.twob or [])
    if not books or not twob:
        _say("  The annual run needs the year's books export and every GSTR-2B "
             "download:")
        _say()
        _say("    python -m gstrecon --annual --file1 books.xlsx "
             "--twob apr.xlsx may.xlsx ... --output out")
        return 2

    _say(f"  Books (year) : {os.path.basename(books)}")
    _say(f"  GSTR-2B      : {len(twob)} file(s)")
    if args.file3:
        _say(f"  Opening master: {os.path.basename(args.file3)}")
    _say()
    _say("  Reading and reconciling the year...")

    try:
        R = pipeline.execute_annual(books, twob, args.file3, args.output, cfg,
                                    log=lambda m, p=None: _say("  " + m))
    except pipeline.InputError as exc:
        _say()
        _say("  STOPPED.")
        for line in str(exc).splitlines():
            _say("  " + line)
        return 3

    n = len(R["books"])
    matched = sum(1 for x in R["books"] if x["_matched"])
    _say()
    _say(f"  Financial year             : {R.get('fy', '')}")
    _say(f"  Vouchers for the year      : {n}")
    _say(f"  Matched somewhere in year  : {matched} of {n}")
    _say(f"  Never matched              : {len(R['only_books'])}")
    _say(f"  In GSTR-2B, never booked   : {len(R['only_2b'])}")
    _say()
    for label, key in (("Table 4(A)(5)", "t4a5"), ("Table 4(B)(1)", "t4b1"),
                       ("Table 4(C) net ITC", "t4c")):
        t = R[key]
        _say(f"  {label:<27}: {t['igst']:>16,.2f} IGST {t['cgst']:>14,.2f} CGST "
             f"{t['sgst']:>14,.2f} SGST")
    c9 = R.get("gstr9c") or {}
    _say()
    _say(f"  GSTR-9C Table 12 difference: "
         f"{c9.get('difference', {}).get('igst', 0):>16,.2f} IGST "
         f"{c9.get('difference', {}).get('cgst', 0):>14,.2f} CGST"
         + ("   (agrees)" if c9.get("ties") else "   <-- to be explained"))
    _say()
    _say("  Written:")
    _say(f"    {os.path.basename(R['out_annual'])}")
    _say()
    _say("  Start on Annual Summary, then GSTR-9, then GSTR-9C ITC.")
    _say("=" * 74)
    if not args.no_open and str(cfg.get("open_output", "file")).lower() == "file":
        _open(R["out_annual"])
    return 0


def main() -> int:
    try:
        return run()
    except Exception:
        _say()
        _say("-" * 74)
        _say("  Something went wrong. The details below help pin it down:")
        _say("-" * 74)
        traceback.print_exc()
        _say("-" * 74)
        _say("  Common causes: a file still open in Excel, or a sheet renamed in the export.")
        return 1

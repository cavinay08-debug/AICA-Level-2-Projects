"""Settings loading. Every business rule that an accountant may want to change
lives in settings.json, not in the code."""

from __future__ import annotations

import json
import os

DEFAULTS = {
    "company_name": "",
    "company_gstin": "",

    "tolerance_rupees": 1.0,

    "enable_normalised_match": True,
    "enable_probable_match": True,
    "probable_match_max_day_gap": 45,
    "probable_match_min_tax": 1.0,
    "probable_match_unconfirmed": "claim",
    "match_when_2b_higher": True,
    "match_notes_on_value": True,

    "itc_ledger_opening": {"igst": 0.0, "cgst": 0.0, "sgst": 0.0},
    "igst_credit_order": "CGST_FIRST",

    "ledger_names": {
        "input_igst": ["IGST-Input", "IGST Input", "Input IGST", "IGST Input Tax Credit"],
        "input_cgst": ["CGST-Input", "CGST Input", "Input CGST", "CGST Input Tax Credit"],
        "input_sgst": ["SGST-Input", "SGST Input", "Input SGST", "SGST/UTGST Input", "UTGST-Input"],
        "deferred_igst": ["IGST Deferred A/c", "IGST Deferred", "Deferred IGST", "IGST Input Deferred"],
        "deferred_cgst": ["CGST Deferred A/c", "CGST Deferred", "Deferred CGST", "CGST Input Deferred"],
        "deferred_sgst": ["SGST Deferred A/c", "SGST Deferred", "Deferred SGST", "SGST/UTGST Deferred", "UTGST Deferred"],
        "payable_igst": ["IGST Payable", "Output IGST", "IGST Output", "IGST Payable A/c"],
        "payable_cgst": ["CGST Payable", "Output CGST", "CGST Output", "CGST Payable A/c"],
        "payable_sgst": ["SGST Payable", "Output SGST", "SGST Output", "SGST/UTGST Payable"],
    },

    "detect_wrong_gstin": True,
    "detect_wrong_tax_head": True,

    "rcm_ineligible_when_gstin_blank": True,
    "rcm_ineligible_keywords": [
        "TRAVEL", "TOUR", "CAB", "TAXI", "CAR RENTAL", "RENT A CAB", "MOTOR",
    ],

    "import_of_goods_source": "2B",

    "apply_section_16_4_time_bar": True,
    "output_prefix": "GSTR_Working",
    "master_prefix": "Pending_Master",
    "open_output": "file",
}

_SETTINGS_NAME = "settings.json"


def _root() -> str:
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def load(path: str | None = None) -> dict:
    cfg = dict(DEFAULTS)
    path = path or os.path.join(_root(), _SETTINGS_NAME)
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8-sig") as fh:
                raw = json.load(fh)
            user = {k: v for k, v in raw.items() if not k.startswith("_")}
            cfg.update(user)
        except (OSError, ValueError) as exc:
            print(f"  ! settings.json could not be read ({exc}); using defaults.")
    return cfg


def write_default(path: str | None = None) -> str:
    path = path or os.path.join(_root(), _SETTINGS_NAME)
    doc = {
        "_readme": [
            "Edit the values below to change how the reconciliation behaves.",
            "Anything starting with an underscore is a comment and is ignored.",
        ],
        "_tolerance_rupees": "Tax difference up to this amount is still treated as Matched.",
        "_import_of_goods_source": "'2B' takes Table 4A(1) from the portal (recommended), 'BOOKS' takes it from Tally.",
        "_rcm_ineligible_when_gstin_blank": "RCM lines with no supplier GSTIN (typically 5% cab / transport) are treated as blocked credit.",
        "_rcm_ineligible_keywords": "Ledger names containing any of these words are treated as blocked credit under section 17(5). Only used if File 1 has no Ineligible ITC sheet.",
        "_open_output": "'file' opens the working paper when the run finishes, 'folder' opens the Output folder, 'none' opens nothing.",
        "_apply_section_16_4_time_bar": "Credit released from a pending month is not claimed if 30 November of the following financial year has already passed. It is listed on Require Correction instead.",
        "_probable_match_unconfirmed": "What to do with a probable match nobody has marked Yes or No yet. 'claim' takes the credit and flags the row for review; 'hold' keeps the credit back until you mark it Yes, and defers it like any other invoice missing from GSTR-2B.",
    }
    doc.update(DEFAULTS)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(doc, fh, indent=2)
    return path

"""Writes Output 2 - the updated pending master."""

from __future__ import annotations

from collections import defaultdict

import openpyxl
from openpyxl.formatting.rule import FormulaRule
from openpyxl.utils import get_column_letter as CL

import re

from . import decisions, read_master, read_tally
from .engine import months_between, totals
from .util import clean_text, fy_of, month_sort_key, r2, to_date
from .xlstyle import (DATE, FILL_GREEN, FILL_GREY, FILL_LIGHT, F_BODY, F_BOLD,
                      F_SECTION, F_SUB, F_TITLE, MONEY, TOP_LINE, autofilter,
                      header_row, stamp_row, widths)

BOOKS_COLS = ["Month", "Date", "Particulars", "Party GSTIN/UIN", "Vch Type", "Vch No.",
              "Doc No.", "Updated Doc No.", "Doc Date", "Taxable amt", "IGST", "CGST",
              "SGST/UTGST", "Cess", "Tax amt", "Remark", "Remark 2", "Status",
              "Invoice month", "Matched in month", "Matched against",
              "Ageing (months)", "Notes"]

B2B_COLS = ["Tax Period", "Doc Type", "Purchase Type", "Doc No", "Doc Date", "Supplier GSTIN",
            "Supplier Name", "Place of Supply", "Reverse Charge", "Doc Value",
            "Item Taxable Value", "IGST", "CGST", "SGST", "Cess", "GSTR-1 Filing Period",
            "GSTR-1 Filing Date", "ITC Eligible", "ITC Ineligible Reason", "Remark",
            "Remark 2", "Status", "Invoice month", "Matched in month", "Matched against",
            "Ageing (months)", "Notes"]

BOOKS_MONEY = [10, 11, 12, 13, 14, 15]
BOOKS_DATE = [2, 9]
B2B_MONEY = [10, 11, 12, 13, 14, 15]
B2B_DATE = [1, 5, 16, 17]


def _books_row(rec, cur_label, period_end=None):
    cleared = bool(rec.get("cleared"))
    return [rec.get("month"), rec.get("date"), rec.get("particulars"), rec.get("gstin"),
            rec.get("vch_type"), rec.get("vch_no"), rec.get("doc_no"),
            rec.get("upd_doc_no") or rec.get("doc_no"), rec.get("doc_date"),
            rec.get("taxable"), rec.get("igst"), rec.get("cgst"), rec.get("sgst"),
            rec.get("cess"), rec.get("tax"),
            rec.get("remark") or rec.get("remark1") or "Not Matched",
            rec.get("remark2", ""),
            "Cleared" if cleared else "Open",
            rec.get("month"),
            _matched_in(rec, cur_label),
            rec.get("_matched_against") or rec.get("_matched_against_prev") or "",
            _ageing(rec, period_end, cleared),
            rec.get("note") or rec.get("_issue", "")]


def _b2b_row(rec, cur_label, period_end=None):
    cleared = bool(rec.get("cleared"))
    return [rec.get("month") or rec.get("gstr1_period"), rec.get("doc_type"),
            rec.get("purchase_type"), rec.get("doc_no"), rec.get("doc_date"),
            rec.get("gstin"), rec.get("supplier") or rec.get("particulars"),
            rec.get("pos"), rec.get("rev_charge"), rec.get("doc_value"), rec.get("taxable"),
            rec.get("igst"), rec.get("cgst"), rec.get("sgst"), rec.get("cess"),
            rec.get("gstr1_period"), rec.get("gstr1_filed"), rec.get("itc_eligible"),
            rec.get("itc_reason"),
            rec.get("remark") or rec.get("remark1") or "Not Matched",
            rec.get("remark2", ""),
            "Cleared" if cleared else "Open",
            rec.get("month"),
            _matched_in(rec, cur_label),
            rec.get("_matched_against") or rec.get("_matched_against_prev") or "",
            _ageing(rec, period_end, cleared),
            rec.get("note") or rec.get("_issue", "")]


def _matched_in(rec, cur_label):
    """The month in which this item finally cleared."""
    if rec.get("_cleared_now"):
        return cur_label
    prev = clean_text(rec.get("_matched_in_prev") or rec.get("_cleared_in"))
    if prev:
        return prev
    # Recover it from a remark written by an earlier run.
    m = re.search(r"matched with month\s+([A-Za-z]+)\s*(\d{2,4})",
                  str(rec.get("remark") or ""), re.IGNORECASE)
    if m:
        yr = m.group(2)[-2:]
        return f"{m.group(1)[:3]}-{yr}"
    m = re.search(r"matched[- ].*?([A-Za-z]{3})[-']?(\d{2})", str(rec.get("remark") or ""))
    return f"{m.group(1)}-{m.group(2)}" if m else ""


def _ageing(rec, period_end, cleared):
    """How many months this item has been waiting. Frozen once it clears."""
    d = rec.get("doc_date") or rec.get("date")
    if not d or not period_end:
        return None
    if cleared:
        end = to_date(rec.get("_cleared_on")) or period_end
    else:
        end = period_end
    return max(0, months_between(end, d))


def _target_sheet(master_rows, side, fallback_fy):
    """
    Keep appending to the sheet already holding the newest data, so the existing
    file structure survives. When the financial year turns over, start a fresh
    sheet instead of dropping the new year into the old one.
    """
    best, best_key, best_fy = None, (0, 0), ""
    for r in master_rows:
        if r.get("side") != side or not r.get("src_sheet"):
            continue
        k = month_sort_key(r.get("month"))
        if k > best_key:
            best_key, best = k, r["src_sheet"]
            best_fy = fy_of(r.get("date") or r.get("doc_date"))
    stem = "Only in books; Not in 2B" if side == "books" else "Only in 2B; Not in books"
    if best and (not best_fy or not fallback_fy or best_fy == fallback_fy):
        return best
    return f"{stem} {fallback_fy}"


DECISION_COLS = ["Supplier GSTIN", "Supplier name", "Invoice month", "Doc No. as booked",
                 "Matched against document", "IGST", "CGST", "SGST/UTGST",
                 "Confirmed", "Decided in"]


def _write_decisions(wb, R):
    """
    Carry your Yes and No answers on the probable matches into next month, so a
    match you have rejected is not put to you again and, more to the point, is
    not quietly claimed again.
    """
    live = [{"key": p["key"], "gstin": p["gstin"], "name": p["name"],
             "month": R["month"], "booked": p["booked"], "against": p["against"],
             "igst": p["igst"], "cgst": p["cgst"], "sgst": p["sgst"],
             "mark": p["mark"], "decided_in": p["decided_in"] or R["month_label"]}
            for p in R.get("probable", []) if p["mark"]]
    rows = decisions.rows_for_master(R.get("decisions") or {}, live)

    ws = wb.create_sheet(decisions.SHEET_NAME[:31])
    ws.cell(row=1, column=1, value="Probable matches you have already decided").font = F_TITLE
    ws.cell(row=2, column=1,
            value="Kept so the same suggestion is not put to you twice. A row marked No is "
                  "never suggested again and no credit is taken on it. Change a mark here "
                  "and the next run will follow it.").font = F_SUB
    header_row(ws, 4, DECISION_COLS)

    r = 5
    for rec in rows:
        stamp_row(ws, r, [rec.get("gstin", ""), rec.get("name", ""), rec.get("month", ""),
                          rec.get("booked", ""), rec.get("against", ""),
                          rec.get("igst"), rec.get("cgst"), rec.get("sgst"),
                          rec.get("mark", ""), rec.get("decided_in", "")],
                  fmts={6: MONEY, 7: MONEY, 8: MONEY})
        r += 1
    if not rows:
        ws.cell(row=5, column=1,
                value="Nil - no probable match has been confirmed or rejected yet.").font = F_SUB

    widths(ws, {"A": 20, "B": 34, "C": 14, "D": 24, "E": 26, "F": 14, "G": 14,
                "H": 15, "I": 13, "J": 14})
    autofilter(ws, 4, max(4, r - 1), len(DECISION_COLS))
    ws.freeze_panes = "A5"
    ws.sheet_view.showGridLines = False


def _write_registers_seen(wb, R):
    """
    Record what each Tally register held this month, and keep what earlier months
    held. Next month this is the only way to tell a register that is genuinely nil
    from one Tally has stopped exporting.
    """
    cur = R["month"]
    info = R["tally"].get("register_info", {})
    kept = [h for h in R["master"].get("registers_seen", []) if h.get("month") != cur]

    fresh = []
    for key, spec in read_tally.REGISTERS.items():
        i = info.get(key, {})
        rows = R["tally"]["registers"].get(key, [])
        t = totals(rows)
        fresh.append({"month": cur, "register": key, "sheet": i.get("sheet") or "",
                      "rows": len(rows), "igst": t["igst"], "cgst": t["cgst"],
                      "sgst": t["sgst"], "cess": t["cess"]})

    allrows = kept + fresh
    allrows.sort(key=lambda h: (month_sort_key(h.get("month")), h.get("register", "")))

    ws = wb.create_sheet(read_master.REGISTER_SHEET[:31])
    ws.cell(row=1, column=1, value="Tally registers seen each month").font = F_TITLE
    ws.cell(row=2, column=1,
            value="Kept so that a register which stops being exported can be spotted. "
                  "A register that used to hold vouchers and suddenly holds none is "
                  "reported on the next run.").font = F_SUB
    header_row(ws, 4, read_master.REGISTER_COLS)
    r = 5
    for h in allrows:
        stamp_row(ws, r, [h.get("month", ""), h.get("register", ""), h.get("sheet", ""),
                          h.get("rows", 0), h.get("igst"), h.get("cgst"),
                          h.get("sgst"), h.get("cess")],
                  fmts={5: MONEY, 6: MONEY, 7: MONEY, 8: MONEY})
        r += 1
    widths(ws, {"A": 12, "B": 18, "C": 22, "D": 12, "E": 15, "F": 15, "G": 16, "H": 12})
    autofilter(ws, 4, max(4, r - 1), len(read_master.REGISTER_COLS))
    ws.freeze_panes = "A5"
    ws.sheet_view.showGridLines = False


def build(R: dict, path: str) -> str:
    cur_label = R["month_label"]
    cur_fy = fy_of(R["period_end"])
    master = R["master"]

    # ---- assemble rows per sheet ----------------------------------------
    pages = defaultdict(lambda: {"side": "", "rows": []})

    for side in ("books", "b2b"):
        for rec in master[side]:
            name = rec.get("src_sheet") or _target_sheet(master[side], side, cur_fy)
            pages[name]["side"] = side
            pages[name]["rows"].append(rec)

    new_books_sheet = _target_sheet(master["books"], "books", cur_fy)
    new_b2b_sheet = _target_sheet(master["b2b"], "b2b", cur_fy)

    for rec in R["only_books"]:
        row = dict(rec)
        row["month"] = R["month"]
        row["remark"] = "Not Matched"
        row["cleared"] = False
        row["side"] = "books"
        row["note"] = rec.get("_issue", "")
        pages[new_books_sheet]["side"] = "books"
        pages[new_books_sheet]["rows"].append(row)

    for rec in R["only_2b"]:
        row = dict(rec)
        row["month"] = R["month"]
        row["remark"] = "Not Matched"
        row["cleared"] = False
        row["side"] = "b2b"
        row["note"] = rec.get("_issue", "")
        row["supplier"] = rec.get("supplier", "")
        pages[new_b2b_sheet]["side"] = "b2b"
        pages[new_b2b_sheet]["rows"].append(row)

    # ---- write -----------------------------------------------------------
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    summary = wb.create_sheet("Summary")

    order = sorted(pages.keys(), key=lambda n: (pages[n]["side"] != "books", n))
    stats = []

    for name in order:
        side = pages[name]["side"]
        rows = pages[name]["rows"]
        cols = BOOKS_COLS if side == "books" else B2B_COLS
        money_cols = BOOKS_MONEY if side == "books" else B2B_MONEY
        date_cols = BOOKS_DATE if side == "books" else B2B_DATE
        row_fn = _books_row if side == "books" else _b2b_row

        ws = wb.create_sheet(name[:31])
        ws.cell(row=1, column=1, value=name).font = F_TITLE
        ws.cell(row=2, column=1,
                value=f"Updated after {cur_label}. 'Open' rows are still pending; "
                      f"'Cleared' rows have been matched and are kept for history."
                ).font = F_SUB
        header_row(ws, 4, cols)

        rows.sort(key=lambda r: (month_sort_key(r.get("month")), str(r.get("particulars") or "")))
        fmts = {i: MONEY for i in money_cols}
        for i in date_cols:
            fmts[i] = DATE

        r = 5
        for rec in rows:
            stamp_row(ws, r, row_fn(rec, cur_label, R["period_end"]), fmts=fmts)
            r += 1
        last = r - 1

        ws.cell(row=r, column=1, value="Total - all rows").font = F_BOLD
        for c in money_cols:
            cell = ws.cell(row=r, column=c, value=f"=SUBTOTAL(9,{CL(c)}5:{CL(c)}{last})")
            cell.font = F_BOLD
            cell.number_format = MONEY
            cell.fill = FILL_LIGHT
            cell.border = TOP_LINE
        st_col = cols.index("Status") + 1
        r += 1
        ws.cell(row=r, column=1, value="Total - open only").font = F_BOLD
        for c in money_cols:
            cell = ws.cell(row=r, column=c,
                           value=f'=SUMIF({CL(st_col)}5:{CL(st_col)}{last},"Open",'
                                 f'{CL(c)}5:{CL(c)}{last})')
            cell.font = F_BOLD
            cell.number_format = MONEY
            cell.fill = FILL_GREEN

        for i in range(1, len(cols) + 1):
            ws.column_dimensions[CL(i)].width = 32 if i in (3, 7) else 15
        ws.column_dimensions["A"].width = 12
        autofilter(ws, 4, last, len(cols))
        ws.freeze_panes = "A5"
        ws.sheet_view.showGridLines = False
        if last >= 5:
            rng = f"A5:{CL(len(cols))}{last}"
            ws.conditional_formatting.add(rng, FormulaRule(
                formula=[f'${CL(st_col)}5="Cleared"'], fill=FILL_GREY, stopIfTrue=False))

        op = [x for x in rows if not x.get("cleared")]
        stats.append((name, side, len(rows), len(op),
                      r2(sum(x.get("igst", 0) for x in op)),
                      r2(sum(x.get("cgst", 0) for x in op)),
                      r2(sum(x.get("sgst", 0) for x in op))))

    # ---- summary ---------------------------------------------------------
    summary.cell(row=1, column=1, value="Pending Master - position after "
                                        f"{cur_label}").font = F_TITLE
    summary.cell(row=2, column=1,
                 value=f"{R['company_name']} | GSTIN {R['company_gstin']}").font = F_SUB
    header_row(summary, 4, ["Sheet", "Side", "Total rows", "Open rows", "Open IGST",
                            "Open CGST", "Open SGST/UTGST"])
    r = 5
    for name, side, tot, op, i, c, s in stats:
        stamp_row(summary, r, [name, "Books" if side == "books" else "GSTR-2B", tot, op, i, c, s],
                  fmts={5: MONEY, 6: MONEY, 7: MONEY})
        r += 1
    summary.cell(row=r, column=1, value="Total").font = F_BOLD
    for c in (3, 4, 5, 6, 7):
        cell = summary.cell(row=r, column=c, value=f"=SUM({CL(c)}5:{CL(c)}{r-1})")
        cell.font = F_BOLD
        cell.number_format = MONEY if c >= 5 else "#,##0"
        cell.fill = FILL_LIGHT

    r += 2
    summary.cell(row=r, column=1, value="Movement this month").font = F_SECTION
    r += 1
    header_row(summary, r, ["Particulars", "Count", "IGST", "CGST", "SGST/UTGST", "", ""])
    r += 1
    moves = [
        ("Brought forward - open book items", R["open_books_master"]),
        ("Brought forward - open GSTR-2B items", R["open_b2b_master"]),
        ("Cleared this month - book items now in GSTR-2B",
         [x for g in R["released_eligible"].values() for x in g]
         + [x for g in R["released_ineligible"].values() for x in g]),
        ("Cleared this month - GSTR-2B items now booked", R["closed_2b_master"]),
        (f"Added this month - in books, not in GSTR-2B", R["only_books"]),
        (f"Added this month - in GSTR-2B, not in books", R["only_2b"]),
    ]
    for label, rows_ in moves:
        stamp_row(summary, r, [label, len(rows_),
                               r2(sum(x.get("igst", 0) for x in rows_)),
                               r2(sum(x.get("cgst", 0) for x in rows_)),
                               r2(sum(x.get("sgst", 0) for x in rows_))],
                  fmts={3: MONEY, 4: MONEY, 5: MONEY})
        r += 1

    widths(summary, {"A": 52, "B": 14, "C": 14, "D": 14, "E": 17, "F": 16, "G": 18})
    summary.freeze_panes = "A5"
    summary.sheet_view.showGridLines = False

    _write_decisions(wb, R)
    _write_registers_seen(wb, R)

    wb.active = 0
    wb.save(path)
    return path

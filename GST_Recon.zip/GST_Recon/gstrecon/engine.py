"""Reconciliation orchestration: everything between reading the inputs and
writing the workbooks."""

from __future__ import annotations

from collections import defaultdict

from . import decisions as D
from . import match as M
from . import read_2b, read_master, read_tally, setoff
from .util import (clean_text, doc_key_exact, doc_key_norm, month_key,
                   month_label, month_sort_key, norm_gstin, r2)

HEADS = ("igst", "cgst", "sgst", "cess")


def _sum(rows, *fields):
    return {f: r2(sum(r.get(f, 0.0) or 0.0 for r in rows)) for f in (fields or HEADS)}


def totals(rows) -> dict:
    out = {f: r2(sum(r.get(f, 0.0) or 0.0 for r in rows)) for f in HEADS}
    out["taxable"] = r2(sum(r.get("taxable", 0.0) or 0.0 for r in rows))
    out["tax"] = r2(out["igst"] + out["cgst"] + out["sgst"] + out["cess"])
    out["n"] = len(rows)
    return out


# --------------------------------------------------------------------------
# Step 1 - flag blocked credit
# --------------------------------------------------------------------------

def _inelig_index(ineligible: list[dict]) -> dict:
    idx = defaultdict(list)
    for r in ineligible:
        idx[("g", norm_gstin(r["gstin"]), doc_key_exact(r["vch_no"]))].append(r)
        idx[("p", clean_text(r["particulars"]).upper(), doc_key_exact(r["vch_no"]))].append(r)
    return idx


def flag_ineligible(rows: list[dict], idx: dict, claimed: set | None = None) -> int:
    """
    Tally keeps blocked credit in its own register. That register is the
    authority for Table 4(B)(1) -- it covers ordinary purchases and reverse
    charge alike, so no guessing is required here.
    """
    hit = 0
    for r in rows:
        keys = [("g", norm_gstin(r["gstin"]), doc_key_exact(r["vch_no"])),
                ("p", clean_text(r["particulars"]).upper(), doc_key_exact(r["vch_no"]))]
        r["ineligible"] = False
        r["remark2"] = ""
        for k in keys:
            for src in idx.get(k, []):
                if claimed is not None and id(src) in claimed:
                    continue
                r["ineligible"] = True
                r["remark2"] = "Ineligible"
                if claimed is not None:
                    claimed.add(id(src))
                hit += 1
                break
            if r["ineligible"]:
                break
    return hit


def classify_rcm_fallback(rcm_books: list[dict], cfg: dict) -> None:
    """Only used when Tally's Ineligible ITC register is missing or empty."""
    kws = [k.upper() for k in cfg.get("rcm_ineligible_keywords", [])]
    blank_rule = bool(cfg.get("rcm_ineligible_when_gstin_blank", True))
    for r in rcm_books:
        name = clean_text(r.get("particulars")).upper()
        reasons = []
        if blank_rule and not norm_gstin(r.get("gstin")):
            reasons.append("supplier not registered")
        for k in kws:
            if k and k in name:
                reasons.append(f"ledger name contains '{k.title()}'")
                break
        r["ineligible"] = bool(reasons)
        r["remark2"] = "Ineligible" if reasons else ""


# --------------------------------------------------------------------------
# Step 2 - the reconciliation itself
# --------------------------------------------------------------------------

def settle_probable(books: list[dict], decided: dict, cfg: dict) -> list[dict]:
    """
    A probable match is a suggestion until somebody has looked at it.

    Whether an unanswered suggestion is claimed or held back is a filing policy,
    so it lives in settings.json. When it is not adopted the row is put back
    exactly as it was booked, which leaves the SUMIFS in the workbook to reach
    Not Matched on its own rather than asking Excel to follow a second rule.
    """
    claim_unconfirmed = str(cfg.get("probable_match_unconfirmed", "claim")).lower() != "hold"

    # A rejected pair is never proposed again, so the voucher would otherwise turn
    # up on the exception sheets with nothing to say why.
    turned_down = defaultdict(list)
    for k, v in decided.items():
        if v.get("mark") == D.NO:
            turned_down[(k[0], k[1])].append(v.get("against") or "a GSTR-2B document")
    for row in books:
        against = turned_down.get((norm_gstin(row.get("gstin")),
                                   doc_key_exact(row.get("doc_no"))))
        if against:
            row["_confirm_note"] = (
                f"A probable match to {', '.join(against)} was rejected by hand, so it is "
                f"no longer suggested.")

    out = []
    for row in books:
        if row.get("_match_type") != M.PROBABLE:
            continue
        other = row.get("_match_row") or {}
        k = D.key(row.get("gstin"), row.get("doc_no"), other.get("doc_no"))
        mark = decided.get(k, {}).get("mark", "")
        adopt = mark == D.YES or (not mark and claim_unconfirmed)

        if adopt:
            row["_confirm_note"] = (
                "Probable match confirmed by hand."
                if mark == D.YES else
                "Probable match, not yet confirmed. Credit claimed on the strength of the "
                "supplier, the tax and the invoice date only. Mark Yes or No against it on "
                "the Probable Matches sheet.")
        else:
            row["_confirm_note"] = (
                f"Probable match to {clean_text(other.get('doc_no')) or 'a GSTR-2B document'} "
                f"not accepted, so this voucher is treated as not matched.")
            _unbind(row, other)

        out.append({
            "key": k, "row": row, "other": other, "mark": mark, "adopted": adopt,
            "gstin": norm_gstin(row.get("gstin")),
            "name": clean_text(row.get("particulars")),
            "booked": clean_text(row.get("doc_no")),
            "against": clean_text(other.get("doc_no")),
            "igst": r2(row.get("igst")), "cgst": r2(row.get("cgst")),
            "sgst": r2(row.get("sgst")),
            "decided_in": decided.get(k, {}).get("decided_in", ""),
        })
    return out


def _note_shortfall(row) -> None:
    """Say by how much, and on which head, so the reader can decide whether the
    invoice was booked short or the supplier has reported too much."""
    d = row.get("_short_detail") or {}
    parts = [f"{h.upper() if h != 'sgst' else 'SGST'} {v:,.2f}"
             for h, v in d.items() if abs(v) > 0.004]
    total = r2(sum(v for v in d.values()))
    row["_issue_kind"] = "GSTR-2B higher"
    row["_issue"] = (f"GSTR-2B carries Rs {total:,.2f} more tax than the books "
                     f"({', '.join(parts)}). Credit has been claimed only to the "
                     f"extent booked. Check whether the invoice was booked short.")


def _unbind(row, other) -> None:
    """Put a rejected suggestion back the way the voucher was booked."""
    for f in ("_match_type", "_match_idx", "_match_tag", "_match_row", "_resolved_doc"):
        row.pop(f, None)
    row["_match_type"] = ""
    row["upd_doc_no"] = row.get("doc_no")
    holders = other.get("_matched_by")
    if holders and row in holders:
        holders.remove(row)


def reconcile(tally: dict, gstr2b: dict, master: dict, cfg: dict,
              decided: dict | None = None) -> dict:
    decided = decided or {}
    period_end = tally.get("period_end")
    cur_month = month_key(period_end)
    cur_label = month_label(period_end)

    books = [dict(r) for r in tally["registers"]["all_other_itc"]]
    for r in books:
        r["upd_doc_no"] = r["doc_no"]
        r["_match_type"] = ""
        r["_issue"] = ""

    inelig_reg = tally["registers"]["ineligible_itc"]
    idx = _inelig_index(inelig_reg)
    claimed: set = set()
    flag_ineligible(books, idx, claimed)

    buckets = read_2b.split_buckets(gstr2b["records"])
    b2b = [dict(r) for r in buckets["itc"]]
    for r in b2b:
        r["_match_type"] = ""
        r["_issue"] = ""
        r["remark2"] = "" if r.get("itc_eligible") != "No" else "Ineligible"

    rcm_books = [dict(r) for r in tally["registers"]["rcm_itc"]]
    if inelig_reg:
        flag_ineligible(rcm_books, idx, claimed)
        inelig_basis = "Tally 'Ineligible ITC' register"
    else:
        classify_rcm_fallback(rcm_books, cfg)
        inelig_basis = "settings.json rules (no Ineligible ITC register in File 1)"
    inelig_unallocated = [r for r in inelig_reg if id(r) not in claimed]

    # ---- open items carried in from earlier months -----------------------
    open_books_master = [r for r in master["books"] if not r["cleared"]]
    open_b2b_master = [r for r in master["b2b"] if not r["cleared"]]
    for r in open_books_master + open_b2b_master:
        r["_match_type"] = ""
        r["_issue"] = ""

    # ---- Pass A: this month's books against this month's 2B --------------
    consumed: set = set()
    stats_primary = M.match_rows(books, b2b, cfg,
                                 left_doc_field="upd_doc_no",
                                 right_doc_field="doc_no",
                                 consumed=consumed, tag="current",
                                 blocked_pairs=D.blocked(decided),
                                 allow_note_value=True)
    probable = settle_probable(books, decided, cfg)
    for r in books:
        if r.get("_resolved_doc"):
            r["upd_doc_no"] = r["_resolved_doc"]

    # ---- Pass B: leftover books against 2B carried from earlier months ---
    # One prior document can release exactly one entry, and the tax must agree.
    stats_books_vs_old2b = M.match_rows(
        books, open_b2b_master, cfg,
        left_doc_field="upd_doc_no", right_doc_field="doc_no",
        allow_probable=False, tag="old2b",
        consume_exact=True, require_amount=True, allow_note_value=True)
    cur_long = period_end.strftime("%B %Y") if period_end else cur_label
    for r in books:
        if r.get("_match_tag") == "old2b":
            other = r["_match_row"]
            src = _lbl(other["month"]) if other.get("month") else \
                month_label(other.get("doc_date") or other.get("date"))
            r["cross_remark"] = f"Matched with GSTR-2B of {src}"
            other["cleared"] = True
            other["remark"] = f"Matched with month {cur_long}"
            other["_matched_against"] = f"Books of {cur_label}"
            other["_cleared_now"] = True

    # ---- Pass C: leftover 2B against books carried from earlier months ---
    stats_2b_vs_oldbooks = M.match_rows(
        b2b, open_books_master, cfg,
        left_doc_field="doc_no", right_doc_field="upd_doc_no",
        allow_probable=False, tag="oldbooks",
        consume_exact=True, require_amount=True, allow_note_value=True)
    for r in b2b:
        if r.get("_match_tag") == "oldbooks":
            other = r["_match_row"]
            r["cross_remark"] = f"Matched with books of {_lbl(other.get('month'))}"
            other["cleared"] = True
            other["remark"] = f"Matched with month {cur_long}"
            other["_matched_against"] = f"GSTR-2B of {cur_label}"
            other["_cleared_now"] = True
            other["_cleared_month"] = other.get("month")

    # ---- final verdict, using the same group logic as the workbook -------
    # The books are the claim, so the one-sided test runs the same way round on
    # both sheets: the figure taken must not exceed what GSTR-2B carries.
    M.apply_group_verdict(books, "upd_doc_no", b2b, "doc_no", cfg, claim_side="left")
    M.apply_group_verdict(b2b, "doc_no", books, "upd_doc_no", cfg, claim_side="right")

    for pool, is_books in ((books, True), (b2b, False)):
        for r in pool:
            if r.get("cross_remark"):
                r["_matched"] = True
                r["remark1"] = r["cross_remark"]
            elif r.get("_short"):
                r["remark1"] = M.SHORT
                if is_books:
                    _note_shortfall(r)
            else:
                r["remark1"] = "Matched" if r["_matched"] else "Not Matched"

    # ---- explain what is left -------------------------------------------
    unmatched_books = [r for r in books if not r["_matched"]]
    unmatched_b2b = [r for r in b2b if not r["_matched"]]
    M.diagnose(unmatched_books, b2b, cfg, "upd_doc_no", "doc_no", "books", "2B")
    M.diagnose(unmatched_b2b, books, cfg, "doc_no", "upd_doc_no", "2B", "books")

    # ---- buckets for the working papers ---------------------------------
    only_books = unmatched_books
    only_2b = unmatched_b2b

    deferred = [r for r in only_books if not r.get("ineligible")]
    ineligible_books = [r for r in books if r.get("ineligible")]

    require_correction = [r for r in (only_books + only_2b) if r.get("_issue")]
    for r in require_correction:
        r["_side"] = "Books" if r in only_books else "GSTR-2B"

    # Matched, but on the strength of the books being the lower figure. The
    # credit is right; whether the purchase was booked short is not something
    # this tool can decide, so the row is put in front of somebody who can.
    for r in books:
        if r.get("_short") and not r.get("cross_remark"):
            r["_side"] = "Books"
            require_correction.append(r)
    # ---- deferred ITC now released, grouped by the month it came from ----
    released = [r for r in open_books_master if r.get("_cleared_now")]
    rel_groups = defaultdict(list)
    for r in released:
        rel_groups[r.get("month") or "Earlier"].append(r)
    time_bar = bool(cfg.get("apply_section_16_4_time_bar", True))
    rel_eligible, rel_ineligible, rel_timebarred = {}, {}, {}
    for m, v in rel_groups.items():
        elig, inelig, barred = [], [], []
        for x in v:
            if str(x.get("remark2", "")).lower() == "ineligible":
                inelig.append(x)
            elif time_bar and _time_barred(x, period_end):
                x["_issue"] = ("Credit appears in GSTR-2B only now; the section 16(4) "
                               f"deadline of {_s164_deadline(x).strftime('%d-%b-%Y')} has passed")
                x["_issue_kind"] = "Time barred"
                barred.append(x)
            else:
                elig.append(x)
        if elig:
            rel_eligible[m] = elig
        if inelig:
            rel_ineligible[m] = inelig
        if barred:
            rel_timebarred[m] = barred

    for v in rel_timebarred.values():
        for r in v:
            r["_side"] = "Books (earlier month)"
            require_correction.append(r)

    closed_2b_master = [r for r in open_b2b_master if r.get("_cleared_now")]

    # ---- Table 4 build-up -------------------------------------------------
    t_books = totals(books)
    t_def = totals(deferred)
    t_rel = {h: r2(sum(totals(v)[h] for v in rel_eligible.values())) for h in HEADS}
    t_inel_books = totals(ineligible_books)
    rcm_inel = [r for r in rcm_books if r.get("ineligible")]
    t_rcm_inel = totals(rcm_inel)
    t_inel_other = totals(inelig_unallocated)

    t4a5 = {h: r2(t_books[h] - t_def[h] + t_rel[h]) for h in HEADS}
    t4b1 = {h: r2(t_inel_books[h] + t_rcm_inel[h] + t_inel_other[h]) for h in HEADS}

    imps = tally["registers"]["imps"]
    impg_books = tally["registers"]["impg"]
    impg_2b = buckets["impg"]
    isd_2b = buckets["isd"]
    rcm_2b = buckets["rcm"]

    use_2b_imports = str(cfg.get("import_of_goods_source", "2B")).upper() == "2B"
    t4a1 = totals(impg_2b if (use_2b_imports and impg_2b) else impg_books)
    t4a2 = totals(imps)
    t4a3 = totals(rcm_books)
    t4a4 = totals(isd_2b)

    t4a = {h: r2(t4a1[h] + t4a2[h] + t4a3[h] + t4a4[h] + t4a5[h]) for h in HEADS}
    t4c = {h: r2(t4a[h] - t4b1[h]) for h in HEADS}

    t31d = totals(tally["registers"]["t31d"]) if tally["registers"]["t31d"] else \
        {h: r2(t4a2[h] + t4a3[h]) for h in HEADS} | {"taxable": 0.0, "tax": 0.0, "n": 0}

    # Utilisation of the credit against the month's output liability. Reverse
    # charge under 3.1(d) is left out: it is payable in cash, not out of credit.
    t31a = totals(tally["registers"]["t31a"])
    opening = {h: r2((cfg.get("itc_ledger_opening") or {}).get(h, 0.0))
               for h in ("igst", "cgst", "sgst")}
    setoff_result = setoff.compute(opening, t4c, t31a, cfg)
    setoff_result["rcm_cash"] = {h: r2(t31d.get(h, 0.0))
                                 for h in ("igst", "cgst", "sgst")}

    return {
        "period_end": period_end,
        "month": cur_month,
        "month_label": cur_label,
        "company_name": tally.get("company_name") or cfg.get("company_name", ""),
        "company_gstin": tally.get("company_gstin") or cfg.get("company_gstin", ""),

        "books": books,
        "b2b": b2b,
        "rcm_books": rcm_books,
        "rcm_2b": rcm_2b,
        "impg_books": impg_books,
        "impg_2b": impg_2b,
        "imps_books": imps,
        "isd_2b": isd_2b,

        "only_books": only_books,
        "only_2b": only_2b,
        "deferred": deferred,
        "ineligible_books": ineligible_books,
        "ineligible_register": inelig_reg,
        "ineligible_unallocated": inelig_unallocated,
        "ineligible_basis": inelig_basis,
        "rcm_ineligible": rcm_inel,
        "require_correction": require_correction,
        "probable": probable,
        "decisions": decided,

        "released_eligible": rel_eligible,
        "released_ineligible": rel_ineligible,
        "released_timebarred": rel_timebarred,
        "closed_2b_master": closed_2b_master,
        "open_books_master": open_books_master,
        "open_b2b_master": open_b2b_master,

        "t_books": t_books,
        "t_deferred": t_def,
        "t_released": t_rel,
        "t_ineligible_books": t_inel_books,
        "t_rcm_ineligible": t_rcm_inel,
        "t_ineligible_other": t_inel_other,
        "t_ineligible_register": totals(inelig_reg),
        "t4a1": t4a1, "t4a2": t4a2, "t4a3": t4a3, "t4a4": t4a4, "t4a5": t4a5,
        "t4a": t4a, "t4b1": t4b1, "t4c": t4c, "t31d": t31d, "t31a": t31a,
        "setoff": setoff_result,

        "warnings": list(tally.get("warnings", [])) + list(gstr2b.get("warnings", [])),
        "tally": tally,
        "gstr2b": gstr2b,
        "master": master,
        "stats": {
            "primary": stats_primary,
            "books_vs_prior_2b": stats_books_vs_old2b,
            "b2b_vs_prior_books": stats_2b_vs_oldbooks,
        },
        "cfg": cfg,
    }


def months_between(later, earlier) -> int:
    if not later or not earlier:
        return 0
    return (later.year - earlier.year) * 12 + (later.month - earlier.month)


_JUNK_NAMES = {"to", "by", "dr", "cr", "none", "n/a", "#n/a", "-", "."}


def _clean_name(value) -> str:
    v = clean_text(value)
    if not v or v.startswith("#") or v.lower() in _JUNK_NAMES or len(v) < 3:
        return ""
    return v


def _name_directory(R: dict) -> dict:
    """Best known trading name per GSTIN, gathered from every source we hold."""
    best: dict[str, str] = {}
    pools = (R["books"], R["b2b"], R["master"]["books"], R["master"]["b2b"],
             R["only_books"], R["only_2b"])
    for pool in pools:
        for rec in pool:
            g = norm_gstin(rec.get("gstin"))
            if not g:
                continue
            for key in ("supplier", "particulars"):
                nm = _clean_name(rec.get(key))
                if nm and len(nm) > len(best.get(g, "")):
                    best[g] = nm
    return best


def build_watchlist(R: dict, cfg: dict) -> list[dict]:
    """
    Which suppliers keep us waiting.

    An invoice sitting in 'only in books, not in GSTR-2B' means we have recorded
    the purchase but the supplier has not reported it. A supplier who turns up
    there month after month is costing us working capital and is the one worth a
    phone call, so the ranking is driven by how many separate months they appear
    in and how much tax is stuck, not by a single large invoice.
    """
    period_end = R["period_end"]
    threshold = float(cfg.get("watchlist_amount_threshold", 10000))
    min_months = int(cfg.get("watchlist_min_months", 2))
    names = _name_directory(R)

    acc: dict[str, dict] = {}

    def slot(gstin, name=""):
        g = norm_gstin(gstin) or "(no GSTIN)"
        s = acc.get(g)
        if s is None:
            s = acc[g] = {
                "gstin": g, "name": name, "open_months": set(), "all_months": set(),
                "open_n": 0, "open_tax": 0.0, "open_igst": 0.0, "open_cgst": 0.0,
                "open_sgst": 0.0, "cleared_n": 0, "oldest": None,
                "delays": [], "late_n": 0, "seen_2b": 0,
            }
        nm = names.get(g) or _clean_name(name)
        if nm and len(nm) > len(s["name"]):
            s["name"] = nm
        return s

    def add_pending(rec, month, is_open):
        s = slot(rec.get("gstin"), rec.get("particulars") or rec.get("supplier"))
        m = month or ""
        if m:
            s["all_months"].add(m)
        if is_open:
            if m:
                s["open_months"].add(m)
            s["open_n"] += 1
            for h in ("igst", "cgst", "sgst"):
                s[f"open_{h}"] += rec.get(h, 0.0) or 0.0
            s["open_tax"] += (rec.get("igst", 0.0) or 0.0) + (rec.get("cgst", 0.0) or 0.0) \
                + (rec.get("sgst", 0.0) or 0.0) + (rec.get("cess", 0.0) or 0.0)
            d = rec.get("doc_date") or rec.get("date")
            if d and (s["oldest"] is None or d < s["oldest"]):
                s["oldest"] = d
        else:
            s["cleared_n"] += 1

    # history carried in the master, plus everything added this month
    for rec in R["master"]["books"]:
        add_pending(rec, rec.get("month"), not rec.get("cleared"))
    for rec in R["only_books"]:
        add_pending(rec, R["month"], True)

    # filing behaviour, read straight off GSTR-2B
    for rec in R["b2b"] + [r for r in R["master"]["b2b"]]:
        g = norm_gstin(rec.get("gstin"))
        if not g:
            continue
        s = slot(g, rec.get("supplier") or rec.get("particulars"))
        s["seen_2b"] += 1
        filed, doc_date = rec.get("gstr1_filed"), rec.get("doc_date")
        if filed and doc_date:
            s["delays"].append((filed - doc_date).days)
        period = rec.get("gstr1_period")
        if period and doc_date and months_between(period, doc_date) >= 1:
            s["late_n"] += 1

    out = []
    for s in acc.values():
        seen, late = s["seen_2b"], s["late_n"]
        chronically_late = seen >= 3 and late and (100.0 * late / seen) >= 34
        # A single late invoice is not a pattern; leave those out entirely so the
        # sheet stays about suppliers who are actually a problem.
        if not s["open_n"] and not chronically_late:
            continue
        open_months = len(s["open_months"])
        ageing = months_between(period_end, s["oldest"]) if s["oldest"] else 0
        delays = s["delays"]
        avg_delay = round(sum(delays) / len(delays)) if delays else None
        late_pct = round(100.0 * s["late_n"] / s["seen_2b"]) if s["seen_2b"] else 0

        material = s["open_tax"] >= threshold
        if open_months >= 3 and material:
            status, why = "Critical", (
                f"Has failed to report our invoices in {open_months} separate months; "
                f"Rs {s['open_tax']:,.0f} of credit is held up")
        elif open_months >= min_months and material:
            status, why = "Serious", (
                f"Missing in {open_months} months; Rs {s['open_tax']:,.0f} held up")
        elif open_months >= 3:
            status, why = "Serious", (
                f"Turns up on the pending master in {open_months} separate months")
        elif material:
            status, why = "Watch", f"Rs {s['open_tax']:,.0f} held up this month"
        elif open_months >= min_months:
            status, why = "Watch", f"Turns up repeatedly - {open_months} months"
        elif late_pct >= 50 and s["seen_2b"] >= 3:
            status, why = "Monitor", (
                f"Files late - {late_pct}% of invoices reported a month or more after issue")
        else:
            status, why = "Monitor", "Occasional delay"

        # Ageing is reported in its own right rather than overriding the ranking,
        # so a single old small invoice cannot outrank a chronic large supplier.
        risk = ""
        if s["open_n"] and ageing >= 17:
            risk = f"Section 16(4) window has closed on the oldest item ({ageing} months)"
            if material:
                status = "Critical"
        elif s["open_n"] and ageing >= 12:
            risk = f"Oldest item is {ageing} months old - 16(4) deadline approaching"

        out.append({
            "gstin": s["gstin"], "name": s["name"] or "(name not recorded)",
            "status": status, "why": why, "risk": risk,
            "open_n": s["open_n"], "open_tax": r2(s["open_tax"]),
            "open_igst": r2(s["open_igst"]), "open_cgst": r2(s["open_cgst"]),
            "open_sgst": r2(s["open_sgst"]),
            "open_months": open_months, "all_months": len(s["all_months"]),
            "cleared_n": s["cleared_n"], "oldest": s["oldest"], "ageing": ageing,
            "avg_delay": avg_delay, "late_pct": late_pct, "seen_2b": s["seen_2b"],
        })

    rank = {"Critical": 0, "Serious": 1, "Watch": 2, "Monitor": 3}
    out.sort(key=lambda x: (rank.get(x["status"], 9), -x["open_tax"], -x["open_months"]))
    return out


def _s164_deadline(rec):
    """Section 16(4): ITC for a financial year lapses after 30 November of the
    following financial year."""
    import datetime as _dt
    d = rec.get("doc_date") or rec.get("date")
    if not d:
        return None
    start = d.year if d.month >= 4 else d.year - 1
    return _dt.date(start + 1, 11, 30)


def _time_barred(rec, period_end) -> bool:
    dl = _s164_deadline(rec)
    return bool(dl and period_end and period_end > dl)


def _lbl(month_tag: str) -> str:
    """'Jun-26' -> \"Jun'26\"."""
    t = clean_text(month_tag)
    if not t:
        return "earlier"
    parts = t.replace("_", "-").split("-")
    if len(parts) == 2:
        yr = parts[1][-2:]
        return f"{parts[0][:3]}'{yr}"
    return t


# --------------------------------------------------------------------------
# Step 3 - journal entries
# --------------------------------------------------------------------------

def journal_entries(R: dict) -> list[dict]:
    lbl = R["month_label"]
    out = []
    tol = float(R["cfg"].get("tolerance_rupees", 1.0))

    def ties(a, b) -> bool:
        return all(abs(float(a.get(h) or 0) - float(b.get(h) or 0)) <= tol for h in HEADS)

    # Each line carries the tax head it represents and each entry the schedule it
    # comes from, so the workbook can point the amount at its backing working
    # rather than repeating a number nobody can trace.
    def entry(title, lines, narration="", src=None):
        lines = [l for l in lines if abs(l[1]) > 0.004 or abs(l[2]) > 0.004]
        if lines:
            out.append({"title": title, "lines": lines, "narration": narration, "src": src})

    d = R["t_deferred"]
    entry(f"ITC Deferred - {lbl}",
          [("IGST Deferred A/c", d["igst"], 0, "igst"),
           ("CGST Deferred A/c", d["cgst"], 0, "cgst"),
           ("SGST Deferred A/c", d["sgst"], 0, "sgst"),
           ("To IGST-Input", 0, d["igst"], "igst"),
           ("To CGST-Input", 0, d["cgst"], "cgst"),
           ("To SGST-Input", 0, d["sgst"], "sgst")],
          f"Being ITC on invoices booked in {lbl} but not reflected in GSTR-2B, "
          f"deferred to a later month ({len(R['deferred'])} invoices)",
          src=("sheet", "Deferred ITC"))

    for m in sorted(R["released_eligible"], key=month_sort_key):
        t = totals(R["released_eligible"][m])
        entry(f"ITC Deferred Reversal - {_lbl(m)}",
              [("IGST-Input", t["igst"], 0, "igst"),
               ("CGST-Input", t["cgst"], 0, "cgst"),
               ("SGST-Input", t["sgst"], 0, "sgst"),
               ("To IGST Deferred A/c", 0, t["igst"], "igst"),
               ("To CGST Deferred A/c", 0, t["cgst"], "cgst"),
               ("To SGST Deferred A/c", 0, t["sgst"], "sgst")],
              f"Being ITC of {_lbl(m)} deferred earlier, now appearing in GSTR-2B of {lbl} "
              f"and claimed ({len(R['released_eligible'][m])} invoices)",
              src=("reversal", m))

    b = R["t4b1"]
    entry("Reversal of Ineligible GST Input",
          [("GST Expense", r2(b["igst"] + b["cgst"] + b["sgst"] + b["cess"]), 0, "all"),
           ("To IGST-Input", 0, b["igst"], "igst"),
           ("To CGST-Input", 0, b["cgst"], "cgst"),
           ("To SGST-Input", 0, b["sgst"], "sgst")],
          f"Being ineligible ITC under section 17(5) reversed in Table 4(B)(1) for {lbl}",
          src=("sheet", "Ineligible ITC")
          if ties(totals(R["ineligible_register"]), b) else ("3b", "t4b1"))

    r = R["t31d"]
    entry("Booking of RCM Liability",
          [("IGST-Input", r["igst"], 0, "igst"),
           ("CGST-Input", r["cgst"], 0, "cgst"),
           ("SGST-Input", r["sgst"], 0, "sgst"),
           ("To IGST Payable (RCM)", 0, r["igst"], "igst"),
           ("To CGST Payable (RCM)", 0, r["cgst"], "cgst"),
           ("To SGST Payable (RCM)", 0, r["sgst"], "sgst")],
          f"Being RCM liability booked for {lbl} as per Table 3.1(d)",
          src=("sheet", "Table 3.1d")
          if ties(totals(R["tally"]["registers"].get("t31d", [])), r) else ("3b", "t31d"))

    so = R.get("setoff") or {}
    disc = so.get("discharged_by_head", {})
    util = so.get("utilised_by_credit", {})
    cash = so.get("cash", {})
    entry("ITC Adjustment against Output Liability",
          [("IGST Payable", disc.get("igst", 0), 0, "igst", "discharged"),
           ("CGST Payable", disc.get("cgst", 0), 0, "cgst", "discharged"),
           ("SGST Payable", disc.get("sgst", 0), 0, "sgst", "discharged"),
           ("To IGST-Input", 0, util.get("igst", 0), "igst", "utilised"),
           ("To CGST-Input", 0, util.get("cgst", 0), "cgst", "utilised"),
           ("To SGST-Input", 0, util.get("sgst", 0), "sgst", "utilised")],
          f"Being input tax credit utilised against the output liability of {lbl} in the "
          f"order laid down by sections 49(5), 49A and rule 88A, the IGST balance being "
          f"applied {so.get('order', 'CGST first')}. Cash still payable: "
          f"IGST {cash.get('igst', 0):,.2f}, CGST {cash.get('cgst', 0):,.2f} and "
          f"SGST {cash.get('sgst', 0):,.2f}, besides reverse charge under Table 3.1(d), "
          f"which is payable in cash and cannot be met out of credit",
          src=("setoff", None))
    return out


# --------------------------------------------------------------------------
# Entry point
# --------------------------------------------------------------------------

def run(file1: str, file2: str, file3: str | None, cfg: dict,
        decided: dict | None = None) -> dict:
    tally = read_tally.read(file1)
    gstr2b = read_2b.read(file2, tally.get("company_gstin", ""))
    master = read_master.read(file3)
    R = reconcile(tally, gstr2b, master, cfg, decided)
    R["entries"] = journal_entries(R)
    R["watchlist"] = build_watchlist(R, cfg)
    return R

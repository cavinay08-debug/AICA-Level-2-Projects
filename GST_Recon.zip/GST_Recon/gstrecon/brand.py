"""
EXI brand values, taken from EXI_Brand_Guidelines.pptx.

One place for the palette, the type and the logo files, so the window and the
workbook cannot drift apart. Nothing here is invented: the hex values are the
ones printed in the guide, not sampled from the artwork, which carries slightly
different values after compression.

  Primary    Blue   #272361      Brown  #412312
  Neutral    Black  #000000      White  #FFFFFF
  Accent     Red    #D83030      digital only

  Usage      Blue 60, White 25, Brown 10, Red 5 (accent only)
  Type       Fira Sans, bold or semi-bold for headings, regular for body.
             Fallback for Office and email: Calibri, then Arial.
  Shapes     Angular, inspired by the logo. Clean margins. No rounded edges.
  Avoid      Cartoons, clipart, emoticons, loud graphics.

The guide gives no green or amber, and a reconciliation has to show three
states. Rather than introduce colours the brand does not own, the three states
are carried on the three brand colours: blue for agreed, brown for needs
attention, red for a difference. Red is the guide's own accent for exactly this
sort of signalling, and the proportions come out close to the 60/25/10/5 split.
"""

from __future__ import annotations

import os

BLUE = "272361"
BROWN = "412312"
BLACK = "000000"
WHITE = "FFFFFF"
RED = "D83030"

# Tints, for fills that must sit under black text. Mixed with white from the
# brand colours themselves so nothing new is introduced.
BLUE_TINT = "E9E9F0"
BLUE_TINT_2 = "D4D3E0"
BROWN_TINT = "F2ECE8"
BROWN_TINT_2 = "E4D8D0"
RED_TINT = "FBE9E9"
GREY_TINT = "F4F5F8"
RULE = "D8DBE4"

# Deeper and lighter blues, for a header band and for hover states. Same hue.
BLUE_DEEP = "1A1743"
BLUE_MID = "3A3580"
BLUE_SOFT = "6F6BA8"

TEXT = "111827"
MUTED = "5A5F6E"
FAINT = "8A8F9E"

# Fira Sans first, as the guide requires, then the fallbacks it names.
FONT_STACK = ("Fira Sans", "Calibri", "Arial")
FONT_EXCEL = "Calibri"          # the guide's stated Office fallback

ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")


def asset(name: str) -> str | None:
    path = os.path.join(ASSETS, name + ".png")
    return path if os.path.exists(path) else None


def ui_font(root, size, weight="normal"):
    """
    The first font in the stack the machine actually has.

    The guide asks for Fira Sans to be installed everywhere; where it is not,
    it names Calibri and then Arial, so this walks the same order rather than
    silently landing on whatever tkinter defaults to.
    """
    try:
        from tkinter import font as tkfont
        have = {f.lower() for f in tkfont.families(root)}
    except Exception:
        have = set()
    for name in FONT_STACK:
        if name.lower() in have:
            return (name, size, weight) if weight != "normal" else (name, size)
    return ("TkDefaultFont", size, weight) if weight != "normal" else ("TkDefaultFont", size)


def hexes(*names) -> tuple:
    return tuple("#" + h for h in names)

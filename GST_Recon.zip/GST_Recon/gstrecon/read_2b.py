"""Reader for File 2 - the GSTR-2B workbook downloaded from the GST portal.

Every relevant section (B2B, credit/debit notes, their amendments, ECO, ISD,
imports) is flattened into one canonical row shape so the matcher only ever
sees a single list.
"""

from __future__ import annotations

import openpyxl

from .sheetutil import (build_map, cell, forward_fill, grid, is_blank_row,
                        merged_header, trim_grid)
from .util import clean_text, month_key, norm_gstin, num, to_date, yes_no

ALIASES = {
    "gstin":        ["gstin of supplier", "gstin of eco", "gstin of isd", "supplier gstin", "gstin"],
    "supplier":     ["trade legal name", "supplier name", "trade name"],
    "doc_no":       ["invoice number", "note number", "document number", "isd document number",
                     "bill of entry number", "number", "doc no"],
    "doc_type":     ["invoice type", "note type", "document type", "isd document type", "doc type"],
    "doc_date":     ["invoice date", "note date", "document date", "isd document date",
                     "bill of entry date", "doc date", "bill of entry details date"],
    "doc_value":    ["invoice value", "note value", "document value", "doc value"],
    "pos":          ["place of supply", "pos"],
    "rev_charge":   ["supply attract reverse charge", "reverse charge"],
    "taxable":      ["taxable value", "item taxable value", "taxable"],
    "igst":         ["integrated tax", "igst"],
    "cgst":         ["central tax", "cgst"],
    "sgst":         ["state ut tax", "state tax", "sgst"],
    "cess":         ["cess"],
    "gstr1_period": ["gstr 1 1a iff gstr 5 period", "gstr 1 iff 1a gstr 5 period",
                     "gstr 1 1a iff period", "isd gstr 6 period", "gstr 1 iff 1a period",
                     "gstr 1 filing period", "period"],
    "gstr1_filed":  ["gstr 1 1a iff gstr 5 filing date", "gstr 1 iff 1a gstr 5 filing date",
                     "gstr 1 1a iff filing date", "isd gstr 6 filing date",
                     "gstr 1 filing date", "filing date"],
    "itc_eligible": ["itc availability", "itc eligible", "eligibility of itc"],
    "itc_reason":   ["reason", "itc ineligible reason type"],
    "rate":         ["applicable of tax rate", "gst rate", "rate"],
    "port_code":    ["port code"],
    "icegate_date": ["icegate reference date"],
    "orig_doc_no":  ["original invoice number", "original doc no"],
    "orig_doc_date": ["original invoice date", "original doc date"],
}

# sheet name -> (purchase_type, is_amendment, is_credit_note_section, bucket, header_tokens)
SECTIONS = [
    ("b2b",            "B2B",  False, False, "itc", ["gstin of supplier", "invoice number"]),
    ("b2ba",           "B2BA", True,  False, "itc", ["gstin of supplier", "invoice number"]),
    ("b2b-cdnr",       "CDN",  False, True,  "itc", ["gstin of supplier", "note number"]),
    ("b2b-cdnra",      "CDNA", True,  True,  "itc", ["gstin of supplier", "note number"]),
    ("b2b-dnr",        "DNR",  False, True,  "itc", ["gstin of supplier", "note number"]),
    ("b2b-dnra",       "DNRA", True,  True,  "itc", ["gstin of supplier", "note number"]),
    ("eco",            "ECO",  False, False, "itc", ["gstin of eco", "document number"]),
    ("ecoa",           "ECOA", True,  False, "itc", ["gstin of eco", "document number"]),
    ("isd",            "ISD",  False, False, "isd", ["gstin of isd"]),
    ("isda",           "ISDA", True,  False, "isd", ["gstin of isd"]),
    ("impg",           "IMPG", False, False, "impg", ["port code"]),
    ("impga",          "IMPGA", True, False, "impg", ["port code"]),
    ("impgsez",        "IMPGSEZ", False, False, "impg", ["port code"]),
    ("impgseza",       "IMPGSEZA", True, False, "impg", ["port code"]),
]

# Sections the portal lists but which must NOT be treated as available credit
EXCLUDE_SUFFIXES = ("(rejected)", "(itc reversal)")

_CREDIT_CODES = {"C", "CN", "CRN", "CR"}
_DEBIT_CODES = {"D", "DN", "DRN", "DR"}


def _doc_kind(raw: str) -> str:
    """Classify a document-type cell. Portal exports use either the full words
    or single-letter codes depending on how the file was produced."""
    t = clean_text(raw).upper()
    if not t:
        return "unknown"
    if "CREDIT" in t:
        return "credit"
    if "DEBIT" in t:
        return "debit"
    squashed = t.replace(" ", "").replace("-", "").replace("_", "")
    if squashed in _CREDIT_CODES:
        return "credit"
    if squashed in _DEBIT_CODES:
        return "debit"
    if "INVOICE" in t or "INV" == squashed:
        return "invoice"
    return "unknown"


def _find_header_row(rows, tokens):
    """Locate the header row and how many rows the header spans."""
    toks = [t.lower() for t in tokens]
    sub_markers = ("integrated tax", "central tax", "invoice number",
                   "note number", "document number", "taxable value")

    def joined(i):
        if i < 0 or i >= len(rows):
            return ""
        return " | ".join(clean_text(c).lower() for c in rows[i])

    def width(i):
        if i < 0 or i >= len(rows):
            return 0
        return sum(1 for c in rows[i] if clean_text(c))

    # Pass A - every token sits in one row (the common case).
    for i in range(min(12, len(rows))):
        if all(t in joined(i) for t in toks):
            depth = 2 if any(m in joined(i + 1) for m in sub_markers) else 1
            return i, depth

    # Pass B - portal two-row header: group labels on top, detail labels below.
    for i in range(min(12, len(rows))):
        both = joined(i) + " | " + joined(i + 1)
        if all(t in both for t in toks) and width(i) >= 3:
            return i, 2
    return None, 1


def _read_section(ws, purchase_type, is_amend, is_note, bucket, tokens, company_gstin,
                  warnings=None):
    warnings = warnings if warnings is not None else []
    rows = trim_grid(grid(ws))
    if not rows:
        return []
    hdr, depth = _find_header_row(rows, tokens)
    if hdr is None:
        return []

    if depth == 2:
        top = forward_fill([clean_text(c) for c in rows[hdr]])
        sub = [clean_text(c) for c in rows[hdr + 1]]
        width = max(len(top), len(sub))
        top += [""] * (width - len(top))
        sub += [""] * (width - len(sub))
        headers = [(f"{t} {s}".strip() if s else t) for t, s in zip(top, sub)]
    else:
        headers = merged_header(rows, hdr, depth=1)

    # For amendment sheets the *revised* details are what matter. The portal puts
    # "Original Details" first, so blank those columns out of the alias search
    # entirely -- prefixing them is not enough, because the alias matcher also
    # tests substrings and "invoice number" sits inside "original invoice number".
    orig_cut = 0
    if is_amend:
        for i, h in enumerate(rows[hdr - 1] if hdr > 0 else []):
            if clean_text(h).lower().startswith("revised"):
                orig_cut = i
                break

    search_headers = list(headers)
    orig_doc_col = orig_date_col = None
    if orig_cut:
        for i in range(min(orig_cut, len(search_headers))):
            slug = search_headers[i].lower()
            if orig_doc_col is None and ("number" in slug or "no" == slug.strip()):
                orig_doc_col = i
            elif orig_date_col is None and "date" in slug:
                orig_date_col = i
            search_headers[i] = ""

    cmap = build_map(search_headers, ALIASES)
    if "doc_no" not in cmap and bucket != "impg":
        return []

    out = []
    for i in range(hdr + depth, len(rows)):
        row = rows[i]
        if is_blank_row(row):
            continue
        doc_no = clean_text(cell(row, cmap.get("doc_no")))
        gstin = norm_gstin(cell(row, cmap.get("gstin")))
        taxable = num(cell(row, cmap.get("taxable")))
        igst = num(cell(row, cmap.get("igst")))
        cgst = num(cell(row, cmap.get("cgst")))
        sgst = num(cell(row, cmap.get("sgst")))
        cess = num(cell(row, cmap.get("cess")))
        if not doc_no and not gstin and not (taxable or igst or cgst or sgst):
            continue
        # skip a repeated header inside the body
        if clean_text(cell(row, cmap.get("doc_no"))).lower() in {"invoice number", "note number", "document number", "number"}:
            continue

        doc_type_raw = clean_text(cell(row, cmap.get("doc_type")))
        kind = _doc_kind(doc_type_raw)
        if bucket == "impg":
            doc_type = "Bill of Entry"
        elif kind == "credit":
            doc_type = "Credit Note"
        elif kind == "debit":
            doc_type = "Debit Note"
        elif is_note:
            doc_type = doc_type_raw or "Note (type not stated)"
        else:
            doc_type = doc_type_raw or "Invoice"

        # A credit note reduces credit, so it is carried negative. If the portal
        # has already signed it, leave it alone rather than flipping it back.
        sign = 1.0
        if kind == "credit":
            already = min(taxable, igst, cgst, sgst, cess) < 0
            sign = 1.0 if already else -1.0
        elif is_note and kind == "unknown":
            warnings.append(
                f"{ws.title} row {i + 1}: note type is blank, so the sign could not be "
                f"determined. Document {doc_no or '(no number)'} has been taken as given.")

        rec = {
            "tax_period": to_date(cell(row, cmap.get("gstr1_period"))),
            "doc_type": doc_type,
            "purchase_type": "Import of goods" if bucket == "impg" else purchase_type,
            "doc_no": doc_no,
            "doc_date": to_date(cell(row, cmap.get("doc_date"))),
            "gstin": gstin,
            "supplier": clean_text(cell(row, cmap.get("supplier"))),
            "pos": clean_text(cell(row, cmap.get("pos"))),
            "port_code": clean_text(cell(row, cmap.get("port_code"))),
            "rev_charge": yes_no(cell(row, cmap.get("rev_charge"))),
            "doc_value": sign * num(cell(row, cmap.get("doc_value"))),
            "taxable": sign * taxable,
            "rate": clean_text(cell(row, cmap.get("rate"))),
            "igst": sign * igst,
            "cgst": sign * cgst,
            "sgst": sign * sgst,
            "cess": sign * cess,
            "is_amendment": "Yes" if is_amend else "",
            "orig_doc_no": clean_text(cell(row, orig_doc_col)) if orig_doc_col is not None
                           else clean_text(cell(row, cmap.get("orig_doc_no"))),
            "orig_doc_date": to_date(cell(row, orig_date_col)) if orig_date_col is not None
                             else None,
            "gstr1_period": to_date(cell(row, cmap.get("gstr1_period"))),
            "gstr1_filed": to_date(cell(row, cmap.get("gstr1_filed"))),
            "itc_eligible": yes_no(cell(row, cmap.get("itc_eligible"))),
            "itc_reason": clean_text(cell(row, cmap.get("itc_reason"))),
            "icegate_date": to_date(cell(row, cmap.get("icegate_date"))),
            "bucket": bucket,
            "section": ws.title,
            "src_row": i + 1,
        }
        rec["supplier_state"] = rec["pos"] if bucket == "impg" else ""
        rec["tax"] = rec["igst"] + rec["cgst"] + rec["sgst"] + rec["cess"]
        rec["month"] = month_key(rec["gstr1_period"] or rec["doc_date"])
        out.append(rec)
    return out


def _summary_table(ws) -> list[dict]:
    rows = trim_grid(grid(ws))
    out = []
    for row in rows:
        sno = clean_text(row[0] if row else "")
        head = clean_text(row[1] if len(row) > 1 else "")
        table = clean_text(row[2] if len(row) > 2 else "").replace("\n", " ")
        if not head:
            continue
        out.append({
            "sno": sno, "heading": head, "table": table,
            "igst": num(row[3] if len(row) > 3 else 0),
            "cgst": num(row[4] if len(row) > 4 else 0),
            "sgst": num(row[5] if len(row) > 5 else 0),
            "cess": num(row[6] if len(row) > 6 else 0),
        })
    return out


def read(path: str, company_gstin: str = "") -> dict:
    wb = openpyxl.load_workbook(path, data_only=True, read_only=False)
    names = {n.lower().strip(): n for n in wb.sheetnames}

    records, sections_read, warnings = [], {}, []
    for key, ptype, is_amend, is_note, bucket, tokens in SECTIONS:
        real = names.get(key)
        if real is None:
            continue
        recs = _read_section(wb[real], ptype, is_amend, is_note, bucket, tokens,
                             company_gstin, warnings)
        sections_read[real] = len(recs)
        records.extend(recs)

    skipped = [n for n in wb.sheetnames
               if any(n.lower().strip().endswith(s) for s in EXCLUDE_SUFFIXES)]

    summaries = {}
    for label, sheet in (("available", "ITC Available"),
                         ("not_available", "ITC not available"),
                         ("reversal", "ITC Reversal"),
                         ("rejected", "ITC Rejected")):
        real = names.get(sheet.lower())
        if real:
            summaries[label] = _summary_table(wb[real])

    wb.close()
    return {
        "path": path,
        "records": records,
        "sections_read": sections_read,
        "sections_skipped": skipped,
        "summaries": summaries,
        "warnings": warnings,
    }


def split_buckets(records: list[dict]) -> dict:
    """Split the flat 2B list into the buckets that feed different 3B tables."""
    out = {"itc": [], "rcm": [], "impg": [], "isd": []}
    for r in records:
        if r["bucket"] == "impg":
            out["impg"].append(r)
        elif r["bucket"] == "isd":
            out["isd"].append(r)
        elif r.get("rev_charge") == "Yes":
            out["rcm"].append(r)
        else:
            out["itc"].append(r)
    return out

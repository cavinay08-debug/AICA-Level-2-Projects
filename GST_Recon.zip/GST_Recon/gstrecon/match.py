"""The matching engine.

Pass 1  Exact      GSTIN + document number, character for character.
Pass 2  Normalised GSTIN + document number ignoring case, separators and
                   leading zeros, with the tax amount agreeing.
Pass 3  Probable   Same GSTIN, same tax, invoice dates close together, and
                   exactly one candidate. Always flagged for review.

Anything the passes reject is then examined for two well-known causes of a
false mismatch: the supplier's GSTIN captured for the wrong state, and tax
charged under the wrong head.
"""

from __future__ import annotations

from collections import defaultdict

from .decisions import key as pair_key
from .util import (doc_key_exact, doc_key_norm, doc_key_tail, gstin_pan,
                   norm_gstin, r2)

EXACT = "Exact"
NORMALISED = "Normalised doc no."
PARTIAL = "Partial doc no."
PROBABLE = "Probable - verify"
NOTE_VALUE = "Note - matched on value"
UNMATCHED = ""

_NOTE_WORDS = ("note", "credit", "debit")


def is_note(rec) -> bool:
    """
    A debit note we raise against a supplier is a credit note in their GSTR-1,
    so it reaches GSTR-2B under their number, not ours. The document numbers on
    the two sides are not the same document number at all.
    """
    for f in ("doc_type", "vch_type", "purchase_type"):
        t = str(rec.get(f) or "").lower()
        if any(w in t for w in _NOTE_WORDS):
            return True
    return _tax(rec) < 0


def _tax(rec) -> float:
    return r2(rec.get("igst", 0) + rec.get("cgst", 0) + rec.get("sgst", 0) + rec.get("cess", 0))


class Candidates:
    """Lookup structures over one side of the reconciliation."""

    def __init__(self, rows: list[dict], doc_field: str = "doc_no"):
        self.rows = rows
        self.doc_field = doc_field
        self.by_exact = defaultdict(list)
        self.by_norm = defaultdict(list)
        self.by_tail = defaultdict(list)
        self.by_pan_norm = defaultdict(list)
        self.by_gstin = defaultdict(list)
        for idx, r in enumerate(rows):
            g = norm_gstin(r.get("gstin"))
            doc = r.get(doc_field) or r.get("doc_no")
            self.by_exact[(g, doc_key_exact(doc))].append(idx)
            self.by_norm[(g, doc_key_norm(doc))].append(idx)
            tail = doc_key_tail(doc)
            if len(tail) >= 4:
                self.by_tail[(g, tail)].append(idx)
            pan = gstin_pan(g)
            if pan:
                self.by_pan_norm[(pan, doc_key_norm(doc))].append(idx)
            self.by_gstin[g].append(idx)


def match_rows(left: list[dict], right: list[dict], cfg: dict,
               left_doc_field: str = "upd_doc_no",
               right_doc_field: str = "doc_no",
               allow_probable: bool = True,
               consumed: set | None = None,
               tag: str = "",
               consume_exact: bool = False,
               require_amount: bool = False,
               blocked_pairs: set | None = None,
               allow_note_value: bool = False) -> dict:
    """
    Try to find a partner in `right` for every row in `left`.

    The passes run one at a time across the WHOLE population, strongest first,
    so a weak probable match can never take a document that a later row would
    have matched exactly.

    consume_exact  - reserve the partner even on an exact hit. Off for the
                     within-month run, where the group totals decide the
                     verdict and a repeated document number must be visible.
                     On for cross-month runs, where one prior document may
                     release exactly one entry.
    require_amount - the tax must also agree before the match is accepted.
    blocked_pairs  - pairs already rejected by hand. A rejection kills the guess,
                     not the invoice, so only the probable pass consults it: if
                     the document numbers later agree on their own, that is
                     better evidence than the one that was turned down.
    """
    tol = float(cfg.get("tolerance_rupees", 1.0))
    gap = int(cfg.get("probable_match_max_day_gap", 45))
    min_tax = float(cfg.get("probable_match_min_tax", 1.0))
    use_norm = bool(cfg.get("enable_normalised_match", True))
    use_prob = bool(cfg.get("enable_probable_match", True)) and allow_probable
    allow_short = bool(cfg.get("match_when_2b_higher", True))
    use_notes = allow_note_value and bool(cfg.get("match_notes_on_value", True))

    cand = Candidates(right, right_doc_field)
    rejected = blocked_pairs or set()
    taken = consumed if consumed is not None else set()
    # Exact matches do not consume their partner (several book lines may share a
    # document number and are compared on the group total), but they must still
    # reserve it, so that a weaker pass cannot take a document that has already
    # been matched on its number.
    reserved: set = set()
    stats = defaultdict(int)

    def free(idxs):
        return [i for i in idxs if i not in taken and i not in reserved]

    def free_exact(idxs):
        return [i for i in idxs if i not in taken]

    def amount_ok(row, idx):
        """
        Cross-month passes insist the tax agrees. The one exception is the other
        side being the higher of the two: credit is claimed from the books, so a
        supplier reporting more than we booked releases the booked amount and
        nothing more. Signs must agree, or a debit note matches its own invoice.
        """
        if not require_amount:
            return True
        mine, theirs = _tax(row), _tax(right[idx])
        if abs(theirs - mine) <= tol:
            return True
        if not allow_short:
            return False
        return same_sign(mine, theirs) and (mine - theirs) <= tol

    def pass_exact(row, g, doc, my_tax):
        hits = [i for i in free_exact(cand.by_exact.get((g, doc_key_exact(doc)), []))
                if amount_ok(row, i)]
        return (hits[0], EXACT) if hits else None

    def pass_norm(row, g, doc, my_tax):
        if not use_norm:
            return None
        hits = free(cand.by_norm.get((g, doc_key_norm(doc)), []))
        good = [i for i in hits if abs(_tax(right[i]) - my_tax) <= tol]
        pick = good or ([] if require_amount else hits)
        return (pick[0], NORMALISED) if pick else None

    def pass_tail(row, g, doc, my_tax):
        if not use_norm:
            return None
        tail = doc_key_tail(doc)
        if len(tail) < 4:
            return None
        hits = free(cand.by_tail.get((g, tail), []))
        good = [i for i in hits if abs(_tax(right[i]) - my_tax) <= tol]
        if len(good) == 1:
            return (good[0], PARTIAL)
        # The same document number carrying a different amount still beats a
        # different document number that happens to carry the same amount, which
        # is all the probable pass has to go on.
        if len(hits) == 1 and not require_amount:
            return (hits[0], PARTIAL)
        return None

    def pass_probable(row, g, doc, my_tax):
        if not use_prob or abs(my_tax) < min_tax:
            return None
        good = []
        for i in free(cand.by_gstin.get(g, [])):
            other = right[i]
            if abs(_tax(other) - my_tax) > tol:
                continue
            d1, d2 = row.get("doc_date"), other.get("doc_date")
            if d1 and d2 and abs((d1 - d2).days) > gap:
                continue
            if rejected and pair_key(g, row.get("doc_no"), other.get("doc_no")) in rejected:
                continue
            good.append(i)
        return (good[0], PROBABLE) if len(good) == 1 else None

    def pass_note(row, g, doc, my_tax):
        """Notes, on the supplier and the amount. The number is no help here."""
        if not use_notes or abs(my_tax) < min_tax or not is_note(row):
            return None
        good = [i for i in free(cand.by_gstin.get(g, []))
                if is_note(right[i]) and abs(_tax(right[i]) - my_tax) <= tol]
        return (good[0], NOTE_VALUE) if len(good) == 1 else None

    for fn in (pass_exact, pass_norm, pass_tail, pass_note, pass_probable):
        for row in left:
            if row.get("_match_type"):
                continue
            g = norm_gstin(row.get("gstin"))
            doc = row.get(left_doc_field) or row.get("doc_no")
            found = fn(row, g, doc, _tax(row))
            if not found:
                continue
            idx, kind = found
            _bind(row, right, idx, kind, tag, right_doc_field, taken,
                  consume_exact=consume_exact)
            reserved.add(idx)
            stats[kind] += 1

    stats["unmatched"] = sum(1 for row in left if not row.get("_match_type"))
    return dict(stats)


def _bind(row, right, idx, kind, tag, right_doc_field, taken, consume_exact=False):
    other = right[idx]
    row["_match_type"] = kind
    row["_match_idx"] = idx
    row["_match_tag"] = tag
    row["_match_row"] = other
    row["_resolved_doc"] = other.get(right_doc_field) or other.get("doc_no") or row.get("doc_no")
    if kind != EXACT or consume_exact:
        taken.add(idx)
    other.setdefault("_matched_by", []).append(row)


# --------------------------------------------------------------------------
# Diagnostics for rows that stayed unmatched
# --------------------------------------------------------------------------

def diagnose(left: list[dict], right: list[dict], cfg: dict,
             left_doc_field: str = "upd_doc_no",
             right_doc_field: str = "doc_no",
             left_label: str = "books", right_label: str = "2B") -> None:
    """Explain likely causes for unmatched rows; writes row['_issue']."""
    if not (cfg.get("detect_wrong_gstin", True) or cfg.get("detect_wrong_tax_head", True)):
        return
    tol = float(cfg.get("tolerance_rupees", 1.0))
    cand = Candidates(right, right_doc_field)

    for row in left:
        if row.get("_match_type") or row.get("_issue"):
            continue
        g = norm_gstin(row.get("gstin"))
        doc = row.get(left_doc_field) or row.get("doc_no")
        nkey = doc_key_norm(doc)
        my = (r2(row.get("igst")), r2(row.get("cgst")), r2(row.get("sgst")))
        my_tax = _tax(row)

        # Same PAN, different state code -> GSTIN captured wrongly somewhere.
        if cfg.get("detect_wrong_gstin", True):
            pan = gstin_pan(g)
            hits = cand.by_pan_norm.get((pan, nkey), []) if pan else []
            hits = [i for i in hits if norm_gstin(right[i].get("gstin")) != g]
            if hits:
                other = right[hits[0]]
                row["_issue"] = (f"GSTIN differs - {left_label} has {g}, "
                                 f"{right_label} has {norm_gstin(other.get('gstin'))}")
                row["_issue_kind"] = "Wrong GSTIN"
                row["_issue_row"] = other
                continue

        # Same document, but tax sits under a different head.
        if cfg.get("detect_wrong_tax_head", True):
            hits = cand.by_norm.get((g, nkey), [])
            if not hits:
                tail = doc_key_tail(doc)
                hits = cand.by_tail.get((g, tail), []) if len(tail) >= 4 else []
            for i in hits:
                other = right[i]
                theirs = (r2(other.get("igst")), r2(other.get("cgst")), r2(other.get("sgst")))
                if abs(_tax(other) - my_tax) <= tol and my != theirs:
                    mine_head = "IGST" if abs(my[0]) > tol else "CGST/SGST"
                    their_head = "IGST" if abs(theirs[0]) > tol else "CGST/SGST"
                    if mine_head != their_head:
                        row["_issue"] = (f"Wrong tax head - {left_label} under {mine_head}, "
                                         f"{right_label} under {their_head}")
                        row["_issue_kind"] = "Wrong tax head"
                        row["_issue_row"] = other
                        break
            if row.get("_issue"):
                continue

        # Document numbers agree but the value does not.
        hits = cand.by_norm.get((g, nkey), [])
        if hits:
            other = right[hits[0]]
            diff = r2(my_tax - _tax(other))
            if abs(diff) > tol:
                side = left_label if diff > 0 else right_label
                row["_issue"] = (f"Same document, tax differs by {abs(diff):,.2f} "
                                 f"(higher in {side})")
                row["_issue_kind"] = "Value difference"
                row["_issue_row"] = other


# --------------------------------------------------------------------------
# SUMIFS-equivalent group comparison (this is what the Excel formulas do)
# --------------------------------------------------------------------------

def group_totals(rows: list[dict], doc_field: str) -> dict:
    out = defaultdict(lambda: {"igst": 0.0, "cgst": 0.0, "sgst": 0.0, "cess": 0.0, "n": 0})
    for r in rows:
        key = (norm_gstin(r.get("gstin")), doc_key_exact(r.get(doc_field) or r.get("doc_no")))
        g = out[key]
        for h in ("igst", "cgst", "sgst", "cess"):
            g[h] += r.get(h, 0.0) or 0.0
        g["n"] += 1
    return out


SHORT = "Matched - GSTR-2B higher"

HEADS = ("igst", "cgst", "sgst", "cess")


def same_sign(a: float, b: float) -> bool:
    """A debit note against an invoice is not an under-booking, it is a different
    document. Only amounts pointing the same way may be compared this way."""
    return (a or 0.0) * (b or 0.0) >= 0


def apply_group_verdict(left: list[dict], left_doc_field: str,
                        right: list[dict], right_doc_field: str,
                        cfg: dict, claim_side: str = "left") -> None:
    """
    Compare group totals on both sides -- identical to the SUMIFS pair written
    into the workbook -- and stamp the final verdict.

    A document may be matched even when the two sides disagree, provided the
    books are the LOWER of the two. Credit is limited to what is booked, so a
    supplier who has reported more than we recorded costs us nothing; the other
    way round would over-claim, and stays Not Matched. Signs must agree, or a
    debit note would match the invoice it reverses.

    claim_side says which list holds the books, because the test is one-sided.
    """
    tol = float(cfg.get("tolerance_rupees", 1.0))
    allow_short = bool(cfg.get("match_when_2b_higher", True))
    lg = group_totals(left, left_doc_field)
    rg = group_totals(right, right_doc_field)
    for row in left:
        key = (norm_gstin(row.get("gstin")),
               doc_key_exact(row.get(left_doc_field) or row.get("doc_no")))
        mine, theirs = lg[key], rg.get(key)
        t = theirs or {"igst": 0.0, "cgst": 0.0, "sgst": 0.0, "cess": 0.0, "n": 0}
        row["_grp_2b_igst"] = r2(t["igst"])
        row["_grp_2b_cgst"] = r2(t["cgst"])
        row["_grp_own_igst"] = r2(mine["igst"])
        row["_grp_own_cgst"] = r2(mine["cgst"])
        for h in HEADS:
            row[f"_diff_{h}"] = r2(mine[h] - t[h])
        row["_dup_count"] = mine["n"]
        row["_rem_igst"] = "Matched" if abs(row["_diff_igst"]) <= tol else "Not Matched"
        row["_rem_cgst"] = "Matched" if abs(row["_diff_cgst"]) <= tol else "Not Matched"

        exact = all(abs(row[f"_diff_{h}"]) <= tol for h in HEADS)
        # books not exceeding the other side, on every head, with signs agreeing
        if claim_side == "left":
            within = all(row[f"_diff_{h}"] <= tol for h in HEADS)
        else:
            within = all(row[f"_diff_{h}"] >= -tol for h in HEADS)
        signs = all(same_sign(mine[h], t[h]) for h in HEADS)
        short = allow_short and not exact and within and signs

        row["_matched"] = t["n"] > 0 and (exact or short)
        row["_short"] = bool(t["n"] > 0 and short)
        if row["_short"]:
            row["_short_detail"] = {h: r2(t[h] - mine[h]) for h in HEADS}

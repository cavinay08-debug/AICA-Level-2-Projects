"""The desktop window.

Built on tkinter, which ships with Python, so the tool needs nothing beyond
openpyxl. Everything happens on this computer; no data leaves it.
"""

from __future__ import annotations

import json
import os
import queue
import subprocess
import sys
import threading
import traceback
import webbrowser

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from . import brand as B
from . import config, detect, pipeline
from .util import r2

APP_TITLE = "GST Reconciliation  -  GSTR-2B vs Books"
STATE_FILE = ".last_run.json"

AUTO_MONTH = "Read it from the export"

# EXI brand values. See brand.py; nothing is chosen here.
BG = "#" + B.GREY_TINT
CARD = "#" + B.WHITE
LINE = "#" + B.RULE
INK = "#" + B.BLUE
INK_DEEP = "#" + B.BLUE_DEEP
INK_MID = "#" + B.BLUE_MID
INK_SOFT = "#" + B.BLUE_SOFT
BROWN = "#" + B.BROWN
TEXT = "#" + B.TEXT
MUTED = "#" + B.MUTED
FAINT = "#" + B.FAINT
ACCENT = "#" + B.BLUE
BAD = "#" + B.RED

# Three states on three brand colours, since the guide owns no green or amber.
CHIP_GOOD = "#" + B.BLUE_TINT
CHIP_WARN = "#" + B.BROWN_TINT
CHIP_BAD = "#" + B.RED_TINT
GOOD = "#" + B.BLUE
WARN = "#" + B.BROWN
ZEBRA = "#" + B.GREY_TINT

# Blue leads, brown supports, red is the accent only, as the guide sets out.
STEP_COLOURS = ("#" + B.BLUE, "#" + B.BLUE_MID, "#" + B.BROWN, "#" + B.BLUE_SOFT)


def _root_dir():
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _open_path(path):
    try:
        if sys.platform.startswith("win"):
            os.startfile(path)  # noqa: S606
        elif sys.platform == "darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])
    except Exception:
        try:
            webbrowser.open("file://" + os.path.abspath(path))
        except Exception:
            pass


def _money(v):
    return f"{v:,.2f}" if isinstance(v, (int, float)) else str(v)


class _Bar:
    """
    A progress bar drawn from two frames.

    The themed widget paints itself in the platform's own colours, which are not
    the brand's. Keeping the ["value"] interface means nothing else had to change.
    """

    def __init__(self, track, fill, width, idle_bg, busy_bg):
        self._track = track
        self._fill = fill
        self._width = width
        self._idle = idle_bg
        self._busy = busy_bg
        self._track.configure(bg=idle_bg)

    def __setitem__(self, key, value):
        if key != "value":
            return
        try:
            pct = max(0.0, min(100.0, float(value)))
        except (TypeError, ValueError):
            return
        # An empty track sitting in the strip is just noise, so it only shows
        # itself while there is something to report.
        self._track.configure(bg=self._busy if pct else self._idle)
        self._fill.place_configure(width=int(self._width * pct / 100.0))

    def __getitem__(self, key):
        return None


class App:
    def __init__(self, root: tk.Tk, cfg: dict):
        self.root = root
        self.cfg = cfg
        self.queue: queue.Queue = queue.Queue()
        self.worker: threading.Thread | None = None
        self.result = None

        root.title(APP_TITLE)
        root.configure(bg=BG)
        root.minsize(920, 700)
        try:
            root.geometry("980x760")
        except Exception:
            pass

        self.v_books = tk.StringVar()
        self.v_2b = tk.StringVar()
        self.v_master = tk.StringVar()
        self.v_out = tk.StringVar(value=os.path.join(_root_dir(), "Output"))
        self.v_first = tk.BooleanVar(value=False)
        self.v_tol = tk.StringVar(value=str(cfg.get("tolerance_rupees", 1.0)))
        self.v_prob = tk.BooleanVar(value=bool(cfg.get("enable_probable_match", True)))
        self.v_impg = tk.StringVar(value=str(cfg.get("import_of_goods_source", "2B")).upper())
        self.v_164 = tk.BooleanVar(value=bool(cfg.get("apply_section_16_4_time_bar", True)))
        self.v_month = tk.StringVar(value=AUTO_MONTH)
        self.v_year = tk.StringVar(value="")
        op = cfg.get("itc_ledger_opening") or {}
        self.v_op_igst = tk.StringVar(value=str(op.get("igst", 0) or 0))
        self.v_op_cgst = tk.StringVar(value=str(op.get("cgst", 0) or 0))
        self.v_op_sgst = tk.StringVar(value=str(op.get("sgst", 0) or 0))
        self.v_ledger = tk.StringVar()
        self.v_gl = tk.StringVar()
        self.v_a_books = tk.StringVar()
        self.v_a_master = tk.StringVar()
        self.v_a_out = tk.StringVar(value=os.path.join(_root_dir(), "Output"))
        self.v_a_2b_note = tk.StringVar(value="No files chosen")
        self.a_2b_files = []
        self.v_status = tk.StringVar(value="Choose your three files, then press Run.")

        self._styles()
        self._build()
        self._load_state()
        root.protocol("WM_DELETE_WINDOW", self._on_close)
        root.after(120, self._drain)

    # ------------------------------------------------------------------ ui --
    def _styles(self):
        s = ttk.Style()
        try:
            s.theme_use("vista" if sys.platform.startswith("win") else "clam")
        except Exception:
            pass
        # Fira Sans where it is installed, then the fallbacks the guide names.
        self.font_h1 = B.ui_font(self.root, 17, "bold")
        self.font_h2 = B.ui_font(self.root, 10, "bold")
        self.font_lg = B.ui_font(self.root, 15, "bold")
        self.font = B.ui_font(self.root, 10)
        self.font_sm = B.ui_font(self.root, 9)
        self.font_mono = ("Consolas" if sys.platform.startswith("win") else "monospace", 9)
        self.font_num = B.ui_font(self.root, 10)
        base = self.font[0]
        s.configure("TFrame", background=BG)
        s.configure("Card.TFrame", background=CARD, relief="solid", borderwidth=1)
        # Inner frames must not repeat the card's border, or every row draws a box.
        s.configure("Inner.TFrame", background=CARD, relief="flat", borderwidth=0)
        s.configure("TLabel", background=BG, font=self.font, foreground=TEXT)
        s.configure("Card.TLabel", background=CARD, font=self.font, foreground=TEXT)
        s.configure("H2.TLabel", background=CARD, font=self.font_h2, foreground=INK)
        s.configure("Step.TLabel", background=ACCENT, foreground="white",
                    font=self.font_h2, anchor="center", padding=(0, 1))
        s.configure("Muted.TLabel", background=CARD, font=self.font_sm, foreground=MUTED)
        s.configure("Faint.TLabel", background=CARD, font=self.font_sm, foreground=FAINT)
        s.configure("TCheckbutton", background=CARD, font=self.font, foreground=TEXT)
        s.configure("TRadiobutton", background=CARD, font=self.font, foreground=TEXT)
        s.configure("TButton", font=self.font, padding=(10, 4))
        s.configure("Run.TButton", font=(base, 11, "bold"), padding=(16, 6))
        s.configure("TEntry", fieldbackground="#FCFDFE")
        s.configure("TNotebook", background=BG, borderwidth=0)
        s.configure("TNotebook.Tab", font=self.font_h2, padding=(18, 8))
        s.map("TNotebook.Tab", foreground=[("selected", INK)])
        s.configure("Treeview", font=self.font, rowheight=26, fieldbackground=CARD,
                    background=CARD, foreground=TEXT, borderwidth=0)
        s.configure("Treeview.Heading", font=self.font_h2, foreground=INK,
                    background="#EAEEF5", relief="flat", padding=(6, 5))
        s.map("Treeview.Heading", background=[("active", "#E1E7F0")])

    def _card(self, parent, title, subtitle=None, accent=None):
        shell = tk.Frame(parent, bg=LINE, highlightthickness=0)
        shell.pack(fill="x", padx=16, pady=(0, 12))
        spine = tk.Frame(shell, bg=accent or ACCENT, width=4)
        spine.pack(side="left", fill="y")
        outer = ttk.Frame(shell, style="Card.TFrame", padding=(16, 12, 16, 14))
        outer.pack(side="left", fill="both", expand=True)
        head = ttk.Frame(outer, style="Inner.TFrame")
        head.pack(fill="x")
        ttk.Label(head, text=title, style="H2.TLabel").pack(side="left")
        if subtitle:
            ttk.Label(outer, text=subtitle, style="Muted.TLabel",
                      wraplength=820, justify="left").pack(anchor="w", pady=(2, 6))
        else:
            ttk.Frame(outer, style="Inner.TFrame", height=5).pack()
        return outer

    def _tile(self, parent, caption, colour):
        """A headline figure. Numbers are what the reader came for."""
        box = tk.Frame(parent, bg=CARD, highlightbackground=LINE, highlightthickness=1)
        box.pack(side="left", fill="both", expand=True, padx=(0, 10))
        tk.Frame(box, bg=colour, height=3).pack(fill="x")
        tk.Label(box, text=caption, bg=CARD, fg=MUTED, font=self.font_sm,
                 anchor="w").pack(fill="x", padx=12, pady=(8, 0))
        val = tk.Label(box, text="-", bg=CARD, fg=colour,
                       font=(self.font_h1[0], 15, "bold"), anchor="w")
        val.pack(fill="x", padx=12, pady=(2, 2))
        sub = tk.Label(box, text="", bg=CARD, fg=FAINT, font=self.font_sm, anchor="w")
        sub.pack(fill="x", padx=12, pady=(0, 10))
        return val, sub

    def _scrollable(self, tab):
        """A scrolling page, so the window still works on a small laptop screen."""
        canvas = tk.Canvas(tab, bg=BG, highlightthickness=0, borderwidth=0)
        vs = ttk.Scrollbar(tab, orient="vertical", command=canvas.yview)
        inner = ttk.Frame(canvas)
        win = canvas.create_window((0, 0), window=inner, anchor="nw")
        inner.bind("<Configure>",
                   lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(win, width=e.width))
        canvas.configure(yscrollcommand=vs.set)
        vs.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        self._canvas, self._inner = canvas, inner

        def wheel(event):
            step = -1 if (event.delta > 0 or event.num == 4) else 1
            canvas.yview_scroll(step, "units")
        for seq in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
            canvas.bind_all(seq, lambda e: wheel(e)
                            if getattr(self, "current_tab", "inputs") == "inputs"
                            else None)
        return inner

    def _place_header(self, _e=None):
        w = max(self.band.winfo_width(), 1)
        self.band.coords(self._title, w - 30, 38)
        self.band.coords(self._subtitle, w - 30, 64)
        rect, text = self._chip
        if not self.band.itemcget(text, "text"):
            self.band.coords(rect, 0, 0, 0, 0)
            self.band.coords(text, -200, -200)
            return
        self.band.coords(text, w - 30, 88)
        box = self.band.bbox(text)
        if box:
            self.band.coords(rect, box[0] - 10, box[1] - 4, box[2] + 10, box[3] + 4)
        self.band.tag_raise(text)

    def _set_period_chip(self, label):
        self.band.itemconfigure(self._chip[1], text=label)
        self._place_header()

    def _build_strip(self):
        """
        The tabs and the two actions in one band.

        Running the reconciliation is the point of the window, so the button for
        it should not be somewhere down the page behind a scroll.
        """
        strip = tk.Frame(self.root, bg=BG)
        strip.pack(fill="x")
        tk.Frame(strip, bg=LINE, height=1).pack(side="bottom", fill="x")

        left = tk.Frame(strip, bg=BG)
        left.pack(side="left", padx=(16, 0))
        self._tabs = {}
        for key, label in (("inputs", "Monthly"), ("results", "Results"),
                           ("annual", "Annual")):
            holder = tk.Frame(left, bg=BG)
            holder.pack(side="left")
            btn = tk.Label(holder, text=label, bg=BG, fg=MUTED, font=self.font_h2,
                           padx=22, pady=11, cursor="hand2")
            btn.pack()
            rule = tk.Frame(holder, bg=BG, height=3)
            rule.pack(fill="x")
            btn.bind("<Button-1>", lambda _e, k=key: self._show(k))
            self._tabs[key] = (btn, rule)

        right = tk.Frame(strip, bg=BG)
        right.pack(side="right", padx=(0, 16), pady=8)
        self.btn_clear = tk.Button(right, text="Clear / Reset", command=self._clear,
                                   bg=CARD, fg=INK, font=self.font, relief="solid",
                                   borderwidth=1, padx=14, pady=5, cursor="hand2",
                                   activebackground="#" + B.BLUE_TINT,
                                   highlightthickness=0)
        self.btn_clear.pack(side="right")
        self.btn_run = tk.Button(right, text="Run reconciliation", command=self._run,
                                 bg=INK, fg="white", font=self.font_h2, relief="flat",
                                 padx=20, pady=6, cursor="hand2",
                                 activebackground=INK_MID, activeforeground="white",
                                 disabledforeground="#B9B7D2", highlightthickness=0)
        self.btn_run.pack(side="right", padx=(0, 10))

        track = tk.Frame(right, bg=BG, height=6, width=200)
        track.pack(side="right", padx=(0, 14), pady=(9, 0))
        track.pack_propagate(False)
        fill = tk.Frame(track, bg=INK)
        fill.place(x=0, y=0, relheight=1, width=0)
        self.pbar = _Bar(track, fill, 200, BG, "#" + B.BLUE_TINT_2)

    def _show(self, key):
        for k, page in self.pages.items():
            page.pack_forget()
        self.pages[key].pack(fill="both", expand=True)
        self.current_tab = key
        # One primary button, doing whatever the open tab is about.
        if hasattr(self, "btn_run"):
            if key == "annual":
                self.btn_run.configure(text="Run annual reconciliation",
                                       command=self._run_annual)
            else:
                self.btn_run.configure(text="Run reconciliation", command=self._run)
            self._refresh_state()
        for k, (btn, rule) in self._tabs.items():
            on = k == key
            btn.configure(fg=INK if on else MUTED, bg=CARD if on else BG)
            rule.configure(bg=INK if on else BG)

    def _build(self):
        # A flat band in the primary blue, with the logo standing alone in its
        # own clear space. The guide asks for clean margins and no loud
        # graphics, so there is no decoration on the band at all.
        self.band = tk.Canvas(self.root, height=104, highlightthickness=0,
                              borderwidth=0, bg=INK)
        self.band.pack(fill="x")
        self._logo = None
        path = B.asset("exi_logo_white_74")
        if path:
            try:
                self._logo = tk.PhotoImage(file=path)
                self.band.create_image(30, 52, image=self._logo, anchor="w")
            except Exception:
                self._logo = None
        if self._logo is None:
            self.band.create_text(30, 52, text="EXACTITUDE INTERNATIONAL", anchor="w",
                                  fill="white", font=self.font_h1)

        self._title = self.band.create_text(0, 38, text="GST Reconciliation", anchor="e",
                                            fill="white", font=self.font_h1)
        self._subtitle = self.band.create_text(
            0, 64, text="GSTR-2B against the books, month by month", anchor="e",
            fill="#B9B7D2", font=self.font_sm)
        self._chip = (self.band.create_rectangle(0, 0, 0, 0, outline="", fill=INK_MID),
                      self.band.create_text(0, 0, text="", anchor="e", fill="white",
                                            font=self.font_h2))
        self.band.bind("<Configure>", self._place_header)
        tk.Frame(self.root, bg=BROWN, height=2).pack(fill="x")

        self._build_strip()

        body = ttk.Frame(self.root)
        body.pack(fill="both", expand=True)
        self.tab_run = ttk.Frame(body)
        self.tab_res = ttk.Frame(body)
        self.tab_ann = ttk.Frame(body)
        self.pages = {"inputs": self.tab_run, "results": self.tab_res,
                      "annual": self.tab_ann}
        self._build_run(self.tab_run)
        self._build_result(self.tab_res)
        self._build_annual(self.tab_ann)
        self._show("inputs")

        bar = tk.Frame(self.root, bg=BG)
        bar.pack(fill="x", side="bottom")
        tk.Frame(bar, bg=LINE, height=1).pack(fill="x")
        tk.Label(bar, textvariable=self.v_status, bg=BG, fg=MUTED,
                 font=self.font_sm, anchor="w").pack(fill="x", padx=18, pady=6)

    def _row(self, parent, n, label, var, hint, kind="file",
             required=False, step=None):
        """
        One input: what it is, and a button to go and get it.

        An empty text box invites typing a path, which nobody does, and reads as
        an unfinished form. A button with the chosen file named beside it says
        what has been picked and what has not at a glance.
        """
        f = ttk.Frame(parent, style="Inner.TFrame")
        f.pack(fill="x", pady=(8, 0))

        if n:
            badge = ttk.Label(f, text=f"{n}", style="Step.TLabel", width=3)
            badge.pack(side="left", anchor="n", padx=(0, 10), pady=(1, 0))
        else:
            ttk.Frame(f, style="Inner.TFrame", width=34).pack(side="left")

        box = ttk.Frame(f, style="Inner.TFrame")
        box.pack(side="left", fill="x", expand=True)

        cap = ttk.Frame(box, style="Inner.TFrame")
        cap.pack(fill="x")
        ttk.Label(cap, text=label, style="Card.TLabel").pack(side="left")
        # Required or optional is said in words, not signalled by colour alone.
        tag = tk.Label(cap, text="Required" if required else "Optional",
                       bg="#" + (B.BLUE_TINT if required else B.GREY_TINT),
                       fg=INK if required else MUTED, font=self.font_sm,
                       padx=7, pady=1)
        tag.pack(side="left", padx=(10, 0))
        ttk.Label(cap, text="   " + hint, style="Muted.TLabel",
                  wraplength=620, justify="left").pack(side="left")

        pick = ttk.Frame(box, style="Inner.TFrame")
        pick.pack(fill="x", pady=(4, 0))

        word = "folder" if kind == "dir" else "file"
        btn = tk.Button(pick, text=f"Choose {word}...", bg=CARD, fg=INK,
                        font=self.font, relief="solid", borderwidth=1,
                        padx=14, pady=4, cursor="hand2", highlightthickness=0,
                        activebackground="#" + B.BLUE_TINT,
                        command=(lambda: self._pick_dir(var)) if kind == "dir"
                        else (lambda: self._pick_file(var, label)))
        btn.pack(side="left")

        shown = tk.Label(pick, text="", bg=CARD, font=self.font_h2, anchor="w")
        shown.pack(side="left", padx=(12, 0))
        where_lbl = tk.Label(pick, text="", bg=CARD, fg=FAINT, font=self.font_sm,
                             anchor="w")
        where_lbl.pack(side="left", padx=(8, 0))

        state = tk.Label(pick, text="", bg=CARD, fg=INK, font=self.font_sm,
                         padx=8, pady=1)
        state.pack(side="left", padx=(12, 0))

        clear = tk.Button(pick, text="Clear", bg=CARD, fg=MUTED, font=self.font_sm,
                          relief="flat", borderwidth=0, cursor="hand2",
                          highlightthickness=0, activebackground=CARD,
                          command=lambda: var.set(""))

        def refresh(*_a):
            path = (var.get() or "").strip()
            if not path:
                shown.configure(text="No " + word + " chosen", fg=FAINT,
                                font=self.font)
                where_lbl.configure(text="")
                clear.pack_forget()
                state.configure(text="")
                self._mark(f, "empty" if required else "idle")
            else:
                name = os.path.basename(path.rstrip("/" + chr(92))) or path
                where = os.path.dirname(path)
                if len(where) > 44:
                    where = where[:18] + " ... " + where[-22:]
                shown.configure(text=name, fg=INK, font=self.font_h2)
                where_lbl.configure(text=where)
                clear.pack(side="left", padx=(10, 0))
                ok = (os.path.isdir(path) if kind == "dir" else os.path.isfile(path))
                if not ok:
                    state.configure(text="Not found", bg="#" + B.RED_TINT, fg=BAD)
                    self._mark(f, "bad")
                elif kind != "dir" and not path.lower().endswith(
                        (".xlsx", ".xlsm", ".xlsb")):
                    state.configure(text="Not an Excel file", bg="#" + B.RED_TINT,
                                    fg=BAD)
                    self._mark(f, "bad")
                else:
                    state.configure(text="Ready", bg="#" + B.BLUE_TINT, fg=INK)
                    self._mark(f, "ok")
            if getattr(self, "_wired", False):
                self._refresh_state()

        f._marker = tk.Frame(f, bg=CARD, width=3)
        f._marker.pack(side="right", fill="y", padx=(8, 0))
        self._inputs.append((f, var, required, kind, step))
        var.trace_add("write", refresh)
        refresh()
        return f, shown, btn

    def _mark(self, row, kind):
        """A thin edge marker beside a row: state without relying on colour."""
        colour = {"ok": INK, "bad": BAD, "empty": BROWN}.get(kind, CARD)
        try:
            row._marker.configure(bg=colour)
        except Exception:
            pass

    def _build_stepper(self, parent):
        """
        Where the reader is in the job, and what is left.

        Four stops, the last of which is the run itself, so the page reads as a
        sequence rather than four disconnected boxes.
        """
        wrapf = tk.Frame(parent, bg=CARD, highlightbackground=LINE,
                         highlightthickness=1)
        wrapf.pack(fill="x", padx=16, pady=(12, 12))
        inner = tk.Frame(wrapf, bg=CARD)
        inner.pack(fill="x", padx=18, pady=14)

        self._steps = {}
        stops = (("files", "1", "Files", "Three workbooks"),
                 ("period", "2", "Filing period", "Cross-check"),
                 ("ledgers", "3", "Ledgers", "Optional"),
                 ("run", "4", "Review and run", "Output folder"))
        for i, (key, num, title, note) in enumerate(stops):
            cell = tk.Frame(inner, bg=CARD, cursor="hand2")
            cell.pack(side="left", fill="x", expand=True)
            top = tk.Frame(cell, bg=CARD)
            top.pack(anchor="w")
            badge = tk.Label(top, text=num, bg=CARD, fg=MUTED, font=self.font_h2,
                             width=3, pady=3, highlightbackground=LINE,
                             highlightthickness=1)
            badge.pack(side="left")
            name = tk.Label(top, text=title, bg=CARD, fg=MUTED, font=self.font_h2)
            name.pack(side="left", padx=(9, 0))
            sub = tk.Label(cell, bg=CARD, fg=FAINT, font=self.font_sm, text=note,
                           anchor="w")
            sub.pack(anchor="w", padx=(2, 0), pady=(3, 0))
            for w in (cell, top, badge, name, sub):
                w.bind("<Button-1>", lambda _e, k=key: self._goto(k))
            if i < len(stops) - 1:
                tk.Frame(inner, bg=LINE, height=1, width=44).pack(
                    side="left", padx=10, pady=(0, 16))
            self._steps[key] = (badge, name, sub)

    def _set_step(self, key, done, current, note):
        badge, name, sub = self._steps[key]
        if done:
            badge.configure(bg=INK, fg="white", highlightbackground=INK)
            name.configure(fg=INK)
        elif current:
            badge.configure(bg="#" + B.BLUE_TINT, fg=INK, highlightbackground=INK)
            name.configure(fg=INK)
        else:
            badge.configure(bg=CARD, fg=MUTED, highlightbackground=LINE)
            name.configure(fg=MUTED)
        sub.configure(text=note, fg=INK if done else FAINT)

    def _goto(self, key):
        target = getattr(self, "_anchor_" + key, None)
        if target is None or not hasattr(self, "_canvas"):
            return
        self._show("inputs")
        self.root.update_idletasks()
        total = max(self._inner.winfo_height(), 1)
        self._canvas.yview_moveto(max(0.0, (target.winfo_y() - 12) / total))

    def _build_review(self, parent):
        """What is set, what is missing, and the run button again at the end."""
        shell = tk.Frame(parent, bg=LINE)
        shell.pack(fill="x", padx=16, pady=(0, 16))
        tk.Frame(shell, bg=INK, width=4).pack(side="left", fill="y")
        card = tk.Frame(shell, bg=CARD)
        card.pack(side="left", fill="both", expand=True)
        pad = tk.Frame(card, bg=CARD)
        pad.pack(fill="x", padx=16, pady=14)

        self.lbl_ready = tk.Label(pad, text="", bg=CARD, fg=INK, font=self.font_lg,
                                  anchor="w")
        self.lbl_ready.pack(anchor="w")
        self.lbl_ready_note = tk.Label(pad, text="", bg=CARD, fg=MUTED,
                                       font=self.font_sm, anchor="w", justify="left")
        self.lbl_ready_note.pack(anchor="w", pady=(3, 10))

        self.review_rows = tk.Frame(pad, bg=CARD)
        self.review_rows.pack(fill="x")

        self.btn_run2 = tk.Button(pad, text="Run reconciliation", command=self._run,
                                  bg=INK, fg="white", font=self.font_h2,
                                  relief="flat", padx=22, pady=8, cursor="hand2",
                                  activebackground=INK_MID, activeforeground="white",
                                  disabledforeground="#B9B7D2", highlightthickness=0)
        self.btn_run2.pack(anchor="w", pady=(14, 0))

    def _refresh_state(self):
        """
        Recompute what is done and what is missing, and say so in one place.

        Called whenever any input changes, so the stepper, the review panel and
        the run buttons never disagree with each other.
        """
        if not getattr(self, "_wired", False):
            return

        def good(var, kind="file"):
            p = (var.get() or "").strip()
            if not p:
                return False
            return os.path.isdir(p) if kind == "dir" else os.path.isfile(p)

        books, twob = good(self.v_books), good(self.v_2b)
        master = good(self.v_master) or bool(self.v_first.get())
        out_ok = good(self.v_out, "dir")
        files_done = books and twob and master
        n_files = sum((books, twob, bool(good(self.v_master))))

        month = self.v_month.get().strip()
        named = month not in ("", AUTO_MONTH)
        led_files = sum((good(self.v_ledger), good(self.v_gl)))
        typed = any((self.v_op_igst.get() or "0").strip() not in ("", "0", "0.0")
                    for _ in (0,)) or any(
            (v.get() or "0").strip() not in ("", "0", "0.0")
            for v in (self.v_op_igst, self.v_op_cgst, self.v_op_sgst))

        self._set_step("files", files_done, not files_done,
                       "All three chosen" if files_done else f"{n_files} of 3 chosen")
        self.lbl_period_note.configure(
            text=("Cross-check on. The run stops if the export is another month."
                  if named else "The month will be taken from the Tally export."))
        self._set_step("period", named, files_done and not named,
                       f"{month} {self.v_year.get()}" if named else "Read from the export")
        self._set_step("ledgers", led_files > 0 or typed, False,
                       (f"{led_files} file(s)" if led_files else "Opening balance typed")
                       if (led_files or typed) else "Nothing given, optional")
        self._set_step("run", files_done and out_ok, files_done and out_ok,
                       "Ready" if (files_done and out_ok) else "Waiting on the files")

        missing = []
        if not books:
            missing.append("the books export")
        if not twob:
            missing.append("the GSTR-2B workbook")
        if not master:
            missing.append("the pending master, or tick the first month box")
        if not out_ok:
            missing.append("a folder to save into")

        for w in self.review_rows.winfo_children():
            w.destroy()
        items = [("Books", self.v_books, True), ("GSTR-2B", self.v_2b, True),
                 ("Pending master", self.v_master, not self.v_first.get()),
                 ("Filing period", None, False), ("Ledgers", None, False),
                 ("Output folder", self.v_out, True)]
        for label, var, need in items:
            line = tk.Frame(self.review_rows, bg=CARD)
            line.pack(fill="x", pady=1)
            tk.Label(line, text=label, bg=CARD, fg=MUTED, font=self.font_sm,
                     width=18, anchor="w").pack(side="left")
            if label == "Filing period":
                txt = (f"{month} {self.v_year.get()}, cross-check on" if named
                       else "Read from the Tally export")
                fg = INK
            elif label == "Ledgers":
                bits = []
                if typed:
                    bits.append("opening balance typed")
                if good(self.v_ledger):
                    bits.append("credit ledger")
                if good(self.v_gl):
                    bits.append("GST ledgers")
                txt = ", ".join(bits) if bits else "none given, optional"
                fg = INK if bits else FAINT
            else:
                p = (var.get() or "").strip()
                if not p and label == "Pending master" and self.v_first.get():
                    txt, fg = "First month, none needed", INK
                elif not p:
                    txt, fg = ("Still needed" if need else "not given"), \
                        (BAD if need else FAINT)
                else:
                    txt = os.path.basename(p.rstrip("/" + chr(92))) or p
                    fg = INK if good(var, "dir" if label == "Output folder" else "file") \
                        else BAD
            tk.Label(line, text=txt, bg=CARD, fg=fg, font=self.font_sm,
                     anchor="w").pack(side="left")

        ready = files_done and out_ok
        if ready:
            self.lbl_ready.configure(text="Ready to run", fg=INK)
            self.lbl_ready_note.configure(
                text="Everything needed is in place. The two workbooks are written to "
                     "the output folder and the window switches to Results.")
        else:
            self.lbl_ready.configure(text="Not ready yet", fg=BROWN)
            self.lbl_ready_note.configure(text="Still needed: " + "; ".join(missing) + ".")
        a_ready, a_missing = self._annual_ready()
        if hasattr(self, "lbl_a_ready"):
            self.lbl_a_ready.configure(
                text="Ready to run the year" if a_ready else "Not ready yet",
                fg=INK if a_ready else BROWN)
            self.lbl_a_note.configure(
                text=("The whole year is matched in one pass and one workbook is "
                      "written." if a_ready
                      else "Still needed: " + "; ".join(a_missing) + "."))
            self.btn_a_run.configure(state="normal" if a_ready else "disabled",
                                     bg=INK if a_ready else "#" + B.BLUE_TINT_2)

        on_annual = getattr(self, "current_tab", "inputs") == "annual"
        want = a_ready if on_annual else ready
        for b in (self.btn_run,):
            b.configure(state="normal" if want else "disabled",
                        bg=INK if want else "#" + B.BLUE_TINT_2)
        self.btn_run2.configure(state="normal" if ready else "disabled",
                                bg=INK if ready else "#" + B.BLUE_TINT_2)

    def _annual_done(self, status):
        self.pbar["value"] = 0
        self.btn_a_run.configure(text="Run annual reconciliation")
        self.v_status.set(status)
        self._refresh_state()

    def _pick_2b_files(self):
        paths = filedialog.askopenfilenames(
            title="Choose every GSTR-2B download for the year",
            filetypes=[("Excel workbooks", "*.xlsx *.xlsm *.xlsb"), ("All files", "*.*")],
            initialdir=self._last_dir(self.v_a_books))
        if paths:
            self.a_2b_files = [os.path.normpath(p) for p in paths]
            self._show_2b()
            self._refresh_state()

    def _show_2b(self):
        n = len(self.a_2b_files)
        if not n:
            self.v_a_2b_note.set("No files chosen")
        else:
            names = ", ".join(os.path.basename(p) for p in self.a_2b_files[:3])
            if n > 3:
                names += f" and {n - 3} more"
            self.v_a_2b_note.set(f"{n} file(s):  {names}")
        for w in self.a_2b_list.winfo_children():
            w.destroy()
        for p in self.a_2b_files:
            line = tk.Frame(self.a_2b_list, bg=CARD)
            line.pack(fill="x", pady=1)
            tk.Label(line, text=os.path.basename(p), bg=CARD, fg=INK,
                     font=self.font_sm, anchor="w").pack(side="left")
            ok = os.path.isfile(p)
            tk.Label(line, text="Ready" if ok else "Not found", bg="#" +
                     (B.BLUE_TINT if ok else B.RED_TINT), fg=INK if ok else BAD,
                     font=self.font_sm, padx=7).pack(side="left", padx=(10, 0))

    def _build_annual(self, tab):
        wrap = self._scrollable_annual(tab)

        intro = self._card(
            wrap, "Annual reconciliation",
            "Kept apart from the monthly run. Every book voucher for the year is "
            "matched against every GSTR-2B row for the year, so an invoice booked in "
            "one month and reported by the supplier in another counts as matched. "
            "That is what makes this different from adding up twelve monthly runs.",
            accent=STEP_COLOURS[0])
        tk.Label(intro, text="Nothing here touches the monthly workbooks or the "
                             "pending master. A separate file is written.",
                 bg=CARD, fg=MUTED, font=self.font_sm, anchor="w").pack(anchor="w")

        c1 = self._card(wrap, "1.  Books for the whole year",
                        "One GSTR-3B working exported from Tally covering the full "
                        "financial year.", accent=STEP_COLOURS[0])
        self._row(c1, "1", "Year books export", self.v_a_books,
                  "The same registers as the monthly export, twelve months of rows.",
                  required=True)

        c2 = self._card(wrap, "2.  GSTR-2B, one download per month",
                        "The portal has no annual GSTR-2B, so give it each month's "
                        "download. Choose them all at once.", accent=STEP_COLOURS[1])
        pick = tk.Frame(c2, bg=CARD)
        pick.pack(fill="x", pady=(2, 0))
        tk.Button(pick, text="Choose files...", bg=CARD, fg=INK, font=self.font,
                  relief="solid", borderwidth=1, padx=14, pady=4, cursor="hand2",
                  highlightthickness=0, activebackground="#" + B.BLUE_TINT,
                  command=self._pick_2b_files).pack(side="left")
        tk.Label(pick, textvariable=self.v_a_2b_note, bg=CARD, fg=MUTED,
                 font=self.font_sm).pack(side="left", padx=(12, 0))
        tk.Button(pick, text="Clear", bg=CARD, fg=MUTED, font=self.font_sm,
                  relief="flat", borderwidth=0, cursor="hand2", highlightthickness=0,
                  activebackground=CARD,
                  command=lambda: (setattr(self, "a_2b_files", []), self._show_2b(),
                                   self._refresh_state())).pack(side="left", padx=(10, 0))
        self.a_2b_list = tk.Frame(c2, bg=CARD)
        self.a_2b_list.pack(fill="x", pady=(8, 0))

        c3 = self._card(wrap, "3.  Opening pending master",
                        "Optional. Items still unmatched at the start of the year, "
                        "carried from an earlier one.", accent=STEP_COLOURS[2])
        self._row(c3, "", "Opening pending master", self.v_a_master,
                  "Leave blank if the year starts clean.")

        c4 = self._card(wrap, "4.  Where to save",
                        "One workbook is written: the annual reconciliation.",
                        accent=STEP_COLOURS[3])
        self._row(c4, "", "Output folder", self.v_a_out, "", kind="dir",
                  required=True)

        rev = tk.Frame(wrap, bg=LINE)
        rev.pack(fill="x", padx=16, pady=(0, 16))
        tk.Frame(rev, bg=INK, width=4).pack(side="left", fill="y")
        card = tk.Frame(rev, bg=CARD)
        card.pack(side="left", fill="both", expand=True)
        pad = tk.Frame(card, bg=CARD)
        pad.pack(fill="x", padx=16, pady=14)
        self.lbl_a_ready = tk.Label(pad, text="", bg=CARD, fg=INK, font=self.font_lg,
                                    anchor="w")
        self.lbl_a_ready.pack(anchor="w")
        self.lbl_a_note = tk.Label(pad, text="", bg=CARD, fg=MUTED, font=self.font_sm,
                                   anchor="w", justify="left")
        self.lbl_a_note.pack(anchor="w", pady=(3, 10))
        tk.Label(pad, text="The annual workbook opens with three sheets of its own: the "
                           "year month by month, the figures set against GSTR-9, and the "
                           "input tax credit reconciliation in the shape GSTR-9C uses. "
                           "The usual working paper follows behind them.",
                 bg=CARD, fg=MUTED, font=self.font_sm, anchor="w", justify="left",
                 wraplength=820).pack(anchor="w", pady=(0, 10))
        self.btn_a_run = tk.Button(pad, text="Run annual reconciliation",
                                   command=self._run_annual, bg=INK, fg="white",
                                   font=self.font_h2, relief="flat", padx=22, pady=8,
                                   cursor="hand2", activebackground=INK_MID,
                                   activeforeground="white",
                                   disabledforeground="#B9B7D2", highlightthickness=0)
        self.btn_a_run.pack(anchor="w")

        lf = ttk.Frame(wrap, style="Card.TFrame", padding=(12, 8, 12, 12))
        lf.pack(fill="x", padx=16, pady=(0, 14))
        ttk.Label(lf, text="Progress", style="H2.TLabel").pack(anchor="w")
        box = ttk.Frame(lf, style="Inner.TFrame")
        box.pack(fill="x", pady=(6, 0))
        self.a_log = tk.Text(box, height=9, font=self.font_mono, wrap="word",
                             bg="#FBFCFE", relief="solid", borderwidth=1, fg="#22303F")
        sb = ttk.Scrollbar(box, command=self.a_log.yview)
        self.a_log.configure(yscrollcommand=sb.set, state="disabled")
        sb.pack(side="right", fill="y")
        self.a_log.pack(side="left", fill="x", expand=True)

        for v in (self.v_a_books, self.v_a_master, self.v_a_out):
            v.trace_add("write", lambda *_a: self._refresh_state())
        self._show_2b()

    def _scrollable_annual(self, tab):
        canvas = tk.Canvas(tab, bg=BG, highlightthickness=0, borderwidth=0)
        vs = ttk.Scrollbar(tab, orient="vertical", command=canvas.yview)
        inner = ttk.Frame(canvas)
        win = canvas.create_window((0, 0), window=inner, anchor="nw")
        inner.bind("<Configure>",
                   lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(win, width=e.width))
        canvas.configure(yscrollcommand=vs.set)
        vs.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        return inner

    def _annual_ready(self):
        books = os.path.isfile((self.v_a_books.get() or "").strip())
        twob = bool(self.a_2b_files) and all(os.path.isfile(p) for p in self.a_2b_files)
        out = os.path.isdir((self.v_a_out.get() or "").strip())
        missing = []
        if not books:
            missing.append("the year books export")
        if not twob:
            missing.append("at least one GSTR-2B download")
        if not out:
            missing.append("a folder to save into")
        return (books and twob and out), missing

    def _run_annual(self):
        if self.worker and self.worker.is_alive():
            return
        ready, missing = self._annual_ready()
        if not ready:
            messagebox.showerror(APP_TITLE, "Please fix this first:" + chr(10) + chr(10)
                                 + "Still needed: " + "; ".join(missing) + ".")
            return
        books = self.v_a_books.get().strip()
        files = list(self.a_2b_files)
        master = self.v_a_master.get().strip() or None
        out = self.v_a_out.get().strip()
        cfg = self._collect_cfg()

        self._set_log("", annual=True)
        self.pbar["value"] = 0
        for b in (self.btn_run, self.btn_a_run):
            b.configure(state="disabled")
        self.btn_a_run.configure(text="Running...")
        self.v_status.set("Working on the year...")

        def work():
            try:
                def log(msg, pct=None):
                    self.queue.put(("alog", msg, pct))
                R = pipeline.execute_annual(books, files, master, out, cfg, log)
                self.queue.put(("adone", R, None))
            except pipeline.InputError as exc:
                self.queue.put(("aerr", str(exc), None))
            except Exception:
                self.queue.put(("acrash", traceback.format_exc(), None))

        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def _build_run(self, tab):
        wrap = self._scrollable(tab)
        self._inputs = []
        self._build_stepper(wrap)

        c = self._card(wrap, "1.  The three workbooks",
                       "Names do not matter; each file is recognised by the sheets inside "
                       "it.", accent=STEP_COLOURS[0])
        self._anchor_files = c.master
        self._row(c, "1", "Books  -  GSTR-3B working exported from Tally",
                  self.v_books, "All Other ITC, Ineligible ITC and RCM registers.",
                  required=True, step="files")
        self._row(c, "2", "GSTR-2B  -  downloaded from the GST portal",
                  self.v_2b, "The workbook with the B2B and ITC Available sheets.",
                  required=True, step="files")
        f3, self.ent_master, self.btn_master = self._row(
            c, "3", "Pending master  -  produced by last month's run",
            self.v_master, "Carries forward items that have not matched yet.",
            required=True, step="files")

        first = tk.Frame(c, bg="#" + B.GREY_TINT, highlightbackground=LINE,
                         highlightthickness=1)
        first.pack(fill="x", pady=(10, 0))
        pad = tk.Frame(first, bg="#" + B.GREY_TINT)
        pad.pack(fill="x", padx=12, pady=9)
        cb = tk.Checkbutton(pad, variable=self.v_first, command=self._toggle_first,
                            bg="#" + B.GREY_TINT, activebackground="#" + B.GREY_TINT,
                            font=self.font, fg=TEXT, highlightthickness=0,
                            text="This is my first month, I do not have a pending "
                                 "master yet", cursor="hand2")
        cb.pack(side="left")
        tk.Label(pad, text="Ticking this starts a fresh master instead.",
                 bg="#" + B.GREY_TINT, fg=MUTED, font=self.font_sm).pack(
            side="left", padx=(10, 0))
        tk.Button(pad, text="Pick a folder containing all three...",
                  command=self._pick_folder, bg=CARD, fg=INK, font=self.font_sm,
                  relief="solid", borderwidth=1, padx=12, pady=3, cursor="hand2",
                  highlightthickness=0,
                  activebackground="#" + B.BLUE_TINT).pack(side="right")

        c15 = self._card(wrap, "2.  Filing period",
                         "The period is always read from the Tally export. Naming it here "
                         "is a cross-check: if the export is for another month the run "
                         "stops and nothing is written.", accent=STEP_COLOURS[1])
        self._anchor_period = c15.master
        m = ttk.Frame(c15, style="Inner.TFrame")
        m.pack(fill="x", pady=(2, 0))
        ttk.Label(m, text="Month", style="Card.TLabel").pack(side="left")
        cbo = ttk.Combobox(m, values=[AUTO_MONTH] + pipeline.MONTH_NAMES,
                           textvariable=self.v_month, width=22, state="readonly",
                           font=self.font)
        cbo.pack(side="left", padx=(8, 18))
        ttk.Label(m, text="Year", style="Card.TLabel").pack(side="left")
        ttk.Spinbox(m, from_=2017, to=2099, width=8, textvariable=self.v_year,
                    font=self.font).pack(side="left", padx=(8, 14))
        self.lbl_period_note = tk.Label(m, text="", bg=CARD, fg=MUTED,
                                        font=self.font_sm)
        self.lbl_period_note.pack(side="left")

        c17 = self._card(wrap, "3.  Ledgers", "All optional. Used for the set-off and "
                                              "the Ledgers Reconciliation sheet.",
                         accent=STEP_COLOURS[2])
        self._anchor_ledgers = c17.master
        ob = tk.Frame(c17, bg=CARD)
        ob.pack(fill="x", pady=(2, 2))
        tk.Label(ob, text="Opening balance in the electronic credit ledger", bg=CARD,
                 fg=TEXT, font=self.font, anchor="w").pack(anchor="w")
        tk.Label(ob, text="Brought forward from last month. Leave at nil if there is none.",
                 bg=CARD, fg=MUTED, font=self.font_sm, anchor="w").pack(anchor="w",
                                                                       pady=(1, 6))
        grid = tk.Frame(ob, bg=CARD)
        grid.pack(anchor="w")
        for col, (label, var) in enumerate((("IGST", self.v_op_igst),
                                            ("CGST", self.v_op_cgst),
                                            ("SGST/UTGST", self.v_op_sgst))):
            cell = tk.Frame(grid, bg=CARD)
            cell.grid(row=0, column=col, padx=(0, 18), sticky="w")
            tk.Label(cell, text=label, bg=CARD, fg=MUTED, font=self.font_sm,
                     anchor="w").pack(anchor="w")
            e = ttk.Entry(cell, textvariable=var, width=16, font=self.font,
                          justify="right")
            e.pack(anchor="w", pady=(2, 0))
            var.trace_add("write", lambda *_a: self._refresh_state())

        tk.Frame(c17, bg=LINE, height=1).pack(fill="x", pady=(14, 4))
        self._row(c17, "", "Electronic credit ledger", self.v_ledger,
                  "The portal download. Used in preference to the figures above.",
                  step="ledgers")
        self._row(c17, "", "GST ledgers from Tally", self.v_gl,
                  "One workbook holding the nine ledgers: inputs, deferred inputs "
                  "and payables.", step="ledgers")

        c2 = self._card(wrap, "4.  Where to save the results",
                        "Two workbooks are written here: the GST working and the "
                        "updated pending master.", accent=STEP_COLOURS[3])
        self._anchor_run = c2.master
        self._row(c2, "", "Output folder", self.v_out,
                  "Remembered for next month.", kind="dir", required=True, step="run")

        c3 = self._card(wrap, "Options", "Sensible defaults. Change only if you need to.",
                        accent=MUTED)
        g = ttk.Frame(c3, style="Inner.TFrame")
        g.pack(fill="x")
        ttk.Label(g, text="Treat a difference up to Rs", style="Card.TLabel").grid(
            row=0, column=0, sticky="w", pady=3)
        ttk.Spinbox(g, from_=0, to=1000, increment=1, width=7, textvariable=self.v_tol,
                    font=self.font).grid(row=0, column=1, sticky="w", padx=6)
        ttk.Label(g, text="per tax head as matched", style="Card.TLabel").grid(
            row=0, column=2, sticky="w")
        ttk.Label(g, text="Import of goods from", style="Card.TLabel").grid(
            row=1, column=0, sticky="w", pady=3)
        ttk.Combobox(g, values=["2B", "BOOKS"], textvariable=self.v_impg, width=8,
                     state="readonly", font=self.font).grid(row=1, column=1, sticky="w",
                                                            padx=6)
        ttk.Label(g, text="for Table 4(A)(1)", style="Card.TLabel").grid(
            row=1, column=2, sticky="w")
        ttk.Checkbutton(c3, text="Suggest probable matches where the document number "
                                 "differs (always flagged for your review)",
                        variable=self.v_prob).pack(anchor="w", pady=(6, 0))
        ttk.Checkbutton(c3, text="Do not claim credit that is time barred under "
                                 "section 16(4)", variable=self.v_164).pack(anchor="w")

        self._build_review(wrap)

        lf = ttk.Frame(wrap, style="Card.TFrame", padding=(12, 8, 12, 12))
        lf.pack(fill="x", padx=16, pady=(0, 14))
        ttk.Label(lf, text="Progress", style="H2.TLabel").pack(anchor="w")
        box = ttk.Frame(lf, style="Inner.TFrame")
        box.pack(fill="x", pady=(6, 0))
        self.log = tk.Text(box, height=8, font=self.font_mono, wrap="word",
                           bg="#FBFCFE", relief="solid", borderwidth=1, fg="#22303F")
        sb = ttk.Scrollbar(box, command=self.log.yview)
        self.log.configure(yscrollcommand=sb.set, state="disabled")
        sb.pack(side="right", fill="y")
        self.log.pack(side="left", fill="x", expand=True)
        self.log.tag_configure("warn", foreground=WARN)
        self.log.tag_configure("bad", foreground=BAD)
        self.log.tag_configure("good", foreground=GOOD)

        for v in (self.v_month, self.v_year, self.v_first):
            v.trace_add("write", lambda *_a: self._refresh_state())
        self._wired = True
        self._refresh_state()

    def _build_result(self, tab):
        wrap = ttk.Frame(tab)
        wrap.pack(fill="both", expand=True, pady=(10, 0))

        self.res_head = ttk.Frame(wrap, style="Card.TFrame", padding=(16, 12, 16, 12))
        self.res_head.pack(fill="x", padx=16, pady=(0, 12))
        self.lbl_period = ttk.Label(self.res_head, text="No run yet", style="H2.TLabel")
        self.lbl_period.pack(anchor="w")
        self.lbl_files = ttk.Label(self.res_head, text="", style="Muted.TLabel")
        self.lbl_files.pack(anchor="w", pady=(2, 8))
        bb = ttk.Frame(self.res_head, style="Inner.TFrame")
        bb.pack(fill="x")
        self.btn_open_work = ttk.Button(bb, text="Open GST working", state="disabled",
                                        command=lambda: self._open("out_work"))
        self.btn_open_work.pack(side="left", ipadx=8, ipady=3)
        self.btn_open_master = ttk.Button(bb, text="Open pending master", state="disabled",
                                          command=lambda: self._open("out_master"))
        self.btn_open_master.pack(side="left", padx=8, ipadx=8, ipady=3)
        self.btn_open_dir = ttk.Button(bb, text="Open folder", state="disabled",
                                       command=lambda: _open_path(self.v_out.get()))
        self.btn_open_dir.pack(side="left", ipadx=8, ipady=3)

        tiles = tk.Frame(wrap, bg=BG)
        tiles.pack(fill="x", padx=16, pady=(0, 12))
        self.tile_net = self._tile(tiles, "NET ITC TO CLAIM, TABLE 4(C)", GOOD)
        self.tile_match = self._tile(tiles, "MATCHED WITH GSTR-2B", ACCENT)
        self.tile_def = self._tile(tiles, "CREDIT DEFERRED", WARN)
        self.tile_cash = self._tile(tiles, "PAYABLE IN CASH AFTER SET-OFF", INK_SOFT)

        f = ttk.Frame(wrap, style="Card.TFrame", padding=(16, 12, 16, 14))
        f.pack(fill="both", expand=True, padx=16, pady=(0, 12))
        ttk.Label(f, text="Figures to report", style="H2.TLabel").pack(anchor="w")
        cols = ("particulars", "igst", "cgst", "sgst")
        self.tv = ttk.Treeview(f, columns=cols, show="headings", height=9)
        for c, t, w, a in (("particulars", "Particulars", 340, "w"),
                           ("igst", "IGST", 150, "e"), ("cgst", "CGST", 140, "e"),
                           ("sgst", "SGST/UTGST", 140, "e")):
            self.tv.heading(c, text=t)
            self.tv.column(c, width=w, anchor=a)
        self.tv.pack(fill="x", pady=(8, 12))
        self.tv.tag_configure("head", font=self.font_h2)

        ttk.Label(f, text="Needs your attention", style="H2.TLabel").pack(anchor="w")
        self.tv2 = ttk.Treeview(f, columns=("item", "count", "what"), show="headings", height=7)
        for c, t, w, a in (("item", "Item", 300, "w"), ("count", "Count", 70, "e"),
                           ("what", "What to do", 420, "w")):
            self.tv2.heading(c, text=t)
            self.tv2.column(c, width=w, anchor=a)
        self.tv2.pack(fill="both", expand=True, pady=(8, 0))
        self.tv2.tag_configure("hot", background=CHIP_BAD, foreground=BAD)
        self.tv2.tag_configure("warn", background=CHIP_WARN, foreground=WARN)
        self.tv2.tag_configure("calm", background=CHIP_GOOD, foreground=GOOD)
        self.tv2.tag_configure("zebra", background=ZEBRA)
        self.tv.tag_configure("zebra", background=ZEBRA)

    # ------------------------------------------------------------- actions --
    def _toggle_first(self):
        first = self.v_first.get()
        self.btn_master.configure(state="disabled" if first else "normal")
        self.ent_master.configure(fg=FAINT if first else INK)
        if first:
            self.v_master.set("")

    def _pick_file(self, var, label):
        p = filedialog.askopenfilename(
            title=f"Choose the file for: {label}",
            filetypes=[("Excel workbooks", "*.xlsx *.xlsm *.xlsb"), ("All files", "*.*")],
            initialdir=self._last_dir(var))
        if p:
            var.set(os.path.normpath(p))

    def _pick_dir(self, var):
        p = filedialog.askdirectory(title="Choose the output folder",
                                    initialdir=var.get() or _root_dir())
        if p:
            var.set(os.path.normpath(p))

    def _last_dir(self, var):
        for v in (var, self.v_books, self.v_2b, self.v_master):
            if v.get():
                d = os.path.dirname(v.get())
                if os.path.isdir(d):
                    return d
        return _root_dir()

    def _pick_folder(self):
        d = filedialog.askdirectory(title="Choose the folder holding all three files",
                                    initialdir=self._last_dir(self.v_books))
        if not d:
            return
        found = detect.classify(d)
        hits = []
        if found.get("tally"):
            self.v_books.set(os.path.normpath(found["tally"]))
            hits.append("books")
        if found.get("gstr2b"):
            self.v_2b.set(os.path.normpath(found["gstr2b"]))
            hits.append("GSTR-2B")
        if found.get("master") and not self.v_first.get():
            self.v_master.set(os.path.normpath(found["master"]))
            hits.append("pending master")
        if hits:
            self.v_status.set("Found " + ", ".join(hits) + ". Check the boxes above, then Run.")
        else:
            messagebox.showwarning(
                APP_TITLE, "No recognisable workbooks were found in that folder.\n\n"
                           "Please choose each file individually.")

    def _clear(self):
        for v in (self.v_books, self.v_2b, self.v_master):
            v.set("")
        self._set_log("")
        self.pbar["value"] = 0
        self.v_status.set("Cleared. Choose your three files, then press Run.")

    def _open(self, key):
        if self.result and self.result.get(key):
            _open_path(self.result[key])

    def _expect_period(self):
        """The month named in the window, or None to accept whatever the export says."""
        name = self.v_month.get().strip()
        if not name or name == AUTO_MONTH:
            return None
        if name not in pipeline.MONTH_NAMES:
            return None
        try:
            year = int(str(self.v_year.get()).strip())
        except ValueError:
            return None
        if not 2017 <= year <= 2099:
            return None
        return (year, pipeline.MONTH_NAMES.index(name) + 1)

    def _collect_cfg(self):
        cfg = dict(self.cfg)
        try:
            cfg["tolerance_rupees"] = float(self.v_tol.get())
        except ValueError:
            cfg["tolerance_rupees"] = 1.0
            self.v_tol.set("1.0")
        cfg["enable_probable_match"] = bool(self.v_prob.get())
        cfg["import_of_goods_source"] = self.v_impg.get() or "2B"
        cfg["apply_section_16_4_time_bar"] = bool(self.v_164.get())

        def money(var):
            try:
                return float(str(var.get()).replace(",", "").strip() or 0)
            except ValueError:
                return 0.0

        cfg["itc_ledger_opening"] = {"igst": money(self.v_op_igst),
                                     "cgst": money(self.v_op_cgst),
                                     "sgst": money(self.v_op_sgst)}
        return cfg

    def _run(self):
        if self.worker and self.worker.is_alive():
            return
        f1 = self.v_books.get().strip()
        f2 = self.v_2b.get().strip()
        f3 = "" if self.v_first.get() else self.v_master.get().strip()
        out = self.v_out.get().strip()

        problems = pipeline.check_inputs(f1, f2, f3, out)
        if problems:
            messagebox.showerror(APP_TITLE, "Please fix this first:\n\n" + "\n".join(
                "  -  " + p for p in problems))
            return
        for note in pipeline.identify(f1, f2, f3):
            if not messagebox.askyesno(APP_TITLE, note + "\n\nCarry on anyway?"):
                return
        if not f3 and not self.v_first.get():
            if not messagebox.askyesno(
                    APP_TITLE,
                    "No pending master has been chosen.\n\n"
                    "Without it, items carried forward from earlier months cannot be "
                    "matched, and credit deferred earlier will not be claimed.\n\n"
                    "Carry on without it?"):
                return

        self._set_log("")
        self.pbar["value"] = 0
        self.btn_run.configure(state="disabled", text="Running...")
        for b in (self.btn_open_work, self.btn_open_master, self.btn_open_dir):
            b.configure(state="disabled")
        self.v_status.set("Working...")
        cfg = self._collect_cfg()
        expect_period = self._expect_period()
        ledger_file = self.v_ledger.get().strip() or None
        gl_file = self.v_gl.get().strip() or None
        if self.v_month.get().strip() not in ("", AUTO_MONTH) and expect_period is None:
            messagebox.showerror(
                APP_TITLE, "A month has been chosen but the year is not a sensible one.\n\n"
                           "Please set the year, or put the month back to "
                           f"'{AUTO_MONTH}'.")
            self.btn_run.configure(state="normal", text="Run reconciliation")
            self.v_status.set("Please check the month and year.")
            return

        def work():
            try:
                def log(msg, pct=None):
                    self.queue.put(("log", msg, pct))
                R = pipeline.execute(f1, f2, f3, out, cfg, log,
                                     expect_period=expect_period,
                                     ledger_file=ledger_file,
                                     gl_file=gl_file)
                self.queue.put(("done", R, None))
            except pipeline.InputError as exc:
                self.queue.put(("input_error", str(exc), None))
            except Exception:
                self.queue.put(("crash", traceback.format_exc(), None))

        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    # ------------------------------------------------------------- plumbing --
    def _set_log(self, text, annual=False):
        box = self.a_log if annual else self.log
        box.configure(state="normal")
        box.delete("1.0", "end")
        if text:
            box.insert("end", text)
        box.configure(state="disabled")

    def _append(self, line, tag=None, annual=False):
        box = self.a_log if annual else self.log
        box.configure(state="normal")
        box.insert("end", line + "\n", tag or ())
        box.see("end")
        box.configure(state="disabled")

    def _drain(self):
        try:
            while True:
                kind, payload, pct = self.queue.get_nowait()
                if kind == "alog":
                    self._append("  " + str(payload), annual=True)
                    if pct is not None:
                        self.pbar["value"] = pct
                    continue
                if kind == "aerr":
                    self._append("", annual=True)
                    self._append("STOPPED.", "bad", annual=True)
                    for ln in str(payload).splitlines():
                        self._append("  " + ln, "bad", annual=True)
                    self._annual_done("Stopped. Please check the inputs.")
                    messagebox.showerror(APP_TITLE, str(payload))
                    continue
                if kind == "acrash":
                    self._append("Something went wrong.", "bad", annual=True)
                    self._annual_done("Something went wrong.")
                    messagebox.showerror(
                        APP_TITLE,
                        "Something went wrong and the annual run was stopped." + chr(10)
                        + chr(10) + "The technical detail has been written to "
                        "error_log.txt in the program folder.")
                    try:
                        with open(os.path.join(_root_dir(), "error_log.txt"), "w",
                                  encoding="utf-8") as fh:
                            fh.write(str(payload))
                    except OSError:
                        pass
                    continue
                if kind == "adone":
                    R = payload
                    self._append("", annual=True)
                    self._append(f"Written: {os.path.basename(R['out_annual'])}",
                                 "good", annual=True)
                    self._annual_done(f"Annual reconciliation finished  -  "
                                      f"{os.path.basename(R['out_annual'])}")
                    self.annual_result = R
                    continue
                if kind == "log":
                    tag = "warn" if payload.strip().startswith("!") else None
                    self._append(payload, tag)
                    if pct is not None:
                        self.pbar["value"] = pct
                elif kind == "done":
                    self._finish(payload)
                elif kind == "input_error":
                    self._fail("Please check the inputs", payload)
                elif kind == "crash":
                    self._crash(payload)
        except queue.Empty:
            pass
        self.root.after(120, self._drain)

    def _fail(self, title, msg):
        self.btn_run.configure(state="normal", text="Run reconciliation")
        self.pbar["value"] = 0
        self._append("")
        self._append(msg, "bad")
        self.v_status.set("Stopped. Nothing was written.")
        messagebox.showerror(APP_TITLE, f"{title}\n\n{msg}")

    def _crash(self, tb):
        self.btn_run.configure(state="normal", text="Run reconciliation")
        self.pbar["value"] = 0
        path = os.path.join(_root_dir(), "error_log.txt")
        try:
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(tb)
        except OSError:
            path = "(could not be written)"
        self._append(tb, "bad")
        self.v_status.set("Something went wrong. Nothing was written.")
        messagebox.showerror(
            APP_TITLE,
            "Something went wrong and the run was stopped.\n\n"
            "The most common causes are a file still open in Excel, or a sheet renamed "
            f"in the export.\n\nThe technical detail has been saved to:\n{path}")

    def _finish(self, R):
        self.result = R
        self.btn_run.configure(state="normal", text="Run reconciliation")
        self.pbar["value"] = 100
        for b in (self.btn_open_work, self.btn_open_master, self.btn_open_dir):
            b.configure(state="normal")

        self._append("")
        self._append("Written: " + os.path.basename(R["out_work"]), "good")
        self._append("Written: " + os.path.basename(R["out_master"]), "good")
        self.v_status.set(f"Finished  -  {R['month_label']}  -  files saved to "
                          f"{self.v_out.get()}")

        self.lbl_period.configure(
            text=f"{R['company_name'] or 'Reconciliation'}   -   {R['month_label']}")
        self._set_period_chip(R["month_label"])

        so = R.get("setoff") or {}
        cash = so.get("cash", {})
        n_books = len(R["books"]) or 1
        n_match = sum(1 for x in R["books"] if x["_matched"])
        for (val, sub), (text, note) in zip(
                (self.tile_net, self.tile_match, self.tile_def, self.tile_cash),
                ((_money(r2(R["t4c"]["igst"] + R["t4c"]["cgst"] + R["t4c"]["sgst"])),
                  "IGST plus CGST plus SGST"),
                 (f"{100.0 * n_match / n_books:.0f}%",
                  f"{n_match} of {len(R['books'])} vouchers"),
                 (_money(r2(R["t_deferred"]["igst"] + R["t_deferred"]["cgst"]
                            + R["t_deferred"]["sgst"])),
                  f"{len(R['deferred'])} invoices not yet in GSTR-2B"),
                 (_money(r2(sum(cash.get(h, 0.0) for h in ("igst", "cgst", "sgst")))),
                  "besides reverse charge, payable in cash"))):
            val.configure(text=text)
            sub.configure(text=note)
        self.lbl_files.configure(
            text=f"GSTIN {R['company_gstin']}    |    "
                 f"{os.path.basename(R['out_work'])}  and  "
                 f"{os.path.basename(R['out_master'])}")

        self.tv.delete(*self.tv.get_children())
        def add(label, t, tag=""):
            self.tv.insert("", "end", tags=(tag,), values=(
                label, _money(t["igst"]), _money(t["cgst"]), _money(t["sgst"])))
        add("Books  -  all other ITC", R["t_books"])
        add("Less: only in books, not in 2B (deferred)",
            {k: -v for k, v in R["t_deferred"].items() if isinstance(v, (int, float))})
        add("Add: deferred credit released this month", R["t_released"])
        add("Table 4(A)(5)", R["t4a5"], "head")
        add("Table 4(B)(1)", R["t4b1"], "head")
        add("Table 4(C)  net ITC", R["t4c"], "head")

        self.tv2.delete(*self.tv2.get_children())
        probable = [p for p in R.get("probable", []) if not p["mark"]]
        barred = [x for g in R.get("released_timebarred", {}).values() for x in g]
        rows = [
            ("Probable matches - not confirmed", len(probable),
             "Mark each Yes or No on the Probable Matches sheet, then run again"),
            ("Entries needing correction", len(R["require_correction"]),
             "See the Require Correction sheet"),
            ("Eligible ITC deferred to a later month", len(R["deferred"]),
             "Chase the supplier to file their GSTR-1"),
            ("In GSTR-2B but not booked", len(R["only_2b"]),
             "Book the invoice, or it stays in the pending master"),
            ("Time barred under section 16(4)", len(barred),
             "Credit has lapsed; write it off rather than claiming it"),
        ]
        for w in R.get("warnings", []):
            rows.insert(0, ("Warning while reading the inputs", "", w))
        for a in reversed(R.get("alerts", [])):
            rows.insert(0, ("CHECK BEFORE FILING", "", a))
        for i, (item, count, what) in enumerate(rows):
            if count == "":
                tag = "hot"
            elif not isinstance(count, int) or count == 0:
                tag = "calm"
            elif item.startswith(("Probable", "Time", "CHECK")):
                tag = "hot"
            else:
                tag = "warn"
            self.tv2.insert("", "end", tags=(tag,), values=(item, count, what))

        self._save_state()
        self._show("results")

    # ---------------------------------------------------------------- state --
    def _state_path(self):
        return os.path.join(_root_dir(), STATE_FILE)

    def _save_state(self):
        try:
            with open(self._state_path(), "w", encoding="utf-8") as fh:
                json.dump({"out": self.v_out.get(),
                           "books_dir": os.path.dirname(self.v_books.get()),
                           "tol": self.v_tol.get(),
                           "prob": self.v_prob.get(),
                           "impg": self.v_impg.get(),
                           "s164": self.v_164.get(),
                           "year": self.v_year.get()}, fh)
        except OSError:
            pass

    def _load_state(self):
        try:
            with open(self._state_path(), "r", encoding="utf-8") as fh:
                s = json.load(fh)
        except (OSError, ValueError):
            return
        if s.get("out"):
            self.v_out.set(s["out"])
        if s.get("tol"):
            self.v_tol.set(s["tol"])
        if "prob" in s:
            self.v_prob.set(bool(s["prob"]))
        if s.get("impg"):
            self.v_impg.set(s["impg"])
        if "s164" in s:
            self.v_164.set(bool(s["s164"]))
        if s.get("year"):
            self.v_year.set(s["year"])

    def _on_close(self):
        if self.worker and self.worker.is_alive():
            if not messagebox.askokcancel(APP_TITLE, "A run is still in progress. Close anyway?"):
                return
        self._save_state()
        self.root.destroy()


def launch(cfg: dict | None = None) -> int:
    if sys.platform.startswith("win"):
        try:
            from ctypes import windll
            windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            try:
                from ctypes import windll
                windll.user32.SetProcessDPIAware()
            except Exception:
                pass
    try:
        cfg = cfg if cfg is not None else config.load()
        root = tk.Tk()
        App(root, cfg)
        root.mainloop()
        return 0
    except Exception:
        # The window itself could not start. There may be no console to print to,
        # so leave a file the launcher can show.
        tb = traceback.format_exc()
        try:
            with open(os.path.join(_root_dir(), "error_log.txt"), "w", encoding="utf-8") as fh:
                fh.write(tb)
        except OSError:
            pass
        try:
            messagebox.showerror(APP_TITLE, "The window could not start.\n\n"
                                            "Details were saved to error_log.txt")
        except Exception:
            print(tb, file=sys.stderr)
        return 1

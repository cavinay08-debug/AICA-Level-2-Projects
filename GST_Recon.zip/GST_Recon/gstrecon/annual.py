"""
The annual, or multi-month, reconciliation.

The monthly run asks a narrow question: does this month's book entry appear in
this month's GSTR-2B, and if not, carry it forward. Over a year that understates
how much actually matched, because an invoice booked in April and reported by
the supplier in November counts as unmatched in April and only clears later.

This runs the same matching over the whole year at once. Every book voucher for
the year meets every GSTR-2B row for the year, so April's invoice matches
November's GSTR-2B directly and the year's matched position is the true one.

Inputs are a single year-long books export out of Tally and one GSTR-2B download
per month, because the portal has no annual GSTR-2B. An opening pending master
may be given, carrying items still unmatched from earlier years.

Nothing in the monthly path is touched. This module reuses the same readers, the
same matching passes and the same Table 4 build-up, so the two cannot drift.
"""

from __future__ import annotations

import os
from collections import defaultdict

from . import engine, read_2b, read_master, read_tally
from .engine import totals
from .util import fy_of, month_key, month_sort_key, r2

HEADS = ("igst", "cgst", "sgst", "cess")


def merge_2b(paths: list[str], own_gstin: str) -> tuple[dict, list]:
    """
    One GSTR-2B population out of a download per month.

    Each row keeps the period it was reported in, so the annual sheets can still
    show when a supplier actually reported, which is the whole point of looking
    at the year rather than the month.
    """
    merged = {"records": [], "sections_read": defaultdict(int),
              "sections_skipped": [], "summaries": {}, "warnings": [],
              "files": []}
    warnings: list = []
    seen_skipped: set = set()

    for path in paths:
        try:
            one = read_2b.read(path, own_gstin)
        except Exception as exc:
            warnings.append(f"'{os.path.basename(path)}' could not be read ({exc}). "
                            f"It has been left out, so the year is incomplete.")
            continue
        tag = os.path.basename(path)
        for rec in one.get("records", []):
            rec["_source_file"] = tag
            merged["records"].append(rec)
        for k, v in (one.get("sections_read") or {}).items():
            merged["sections_read"][k] += v
        for k in (one.get("sections_skipped") or []):
            if k not in seen_skipped:
                seen_skipped.add(k)
                merged["sections_skipped"].append(k)
        merged["warnings"].extend(one.get("warnings", []))
        merged["files"].append(tag)
        if not merged["summaries"]:
            merged["summaries"] = one.get("summaries", {})

    merged["sections_read"] = dict(merged["sections_read"])
    if not merged["records"]:
        warnings.append("No GSTR-2B rows could be read from any of the files given, "
                        "so nothing can be matched. Check that these are the monthly "
                        "GSTR-2B downloads.")
    return merged, warnings


def _period_of(rec) -> str:
    """The month a GSTR-2B row belongs to, for the month-by-month table."""
    for f in ("gstr1_period", "doc_date", "date"):
        m = month_key(rec.get(f))
        if m:
            return m
    return ""


def _book_month(rec) -> str:
    return rec.get("month") or month_key(rec.get("date") or rec.get("doc_date"))


def run(books_file: str, twob_files: list[str], master_file: str | None,
        cfg: dict) -> dict:
    """Read the year, match it in one pass, and lay out what the year looks like."""
    tally = read_tally.read(books_file)
    own = tally.get("company_gstin", "")
    gstr2b, merge_warnings = merge_2b(list(twob_files or []), own)
    master = read_master.read(master_file)

    A = engine.reconcile(tally, gstr2b, master, cfg)
    A["entries"] = engine.journal_entries(A)
    A["watchlist"] = engine.build_watchlist(A, cfg)
    A["warnings"] = list(A.get("warnings", [])) + merge_warnings
    A["is_annual"] = True
    A["twob_files"] = gstr2b.get("files", [])
    A["fy"] = fy_of(tally.get("period_end"))
    A["months"] = by_month(A)
    A["gstr9"] = gstr9(A)
    A["gstr9c"] = gstr9c(A)
    # The annual run shares the monthly writer, which expects these to be there.
    A.setdefault("alerts", [])
    from . import ledgers as _ledgers
    A["gl"] = {}
    A["ledger_recon"] = _ledgers.build(A, {})
    return A


# --------------------------------------------------------------------------
# Month by month
# --------------------------------------------------------------------------

def by_month(A: dict) -> list[dict]:
    """
    The year broken back down, so the annual figure can be traced to a month.

    Books are grouped on the month the voucher was booked. GSTR-2B is grouped on
    the period the supplier reported it in, which is the comparison that matters:
    the gap between the two columns is the lag being financed.
    """
    books = defaultdict(list)
    for rec in A["books"]:
        books[_book_month(rec)].append(rec)
    twob = defaultdict(list)
    for rec in A["b2b"]:
        twob[_period_of(rec)].append(rec)
    unmatched_b = defaultdict(list)
    for rec in A["only_books"]:
        unmatched_b[_book_month(rec)].append(rec)
    unmatched_2 = defaultdict(list)
    for rec in A["only_2b"]:
        unmatched_2[_period_of(rec)].append(rec)

    out = []
    for m in sorted(set(books) | set(twob), key=month_sort_key):
        if not m:
            continue
        tb, t2 = totals(books[m]), totals(twob[m])
        matched = [x for x in books[m] if x.get("_matched")]
        out.append({
            "month": m,
            "books": tb, "twob": t2,
            "matched": totals(matched),
            "n_books": len(books[m]), "n_matched": len(matched),
            "n_twob": len(twob[m]),
            "only_books": totals(unmatched_b[m]),
            "n_only_books": len(unmatched_b[m]),
            "only_2b": totals(unmatched_2[m]),
            "n_only_2b": len(unmatched_2[m]),
        })
    return out


# --------------------------------------------------------------------------
# GSTR-9
# --------------------------------------------------------------------------

def gstr9(A: dict) -> dict:
    """
    The year's figures set against the tables of the annual return.

    Only the lines this tool can actually derive are filled. Anything it has no
    basis for is left for the preparer rather than guessed at, and says so.
    """
    inelig_2b = totals([x for x in A["b2b"]
                        if str(x.get("remark2", "")).lower() == "ineligible"])
    elig_not_availed = totals([x for x in A["only_2b"]
                               if str(x.get("remark2", "")).lower() != "ineligible"])
    inelig_not_availed = totals([x for x in A["only_2b"]
                                 if str(x.get("remark2", "")).lower() == "ineligible"])
    t_2b_all = totals(A["b2b"])

    six = [
        ("6B", "Inward supplies other than imports and inward supplies liable to "
               "reverse charge", A["t4a5"], "Table 4(A)(5) for the year"),
        ("6C", "Inward supplies from unregistered persons liable to reverse charge",
         None, "Not separated by this tool; take from the reverse charge register"),
        ("6D", "Inward supplies from registered persons liable to reverse charge",
         A["t4a3"], "Reverse charge register"),
        ("6E", "Import of goods", A["t4a1"], "IMPG"),
        ("6F", "Import of services", A["t4a2"], "IMPS"),
        ("6G", "Input tax credit received from ISD", A["t4a4"], "ISD per GSTR-2B"),
        ("6H", "Amount of ITC reclaimed under the provisions of the Act", None,
         "Not tracked separately; enter if any"),
    ]
    seven = [
        ("7E", "As per section 17(5)", A["t4b1"], "Table 4(B)(1), the blocked "
                                                 "credit register"),
        ("7H", "Other reversals", None, "Enter if any"),
    ]
    eight = [
        ("8A", "ITC as per GSTR-2A or GSTR-2B", t_2b_all,
         "Every GSTR-2B row read for the year"),
        ("8B", "ITC as per sum of 6(B) and 6(H) above", A["t4a5"],
         "6B, since 6H is not tracked"),
        ("8C", "ITC on inward supplies received during the year but availed in the "
               "next financial year", None,
         "Credit still pending at the year end that is claimed later"),
        ("8E", "ITC available but not availed", elig_not_availed,
         "Eligible rows in GSTR-2B never booked"),
        ("8F", "ITC available but ineligible", inelig_not_availed,
         "Blocked rows in GSTR-2B never booked"),
        ("8G", "IGST paid on import of goods", A["t4a1"], "IMPG per GSTR-2B"),
        ("8H", "IGST credit availed on import of goods", A["t4a1"], "As claimed"),
    ]
    return {"six": six, "seven": seven, "eight": eight,
            "inelig_2b": inelig_2b}


# --------------------------------------------------------------------------
# GSTR-9C, the input tax credit reconciliation
# --------------------------------------------------------------------------

def gstr9c(A: dict) -> dict:
    """
    Table 12 of GSTR-9C: the credit in the books against the credit claimed.

    This is the deferral the tool already tracks, read over a year instead of a
    month. Credit booked in the year but still waiting on a supplier is exactly
    12C; credit released this year that was booked in an earlier one is 12B.
    """
    fy = A.get("fy") or ""

    # Booked in an earlier year, claimed now.
    earlier = [x for g in A.get("released_eligible", {}).values() for x in g]
    from_earlier = totals([x for x in earlier
                           if fy_of(x.get("doc_date") or x.get("date")) != fy])

    # Booked this year, not yet claimed.
    pending = totals(A.get("deferred", []))

    books = A["t_books"]
    claimed = A["t4a5"]
    # 12D = 12A plus what was booked earlier and claimed now, less what is booked
    # now and will be claimed later. Credit released within the same year needs
    # no adjustment: it is already inside 12A.
    adjusted = {h: r2(books[h] + from_earlier[h] - pending[h]) for h in HEADS}
    diff = {h: r2(adjusted[h] - claimed[h]) for h in HEADS}

    return {
        "rows": [
            ("12A", "ITC on inward supplies per the books, the All Other ITC register",
             books, False),
            ("12B", "Add: ITC booked in an earlier year but claimed in this one",
             from_earlier, False),
            ("12C", "Less: ITC booked in this year but to be claimed in a later one",
             pending, True),
            ("12D", "ITC per the books, adjusted", adjusted, False),
            ("12E", "ITC claimed in the return, Table 4(A)(5)", claimed, False),
            ("12F", "Unreconciled difference", diff, False),
        ],
        "difference": diff,
        "ties": all(abs(diff[h]) <= 1.0 for h in HEADS),
        "note": ("This should come to nil over a complete year. A difference usually "
                 "means the books export does not cover the whole year, so credit "
                 "released from a month outside it has been claimed without the "
                 "original entry being in 12A."),
    }

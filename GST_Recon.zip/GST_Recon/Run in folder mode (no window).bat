@echo off
setlocal EnableDelayedExpansion
title GST Reconciliation - folder mode
cd /d "%~dp0"

echo ==========================================================================
echo    GST RECONCILIATION  -  folder mode (no window)
echo    Reads whatever is in the Input folder, writes to the Output folder.
echo ==========================================================================
echo.

set "PY="
py -3 --version >nul 2>&1 && set "PY=py -3"
if not defined PY ( python --version >nul 2>&1 && set "PY=python" )
if not defined PY ( python3 --version >nul 2>&1 && set "PY=python3" )
if not defined PY (
  echo   Python is not installed. Please install Python 3.9 or later from
  echo   https://www.python.org/downloads/ and tick "Add python.exe to PATH".
  echo.
  pause
  exit /b 1
)

%PY% -c "import openpyxl" >nul 2>&1
if errorlevel 1 (
  echo   Installing openpyxl...
  %PY% -m pip install --quiet --user openpyxl
  if errorlevel 1 (
    echo   Could not install it. Please run: %PY% -m pip install openpyxl
    pause
    exit /b 1
  )
)

if not exist "Input" mkdir "Input"
if not exist "Output" mkdir "Output"

dir /b "Input\*.xls*" >nul 2>&1
if errorlevel 1 (
  echo   The Input folder is empty. Put these three files in it:
  echo      1. GSTR-3B working exported from Tally
  echo      2. GSTR-2B workbook downloaded from the GST portal
  echo      3. Last month's pending master  ^(skip on the very first run^)
  echo.
  start "" "%~dp0Input"
  pause
  exit /b 1
)

%PY% -m gstrecon --folder
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" echo   The run did not finish. Please read the message above.
pause
exit /b %RC%

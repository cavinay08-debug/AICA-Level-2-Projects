# GST Reconciliation — GSTR-2B vs Books

Reconciles the GSTR-2B downloaded from the GST portal against the GSTR-3B working
exported from Tally, carries unmatched items forward month after month, and produces
the monthly working paper plus the journal entries to pass in Tally.

---

## Everything stays on your computer

There is no internet connection, no account and no upload. The `.bat`, the program and
your Excel files all live in this folder on your laptop. The only thing that ever leaves
your machine is the one-off download of `openpyxl` (the library that reads Excel files)
the first time you run it.

---

## Running it

Double-click **`GST Reconciliation.bat`**. A window opens:

The **Inputs** tab reads as a sequence. A stepper across the top shows where you are:
Files, Filing period, Ledgers, Review and run, each saying what is done and what is not.
**Run reconciliation** stays greyed until the two mandatory workbooks, the pending master
(or the first-month tick) and an output folder are all in place, and the **Ready to run**
panel at the foot lists exactly what is still needed.

1. **Choose the three files.** Each row has a **Choose file** button, shows the file you
   picked, and says **Required** or **Optional** and **Ready** or **Not found** in words.

   | | File | Where it comes from |
   |---|---|---|
   | 1 | Books | Tally → GSTR-3B → export to Excel |
   | 2 | GSTR-2B | GST portal → Returns → GSTR-2B → download Excel |
   | 3 | Pending master | the `Pending_Master_*.xlsx` produced by **last month's** run |

   File names do not matter — each workbook is identified by the sheets inside it. If all
   three sit in one folder, **Pick a folder containing all three** fills them in for you.

   On your very first month you will not have file 3. Tick *"This is my first month"* and
   the tool starts a fresh master.

2. **Say which month you are filing** (optional). See *Naming the month* below.

3. **Choose where to save.** The folder is remembered for next month.

4. Press **Run reconciliation**. It sits in the strip at the top, next to the **Inputs**
   and **Results** tabs and **Clear / Reset**, so it is always in reach rather than at the
   foot of a long page. Progress runs alongside it, then the window switches to
   **Results**, showing the figures to report, anything needing your attention, and
   buttons to open either output file.

Two files are written:

- `GSTR_Working_Jul26.xlsx` — the working paper for the month
- `Pending_Master_Jul26.xlsx` — the updated master; this becomes file 3 next month

The first time you run it, the launcher checks that Python is present and installs
`openpyxl` if needed. If Python is missing it offers to install that too.

Close the files in Excel before running — the tool tells you if one is still open rather
than failing halfway.

### Naming the month

Step 2 in the window asks which month you are filing. This is a **cross-check, not a
setting**: the period is always read from the Tally export. If you say July 2026 and the
export turns out to cover June, the run stops, tells you both dates, and writes nothing.
That catches exporting the wrong month from Tally, which is otherwise invisible.

Leave it on *"Read it from the export"* to skip the check. The box goes back to that every
time you open the window, on purpose, so a month left over from last time cannot quietly
check the wrong thing. From the command line the same check is `--month 2026-07`.

> **Re-running the same month.** If you correct something in Tally and run July again,
> point file 3 back at **June's** master, not the July master the tool just produced. The
> July master already records those items as cleared, so re-using it would under-claim.
> One master in, one master out, one month at a time. The tool warns you loudly if it
> spots this, but it cannot know for certain, so the habit still matters.

### Trying it without your own data

The **Sample** folder holds three invented workbooks for a fictional company, so the tool
can be demonstrated without opening anybody's real books. Point the three Browse buttons
at them, or use *Pick a folder containing all three* and choose `Sample`. See
`Sample\README.md` for what the demonstration is built to show.

### No-window alternative

`Run in folder mode (no window).bat` does the same thing without the window: put the
three files in the **Input** folder, double-click, and the results appear in **Output**.
Useful if you ever want to schedule it. The Input folder currently holds the July 2026
files so you can try either version straight away.

---

## How it looks

The window and the working paper both follow the **Exactitude International brand
guidelines**: the primary blue leads, brown supports, red is kept for exceptions, and the
shapes are square-edged throughout, as the guide requires.

Because the guide has no green or amber, the three states a reconciliation has to show
are carried on the three brand colours instead:

| | Colour | Meaning |
|---|---|---|
| Blue | `#272361` | Agreed, and the figures being reported |
| Brown | `#412312` | Waiting on somebody, deferred or held up |
| Red | `#D83030` | A difference, or something that needs a decision |

Type is Fira Sans where it is installed, falling back to Calibri and then Arial, which is
the order the guide sets out. The working paper stays on Calibri, since Fira Sans cannot
be relied on to be present wherever the file is opened.

---

## What the working paper contains

Read it in this order.

| Sheet | What it is for |
|---|---|
| **Dashboard** | Headline figures, four charts and links into the detail. Open on this. |
| **Summary** | Where every rupee of credit went and what needs your attention. **Every count is a link** to the rows behind it. |
| **Supplier Watchlist** | Suppliers who keep failing to report our invoices, ranked. Split into "needs action" and "for reference". |
| **Probable Matches** / **Cleaned Doc No Matches** | The rows behind those two counts, so nothing is a black box. |
| **GSTR-3B** | The reconciled return figures, table by table. |
| **All other ITC-4A(5)-Calculation** | The build-up from the books figure to the Table 4(A)(5) figure, and to 4(B)(1) and 4(C). |
| **Entries** | The journal entries to pass in Tally, ready to read across. |
| **Require Correction** | Entries that almost match but need a correction — wrong GSTIN, wrong tax head, or a value difference. Each row carries a suggested action. |
| **Deferred ITC** | Eligible credit booked this month but not yet in GSTR-2B. Not claimed; carried forward. |
| **Deferred ITC Reversal** | Credit deferred in earlier months that has now appeared in GSTR-2B, so it is claimed this month. |
| **ITC only in books; Not in 2B** | Everything unmatched on the books side. |
| **ITC only in 2b; Not in Books** | Everything unmatched on the GSTR-2B side. |
| **Ineligible ITC** | Blocked credit reversed under Table 4(B)(1). |
| **All other ITC** / **GSTR 2B** | The two populations being matched, with the live matching formulas. |
| **RCM ITC Books**, **RCM-2B**, **IMPS Books**, **IMPG Books**, **IMPG-2B**, **ISD-2B**, **Table 3.1a/b/c/d/e** | Supporting registers. Every figure in the return is linked to one of these. |

The matching columns on **All other ITC** and **GSTR 2B** are live `SUMIFS` formulas, so
if you correct a document number in the `Update Doc. No.` column the row re-matches
immediately in Excel — the same way you do it by hand today.

### Every figure is linked to its backup

The amounts on **GSTR-3B**, **Summary** and **Entries** are not typed in. Each one is a
formula pointing at the schedule it comes from, so the return ties out to its working and
moves with it if you correct something underneath.

- Click the label on any row to jump to the sheet behind it.
- Stand on an amount and press **Ctrl and [** to jump to the exact cell it comes from,
  or use **Formulas, Trace Precedents** to see the chain drawn on screen.
- Each journal entry names its backup working in the last column.

A figure is only linked when it genuinely agrees with its schedule. If the two ever
disagree, the tool keeps the figure that was reported and says so in the `Source` column
rather than quietly changing the return to match a schedule.

On the **ITC Set-off** sheet only two things are typed: the opening credit ledger, which
comes from outside the workbook, and the three allocation rows, which are the result of
the statutory order. Every other figure there is worked out from the rows above it or
points at GSTR-3B, so the sheet ties out on its own.

Three sheets were added so that everything reported has somewhere to point:
**ISD-2B** for Table 4(A)(4), and **Table 3.1c** and **Table 3.1e**. Table 4(A)(4) used to
appear in the return with no supporting sheet at all.

---

## How the matching works

For each invoice in the books the tool looks for a partner in GSTR-2B, in this order:

1. **Exact** — supplier GSTIN and document number match character for character.
2. **Normalised document number** — same GSTIN, and the document numbers agree once case,
   spaces, slashes, dashes and leading zeros are ignored, with the tax amount agreeing.
   `SS/26-27/00158` matches `SS26270158`.
3. **Partial document number** — same GSTIN, same last six characters, tax amount agrees,
   and only one candidate exists.
4. **Probable** — same GSTIN, same tax amount, invoice dates within 45 days, and only one
   candidate exists.

Whenever a match is found by anything other than rule 1, the tool writes the GSTR-2B
document number into the `Update Doc. No.` column, which is exactly the manual correction
you would have made. The `Match Type` column records which rule was used, and anything
non-exact is colour-flagged. **Probable matches are shaded orange and must be confirmed
before filing** — they are counted separately on the Summary sheet.

### Confirming the probable matches

A probable match is a suggestion, not a finding. The credit on it is claimed in Table
4(A)(5), so leaving one unanswered is itself a decision about credit you have already
taken. The **Probable Matches** sheet has a `Confirmed` column with a Yes / No dropdown:

- **Yes** records that you have looked at it. Nothing moves.
- **No** rejects the suggestion. The voucher keeps the document number it was booked
  under, so it no longer matches, and the credit is deferred like any other invoice
  missing from GSTR-2B. The pair is never suggested again.
- **Blank** means the credit is claimed on the tool's suggestion alone.

Mark the column, save the workbook, and run the month again. The tool reads your marks
back before it overwrites the file, and copies them into the pending master so next month
still knows about them. Rejected pairs are listed again at the foot of the sheet, so you
can change a No back to a Yes later.

Rejecting a pair only rejects that guess. If the document numbers agree on their own in a
later month, that is better evidence and the invoice matches normally.

Whatever still does not match is examined for the three usual culprits and, if one fits,
listed on **Require Correction**:

- the same PAN under a different state code — the GSTIN was captured for the wrong state
- the same document with the tax under a different head — IGST booked as CGST/SGST or vice versa
- the same document with a different value

A tax difference of up to **Rs 1** per head still counts as matched, so paisa-level
rounding does not create hundreds of false mismatches. The difference is still shown in
the `DIFF` column. Change this in `settings.json`.

### When GSTR-2B and the books disagree on the amount

Credit is limited to what you have booked, so the test is one-sided:

| | Result |
|---|---|
| The two agree within tolerance | **Matched** |
| GSTR-2B shows **more** than the books | **Matched - GSTR-2B higher**, credit claimed to the extent booked |
| The books show **more** than GSTR-2B | **Not Matched**, because claiming it would exceed GSTR-2B |

Where GSTR-2B is the higher figure, the row is still listed on **Require Correction**
under the kind *GSTR-2B higher*, with the difference spelled out head by head, so you can
check whether the purchase was booked short.

A debit note is never matched to the invoice it reverses, whatever the amounts look like.
The two sides have to point the same way before they are compared at all.

### Debit notes and credit notes

Your debit note against a supplier is **their credit note** in GSTR-2B, so the document
numbers never correspond and there is often no document number on your side at all.
Notes are therefore matched on the supplier, the sign and the amount, with the document
number ignored, and only where exactly one candidate fits.

### Matching across months

Books that do not match this month's GSTR-2B are also checked against the GSTR-2B items
carried in the pending master from earlier months, and vice versa. This is what catches
an invoice that appeared in GSTR-2B in June but was only booked in July.

- A book invoice that matches an **earlier month's** GSTR-2B is claimable now and is
  marked `Matched-GSTR-2B-Jun'26`.
- A pending book item that appears in **this month's** GSTR-2B is released: it goes to
  **Deferred ITC Reversal** and is added back to Table 4(A)(5).

Cross-month matching is deliberately stricter than within-month matching: the tax amount
must also agree, and one prior document releases exactly one entry. Rows already marked
as matched in the pending master are never re-matched. Together these mean the same
credit cannot be claimed twice.

**Section 16(4).** Credit released from an earlier month is not claimed if 30 November of
the following financial year has already gone by. It is listed on **Require Correction**
as time barred instead. Turn this off with `apply_section_16_4_time_bar` if you handle it
another way.

---

## How the figures are built

```
Table 4(A)(5)   =  All other ITC per books
                -  eligible ITC booked but not in GSTR-2B      (deferred)
                +  ITC deferred in earlier months, now in 2B   (released)

Table 4(B)(1)   =  Tally's Ineligible ITC register             (blocked credit)

Table 4(A)(1)   =  Import of goods per GSTR-2B                 (settings: 2B or BOOKS)
Table 4(A)(2)   =  Import of services per books
Table 4(A)(3)   =  Reverse charge per books
Table 4(A)(4)   =  ISD credit per GSTR-2B

Table 4(C)      =  4(A) total  -  4(B)
```

Blocked credit is taken **entirely from Tally's own "Ineligible ITC" register**, which
covers ordinary purchases and reverse-charge lines alike. Nothing is guessed. If that
sheet is ever missing from the export, the tool falls back to the keyword rules in
`settings.json` and says so on the Summary sheet.

Note that blocked credit which is also missing from GSTR-2B is still claimed in 4(A)(5)
and reversed in 4(B)(1) — the net effect is nil, and it matches the presentation used in
your existing workings.

---

## Settings

The four you are most likely to touch — tolerance, import source, probable matches and
the section 16(4) check — are on the **Options** panel in the window, and what you choose
is remembered.

`settings.json` sits next to the .bat file and holds the full list:

| Setting | Default | Meaning |
|---|---|---|
| `tolerance_rupees` | `1.0` | Tax difference still treated as matched |
| `enable_probable_match` | `true` | Turn off to require document numbers to agree |
| `probable_match_max_day_gap` | `45` | How far apart invoice dates may be for a probable match |
| `probable_match_unconfirmed` | `"claim"` | What to do with a probable match nobody has marked yet. `claim` takes the credit and flags the row; `hold` keeps it back until you mark it Yes |
| `import_of_goods_source` | `"2B"` | `2B` or `BOOKS` for Table 4(A)(1) |
| `detect_wrong_gstin` | `true` | Flag same-PAN, different-state mismatches |
| `detect_wrong_tax_head` | `true` | Flag IGST vs CGST/SGST mismatches |
| `open_output` | `"file"` | `file`, `folder` or `none` |

Lines beginning with an underscore are comments and are ignored.

---

## Setting the credit off against your liability

The last journal entry is the real utilisation of credit, not a straight offset. It
follows the order the law fixes:

1. The **IGST** balance is used first and in full: against IGST, then CGST, then SGST.
2. **CGST** credit then pays CGST, and after that IGST.
3. **SGST/UTGST** credit pays SGST, and IGST only once CGST credit is exhausted.

CGST credit can never pay SGST, and SGST can never pay CGST. Rule 88A leaves one choice,
the order in which a surplus IGST balance is applied to CGST and SGST; this is set to
**CGST first** and can be changed in `settings.json`.

**Reverse charge under Table 3.1(d) is not part of the set-off.** It has to be paid in
cash, so it is shown separately at the foot of the sheet.

For this the tool needs the opening balance of your **electronic credit ledger**. Type it
on the Run tab, or point at the ledger downloaded from the portal, which is used in
preference when given. The new **ITC Set-off** sheet shows the whole working, ending in
the cash payable by head and the closing ledger balance, which should agree with the
portal once the return is filed.

If you point at a workbook that is not a credit ledger, or the balance cannot be found in
it, the tool says so and uses the figures you typed. It never assumes a nil ledger, which
would overstate the cash payable.

---

## Reconciling the GST ledgers

Give the tool one workbook holding your nine GST ledgers, and the working paper gains a
**Ledgers Reconciliation** sheet:

| | |
|---|---|
| GST Inputs | IGST, CGST and SGST input |
| GST Deferred Inputs | the three deferred accounts |
| GST Payables | the three payable accounts |

For each one it shows the closing balance per Tally, the effect of the entries on the
Entries sheet, the position after those entries are passed, what the ledger ought to
stand at, and the difference. Figures are debit positive, so a credit balance prints in
brackets.

The effect column is a live formula reading the Entries sheet, so if you change an entry
the reconciliation moves with it.

**What each group should come to**

- The input ledgers should equal the credit still available, per the electronic credit
  ledger after the set-off.
- The deferred ledgers should equal the credit still unclaimed, which is the eligible open
  items carried in the pending master plus whatever is being deferred this month.
- The payable ledgers should equal the tax still payable in cash after the set-off.

Only eligible invoices are deferred, so blocked credit is excluded from the deferred
comparison; it is claimed and reversed instead and never reaches that ledger.

**Credit time barred under section 16(4)** is shown as a reconciling line of its own. It
leaves the pending master because it has matched, but nothing takes it out of the deferred
ledger, so it sits there until you write it off.

If a ledger cannot be found it is shown as *not found*, never as nil. Add the spelling
your chart of accounts uses under `ledger_names` in `settings.json`.

---

## The annual reconciliation

The **Annual** tab is a separate job from the monthly one. It writes its own workbook and
never touches your monthly workbooks or the pending master.

Give it:

1. **One books export covering the whole financial year**, the same GSTR-3B working out of
   Tally, with twelve months of rows.
2. **Every GSTR-2B download for the year.** The portal has no annual GSTR-2B, so choose
   the twelve monthly files together.
3. **An opening pending master**, if items were still unmatched when the year began.

**Why it differs from adding up the months.** The monthly run asks whether April's invoice
appears in April's GSTR-2B. Over a year that understates how much really matched, because
an invoice booked in April and reported by the supplier in November counts as unmatched in
April. The annual run matches every voucher for the year against every GSTR-2B row for the
year, so it shows the true annual position.

The workbook opens with three sheets of its own, then the usual working paper behind them:

| Sheet | What it is |
|---|---|
| **Annual Summary** | The year at a glance, then month by month. Books are shown in the month booked, GSTR-2B in the month the supplier reported; the gap is the lag being financed. |
| **GSTR-9** | Tables 6, 7 and 8 with the year's figures against them, and where each one comes from. Lines the tool has no basis for are shaded and left for you rather than guessed at. |
| **GSTR-9C ITC** | Table 12: the credit in the books against the credit claimed. This should come to nil over a complete year. |

From the command line:

```bash
python -m gstrecon --annual --file1 "Books FY26-27.xlsx" --twob apr.xlsx may.xlsx jun.xlsx --output Output
```

---

## The pending master

Every unmatched item goes into the master and stays there until it clears. Matched rows are kept for history, greyed out, with `Status = Cleared`, the remark
**"Matched with month July 2026"**, and columns for the invoice month, the month it
cleared in, what it cleared against, and its ageing in months.
Each sheet totals the open rows separately from all rows, and the **Summary** sheet shows
the month's movement: brought forward, cleared, added, carried forward.

The tool appends to whichever sheet already holds your most recent data, so your existing
sheet structure is preserved rather than replaced.

### If a future Tally export changes shape

The tool has only ever seen one layout of the GSTR-3B export. If a Tally upgrade renames
a sheet or a column, the risk is not that it crashes, it is that a register reads as zero
and a table quietly comes out nil.

So each register is checked before anything is written. If a register that feeds Table 4
is present but its tax columns cannot be recognised, the run **stops** and names the sheet
and the columns it was looking for. Nothing is written, because a nil register understates
the return while everything else looks normal. The Table 3.1 sheets only warn, and their
figures are dropped rather than taken as zero, so Table 3.1(d) falls back to IMPS plus RCM.

The pending master also records how many vouchers each register held each month. If a
register that used to hold vouchers suddenly holds none, you are told, with last month's
figures for comparison. That is the only way to tell a genuinely empty register from one
Tally has stopped producing.

If the export has genuinely changed for good, the new column headings need adding to the
list the tool recognises. That is a small edit to `read_tally.py`.

### Use last month's master, not this month's

When you run a month, file 3 must be the master from the **month before**. If you re-run
July, keep pointing at June's master. Pointing it at the `Pending_Master_Jul26.xlsx` this
tool just produced is the one mistake that makes your return too **small**: everything it
cleared in July is already stamped `Cleared`, and cleared rows are never matched again, so
credit that should be released this month is silently left out of Table 4(A)(5).

The tool now checks for this. If the master already records items as matched in the month
being worked on, you get a red block at the top of the **Summary** sheet, a boxed warning
on screen and a line at the top of the results in the window, telling you which file was
used, how many rows are affected and roughly how much credit is at risk. The run still
finishes, so if you know the file is right you can carry on.

---

## Running it another way

The .bat is a wrapper around a normal Python package, so you can also run:

```
python -m gstrecon                             # opens the window (the default)
python -m gstrecon --folder                    # Input and Output folders, no window
python -m gstrecon --input D:\GST\Jul --output D:\GST\Jul\Out --folder
python -m gstrecon --file1 books.xlsx --file2 gstr2b.xlsx --file3 master.xlsx
python -m gstrecon --settings D:\GST\settings.json --no-open
```

Requires Python 3.9 or later, `openpyxl`, and `tkinter` for the window (tkinter comes
with the standard Python installer from python.org).

---

## If something goes wrong

| Message | Cause |
|---|---|
| "Your Python is missing the tkinter component" | Re-run the Python installer, choose Modify, tick *tcl/tk and IDLE* |
| "looks like it is open in Excel" | Close the workbook and press Run again |
| "has no 'All Other ITC' sheet" | The Tally export left out a register; export the GSTR-3B working again with all of them |
| "Have the first two files been swapped?" | The books and GSTR-2B pickers are the wrong way round |
| The window closes straight away | `error_log.txt` in this folder has the detail; the launcher prints it for you |
| A register reads as empty | The sheet was renamed in Tally; the tool looks for a header row starting with `Date` |

The Summary sheet always records how many rows were read from each input, so a silent
mis-read shows up as a row count that looks wrong.

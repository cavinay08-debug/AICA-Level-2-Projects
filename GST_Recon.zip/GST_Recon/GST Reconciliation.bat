@echo off
setlocal EnableDelayedExpansion
title GST Reconciliation
cd /d "%~dp0"

echo.
echo   Starting GST Reconciliation...
echo   Everything runs on this computer. No data is sent anywhere.
echo.

REM ---------------------------------------------------------------- Python --
set "PY="
set "PYW="
py -3 --version >nul 2>&1 && ( set "PY=py -3" & set "PYW=pyw -3" )
if not defined PY ( python --version >nul 2>&1 && ( set "PY=python" & set "PYW=pythonw" ) )
if not defined PY ( python3 --version >nul 2>&1 && ( set "PY=python3" & set "PYW=python3" ) )

if not defined PY (
  echo   Python is not installed on this computer.
  echo.
  choice /c YN /m "   Shall I install it now (needs an internet connection)"
  if errorlevel 2 goto :nopython
  echo.
  echo   Installing Python, please wait...
  winget install -e --id Python.Python.3.12 --accept-source-agreements --accept-package-agreements
  if errorlevel 1 goto :nopython
  echo.
  echo   Python installed. Please close this window and start the tool again
  echo   so Windows picks up the new installation.
  echo.
  pause
  exit /b 0
)

REM ------------------------------------------------------------ Components --
%PY% -c "import tkinter" >nul 2>&1
if errorlevel 1 (
  echo   Your Python is missing the tkinter component, which draws the window.
  echo.
  echo   Fix: re-run the Python installer, choose Modify, and tick
  echo        "tcl/tk and IDLE". Then start this tool again.
  echo.
  echo   Meanwhile you can still use the no-window version:
  echo        "Run in folder mode (no window).bat"
  echo.
  pause
  exit /b 1
)

%PY% -c "import openpyxl" >nul 2>&1
if errorlevel 1 (
  echo   Installing the one component needed to read Excel files...
  %PY% -m pip install --quiet --upgrade pip >nul 2>&1
  %PY% -m pip install --quiet --user openpyxl
  if errorlevel 1 (
    echo.
    echo   That did not work. Please open a Command Prompt, run this,
    echo   and then start the tool again:
    echo        %PY% -m pip install openpyxl
    echo.
    pause
    exit /b 1
  )
  echo   Done.
)

if not exist "Output" mkdir "Output"
if exist "error_log.txt" del "error_log.txt" >nul 2>&1

REM ------------------------------------------------------------------- Go! --
echo   Opening the window...
%PYW% -m gstrecon --gui
set "RC=%ERRORLEVEL%"

if not "%RC%"=="0" (
  echo.
  echo   The window closed unexpectedly.
  if exist "error_log.txt" (
    echo   Details were saved to error_log.txt:
    echo   --------------------------------------------------------------
    type "error_log.txt"
    echo   --------------------------------------------------------------
  ) else (
    echo   Running it again with messages showing:
    echo   --------------------------------------------------------------
    %PY% -m gstrecon --gui
    echo   --------------------------------------------------------------
  )
  echo.
  pause
)
exit /b %RC%

:nopython
echo.
echo   Please install Python 3.9 or later from https://www.python.org/downloads/
echo   During installation, tick "Add python.exe to PATH".
echo   Then start this tool again.
echo.
pause
exit /b 1

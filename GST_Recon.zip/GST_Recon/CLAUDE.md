# GST Reconciliation — project context

This file is the handoff. It carries everything an assistant needs to keep working on
this tool without re-deriving it. Read it before changing anything.

---

## 1. What this is

A Windows desktop tool that reconciles **GSTR-2B** (downloaded from the GST portal)
against **books** (the GSTR-3B working exported from Tally), maintains a rolling
**pending master** of unmatched items across months, and produces the monthly GST
working paper plus the journal entries to pass in Tally.

Built for **Vandhana International Pvt Ltd**, GSTIN `07AAACV2037R1ZZ`, Delhi.
It is used monthly by the person filing the return.

**It runs entirely offline on the user's laptop.** No network, no account, no upload.
The only network call is the one-off `pip install openpyxl` on first run. The user
raised this explicitly — do not introduce anything that phones home.

### Inputs (three Excel files)

| | File | Source | Key sheets |
|---|---|---|---|
| 1 | Books | Tally → GSTR-3B → export | `All Other ITC`, `Ineligible ITC`, `RCM ITC Book`, `IMPS Books`, `IMPG Books`, `Table 3.1a/3.1b/3.1d`, `GSTR-3B` |
| 2 | GSTR-2B | GST portal | `B2B`, `B2B-CDNR`, `B2BA`, `B2B-CDNRA`, `ECO`, `ISD`, `IMPG`, `ITC Available` |
| 3 | Pending master | last month's output of this tool | `Only in books; Not in 2B <FY>`, `Only in 2B; Not in books <FY>` |

Files are identified **by the sheets inside them**, never by filename (`detect.py`).

### Outputs

- `GSTR_Working_<Mon><yy>.xlsx` — 28 sheets, the month's working paper
- `Pending_Master_<Mon><yy>.xlsx` — becomes input file 3 next month

---

## 2. How to run and test

```bash
python -m gstrecon                 # opens the window (default)
python -m gstrecon --folder        # reads Input/, writes Output/, no window
python -m gstrecon --file1 a.xlsx --file2 b.xlsx --file3 c.xlsx --output out/
python -m gstrecon --folder --month 2026-07   # stop if the export is another month
```

`Input/` holds the real July 2026 files — a genuine regression fixture. Any change
must keep these figures:

```
Table 4(A)(5)   19,407,940.91 IGST    642,265.89 CGST    642,265.89 SGST
Table 4(B)(1)       85,471.74 IGST     90,130.42 CGST     90,130.42 SGST
Table 4(C)      20,093,405.88 IGST    577,476.21 CGST    577,476.21 SGST
Books all other ITC 19,406,041.33 IGST  1,024,106.98 CGST   (352 vouchers, 316 matched)
```

The matched count moved from 315 to 316, and Require Correction from 3 to 2 plus one
noted item, when the "GSTR-2B is the higher side" rule went in. **The Table 4 figures did
not move**, because the one document it newly matches is blocked credit, which is claimed
and reversed either way. Anything that moves Table 4 has to be agreed first.

### The verification that matters

The workbook carries **live SUMIFS formulas**, so Excel recomputes the verdict
independently of Python. They must agree on every row. To check, drive Excel over COM
from PowerShell (the user's machine has Excel 16.0 and no LibreOffice):

```powershell
$xl = New-Object -ComObject Excel.Application
$wb = $xl.Workbooks.Open($book, $false, $true)
$xl.CalculateFullRebuild()
# compare 'All other ITC'!U (col 21) and 'GSTR 2B'!X (col 24) against
# R['books'][i]['remark1'] and R['b2b'][i]['remark1']
# and scan every sheet with .Cells.SpecialCells(-4123, 16) for error values
```

Last run: **0 formula errors in either workbook, 0 mismatches across 874 rows.**
Also verified with rejections in place, which is the case that can pull the two apart.
If a change breaks that agreement, the Python verdict and the Excel formula have
drifted apart — fix both together.

Control checks that must hold (see the ad-hoc script pattern used in this project):
books split without loss, 4A(5) build-up arithmetic, 4B(1) ties to the Tally
ineligible register, 4C = 4A − 4B, 3.1(d) = IMPS + RCM, every journal entry balances,
no book row hijacks another's document number, one prior 2B document releases one entry.

The GUI can be driven headlessly for testing: instantiate `gui.App` on a withdrawn
`Tk()`, stub out `messagebox.*`, set the `v_*` StringVars, call `app._run()`, then pump
`root.update()` until `app.result` is set or a messagebox is captured. On Windows no
xvfb is needed; `root.withdraw()` is enough.

---

## 3. Module map

| File | Responsibility |
|---|---|
| `util.py` | number/date coercion, GSTIN normalisation, the three document-number keys |
| `sheetutil.py` | grid loading, header detection, header-alias → column mapping |
| `config.py` | `settings.json` load/write, every tunable business rule |
| `read_tally.py` | File 1 → canonical voucher records per register |
| `read_2b.py` | File 2 → one flat list of 2B records across all sections |
| `read_master.py` | File 3 → open/cleared pending items, register history, several legacy layouts |
| `decisions.py` | the accountant's Yes / No answers on the probable matches |
| `match.py` | the matching passes and the SUMIFS-equivalent group verdict |
| `engine.py` | orchestration, Table 4 build-up, journal entries, supplier watchlist |
| `pipeline.py` | read → reconcile → write, with validation and a progress callback |
| `write_working.py` | Output 1 (dashboard, summary, 28 sheets, live formulas, cell links, charts) |
| `write_master.py` | Output 2 (updated pending master) |
| `gui.py` | the tkinter window |
| `detect.py` | which workbook is which |
| `main.py` | CLI entry, chooses window vs folder mode |

---

## 4. The reconciliation logic

### Matching passes (`match.py`)

Passes run **pass-major** — every pass runs across the whole population before the
next begins — so a weak match can never take a document a later row would have
matched exactly.

1. **Exact** — GSTIN + document number, character for character
2. **Normalised** — GSTIN + document number ignoring case, separators, leading zeros; tax must agree
3. **Partial** — GSTIN + last 6 alphanumerics, tax agrees, exactly one candidate
4. **Probable** — GSTIN + same tax + invoice dates within 45 days, exactly one candidate

When a non-exact pass matches, the 2B document number is written into the books row's
**`Update Doc. No.`** column. That is the same manual correction the user makes by hand,
and it makes the live SUMIFS in Excel agree with the Python verdict.

### One-sided amount test (`match.apply_group_verdict`)

Credit is limited to what is booked, so the amount test is **not symmetric**:

- books and GSTR-2B agree within tolerance          -> `Matched`
- GSTR-2B is the higher of the two, on every head   -> `Matched - GSTR-2B higher`
- the books are the higher of the two               -> `Not Matched`

Claiming the books figure when GSTR-2B carries more costs nothing; the other way round
over-claims. `claim_side` tells `apply_group_verdict` which list holds the books, because
the test flips between the two sheets.

**The sign guard is load-bearing.** `TS2262707AB56328` in the July fixture is -408.00 in
the books and +407.73 in GSTR-2B. Without `same_sign` the one-sided test would match a
debit note to the invoice it reverses. Every head must point the same way.

`_verdict_formula` in `write_working.py` writes the same three-way test into Excel,
including the sign products, so the workbook still reaches the verdict on its own. The
formula now also checks SGST and cess, which the old one did not; it relied on SGST
mirroring CGST.

Rows matched this way stay on `Require Correction` under Kind `GSTR-2B higher`, with the
shortfall spelled out. Only the **books** row carries the note; the GSTR-2B row would
state the excess backwards.

### Document number beats a coincidence of amount

`pass_tail` falls back to the document number alone when exactly one candidate carries it
and the amount test is off. A number that agrees is better evidence than an unrelated
number that happens to carry the same amount, which is all `pass_probable` has to go on.

### Notes matched on value (`match.is_note`, `pass_note`)

A debit note we raise is a credit note in the supplier's GSTR-1, so it reaches GSTR-2B
under their number. `pass_note` matches on GSTIN, sign and amount with exactly one
candidate, ignoring the document number, and is accepted outright at the accountant's
instruction. Setting: `match_notes_on_value`.

On the July fixture it fires once within the month and never cross-month, because none of
the six pending debit notes has any counterpart note in that month's GSTR-2B at all. What
is there for the same suppliers are positive invoices of the same value, already matched
to their own book rows. Do not be tempted to drop the sign test to make those match.

### Confirming probable matches (`decisions.py`)

A probable match is a suggestion. **Its credit is claimed** unless the accountant rejects
it: the pass rewrites `upd_doc_no`, so the row is matched in Python and in Excel alike.
The accountant was asked and chose to keep it that way, with a remark on the row rather
than the credit held back. `probable_match_unconfirmed` in settings.json switches this to
`hold` if that is ever wanted.

The `Confirmed` column on `Probable Matches` is read back on the next run, from three
places, weakest first, so the freshest answer wins:

1. `Probable Match Decisions` in the pending master given as file 3 (the history)
2. the same sheet in the master this tool wrote for the same period, if it is still there
   (so a decision survives the working paper being deleted)
3. the `Confirmed` column of the working paper already in the output folder, which is
   where the accountant actually types

Decisions are keyed on `(GSTIN, document number as booked, matched-against document
number)`, so they survive re-runs, re-sorting and next month's file.

**A rejection undoes the binding rather than overriding the verdict.** `engine._unbind`
puts `upd_doc_no` back to the number the voucher was booked under, and the existing SUMIFS
then reaches Not Matched by itself. Do not replace this with a second rule that Python
applies and Excel does not, or the two will drift apart.

A rejection kills the guess, not the invoice: only `pass_probable` consults the blocked
set, so if the document numbers later agree on their own the invoice matches normally.
Rejections not re-suggested this month are listed in a second block at the foot of the
sheet so the accountant can change their mind.

Two traps, both hit during development:
- the decisions sheet in the master carries document numbers, so `read_master.read` must
  skip it by name or it becomes phantom pending items
- the second block on `Probable Matches` repeats the headings, and the reader took the
  word "Confirmed" in the heading as a Yes. `verdict()` now accepts only y/yes/true/1 and
  n/no/false/0, and `_is_header_repeat` skips repeated heading rows

Two reservation sets, and the distinction matters:
- `taken` — hard consumption. Fuzzy passes and all cross-month passes add to it.
- `reserved` — every match adds to it. Fuzzy passes skip reserved rows; the exact pass
  does not. Within a month several book lines may legitimately share a document number
  and are compared on the **group total**, so exact matches must not consume — but they
  must still reserve, or a probable match steals a document already matched on its number.

### The verdict

`apply_group_verdict` compares group totals on both sides, keyed on
`(GSTIN, document number)` — exactly what the SUMIFS pair in the workbook computes.
Tolerance is per tax head (default Rs 1), and **a counterpart must exist**
(`COUNTIFS(...) > 0` in the formula, `t["n"] > 0` in Python). All four heads including
cess are compared.

### Cross-month matching

- **Pass B** — this month's books against 2B items carried in the master
- **Pass C** — this month's 2B against book items carried in the master

Both run with `consume_exact=True, require_amount=True`. This is stricter than
within-month matching on purpose (see the bugs section).

A pending book item that appears in this month's 2B is **released**: added back to
Table 4(A)(5) and shown on `Deferred ITC Reversal`.

### Table build-up (`engine.reconcile`)

```
Table 4(A)(5) = books all other ITC
              − eligible ITC booked but not in GSTR-2B   (deferred)
              + ITC deferred earlier, now in 2B          (released, net of time-barred)

Table 4(B)(1) = the Tally "Ineligible ITC" register, in full
Table 4(A)(1) = imports per GSTR-2B  (settings: 2B or BOOKS)
Table 4(A)(2) = import of services per books
Table 4(A)(3) = reverse charge per books
Table 4(A)(4) = ISD per GSTR-2B
Table 4(C)    = 4(A) total − 4(B)
```

---

## 5. Domain decisions — read before "improving" anything here

**Blocked credit comes only from Tally's Ineligible ITC register.**
The original sample working showed 4(B)(1) IGST as books-ineligible *plus the whole
RCM IGST*, which looked like a judgment call. It is not: Tally's Ineligible ITC register
already contains the RCM lines. Verified to the paisa on two months. Heuristics were
written first and then deleted. `settings.json` still has `rcm_ineligible_keywords`, used
**only** if that register is missing, and the Summary sheet records which basis was used.

**Ineligible items not in 2B are still claimed in 4(A)(5) and reversed in 4(B)(1).**
Net effect nil. This matches the client's established presentation — replicated
deliberately, not an oversight.

**Only *eligible* items missing from 2B are deferred.** Blocked credit missing from 2B
is not deferred, because it gets reversed anyway.

**Section 16(4).** Credit released from an earlier month is not claimed if 30 November
of the following financial year has passed; it goes to `Require Correction` as
time-barred. The master still carries 2,095 open 2B rows from FY 24-25, so this is live.
Toggle: `apply_section_16_4_time_bar`.

**Credit notes are carried negative.** Sign is decided per row from the document-type
cell, handling both full words and the `C`/`D` codes some exporters emit. A blank note
type raises a warning rather than a guess.

**The sample file had `RCM-2B` and `IMPG-2B` swapped.** This tool names them correctly.

---

## 6. Bugs found by adversarial review — do not reintroduce

An independent review found these in the first working version. All are fixed and have
regression evidence; the fixes are load-bearing.

1. **Double-counted credit (critical).** A repeated book entry matched cross-month was
   claimed twice, because `cross_remark` forced `_matched = True` and skipped the group
   verdict, and exact matches did not consume. Fix: `consume_exact=True` on the
   cross-month passes. Test: duplicate voucher 1573 in the books — 4(A)(5) CGST must not
   move.
2. **Cross-month matched on document number alone**, no tolerance. Over-claimed ₹15.25 on
   `IN-1319` and silently swallowed ₹46.82 on `IN-137`. Fix: `require_amount=True`.
3. **A probable match stole an exact partner** (`IS26/4520` vs `DS26/1143`, ₹180 CGST +
   ₹180 SGST wrongly deferred). Fix: pass-major ordering plus the `reserved` set.
4. **ISD/ECO credit notes were added instead of subtracted.** Fix: sign from the row's
   own document type, not from the section.
5. **Note-type codes `C`/`D` were not understood** — only the literal word "credit".
6. **A missing Tally sheet was silently zero** — one run produced a *negative* net ITC with
   no warning. Fix: `read_tally` collects warnings; a missing `All Other ITC` is a hard stop.
7. **Amendment rows carried the superseded document number**, because the alias matcher's
   substring stage matched "invoice number" inside "original invoice number". Fix: blank
   the original-detail columns out of the search entirely.
8. **`carry_forward_months` was dead code** with no time bar. Replaced by the 16(4) check.
9. **The master lost its Notes and Cleared-in columns on every cycle** (alias `"remarks"`
   does not match header `"Notes"`).
10. **Cess was never compared** in the verdict.

Confirmed fine, do not re-investigate: Excel formula anchors in every degenerate case
(empty lists included), no crash on a first month with no master, `cleared` rows correctly
excluded from re-matching, amendments do not double count against their originals,
4(B)(1) allocation is 1:1 against the register.

---

## 7. Output structure

`GSTR_Working_*.xlsx`, 28 sheets in this order:

`Dashboard`, `Summary`, `GSTR-3B`, `All other ITC-4A(5)-Calculation`, `Entries`,
`Supplier Watchlist`, `Require Correction`, `Probable Matches`,
`Cleaned Doc No Matches`, `Deferred ITC`, `Deferred ITC Reversal`,
`ITC only in books; Not in 2B`, `ITC only in 2b; Not in Books`, `Ineligible ITC`,
`All other ITC`, `GSTR 2B`, `RCM ITC Books`, `RCM-2B`, `IMPS Books`, `IMPG Books`,
`IMPG-2B`, `ISD-2B`, `Table 3.1a`, `Table 3.1b`, `Table 3.1c`, `Table 3.1d`,
`Table 3.1e`, `_ChartData` (hidden).

`ISD-2B`, `Table 3.1c` and `Table 3.1e` were added so that every figure reported in the
return has a schedule to be linked to. Before that, Table 4(A)(4) appeared in the return
with no supporting sheet anywhere in the workbook.

- `All other ITC` — header row 10, data from row 11, totals row 9. Columns A–X.
  Column X (`Notes`) carries the confirmation remark on a probable match.
- `GSTR 2B` — header row 3, data from row 4, totals row 2. Columns A–AF.
- `Probable Matches` — written by its own `_write_probable`, not `_listing`, because it
  has two blocks and a dropdown. Header row 5, data from row 6, `Confirmed` in column Q.
  The reader finds its columns by heading text, so the headings are load-bearing: change
  `Doc No. as booked`, `Matched against document`, `GSTIN` or `Confirmed` and the marks
  stop being read back. It warns rather than silently losing them.
- These two carry the live SUMIFS grid. Formula ranges are bounded, not whole-column.

### What is still typed rather than linked

After the linking pass, only these carry a value rather than a formula, and each has a
reason:

- the **opening credit ledger** on `ITC Set-off`, which comes from outside the workbook
- the **three allocation rows** on `ITC Set-off`, which are the output of the statutory
  order and cannot be written as a cell formula
- **closing balances** on `Ledgers Reconciliation`, read from the Tally ledgers workbook
- the **counts** on the Dashboard tiles, and the match percentage

Everything else, including every money tile on the Dashboard, is a formula. `ITC Set-off`
derives Credit available, Payable in cash, Credit utilised, Closing balance and Output
liability met out of credit from the rows above them, and points at `GSTR-3B` for Table
4(C), Table 3.1(a) and Table 3.1(d). `Ledgers Reconciliation` points its expected column at
`ITC Set-off` and at its own deferred block.

### Everything is cell-linked

The figures on `Entries`, `Summary` and `GSTR-3B` are **formulas pointing at the schedule
behind them**, not repeated values. The accountant asked for this: the return has to tie
out to its backup and recalculate if a backup is corrected.

`_listing` returns an anchor `{sheet, total, first, last, cols}` and `build` collects them
in `anchors`. `_head_col` finds a tax head's column **by its heading text**, so a schedule
whose layout differs (Require Correction, Probable Matches) still resolves correctly and a
moved column does not silently point at the wrong figure. `_ref` is a whole-schedule
total, `_sumifs` a filtered part, `_awaiting_links` the probable matches still unanswered.

Rules that must hold:
- **A figure must never move because it was linked.** `_write_3b` links a 3.1 line only
  when the register total actually ties to the Tally 3B summary (`_ties`); otherwise it
  keeps the reported value and says so in the Source column. Same idea in
  `engine.journal_entries`, which points an entry at its schedule only when the two agree.
- Subsets are linked with SUMIFS on a stable column, never on wording. `Require
  Correction` gained a `Kind` column purely so the section 16(4) figure could key on it.
- "Matched" is tested as `Matched*`, because a cross-month match reads
  "Matched with GSTR-2B of Jun'26".
- Unanswered probable matches are `SUM - SUMIFS("Yes") - SUMIFS("No")`, because a blank
  cell is not something SUMIFS can be trusted to test for.
- A single row on `GSTR-3B` has no range, so `_apply_links` skips the count there.

Verified by recalculating in Excel: **0 disagreements on GSTR-3B, 0 on the Summary, 0
across the 874 verdict rows, 0 formula errors in either workbook.**
- Every count on `Summary` is a hyperlink (`Hyperlink(ref=..., location="'Sheet'!A1")` —
  assigning a plain string makes an *external* link, which is wrong).

### Charts

Native Excel charts, source data on the hidden `_ChartData` sheet. Palette from the
`dataviz` skill, validated: series 1 `#2A78D6`, series 2 `#EB6834`.

Amounts in this return span three orders of magnitude, so **the position chart counts
documents and the money chart shows only exception buckets**. A bar chart with the ₹21m
matched figure beside a ₹90k one draws one bar and four slivers — this was tried and
rejected. Month buckets are keyed on `month_sort_key`, not the label, or `Dec-2025` and
`Dec-25` split into two bars.

---

## 8. The pending master

Previous data is **retained in full**, including historical remarks. Rows cleared this
month are stamped `Matched with month July 2026` (the user asked for this wording; the
year is included because the master spans three financial years), plus columns
`Invoice month`, `Matched in month`, `Matched against`, `Ageing (months)`, `Status`.

`Status = Cleared` rows are greyed and excluded from re-matching, so credit cannot be
claimed twice. `read_master.is_cleared` treats any remark starting with "Matched" (but
not "Not ") as cleared, which is backward compatible with the client's own hand-written
remarks.

New rows are appended to whichever sheet already holds the newest data, so the client's
existing sheet structure survives. A new FY starts a new sheet.

It also carries a `Probable Match Decisions` sheet. `read_master.read` skips it by name;
it is read only by `decisions.py`.

It also carries a `Registers Seen` sheet: one row per month per Tally register, with the
sheet name, voucher count and tax totals. This is the only way to tell a register that is
genuinely nil from one Tally has stopped exporting, since nothing in the current month's
file can distinguish them. `pipeline._register_gap_alerts` compares and warns. Both extra
sheets are skipped by name in `read_master.read`, or they would be read back as pending
items.

---

## 9. Supplier watchlist

Aggregates the pending master by GSTIN. Ranked by **how many separate months a supplier
appears** and how much tax is stuck — not by a single large invoice, because a one-off
big item is not a chronic problem. Statuses: Critical / Serious / Watch / Monitor.
Ageing is reported in its own column rather than overriding the ranking (an early version
let one old ₹144 invoice outrank a chronic supplier).

The sheet is split: **A. Needs action**, then **B. For reference**.

Supplier names are resolved through `_name_directory` across every source, because the
FY 24-25 master sheet has two `Particulars` columns and the naive mapping picked the
Tally To/By marker, showing every supplier as "To".

---

## 9a. The window (`gui.py`)

Refined at the accountant's request, in the direction they chose: same layout, tighter.
Navy header band with the period shown as a chip once a run finishes, white cards on light
grey, `#1F3864` for identity and `#2F5597` for action, and colour used only where it
carries a meaning. Three type sizes; anything wanting a fourth is saying too much. The
attention list uses background chips, green when a count is nil, amber for ordinary work,
red for anything that must be cleared before filing.

**The Inputs page is a workflow, not a form.** A stepper across the top
(`_build_stepper`) shows Files, Filing period, Ledgers, Review and run, with each stop
carrying a caption saying what is done. `_refresh_state` is the single place that decides
what is complete and what is missing; it drives the stepper, the per-row status pills, the
review panel and whether the two Run buttons are enabled. Every input variable traces to
it, so nothing can disagree with anything else. Add a new input by passing `required=` and
`step=` to `_row` and adding a line to `_refresh_state`, not by writing new state logic.

Status is never carried by colour alone: each row shows `Required` or `Optional` in words
and `Ready` or `Not found` as text, with the edge marker only reinforcing it. That is a
brand constraint as much as an accessibility one, since the palette has no green.

**The tab strip is hand built, not a `ttk.Notebook`.** `Inputs` and `Results` sit on the
left, `Run reconciliation` and `Clear / Reset` on the right, in one band, so the primary
action is never below the fold. `_show(key)` packs one page and forgets the other; there
is no `self.nb` any more, so use `app._show("results")` in tests. The progress bar is two
frames behind a `_Bar` shim that keeps the old `pbar["value"]` interface, because the
themed widget paints itself in the platform's colours rather than the brand's, and it
hides itself when idle.

**Month of reconciliation.** A month and year box on step 2. The period still comes from
the Tally export, which is the only trustworthy source; the choice is a **cross-check**,
and a disagreement stops the run before anything is written (`pipeline._period_check`,
`--month YYYY-MM` on the command line). The month deliberately defaults back to
"Read it from the export" every time and is not remembered, because a stale month left
over from last time would turn the safeguard into a nuisance. The year is remembered.

---

## 9b. Sample files (`Sample/`)

Three invented workbooks for demonstrations, plus `make_sample_files.py` that builds them.
Company *Meridian Traders Private Limited*, period **August 2026**, master carrying June
and July 2026 and one April 2024 item. Nothing in them comes from the client's books.

They are **not a second regression fixture**; `Input/` remains the fixture. The sample set
exists because a demonstration on real data is not appropriate and because the July file
set does not exercise ISD, imports of both kinds, or a rejected probable match carried
forward.

The `fate` column in `BOOKS` decides what GSTR-2B will contain for each purchase, which is
how the exception cases are produced: `exact`, `norm`, `tail`, `probable`, `none`,
`wrong_gstin`, `wrong_head`, `value_diff`, `group`, `credit`. The Tally sheets are written
in the same shapes the real export uses, including the shorter layout Tally gives the
Ineligible ITC register, so the sample exercises that reader path as well.

Verified on the sample set: 0 formula errors in either workbook, 0 verdict disagreements
between Excel and Python across 59 rows.

---

## 9c. Set-off of credit (`setoff.py`, `read_ledger.py`)

The closing journal entry is the real utilisation, not a full offset of Table 4(C).

Order is fixed by sections 49(5) and 49A: the IGST balance is used first and in full,
then CGST credit against CGST and then IGST, then SGST against SGST and against IGST but
**only once CGST credit is exhausted**. CGST never pays SGST, nor SGST CGST. Rule 88A
leaves one free choice, the order in which a surplus IGST balance is applied to CGST and
SGST; the accountant chose CGST first (`igst_credit_order`).

**Reverse charge under Table 3.1(d) is deliberately left out of the set-off.** Section
49(4) allows credit against output tax only, and tax under reverse charge is not the
recipient's output tax. It is shown separately on the sheet as payable in cash.

Output liability comes from the Table 3.1(a) register. Opening balance comes from
`itc_ledger_opening` in settings, typed on the Run tab, or from a credit ledger workbook
which wins if one is given.

`read_ledger.py` is the only reader written without a real file to work from, so it is
deliberately suspicious: the workbook must name itself a credit ledger somewhere, and the
row taken must call itself a balance. An earlier version fell back to "the last numeric
row", which read the pending master as a credit ledger with a balance of 4.42. It returns
nothing rather than zeros, because zeros would silently overstate the cash payable.

Sheet `ITC Set-off` shows the working; the entry's amounts are formulas pointing into it.

---

## 9d. EXI branding (`brand.py`, `assets/`)

Everything visual comes from `EXI_Brand_Guidelines.pptx`. `brand.py` is the single
source; the window and the workbook both read it, so they cannot drift apart.

```
Blue   #272361   primary, leads          Brown  #412312   secondary
Black  #000000   White  #FFFFFF          Red    #D83030   accent, digital only
Ratio  Blue 60, White 25, Brown 10, Red 5
Type   Fira Sans, bold or semi-bold headings, regular body
       Fallback for Office and email: Calibri, then Arial
Shapes Angular, inspired by the logo. Clean margins. NO ROUNDED EDGES.
Avoid  Cartoons, clipart, emoticons, loud graphics
```

**The guide owns no green and no amber**, and a reconciliation has three states, so the
three states are carried on the three brand colours: blue agreed, brown needs attention,
red a difference. Red is the guide's own accent for exactly that. `FILL_GREEN` in
`xlstyle.py` is now a blue tint and keeps its name only so callers did not all have to
change. If green is ever wanted back, it is one line in `brand.py`.

**No rounded edges is load-bearing.** Excel rounds chart frames by default, so every
chart sets `roundedCorners = False`. Do not remove it.

Chart series are brand blue and brand brown. They differ in hue rather than only in
lightness, so they stay apart for a reader with a colour-vision deficiency; that is why
the earlier validated pair could be replaced.

Fonts: the window walks `FONT_STACK` and takes the first installed, which on this machine
is Calibri, the fallback the guide names. The workbook stays on Calibri outright, since
Fira Sans cannot be relied on wherever the file is opened.

`assets/` holds the logo, prepared by `assets/make_assets.py` from the guidelines deck.
Nothing is stretched, rotated or recoloured; the white version is the black one with the
ink turned white, which the guide lists as an approved format. **Pillow is used only at
preparation time.** The window reads the PNG through tkinter, and the workbook's logo is
best effort: `_brandmark` falls back to type if Pillow is absent, so the tool still runs
on openpyxl alone.

Data label formats come from the `_ChartData` cells, not from the chart. Excel ignores the
chart-level `numFmt`, so formatting the source cells is the only thing that works.

---

## 9e. Ledgers reconciliation (`read_gl.py`, `ledgers.py`)

Nine GST ledgers out of Tally, in one workbook, against what the entries will do to them.

```
GST Inputs            IGST-Input, CGST-Input, SGST-Input
GST Deferred Inputs   IGST/CGST/SGST Deferred A/c
GST Payables          IGST/CGST/SGST Payable
```

Everything is held **debit positive**, so a payable is negative internally and prints in
brackets. `read_gl` accepts either a sheet per ledger, Tally style ending in a Closing
Balance, or one sheet listing names against balances. Which name is which ledger belongs
to the chart of accounts, so the spellings live in `settings.json` under `ledger_names`.

Expected positions, and each is a real control:

```
input ledgers      the closing electronic credit ledger, from the set-off
deferred ledgers   eligible open book items in the master, plus what is deferred now
payable ledgers    the cash payable after the set-off
```

The movement column on the sheet is a **live SUMIF over the Entries sheet**, not a figure
repeated from Python, so editing an entry moves the reconciliation with it. That is why
`ledgers.ENTRY_NAME` has to match the names `engine.journal_entries` writes.

**Entry lines are matched exactly, never guessed at.** `ENTRY_LEDGERS` is keyed on slugs
of the names the engine writes, and a leading "To" is stripped, since that marks the
credit side of the same ledger. Anything unmatched is reported rather than folded into one
of the nine. `IGST Payable (RCM)` is deliberately a different ledger from `IGST Payable`:
reverse charge is paid in cash and never set off, so `read_gl._match_ledger` refuses to
match across the presence of "rcm".

**A time-barred release is a genuine reconciling item, not a difference.** It leaves the
pending master because it matched, but no entry takes it out of the deferred ledger, so
the ledger keeps it until somebody writes it off. The sheet shows it on its own line and
says so. Adding a write-off entry would change the figures and has not been agreed.

Two traps hit while building it:
- a nil ledger is a reading, not a missing ledger. The reader tests whether the cell is
  **present**, not whether it is non-zero, or a genuinely nil deferred ledger reads as
  "not found".
- a subtitle reading "closing balances as at 31-Aug" was being taken for the header row.
  Header cells are now required to be short, not prose.

---

## 9f. The annual reconciliation (`annual.py`, `write_annual.py`)

**Kept apart from the monthly run on purpose**, at the accountant's instruction: its own
tab, its own inputs, its own workbook `Annual_Reconciliation_FY<yy><yy>.xlsx`. It never
writes a pending master and never touches the monthly outputs, so a year can be looked at
without disturbing months already filed.

Inputs are a **year-long books export plus one GSTR-2B download per month**, because the
portal has no annual GSTR-2B. `annual.merge_2b` pools them into one population, tagging
each row with the file it came from.

**The point is matching across the whole year.** The monthly run asks whether April's
invoice is in April's GSTR-2B; the annual run lets it match November's. It reuses
`engine.reconcile` unchanged, just handed a year of books and a year of 2B, so the two
paths cannot drift apart.

`by_month` groups books on the month booked and GSTR-2B on the period reported, because
the gap between those two columns is the lag being financed.

**GSTR-9**: Tables 6, 7 and 8, with only the lines the tool can actually derive filled.
Anything without a basis is shaded and says "Not derived" rather than being guessed at.

**GSTR-9C Table 12** is the deferral mechanic read over a year:
`12D = 12A + 12B - 12C`, that is books, plus credit booked earlier and claimed now, less
credit booked now and claimed later. **Watch the signs**: an earlier version had 12B and
12C inverted. It should come to nil over a complete year; a difference usually means the
books export does not cover the whole year, which is exactly what happens if you test it
with a single month's export.

`write_working.build` gained an `extra` hook so the annual sheets can be added without
reopening the file. Reopening with openpyxl would drop the Dashboard charts.

---

## 10. Open items / possible next steps

- ~~The 14 probable matches are unconfirmed.~~ **Done.** See the confirmation section
  above. The count on screen and on the Summary is now those still *awaiting* an answer.
- **`Run in folder mode` cannot be scheduled safely as-is** — it would need the previous
  master chosen deliberately rather than auto-detected.
- ~~Re-running the same month needs the *previous* master.~~ **Done.**
  `read_master.cleared_in_period` finds rows the master already records as matched in the
  period being worked on, or later. `pipeline._master_period_alert` turns that into
  `R["alerts"]`, shown at the top of the Summary sheet, boxed on the console and at the
  top of the window. The accountant asked for a warning, not a stop: the run finishes and
  the figures stand. This is the one input mistake that makes a return too *small*, and it
  leaves no trace in the numbers, which is why it says so in dozens of words rather than
  one line among the other notices.
- `identify()` in `pipeline.py` warns on swapped files but only checks sheet names.
- The GUI has no per-row drill-down; everything routes to the workbook.
- ~~Only tested against this client's Tally export layout.~~ **Done, within limits.**
  `read_tally.REGISTERS` now states what each register must yield. A register that feeds
  Table 4 and whose tax columns cannot be identified raises an entry in `tally["errors"]`,
  and `pipeline.execute` refuses to write anything. Table 3.1 sheets only warn, and their
  rows are discarded so 3.1(d) falls back to IMPS plus RCM rather than publishing a zero.
  A new Tally layout still needs new spellings in `VOUCHER_ALIASES`; the difference is
  that it now says so instead of totalling nil.

---

## 11. House rules for this codebase

- **No emojis, no em dashes** in code, comments, documentation or UI text. The user asked
  for this explicitly.
- Comments explain *why*, never *what*. Delete a comment rather than restate the code.
- User-facing text is plain English aimed at an accountant, not a developer: "looks like
  it is open in Excel", not "PermissionError".
- Every business rule that an accountant might want to change belongs in `settings.json`,
  not in the code.
- Never let a missing input read as zero. Warn loudly or stop.
- If the Python verdict and the Excel formula can disagree, that is a bug in itself.
- Keep the July fixture in `Input/` working. It is the regression test.

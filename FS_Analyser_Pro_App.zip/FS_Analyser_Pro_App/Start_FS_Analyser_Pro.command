#!/bin/bash
cd "$(dirname "$0")"

echo "============================================"
echo "  FS Analyser Pro - Starting Up"
echo "============================================"
echo ""

if ! command -v python3 &> /dev/null
then
    echo "ERROR: Python 3 was not found on this computer."
    echo "Please install it from https://www.python.org/downloads/"
    read -p "Press Enter to close..."
    exit 1
fi

echo "Checking / installing requirements (only installs what's missing)..."
python3 -m pip install -r requirements.txt --quiet

echo ""
echo "Launching FS Analyser Pro in your browser..."
echo "(Close this window, or press Ctrl+C, to stop the app)"
echo ""
python3 -m streamlit run app.py

read -p "Press Enter to close..."

"""
FS Analyser Pro — Streamlit App
Build: 2026-08-06.8

Verified this build via streamlit.testing.v1.AppTest — actually clicked
every button (all 5 module reports, PPTX, PDF, Consolidated ZIP) through
the real Streamlit runtime for both HUL and Nestle test filings, plus
the fresh/no-upload state. Fixed a `use_container_width` deprecation
(replaced with `width='stretch'`) surfaced by this testing.

Added: Module 5 (Risk & Auditor Analysis), an interactive Plotly
Dashboard, and automated PowerPoint + PDF report generation — on top of
the existing general-purpose-company scope note, disclaimer, and
Modules 1-4 (each generalized across HUL and Nestlé's differing report
conventions; all pass their independent tie-out checks).

Run with:  streamlit run app.py
"""
import io
import os
import sys
import zipfile
import tempfile
from datetime import datetime

import streamlit as st

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from fs_extractor.extractor import FinancialStatementExtractor
from fs_extractor.export import to_excel as export_module1_excel
from fs_extractor.export_ratios import to_excel_module2, to_excel_module3, to_excel_module4
from fs_extractor.trend_extractor import extract_long_term_track_record
from fs_extractor.trends import build_trend_analysis
from fs_extractor.ratios import build_ratio_analysis
from fs_extractor.red_flags import build_red_flag_report
from fs_extractor.risk_auditor import build_risk_auditor_report
from fs_extractor.export_risk_auditor import to_excel_module5
from fs_extractor.pptx_report import build_pptx_report
from fs_extractor.pdf_report import build_pdf_report
import fs_extractor.dashboard as dash

BUILD_ID = "2026-08-06.8"


# ----------------------------------------------------------------------------
# Page config & styling
# ----------------------------------------------------------------------------
st.set_page_config(page_title="FS Analyser Pro", page_icon="📊", layout="wide")

NAVY = "#1F3864"
GOLD = "#BF9000"

st.markdown(f"""
<style>
    .stApp {{ background-color: #FAFAFA; }}
    .app-header {{
        background: linear-gradient(90deg, {NAVY} 0%, #2E4E8C 100%);
        padding: 28px 36px;
        border-radius: 8px;
        margin-bottom: 28px;
    }}
    .app-header h1 {{
        color: white;
        font-size: 34px;
        font-weight: 700;
        margin: 0;
        letter-spacing: 0.5px;
    }}
    .app-header p {{
        color: {GOLD};
        font-size: 15px;
        margin: 4px 0 0 0;
        font-weight: 500;
    }}
    .section-card {{
        background: white;
        border: 1px solid #E0E0E0;
        border-left: 4px solid {GOLD};
        border-radius: 6px;
        padding: 18px 22px;
        margin-bottom: 16px;
    }}
    .section-card h3 {{
        color: {NAVY};
        margin-top: 0;
        font-size: 18px;
    }}
    .status-ok {{ color: #2E7D32; font-weight: 600; }}
    .status-warn {{ color: #B8860B; font-weight: 600; }}
    .status-fail {{ color: #C00000; font-weight: 600; }}
    div.stButton > button {{
        background-color: {NAVY};
        color: white;
        border-radius: 6px;
        border: none;
        padding: 10px 18px;
        font-weight: 600;
    }}
    div.stButton > button:hover {{
        background-color: {GOLD};
        color: {NAVY};
    }}
    div.stButton > button:disabled, div.stButton > button:disabled:hover {{
        background-color: #CCCCCC !important;
        color: #777777 !important;
        cursor: not-allowed;
        opacity: 1;
    }}
    div.stDownloadButton > button {{
        background-color: {GOLD};
        color: {NAVY};
        border-radius: 6px;
        border: none;
        padding: 10px 18px;
        font-weight: 700;
    }}
    .scope-note {{
        background: #FDF2CC;
        border-left: 4px solid {GOLD};
        border-radius: 6px;
        padding: 10px 18px;
        margin-bottom: 24px;
        font-size: 13px;
        color: #5C4A00;
    }}
    .app-footer {{
        margin-top: 48px;
        padding: 18px 22px;
        border-top: 2px solid {NAVY};
        background: #F2F2F2;
        border-radius: 6px;
        font-size: 12px;
        color: #444444;
        line-height: 1.6;
    }}
    .app-footer b {{
        color: {NAVY};
    }}
</style>
""", unsafe_allow_html=True)

st.markdown(f"""
<div class="app-header">
    <h1>📊 FS Analyser Pro</h1>
    <p>AI-Assisted Financial Statement Analyser &nbsp;|&nbsp; Extraction, Ratios, Trends, Red Flags, Risk &amp; Auditor Analysis, Dashboard &amp; Reports</p>
</div>
""", unsafe_allow_html=True)
st.caption(f"Build {BUILD_ID} — if you don't see this exact build number, you're running an old copy of app.py.")

st.markdown("""
<div class="scope-note">
⚠️ <b>Scope:</b> This application is built for a <b>general-purpose, non-financial-services company</b>
reporting under Ind-AS Schedule III (Division I). It does <b>not</b> incorporate industry-specific ratios
or disclosures, and is <b>not applicable</b> to banks, NBFCs, insurance companies, or other niche/regulated
financial-services entities, which follow a different Schedule III division and a materially different
statement format (e.g. Balance Sheet presented by order of liquidity, not current/non-current
classification). Using this tool on such an entity's filing will produce unreliable or meaningless results.
</div>
""", unsafe_allow_html=True)

# ----------------------------------------------------------------------------
# Session state
# ----------------------------------------------------------------------------
if "company" not in st.session_state:
    st.session_state.company = None
if "pdf_path" not in st.session_state:
    st.session_state.pdf_path = None
if "pdf_name" not in st.session_state:
    st.session_state.pdf_name = None
if "generated_files" not in st.session_state:
    st.session_state.generated_files = {}  # label -> (filename, bytes)
if "trends" not in st.session_state:
    st.session_state.trends = None
if "trend_warnings" not in st.session_state:
    st.session_state.trend_warnings = []
if "ra_sa" not in st.session_state:
    st.session_state.ra_sa = None
if "ra_co" not in st.session_state:
    st.session_state.ra_co = None
if "rf_sa" not in st.session_state:
    st.session_state.rf_sa = None
if "rf_co" not in st.session_state:
    st.session_state.rf_co = None
if "risk_report" not in st.session_state:
    st.session_state.risk_report = None

WORKDIR = tempfile.mkdtemp(prefix="fs_analyser_")


# ----------------------------------------------------------------------------
# Step 1 — Upload
# ----------------------------------------------------------------------------
st.markdown('<div class="section-card"><h3>Step 1 — Upload Annual Report</h3></div>', unsafe_allow_html=True)

uploaded = st.file_uploader("Upload the company's Annual Report (PDF)", type=["pdf"])

if uploaded is not None and uploaded.name != st.session_state.pdf_name:
    pdf_path = os.path.join(WORKDIR, uploaded.name)
    with open(pdf_path, "wb") as f:
        f.write(uploaded.getbuffer())
    st.session_state.pdf_path = pdf_path
    st.session_state.pdf_name = uploaded.name
    st.session_state.company = None  # force re-extraction
    st.session_state.generated_files = {}

company_name_input = st.text_input("Company name (optional, shown on report covers)", value="")

if st.session_state.pdf_path and st.session_state.company is None:
    with st.spinner("Reading and validating the annual report — this can take a minute for large filings..."):
        fx = FinancialStatementExtractor(st.session_state.pdf_path)
        company = fx.extract()
        if company_name_input:
            company.company_name = company_name_input
        st.session_state.company = company
    with st.spinner("Scanning for a company-disclosed multi-year 'Long-term Track Record' table "
                     "(used by the Trend sheet) — this is a second, separate pass over the PDF..."):
        try:
            trend_data = extract_long_term_track_record([st.session_state.pdf_path])
            st.session_state.trend_warnings = trend_data.warnings
            st.session_state.trends = build_trend_analysis(trend_data) if trend_data.years else None
        except Exception as e:
            st.session_state.trend_warnings = [f"Trend extraction raised an error and was skipped: {e}"]
            st.session_state.trends = None
    with st.spinner("Computing ratios and red-flag checks..."):
        try:
            m_sa = company.mapped.get("standalone")
            m_co = company.mapped.get("consolidated")
            st.session_state.ra_sa = build_ratio_analysis(m_sa) if m_sa else None
            st.session_state.ra_co = build_ratio_analysis(m_co) if m_co else None
            st.session_state.rf_sa = build_red_flag_report("standalone", m_sa, st.session_state.ra_sa) if m_sa else None
            st.session_state.rf_co = build_red_flag_report("consolidated", m_co, st.session_state.ra_co) if m_co else None
        except Exception as e:
            st.session_state.ra_sa = st.session_state.ra_co = None
            st.session_state.rf_sa = st.session_state.rf_co = None
    with st.spinner("Scanning for the Risk Register and Independent Auditor's Report(s) — this is a third, "
                     "separate pass over the PDF and can take a minute or more on a large filing..."):
        try:
            st.session_state.risk_report = build_risk_auditor_report(st.session_state.pdf_path)
        except Exception as e:
            st.session_state.risk_report = None
            st.warning(f"Risk & Auditor scan raised an error and was skipped: {e}")

company = st.session_state.company

if company is not None:
    passed = sum(1 for v in company.validation_results if v["status"] == "PASS")
    failed = sum(1 for v in company.validation_results if v["status"] == "FAIL")
    total = len(company.validation_results)
    if not company.statements:
        st.error("Could not locate any financial statements in this PDF. It may not follow the standard "
                 "Ind-AS Schedule III title convention this engine looks for.")
    elif failed:
        st.markdown(f'<span class="status-warn">⚠ Extracted with {failed} of {total} tie-out checks failing '
                    f"— review Module 1 output before relying on downstream ratios.</span>", unsafe_allow_html=True)
    else:
        st.markdown(f'<span class="status-ok">✓ Extracted and validated — {passed} of {total} arithmetic '
                    f"tie-out checks passed.</span>", unsafe_allow_html=True)
    st.caption(f"Statements found: {', '.join(company.statements.keys()) if company.statements else 'none'}")
    st.caption(f"Mapped bases available for ratio analysis: "
               f"{', '.join(company.mapped.keys()) if company.mapped else 'NONE — this is why the Module 2 and Module 4 buttons below will be disabled'}")
    if st.session_state.trends:
        st.caption(f"Long-term Track Record table found: {len(st.session_state.trends)} metrics, "
                   f"years {next(iter(st.session_state.trends.values())).years}")
    else:
        st.caption("Long-term Track Record table: not found in this PDF (Trend sheet will be omitted — "
                   "this is expected for reports that don't disclose a multi-year summary table).")
    rr = st.session_state.risk_report
    if rr is not None:
        risk_status = f"{len(rr.risk_entries)} risk(s) found" if rr.risk_register_found else "no structured risk register found"
        auditor_status = f"{len(rr.auditor_findings)} Auditor's Report(s) found" if rr.auditor_findings else "no Auditor's Report found"
        st.caption(f"Risk & Auditor scan: {risk_status}; {auditor_status}.")

st.divider()

# ----------------------------------------------------------------------------
# Step 2 — Section-wise reports
# ----------------------------------------------------------------------------
st.markdown('<div class="section-card"><h3>Step 2 — Generate Section Reports</h3></div>', unsafe_allow_html=True)


def render_module_button(col, module_label, caption, key, disabled, disabled_reason, generate_fn, out_filename, store_key, button_label, mime=None):
    with col:
        st.markdown(f"**{module_label}**")
        st.caption(caption)
        if disabled and company is not None and disabled_reason:
            st.caption(f"⚠ {disabled_reason}")
        if st.button(button_label, disabled=disabled, key=f"btn_{key}"):
            try:
                with st.spinner(f"Generating {module_label}..."):
                    out_path = os.path.join(WORKDIR, out_filename)
                    generate_fn(out_path)
                    with open(out_path, "rb") as f:
                        data = f.read()
                    st.session_state.generated_files[store_key] = (out_filename, data)
                st.success(f"{module_label} report generated — download below.")
            except Exception as e:
                st.error(f"Report generation failed: {e}")
                st.exception(e)
        if store_key in st.session_state.generated_files:
            fname, data = st.session_state.generated_files[store_key]
            ext = os.path.splitext(fname)[1]
            st.download_button(f"⬇ Download ({ext})", data=data, file_name=fname, key=f"dl_{key}", mime=mime)


row1_col1, row1_col2, row1_col3 = st.columns(3)
row2_col1, row2_col2 = st.columns(2)

m1_disabled = company is None or not company.statements if company is not None else True
render_module_button(
    row1_col1, "Module 1 — Financial Statement Extraction",
    "Standalone & Consolidated Balance Sheet, P&L and Cash Flow Statement, with formulas and tie-out validation.",
    "m1", m1_disabled, "No financial statements were located in this PDF.",
    lambda out_path: export_module1_excel(company, out_path),
    "Module1_Extraction.xlsx", "m1", "Generate Extraction Report",
)

m2_disabled = company is None or not company.mapped if company is not None else True
render_module_button(
    row1_col2, "Module 2 — Ratio Analysis",
    "Growth, margin, return, liquidity, leverage, efficiency and per-share ratios — Standalone & Consolidated, formulas disclosed.",
    "m2", m2_disabled, "No mapped financial data available (see 'Mapped bases' line above).",
    lambda out_path: to_excel_module2(company, out_path),
    "Module2_Ratio_Analysis.xlsx", "m2", "Generate Ratio Analysis Report",
)

m3_disabled = company is None or not st.session_state.trends
render_module_button(
    row1_col3, "Module 3 — Long-Term Trend",
    "The company's own disclosed multi-year 'Long-term Track Record' table — CAGR, YoY growth, direction.",
    "m3", m3_disabled, "No 'Long-term Track Record' table was found in this PDF.",
    lambda out_path: to_excel_module3(company, out_path, precomputed_trends=st.session_state.trends,
                                        precomputed_trend_warnings=st.session_state.trend_warnings),
    "Module3_Long_Term_Trend.xlsx", "m3", "Generate Long-Term Trend Report",
)

m4_disabled = company is None or not company.mapped if company is not None else True
render_module_button(
    row2_col1, "Module 4 — Red Flag Detection",
    "9 quantitative, rule-based checks with disclosed thresholds — Standalone & Consolidated. See sheet for scope limits.",
    "m4", m4_disabled, "No mapped financial data available (see 'Mapped bases' line above).",
    lambda out_path: to_excel_module4(company, out_path),
    "Module4_Red_Flag_Detection.xlsx", "m4", "Generate Red Flag Report",
)

m5_disabled = company is None or st.session_state.risk_report is None
render_module_button(
    row2_col2, "Module 5 — Risk & Auditor Analysis",
    "Categorised risk register (where disclosed) + auditor opinion, Key Audit Matters, Emphasis of Matter, ICFR.",
    "m5", m5_disabled, "Risk & Auditor scan has not completed — re-upload the PDF and wait for Step 1 to finish.",
    lambda out_path: to_excel_module5(company, st.session_state.risk_report, out_path),
    "Module5_Risk_Auditor_Analysis.xlsx", "m5", "Generate Risk & Auditor Report",
)

st.divider()

# ----------------------------------------------------------------------------
# Step 3 — Interactive Dashboard
# ----------------------------------------------------------------------------
st.markdown('<div class="section-card"><h3>Step 3 — Interactive Dashboard</h3></div>', unsafe_allow_html=True)
st.caption("Built live from the data already computed above — nothing here re-reads the PDF.")

if company is None or not company.mapped:
    st.info("Upload a PDF and complete Step 1 to see the dashboard.")
else:
    m_sa_dash = company.mapped.get("standalone")
    ra_sa_dash = st.session_state.ra_sa
    rf_sa_dash = st.session_state.rf_sa
    trends_dash = st.session_state.trends
    risk_report_dash = st.session_state.risk_report

    if m_sa_dash and ra_sa_dash:
        kpis = dash.build_kpi_cards(m_sa_dash.fields)
        kpi_cols = st.columns(len(kpis))
        for col, kpi in zip(kpi_cols, kpis):
            delta = f"{kpi['delta_pct']:+.1f}%" if kpi["delta_pct"] is not None else None
            col.metric(kpi["label"], f"{kpi['value']:,.0f}" if kpi["value"] is not None else "n/a", delta)

        st.markdown("##### Revenue / EBITDA / PAT Trend")
        st.plotly_chart(dash.build_trend_line_chart(
            trends_dash, [("turnover", "Turnover"), ("ebitda", "EBITDA"), ("pat", "PAT")]
        ), width='stretch', key="chart_trend")

        c1, c2 = st.columns(2)
        with c1:
            st.markdown("##### Margin Analysis")
            st.plotly_chart(dash.build_margin_chart(trends_dash, ra_sa_dash), width='stretch', key="chart_margin")
        with c2:
            st.markdown("##### Cash Flow")
            st.plotly_chart(dash.build_cash_flow_chart(m_sa_dash.fields), width='stretch', key="chart_cf")

        c3, c4 = st.columns(2)
        with c3:
            st.markdown("##### Assets vs Liabilities (FY26)")
            st.plotly_chart(dash.build_assets_liabilities_chart(m_sa_dash.fields), width='stretch', key="chart_al")
        with c4:
            st.markdown("##### Debt / Capex Trend")
            st.plotly_chart(dash.build_debt_trend_chart(trends_dash, ra_sa_dash), width='stretch', key="chart_debt")

        st.markdown("##### Ratio Gauges")
        st.plotly_chart(dash.build_ratio_gauges(ra_sa_dash), width='stretch', key="chart_gauges")

        c5, c6 = st.columns(2)
        with c5:
            st.markdown("##### Risk Heatmap")
            risk_entries = risk_report_dash.risk_entries if risk_report_dash else None
            st.plotly_chart(dash.build_risk_heatmap(risk_entries), width='stretch', key="chart_heatmap")
        with c6:
            st.markdown("##### Year Comparison")
            st.plotly_chart(dash.build_year_comparison_chart(m_sa_dash.fields), width='stretch', key="chart_yoy")

        st.markdown("##### Financial Scorecard")
        scorecard = dash.build_scorecard(ra_sa_dash, rf_sa_dash)
        if scorecard:
            sc_cols = st.columns(len(scorecard))
            sev_emoji = {"NONE": "🟢", "LOW": "🟡", "MEDIUM": "🟠", "HIGH": "🔴", "CRITICAL": "🔴"}
            for col, row in zip(sc_cols, scorecard):
                val = f"{row['value']:,.2f}" if row["value"] is not None else "n/a"
                col.metric(row["metric"], val, sev_emoji.get(row["severity"], ""))
    else:
        st.info("Ratio data not available for this filing — dashboard cannot be built.")

st.divider()

# ----------------------------------------------------------------------------
# Step 4 — Presentation & PDF Report
# ----------------------------------------------------------------------------
st.markdown('<div class="section-card"><h3>Step 4 — Presentation & PDF Report</h3></div>', unsafe_allow_html=True)
st.caption("Board-ready PowerPoint and PDF, built from the same validated data as the section reports above — "
           "Executive Summary, Financial Statements, Ratios, Charts, Risks, Auditor Findings, Recommendations, Appendix.")

report_disabled = company is None or not company.mapped

def _report_kwargs():
    return dict(
        mapped_sa=company.mapped.get("standalone"), mapped_co=company.mapped.get("consolidated"),
        ra_sa=st.session_state.ra_sa, ra_co=st.session_state.ra_co,
        rf_sa=st.session_state.rf_sa, rf_co=st.session_state.rf_co,
        trends=st.session_state.trends, risk_report=st.session_state.risk_report,
    )

pcol1, pcol2 = st.columns(2)
render_module_button(
    pcol1, "PowerPoint Report",
    "11-slide deck: Title, TOC, Executive Summary, Financial Statements, Ratios, Charts, Risk Register, "
    "Auditor Findings, Red Flags, Recommendations, Appendix.",
    "pptx", report_disabled, "No mapped financial data available.",
    lambda out_path: build_pptx_report(company, **_report_kwargs(), output_path=out_path),
    "FS_Analyser_Pro_Report.pptx", "pptx", "Generate PowerPoint Report",
    mime="application/vnd.openxmlformats-officedocument.presentationml.presentation",
)
render_module_button(
    pcol2, "PDF Report",
    "Same structure as the PowerPoint, formatted as a printable PDF document.",
    "pdf", report_disabled, "No mapped financial data available.",
    lambda out_path: build_pdf_report(company, **_report_kwargs(), output_path=out_path),
    "FS_Analyser_Pro_Report.pdf", "pdf", "Generate PDF Report",
    mime="application/pdf",
)

st.divider()

# ----------------------------------------------------------------------------
# Step 5 — Consolidated ZIP
# ----------------------------------------------------------------------------
st.markdown('<div class="section-card"><h3>Step 5 — Consolidated Report</h3></div>', unsafe_allow_html=True)
st.caption("Bundles every report generated in Steps 2 and 4 into a single ZIP. Generate the sections you want "
           "included first — this only zips what has already been generated in this session.")

if st.button("Build Consolidated ZIP", key="btn_zip"):
    if not st.session_state.generated_files:
        st.warning("Nothing generated yet — use the buttons in Step 2 or Step 4 first.")
    else:
        buf = io.BytesIO()
        company_label = (company.company_name or company.report_title or "Company").replace(" ", "_") if company else "Company"
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            for label, (fname, data) in st.session_state.generated_files.items():
                zf.writestr(fname, data)
            readme = (
                f"FS Analyser Pro — Consolidated Report\n"
                f"Company: {company_label}\n"
                f"Source file: {st.session_state.pdf_name}\n"
                f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n\n"
                f"Contents:\n" + "\n".join(f"  - {fname}" for _, (fname, _) in st.session_state.generated_files.items())
            )
            zf.writestr("README.txt", readme)
        st.download_button(
            "⬇ Download Consolidated_Report.zip",
            data=buf.getvalue(),
            file_name=f"{company_label}_Consolidated_Report.zip",
            mime="application/zip",
            key="dl_zip",
        )

# ----------------------------------------------------------------------------
# Footer — Disclaimer
# ----------------------------------------------------------------------------
st.markdown("""
<div class="app-footer">
<b>Disclaimer</b><br>
FS Analyser Pro is a rule-based extraction and computation tool built for
<b>general-purpose, non-financial-services companies</b> reporting under Ind-AS
Schedule III (Division I). It does not apply industry-specific ratios or
disclosures, and is <b>not suitable</b> for banks, NBFCs, insurance companies,
or other financial-services / niche regulated entities, which follow a
different Schedule III division and statement format.<br><br>
All figures are extracted mechanically from the uploaded PDF and cross-checked
via independent arithmetic tie-outs (see the Validation sheet in each report),
but this tool does <b>not</b> constitute financial, investment, tax, legal, or
audit advice, and does not substitute for professional judgement or a
statutory audit. Extraction accuracy depends on the source PDF's structure and
formatting; always verify key figures against the original Annual Report
before relying on them. Red Flag Detection (Module 4) covers only 9
quantitative checks. Auditor opinion, Key Audit Matters, Emphasis of Matter,
Internal Financial Controls, and company-disclosed risk categorisation are
covered separately in Module 5 via pattern-matching against standard
boilerplate — not a substantive audit review — and depend on the filing
using a structured risk-disclosure template; where one is not found, this is
reported honestly rather than a low-quality narrative parse being forced.
Recommendations in the PowerPoint/PDF reports are templated statements tied
directly to a specific figure or finding, not an AI-generated assessment.
Neither the developer nor any provider of the underlying AI model accepts
liability for decisions made based on this tool's output.
</div>
""", unsafe_allow_html=True)

"""
FS Analyser Pro — Module 4: Red Flag Detection (Quantitative)

Scope (by explicit instruction): quantitative checks only, computed from
data already extracted in Modules 1-2 (MappedFinancials + RatioAnalysis).
Text-based flags (auditor qualifications, contingent liabilities,
related-party concerns, going concern) are OUT OF SCOPE for this module
and are listed separately as "Not Assessed" so the report never implies
a clean bill of health on checks it did not actually perform.

Every threshold used is a DISCLOSED, generic rule (stated in
THRESHOLD_NOTES below) — not a company- or sector-calibrated benchmark.
Severity is mechanical (bigger deviation = higher tier), not a subjective
"Good/Bad" judgement on the business.

IMPORTANT structural caveat carried over from Module 3: HUL's Balance
Sheet shows a discontinuity from the FY2020-21 GSK Consumer Healthcare
amalgamation. Checks that compare only the current year vs the prior
year (as here, FY26 vs FY25) are NOT affected by that discontinuity —
it is flagged here only because it would matter if this module is later
extended to check further back using Module 3's multi-year data.

IMPORTANT caveat on liquidity checks: a Current Ratio below 1.0 is a
BOOKED RULE-BASED FLAG here, but many FMCG/retail businesses (including
HUL, per Module 2's negative Cash Conversion Cycle) run on negative
working capital BY DESIGN, funded by trade payables rather than
distress. This flag should be read alongside the CCC and payable-days
figures from Module 2, not in isolation — the module surfaces the
number; it deliberately does not claim the number means distress.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from .models import MappedFinancials
from .ratios import RatioAnalysis

SEVERITY_ORDER = {"NONE": 0, "LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}

THRESHOLD_NOTES: Dict[str, str] = {
    "revenue_decline": "No flag if growth >= 0%. LOW: 0% to -10%. MEDIUM: -10% to -20%. HIGH: below -20%.",
    "pat_decline": "No flag if growth >= 0%. LOW: 0% to -10%. MEDIUM: -10% to -25%. HIGH: below -25%.",
    "ebitda_margin_contraction": "Compares EBITDA Margin % (FY26) vs (FY25), in percentage points (bps/100). "
                                  "No flag if margin flat/expanded. LOW: 0-1.0pp contraction. MEDIUM: 1.0-3.0pp. HIGH: >3.0pp.",
    "negative_operating_cash_flow": "CRITICAL if Net Cash Flow from Operating Activities is negative. No tiering — "
                                     "any negative OCF for an established operating company is flagged CRITICAL.",
    "high_leverage_debt_equity": "No flag if D/E <= 0.5x. LOW: 0.5x-1.0x. MEDIUM: 1.0x-2.0x. HIGH: above 2.0x.",
    "low_interest_coverage": "No flag if Interest Coverage >= 4.0x. LOW: 3.0x-4.0x. MEDIUM: 1.5x-3.0x. "
                              "HIGH: below 1.5x (i.e. earnings barely cover or fail to cover interest).",
    "liquidity_current_ratio": "No flag if Current Ratio >= 1.0x. LOW: 0.75x-1.0x. MEDIUM: 0.5x-0.75x. HIGH: below 0.5x. "
                                "See module-level caveat on negative-working-capital business models.",
    "exceptional_items_pct_of_pbt": "Measures |Exceptional Items| / PBT (continuing operations). No flag if <10%. "
                                     "LOW: 10-25%. MEDIUM: 25-50%. HIGH: above 50% (earnings quality / recurring "
                                     "profitability concern — reported PBT materially shaped by one-off items).",
    "cash_conversion_cycle_deterioration": "YoY worsening (increase) in Cash Conversion Cycle, in days. No flag if "
                                            "flat/improved. LOW: 1-15 days worse. MEDIUM: 15-30 days worse. "
                                            "HIGH: more than 30 days worse.",
}


@dataclass
class RedFlag:
    check: str
    basis: str
    severity: str  # NONE | LOW | MEDIUM | HIGH | CRITICAL
    metric_value: Optional[float]
    threshold_rule: str
    description: str


@dataclass
class RedFlagReport:
    basis: str
    flags: List[RedFlag] = field(default_factory=list)
    not_assessed: List[str] = field(default_factory=list)

    def summary_counts(self) -> Dict[str, int]:
        counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "NONE": 0}
        for f in self.flags:
            counts[f.severity] += 1
        return counts


def _tier(value: float, cuts: List[float], labels: List[str], higher_is_worse: bool = True) -> str:
    """cuts must be ascending; labels has len(cuts)+1 entries, labels[0] = 'NONE'."""
    if higher_is_worse:
        for cut, label in zip(cuts, labels[1:]):
            if value < cut:
                return label
        return labels[-1]
    else:
        for cut, label in zip(cuts, labels[1:]):
            if value > cut:
                return label
        return labels[-1]


def _check_decline(name: str, growth_pct: Optional[float], cuts, rule_key) -> Optional[RedFlag]:
    if growth_pct is None:
        return None
    if growth_pct >= 0:
        sev = "NONE"
    else:
        decline = abs(growth_pct)
        if decline < cuts[0]:
            sev = "LOW"
        elif decline < cuts[1]:
            sev = "MEDIUM"
        else:
            sev = "HIGH"
    return RedFlag(
        check=name, basis="", severity=sev, metric_value=growth_pct,
        threshold_rule=THRESHOLD_NOTES[rule_key],
        description=f"YoY growth: {growth_pct:+.2f}%",
    )


def build_red_flag_report(basis: str, m: Optional[MappedFinancials], ra: Optional[RatioAnalysis]) -> RedFlagReport:
    report = RedFlagReport(basis=basis)
    if m is None or ra is None:
        report.not_assessed.append(f"No mapped financials/ratios available for basis='{basis}'.")
        return report

    f = m.fields
    r = ra.ratios

    # 1. Revenue decline
    flag = _check_decline("Revenue Decline (YoY)", r.get("revenue_growth_pct"), [10, 20], "revenue_decline")
    if flag:
        flag.basis = basis
        report.flags.append(flag)

    # 2. PAT decline
    flag = _check_decline("PAT Decline (YoY)", r.get("pat_growth_pct"), [10, 25], "pat_decline")
    if flag:
        flag.basis = basis
        report.flags.append(flag)

    # 3. EBITDA margin contraction
    m_cur = r.get("ebitda_margin_pct_fy26")
    m_prev = r.get("ebitda_margin_pct_fy25")
    if m_cur is not None and m_prev is not None:
        contraction = m_prev - m_cur  # positive = margin got worse
        if contraction <= 0:
            sev = "NONE"
        elif contraction < 1.0:
            sev = "LOW"
        elif contraction < 3.0:
            sev = "MEDIUM"
        else:
            sev = "HIGH"
        report.flags.append(RedFlag(
            check="EBITDA Margin Contraction (YoY)", basis=basis, severity=sev,
            metric_value=round(contraction, 2),
            threshold_rule=THRESHOLD_NOTES["ebitda_margin_contraction"],
            description=f"EBITDA Margin moved from {m_prev:.2f}% (FY25) to {m_cur:.2f}% (FY26), "
                         f"a {contraction:+.2f} percentage-point change (positive = contraction).",
        ))
    else:
        report.not_assessed.append(f"[{basis}] EBITDA Margin Contraction — insufficient data.")

    # 4. Negative operating cash flow
    ocf = f.get("operating_cash_flow")
    if ocf is not None:
        sev = "CRITICAL" if ocf < 0 else "NONE"
        report.flags.append(RedFlag(
            check="Negative Operating Cash Flow", basis=basis, severity=sev,
            metric_value=ocf,
            threshold_rule=THRESHOLD_NOTES["negative_operating_cash_flow"],
            description=f"Net Cash Flow from Operating Activities (FY26): Rs. {ocf:,.0f} Crores",
        ))
    else:
        report.not_assessed.append(f"[{basis}] Negative Operating Cash Flow — insufficient data.")

    # 5. High leverage (Debt-Equity)
    de = r.get("debt_equity_ratio_fy26")
    if de is not None:
        if de <= 0.5:
            sev = "NONE"
        elif de <= 1.0:
            sev = "LOW"
        elif de <= 2.0:
            sev = "MEDIUM"
        else:
            sev = "HIGH"
        report.flags.append(RedFlag(
            check="High Leverage (Debt-Equity)", basis=basis, severity=sev,
            metric_value=de,
            threshold_rule=THRESHOLD_NOTES["high_leverage_debt_equity"],
            description=f"Debt-Equity Ratio (FY26): {de:.2f}x. NOTE: 'Debt' = Lease Liabilities only "
                         f"(see Module 1/2 assumption — no separate Borrowings line on this Balance Sheet).",
        ))
    else:
        report.not_assessed.append(f"[{basis}] High Leverage — insufficient data.")

    # 6. Low interest coverage
    icr = r.get("interest_coverage_ratio_fy26")
    if icr is not None:
        if icr >= 4.0:
            sev = "NONE"
        elif icr >= 3.0:
            sev = "LOW"
        elif icr >= 1.5:
            sev = "MEDIUM"
        else:
            sev = "HIGH"
        report.flags.append(RedFlag(
            check="Low Interest Coverage", basis=basis, severity=sev,
            metric_value=icr,
            threshold_rule=THRESHOLD_NOTES["low_interest_coverage"],
            description=f"Interest Coverage Ratio (FY26): {icr:.2f}x",
        ))
    else:
        report.not_assessed.append(f"[{basis}] Low Interest Coverage — insufficient data.")

    # 7. Liquidity stress (Current Ratio)
    cr = r.get("current_ratio_fy26")
    if cr is not None:
        if cr >= 1.0:
            sev = "NONE"
        elif cr >= 0.75:
            sev = "LOW"
        elif cr >= 0.5:
            sev = "MEDIUM"
        else:
            sev = "HIGH"
        report.flags.append(RedFlag(
            check="Liquidity Stress (Current Ratio)", basis=basis, severity=sev,
            metric_value=cr,
            threshold_rule=THRESHOLD_NOTES["liquidity_current_ratio"],
            description=f"Current Ratio (FY26): {cr:.2f}x. See module-level caveat on negative-working-capital "
                         f"business models before treating this as distress.",
        ))
    else:
        report.not_assessed.append(f"[{basis}] Liquidity Stress — insufficient data.")

    # 8. Exceptional items as % of PBT (earnings quality)
    exc = f.get("exceptional_items")
    pbt = f.get("pbt_continuing")
    if exc is not None and pbt not in (None, 0):
        pct = abs(exc / pbt) * 100
        if pct < 10:
            sev = "NONE"
        elif pct < 25:
            sev = "LOW"
        elif pct < 50:
            sev = "MEDIUM"
        else:
            sev = "HIGH"
        report.flags.append(RedFlag(
            check="Exceptional Items % of PBT (Earnings Quality)", basis=basis, severity=sev,
            metric_value=round(pct, 2),
            threshold_rule=THRESHOLD_NOTES["exceptional_items_pct_of_pbt"],
            description=f"Exceptional Items (FY26): Rs. {exc:,.0f} Crores against PBT (Continuing) of "
                         f"Rs. {pbt:,.0f} Crores = {pct:.1f}% of PBT.",
        ))
    else:
        report.not_assessed.append(f"[{basis}] Exceptional Items % of PBT — insufficient data.")

    # 9. Cash Conversion Cycle deterioration
    ccc_cur = r.get("cash_conversion_cycle_closing_fy26")
    ccc_prev = r.get("cash_conversion_cycle_closing_fy25")
    if ccc_cur is not None and ccc_prev is not None:
        delta = ccc_cur - ccc_prev  # positive = cycle got LONGER (worse)
        if delta <= 0:
            sev = "NONE"
        elif delta <= 15:
            sev = "LOW"
        elif delta <= 30:
            sev = "MEDIUM"
        else:
            sev = "HIGH"
        report.flags.append(RedFlag(
            check="Cash Conversion Cycle Deterioration (YoY)", basis=basis, severity=sev,
            metric_value=round(delta, 1),
            threshold_rule=THRESHOLD_NOTES["cash_conversion_cycle_deterioration"],
            description=f"CCC moved from {ccc_prev:.1f} days (FY25) to {ccc_cur:.1f} days (FY26), "
                         f"a {delta:+.1f} day change (positive = cycle lengthened).",
        ))
    else:
        report.not_assessed.append(f"[{basis}] Cash Conversion Cycle Deterioration — insufficient data.")

    # Explicitly list what this module does NOT cover, so silence isn't mistaken for "clean"
    report.not_assessed.extend([
        f"[{basis}] Auditor Qualifications / Key Audit Matters — requires text extraction from Auditor's Report (not built).",
        f"[{basis}] Contingent Liabilities — requires text extraction from Notes to Accounts (not built).",
        f"[{basis}] Related Party Transaction concerns — requires text extraction from Notes to Accounts (not built).",
        f"[{basis}] Going Concern — requires text extraction from Auditor's Report (not built).",
        f"[{basis}] Corporate Governance concerns — requires text extraction from Corporate Governance Report (not built).",
    ])

    return report

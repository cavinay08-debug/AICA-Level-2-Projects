"""
FS Analyser Pro — PowerPoint Report Generator

Builds a board-ready deck entirely from data already extracted and
validated by Modules 1-5 — no new figures are derived here, and no
free-form narrative is generated. "Recommendations" are templated,
data-driven statements (e.g. tied to a specific red flag or KAM), not
an AI-written assessment.
"""
from __future__ import annotations

from typing import Optional, Any, Dict, List

from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.chart.data import CategoryChartData
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION

NAVY = RGBColor(0x1F, 0x38, 0x64)
GOLD = RGBColor(0xBF, 0x90, 0x00)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
GREY = RGBColor(0x59, 0x59, 0x59)
LIGHT_GOLD = RGBColor(0xFD, 0xF2, 0xCC)
GREEN = RGBColor(0x2E, 0x7D, 0x32)
RED = RGBColor(0xC0, 0x00, 0x00)

SLIDE_W = Inches(13.333)
SLIDE_H = Inches(7.5)


def _fmt(v, dp=1, suffix=""):
    if v is None:
        return "n/a"
    try:
        return f"{v:,.{dp}f}{suffix}"
    except (TypeError, ValueError):
        return str(v)


def _add_title_bar(slide, prs, title_text, subtitle=None):
    bar = slide.shapes.add_shape(1, 0, 0, prs.slide_width, Inches(0.9))
    bar.fill.solid()
    bar.fill.fore_color.rgb = NAVY
    bar.line.fill.background()
    tb = slide.shapes.add_textbox(Inches(0.4), Inches(0.12), prs.slide_width - Inches(0.8), Inches(0.65))
    tf = tb.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = title_text
    p.font.size = Pt(26)
    p.font.bold = True
    p.font.color.rgb = WHITE
    if subtitle:
        p2 = tf.add_paragraph()
        p2.text = subtitle
        p2.font.size = Pt(12)
        p2.font.color.rgb = RGBColor(0xE8, 0xD9, 0xA0)


def _add_footer(slide, prs, text):
    tb = slide.shapes.add_textbox(Inches(0.4), prs.slide_height - Inches(0.4), prs.slide_width - Inches(0.8), Inches(0.3))
    p = tb.text_frame.paragraphs[0]
    p.text = text
    p.font.size = Pt(9)
    p.font.color.rgb = GREY


def _new_slide(prs, layout_idx=6):
    return prs.slides.add_slide(prs.slide_layouts[layout_idx])


def _add_bullets(slide, x, y, w, h, lines: List[str], size=14, color=RGBColor(0, 0, 0)):
    tb = slide.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame
    tf.word_wrap = True
    for i, line in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.text = f"•  {line}"
        p.font.size = Pt(size)
        p.font.color.rgb = color
        p.space_after = Pt(8)
    return tb


def _add_table(slide, x, y, w, h, headers: List[str], rows: List[List[str]], col_widths=None, font_size=11):
    n_rows = len(rows) + 1
    n_cols = len(headers)
    table_shape = slide.shapes.add_table(n_rows, n_cols, x, y, w, h)
    table = table_shape.table
    if col_widths:
        for i, cw in enumerate(col_widths):
            table.columns[i].width = cw
    for c, h in enumerate(headers):
        cell = table.cell(0, c)
        cell.text = h
        cell.fill.solid()
        cell.fill.fore_color.rgb = NAVY
        for p in cell.text_frame.paragraphs:
            p.font.size = Pt(font_size)
            p.font.bold = True
            p.font.color.rgb = WHITE
    for r, row in enumerate(rows, start=1):
        for c, val in enumerate(row):
            cell = table.cell(r, c)
            cell.text = str(val)
            for p in cell.text_frame.paragraphs:
                p.font.size = Pt(font_size)
            if r % 2 == 0:
                cell.fill.solid()
                cell.fill.fore_color.rgb = RGBColor(0xF5, 0xF5, 0xF5)
    return table_shape


def _add_bar_chart(slide, x, y, w, h, categories, series: Dict[str, List[Optional[float]]], title=None):
    chart_data = CategoryChartData()
    chart_data.categories = categories
    for name, vals in series.items():
        chart_data.add_series(name, [v if v is not None else 0 for v in vals])
    gframe = slide.shapes.add_chart(XL_CHART_TYPE.COLUMN_CLUSTERED, x, y, w, h, chart_data)
    chart = gframe.chart
    chart.has_legend = len(series) > 1
    if chart.has_legend:
        chart.legend.position = XL_LEGEND_POSITION.BOTTOM
        chart.legend.include_in_layout = False
    if title:
        chart.has_title = True
        chart.chart_title.text_frame.text = title
    return gframe


def _add_line_chart(slide, x, y, w, h, categories, series: Dict[str, List[Optional[float]]], title=None):
    chart_data = CategoryChartData()
    chart_data.categories = categories
    for name, vals in series.items():
        chart_data.add_series(name, [v if v is not None else 0 for v in vals])
    gframe = slide.shapes.add_chart(XL_CHART_TYPE.LINE_MARKERS, x, y, w, h, chart_data)
    chart = gframe.chart
    chart.has_legend = True
    chart.legend.position = XL_LEGEND_POSITION.BOTTOM
    chart.legend.include_in_layout = False
    if title:
        chart.has_title = True
        chart.chart_title.text_frame.text = title
    return gframe


def build_pptx_report(company, mapped_sa, mapped_co, ra_sa, ra_co, rf_sa, rf_co,
                       trends, risk_report, output_path: str) -> str:
    prs = Presentation()
    prs.slide_width = SLIDE_W
    prs.slide_height = SLIDE_H
    blank = 6  # blank layout index in default template

    company_name = company.company_name or company.report_title or "Company"

    # ---------------- TITLE SLIDE ----------------
    s = _new_slide(prs, blank)
    bg = s.shapes.add_shape(1, 0, 0, prs.slide_width, prs.slide_height)
    bg.fill.solid(); bg.fill.fore_color.rgb = NAVY; bg.line.fill.background()
    tb = s.shapes.add_textbox(Inches(0.8), Inches(2.6), Inches(11.5), Inches(1.5))
    p = tb.text_frame.paragraphs[0]
    p.text = company_name
    p.font.size = Pt(40); p.font.bold = True; p.font.color.rgb = WHITE
    tb2 = s.shapes.add_textbox(Inches(0.8), Inches(3.6), Inches(11.5), Inches(0.8))
    p2 = tb2.text_frame.paragraphs[0]
    p2.text = "Financial Statement Analysis — FS Analyser Pro"
    p2.font.size = Pt(20); p2.font.color.rgb = GOLD
    tb3 = s.shapes.add_textbox(Inches(0.8), Inches(6.6), Inches(11.5), Inches(0.5))
    p3 = tb3.text_frame.paragraphs[0]
    p3.text = "General-purpose, non-financial-services company scope — see Appendix for disclaimer."
    p3.font.size = Pt(11); p3.font.color.rgb = RGBColor(0xCC, 0xCC, 0xCC)

    # ---------------- TABLE OF CONTENTS ----------------
    s = _new_slide(prs, blank)
    _add_title_bar(s, prs, "Table of Contents")
    toc_items = [
        "Executive Summary", "Financial Statements (Standalone)", "Ratio Analysis",
        "Financial Trends & Charts", "Risk Register", "Auditor Findings",
        "Red Flag Detection", "Recommendations", "Appendix — Formulas, Methodology & Disclaimer",
    ]
    _add_bullets(s, Inches(1), Inches(1.3), Inches(10), Inches(5.5), toc_items, size=18)
    _add_footer(s, prs, company_name)

    # ---------------- EXECUTIVE SUMMARY ----------------
    s = _new_slide(prs, blank)
    _add_title_bar(s, prs, "Executive Summary")
    f = mapped_sa.fields if mapped_sa else {}
    r = ra_sa.ratios if ra_sa else {}
    kpi_lines = [
        f"Revenue (FY26): {_fmt(f.get('revenue'))} | YoY Growth: {_fmt(r.get('revenue_growth_pct'), 2, '%')}",
        f"EBITDA (Operating, FY26): {_fmt(f.get('ebitda_operating'))} | Margin: {_fmt(r.get('ebitda_margin_pct_fy26'), 2, '%')}",
        f"PAT (FY26): {_fmt(f.get('pat_total'))} | Net Margin: {_fmt(r.get('net_profit_margin_pct_fy26'), 2, '%')}",
        f"Total Assets (FY26): {_fmt(f.get('total_assets'))} | Total Equity: {_fmt(f.get('total_equity'))}",
        f"Current Ratio: {_fmt(r.get('current_ratio_fy26'), 2, 'x')} | Debt-Equity: {_fmt(r.get('debt_equity_ratio_fy26'), 2, 'x')}",
    ]
    _add_bullets(s, Inches(0.6), Inches(1.15), Inches(12), Inches(2.0), kpi_lines, size=15)
    impl_lines = (risk_report.business_implications[:6] if risk_report else [])
    if impl_lines:
        tb = s.shapes.add_textbox(Inches(0.6), Inches(3.3), Inches(12), Inches(0.4))
        tb.text_frame.paragraphs[0].text = "Risk & Auditor Highlights"
        tb.text_frame.paragraphs[0].font.bold = True
        tb.text_frame.paragraphs[0].font.size = Pt(14)
        tb.text_frame.paragraphs[0].font.color.rgb = NAVY
        _add_bullets(s, Inches(0.6), Inches(3.75), Inches(12), Inches(3.2), impl_lines, size=12)
    _add_footer(s, prs, "Figures per Module 1-5 output — see Appendix for scope and disclaimer.")

    # ---------------- FINANCIAL STATEMENTS SUMMARY ----------------
    s = _new_slide(prs, blank)
    _add_title_bar(s, prs, "Financial Statements — Standalone Summary", "Rs. as per source statement units")
    bs_rows = [
        ["Total Assets", _fmt(f.get("total_assets")), _fmt(f.get("total_assets_prev"))],
        ["Non-Current Assets", _fmt(f.get("non_current_assets")), _fmt(f.get("non_current_assets_prev"))],
        ["Current Assets", _fmt(f.get("current_assets")), _fmt(f.get("current_assets_prev"))],
        ["Total Equity", _fmt(f.get("total_equity")), _fmt(f.get("total_equity_prev"))],
        ["Non-Current Liabilities", _fmt(f.get("non_current_liabilities")), _fmt(f.get("non_current_liabilities_prev"))],
        ["Current Liabilities", _fmt(f.get("current_liabilities")), _fmt(f.get("current_liabilities_prev"))],
    ]
    _add_table(s, Inches(0.5), Inches(1.15), Inches(6.0), Inches(3.0),
               ["Balance Sheet", "FY26", "FY25"], bs_rows, font_size=11)
    pl_rows = [
        ["Revenue", _fmt(f.get("revenue")), _fmt(f.get("revenue_prev"))],
        ["COGS", _fmt(f.get("cogs")), _fmt(f.get("cogs_prev"))],
        ["EBITDA (Operating)", _fmt(f.get("ebitda_operating")), _fmt(f.get("ebitda_operating_prev"))],
        ["PBT (Continuing)", _fmt(f.get("pbt_continuing")), _fmt(f.get("pbt_continuing_prev"))],
        ["PAT (Total)", _fmt(f.get("pat_total")), _fmt(f.get("pat_total_prev"))],
    ]
    _add_table(s, Inches(6.8), Inches(1.15), Inches(6.0), Inches(2.6),
               ["Profit & Loss", "FY26", "FY25"], pl_rows, font_size=11)
    cf_rows = [
        ["Operating CF", _fmt(f.get("operating_cash_flow")), _fmt(f.get("operating_cash_flow_prev"))],
        ["Investing CF", _fmt(f.get("investing_cash_flow")), _fmt(f.get("investing_cash_flow_prev"))],
        ["Financing CF", _fmt(f.get("financing_cash_flow")), _fmt(f.get("financing_cash_flow_prev"))],
        ["Free Cash Flow", _fmt(f.get("free_cash_flow")), _fmt(f.get("free_cash_flow_prev"))],
    ]
    _add_table(s, Inches(0.5), Inches(4.35), Inches(6.0), Inches(2.2),
               ["Cash Flow", "FY26", "FY25"], cf_rows, font_size=11)
    _add_footer(s, prs, "Full statement detail with Notes/formulas: see Module 1 workbook.")

    # ---------------- RATIO ANALYSIS ----------------
    s = _new_slide(prs, blank)
    _add_title_bar(s, prs, "Ratio Analysis — Standalone")
    ratio_rows = [
        ["Gross Margin %", _fmt(r.get("gross_margin_pct_fy26"), 2), _fmt(r.get("gross_margin_pct_fy25"), 2)],
        ["EBITDA Margin %", _fmt(r.get("ebitda_margin_pct_fy26"), 2), _fmt(r.get("ebitda_margin_pct_fy25"), 2)],
        ["Net Profit Margin %", _fmt(r.get("net_profit_margin_pct_fy26"), 2), _fmt(r.get("net_profit_margin_pct_fy25"), 2)],
        ["ROE (Closing) %", _fmt(r.get("roe_closing_pct_fy26"), 2), _fmt(r.get("roe_closing_pct_fy25"), 2)],
        ["Current Ratio (x)", _fmt(r.get("current_ratio_fy26"), 2), _fmt(r.get("current_ratio_fy25"), 2)],
        ["Debt-Equity (x)", _fmt(r.get("debt_equity_ratio_fy26"), 2), _fmt(r.get("debt_equity_ratio_fy25"), 2)],
        ["Interest Coverage (x)", _fmt(r.get("interest_coverage_ratio_fy26"), 2), _fmt(r.get("interest_coverage_ratio_fy25"), 2)],
        ["Cash Conversion Cycle (days)", _fmt(r.get("cash_conversion_cycle_closing_fy26"), 1),
         _fmt(r.get("cash_conversion_cycle_closing_fy25"), 1)],
    ]
    _add_table(s, Inches(0.8), Inches(1.2), Inches(8.0), Inches(5.5),
               ["Ratio", "FY26", "FY25"], ratio_rows, font_size=13)
    _add_footer(s, prs, "Formulas disclosed in Module 2 workbook — no qualitative labels applied.")

    # ---------------- CHARTS ----------------
    s = _new_slide(prs, blank)
    _add_title_bar(s, prs, "Financial Trends")
    if trends and trends.get("turnover") and trends.get("pat"):
        years = trends["turnover"].years
        _add_line_chart(s, Inches(0.4), Inches(1.15), Inches(6.2), Inches(3.0), years,
                         {"Turnover": trends["turnover"].values, "PAT": trends["pat"].values},
                         title="Turnover & PAT Trend")
    else:
        _add_bar_chart(s, Inches(0.4), Inches(1.15), Inches(6.2), Inches(3.0), ["FY25", "FY26"],
                        {"Revenue": [f.get("revenue_prev"), f.get("revenue")]}, title="Revenue (2-Year)")
    _add_bar_chart(s, Inches(6.8), Inches(1.15), Inches(6.1), Inches(3.0), ["FY25", "FY26"],
                   {"Operating CF": [f.get("operating_cash_flow_prev"), f.get("operating_cash_flow")],
                    "Investing CF": [f.get("investing_cash_flow_prev"), f.get("investing_cash_flow")],
                    "Financing CF": [f.get("financing_cash_flow_prev"), f.get("financing_cash_flow")]},
                   title="Cash Flow by Activity")
    _add_bar_chart(s, Inches(0.4), Inches(4.3), Inches(6.2), Inches(2.9), ["FY25", "FY26"],
                   {"EBITDA Margin %": [r.get("ebitda_margin_pct_fy25"), r.get("ebitda_margin_pct_fy26")],
                    "Net Margin %": [r.get("net_profit_margin_pct_fy25"), r.get("net_profit_margin_pct_fy26")]},
                   title="Margin Trend")
    _add_bar_chart(s, Inches(6.8), Inches(4.3), Inches(6.1), Inches(2.9),
                   ["Non-Curr. Assets", "Curr. Assets", "Equity", "Non-Curr. Liab.", "Curr. Liab."],
                   {"FY26": [f.get("non_current_assets"), f.get("current_assets"), f.get("total_equity"),
                             f.get("non_current_liabilities"), f.get("current_liabilities")]},
                   title="Assets vs Liabilities (FY26)")

    # ---------------- RISK REGISTER ----------------
    s = _new_slide(prs, blank)
    _add_title_bar(s, prs, "Risk Register")
    if risk_report and risk_report.risk_register_found:
        risk_rows = [[e.title, e.category_normalized, e.level_of_change, str(len(e.capitals_impacted))]
                     for e in risk_report.risk_entries[:8]]
        _add_table(s, Inches(0.5), Inches(1.15), Inches(12.3), Inches(5.5),
                   ["Risk", "Category", "Trend (Likelihood proxy)", "Capitals Impacted (Impact proxy)"],
                   risk_rows, col_widths=[Inches(4.2), Inches(4.0), Inches(2.1), Inches(2.0)], font_size=11)
    else:
        _add_bullets(s, Inches(0.6), Inches(1.3), Inches(11.5), Inches(2),
                     ["No structured risk register was found in this filing.",
                      "See Module 5 workbook for details — a script cannot reliably paraphrase "
                      "free-form risk narrative without a structured template to parse."], size=15)
    _add_footer(s, prs, "Likelihood/Impact are company-disclosed proxies, not independent probability ratings.")

    # ---------------- AUDITOR FINDINGS ----------------
    s = _new_slide(prs, blank)
    _add_title_bar(s, prs, "Auditor Findings")
    af_rows = []
    if risk_report:
        for af in risk_report.auditor_findings:
            af_rows.append([af.basis, af.opinion_type, str(af.kam_count),
                             "Yes" if af.eom_present else "No",
                             "Clean" if af.icfr_opinion_clean else ("Flagged" if af.icfr_opinion_clean is False else "n/d")])
    if af_rows:
        _add_table(s, Inches(0.6), Inches(1.2), Inches(11.5), Inches(1.8),
                   ["Basis", "Opinion Type", "KAM Count", "EOM Present", "ICFR Opinion"], af_rows, font_size=13)
        kam_lines = []
        if risk_report:
            for af in risk_report.auditor_findings:
                if af.kam_titles:
                    kam_lines.append(f"{af.basis}: " + "; ".join(af.kam_titles))
        if kam_lines:
            tb = s.shapes.add_textbox(Inches(0.6), Inches(3.3), Inches(11.5), Inches(0.4))
            tb.text_frame.paragraphs[0].text = "Key Audit Matter Titles"
            tb.text_frame.paragraphs[0].font.bold = True
            tb.text_frame.paragraphs[0].font.color.rgb = NAVY
            _add_bullets(s, Inches(0.6), Inches(3.75), Inches(11.5), Inches(3), kam_lines, size=13)
    else:
        _add_bullets(s, Inches(0.6), Inches(1.3), Inches(11.5), Inches(2),
                     ["No Independent Auditor's Report was located in this filing."], size=15)
    _add_footer(s, prs, "Pattern-matched against standard audit-report boilerplate — verify against source.")

    # ---------------- RED FLAGS ----------------
    s = _new_slide(prs, blank)
    _add_title_bar(s, prs, "Red Flag Detection — Standalone")
    sev_color = {"CRITICAL": RED, "HIGH": RGBColor(0xE0, 0x66, 0x66), "MEDIUM": RGBColor(0xF9, 0xCB, 0x9C),
                 "LOW": RGBColor(0xFF, 0xE5, 0x99), "NONE": RGBColor(0xD9, 0xEA, 0xD3)}
    if rf_sa:
        rows = [[fl.check, fl.severity, str(fl.metric_value)] for fl in rf_sa.flags]
        tbl_shape = _add_table(s, Inches(0.6), Inches(1.15), Inches(11.5), Inches(5.4),
                                ["Check", "Severity", "Value"], rows, col_widths=[Inches(6.5), Inches(2.5), Inches(2.5)],
                                font_size=12)
        table = tbl_shape.table
        for i, fl in enumerate(rf_sa.flags, start=1):
            cell = table.cell(i, 1)
            cell.fill.solid()
            cell.fill.fore_color.rgb = sev_color.get(fl.severity, WHITE)
    else:
        _add_bullets(s, Inches(0.6), Inches(1.3), Inches(11.5), Inches(2), ["No red flag data available."], size=15)
    _add_footer(s, prs, "9 quantitative checks — Auditor/Related-Party/Governance covered separately (Module 5).")

    # ---------------- RECOMMENDATIONS (data-driven, not generated prose) ----------------
    s = _new_slide(prs, blank)
    _add_title_bar(s, prs, "Recommendations", "Templated, tied directly to a specific finding above — not a generated narrative")
    recs = []
    if rf_sa:
        for fl in rf_sa.flags:
            if fl.severity not in ("NONE",):
                recs.append(f"[{fl.severity}] Review '{fl.check}' — {fl.description}")
    if risk_report:
        for af in risk_report.auditor_findings:
            if af.opinion_type and "Unmodified" not in af.opinion_type:
                recs.append(f"[{af.basis}] Auditor's opinion is '{af.opinion_type}' — review the qualification in full before relying on the financial statements.")
            if af.kam_count:
                recs.append(f"[{af.basis}] {af.kam_count} Key Audit Matter(s) identified — discuss with the Audit Committee: {', '.join(af.kam_titles[:3])}.")
        increased = [rr.title for rr in risk_report.risk_entries if rr.level_of_change.lower() == "increased"]
        if increased:
            recs.append("Monitor risks flagged by the company as INCREASING: " + "; ".join(increased) + ".")
    if not recs:
        recs.append("No red flags, audit qualifications, or increasing risk trends were identified from the "
                     "checks this tool performs — continue routine monitoring.")
    _add_bullets(s, Inches(0.6), Inches(1.5), Inches(12), Inches(5.3), recs[:10], size=14)
    _add_footer(s, prs, "Every line above ties to a specific figure or disclosure — verify against source before acting.")

    # ---------------- APPENDIX ----------------
    s = _new_slide(prs, blank)
    _add_title_bar(s, prs, "Appendix — Scope, Methodology & Disclaimer")
    appendix_lines = [
        "Scope: built for a general-purpose, non-financial-services company reporting under Ind-AS "
        "Schedule III (Division I). NOT applicable to banks, NBFCs, insurance, or other regulated "
        "financial-services entities (different Schedule III division and statement format).",
        "All figures are extracted mechanically from the uploaded PDF and independently tie-out validated "
        "(see Module 1 Validation sheet) — this does not constitute financial, investment, tax, legal, or "
        "audit advice, nor a substitute for professional judgement or statutory audit.",
        "Red Flag Detection covers 9 quantitative checks only — auditor qualifications, contingent "
        "liabilities, related-party transactions, and corporate governance are NOT assessed by that module "
        "(see Module 5 for auditor/risk findings instead).",
        "Risk Likelihood/Impact fields are company-disclosed proxies (Level of Change / Capitals Impacted) "
        "— neither company independently publishes a probability or severity RATING.",
        "'Debt' in leverage ratios uses Lease Liabilities where no separate Borrowings line exists on the "
        "Balance Sheet — see Module 2 Formula Disclosures.",
        "Always verify key figures against the original Annual Report before relying on them for any "
        "decision.",
    ]
    _add_bullets(s, Inches(0.6), Inches(1.2), Inches(12), Inches(5.6), appendix_lines, size=13, color=GREY)

    prs.save(output_path)
    return output_path

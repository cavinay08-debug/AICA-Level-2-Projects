"""
FS Analyser Pro — Module 2: Financial Analysis / Ratio Engine
Excel export (separate workbook from Module 1)
"""
from __future__ import annotations

from typing import Dict, Optional

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

from .ratios import RatioAnalysis
from .models import CompanyFinancials

NAVY = "1F3864"
GOLD = "BF9000"
LIGHT_GOLD = "FDF2CC"
LIGHT_GREY = "F2F2F2"
WHITE = "FFFFFF"

SECTIONS = [
    ("Growth (FY26 vs FY25 only)", [
        ("Revenue Growth %", "revenue_growth_pct", None),
        ("EBITDA (Operating) Growth %", "ebitda_growth_pct", None),
        ("PAT Growth %", "pat_growth_pct", None),
    ]),
    ("Profitability Margins", [
        ("Gross Margin %", "gross_margin_pct_fy26", "gross_margin_pct_fy25"),
        ("EBITDA Margin %", "ebitda_margin_pct_fy26", "ebitda_margin_pct_fy25"),
        ("Operating Margin (EBIT) %", "operating_margin_pct_fy26", "operating_margin_pct_fy25"),
        ("Net Profit Margin %", "net_profit_margin_pct_fy26", "net_profit_margin_pct_fy25"),
    ]),
    ("Return Ratios — Closing Balance Basis", [
        ("ROE (Closing) %", "roe_closing_pct_fy26", "roe_closing_pct_fy25"),
        ("ROA (Closing) %", "roa_closing_pct_fy26", "roa_closing_pct_fy25"),
        ("ROCE (Closing) %", "roce_closing_pct_fy26", "roce_closing_pct_fy25"),
    ]),
    ("Return Ratios — Average Balance Basis (FY26 only)", [
        ("ROE (Average) %", "roe_average_pct_fy26", None),
        ("ROA (Average) %", "roa_average_pct_fy26", None),
        ("ROCE (Average) %", "roce_average_pct_fy26", None),
    ]),
    ("Liquidity", [
        ("Current Ratio (x)", "current_ratio_fy26", "current_ratio_fy25"),
        ("Quick Ratio (x)", "quick_ratio_fy26", "quick_ratio_fy25"),
        ("Working Capital (Rs. Crores)", "working_capital_fy26", "working_capital_fy25"),
    ]),
    ("Leverage", [
        ("Debt-Equity Ratio (x)", "debt_equity_ratio_fy26", "debt_equity_ratio_fy25"),
        ("Interest Coverage Ratio (x)", "interest_coverage_ratio_fy26", "interest_coverage_ratio_fy25"),
    ]),
    ("Efficiency — Closing Balance Basis", [
        ("Asset Turnover (x)", "asset_turnover_closing_fy26", "asset_turnover_closing_fy25"),
        ("Inventory Turnover (x)", "inventory_turnover_closing_fy26", "inventory_turnover_closing_fy25"),
        ("Inventory Days", "inventory_days_closing_fy26", "inventory_days_closing_fy25"),
        ("Receivable Days", "receivable_days_closing_fy26", "receivable_days_closing_fy25"),
        ("Payable Days", "payable_days_closing_fy26", "payable_days_closing_fy25"),
        ("Cash Conversion Cycle (Days)", "cash_conversion_cycle_closing_fy26", "cash_conversion_cycle_closing_fy25"),
    ]),
    ("Efficiency — Average Balance Basis (FY26 only)", [
        ("Asset Turnover (x)", "asset_turnover_average_fy26", None),
        ("Inventory Turnover (x)", "inventory_turnover_average_fy26", None),
        ("Inventory Days", "inventory_days_average_fy26", None),
        ("Receivable Days", "receivable_days_average_fy26", None),
        ("Payable Days", "payable_days_average_fy26", None),
        ("Cash Conversion Cycle (Days)", "cash_conversion_cycle_average_fy26", None),
    ]),
    ("Per-Share & Dividend", [
        ("Shares Outstanding — approx. (crore)", "shares_outstanding_approx_crore_fy26", "shares_outstanding_approx_crore_fy25"),
        ("Book Value per Share (Rs.)", "book_value_per_share_fy26", "book_value_per_share_fy25"),
        ("Dividend Payout Ratio %", "dividend_payout_ratio_pct_fy26", "dividend_payout_ratio_pct_fy25"),
    ]),
]


def _style_title(ws, row_idx, ncols, text):
    ws.merge_cells(start_row=row_idx, start_column=1, end_row=row_idx, end_column=ncols)
    cell = ws.cell(row=row_idx, column=1, value=text)
    cell.font = Font(bold=True, color=WHITE, name="Arial", size=13)
    cell.fill = PatternFill("solid", fgColor=NAVY)
    cell.alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[row_idx].height = 22


def _style_header(ws, row_idx, ncols):
    for c in range(1, ncols + 1):
        cell = ws.cell(row=row_idx, column=c)
        cell.font = Font(bold=True, color=WHITE, name="Arial", size=10)
        cell.fill = PatternFill("solid", fgColor=NAVY)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)


def _write_ratio_sheet(wb, sa: Optional[RatioAnalysis], co: Optional[RatioAnalysis]):
    ws = wb.create_sheet("Ratio Analysis")
    ncols = 5
    _style_title(ws, 1, ncols, "FS Analyser Pro — Module 2: Financial Ratio & Growth Analysis")
    ws.cell(row=2, column=1,
            value="Figures and formulas only — no qualitative (Excellent/Good/Average/Weak) labels applied, by design.").font = \
        Font(italic=True, size=9, name="Arial", color="595959")

    headers = ["Ratio", "Standalone FY26", "Standalone FY25", "Consolidated FY26", "Consolidated FY25"]
    hdr_row = 4
    for c, h in enumerate(headers, start=1):
        ws.cell(row=hdr_row, column=c, value=h)
    _style_header(ws, hdr_row, ncols)

    r = hdr_row + 1
    for section_title, rows in SECTIONS:
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncols)
        c = ws.cell(row=r, column=1, value=section_title)
        c.font = Font(bold=True, name="Arial", size=10, color=NAVY)
        c.fill = PatternFill("solid", fgColor=LIGHT_GOLD)
        r += 1
        for label, key_cur, key_prev in rows:
            ws.cell(row=r, column=1, value=label).font = Font(name="Arial", size=10)
            sa_cur = sa.ratios.get(key_cur) if sa else None
            sa_prev = sa.ratios.get(key_prev) if (sa and key_prev) else None
            co_cur = co.ratios.get(key_cur) if co else None
            co_prev = co.ratios.get(key_prev) if (co and key_prev) else None
            for c_idx, v in enumerate([sa_cur, sa_prev, co_cur, co_prev], start=2):
                cell = ws.cell(row=r, column=c_idx, value=v)
                cell.font = Font(name="Arial", size=10)
                if isinstance(v, (int, float)):
                    cell.number_format = "#,##0.00;(#,##0.00)"
                    cell.alignment = Alignment(horizontal="right")
                elif key_prev is None and c_idx in (3, 5):
                    cell.value = "n/a (needs 3rd year)"
                    cell.font = Font(name="Arial", size=8, italic=True, color="999999")
            r += 1
        r += 1

    widths = [42, 18, 18, 18, 18]
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = f"A{hdr_row+1}"


def _write_formula_sheet(wb, sa: Optional[RatioAnalysis], co: Optional[RatioAnalysis]):
    ws = wb.create_sheet("Formula Disclosures")
    ncols = 2
    _style_title(ws, 1, ncols, "Formula & Methodology Disclosures")

    formulas: Dict[str, str] = {}
    notes: Dict[str, str] = {}
    for ra in (sa, co):
        if ra:
            formulas.update(ra.formulas)
            notes.update(ra.notes)

    r = 3
    ws.cell(row=r, column=1, value="Ratio / Metric").font = Font(bold=True, name="Arial", size=10, color=WHITE)
    ws.cell(row=r, column=2, value="Formula").font = Font(bold=True, name="Arial", size=10, color=WHITE)
    _style_header(ws, r, ncols)
    r += 1
    for key, formula in formulas.items():
        ws.cell(row=r, column=1, value=key.replace("_", " ").title()).font = Font(bold=True, name="Arial", size=9)
        c = ws.cell(row=r, column=2, value=formula)
        c.font = Font(italic=True, name="Arial", size=9, color="595959")
        c.alignment = Alignment(wrap_text=True)
        ws.row_dimensions[r].height = 26
        r += 1

    r += 1
    ws.cell(row=r, column=1, value="Methodology Notes").font = Font(bold=True, name="Arial", size=11, color=NAVY)
    r += 1
    for key, note in notes.items():
        ws.cell(row=r, column=1, value=key.replace("_", " ").title()).font = Font(bold=True, name="Arial", size=9)
        c = ws.cell(row=r, column=2, value=note)
        c.font = Font(italic=True, name="Arial", size=9, color="595959")
        c.alignment = Alignment(wrap_text=True)
        ws.row_dimensions[r].height = 32
        r += 1

    ws.column_dimensions["A"].width = 30
    ws.column_dimensions["B"].width = 90


def _write_trend_sheet(wb, trends):
    ws = wb.create_sheet("Long-Term Trend")
    if not trends:
        ws.cell(row=1, column=1, value="No long-term track record data available.")
        return

    years = next(iter(trends.values())).years
    ncols = 2 + len(years) + 2  # Metric, Unit, [years...], CAGR%, Direction
    _style_title(ws, 1, ncols, "FS Analyser Pro — Module 3: Long-Term Trend (Company-Disclosed Track Record)")
    ws.cell(row=2, column=1,
            value="Source: company's own multi-year 'Long-term Track Record' disclosure in the Annual Report "
                  "(not a re-derived estimate). Figures and formulas only.").font = \
        Font(italic=True, size=9, name="Arial", color="595959")

    hdr_row = 4
    headers = ["Metric", "Unit"] + years + ["CAGR % (full period)", "Direction"]
    for c, h in enumerate(headers, start=1):
        ws.cell(row=hdr_row, column=c, value=h)
    _style_header(ws, hdr_row, ncols)

    r = hdr_row + 1
    for key, mt in trends.items():
        ws.cell(row=r, column=1, value=mt.label).font = Font(name="Arial", size=10, bold=True, color=NAVY)
        ws.cell(row=r, column=2, value=mt.unit).font = Font(name="Arial", size=9, italic=True)
        for i, v in enumerate(mt.values):
            cell = ws.cell(row=r, column=3 + i, value=v)
            cell.font = Font(name="Arial", size=10)
            if isinstance(v, (int, float)):
                cell.number_format = "#,##0.00;(#,##0.00)"
                cell.alignment = Alignment(horizontal="right")
            elif v is None:
                cell.value = "n/a"
                cell.font = Font(name="Arial", size=8, italic=True, color="999999")
        cagr_cell = ws.cell(row=r, column=3 + len(years), value=mt.cagr_pct)
        cagr_cell.font = Font(name="Arial", size=10, bold=True)
        if isinstance(mt.cagr_pct, (int, float)):
            cagr_cell.number_format = "#,##0.00"
        ws.cell(row=r, column=4 + len(years), value=mt.direction).font = Font(name="Arial", size=9)
        r += 1

        # YoY growth sub-row
        ws.cell(row=r, column=1, value="  YoY Growth %").font = Font(name="Arial", size=8, italic=True, color="595959")
        for i, y in enumerate(mt.years):
            v = mt.yoy_growth_pct.get(y)
            cell = ws.cell(row=r, column=3 + i, value=v)
            cell.font = Font(name="Arial", size=8, italic=True, color="595959")
            if isinstance(v, (int, float)):
                cell.number_format = "#,##0.00"
                cell.alignment = Alignment(horizontal="right")
        r += 2

    widths = [30, 12] + [11] * len(years) + [16, 26]
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = f"C{hdr_row+1}"


def _write_red_flag_sheet(wb, sa_flags, co_flags):
    ws = wb.create_sheet("Red Flag Detection")
    ncols = 5
    _style_title(ws, 1, ncols, "FS Analyser Pro — Module 4: Red Flag Detection (Quantitative)")
    ws.cell(row=2, column=1,
            value="Rule-based checks with disclosed, generic thresholds (not sector-calibrated). "
                  "Severity is mechanical, not a subjective judgement on the business.").font = \
        Font(italic=True, size=9, name="Arial", color="595959")

    sev_colors = {"CRITICAL": "C00000", "HIGH": "E06666", "MEDIUM": "F9CB9C", "LOW": "FFE599", "NONE": "D9EAD3"}

    headers = ["Check", "Basis", "Severity", "Value", "Description / Threshold Rule"]
    hdr_row = 4
    for c, h in enumerate(headers, start=1):
        ws.cell(row=hdr_row, column=c, value=h)
    _style_header(ws, hdr_row, ncols)

    r = hdr_row + 1
    for flags in (sa_flags, co_flags):
        if flags is None:
            continue
        for flag in flags.flags:
            ws.cell(row=r, column=1, value=flag.check).font = Font(name="Arial", size=10)
            ws.cell(row=r, column=2, value=flag.basis.title()).font = Font(name="Arial", size=9)
            sev_cell = ws.cell(row=r, column=3, value=flag.severity)
            sev_cell.font = Font(name="Arial", size=10, bold=True)
            sev_cell.fill = PatternFill("solid", fgColor=sev_colors.get(flag.severity, "FFFFFF"))
            sev_cell.alignment = Alignment(horizontal="center")
            val_cell = ws.cell(row=r, column=4, value=flag.metric_value)
            val_cell.font = Font(name="Arial", size=10)
            if isinstance(flag.metric_value, (int, float)):
                val_cell.number_format = "#,##0.00;(#,##0.00)"
            desc_cell = ws.cell(row=r, column=5, value=f"{flag.description}\nRule: {flag.threshold_rule}")
            desc_cell.font = Font(name="Arial", size=8, color="595959")
            desc_cell.alignment = Alignment(wrap_text=True, vertical="top")
            ws.row_dimensions[r].height = 32
            r += 1

    r += 1
    ws.cell(row=r, column=1, value="Not Assessed in this Module (scope limitation, not a clean result)").font = \
        Font(bold=True, name="Arial", size=10, color="C00000")
    r += 1
    seen_na = set()
    for flags in (sa_flags, co_flags):
        if flags is None:
            continue
        for na in flags.not_assessed:
            if na in seen_na:
                continue
            seen_na.add(na)
            ws.cell(row=r, column=1, value=na).font = Font(name="Arial", size=8, italic=True, color="595959")
            ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncols)
            r += 1

    widths = [38, 12, 10, 12, 70]
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = f"A{hdr_row+1}"


def _simple_cover(wb, title, company, extra_lines=None):
    ws = wb.create_sheet("Cover")
    ws.sheet_view.showGridLines = False
    _style_title(ws, 2, 5, title)
    ws.cell(row=4, column=1, value="Company:").font = Font(bold=True, name="Arial")
    ws.cell(row=4, column=2, value=company.company_name or company.report_title or "—").font = Font(name="Arial")
    ws.cell(row=5, column=1, value="Source File:").font = Font(bold=True, name="Arial")
    ws.cell(row=5, column=2, value=company.source_file or "—").font = Font(name="Arial")
    r = 7
    for line in (extra_lines or []):
        ws.cell(row=r, column=1, value=line).font = Font(name="Arial", size=10)
        r += 1
    for i, w in enumerate([22, 60], start=1):
        ws.column_dimensions[get_column_letter(i)].width = w
    return ws


def to_excel_module2(company: CompanyFinancials, output_path: str):
    """Module 2 only: Ratio Analysis + Formula Disclosures, as its own workbook."""
    from .ratios import build_ratio_analysis

    sa_mapped = company.mapped.get("standalone")
    co_mapped = company.mapped.get("consolidated")
    sa_ra = build_ratio_analysis(sa_mapped) if sa_mapped else None
    co_ra = build_ratio_analysis(co_mapped) if co_mapped else None

    wb = Workbook()
    wb.remove(wb.active)
    _simple_cover(wb, "FS Analyser Pro — Module 2: Ratio Analysis", company, [
        "Contents:",
        "  1. Ratio Analysis — Standalone & Consolidated, side by side",
        "  2. Formula Disclosures — exact formula behind every figure",
    ])
    _write_ratio_sheet(wb, sa_ra, co_ra)
    _write_formula_sheet(wb, sa_ra, co_ra)
    wb.save(output_path)
    return output_path, sa_ra, co_ra


def to_excel_module3(company: CompanyFinancials, output_path: str, pdf_paths_for_trend=None,
                      precomputed_trends=None, precomputed_trend_warnings=None):
    """Module 3 only: Long-Term Trend, as its own workbook."""
    if precomputed_trends is not None or precomputed_trend_warnings is not None:
        trends = precomputed_trends
        trend_warnings = precomputed_trend_warnings or []
    else:
        trends = None
        trend_warnings = []
        if pdf_paths_for_trend:
            from .trend_extractor import extract_long_term_track_record
            from .trends import build_trend_analysis
            trend_data = extract_long_term_track_record(pdf_paths_for_trend)
            trend_warnings = trend_data.warnings
            if trend_data.years:
                trends = build_trend_analysis(trend_data)

    wb = Workbook()
    wb.remove(wb.active)
    extra = ["Contents:", "  1. Long-Term Trend — company-disclosed multi-year track record"]
    if trend_warnings:
        extra.append("")
        extra.append("Trend extraction warnings:")
        extra.extend(f"  - {w}" for w in trend_warnings)
    ws = _simple_cover(wb, "FS Analyser Pro — Module 3: Long-Term Trend", company, extra)
    for i, line in enumerate(extra):
        if line.startswith("  - "):
            ws.cell(row=7 + i, column=1).font = Font(name="Arial", size=9, color="C00000")

    if trends:
        _write_trend_sheet(wb, trends)
    else:
        ws2 = wb.create_sheet("Long-Term Trend")
        ws2.cell(row=1, column=1,
                 value="No company-disclosed 'Long-term Track Record' table was found in this PDF. "
                       "This sheet is intentionally empty rather than estimated.").font = Font(name="Arial", italic=True)
    wb.save(output_path)
    return output_path, trends


def to_excel_module4(company: CompanyFinancials, output_path: str):
    """Module 4 only: Red Flag Detection, as its own workbook."""
    from .ratios import build_ratio_analysis
    from .red_flags import build_red_flag_report

    sa_mapped = company.mapped.get("standalone")
    co_mapped = company.mapped.get("consolidated")
    sa_ra = build_ratio_analysis(sa_mapped) if sa_mapped else None
    co_ra = build_ratio_analysis(co_mapped) if co_mapped else None
    sa_flags = build_red_flag_report("standalone", sa_mapped, sa_ra) if sa_mapped else None
    co_flags = build_red_flag_report("consolidated", co_mapped, co_ra) if co_mapped else None

    wb = Workbook()
    wb.remove(wb.active)
    extra = ["Contents:", "  1. Red Flag Detection — quantitative rule-based checks (see sheet for scope limits)"]
    counts = {}
    for flags in (sa_flags, co_flags):
        if flags:
            for k, v in flags.summary_counts().items():
                if v > 0 and k != "NONE":
                    counts[f"{flags.basis}_{k}"] = v
    if counts:
        extra.append("")
        extra.append("Red Flag Summary:")
        extra.extend(f"  {k}: {v}" for k, v in counts.items())
    _simple_cover(wb, "FS Analyser Pro — Module 4: Red Flag Detection", company, extra)
    _write_red_flag_sheet(wb, sa_flags, co_flags)
    wb.save(output_path)
    return output_path, sa_flags, co_flags


def to_excel_ratios(company: CompanyFinancials, output_path: str, pdf_paths_for_trend=None,
                     precomputed_trends=None, precomputed_trend_warnings=None) -> str:
    """Legacy combined Modules 2-4 workbook — kept for CLI backward compatibility.
    The Streamlit app now uses to_excel_module2/3/4 separately instead."""
    from .ratios import build_ratio_analysis
    from .red_flags import build_red_flag_report

    sa_mapped = company.mapped.get("standalone")
    co_mapped = company.mapped.get("consolidated")
    sa_ra = build_ratio_analysis(sa_mapped) if sa_mapped else None
    co_ra = build_ratio_analysis(co_mapped) if co_mapped else None

    sa_flags = build_red_flag_report("standalone", sa_mapped, sa_ra) if sa_mapped else None
    co_flags = build_red_flag_report("consolidated", co_mapped, co_ra) if co_mapped else None

    if precomputed_trends is not None or precomputed_trend_warnings is not None:
        trends = precomputed_trends
        trend_warnings = precomputed_trend_warnings or []
    else:
        trends = None
        trend_warnings = []
        if pdf_paths_for_trend:
            from .trend_extractor import extract_long_term_track_record
            from .trends import build_trend_analysis
            trend_data = extract_long_term_track_record(pdf_paths_for_trend)
            trend_warnings = trend_data.warnings
            if trend_data.years:
                trends = build_trend_analysis(trend_data)

    wb = Workbook()
    wb.remove(wb.active)

    ws = wb.create_sheet("Cover")
    ws.sheet_view.showGridLines = False
    _style_title(ws, 2, 5, "FS Analyser Pro — Module 2, 3 & 4 Output")
    ws.cell(row=4, column=1, value="Company:").font = Font(bold=True, name="Arial")
    ws.cell(row=4, column=2, value=company.company_name or company.report_title or "—").font = Font(name="Arial")
    ws.cell(row=5, column=1, value="Source File:").font = Font(bold=True, name="Arial")
    ws.cell(row=5, column=2, value=company.source_file or "—").font = Font(name="Arial")
    ws.cell(row=7, column=1, value="Contents:").font = Font(bold=True, name="Arial")
    ws.cell(row=8, column=1, value="  1. Ratio Analysis — Standalone & Consolidated, side by side").font = Font(name="Arial")
    ws.cell(row=9, column=1, value="  2. Formula Disclosures — exact formula behind every figure").font = Font(name="Arial")
    ws.cell(row=10, column=1, value="  3. Long-Term Trend — company-disclosed multi-year track record").font = Font(name="Arial")
    ws.cell(row=11, column=1, value="  4. Red Flag Detection — quantitative rule-based checks (see sheet for scope limits)").font = Font(name="Arial")
    if sa_flags or co_flags:
        counts = {}
        for flags in (sa_flags, co_flags):
            if flags:
                for k, v in flags.summary_counts().items():
                    counts[f"{flags.basis}_{k}"] = v
        ws.cell(row=13, column=1, value="Red Flag Summary:").font = Font(bold=True, name="Arial")
        rr = 14
        for k, v in counts.items():
            if v > 0 and "NONE" not in k:
                ws.cell(row=rr, column=1, value=f"  {k}: {v}").font = Font(name="Arial", size=9)
                rr += 1
    if trend_warnings:
        ws.cell(row=17, column=1, value="Trend extraction warnings:").font = Font(bold=True, name="Arial", color="C00000")
        rr = 18
        for w in trend_warnings:
            ws.cell(row=rr, column=1, value=f"  - {w}").font = Font(name="Arial", size=9, color="C00000")
            rr += 1
    for i, w in enumerate([22, 60], start=1):
        ws.column_dimensions[get_column_letter(i)].width = w

    _write_ratio_sheet(wb, sa_ra, co_ra)
    _write_formula_sheet(wb, sa_ra, co_ra)
    if trends:
        _write_trend_sheet(wb, trends)
    _write_red_flag_sheet(wb, sa_flags, co_flags)

    wb.save(output_path)
    return output_path, sa_ra, co_ra

"""
FS Analyser Pro — Module 1: PDF Extraction Engine
Statement locator

Scans the PDF's text layer for Schedule III statement titles and returns
the page span each statement occupies. Deliberately title-driven (not a
fixed page-number lookup) so it survives a report growing/shrinking by a
few pages year to year, and generalised across the title-wording
variations actually observed across different Indian listed companies:

  - Basis prefix ("Standalone"/"Consolidated") may be ABSENT from the
    title line entirely (seen in Nestlé India's filing) — resolved here
    by nearest-neighbour inference from the closest OTHER statement title
    in the document that DOES carry an explicit basis.
  - The title line may carry trailing text on the same line (e.g.
    "STANDALONE BALANCE SHEET AS AT 31st MARCH, 2026") rather than being
    a clean, standalone line (as in HUL's filing) — matched via a
    start-anchored, not full-line, pattern.
  - A statement's header may REPEAT on each of its own continuation pages
    (Nestlé) rather than appearing once (HUL) — consecutive same-type,
    same-basis title hits are merged into one span rather than treated as
    duplicate statements.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List, Optional, Dict, Tuple

import pdfplumber

CORE_PATTERNS = {
    "balance_sheet": r"BALANCE\s+SHEET\b",
    "profit_and_loss": r"STATEMENT\s+OF\s+PROFIT\s+AND\s+LOSS\b",
    "cash_flow": r"STATEMENT\s+OF\s+CASH\s+FLOWS?\b",
    "changes_in_equity": r"STATEMENT\s+OF\s+CHANGES\s+IN\s+EQUITY\b",
}
# Start-anchored (not full-line) — an optional basis prefix, then the core
# phrase; anything may follow on the same line (dates, "AS AT ...", etc.).
STATEMENT_TITLES = {
    stype: re.compile(rf"^(?:(STANDALONE|CONSOLIDATED)\s+)?{pat}", re.IGNORECASE)
    for stype, pat in CORE_PATTERNS.items()
}

NOTES_TITLE = re.compile(r"^NOTES\b", re.IGNORECASE)
CFS_END_MARKER = re.compile(r"has been prepared under the .Indirect Method.", re.IGNORECASE)

LINES_TO_SCAN_PER_PAGE = 6  # skip deeper into the page than just the first line,
                            # to get past running headers (page no. / company name)


@dataclass
class LocatedStatement:
    statement_type: str   # "balance_sheet" | "profit_and_loss" | "cash_flow" | "changes_in_equity"
    basis: str             # "Standalone" | "Consolidated" | "Unspecified"
    start_page: int        # 1-indexed, inclusive
    end_page: int          # 1-indexed, inclusive
    basis_inferred: bool = False   # True if basis was not stated on the title line itself


def _looks_like_title(line: str) -> bool:
    """Reject incidental sentence-wrapped text that happens to start with a
    statement-title phrase (e.g. '...consolidated\\nstatement of profit and
    loss are as follows:' wrapping onto its own line). Genuine statement
    titles are always ALL CAPS or Title Case, never plain sentence case."""
    letters = [c for c in line if c.isalpha()]
    if not letters:
        return False
    if all(c.isupper() for c in letters):
        return True
    first_word = line.split()[0] if line.split() else ""
    return bool(first_word) and first_word[0].isupper()


def _candidate_lines(page) -> List[str]:
    text = page.extract_text() or ""
    lines = [l.strip() for l in text.split("\n") if l.strip()]
    return lines[:LINES_TO_SCAN_PER_PAGE]


def _find_raw_matches(pdf) -> List[Tuple[int, str, Optional[str]]]:
    """Returns [(page_no, statement_type, basis_or_None)] in document order."""
    matches: List[Tuple[int, str, Optional[str]]] = []
    for i, page in enumerate(pdf.pages, start=1):
        for line in _candidate_lines(page):
            if not _looks_like_title(line):
                continue
            for stype, pattern in STATEMENT_TITLES.items():
                m = pattern.match(line)
                if m:
                    basis = m.group(1).capitalize() if m.group(1) else None
                    matches.append((i, stype, basis))
                    break  # one statement-type match per line is enough
    return matches


def _resolve_missing_basis(matches: List[Tuple[int, str, Optional[str]]]) -> List[Tuple[int, str, str, bool]]:
    """For entries with basis=None, use the basis of the nearest (by page
    distance) OTHER entry that has an explicit basis. This correctly
    handles a title line that omits the qualifier but sits between two
    explicitly-labelled statements of the same basis (or right at the
    boundary into a new basis section)."""
    explicit_idx = [idx for idx, m in enumerate(matches) if m[2] is not None]
    resolved: List[Tuple[int, str, str, bool]] = []
    for idx, (page_no, stype, basis) in enumerate(matches):
        if basis is not None:
            resolved.append((page_no, stype, basis, False))
            continue
        if not explicit_idx:
            resolved.append((page_no, stype, "Unspecified", True))
            continue
        nearest = min(explicit_idx, key=lambda j: abs(matches[j][0] - page_no))
        resolved.append((page_no, stype, matches[nearest][2], True))
    return resolved


def _merge_runs(resolved: List[Tuple[int, str, str, bool]]) -> List[Tuple[int, int, str, str, bool]]:
    """Merge consecutive (adjacent-page) hits of the SAME type+basis into
    one run: (start_page, last_hit_page, statement_type, basis, basis_inferred)."""
    runs: List[List] = []
    for page_no, stype, basis, inferred in resolved:
        if runs and runs[-1][2] == stype and runs[-1][3] == basis and page_no - runs[-1][1] <= 1:
            runs[-1][1] = page_no
            runs[-1][4] = runs[-1][4] or inferred
        else:
            runs.append([page_no, page_no, stype, basis, inferred])
    return [tuple(r) for r in runs]


def locate_statements(pdf_path: str) -> List[LocatedStatement]:
    with pdfplumber.open(pdf_path) as pdf:
        n_pages = len(pdf.pages)
        raw_matches = _find_raw_matches(pdf)
        resolved = _resolve_missing_basis(raw_matches)
        runs = _merge_runs(resolved)

        # Candidate lines (first few non-header lines) of every page, for
        # the forward-scan boundary check below — using only the literal
        # first line fails whenever a page has a running header (company
        # name / page number) as its actual first line, which is common.
        page_candidate_lines = [_candidate_lines(page) for page in pdf.pages]

        def _page_has_boundary_marker(lines: List[str]) -> bool:
            for line in lines:
                if not _looks_like_title(line):
                    continue
                if NOTES_TITLE.match(line):
                    return True
                if any(p.match(line) for p in STATEMENT_TITLES.values()):
                    return True
            return False

        results: List[LocatedStatement] = []
        for run_start, run_last_hit, stype, basis, inferred in runs:
            end = run_last_hit
            for j in range(run_last_hit, n_pages):
                if _page_has_boundary_marker(page_candidate_lines[j]):
                    break
                end = j + 1
            results.append(LocatedStatement(
                statement_type=stype,
                basis=basis,
                start_page=run_start,
                end_page=end,
                basis_inferred=inferred,
            ))

    return results


def get_statement_pages(pdf_path: str, statement_type: str, basis: str) -> Optional[List[int]]:
    """Convenience: return the list of page numbers for one statement/basis."""
    stmts = locate_statements(pdf_path)
    for s in stmts:
        if s.statement_type == statement_type and s.basis.lower() == basis.lower():
            return list(range(s.start_page, s.end_page + 1))
    return None

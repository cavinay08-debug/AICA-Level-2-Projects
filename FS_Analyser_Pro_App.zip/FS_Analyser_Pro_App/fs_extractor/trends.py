"""
FS Analyser Pro — Module 3: Trend Analysis Engine
Trend computation

Works on LongTermTrendData (trend_extractor.py) — the company's OWN
disclosed multi-year figures — and computes:
  - Year-on-Year growth % for every consecutive year pair actually present
  - CAGR from the first to the last available year for that metric
  - A simple directional flag (Rising / Falling / Flat / Mixed) based on
    the sign pattern of YoY changes — descriptive only, not a
    qualitative "Good/Bad" judgement call.

No figure here is invented: if a metric has a gap year (e.g. a company's
FY24 report doesn't disclose FY18), the YoY calc for that gap is skipped
and flagged, not interpolated.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from .trend_extractor import LongTermTrendData


@dataclass
class MetricTrend:
    key: str
    label: str
    unit: str
    years: List[str]
    values: List[Optional[float]]
    yoy_growth_pct: Dict[str, Optional[float]] = field(default_factory=dict)  # keyed by the LATER year in the pair
    cagr_pct: Optional[float] = None
    cagr_period: Optional[str] = None
    direction: Optional[str] = None
    gaps: List[str] = field(default_factory=list)


def _cagr(first: Optional[float], last: Optional[float], n_years: int) -> Optional[float]:
    if first is None or last is None or first <= 0 or n_years <= 0:
        return None
    return round(((last / first) ** (1.0 / n_years) - 1) * 100, 2)


def build_trend_analysis(data: LongTermTrendData) -> Dict[str, MetricTrend]:
    trends: Dict[str, MetricTrend] = {}
    years = data.years

    for key, year_vals in data.metrics.items():
        if not year_vals:
            continue  # no data found for this metric in any supplied PDF — omit rather than show an empty row
        label = data.metric_labels.get(key, key)
        unit = data.metric_units.get(key, "")
        values = [year_vals.get(y) for y in years]
        mt = MetricTrend(key=key, label=label, unit=unit, years=list(years), values=values)

        # Gaps
        for y, v in zip(years, values):
            if v is None:
                mt.gaps.append(y)

        # YoY growth for every consecutive pair where BOTH years present
        for i in range(1, len(years)):
            y_prev, y_cur = years[i - 1], years[i]
            v_prev, v_cur = values[i - 1], values[i]
            if v_prev is not None and v_cur is not None and v_prev != 0:
                mt.yoy_growth_pct[y_cur] = round(((v_cur - v_prev) / v_prev) * 100, 2)
            else:
                mt.yoy_growth_pct[y_cur] = None

        # CAGR from first to last AVAILABLE (non-None) data point
        available = [(y, v) for y, v in zip(years, values) if v is not None]
        if len(available) >= 2:
            first_y, first_v = available[0]
            last_y, last_v = available[-1]
            n_years = int(last_y[:4]) - int(first_y[:4])  # "2015-16" -> 2015
            mt.cagr_pct = _cagr(first_v, last_v, n_years) if n_years > 0 else None
            mt.cagr_period = f"{first_y} to {last_y} ({n_years} years)"

        # Direction: based on sign of YoY changes (descriptive, not evaluative)
        signs = [1 if v > 0 else (-1 if v < 0 else 0) for v in mt.yoy_growth_pct.values() if v is not None]
        if not signs:
            mt.direction = None
        elif all(s > 0 for s in signs):
            mt.direction = "Rising throughout"
        elif all(s < 0 for s in signs):
            mt.direction = "Falling throughout"
        elif all(s == 0 for s in signs):
            mt.direction = "Flat"
        else:
            pos = sum(1 for s in signs if s > 0)
            neg = sum(1 for s in signs if s < 0)
            mt.direction = f"Mixed ({pos} up-years, {neg} down-years)"

        trends[key] = mt

    return trends

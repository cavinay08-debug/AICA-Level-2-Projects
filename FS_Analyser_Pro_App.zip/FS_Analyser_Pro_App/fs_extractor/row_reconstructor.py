"""
FS Analyser Pro — Module 1: PDF Extraction Engine
Row reconstruction

Indian Ind-AS / Schedule III financial statements are typeset as text-only
tables (no ruling lines) with four visual columns: Label | Note | Value(Yr1)
| Value(Yr2). A material engineering problem is that long labels wrap across
2-3 physical lines while the corresponding value pair prints on the
VERTICAL MIDPOINT of the wrapped label (not on its first or last line), and
label continuation text can appear both before and after the value line.
A naive line-by-line regex parser misattributes these wrapped labels.

This module solves it with 1-D nearest-anchor (Voronoi) assignment:
  1. Locate value-pairs on the page (two numeric tokens sharing the same
     vertical position) -> these are the "row anchors".
  2. Assign every label-column word to its NEAREST anchor by vertical
     distance, regardless of whether the word appears above or below the
     anchor's own line.
  3. Recognised section headings (ASSETS, Non-current assets, etc.) are
     excluded from the label pool and carried forward as context.

This generalises to any Ind-AS Schedule III formatted statement, not just
the specific filing used to build/test this module.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List, Optional, Dict, Any

import pdfplumber

# ---------------------------------------------------------------------------
# Section / sub-section headings commonly seen in Schedule III statements.
# Extend this list if a new company's report uses different wording.
# ---------------------------------------------------------------------------
KNOWN_SUBHEADINGS = {
    "assets", "equity and liabilities", "equity", "liabilities",
    "non-current assets", "current assets", "non-current liabilities",
    "current liabilities", "financial assets", "financial liabilities",
    "income", "expenses", "continuing operations", "discontinued operations",
    "other comprehensive income",
    "items that will not be reclassified to profit or loss",
    "items that will be reclassified to profit or loss",
    "for continuing operations", "for discontinued operations",
    "for continuing and discontinued operations",
    "a cash flows from operating activities:", "a cash flows from operating activities",
    "b cash flows from investing activities:", "b cash flows from investing activities",
    "c cash flows from financing activities:", "c cash flows from financing activities",
    "adjustments for:",
}

NUMERIC_TOKEN_RE = re.compile(
    r"^\(?[A-Za-z₹]{0,3}\.?\s*[\d,]+\.?\d*\)?$|^[-–—]$"
)
NOTE_TOKEN_RE = re.compile(r"^[0-9]{1,3}[A-Za-z]{0,2}$")


def _clean_number(tok: str) -> Optional[float]:
    """Convert a printed numeric token to float. Parentheses = negative. '-' = 0.0 (nil).

    Different PDFs map the rupee symbol to a different single-letter
    substitute depending on how the embedded font encodes glyph 'Rs.'
    (observed: 'H' in one filing, 'J' in another) — rather than hardcode
    one glyph, strip any leading run of 1-3 alphabetic characters (with an
    optional trailing '.') that precedes a digit run, since a genuine
    numeric token never legitimately starts with letters otherwise.
    """
    if tok is None:
        return None
    t = tok.strip()
    m = re.match(r"^([A-Za-z₹]{1,3}\.?)\s*(\(?[\d,.\-–—]+\)?)$", t)
    if m:
        t = m.group(2)
    if t in ("-", "–", "—", ""):
        return 0.0
    neg = t.startswith("(") and t.endswith(")")
    t = t.strip("()")
    t = t.replace(",", "")
    try:
        val = float(t)
    except ValueError:
        return None
    return -val if neg else val


@dataclass
class RawRow:
    label: str
    note: Optional[str]
    value_current: Optional[float]
    value_previous: Optional[float]
    section: Optional[str]
    top: float
    page_no: int


def _words(page) -> List[Dict[str, Any]]:
    return page.extract_words(use_text_flow=False, keep_blank_chars=False, extra_attrs=["size"])


def reconstruct_page_rows(
    page,
    page_no: int,
    header_cutoff: float = 0.0,
    footer_cutoff: Optional[float] = None,
) -> Dict[str, Any]:
    """
    Reconstruct label/note/value rows for one page of a financial statement.
    Returns a dict: {"rows": [...], "running_section": str|None,
                     "period_current": str|None, "period_previous": str|None}
    """
    words = _words(page)
    page_height = page.height
    if footer_cutoff is None:
        footer_cutoff = page_height - 40  # exclude repeating page-number footer

    words = [w for w in words if header_cutoff < w["top"] < footer_cutoff]
    if not words:
        return {"rows": [], "running_section": None, "period_current": None, "period_previous": None}

    # --- Determine column bands from this page's own header row -----------
    # Primary anchor: the word "Note" (Balance Sheet / P&L have a Note
    # column). Some statements (e.g. Cash Flow Statement) have no Note
    # column at all, so we fall back to locating the physical line that
    # carries TWO 4-digit year tokens together — the statement's title line
    # (e.g. "for the year ended 31st March, 2026") mentions only ONE year,
    # so this reliably distinguishes the true header row from the title.
    upper_zone = [w for w in words if w["top"] < header_cutoff + 160]
    # The genuine Note/Notes COLUMN HEADER always sits on the same physical
    # line as "Particulars". Without this check, a stray "(refer Note 14)"
    # reference inside an ordinary data row (common on continuation pages)
    # gets mistaken for the header, corrupting the whole column layout.
    particulars_word = next((w for w in upper_zone if w["text"].strip().lower() == "particulars"), None)
    if particulars_word is not None:
        note_hdr = next(
            (w for w in upper_zone
             if w["text"].strip().lower() in ("note", "notes")
             and abs(w["top"] - particulars_word["top"]) < 3.0),
            None,
        )
    else:
        note_hdr = None

    if note_hdr is not None:
        hdr_top = note_hdr["top"]
    else:
        from collections import defaultdict as _dd
        by_top = _dd(list)
        for w in upper_zone:
            by_top[round(w["top"], 1)].append(w)
        hdr_top = None
        for t in sorted(by_top.keys()):
            yrs_on_line = [w for w in by_top[t] if re.fullmatch(r"20\d{2}", w["text"].strip())]
            if len(yrs_on_line) >= 2:
                hdr_top = t
                break

    if hdr_top is not None:
        year_zone = [w for w in upper_zone if hdr_top - 5 <= w["top"] <= hdr_top + 20]
    else:
        year_zone = upper_zone
    year_tokens = [w for w in year_zone if re.fullmatch(r"20\d{2}", w["text"].strip())]
    year_tokens = sorted(year_tokens, key=lambda w: w["x0"])

    if note_hdr is not None:
        note_col_x0 = note_hdr["x0"] - 5
    else:
        note_col_x0 = None

    if len(year_tokens) >= 2:
        val1_col_x0 = year_tokens[0]["x0"] - 45
        val2_col_x0 = year_tokens[-1]["x0"] - 45
        # Build the full period label (spanning the "As at"/"Year ended" row
        # plus the "31st March, YYYY" row) from words that sit in each
        # value column's x-range, restricted to the header block only.
        col_split = val2_col_x0
        period_current = re.sub(r"\s+", " ", " ".join(
            w["text"] for w in sorted(year_zone, key=lambda w: (w["top"], w["x0"]))
            if val1_col_x0 <= w["x0"] < col_split
        )).strip()
        period_previous = re.sub(r"\s+", " ", " ".join(
            w["text"] for w in sorted(year_zone, key=lambda w: (w["top"], w["x0"]))
            if w["x0"] >= col_split
        )).strip()
    else:
        # Fallback: infer from rightmost numeric tokens overall (rare pages)
        val1_col_x0 = None
        val2_col_x0 = None
        period_current = period_previous = None

    # Data rows start strictly below the column-header row itself, so that
    # the header's own year tokens (and the statement title above it, which
    # may repeat the reporting year) are never mistaken for a data anchor.
    data_start_top = (hdr_top + 16) if hdr_top is not None else header_cutoff
    words = [w for w in words if w["top"] > data_start_top]

    # --- Classify every word into a column bucket ---------------------------
    label_words, note_words, val1_words, val2_words = [], [], [], []

    for w in words:
        text = w["text"].strip()
        if not text:
            continue
        x0 = w["x0"]
        if val1_col_x0 is not None and x0 >= val2_col_x0:
            val2_words.append(w)
        elif val1_col_x0 is not None and x0 >= val1_col_x0:
            val1_words.append(w)
        elif note_col_x0 is not None and x0 >= note_col_x0:
            note_words.append(w)
        else:
            label_words.append(w)

    # If column detection failed (no header on this continuation page), bail
    # out gracefully — caller will skip / flag this page.
    if val1_col_x0 is None:
        return {"rows": [], "running_section": None, "period_current": None, "period_previous": None}

    # --- Build row anchors: pair val1/val2 tokens sharing near-identical top
    def numeric_ok(tok):
        t = tok["text"].strip()
        return bool(NUMERIC_TOKEN_RE.match(t)) and any(ch.isdigit() for ch in t) or t in ("-", "–", "—")

    val1_nums = [w for w in val1_words if numeric_ok(w)]
    val2_nums = [w for w in val2_words if numeric_ok(w)]

    anchors = []  # list of dict: top, note, value_current, value_previous
    used_v2 = set()
    for v1 in sorted(val1_nums, key=lambda w: w["top"]):
        best = None
        best_dist = None
        for idx, v2 in enumerate(val2_nums):
            if idx in used_v2:
                continue
            d = abs(v2["top"] - v1["top"])
            if d < 4.0 and (best_dist is None or d < best_dist):
                best = idx
                best_dist = d
        if best is not None:
            used_v2.add(best)
            v2w = val2_nums[best]
            anchors.append({
                "top": (v1["top"] + v2w["top"]) / 2.0,
                "value_current": _clean_number(v1["text"]),
                "value_previous": _clean_number(v2w["text"]),
            })
        else:
            # single-column value row (rare) — still register as anchor
            anchors.append({
                "top": v1["top"],
                "value_current": _clean_number(v1["text"]),
                "value_previous": None,
            })

    if not anchors:
        return {"rows": [], "running_section": None, "period_current": period_current, "period_previous": period_previous}

    anchors.sort(key=lambda a: a["top"])

    # --- Attach nearest note token to each anchor ---------------------------
    for a in anchors:
        nearest_note = None
        nearest_d = None
        for nw in note_words:
            if not NOTE_TOKEN_RE.match(nw["text"].strip()):
                continue
            d = abs(nw["top"] - a["top"])
            if d < 8.0 and (nearest_d is None or d < nearest_d):
                nearest_note = nw["text"].strip()
                nearest_d = d
        a["note"] = nearest_note

    # --- Separate section-heading words from label words --------------------
    # Group label words into physical lines first (by rounded top) to detect
    # standalone heading lines.
    from collections import defaultdict
    lines: Dict[float, List[Dict]] = defaultdict(list)
    for w in label_words:
        lines[round(w["top"], 1)].append(w)

    heading_tops = set()
    for top, ws in lines.items():
        ws_sorted = sorted(ws, key=lambda w: w["x0"])
        line_text = " ".join(w["text"] for w in ws_sorted).strip()
        norm = re.sub(r"\s+", " ", line_text).strip().lower()
        word_count = len(line_text.split())
        # Genuine section headers (ASSETS, EXPENSES, CONTINUING OPERATIONS,
        # EQUITY AND LIABILITIES...) are short (<=4 words). A long all-caps
        # phrase (e.g. "PROFIT BEFORE EXCEPTIONAL ITEMS AND TAX FROM
        # CONTINUING") is a wrapped LINE-ITEM label, not a header, even
        # though it happens to be printed in capitals — excluding it here
        # would silently drop that row's label text.
        is_all_caps = (
            bool(re.fullmatch(r"[A-Z0-9][A-Z0-9 \-&/,():]+", line_text))
            and len(line_text) > 3
            and word_count <= 4
        )
        is_known = norm in KNOWN_SUBHEADINGS
        # Only treat as heading if no anchor sits essentially on this exact line
        near_anchor = any(abs(top - a["top"]) < 2.0 for a in anchors)
        if (is_all_caps or is_known) and not near_anchor:
            heading_tops.add(top)

    running_section = None
    section_by_top = {}
    for top in sorted(lines.keys()):
        if top in heading_tops:
            ws_sorted = sorted(lines[top], key=lambda w: w["x0"])
            running_section = re.sub(r"\s+", " ", " ".join(w["text"] for w in ws_sorted)).strip()
        section_by_top[top] = running_section

    # --- Nearest-anchor assignment for remaining label words -----------------
    anchor_tops = [a["top"] for a in anchors]
    assigned: Dict[int, List[Dict]] = defaultdict(list)  # anchor idx -> words

    for top, ws in lines.items():
        if top in heading_tops:
            continue
        # nearest anchor index by vertical distance
        nearest_idx = min(range(len(anchor_tops)), key=lambda i: abs(anchor_tops[i] - top))
        assigned[nearest_idx].extend(ws)

    rows: List[RawRow] = []
    for i, a in enumerate(anchors):
        ws = assigned.get(i, [])
        ws_sorted = sorted(ws, key=lambda w: (round(w["top"], 1), w["x0"]))
        label = re.sub(r"\s+", " ", " ".join(w["text"] for w in ws_sorted)).strip()
        # section context = section active at the anchor's own top (nearest known)
        candidate_tops = [t for t in section_by_top if t <= a["top"] + 2]
        section = section_by_top[max(candidate_tops)] if candidate_tops else None
        if not label:
            continue
        rows.append(RawRow(
            label=label,
            note=a.get("note"),
            value_current=a.get("value_current"),
            value_previous=a.get("value_previous"),
            section=section,
            top=a["top"],
            page_no=page_no,
        ))

    return {
        "rows": rows,
        "running_section": running_section,
        "period_current": period_current,
        "period_previous": period_previous,
    }

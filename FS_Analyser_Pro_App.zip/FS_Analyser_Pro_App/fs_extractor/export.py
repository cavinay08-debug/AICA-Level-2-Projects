"""
FS Analyser Pro — Module 1: PDF Extraction Engine
Export utilities: JSON and Excel (navy/gold house style)
"""
from __future__ import annotations

import json
from typing import Any, Dict

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

from .models import CompanyFinancials

NAVY = "1F3864"
GOLD = "BF9000"
LIGHT_GOLD = "FDF2CC"
WHITE = "FFFFFF"


def to_json(company: CompanyFinancials) -> str:
    payload: Dict[str, Any] = {
        "company_name": company.company_name,
        "report_title": company.report_title,
        "source_file": company.source_file,
        "extraction_warnings": company.extraction_warnings,
        "statements": {
            key: {
                "statement_type": blk.statement_type,
                "basis": blk.basis,
                "period_current": blk.period_label_current,
                "period_previous": blk.period_label_previous,
                "unit": blk.unit,
                "page_range": blk.page_range,
                "line_items": blk.to_records(),
            }
            for key, blk in company.statements.items()
        },
        "mapped_financials": {
            basis: {
                "fields": m.fields,
                "formulas": m.formulas,
            }
            for basis, m in company.mapped.items()
        },
        "validation_results": company.validation_results,
    }
    return json.dumps(payload, indent=2, default=str)


def _style_header(ws, row_idx, ncols):
    for c in range(1, ncols + 1):
        cell = ws.cell(row=row_idx, column=c)
        cell.font = Font(bold=True, color=WHITE, name="Arial", size=10)
        cell.fill = PatternFill("solid", fgColor=NAVY)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)


def _style_title(ws, row_idx, ncols, text):
    ws.merge_cells(start_row=row_idx, start_column=1, end_row=row_idx, end_column=ncols)
    cell = ws.cell(row=row_idx, column=1, value=text)
    cell.font = Font(bold=True, color=WHITE, name="Arial", size=13)
    cell.fill = PatternFill("solid", fgColor=NAVY)
    cell.alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[row_idx].height = 22


def _write_statement_sheet(wb, key, block):
    sheet_name = key.replace("_", " ").title()[:31]
    ws = wb.create_sheet(sheet_name)
    ncols = 6

    _style_title(ws, 1, ncols, f"{block.basis} {block.statement_type}")
    ws.cell(row=2, column=1, value=f"Unit: {block.unit or 'Not disclosed on statement'}").font = Font(
        italic=True, size=9, name="Arial", color="595959")
    ws.cell(row=3, column=1, value=f"Source pages: {block.page_range}").font = Font(
        italic=True, size=9, name="Arial", color="595959")

    headers = ["Section", "Particulars", "Note", block.period_label_current or "Current Year",
               block.period_label_previous or "Previous Year", "Page"]
    hdr_row = 5
    for c, h in enumerate(headers, start=1):
        ws.cell(row=hdr_row, column=c, value=h)
    _style_header(ws, hdr_row, ncols)

    thin = Side(style="thin", color="D9D9D9")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    r = hdr_row + 1
    for li in block.line_items:
        vals = [li.section, li.label, li.note, li.value_current, li.value_previous, li.page_no]
        for c, v in enumerate(vals, start=1):
            cell = ws.cell(row=r, column=c, value=v)
            cell.border = border
            cell.font = Font(name="Arial", size=10,
                              bold=li.is_subtotal, color=NAVY if li.is_subtotal else "000000")
            if c in (4, 5) and isinstance(v, (int, float)):
                cell.number_format = "#,##0.00;(#,##0.00)"
                cell.alignment = Alignment(horizontal="right")
            if li.is_subtotal:
                cell.fill = PatternFill("solid", fgColor=LIGHT_GOLD)
        r += 1

    widths = [20, 55, 8, 16, 16, 8]
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = f"A{hdr_row+1}"


def _write_mapped_sheet(wb, company: CompanyFinancials):
    ws = wb.create_sheet("Standardised Financials")
    ncols = 5
    _style_title(ws, 1, ncols, "Standardised Financials & Derived Metrics (with formulas disclosed)")

    headers = ["Metric", "Standalone (Current)", "Standalone (Previous)",
               "Consolidated (Current)", "Consolidated (Previous)"]
    hdr_row = 3
    for c, h in enumerate(headers, start=1):
        ws.cell(row=hdr_row, column=c, value=h)
    _style_header(ws, hdr_row, ncols)

    sa = company.mapped.get("standalone")
    co = company.mapped.get("consolidated")
    all_keys = []
    seen = set()
    for m in (sa, co):
        if m:
            for k in m.fields:
                base = k.replace("_prev", "")
                if base not in seen:
                    seen.add(base)
                    all_keys.append(base)

    r = hdr_row + 1
    for key in all_keys:
        sa_cur = sa.fields.get(key) if sa else None
        sa_prev = sa.fields.get(f"{key}_prev") if sa else None
        co_cur = co.fields.get(key) if co else None
        co_prev = co.fields.get(f"{key}_prev") if co else None
        label = key.replace("_", " ").title()
        ws.cell(row=r, column=1, value=label).font = Font(name="Arial", size=10, bold=True, color=NAVY)
        for c, v in enumerate([sa_cur, sa_prev, co_cur, co_prev], start=2):
            cell = ws.cell(row=r, column=c, value=v)
            cell.font = Font(name="Arial", size=10)
            if isinstance(v, (int, float)):
                cell.number_format = "#,##0.00;(#,##0.00)"
                cell.alignment = Alignment(horizontal="right")
        r += 1

    r += 1
    ws.cell(row=r, column=1, value="Formula Disclosures (derived / non-Schedule III metrics)").font = Font(
        bold=True, name="Arial", size=11, color=NAVY)
    r += 1
    formulas = {}
    for m in (sa, co):
        if m:
            formulas.update(m.formulas)
    for key, formula in formulas.items():
        ws.cell(row=r, column=1, value=key.replace("_", " ").title()).font = Font(bold=True, name="Arial", size=9)
        ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=ncols)
        c = ws.cell(row=r, column=2, value=formula)
        c.font = Font(italic=True, name="Arial", size=9, color="595959")
        c.alignment = Alignment(wrap_text=True)
        ws.row_dimensions[r].height = 28
        r += 1

    widths = [28, 20, 20, 20, 20]
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w


def _write_validation_sheet(wb, company: CompanyFinancials):
    ws = wb.create_sheet("Validation & Tie-Outs")
    ncols = 5
    _style_title(ws, 1, ncols, "Extraction Validation — Arithmetic Tie-Out Checks")
    headers = ["Check", "Basis", "Status", "Extracted (LHS)", "Cross-check (RHS)"]
    hdr_row = 3
    for c, h in enumerate(headers, start=1):
        ws.cell(row=hdr_row, column=c, value=h)
    _style_header(ws, hdr_row, ncols)

    r = hdr_row + 1
    green = PatternFill("solid", fgColor="D9EAD3")
    red = PatternFill("solid", fgColor="F4CCCC")
    grey = PatternFill("solid", fgColor="EFEFEF")
    for v in company.validation_results:
        ws.cell(row=r, column=1, value=v["check"]).font = Font(name="Arial", size=9)
        ws.cell(row=r, column=2, value=v["basis"].title()).font = Font(name="Arial", size=9)
        status_cell = ws.cell(row=r, column=3, value=v["status"])
        status_cell.font = Font(name="Arial", size=9, bold=True)
        ws.cell(row=r, column=4, value=v.get("lhs")).font = Font(name="Arial", size=9)
        ws.cell(row=r, column=5, value=v.get("rhs")).font = Font(name="Arial", size=9)
        fill = green if v["status"] == "PASS" else (red if v["status"] == "FAIL" else grey)
        for c in range(1, ncols + 1):
            ws.cell(row=r, column=c).fill = fill
        r += 1

    widths = [58, 14, 10, 16, 16]
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = f"A{hdr_row+1}"


def to_excel(company: CompanyFinancials, output_path: str) -> str:
    wb = Workbook()
    wb.remove(wb.active)

    # Cover sheet
    ws = wb.create_sheet("Cover")
    ws.sheet_view.showGridLines = False
    _style_title(ws, 2, 6, "FS Analyser Pro — Extraction Output")
    ws.cell(row=4, column=1, value="Report Title:").font = Font(bold=True, name="Arial")
    ws.cell(row=4, column=2, value=company.report_title or "—").font = Font(name="Arial")
    ws.cell(row=5, column=1, value="Source File:").font = Font(bold=True, name="Arial")
    ws.cell(row=5, column=2, value=company.source_file or "—").font = Font(name="Arial")
    ws.cell(row=6, column=1, value="Statements Extracted:").font = Font(bold=True, name="Arial")
    ws.cell(row=6, column=2, value=", ".join(company.statements.keys())).font = Font(name="Arial")
    passed = sum(1 for v in company.validation_results if v["status"] == "PASS")
    failed = sum(1 for v in company.validation_results if v["status"] == "FAIL")
    skipped = sum(1 for v in company.validation_results if v["status"] == "SKIPPED")
    ws.cell(row=8, column=1, value="Validation Summary:").font = Font(bold=True, name="Arial")
    ws.cell(row=9, column=1, value=f"  Passed: {passed}   Failed: {failed}   Skipped: {skipped}").font = Font(name="Arial")
    for i, w in enumerate([22, 60], start=1):
        ws.column_dimensions[get_column_letter(i)].width = w

    for key, block in company.statements.items():
        _write_statement_sheet(wb, key, block)

    if company.mapped:
        _write_mapped_sheet(wb, company)

    if company.validation_results:
        _write_validation_sheet(wb, company)

    wb.save(output_path)
    return output_path

"""
FS Analyser Pro — Module 5: Risk & Auditor Analysis
Excel export (separate workbook)
"""
from __future__ import annotations

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

from .risk_auditor import RiskAuditorReport
from .models import CompanyFinancials

NAVY = "1F3864"
GOLD = "BF9000"
LIGHT_GOLD = "FDF2CC"
WHITE = "FFFFFF"
GREEN = "D9EAD3"
RED = "F4CCCC"
GREY = "EFEFEF"


def _style_title(ws, row_idx, ncols, text):
    ws.merge_cells(start_row=row_idx, start_column=1, end_row=row_idx, end_column=ncols)
    cell = ws.cell(row=row_idx, column=1, value=text)
    cell.font = Font(bold=True, color=WHITE, name="Arial", size=13)
    cell.fill = PatternFill("solid", fgColor=NAVY)
    cell.alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[row_idx].height = 22


def _style_header(ws, row_idx, ncols):
    for c in range(1, ncols + 1):
        cell = ws.cell(row=row_idx, column=c)
        cell.font = Font(bold=True, color=WHITE, name="Arial", size=10)
        cell.fill = PatternFill("solid", fgColor=NAVY)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)


def _write_risk_sheet(wb, report: RiskAuditorReport):
    ws = wb.create_sheet("Risk Register")
    ncols = 7
    _style_title(ws, 1, ncols, "FS Analyser Pro — Module 5: Risk Register")
    ws.cell(row=2, column=1,
            value="'Likelihood' = company-disclosed Level of Change (a trend indicator, NOT a probability "
                  "rating). 'Impact' = number of Capitals Impacted disclosed by the company (an approximation, "
                  "NOT a quantified severity score). Neither company independently rates risks on a numeric "
                  "scale — see Module 5 methodology notes.").font = Font(italic=True, size=9, name="Arial", color="595959")

    if not report.risk_register_found:
        ws.cell(row=4, column=1, value="No structured risk register was found in this filing.").font = \
            Font(bold=True, name="Arial", size=11, color="C00000")
        r = 5
        for note in report.not_assessed:
            if "risk register" in note.lower() or "Key Risk" in note:
                ws.cell(row=r, column=1, value=note).font = Font(italic=True, name="Arial", size=9, color="595959")
                ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncols)
                r += 1
        ws.column_dimensions["A"].width = 100
        return

    headers = ["Risk Title", "Category (Company-Disclosed / Normalised)", "Likelihood (Level of Change)",
               "Impact (Capitals Impacted)", "Description", "Mitigation Actions", "Source Page"]
    hdr_row = 4
    for c, h in enumerate(headers, start=1):
        ws.cell(row=hdr_row, column=c, value=h)
    _style_header(ws, hdr_row, ncols)

    level_fill = {"increased": "F4CCCC", "no change": "FDF2CC", "decreased": "D9EAD3"}
    r = hdr_row + 1
    for entry in report.risk_entries:
        ws.cell(row=r, column=1, value=entry.title).font = Font(bold=True, name="Arial", size=10, color=NAVY)
        cat_cell = ws.cell(row=r, column=2, value=f"{entry.category_raw}  →  {entry.category_normalized}")
        cat_cell.font = Font(name="Arial", size=9)
        cat_cell.alignment = Alignment(wrap_text=True)
        level_cell = ws.cell(row=r, column=3, value=entry.level_of_change)
        level_cell.font = Font(name="Arial", size=10, bold=True)
        level_cell.fill = PatternFill("solid", fgColor=level_fill.get(entry.level_of_change.lower(), "FFFFFF"))
        level_cell.alignment = Alignment(horizontal="center")
        impact_cell = ws.cell(row=r, column=4, value=f"{len(entry.capitals_impacted)} capital(s): " +
                               ", ".join(c.replace(" Capital", "") for c in entry.capitals_impacted))
        impact_cell.font = Font(name="Arial", size=9)
        impact_cell.alignment = Alignment(wrap_text=True)
        desc_cell = ws.cell(row=r, column=5, value=entry.description)
        desc_cell.font = Font(name="Arial", size=9)
        desc_cell.alignment = Alignment(wrap_text=True, vertical="top")
        mit_cell = ws.cell(row=r, column=6, value="\n".join(f"• {m}" for m in entry.mitigation_actions))
        mit_cell.font = Font(name="Arial", size=9)
        mit_cell.alignment = Alignment(wrap_text=True, vertical="top")
        ws.cell(row=r, column=7, value=entry.page_no).font = Font(name="Arial", size=9)
        ws.row_dimensions[r].height = 90
        r += 1

    widths = [26, 30, 16, 22, 45, 45, 10]
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = f"A{hdr_row+1}"


def _write_auditor_sheet(wb, report: RiskAuditorReport):
    ws = wb.create_sheet("Auditor Findings")
    ncols = 2
    _style_title(ws, 1, ncols, "FS Analyser Pro — Module 5: Auditor Analysis")

    r = 3
    ws.cell(row=r, column=1, value="Board's Report — Auditor Qualification Disclosure").font = \
        Font(bold=True, name="Arial", size=11, color=NAVY)
    r += 1
    if report.qualification_boilerplate_found:
        status = "CLEAN — no qualification/reservation/adverse remark/disclaimer" if report.qualification_boilerplate_clean \
            else "FLAGGED — qualification/reservation/adverse remark/disclaimer present"
        fill = GREEN if report.qualification_boilerplate_clean else RED
        cell = ws.cell(row=r, column=1, value=status)
        cell.font = Font(bold=True, name="Arial", size=10)
        cell.fill = PatternFill("solid", fgColor=fill)
        r += 1
        ws.cell(row=r, column=1, value=f"Source text: \"{report.qualification_boilerplate_text}\"").font = \
            Font(italic=True, name="Arial", size=9, color="595959")
        ws.cell(row=r, column=1).alignment = Alignment(wrap_text=True)
        r += 2
    else:
        ws.cell(row=r, column=1, value="Standard boilerplate not found — see Auditor's Report opinion below instead.").font = \
            Font(italic=True, name="Arial", size=9, color="C00000")
        r += 2

    for af in report.auditor_findings:
        ws.cell(row=r, column=1, value=f"{af.basis} Auditor's Report").font = \
            Font(bold=True, name="Arial", size=12, color=NAVY)
        r += 1
        rows_data = [
            ("Opinion Type", af.opinion_type),
            ("Opinion Excerpt", af.opinion_excerpt or "—"),
            ("Key Audit Matters — Count", str(af.kam_count)),
            ("Key Audit Matters — Titles", "; ".join(af.kam_titles) if af.kam_titles else "None identified"),
            ("Emphasis of Matter Present", "Yes — review directly" if af.eom_present else "No"),
            ("Internal Financial Controls Opinion",
             "Adequate / Operating Effectively (unmodified)" if af.icfr_opinion_clean is True
             else ("Possible weakness/exception flagged — review directly" if af.icfr_opinion_clean is False
                   else "Not determined from standard phrasing — review directly")),
            ("Source Pages", f"{af.page_range[0]}–{af.page_range[-1]}" if af.page_range else "—"),
        ]
        for label, value in rows_data:
            ws.cell(row=r, column=1, value=label).font = Font(bold=True, name="Arial", size=9)
            vcell = ws.cell(row=r, column=2, value=value)
            vcell.font = Font(name="Arial", size=9)
            vcell.alignment = Alignment(wrap_text=True)
            if label == "Opinion Type":
                vcell.font = Font(bold=True, name="Arial", size=10)
                vcell.fill = PatternFill("solid", fgColor=GREEN if "Unmodified" in value else RED)
            r += 1
        r += 1

    ws.column_dimensions["A"].width = 32
    ws.column_dimensions["B"].width = 90


def _write_implications_sheet(wb, report: RiskAuditorReport):
    ws = wb.create_sheet("Business Implications")
    ncols = 1
    _style_title(ws, 1, ncols, "FS Analyser Pro — Module 5: Business Implications (Data-Driven Summary)")
    ws.cell(row=2, column=1,
            value="Each line below is a direct restatement of a count or a disclosed fact already in this "
                  "workbook — not an interpretive narrative or an AI-generated assessment.").font = \
        Font(italic=True, size=9, name="Arial", color="595959")

    r = 4
    for line in report.business_implications:
        ws.cell(row=r, column=1, value=f"• {line}").font = Font(name="Arial", size=10)
        ws.cell(row=r, column=1).alignment = Alignment(wrap_text=True)
        ws.row_dimensions[r].height = 30
        r += 1

    if report.not_assessed:
        r += 1
        ws.cell(row=r, column=1, value="Not Assessed (scope limitations — not a clean result)").font = \
            Font(bold=True, name="Arial", size=11, color="C00000")
        r += 1
        for note in report.not_assessed:
            ws.cell(row=r, column=1, value=f"• {note}").font = Font(italic=True, name="Arial", size=9, color="595959")
            ws.cell(row=r, column=1).alignment = Alignment(wrap_text=True)
            ws.row_dimensions[r].height = 40
            r += 1

    ws.column_dimensions["A"].width = 110


def to_excel_module5(company: CompanyFinancials, report: RiskAuditorReport, output_path: str) -> str:
    wb = Workbook()
    wb.remove(wb.active)

    ws = wb.create_sheet("Cover")
    ws.sheet_view.showGridLines = False
    _style_title(ws, 2, 2, "FS Analyser Pro — Module 5: Risk & Auditor Analysis")
    ws.cell(row=4, column=1, value="Company:").font = Font(bold=True, name="Arial")
    ws.cell(row=4, column=2, value=company.company_name or company.report_title or "—").font = Font(name="Arial")
    ws.cell(row=5, column=1, value="Source File:").font = Font(bold=True, name="Arial")
    ws.cell(row=5, column=2, value=company.source_file or "—").font = Font(name="Arial")
    ws.cell(row=7, column=1, value="Contents:").font = Font(bold=True, name="Arial")
    ws.cell(row=8, column=1, value="  1. Risk Register — categorised risks with mitigation actions").font = Font(name="Arial")
    ws.cell(row=9, column=1, value="  2. Auditor Findings — opinion, KAM, EOM, ICFR per basis").font = Font(name="Arial")
    ws.cell(row=10, column=1, value="  3. Business Implications — data-driven summary + scope limitations").font = Font(name="Arial")
    ws.column_dimensions["A"].width = 22
    ws.column_dimensions["B"].width = 60

    _write_risk_sheet(wb, report)
    _write_auditor_sheet(wb, report)
    _write_implications_sheet(wb, report)

    wb.save(output_path)
    return output_path

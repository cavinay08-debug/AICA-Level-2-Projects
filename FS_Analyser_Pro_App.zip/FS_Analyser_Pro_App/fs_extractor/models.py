"""
FS Analyser Pro — Module 1: PDF Extraction Engine
Data models

All monetary figures are stored exactly as printed in the source financial
statement (i.e. in the reporting currency/unit disclosed on the statement,
typically Rs. Crores for large Indian listed companies). No unit conversion
is performed by this module.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any


@dataclass
class LineItem:
    """A single extracted row from a financial statement."""
    label: str                     # Cleaned label text as printed in the statement
    note: Optional[str] = None     # Note/Schedule reference, if any (e.g. "3", "9D", "18A")
    value_current: Optional[float] = None   # Value under the current/first reported year column
    value_previous: Optional[float] = None  # Value under the comparative/second column
    section: Optional[str] = None  # Section context (e.g. "Non-current assets", "EXPENSES")
    is_subtotal: bool = False      # Heuristic flag: label contains "Total"
    page_no: Optional[int] = None  # Source PDF page (1-indexed) for audit trail

    def to_dict(self) -> Dict[str, Any]:
        return {
            "label": self.label,
            "note": self.note,
            "value_current": self.value_current,
            "value_previous": self.value_previous,
            "section": self.section,
            "is_subtotal": self.is_subtotal,
            "page_no": self.page_no,
        }


@dataclass
class StatementBlock:
    """One full statement (e.g. Standalone Balance Sheet) as extracted."""
    statement_type: str            # "Balance Sheet" | "Statement of Profit and Loss" | "Statement of Cash Flows"
    basis: str                     # "Standalone" | "Consolidated"
    period_label_current: Optional[str] = None   # e.g. "31st March, 2026" or "Year ended 31st March, 2026"
    period_label_previous: Optional[str] = None
    unit: Optional[str] = None     # e.g. "Rs. Crores" (as disclosed on the statement)
    page_range: Optional[List[int]] = None
    line_items: List[LineItem] = field(default_factory=list)

    def get(self, label_substring: str) -> Optional[LineItem]:
        """Fetch first line item whose label contains the given substring (case-insensitive)."""
        target = label_substring.lower()
        for li in self.line_items:
            if target in li.label.lower():
                return li
        return None

    def get_all(self, label_substring: str) -> List[LineItem]:
        """Fetch all line items whose label contains the given substring (case-insensitive)."""
        target = label_substring.lower()
        return [li for li in self.line_items if target in li.label.lower()]

    def get_starting_with(self, phrase: str) -> Optional[LineItem]:
        """Fetch first line item whose label STARTS WITH phrase (after
        stripping leading whitespace/numbering), case-insensitive. Stricter
        than get()/get_multi() — needed for phrases like 'Exceptional
        items' that are also a substring of an unrelated subtotal row
        ('PROFIT BEFORE EXCEPTIONAL ITEMS AND TAX...'), where a plain
        'contains' search matches the wrong row first."""
        target = phrase.lower()
        for li in self.line_items:
            lbl = li.label.strip().lower()
            if lbl.startswith(target):
                return li
        return None

    def get_starting_with_marker(self, phrase: str, must_also_contain: Optional[List[str]] = None) -> Optional[LineItem]:
        """Like get_starting_with(), but also accepts a single leading
        list-marker letter/roman-numeral before the phrase (e.g. 'D Share
        of...', 'F Exceptional items...') — companies often prefix
        line-item labels this way. If must_also_contain is given, ALL of
        those substrings must also appear anywhere in the label (used to
        confirm we've found the right row among several that start
        similarly)."""
        import re as _re
        target = phrase.lower()
        for li in self.line_items:
            stripped = _re.sub(r"^[A-Za-z]{1,3}\s+", "", li.label.strip()).lower()
            if not stripped.startswith(target):
                continue
            if must_also_contain and not all(s.lower() in li.label.lower() for s in must_also_contain):
                continue
            return li
        return None

    def get_not_preceded_by(self, phrase: str, exclude_precursor: str) -> Optional[LineItem]:
        """Fetch first line item containing phrase, EXCLUDING matches where
        the text immediately before phrase (within the same label) ends
        with exclude_precursor. Handles a subtotal that happens to embed
        the same phrase ('PROFIT BEFORE EXCEPTIONAL ITEMS...' contains
        'exceptional items', same as the real 'Exceptional items [net
        credit]' row) without requiring phrase to sit at position 0 —
        some companies prefix the real row with a list marker ('D ',
        'i ') that a strict startswith() check would also reject."""
        target = phrase.lower()
        exc = exclude_precursor.lower()
        for li in self.line_items:
            lbl = li.label.lower()
            idx = lbl.find(target)
            if idx == -1:
                continue
            if lbl[:idx].strip().endswith(exc):
                continue
            return li
        return None

    def get_by_note(self, note: str) -> List[LineItem]:
        return [li for li in self.line_items if (li.note or "").lower() == note.lower()]

    def get_where(self, section_substr: Optional[str] = None,
                  label_substr: Optional[str] = None) -> Optional[LineItem]:
        """Fetch first line item matching BOTH a section-context substring and
        a label substring (case-insensitive). Use when a label alone is
        ambiguous (e.g. multiple 'Basic (in Rs.)' EPS rows under different
        sections)."""
        for li in self.line_items:
            sec_ok = section_substr is None or (
                li.section and section_substr.lower() in li.section.lower())
            lbl_ok = label_substr is None or (
                label_substr.lower() in li.label.lower())
            if sec_ok and lbl_ok:
                return li
        return None

    def get_multi(self, substrings: List[str]) -> Optional[LineItem]:
        """Fetch first line item whose label contains ALL given substrings
        (case-insensitive), regardless of their order in the text. Useful
        when different companies phrase the same subtotal differently
        (e.g. 'Net cash flows generated from operating activities - [A]'
        vs 'Net cash flows generated from / (used in) operating activities') —
        matching on the invariant fragments ('net cash', 'operating
        activities') rather than the exact full phrase."""
        for li in self.line_items:
            lbl = li.label.lower()
            if all(s.lower() in lbl for s in substrings):
                return li
        return None

    def get_total(self, phrase_substring: str, exclude: Optional[str] = None) -> Optional[LineItem]:
        """Fetch first line item whose label STARTS WITH 'total' (after
        stripping) and contains phrase_substring — used for Balance Sheet
        subtotal rows where the exact wording varies by company (e.g.
        'Total - Non-current assets (A)' vs 'Total Non-Current Assets')
        but a plain substring search would wrongly match an individual
        line item like 'Other non-current assets' that happens to contain
        the same words. The optional `exclude` guards against a related
        subtotal ('Total Non-Current Assets') being mistaken for the one
        actually being searched for ('Total Current Assets', which is a
        substring of the non-current version)."""
        target = phrase_substring.lower()
        for li in self.line_items:
            lbl = li.label.strip().lower()
            if not lbl.startswith("total"):
                continue
            if target not in lbl:
                continue
            if exclude is not None and exclude.lower() in lbl:
                continue
            return li
        return None

    def to_records(self) -> List[Dict[str, Any]]:
        return [li.to_dict() for li in self.line_items]


@dataclass
class MappedFinancials:
    """Standardised taxonomy view derived from a StatementBlock, with formulas disclosed."""
    basis: str
    fields: Dict[str, Optional[float]] = field(default_factory=dict)
    formulas: Dict[str, str] = field(default_factory=dict)   # discloses how each derived field was computed
    source_labels: Dict[str, str] = field(default_factory=dict)  # maps standard field -> as-printed label(s) used


@dataclass
class CompanyFinancials:
    """Top-level container for one Annual Report PDF."""
    company_name: Optional[str] = None
    source_file: Optional[str] = None
    report_title: Optional[str] = None
    statements: Dict[str, StatementBlock] = field(default_factory=dict)   # key e.g. "standalone_balance_sheet"
    mapped: Dict[str, MappedFinancials] = field(default_factory=dict)     # key e.g. "standalone"
    extraction_warnings: List[str] = field(default_factory=list)
    validation_results: List[Dict[str, Any]] = field(default_factory=list)

"""
FS Analyser Pro — Module 3: Trend Analysis Engine
Long-term Track Record extractor

Rather than approximating a multi-year trend from just this filing's
2-year comparatives, this module extracts the company's OWN disclosed
multi-year summary table (commonly titled "Long-term Track Record" /
"Financial Highlights" / "10-Year Highlights" in Indian annual reports).
HUL's FY26 Integrated Annual Report discloses 11 years (FY2015-16 to
FY2025-26) across Turnover, PAT, EPS, DPS, Balance Sheet, Standalone
Ratios, and Market data — audited/board-approved figures, not derived
estimates.

Extensibility (per requirement): extract_long_term_track_record() accepts
a LIST of PDF paths. Each PDF contributes whatever years its own table
covers; results are merged year-wise. Where the same year is disclosed
in more than one PDF (e.g. FY24 appearing in both the FY25 and FY26
reports), the value from the MOST RECENTLY DATED PDF is kept, since a
later report may carry a restated figure (Ind-AS restatements, scheme
of demerger reclassification, etc.) — this is recorded, not silently
overwritten.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any

import pdfplumber

TITLE_RE = re.compile(
    r"Long-term Track Record"
    r"|\d+\s*[-–]?\s*Years?\s+Financial\s+Highlights"
    r"|Years?\s+at\s+a\s+Glance",
    re.IGNORECASE,
)
# Fiscal-year format ("2025-26") tried first so it isn't short-matched as
# just "2025" — some companies' older columns predate a fiscal-year
# convention change and use plain calendar years instead (observed:
# Nestlé India shows FY-format for its 3 most recent years, then plain
# 4-digit calendar years for 2022 and earlier, following an actual
# year-end change disclosed in the report's own footnotes).
YEAR_RE = re.compile(r"20\d{2}-\d{2}|20\d{2}")
NUM_TOKEN_RE = re.compile(r"^\(?-?[\d,]+\.?\d*\)?\*{0,2}#{0,2}\^{0,2}$")
UNIT_RE = re.compile(r"\(All amounts in ([^)]+)\)", re.IGNORECASE)

# (output_key, label substring to match on the line, human label, unit, is_money)
# is_money=True metrics have their unit OVERRIDDEN at extraction time by
# whatever the table itself discloses (e.g. "Rs. Crores" for HUL, "₹
# million" for Nestlé) rather than trusting a hardcoded default here.
# (output_key, candidate label substrings to try in order, human label, unit, is_money)
# is_money=True metrics have their unit OVERRIDDEN at extraction time by
# whatever the table itself discloses (e.g. "Rs. Crores" for HUL, "₹
# million" for Nestlé) rather than trusting a hardcoded default here.
METRIC_DEFS: List[Tuple[str, Any, str, str, bool]] = [
    ("turnover", ("Turnover", "Sales"), "Turnover / Sales", "Rs. Crores", True),
    ("pat", "Profit After Tax", "Profit After Tax (PAT)", "Rs. Crores", True),
    ("ebitda", "EBITDA", "EBITDA", "Rs. Crores", True),
    ("eps", "Earnings Per Share", "Earnings per Share (EPS)", "Rs.", False),
    ("dps", "Dividend Per Share", "Dividend per Share (DPS)", "Rs.", False),
    ("ppe", "Property, Plant and Equipment", "Property, Plant and Equipment", "Rs. Crores", True),
    ("intangible_assets", "Intangible Assets", "Intangible Assets", "Rs. Crores", True),
    ("other_assets", "Other Assets", "Other Assets", "Rs. Crores", True),
    ("total_assets", "Total Assets", "Total Assets", "Rs. Crores", True),
    ("share_capital", "Share Capital", "Share Capital", "Rs. Crores", True),
    ("other_equity", "Other Equity", "Other Equity (incl. NCI)", "Rs. Crores", True),
    ("other_liabilities", "Other Liabilities", "Other Liabilities", "Rs. Crores", True),
    ("shareholders_fund", "Shareholders Fund", "Shareholders' Fund / Net Worth", "Rs. Crores", True),
    ("total_equity_and_liabilities", "Total Equity and Liabilities", "Total Equity and Liabilities", "Rs. Crores", True),
    ("operating_cash_flow", "Operating Cash Flow", "Operating Cash Flow", "Rs. Crores", True),
    ("capex", "Capital Expenditure", "Capital Expenditure (Outflows)", "Rs. Crores", True),
    ("fixed_asset_turnover", "Fixed Asset Turnover", "Fixed Asset Turnover", "x", False),
    ("pat_turnover_pct", "PAT/Turnover", "PAT / Turnover", "%", False),
    ("roce_pct", "Return On Capital Employed", "Return on Capital Employed (ROCE)", "%", False),
    ("ronw_pct", "Return On Net Worth", "Return on Net Worth (RONW)", "%", False),
    ("return_on_avg_equity_pct", "Return on Average", "Return on Average Equity (RoAE)", "%", False),
    ("eva", "Economic Value Added", "Economic Value Added (EVA)", "Rs. Crores", True),
    ("share_price_bse", "HUL Share Price on BSE", "Share Price on BSE", "Rs.", False),
    ("market_cap", "Market Capitalisation", "Market Capitalisation", "Rs. Crores", True),
    ("employees", "Number of Employees", "Number of Employees", "count", False),
]


@dataclass
class LongTermTrendData:
    years: List[str] = field(default_factory=list)          # sorted chronologically, e.g. ["2015-16", ..., "2025-26"]
    metrics: Dict[str, Dict[str, float]] = field(default_factory=dict)  # metric_key -> {year: value}
    metric_labels: Dict[str, str] = field(default_factory=dict)
    metric_units: Dict[str, str] = field(default_factory=dict)
    source_by_year: Dict[str, str] = field(default_factory=dict)        # year -> source PDF path
    warnings: List[str] = field(default_factory=list)


def _clean_num(tok: str) -> Optional[float]:
    t = tok.strip().rstrip("*#^")
    if t in ("-", "–", "—", ""):
        return None
    neg = t.startswith("(") and t.endswith(")")
    t = t.strip("()").replace(",", "")
    try:
        v = float(t)
    except ValueError:
        return None
    return -v if neg else v


def _extract_table_from_pages(pages_text: str) -> Tuple[List[str], Dict[str, Dict[str, float]]]:
    lines = pages_text.split("\n")
    year_seq: List[str] = []
    for line in lines:
        years_here = YEAR_RE.findall(line)
        if len(years_here) > len(year_seq):
            year_seq = years_here  # take the longest/most complete year header found

    def line_nums(line: str, strip_substr: Optional[str] = None) -> List[float]:
        text = line.replace(strip_substr, " ") if strip_substr else line
        nums = []
        for tok in text.split():
            if NUM_TOKEN_RE.match(tok):
                v = _clean_num(tok)
                if v is not None:
                    nums.append(v)
        return nums

    results: Dict[str, Dict[str, float]] = {}
    for key, substr_or_list, _, _, _ in METRIC_DEFS:
        candidates = substr_or_list if isinstance(substr_or_list, (list, tuple)) else (substr_or_list,)
        for substr in candidates:
            target = substr.lower()
            found_for_this_metric = False
            for i, line in enumerate(lines):
                stripped = line.strip().lower()
                if not stripped.startswith(target):
                    continue
                nums = line_nums(line, substr)
                # Chart-style layout: label and its 11 values sit on separate,
                # adjacent lines (e.g. "Turnover (Rs. in crores)" then the
                # number row on the very next line). Look ahead up to 2 lines.
                lookahead = 0
                while len(nums) < 2 and lookahead < 2 and (i + 1 + lookahead) < len(lines):
                    nums = line_nums(lines[i + 1 + lookahead])
                    lookahead += 1
                if len(nums) >= 2:
                    # Guard against accidentally matching a DIFFERENT,
                    # smaller table that happens to share a page with the
                    # real one (observed: a 2-year "Key Financial Ratios"
                    # box using the same row label as a metric in the real
                    # 10-year table). If far fewer values were found than
                    # the established year count, this almost certainly
                    # belongs to that other table, not this one — reject
                    # rather than force-align it to the wrong years.
                    if year_seq and len(nums) < len(year_seq) - 1:
                        continue
                    n = min(len(nums), len(year_seq)) if year_seq else len(nums)
                    yrs = year_seq[-n:] if year_seq else [str(x) for x in range(n)]
                    vals = nums[-n:]
                    results[key] = dict(zip(yrs, vals))
                    found_for_this_metric = True
                    break  # first matching line (by document order) wins for this metric
            if found_for_this_metric:
                break  # don't try the next candidate substring once one has matched
    return year_seq, results


def _extract_unit(pages_text: str) -> Optional[str]:
    m = UNIT_RE.search(pages_text)
    if not m:
        return None
    unit_text = m.group(1).strip()
    unit_text = re.sub(r",?\s*unless otherwise stated\.?$", "", unit_text, flags=re.IGNORECASE).strip()
    return unit_text


def _has_real_title(text: str) -> bool:
    """True if TITLE_RE matches a genuine heading line, not a Table-of-
    Contents entry (e.g. '14   10 - Year Financial Highlights ...') where
    the title text is preceded by a page-number reference on the same
    line."""
    for line in text.split("\n"):
        m = TITLE_RE.search(line)
        if not m:
            continue
        prefix = line[:m.start()].strip()
        if prefix == "" or not re.fullmatch(r"\d+", prefix):
            return True
    return False


def extract_long_term_track_record(pdf_paths: List[str], front_matter_scan_limit: int = 150) -> LongTermTrendData:
    """
    Extract and merge the disclosed multi-year "Long-term Track Record"
    table across one or more Annual Report PDFs. Later PDFs (by list
    order — pass them oldest-first) take precedence for overlapping years.

    Performance note: a multi-year highlights table is almost always in
    an Annual Report's front matter (well before the audited financial
    statements). Scanning every single page of a 400-600 page filing
    just to find this title is unnecessarily slow, so the search checks
    only the first `front_matter_scan_limit` pages first, and only falls
    back to scanning the FULL document if nothing is found in that
    window — keeping the common case fast without giving up thoroughness
    on an unusual filing that places this table later.
    """
    data = LongTermTrendData()
    money_keys = set()
    for key, _, label, unit, is_money in METRIC_DEFS:
        data.metric_labels[key] = label
        data.metric_units[key] = unit
        data.metrics[key] = {}
        if is_money:
            money_keys.add(key)
    detected_unit: Optional[str] = None

    for pdf_path in pdf_paths:
        found_pages = []
        with pdfplumber.open(pdf_path) as pdf:
            total_pages = len(pdf.pages)
            scan_limit = min(front_matter_scan_limit, total_pages)
            for i in range(1, scan_limit + 1):
                text = pdf.pages[i - 1].extract_text() or ""
                if _has_real_title(text):
                    found_pages.append(i)

            if not found_pages and scan_limit < total_pages:
                # Fall back to scanning the rest of the document.
                for i in range(scan_limit + 1, total_pages + 1):
                    text = pdf.pages[i - 1].extract_text() or ""
                    if _has_real_title(text):
                        found_pages.append(i)
                        break

            if not found_pages:
                data.warnings.append(
                    f"No 'Long-term Track Record' (or similarly titled multi-year "
                    f"highlights) section found in: {pdf_path}. Skipped.")
                continue

            # Pull text from the located page(s) and a couple of pages after,
            # since the table commonly spans 2 pages.
            span = range(found_pages[0], min(found_pages[0] + 2, len(pdf.pages)) + 1)
            combined_text = "\n".join(
                (pdf.pages[p - 1].extract_text() or "") for p in span if p <= len(pdf.pages)
            )

        years, parsed = _extract_table_from_pages(combined_text)
        if not years:
            data.warnings.append(f"Found the Track Record title but could not parse a "
                                  f"year header from: {pdf_path}. Skipped.")
            continue

        unit_here = _extract_unit(combined_text)
        if unit_here:
            if detected_unit is None:
                detected_unit = unit_here
                for key in money_keys:
                    data.metric_units[key] = detected_unit
            elif unit_here != detected_unit:
                data.warnings.append(
                    f"Unit mismatch: '{pdf_path}' discloses amounts in '{unit_here}', "
                    f"but an earlier PDF in this run used '{detected_unit}'. Money-metric "
                    f"figures from different PDFs may NOT be directly comparable — "
                    f"verify before combining across filings.")

        for y in years:
            if y not in data.years:
                data.years.append(y)
            data.source_by_year[y] = pdf_path  # later PDFs in the list override

        for key, year_vals in parsed.items():
            data.metrics.setdefault(key, {})
            for y, v in year_vals.items():
                data.metrics[key][y] = v  # later PDF overrides earlier for same year

    data.years = sorted(set(data.years), key=lambda y: y)  # "2015-16" < "2016-17" lexically works here
    return data

"""
FS Analyser Pro — Module 1: PDF Extraction Engine
Validators

Per the requirement to reconfirm accuracy before presenting any figure,
this module runs independent arithmetic tie-outs on the extracted data
and flags any mismatch beyond a small rounding tolerance (+/- 1, to
absorb printed rounding to the nearest crore/lakh).
"""
from __future__ import annotations

from typing import List, Dict, Any

from .models import CompanyFinancials

TOL = 1.0


def _check(results: List[Dict[str, Any]], name: str, basis: str, lhs, rhs, tolerance=TOL):
    if lhs is None or rhs is None:
        results.append({
            "check": name, "basis": basis, "status": "SKIPPED",
            "detail": "One or both figures not found in extracted data.",
        })
        return
    diff = round(lhs - rhs, 2)
    ok = abs(diff) <= tolerance
    results.append({
        "check": name, "basis": basis,
        "status": "PASS" if ok else "FAIL",
        "lhs": lhs, "rhs": rhs, "difference": diff,
    })


def run_all_checks(company: CompanyFinancials) -> List[Dict[str, Any]]:
    results: List[Dict[str, Any]] = []

    for basis in ("standalone", "consolidated"):
        bs = company.statements.get(f"{basis}_balance_sheet")
        pl = company.statements.get(f"{basis}_profit_and_loss")
        cf = company.statements.get(f"{basis}_cash_flow")

        if bs is not None:
            for suffix, label in (("current", "FY (current)"), ("previous", "FY (previous)")):
                total_assets = bs.get("TOTAL ASSETS")
                total_eq_liab = bs.get("TOTAL EQUITY AND LIABILITIES")
                ta = getattr(total_assets, f"value_{suffix}", None) if total_assets else None
                tel = getattr(total_eq_liab, f"value_{suffix}", None) if total_eq_liab else None
                _check(results, f"Balance Sheet ties out (Assets = Equity & Liabilities) — {label}",
                       basis, ta, tel)

                nca = bs.get_total("non-current assets")
                ca = bs.get_total("current assets", exclude="non-current")
                nca_v = getattr(nca, f"value_{suffix}", None) if nca else None
                ca_v = getattr(ca, f"value_{suffix}", None) if ca else None
                if nca_v is not None and ca_v is not None:
                    _check(results, f"Non-current + Current Assets = Total Assets — {label}",
                           basis, round(nca_v + ca_v, 2), ta)

                eq = bs.get_total("equity", exclude="liabilities")
                ncl = bs.get_total("non-current liabilities")
                cl = bs.get_total("current liabilities", exclude="non-current")
                eq_v = getattr(eq, f"value_{suffix}", None) if eq else None
                ncl_v = getattr(ncl, f"value_{suffix}", None) if ncl else None
                cl_v = getattr(cl, f"value_{suffix}", None) if cl else None
                if None not in (eq_v, ncl_v, cl_v):
                    _check(results, f"Equity + Non-current Liab. + Current Liab. = Total Equity & Liab. — {label}",
                           basis, round(eq_v + ncl_v + cl_v, 2), tel)

        if pl is not None:
            for suffix, label in (("current", "FY (current)"), ("previous", "FY (previous)")):
                ti = pl.get("TOTAL INCOME")
                te = pl.get("TOTAL EXPENSES")
                exceptional = pl.get_starting_with_marker("exceptional items")
                # Must START with (allowing a single leading list-marker
                # letter, e.g. "D Share of...", "F Exceptional items...")
                # to avoid matching a subtotal row that merely MENTIONS
                # "share of ... associate" / "exceptional items" within its
                # own longer descriptive title (e.g. Nestlé Consolidated's
                # "C PROFIT BEFORE SHARE OF (PROFIT) / LOSS OF AN
                # ASSOCIATE, EXCEPTIONAL ITEMS AND TAX (A-B)", which
                # mentions both phrases but is itself a subtotal, not
                # either component).
                share_of_associate = (
                    pl.get_starting_with_marker("share of", must_also_contain=["associate"])
                    or pl.get_starting_with_marker("share of", must_also_contain=["joint venture"])
                    or pl.get_starting_with_marker("share of", must_also_contain=["investee"])
                )
                pbt = pl.get("Profit before tax from continuing operations") or pl.get("profit before tax")
                ti_v = getattr(ti, f"value_{suffix}", None) if ti else None
                te_v = getattr(te, f"value_{suffix}", None) if te else None
                exc_v = getattr(exceptional, f"value_{suffix}", None) if exceptional else None
                soa_v = getattr(share_of_associate, f"value_{suffix}", None) if share_of_associate else 0.0
                pbt_v = getattr(pbt, f"value_{suffix}", None) if pbt else None
                if None not in (ti_v, te_v, exc_v):
                    soa = soa_v or 0.0
                    # Companies differ in sign convention for BOTH the
                    # "Exceptional items" row (added vs subtracted — see
                    # HUL vs Nestlé Standalone) and, where present, the
                    # "Share of associate profit/loss" row (Nestlé
                    # Consolidated). Rather than hardcode one convention,
                    # try the plausible combinations and accept whichever
                    # ties out — still a genuine independent arithmetic
                    # check, just not committed to an a-priori sign.
                    candidates = {
                        "exceptional items ADDED, share of assoc. ADDED": ti_v - te_v + soa + exc_v,
                        "exceptional items SUBTRACTED, share of assoc. ADDED": ti_v - te_v + soa - exc_v,
                        "exceptional items ADDED, share of assoc. SUBTRACTED": ti_v - te_v - soa + exc_v,
                        "exceptional items SUBTRACTED, share of assoc. SUBTRACTED": ti_v - te_v - soa - exc_v,
                    }
                    match_label, match_val = None, None
                    for lbl, val in candidates.items():
                        if pbt_v is not None and abs(round(val, 2) - pbt_v) <= TOL:
                            match_label, match_val = lbl, round(val, 2)
                            break
                    if match_label:
                        _check(results, f"Total Income − Total Expenses ± Share of Assoc./JV ± Exceptional Items = PBT (Continuing) [{match_label}] — {label}",
                               basis, match_val, pbt_v)
                    else:
                        _check(results, f"Total Income − Total Expenses ± Share of Assoc./JV ± Exceptional Items = PBT (Continuing) — {label}",
                               basis, round(candidates["exceptional items ADDED, share of assoc. ADDED"], 2), pbt_v)

                pat_c = pl.get("PROFIT FOR THE YEAR FROM CONTINUING OPERATIONS")
                pat_d = pl.get("FOR THE YEAR FROM DISCONTINUED OPERATIONS")
                pat_t = pl.get("PROFIT FOR THE YEAR (C=A+B)")
                pat_c_v = getattr(pat_c, f"value_{suffix}", None) if pat_c else None
                pat_d_v = getattr(pat_d, f"value_{suffix}", None) if pat_d else None
                pat_t_v = getattr(pat_t, f"value_{suffix}", None) if pat_t else None
                if None not in (pat_c_v, pat_d_v):
                    _check(results, f"PAT Continuing (A) + PAT Discontinued (B) = PAT for the Year (C) — {label}",
                           basis, round(pat_c_v + pat_d_v, 2), pat_t_v)

        if bs is not None and cf is not None:
            cash_bs = bs.get("Cash and cash equivalents")
            cash_cf_close = cf.get("Cash and cash equivalents at the end of the year")
            cash_bs_v = getattr(cash_bs, "value_current", None) if cash_bs else None
            cash_cf_v = getattr(cash_cf_close, "value_current", None) if cash_cf_close else None
            _check(results, "Closing Cash per Cash Flow Statement ties to Balance Sheet — FY (current)",
                   basis, cash_bs_v, cash_cf_v)

            cash_bs_prev = getattr(cash_bs, "value_previous", None) if cash_bs else None
            cash_cf_prev = getattr(cash_cf_close, "value_previous", None) if cash_cf_close else None
            _check(results, "Closing Cash per Cash Flow Statement ties to Balance Sheet — FY (previous)",
                   basis, cash_bs_prev, cash_cf_prev)

        if cf is not None:
            ocf = cf.get_multi(["net cash", "operating activities"])
            icf = cf.get_multi(["net cash", "investing activities"])
            fcf = cf.get_multi(["net cash", "financing activities"])
            net_chg = cf.get("increase in cash") or cf.get("decrease in cash")
            ocf_v = getattr(ocf, "value_current", None) if ocf else None
            icf_v = getattr(icf, "value_current", None) if icf else None
            fcf_v = getattr(fcf, "value_current", None) if fcf else None
            net_v = getattr(net_chg, "value_current", None) if net_chg else None
            if None not in (ocf_v, icf_v, fcf_v):
                _check(results, "Operating + Investing + Financing CF = Net Change in Cash — FY (current)",
                       basis, round(ocf_v + icf_v + fcf_v, 2), net_v)

    return results

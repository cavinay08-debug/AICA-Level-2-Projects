"""
FS Analyser Pro — Module 2: Financial Analysis / Ratio Engine

Computes growth, margin, return, liquidity, leverage, efficiency and
per-share ratios from the MappedFinancials produced by Module 1.

Design choices (stated explicitly, not buried in code):

1. Only 2 years of data exist per Annual Report PDF (current + one
   comparative). Growth ratios (YoY %) are therefore only computable for
   the CURRENT year (FY26 vs FY25) — computing FY25's own growth would
   need FY24 figures, which would come from a THIRD-year PDF not yet
   supplied. This is flagged, not silently worked around.

2. Average-balance ratios (ROE, ROCE, ROA, turnover ratios) are computed
   TWO ways and BOTH are shown:
     - "Closing balance" basis — uses the year-end balance only.
       Computable for both FY26 and FY25.
     - "Average balance" basis — uses (opening + closing) / 2, the more
       rigorous convention. Computable ONLY for FY26, since the FY26
       opening balance equals FY25's closing balance (which we have);
       FY25's own opening balance would require FY24 data.
   No qualitative Excellent/Good/Average/Weak labels are applied — this
   module returns figures and formulas only, by design choice.

3. "Debt" for leverage ratios uses Lease Liabilities (Non-current +
   Current), because HUL's Standalone/Consolidated Balance Sheet carries
   no separate interest-bearing Borrowings line. This mirrors the
   assumption already disclosed in Module 1 (taxonomy.py).

4. Book Value per Share requires the share count. The extracted Balance
   Sheet gives only the aggregate face value of Equity Share Capital
   (Rs. crores), not the per-share face value or share count. Shares
   outstanding are therefore BACK-SOLVED as PAT / Basic EPS (Continuing
   and Discontinued) — a standard analyst approximation — and flagged as
   such rather than presented as a directly extracted figure.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Dict

from .models import MappedFinancials


@dataclass
class RatioAnalysis:
    basis: str
    ratios: Dict[str, Optional[float]] = field(default_factory=dict)
    formulas: Dict[str, str] = field(default_factory=dict)
    notes: Dict[str, str] = field(default_factory=dict)


def _pct(numerator, denominator):
    if numerator is None or denominator in (None, 0):
        return None
    return round((numerator / denominator) * 100, 2)


def _ratio(numerator, denominator, dp=2):
    if numerator is None or denominator in (None, 0):
        return None
    return round(numerator / denominator, dp)


def _avg(a, b):
    if a is None or b is None:
        return None
    return (a + b) / 2.0


def build_ratio_analysis(m: MappedFinancials) -> RatioAnalysis:
    """m is the MappedFinancials for ONE basis (standalone or consolidated)."""
    ra = RatioAnalysis(basis=m.basis)
    R, FORM, NOTE = ra.ratios, ra.formulas, ra.notes
    f = m.fields  # shorthand

    # ---------------- GROWTH (FY26 only — see module docstring) -------------
    R["revenue_growth_pct"] = _pct(
        (f.get("revenue") or 0) - (f.get("revenue_prev") or 0), f.get("revenue_prev"))
    FORM["revenue_growth_pct"] = "((Revenue_FY26 − Revenue_FY25) / Revenue_FY25) × 100"

    R["ebitda_growth_pct"] = _pct(
        (f.get("ebitda_operating") or 0) - (f.get("ebitda_operating_prev") or 0), f.get("ebitda_operating_prev"))
    FORM["ebitda_growth_pct"] = "((EBITDA(Operating)_FY26 − EBITDA(Operating)_FY25) / EBITDA(Operating)_FY25) × 100"

    R["pat_growth_pct"] = _pct(
        (f.get("pat_total") or 0) - (f.get("pat_total_prev") or 0), f.get("pat_total_prev"))
    FORM["pat_growth_pct"] = "((PAT_FY26 − PAT_FY25) / PAT_FY25) × 100"
    NOTE["growth_ratios"] = ("Computable only for FY26 vs FY25. FY25's own growth (vs FY24) "
                              "requires a third annual report PDF (FY24) not yet supplied.")

    # ---------------- MARGINS (both years) -----------------------------------
    for yr, suf in (("fy26", ""), ("fy25", "_prev")):
        rev = f.get(f"revenue{suf}")
        R[f"gross_margin_pct_{yr}"] = _pct(
            (rev - (f.get(f"cogs{suf}") or 0)) if rev is not None else None, rev)
        R[f"ebitda_margin_pct_{yr}"] = _pct(f.get(f"ebitda_operating{suf}"), rev)
        R[f"operating_margin_pct_{yr}"] = _pct(f.get(f"ebit_operating{suf}"), rev)
        R[f"net_profit_margin_pct_{yr}"] = _pct(f.get(f"pat_total{suf}"), rev)
    FORM["gross_margin_pct"] = "((Revenue − COGS) / Revenue) × 100"
    FORM["ebitda_margin_pct"] = "(EBITDA(Operating) / Revenue) × 100"
    FORM["operating_margin_pct"] = "(EBIT(Operating) / Revenue) × 100"
    FORM["net_profit_margin_pct"] = "(PAT for the Year / Revenue) × 100"

    # ---------------- RETURNS: Closing-balance basis (both years) -----------
    for yr, suf in (("fy26", ""), ("fy25", "_prev")):
        pat = f.get(f"pat_total{suf}")
        equity_close = f.get(f"total_equity{suf}")
        assets_close = f.get(f"total_assets{suf}")
        ncl_close = f.get(f"non_current_liabilities{suf}")
        cap_employed_close = (equity_close + ncl_close) if None not in (equity_close, ncl_close) else None
        ebit = f.get(f"ebit_operating{suf}")

        R[f"roe_closing_pct_{yr}"] = _pct(pat, equity_close)
        R[f"roa_closing_pct_{yr}"] = _pct(pat, assets_close)
        R[f"roce_closing_pct_{yr}"] = _pct(ebit, cap_employed_close)

    FORM["roe_closing_pct"] = "(PAT for the Year / Closing Total Equity) × 100"
    FORM["roa_closing_pct"] = "(PAT for the Year / Closing Total Assets) × 100"
    FORM["roce_closing_pct"] = ("(EBIT(Operating) / Closing Capital Employed) × 100, where "
                                 "Capital Employed = Total Equity + Non-current Liabilities")

    # ---------------- RETURNS: Average-balance basis (FY26 only) ------------
    pat_26 = f.get("pat_total")
    equity_avg = _avg(f.get("total_equity"), f.get("total_equity_prev"))
    assets_avg = _avg(f.get("total_assets"), f.get("total_assets_prev"))
    ncl_avg = _avg(f.get("non_current_liabilities"), f.get("non_current_liabilities_prev"))
    cap_employed_avg = (equity_avg + ncl_avg) if None not in (equity_avg, ncl_avg) else None
    ebit_26 = f.get("ebit_operating")

    R["roe_average_pct_fy26"] = _pct(pat_26, equity_avg)
    R["roa_average_pct_fy26"] = _pct(pat_26, assets_avg)
    R["roce_average_pct_fy26"] = _pct(ebit_26, cap_employed_avg)
    FORM["roe_average_pct"] = "(PAT for the Year / Average Total Equity [(Opening+Closing)/2]) × 100 — FY26 only"
    FORM["roa_average_pct"] = "(PAT for the Year / Average Total Assets [(Opening+Closing)/2]) × 100 — FY26 only"
    FORM["roce_average_pct"] = ("(EBIT(Operating) / Average Capital Employed [(Opening+Closing)/2]) × 100 "
                                 "— FY26 only")
    NOTE["average_balance_ratios"] = ("Average-balance ROE/ROA/ROCE computable only for FY26, "
                                        "since FY25's closing balance serves as FY26's opening "
                                        "balance. FY25's own average-basis ratios would require "
                                        "FY24 closing balances.")

    # ---------------- LIQUIDITY (both years, point-in-time) ------------------
    for yr, suf in (("fy26", ""), ("fy25", "_prev")):
        ca = f.get(f"current_assets{suf}")
        cl = f.get(f"current_liabilities{suf}")
        inv = f.get(f"inventories{suf}")
        R[f"current_ratio_{yr}"] = _ratio(ca, cl)
        R[f"quick_ratio_{yr}"] = _ratio((ca - (inv or 0)) if ca is not None else None, cl)
        R[f"working_capital_{yr}"] = round(ca - cl, 2) if None not in (ca, cl) else None
    FORM["current_ratio"] = "Current Assets / Current Liabilities"
    FORM["quick_ratio"] = "(Current Assets − Inventories) / Current Liabilities"
    FORM["working_capital"] = "Current Assets − Current Liabilities (Rs. Crores)"

    # ---------------- LEVERAGE (both years) -----------------------------------
    for yr, suf in (("fy26", ""), ("fy25", "_prev")):
        debt = f.get(f"lease_liabilities_total{suf}")
        equity = f.get(f"total_equity{suf}")
        ebit = f.get(f"ebit_operating{suf}")
        fin_cost = f.get(f"finance_costs{suf}")
        R[f"debt_equity_ratio_{yr}"] = _ratio(debt, equity)
        R[f"interest_coverage_ratio_{yr}"] = _ratio(ebit, fin_cost)
    FORM["debt_equity_ratio"] = ("Total Lease Liabilities (Non-current + Current) / Total Equity "
                                  "— used as Debt in the absence of a separate Borrowings line "
                                  "(see Module 1 assumption note)")
    FORM["interest_coverage_ratio"] = "EBIT(Operating) / Finance Costs"

    # ---------------- EFFICIENCY: Closing-balance basis (both years) --------
    for yr, suf in (("fy26", ""), ("fy25", "_prev")):
        rev = f.get(f"revenue{suf}")
        cogs = f.get(f"cogs{suf}")
        assets_close = f.get(f"total_assets{suf}")
        inv_close = f.get(f"inventories{suf}")
        recv_close = f.get(f"trade_receivables{suf}")
        pay_close = f.get(f"trade_payables{suf}")

        R[f"asset_turnover_closing_{yr}"] = _ratio(rev, assets_close)
        inv_turn = _ratio(cogs, inv_close)
        R[f"inventory_turnover_closing_{yr}"] = inv_turn
        R[f"inventory_days_closing_{yr}"] = round(365.0 / inv_turn, 1) if inv_turn else None
        R[f"receivable_days_closing_{yr}"] = (
            round((recv_close / rev) * 365, 1) if None not in (recv_close, rev) and rev else None)
        R[f"payable_days_closing_{yr}"] = (
            round((pay_close / cogs) * 365, 1) if None not in (pay_close, cogs) and cogs else None)
        inv_d = R.get(f"inventory_days_closing_{yr}")
        recv_d = R.get(f"receivable_days_closing_{yr}")
        pay_d = R.get(f"payable_days_closing_{yr}")
        if None not in (inv_d, recv_d, pay_d):
            R[f"cash_conversion_cycle_closing_{yr}"] = round(inv_d + recv_d - pay_d, 1)
        else:
            R[f"cash_conversion_cycle_closing_{yr}"] = None

    FORM["asset_turnover_closing"] = "Revenue from Operations / Closing Total Assets"
    FORM["inventory_turnover_closing"] = "COGS / Closing Inventories"
    FORM["inventory_days_closing"] = "365 / Inventory Turnover"
    FORM["receivable_days_closing"] = "(Closing Trade Receivables / Revenue) × 365"
    FORM["payable_days_closing"] = "(Closing Trade Payables / COGS) × 365"
    FORM["cash_conversion_cycle_closing"] = "Inventory Days + Receivable Days − Payable Days"

    # ---------------- EFFICIENCY: Average-balance basis (FY26 only) ---------
    rev_26 = f.get("revenue")
    cogs_26 = f.get("cogs")
    assets_avg2 = assets_avg
    inv_avg = _avg(f.get("inventories"), f.get("inventories_prev"))
    recv_avg = _avg(f.get("trade_receivables"), f.get("trade_receivables_prev"))
    pay_avg = _avg(f.get("trade_payables"), f.get("trade_payables_prev"))

    R["asset_turnover_average_fy26"] = _ratio(rev_26, assets_avg2)
    inv_turn_avg = _ratio(cogs_26, inv_avg)
    R["inventory_turnover_average_fy26"] = inv_turn_avg
    inv_days_avg = round(365.0 / inv_turn_avg, 1) if inv_turn_avg else None
    R["inventory_days_average_fy26"] = inv_days_avg
    recv_days_avg = round((recv_avg / rev_26) * 365, 1) if None not in (recv_avg, rev_26) and rev_26 else None
    R["receivable_days_average_fy26"] = recv_days_avg
    pay_days_avg = round((pay_avg / cogs_26) * 365, 1) if None not in (pay_avg, cogs_26) and cogs_26 else None
    R["payable_days_average_fy26"] = pay_days_avg
    if None not in (inv_days_avg, recv_days_avg, pay_days_avg):
        R["cash_conversion_cycle_average_fy26"] = round(inv_days_avg + recv_days_avg - pay_days_avg, 1)
    else:
        R["cash_conversion_cycle_average_fy26"] = None

    FORM["asset_turnover_average"] = "Revenue from Operations / Average Total Assets — FY26 only"
    FORM["inventory_turnover_average"] = "COGS / Average Inventories — FY26 only"
    NOTE["efficiency_average_ratios"] = ("Average-balance efficiency ratios computable only for "
                                          "FY26 for the same reason as average-balance return ratios.")

    # ---------------- PER-SHARE & DIVIDEND (both years) ----------------------
    for yr, suf in (("fy26", ""), ("fy25", "_prev")):
        pat = f.get(f"pat_total{suf}")
        eps = f.get(f"basic_eps_total{suf}")
        equity = f.get(f"total_equity{suf}")
        div_paid = f.get(f"dividends_paid{suf}")  # populated by extractor wiring below

        shares_approx = _ratio(pat, eps, dp=4) if None not in (pat, eps) and eps else None
        R[f"shares_outstanding_approx_crore_{yr}"] = shares_approx
        R[f"book_value_per_share_{yr}"] = (
            round(equity / shares_approx, 2) if None not in (equity, shares_approx) and shares_approx else None)
        R[f"dividend_payout_ratio_pct_{yr}"] = _pct(abs(div_paid) if div_paid is not None else None, pat)

    FORM["shares_outstanding_approx_crore"] = ("PAT for the Year / Basic EPS (Continuing & Discontinued) "
                                                 "— BACK-SOLVED approximation; not a directly extracted "
                                                 "share count. Units: crore shares (same base as PAT in "
                                                 "Rs. Crores; EPS in Rs.)")
    FORM["book_value_per_share"] = "Total Equity / Shares Outstanding (approx., see above)"
    FORM["dividend_payout_ratio_pct"] = ("(Dividends Paid per Cash Flow Statement / PAT for the Year) × 100. "
                                          "Note: cash dividend paid during the year typically relates to the "
                                          "PRIOR year's proposed final dividend under Ind-AS; this is a cash-"
                                          "basis approximation, not a strict same-year payout ratio.")

    return ra

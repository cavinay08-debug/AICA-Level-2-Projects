"""
FS Analyser Pro — Dashboard
Builds Plotly figures from data already computed by Modules 1-5.
Nothing here re-reads the PDF or re-derives figures — it only visualises
what the other modules already extracted and validated.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Any

import plotly.graph_objects as go
from plotly.subplots import make_subplots

NAVY = "#1F3864"
GOLD = "#BF9000"
GREY = "#8C8C8C"
GREEN = "#2E7D32"
RED = "#C00000"
PALETTE = [NAVY, GOLD, "#5B8AC7", "#D9A400", "#8FAADC", "#7F6000"]


def _empty_fig(message: str) -> go.Figure:
    fig = go.Figure()
    fig.add_annotation(text=message, showarrow=False, font=dict(size=14, color=GREY))
    fig.update_layout(xaxis=dict(visible=False), yaxis=dict(visible=False), height=220,
                       margin=dict(l=20, r=20, t=20, b=20))
    return fig


def build_kpi_cards(fields: Dict[str, Optional[float]]) -> List[Dict[str, Any]]:
    def delta_pct(cur, prev):
        if cur is None or prev in (None, 0):
            return None
        return round((cur - prev) / abs(prev) * 100, 1)

    kpis = []
    specs = [
        ("Revenue", "revenue", "revenue_prev", "Rs."),
        ("EBITDA (Operating)", "ebitda_operating", "ebitda_operating_prev", "Rs."),
        ("PAT", "pat_total", "pat_total_prev", "Rs."),
        ("Total Assets", "total_assets", "total_assets_prev", "Rs."),
        ("Operating Cash Flow", "operating_cash_flow", "operating_cash_flow_prev", "Rs."),
        ("Free Cash Flow", "free_cash_flow", "free_cash_flow_prev", "Rs."),
    ]
    for label, key, prev_key, unit in specs:
        cur = fields.get(key)
        prev = fields.get(prev_key)
        kpis.append({
            "label": label, "value": cur, "delta_pct": delta_pct(cur, prev), "unit": unit,
        })
    return kpis


def build_trend_line_chart(trends: Optional[Dict[str, Any]], keys_labels: List[tuple]) -> go.Figure:
    """keys_labels: [(trend_key, display_label), ...] — e.g. [('turnover','Turnover'), ('pat','PAT')]"""
    if not trends:
        return _empty_fig("No multi-year track record table was found in this filing — trend chart unavailable.")
    fig = go.Figure()
    any_data = False
    for i, (key, label) in enumerate(keys_labels):
        mt = trends.get(key)
        if not mt:
            continue
        vals = [v if v is not None else None for v in mt.values]
        if all(v is None for v in vals):
            continue
        any_data = True
        fig.add_trace(go.Scatter(x=mt.years, y=vals, mode="lines+markers", name=label,
                                  line=dict(color=PALETTE[i % len(PALETTE)], width=3),
                                  marker=dict(size=7)))
    if not any_data:
        return _empty_fig("None of the requested metrics were found in the multi-year track record table.")
    fig.update_layout(height=380, margin=dict(l=40, r=20, t=30, b=40),
                       legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="left", x=0),
                       plot_bgcolor="white", xaxis=dict(showgrid=False), yaxis=dict(showgrid=True, gridcolor="#EEEEEE"))
    return fig


def build_margin_chart(trends: Optional[Dict[str, Any]], ratios_sa: Optional[Any]) -> go.Figure:
    """Margin trend if multi-year data exists; else a 2-year bar comparison from ratios."""
    if trends and trends.get("turnover") and trends.get("ebitda") and trends.get("pat"):
        years = trends["turnover"].years
        turnover = trends["turnover"].values
        ebitda = trends["ebitda"].values
        pat = trends["pat"].values
        ebitda_margin = [round(e / t * 100, 2) if (e is not None and t) else None for e, t in zip(ebitda, turnover)]
        pat_margin = [round(p / t * 100, 2) if (p is not None and t) else None for p, t in zip(pat, turnover)]
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=years, y=ebitda_margin, mode="lines+markers", name="EBITDA Margin %",
                                  line=dict(color=NAVY, width=3)))
        fig.add_trace(go.Scatter(x=years, y=pat_margin, mode="lines+markers", name="Net Profit Margin %",
                                  line=dict(color=GOLD, width=3)))
        fig.update_layout(height=350, margin=dict(l=40, r=20, t=30, b=40), plot_bgcolor="white",
                           legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="left", x=0),
                           yaxis=dict(title="%", showgrid=True, gridcolor="#EEEEEE"), xaxis=dict(showgrid=False))
        return fig

    if ratios_sa is None:
        return _empty_fig("No ratio data available for margin analysis.")
    r = ratios_sa.ratios
    cats = ["Gross Margin", "EBITDA Margin", "Operating Margin", "Net Profit Margin"]
    cur = [r.get("gross_margin_pct_fy26"), r.get("ebitda_margin_pct_fy26"),
           r.get("operating_margin_pct_fy26"), r.get("net_profit_margin_pct_fy26")]
    prev = [r.get("gross_margin_pct_fy25"), r.get("ebitda_margin_pct_fy25"),
            r.get("operating_margin_pct_fy25"), r.get("net_profit_margin_pct_fy25")]
    fig = go.Figure()
    fig.add_trace(go.Bar(x=cats, y=prev, name="FY25", marker_color=GOLD))
    fig.add_trace(go.Bar(x=cats, y=cur, name="FY26", marker_color=NAVY))
    fig.update_layout(barmode="group", height=350, margin=dict(l=40, r=20, t=30, b=40), plot_bgcolor="white",
                       yaxis=dict(title="%", showgrid=True, gridcolor="#EEEEEE"))
    return fig


def build_cash_flow_chart(fields: Dict[str, Optional[float]]) -> go.Figure:
    cats = ["Operating", "Investing", "Financing"]
    cur = [fields.get("operating_cash_flow"), fields.get("investing_cash_flow"), fields.get("financing_cash_flow")]
    if all(v is None for v in cur):
        return _empty_fig("Cash flow data not available.")
    colors = [GREEN if (v or 0) >= 0 else RED for v in cur]
    fig = go.Figure(go.Bar(x=cats, y=cur, marker_color=colors, text=[f"{v:,.0f}" if v is not None else "" for v in cur],
                            textposition="outside"))
    fig.update_layout(height=320, margin=dict(l=40, r=20, t=30, b=40), plot_bgcolor="white",
                       yaxis=dict(title="Rs. (statement units)", showgrid=True, gridcolor="#EEEEEE"),
                       xaxis=dict(showgrid=False))
    return fig


def build_assets_liabilities_chart(fields: Dict[str, Optional[float]]) -> go.Figure:
    cats = ["Non-Current Assets", "Current Assets", "Equity", "Non-Current Liab.", "Current Liab."]
    cur = [fields.get("non_current_assets"), fields.get("current_assets"), fields.get("total_equity"),
           fields.get("non_current_liabilities"), fields.get("current_liabilities")]
    if all(v is None for v in cur):
        return _empty_fig("Balance Sheet data not available.")
    colors = [NAVY, "#5B8AC7", GOLD, "#D9A400", "#7F6000"]
    fig = go.Figure(go.Bar(x=cats, y=cur, marker_color=colors, text=[f"{v:,.0f}" if v is not None else "" for v in cur],
                            textposition="outside"))
    fig.update_layout(height=350, margin=dict(l=40, r=20, t=30, b=60), plot_bgcolor="white",
                       yaxis=dict(title="Rs. (statement units)", showgrid=True, gridcolor="#EEEEEE"),
                       xaxis=dict(showgrid=False))
    return fig


def build_debt_trend_chart(trends: Optional[Dict[str, Any]], ratios_sa: Optional[Any]) -> go.Figure:
    if trends and trends.get("shareholders_fund"):
        de_years = trends["shareholders_fund"].years
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=de_years, y=trends["shareholders_fund"].values, mode="lines+markers",
                                  name="Shareholders' Fund", line=dict(color=NAVY, width=3)))
        if trends.get("capex"):
            fig.add_trace(go.Bar(x=trends["capex"].years, y=trends["capex"].values, name="Capex",
                                  marker_color=GOLD, opacity=0.6, yaxis="y2"))
            fig.update_layout(yaxis2=dict(overlaying="y", side="right", title="Capex", showgrid=False))
        fig.update_layout(height=350, margin=dict(l=40, r=40, t=30, b=40), plot_bgcolor="white",
                           legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="left", x=0),
                           yaxis=dict(title="Shareholders' Fund", showgrid=True, gridcolor="#EEEEEE"))
        return fig
    if ratios_sa is None:
        return _empty_fig("No leverage trend data available.")
    r = ratios_sa.ratios
    cats = ["FY25", "FY26"]
    de = [r.get("debt_equity_ratio_fy25"), r.get("debt_equity_ratio_fy26")]
    fig = go.Figure(go.Bar(x=cats, y=de, marker_color=[GOLD, NAVY],
                            text=[f"{v:.2f}x" if v is not None else "" for v in de], textposition="outside"))
    fig.update_layout(height=320, margin=dict(l=40, r=20, t=30, b=40), plot_bgcolor="white",
                       yaxis=dict(title="Debt-Equity Ratio (x)", showgrid=True, gridcolor="#EEEEEE"))
    return fig


def build_ratio_gauges(ratios_sa: Optional[Any]) -> go.Figure:
    if ratios_sa is None:
        return _empty_fig("No ratio data available for gauges.")
    r = ratios_sa.ratios
    gauges = [
        ("Current Ratio", r.get("current_ratio_fy26"), 0, 3, 1.0),
        ("ROE % (Closing)", r.get("roe_closing_pct_fy26"), 0, 50, 15),
        ("Debt-Equity (x)", r.get("debt_equity_ratio_fy26"), 0, 2, 1.0),
        ("Interest Coverage (x)", r.get("interest_coverage_ratio_fy26"), 0, 40, 4.0),
    ]
    fig = make_subplots(rows=1, cols=4, specs=[[{"type": "indicator"}] * 4])
    for i, (title, value, lo, hi, threshold) in enumerate(gauges, start=1):
        fig.add_trace(go.Indicator(
            mode="gauge+number", value=value if value is not None else 0,
            title={"text": title, "font": {"size": 13}},
            gauge={"axis": {"range": [lo, hi]},
                   "bar": {"color": NAVY},
                   "threshold": {"line": {"color": RED, "width": 3}, "value": threshold}},
        ), row=1, col=i)
    fig.update_layout(height=260, margin=dict(l=20, r=20, t=50, b=10))
    return fig


def build_risk_heatmap(risk_entries: Optional[List[Any]]) -> go.Figure:
    if not risk_entries:
        return _empty_fig("No structured risk register available for this filing — heatmap unavailable.")
    level_map = {"increased": 3, "no change": 2, "decreased": 1}
    x_vals, y_vals, texts, sizes = [], [], [], []
    for r in risk_entries:
        x_vals.append(len(r.capitals_impacted))          # proxy for Impact
        y_vals.append(level_map.get(r.level_of_change.lower(), 2))  # proxy for Likelihood/trend
        texts.append(r.title)
        sizes.append(18)
    fig = go.Figure(go.Scatter(
        x=x_vals, y=y_vals, mode="markers+text", text=texts, textposition="top center",
        marker=dict(size=sizes, color=[GOLD if v == 3 else (NAVY if v == 2 else "#5B8AC7") for v in y_vals]),
    ))
    fig.update_layout(
        height=380, margin=dict(l=60, r=20, t=30, b=60), plot_bgcolor="white",
        xaxis=dict(title="Impact (Capitals Impacted — company-disclosed count)", tickmode="linear", dtick=1,
                   range=[-0.5, max(x_vals + [1]) + 0.5]),
        yaxis=dict(title="Trend (company-disclosed Level of Change)", tickmode="array", tickvals=[1, 2, 3],
                   ticktext=["Decreased", "No change", "Increased"], range=[0.5, 3.5]),
    )
    return fig


def build_year_comparison_chart(fields: Dict[str, Optional[float]]) -> go.Figure:
    cats = ["Revenue", "EBITDA", "PAT", "Total Assets"]
    cur = [fields.get("revenue"), fields.get("ebitda_operating"), fields.get("pat_total"), fields.get("total_assets")]
    prev = [fields.get("revenue_prev"), fields.get("ebitda_operating_prev"), fields.get("pat_total_prev"),
            fields.get("total_assets_prev")]
    if all(v is None for v in cur):
        return _empty_fig("No data available for year comparison.")
    fig = go.Figure()
    fig.add_trace(go.Bar(x=cats, y=prev, name="FY25", marker_color=GOLD))
    fig.add_trace(go.Bar(x=cats, y=cur, name="FY26", marker_color=NAVY))
    fig.update_layout(barmode="group", height=350, margin=dict(l=40, r=20, t=30, b=40), plot_bgcolor="white",
                       legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="left", x=0),
                       yaxis=dict(title="Rs. (statement units)", showgrid=True, gridcolor="#EEEEEE"))
    return fig


def build_scorecard(ratios_sa: Optional[Any], red_flags_sa: Optional[Any]) -> List[Dict[str, Any]]:
    """Returns a list of {metric, value, status} for a simple colour-coded scorecard table."""
    if ratios_sa is None:
        return []
    r = ratios_sa.ratios
    rows = [
        ("Revenue Growth %", r.get("revenue_growth_pct")),
        ("EBITDA Margin %", r.get("ebitda_margin_pct_fy26")),
        ("Net Profit Margin %", r.get("net_profit_margin_pct_fy26")),
        ("ROE (Closing) %", r.get("roe_closing_pct_fy26")),
        ("Current Ratio (x)", r.get("current_ratio_fy26")),
        ("Debt-Equity (x)", r.get("debt_equity_ratio_fy26")),
        ("Interest Coverage (x)", r.get("interest_coverage_ratio_fy26")),
        ("Cash Conversion Cycle (days)", r.get("cash_conversion_cycle_closing_fy26")),
    ]
    severity_by_check = {}
    if red_flags_sa is not None:
        for f in red_flags_sa.flags:
            severity_by_check[f.check] = f.severity
    flag_map = {
        "Revenue Growth %": "Revenue Decline (YoY)",
        "EBITDA Margin %": "EBITDA Margin Contraction (YoY)",
        "Current Ratio (x)": "Liquidity Stress (Current Ratio)",
        "Debt-Equity (x)": "High Leverage (Debt-Equity)",
        "Interest Coverage (x)": "Low Interest Coverage",
    }
    out = []
    for label, value in rows:
        sev = severity_by_check.get(flag_map.get(label, ""), "NONE")
        out.append({"metric": label, "value": value, "severity": sev})
    return out

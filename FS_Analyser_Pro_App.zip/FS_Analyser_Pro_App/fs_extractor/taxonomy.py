"""
FS Analyser Pro — Module 1: PDF Extraction Engine
Taxonomy mapping

Ind-AS Schedule III statements do not print "COGS" or "EBITDA" as a
line item — these are analyst constructs. This module derives them
transparently and records the EXACT formula used against every derived
field, per the requirement to state assumptions clearly before any
figure is relied upon.

Two EBITDA variants are provided deliberately:
  - "ebitda_operating": excludes Other Income and Exceptional items.
    This is the cleaner measure of core operating performance and the
    one this module treats as primary.
  - "ebitda_reported": includes Other Income (a looser, more commonly
    quoted variant). Provided for cross-reference only.
Both are clearly labelled; neither should be treated as an Ind-AS/SEBI
defined term, since none exists for EBITDA under Indian GAAP/Ind-AS.
"""
from __future__ import annotations

from typing import Optional

from .models import StatementBlock, MappedFinancials


def _sum_values(items, field: str) -> Optional[float]:
    vals = [getattr(li, field) for li in items if getattr(li, field) is not None]
    return round(sum(vals), 2) if vals else None


def _val(li, field: str) -> Optional[float]:
    return getattr(li, field) if li is not None else None


def build_mapped_financials(
    basis: str,
    bs: Optional[StatementBlock],
    pl: Optional[StatementBlock],
    cf: Optional[StatementBlock],
) -> MappedFinancials:
    m = MappedFinancials(basis=basis)
    F = m.fields
    FORM = m.formulas
    SRC = m.source_labels

    for yr_field in ("value_current", "value_previous"):
        suffix = "" if yr_field == "value_current" else "_prev"

        # ---------------- INCOME STATEMENT ---------------------------------
        if pl is not None:
            revenue = pl.get("Revenue from operations")
            other_income = pl.get("Other income")
            total_income = pl.get("TOTAL INCOME")
            cost_materials = pl.get("Cost of materials consumed")
            purchases_stock = pl.get("Purchases of stock-in-trade")
            chg_inventories = pl.get("Changes in inventories")
            employee_cost = pl.get("Employee benefits expense")
            finance_costs = pl.get("Finance costs")
            depreciation = pl.get("Depreciation and amortisation expense")
            other_expenses = pl.get("Other expenses")
            total_expenses = pl.get("TOTAL EXPENSES")
            exceptional = pl.get_starting_with_marker("exceptional items")
            pbt_continuing = pl.get("Profit before tax from continuing operations") or pl.get("profit before tax")
            pat_continuing = (pl.get("PROFIT FOR THE YEAR FROM CONTINUING OPERATIONS")
                               or pl.get("profit for the year from continuing operations")
                               or pl.get("profit for the year"))
            pat_discontinued = pl.get("FOR THE YEAR FROM DISCONTINUED OPERATIONS")
            pat_total = pl.get("PROFIT FOR THE YEAR (C=A+B)") or pl.get("PROFIT FOR THE YEAR")
            basic_eps = (pl.get_where(section_substr="continuing and discontinued", label_substr="Basic (in")
                         or pl.get_multi(["basic", "diluted", "earnings per"])
                         or pl.get_multi(["basic", "earnings per share"]))

            F[f"revenue{suffix}"] = _val(revenue, yr_field)
            F[f"other_income{suffix}"] = _val(other_income, yr_field)
            F[f"total_income{suffix}"] = _val(total_income, yr_field)

            cogs = None
            parts = [cost_materials, purchases_stock, chg_inventories]
            if any(p is not None for p in parts):
                cogs = round(sum(_val(p, yr_field) or 0.0 for p in parts), 2)
            F[f"cogs{suffix}"] = cogs
            FORM["cogs"] = ("Cost of materials consumed + Purchases of stock-in-trade + "
                             "Changes in inventories of finished goods/WIP/stock-in-trade "
                             "(Ind-AS Schedule III does not use the term 'COGS'; this is an "
                             "analyst construct combining the three relevant expense lines)")

            F[f"employee_cost{suffix}"] = _val(employee_cost, yr_field)
            F[f"finance_costs{suffix}"] = _val(finance_costs, yr_field)
            F[f"depreciation{suffix}"] = _val(depreciation, yr_field)
            F[f"other_expenses{suffix}"] = _val(other_expenses, yr_field)
            F[f"total_expenses{suffix}"] = _val(total_expenses, yr_field)
            F[f"exceptional_items{suffix}"] = _val(exceptional, yr_field)
            F[f"pbt_continuing{suffix}"] = _val(pbt_continuing, yr_field)
            F[f"pat_continuing{suffix}"] = _val(pat_continuing, yr_field)
            F[f"pat_discontinued{suffix}"] = _val(pat_discontinued, yr_field)
            F[f"pat_total{suffix}"] = _val(pat_total, yr_field)
            F[f"basic_eps_total{suffix}"] = _val(basic_eps, yr_field)

            rev_v = F.get(f"revenue{suffix}")
            texp_v = F.get(f"total_expenses{suffix}")
            fc_v = F.get(f"finance_costs{suffix}")
            dep_v = F.get(f"depreciation{suffix}")
            oi_v = F.get(f"other_income{suffix}")
            pbt_v = F.get(f"pbt_continuing{suffix}")

            if None not in (rev_v, texp_v, fc_v, dep_v):
                F[f"ebitda_operating{suffix}"] = round(rev_v - (texp_v - fc_v - dep_v), 2)
            else:
                F[f"ebitda_operating{suffix}"] = None
            FORM["ebitda_operating"] = ("Revenue from operations − (Total Expenses − Finance "
                                         "Costs − Depreciation & Amortisation). Excludes Other "
                                         "Income and Exceptional items — reflects core operating "
                                         "performance only. Primary EBITDA measure used by this "
                                         "module.")

            if None not in (pbt_v, fc_v, dep_v, oi_v):
                F[f"ebitda_reported{suffix}"] = round(pbt_v + fc_v + dep_v - oi_v + 0.0, 2)
                # Note: PBT already reflects exceptional items; this variant
                # therefore nets exceptional items back into the base unless
                # explicitly removed. Kept only as a loose cross-reference.
            else:
                F[f"ebitda_reported{suffix}"] = None
            FORM["ebitda_reported"] = ("Profit Before Tax (continuing ops) + Finance Costs + "
                                        "Depreciation & Amortisation − Other Income. Includes "
                                        "the effect of Exceptional items embedded in PBT — "
                                        "provided for cross-reference only; ebitda_operating is "
                                        "the recommended measure for margin analysis.")

            ebitda_op = F.get(f"ebitda_operating{suffix}")
            if ebitda_op is not None and dep_v is not None:
                F[f"ebit_operating{suffix}"] = round(ebitda_op - dep_v, 2)
            else:
                F[f"ebit_operating{suffix}"] = None
            FORM["ebit_operating"] = "ebitda_operating − Depreciation & Amortisation Expense"

        # ---------------- BALANCE SHEET -------------------------------------
        if bs is not None:
            # "TOTAL ASSETS" never collides with "Total Non-current/Current
            # Assets" sub-totals (the qualifier sits BETWEEN "total" and
            # "assets" in Schedule III wording, e.g. "Total Non-Current
            # Assets"), so a plain substring search is already safe here.
            total_assets = bs.get("TOTAL ASSETS")
            nca_total = bs.get_total("non-current assets")
            ca_total = bs.get_total("current assets", exclude="non-current")
            inventories = bs.get_all("Inventories")
            inventories = inventories[0] if inventories else None
            trade_recv = bs.get("Trade receivables")
            cash_equiv = bs.get("Cash and cash equivalents")
            total_equity = bs.get_total("equity", exclude="liabilities")
            ncl_total = bs.get_total("non-current liabilities")
            cl_total = bs.get_total("current liabilities", exclude="non-current")
            lease_liabs = bs.get_all("Lease liabilities")
            trade_pay_micro = bs.get("outstanding dues of micro")
            trade_pay_other = bs.get("outstanding dues of creditors other than micro")

            F[f"total_assets{suffix}"] = _val(total_assets, yr_field)
            F[f"non_current_assets{suffix}"] = _val(nca_total, yr_field)
            F[f"current_assets{suffix}"] = _val(ca_total, yr_field)
            F[f"inventories{suffix}"] = _val(inventories, yr_field)
            F[f"trade_receivables{suffix}"] = _val(trade_recv, yr_field)
            F[f"cash_and_equivalents{suffix}"] = _val(cash_equiv, yr_field)
            F[f"total_equity{suffix}"] = _val(total_equity, yr_field)
            F[f"non_current_liabilities{suffix}"] = _val(ncl_total, yr_field)
            F[f"current_liabilities{suffix}"] = _val(cl_total, yr_field)
            F[f"lease_liabilities_total{suffix}"] = _sum_values(lease_liabs, yr_field)
            FORM["lease_liabilities_total"] = ("Sum of non-current + current Lease liabilities. "
                                                "HUL Standalone carries no interest-bearing "
                                                "borrowings on the face of the Balance Sheet; "
                                                "lease liabilities are the closest analogue and "
                                                "are used as 'Debt' for leverage ratios in "
                                                "Module 2 unless a Borrowings line is present.")
            tp_parts = [trade_pay_micro, trade_pay_other]
            if any(p is not None for p in tp_parts):
                F[f"trade_payables{suffix}"] = round(
                    sum(_val(p, yr_field) or 0.0 for p in tp_parts), 2)
            else:
                F[f"trade_payables{suffix}"] = None
            FORM["trade_payables"] = ("Total outstanding dues to micro/small enterprises + "
                                       "Total outstanding dues to other creditors (both "
                                       "disclosed separately per MSMED Act, 2006 requirements)")

        # ---------------- CASH FLOW STATEMENT -------------------------------
        if cf is not None:
            # Matched on invariant fragments ("net cash" + "operating
            # activities") rather than the exact phrase, since companies
            # phrase this differently — e.g. HUL: "Net cash flows generated
            # from operating activities - [A]"; Nestlé: "Net cash flows
            # generated from / (used in) operating activities" (no "[A]"
            # suffix at all).
            ocf = cf.get_multi(["net cash", "operating activities"])
            icf = cf.get_multi(["net cash", "investing activities"])
            fcf = cf.get_multi(["net cash", "financing activities"])
            capex = cf.get("Purchase of property, plant and equipment")
            dividends_paid = cf.get("Dividends paid")

            F[f"operating_cash_flow{suffix}"] = _val(ocf, yr_field)
            F[f"investing_cash_flow{suffix}"] = _val(icf, yr_field)
            F[f"financing_cash_flow{suffix}"] = _val(fcf, yr_field)
            F[f"dividends_paid{suffix}"] = _val(dividends_paid, yr_field)
            capex_v = _val(capex, yr_field)
            F[f"capex{suffix}"] = abs(capex_v) if capex_v is not None else None
            FORM["capex"] = ("Absolute value of 'Purchase of property, plant and equipment' "
                              "under Investing Activities. Does not include intangible asset "
                              "purchases or capitalised lease additions.")

            ocf_v = F.get(f"operating_cash_flow{suffix}")
            capex_val = F.get(f"capex{suffix}")
            if ocf_v is not None and capex_val is not None:
                F[f"free_cash_flow{suffix}"] = round(ocf_v - capex_val, 2)
            else:
                F[f"free_cash_flow{suffix}"] = None
            FORM["free_cash_flow"] = "Net Cash Flow from Operating Activities − Capex (PP&E purchases only)"

    return m

"""
FS Analyser Pro — Module 5: Risk & Auditor Analysis (Rule-Based)

Two genuinely different extraction problems live in this module:

1. RISK REGISTER — some companies (observed: HUL) disclose risks in a
   STRUCTURED template: a short risk title, "Category of Risk:", "Level
   of Change:", "Capital Impacted:" tags, a description paragraph, and a
   numbered mitigation-actions list, laid out in two columns (description
   left, response right). Where this structured template is detected,
   this module parses it mechanically (coordinate-based column split,
   the same technique used for financial statements) — NOT via narrative
   summarisation. Where it is NOT detected (observed: Nestlé, which
   discusses risk more diffusely across its MD&A and BRSR rather than in
   one structured register), this module reports that finding honestly
   rather than forcing a low-quality parse — see `risk_register_found`.

   "Likelihood" is approximated by the disclosed "Level of Change"
   (Increased/No change/Decreased) — a trend indicator, not a probability
   — flagged as such throughout. "Impact" is approximated by the number
   of Capitals Impacted, since neither company independently discloses a
   quantified severity score; also flagged as an approximation, not
   invented data.

2. AUDITOR ANALYSIS — opinion type, Key Audit Matters, Emphasis of
   Matter, and internal-control observations are identified via
   structural cues that are consistent across Indian statutory audit
   reports: known section headings ("Key Audit Matters", "Emphasis of
   Matter"), a company-law-mandated boilerplate sentence in the Board's
   Report confirming (or not) that the auditor's report carries no
   qualification/reservation/adverse remark/disclaimer, and bold-font KAM
   sub-headings (left column only, matched by "bold" appearing in the
   PDF's own font name — a generic, company-agnostic signal). KAM titles
   are extracted; the underlying descriptive paragraphs are NOT
   reproduced, consistent with copyright limits and with this module's
   "mechanical facts only" design.

Business implications are stated as plain factual enumeration (e.g. "N
Key Audit Matters were identified, relating to: ...") — not an
interpretive narrative — for the same reason MD&A summarisation was kept
out of the app: a script can reliably count and list what a heading-based
scan found, but should not be dressed up as having "read and assessed"
the underlying risk.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import pdfplumber

# ---------------------------------------------------------------------------
# Risk category taxonomy (the 15 buckets requested) + keyword map used to
# normalise whatever category label the company itself uses.
# ---------------------------------------------------------------------------
RISK_TAXONOMY = [
    "Market", "Operational", "Financial", "Liquidity", "Interest Rate",
    "Foreign Exchange", "Commodity", "Regulatory", "Cybersecurity", "ESG",
    "Legal", "Climate", "Supply Chain", "Customer Concentration", "Technology",
]

_CATEGORY_KEYWORDS: List[Tuple[str, List[str]]] = [
    ("Cybersecurity", ["cyber", "information security", "data security", "it security"]),
    ("Technology", ["technology", "digital", "system", "it risk", "automation"]),
    ("Climate", ["climate"]),
    ("ESG", ["environmental", "sustainab", "esg", "governance risk", "social"]),
    ("Regulatory", ["regulat", "compliance", "statutory", "policy risk", "legislat"]),
    ("Legal", ["legal", "litigation", "lawsuit"]),
    ("Supply Chain", ["supply chain", "sourcing", "procurement", "logistics", "vendor"]),
    ("Commodity", ["commodity", "raw material price", "input cost"]),
    ("Foreign Exchange", ["foreign exchange", "forex", "fx risk", "currency"]),
    ("Interest Rate", ["interest rate"]),
    ("Liquidity", ["liquidity"]),
    ("Financial", ["financial risk", "credit risk", "capital structure"]),
    ("Customer Concentration", ["customer concentration", "key customer", "customer dependency"]),
    ("Operational", ["operational", "manufactur", "production", "quality", "safety"]),
    ("Market", ["market", "competitive", "brand", "consumer preference", "economic"]),
]


def normalize_risk_category(raw: Optional[str]) -> str:
    if not raw:
        return "Uncategorised (not stated)"
    low = raw.lower()
    matched = [cat for cat, kws in _CATEGORY_KEYWORDS if any(kw in low for kw in kws)]
    if matched:
        return " / ".join(dict.fromkeys(matched))  # dedupe, preserve order
    return f"Uncategorised (company label: '{raw.strip()}')"


RISK_SECTION_TITLE_RE = re.compile(r"Key Risk[s]? and Mitigation Strateg", re.IGNORECASE)
RISK_HEADER_RE = re.compile(
    r"^(?P<title>.+?)\s+Category of Risk:\s*(?P<category>.+?)\s+Level of Change:\s*(?P<level>Increased|Decreased|No change)",
    re.IGNORECASE,
)
CAPITAL_LABELS = [
    "Manufactured Capital", "Financial Capital", "Intellectual Capital",
    "Human Capital", "Social & Relationship Capital", "Natural Capital",
]


@dataclass
class RiskEntry:
    title: str
    category_raw: str
    category_normalized: str
    level_of_change: str            # Increased | Decreased | No change  (Likelihood proxy)
    capitals_impacted: List[str] = field(default_factory=list)   # Impact proxy
    description: str = ""
    mitigation_actions: List[str] = field(default_factory=list)
    page_no: int = 0


@dataclass
class AuditorFinding:
    basis: str
    opinion_type: str = "Not determined"     # Unmodified | Qualified | Adverse | Disclaimer | Not determined
    opinion_excerpt: str = ""
    kam_count: int = 0
    kam_titles: List[str] = field(default_factory=list)
    eom_present: bool = False
    icfr_opinion_clean: Optional[bool] = None    # None = not determined
    page_range: Optional[List[int]] = None


@dataclass
class RiskAuditorReport:
    risk_register_found: bool = False
    risk_entries: List[RiskEntry] = field(default_factory=list)
    qualification_boilerplate_found: Optional[bool] = None   # from Board's Report Sec.134(3) disclosure
    qualification_boilerplate_clean: Optional[bool] = None   # True = "does NOT contain any qualification..."
    qualification_boilerplate_text: str = ""
    auditor_findings: List[AuditorFinding] = field(default_factory=list)
    business_implications: List[str] = field(default_factory=list)
    not_assessed: List[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# RISK REGISTER extraction
# ---------------------------------------------------------------------------
def _locate_risk_section(pdf) -> Optional[List[int]]:
    found = []
    for i, page in enumerate(pdf.pages, start=1):
        text = page.extract_text() or ""
        if RISK_SECTION_TITLE_RE.search(text):
            found.append(i)
    if not found:
        return None
    start = found[0]
    end = start
    with_hits = 0
    for j in range(start, min(start + 8, len(pdf.pages)) + 1):
        if j > len(pdf.pages):
            break
        text = pdf.pages[j - 1].extract_text() or ""
        if "Category of Risk:" in text or j == start:
            end = j
            with_hits += 1
        elif j - end > 1:
            break
    return list(range(start, end + 1))


def _split_two_columns(page, col_split_x: float) -> Tuple[List[dict], List[dict]]:
    words = page.extract_words(use_text_flow=False, keep_blank_chars=False, extra_attrs=["fontname"])
    left = [w for w in words if w["x0"] < col_split_x]
    right = [w for w in words if w["x0"] >= col_split_x]
    return left, right


def _lines_from_words(words: List[dict]) -> List[Tuple[float, str]]:
    from collections import defaultdict
    grouped = defaultdict(list)
    for w in words:
        grouped[round(w["top"], 0)].append(w)
    lines = []
    for top in sorted(grouped.keys()):
        ws = sorted(grouped[top], key=lambda w: w["x0"])
        lines.append((top, " ".join(w["text"] for w in ws)))
    return lines


def _extract_risk_entries(pdf, pages: List[int]) -> List[RiskEntry]:
    entries: List[RiskEntry] = []
    for pno in pages:
        page = pdf.pages[pno - 1]
        full_text = page.extract_text() or ""
        if "Category of Risk:" not in full_text:
            continue

        page_width = page.width
        # The header row (title + "Category of Risk:" + "Level of Change:")
        # spans the FULL page width, so it must be reconstructed from ALL
        # words, not the column-split subsets — splitting first truncates
        # it mid-sentence (e.g. right before "Level of Change:"), which is
        # why an earlier version of this function found zero valid matches.
        all_words = page.extract_words(use_text_flow=False, keep_blank_chars=False)
        full_lines = _lines_from_words(all_words)   # [(top, text), ...] across the whole page width

        left_words, right_words = _split_two_columns(page, page_width * 0.48)
        left_lines = _lines_from_words(left_words)
        right_lines = _lines_from_words(right_words)

        header_positions = [i for i, (top, text) in enumerate(full_lines) if "Category of Risk:" in text]

        for hi, line_idx in enumerate(header_positions):
            header_top, header_text = full_lines[line_idx]
            m = RISK_HEADER_RE.search(re.sub(r"\s+", " ", header_text))
            if not m:
                continue
            title = m.group("title").strip()
            category_raw = m.group("category").strip()
            level = m.group("level").strip()

            band_top = header_top
            band_bottom = full_lines[header_positions[hi + 1]][0] if hi + 1 < len(header_positions) else page.height

            desc_parts = []
            for top, text in left_lines:
                if not (band_top < top < band_bottom):
                    continue
                if "Additional Risk Considerations" in text or "Capital Impacted" in text:
                    break
                desc_parts.append(text)
            description = re.sub(r"\s+", " ", " ".join(desc_parts)).strip()

            band_words = [w for w in all_words if band_top <= w["top"] < band_bottom]
            band_text = " ".join(w["text"] for w in band_words)
            capitals = [c for c in CAPITAL_LABELS if c in band_text]

            right_block = [(t, txt) for t, txt in right_lines if band_top - 5 <= t < band_bottom]
            mitigation_text = " ".join(t for _, t in right_block)
            mitigation_items = re.findall(r"\d+\.\s+(.+?)(?=\d+\.\s+|$)", mitigation_text)
            mitigation_items = [re.sub(r"\s+", " ", mi).strip() for mi in mitigation_items if mi.strip()]

            entries.append(RiskEntry(
                title=title,
                category_raw=category_raw,
                category_normalized=normalize_risk_category(category_raw),
                level_of_change=level,
                capitals_impacted=capitals,
                description=description[:600],
                mitigation_actions=mitigation_items[:6],
                page_no=pno,
            ))
    return entries


# ---------------------------------------------------------------------------
# AUDITOR ANALYSIS extraction
# ---------------------------------------------------------------------------
AUDITOR_REPORT_TITLE_RE = re.compile(r"INDEPENDENT AUDITOR.S REPORT", re.IGNORECASE)
KAM_HEADING_RE = re.compile(r"^Key Audit Matter", re.IGNORECASE | re.MULTILINE)
EOM_HEADING_RE = re.compile(r"Emphasis of Matter", re.IGNORECASE)
CONSOLIDATED_HINT_RE = re.compile(r"consolidated financial statements", re.IGNORECASE)

QUALIFICATION_CLEAN_RE = re.compile(
    r"(do(es)?\s+not\s+contain\s+any\s+qualification|"
    r"without\s+any\s+qualification|"
    r"free\s+from\s+any\s+qualification)",
    re.IGNORECASE,
)
QUALIFICATION_PRESENT_RE = re.compile(
    r"\bcontains?\s+(a\s+|the\s+following\s+)?qualification\b(?!.{0,15}(does not|do not))",
    re.IGNORECASE,
)


def _find_qualification_boilerplate(pdf) -> Tuple[Optional[bool], str]:
    """Search the Board's Report for the Companies Act s.134(3)(ca)-driven
    disclosure on whether the Statutory Auditors' report carries any
    qualification, reservation, adverse remark or disclaimer. This is a
    standard, near-universal boilerplate sentence in Indian Board's
    Reports, making it a reliable mechanical signal."""
    for page in pdf.pages:
        text = page.extract_text() or ""
        if "qualification" not in text.lower():
            continue
        for line in text.split("\n"):
            if "qualification" not in line.lower():
                continue
            if QUALIFICATION_CLEAN_RE.search(line):
                return True, line.strip()
        idx = text.lower().find("qualification")
        window = text[max(0, idx - 200):idx + 100]
        if QUALIFICATION_CLEAN_RE.search(window):
            return True, re.sub(r"\s+", " ", window).strip()
        if QUALIFICATION_PRESENT_RE.search(window):
            return False, re.sub(r"\s+", " ", window).strip()
    return None, ""


def _detect_opinion_type(text: str) -> Tuple[str, str]:
    # Normalise whitespace BEFORE classification — the target phrases
    # ("true and fair view", "qualified opinion", etc.) can legitimately
    # wrap across a line break in the source PDF (e.g. "...give a true
    # and\n          fair view..."), which breaks a literal substring
    # check against the raw text. The excerpt capture below already did
    # this; the classification checks did not, causing "Not determined"
    # on pages where the phrase happened to wrap mid-sentence.
    low = re.sub(r"\s+", " ", text).lower()
    opinion_para = ""
    m = re.search(r"opinion\s*\n(.+?)(?:basis for opinion|key audit matter)", text, re.IGNORECASE | re.DOTALL)
    if m:
        opinion_para = re.sub(r"\s+", " ", m.group(1)).strip()[:400]
    if "disclaimer of opinion" in low:
        return "Disclaimer of Opinion", opinion_para
    if "adverse opinion" in low:
        return "Adverse Opinion", opinion_para
    if "qualified opinion" in low:
        return "Qualified Opinion", opinion_para
    if "true and fair view" in low or "present fairly" in low:
        return "Unmodified (Unqualified)", opinion_para
    return "Not determined", opinion_para


def _extract_kam_titles(pdf, pages: List[int]) -> List[str]:
    titles: List[str] = []
    for pno in pages:
        page = pdf.pages[pno - 1]
        page_width = page.width
        words = page.extract_words(use_text_flow=False, keep_blank_chars=False, extra_attrs=["fontname"])
        left_words = [w for w in words if w["x0"] < page_width * 0.5]
        from collections import defaultdict
        grouped = defaultdict(list)
        for w in left_words:
            grouped[round(w["top"], 0)].append(w)
        bold_lines = []
        for top in sorted(grouped.keys()):
            ws = sorted(grouped[top], key=lambda w: w["x0"])
            is_bold = any("bold" in (w.get("fontname") or "").lower() for w in ws)
            text = " ".join(w["text"] for w in ws)
            bold_lines.append((top, text, is_bold))

        i = 0
        while i < len(bold_lines):
            top, text, is_bold = bold_lines[i]
            if not is_bold or KAM_HEADING_RE.match(text.strip()) or "how our audit addressed" in text.lower():
                i += 1
                continue
            block = [text]
            j = i + 1
            while j < len(bold_lines) and bold_lines[j][2] and (bold_lines[j][0] - bold_lines[j - 1][0]) < 15:
                block.append(bold_lines[j][1])
                j += 1
            title = re.sub(r"\s+", " ", " ".join(block)).strip()
            title_low = title.lower()
            if (len(title) > 8 and not re.match(r"^\d+\.\s", title)
                    and "information other than" not in title_low
                    and title_low != "other information" and not title_low.startswith("other information")
                    and "responsibilities of management" not in title_low
                    and not title_low.startswith("auditor")
                    and "independent auditor" not in title_low
                    and "to the members of" not in title_low
                    and "report on the audit of" not in title_low
                    and "annexure" not in title_low
                    and "report on other legal" not in title_low):
                titles.append(title)
            i = j
    seen = set()
    unique = []
    for t in titles:
        key = t.lower()[:40]
        if key not in seen:
            seen.add(key)
            unique.append(t)
    return unique


def _analyze_auditor_report(pdf, basis: str, start_page: int, end_page: int) -> AuditorFinding:
    pages = list(range(start_page, min(end_page, len(pdf.pages)) + 1))
    combined_text = "\n".join((pdf.pages[p - 1].extract_text() or "") for p in pages)

    finding = AuditorFinding(basis=basis, page_range=pages)
    finding.opinion_type, finding.opinion_excerpt = _detect_opinion_type(combined_text)
    finding.eom_present = bool(EOM_HEADING_RE.search(combined_text))

    kam_pages = [p for p in pages if KAM_HEADING_RE.search(pdf.pages[p - 1].extract_text() or "")]
    if kam_pages:
        # The KAM section's heading only appears once (it does not repeat
        # as a running header on continuation pages), so its end must be
        # found via the NEXT standard SA-700 report heading that always
        # follows it, rather than a fixed page offset — otherwise later
        # bold headings ("Auditor's Responsibilities...", "Annexure I")
        # get wrongly swept in as if they were further KAM titles.
        kam_end_re = re.compile(
            r"Information other than the|Responsibilities of Management|"
            r"Auditor.s Responsibilit",
            re.IGNORECASE,
        )
        span = [kam_pages[0]]
        for p in range(kam_pages[0] + 1, min(kam_pages[0] + 6, len(pdf.pages)) + 1):
            page_text = pdf.pages[p - 1].extract_text() or ""
            span.append(p)
            if kam_end_re.search(page_text):
                break
        finding.kam_titles = _extract_kam_titles(pdf, span)
        finding.kam_count = len(finding.kam_titles)

    # Search ALL occurrences of "internal financial controls", not just the
    # first — a Key Audit Matter description often mentions the phrase
    # incidentally (e.g. "...evaluated internal financial controls
    # relevant to accounting for the demerger...") well before the actual
    # ICFR opinion paragraph appears later in the report (under "Report on
    # Other Legal and Regulatory Requirements" / the ICFR Annexure).
    # Taking only the first hit was matching the wrong (KAM) occurrence.
    icfr_opinion_clean = None
    for m in re.finditer(r"internal financial controls", combined_text, re.IGNORECASE):
        window = combined_text[m.start():m.start() + 2000]
        win_norm = re.sub(r"\s+", " ", window).lower()
        if "adequate internal financial controls" in win_norm and "operating effectively" in win_norm:
            if "material weakness" in win_norm:
                icfr_opinion_clean = False
            else:
                icfr_opinion_clean = True
            break
        if "material weakness" in win_norm and ("except for" in win_norm or "qualified" in win_norm):
            icfr_opinion_clean = False
            break
    finding.icfr_opinion_clean = icfr_opinion_clean

    return finding


def _locate_auditor_reports(pdf) -> List[Tuple[str, int, int]]:
    hits = []
    for i, page in enumerate(pdf.pages, start=1):
        text = page.extract_text() or ""
        first_lines = "\n".join(text.split("\n")[:6])
        # "TO THE MEMBERS OF" appears only on the true OPENING page of an
        # Independent Auditor's Report — the title itself repeats as a
        # running header on every subsequent page of the same report, so
        # matching the title alone would wrongly create one "report" per
        # page.
        # Exclude "Annexure" pages (e.g. the CARO annexure) that merely
        # REFER BACK to "the Independent Auditor's Report ... to the
        # members of [Company]" in their own opening line — a genuine
        # report's opening page never describes itself as an annexure.
        if (AUDITOR_REPORT_TITLE_RE.search(first_lines) and "TO THE MEMBERS OF" in first_lines.upper()
                and "annexure" not in first_lines.lower() and "referred to in" not in first_lines.lower()):
            hits.append(i)
    if not hits:
        return []
    results = []
    for idx, start in enumerate(hits):
        end = hits[idx + 1] - 1 if idx + 1 < len(hits) else min(start + 100, len(pdf.pages))
        probe_text = "\n".join((pdf.pages[p - 1].extract_text() or "") for p in range(start, min(start + 2, end) + 1))
        basis = "Consolidated" if CONSOLIDATED_HINT_RE.search(probe_text) else "Standalone"
        results.append((basis, start, end))
    return results


def build_risk_auditor_report(pdf_path: str) -> RiskAuditorReport:
    report = RiskAuditorReport()
    with pdfplumber.open(pdf_path) as pdf:
        risk_pages = _locate_risk_section(pdf)
        if risk_pages:
            entries = _extract_risk_entries(pdf, risk_pages)
            if entries:
                report.risk_register_found = True
                report.risk_entries = entries
            else:
                report.not_assessed.append(
                    "A 'Key Risk and Mitigation Strategies' heading was found, but no individual risk "
                    "entries matching the expected 'Category of Risk: / Level of Change:' template could "
                    "be parsed from it — the company may use a variant layout.")
        else:
            report.not_assessed.append(
                "No structured risk register (a 'Key Risk and Mitigation Strategies' section using a "
                "'Category of Risk:' / 'Level of Change:' template) was found in this filing. Risk factors "
                "may be discussed narratively elsewhere in the report (MD&A, BRSR) but are not mechanically "
                "extracted by this module — a script cannot reliably paraphrase free-form risk narrative "
                "without misrepresenting it (the same limitation that excluded MD&A summarisation).")

        clean, boilerplate_text = _find_qualification_boilerplate(pdf)
        report.qualification_boilerplate_found = clean is not None
        report.qualification_boilerplate_clean = clean
        report.qualification_boilerplate_text = boilerplate_text
        if clean is None:
            report.not_assessed.append(
                "The standard Companies Act s.134(3)(ca) Board's Report disclosure on auditor qualifications "
                "was not found verbatim — could not mechanically confirm qualification status from this source; "
                "see each Auditor's Report opinion type below instead.")

        auditor_sections = _locate_auditor_reports(pdf)
        if not auditor_sections:
            report.not_assessed.append("No 'Independent Auditor's Report' section was located in this filing.")
        for basis, start, end in auditor_sections:
            report.auditor_findings.append(_analyze_auditor_report(pdf, basis, start, end))

    impl = []
    if report.qualification_boilerplate_clean is True:
        impl.append("The Board's Report confirms the Statutory Auditors' report carries no qualification, "
                     "reservation, adverse remark, or disclaimer.")
    elif report.qualification_boilerplate_clean is False:
        impl.append("The Board's Report disclosure indicates the Statutory Auditors' report DOES carry a "
                     "qualification, reservation, adverse remark, or disclaimer — review the full Auditor's "
                     "Report before relying on the financial statements.")

    for af in report.auditor_findings:
        impl.append(f"{af.basis} Auditor's Report opinion: {af.opinion_type}.")
        if af.kam_count:
            impl.append(f"{af.basis}: {af.kam_count} Key Audit Matter(s) identified — "
                        + "; ".join(af.kam_titles) + ".")
        else:
            impl.append(f"{af.basis}: No Key Audit Matters section was identified.")
        if af.eom_present:
            impl.append(f"{af.basis}: An Emphasis of Matter paragraph IS present — review it directly, "
                        f"as this module does not extract its content.")
        if af.icfr_opinion_clean is True:
            impl.append(f"{af.basis}: Internal financial controls opinion appears unmodified "
                        f"(no material weakness language detected).")
        elif af.icfr_opinion_clean is False:
            impl.append(f"{af.basis}: Internal financial controls section may flag a weakness or "
                        f"exception — review directly.")

    if report.risk_register_found:
        cat_counts: Dict[str, int] = {}
        for r in report.risk_entries:
            cat_counts[r.category_normalized] = cat_counts.get(r.category_normalized, 0) + 1
        impl.append(f"{len(report.risk_entries)} risk(s) disclosed in the structured risk register, "
                    f"spanning categories: " + ", ".join(f"{k} ({v})" for k, v in cat_counts.items()) + ".")
        increased = [r.title for r in report.risk_entries if r.level_of_change.lower() == "increased"]
        if increased:
            impl.append("Risks the company itself flags as INCREASED since the prior year: " + "; ".join(increased) + ".")

    report.business_implications = impl
    return report

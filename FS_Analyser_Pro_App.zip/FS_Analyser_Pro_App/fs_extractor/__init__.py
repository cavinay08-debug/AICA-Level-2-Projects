"""FS Analyser Pro — Module 1: PDF Extraction Engine"""
from .extractor import FinancialStatementExtractor

__all__ = ["FinancialStatementExtractor"]

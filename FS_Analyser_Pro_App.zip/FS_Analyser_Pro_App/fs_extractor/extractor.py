"""
FS Analyser Pro — Module 1: PDF Extraction Engine
Main orchestrator

Usage:
    from fs_extractor.extractor import FinancialStatementExtractor
    fx = FinancialStatementExtractor("annual_report.pdf")
    company = fx.extract()
"""
from __future__ import annotations

import re
from typing import Optional, List

import pdfplumber

from .locator import locate_statements, LocatedStatement, CFS_END_MARKER
from .row_reconstructor import reconstruct_page_rows
from .models import LineItem, StatementBlock, CompanyFinancials
from . import taxonomy
from . import validators

STATEMENT_LABELS = {
    "balance_sheet": "Balance Sheet",
    "profit_and_loss": "Statement of Profit and Loss",
    "cash_flow": "Statement of Cash Flows",
}


class FinancialStatementExtractor:
    def __init__(self, pdf_path: str):
        self.pdf_path = pdf_path

    def extract(self) -> CompanyFinancials:
        company = CompanyFinancials(source_file=self.pdf_path)

        located = locate_statements(self.pdf_path)
        if not located:
            company.extraction_warnings.append(
                "No financial statement pages were located. The document may "
                "not follow the standard Ind-AS Schedule III title convention "
                "this engine looks for ('Standalone/Consolidated Balance "
                "Sheet', etc.)."
            )
            return company

        company.report_title = self._get_report_title()

        with pdfplumber.open(self.pdf_path) as pdf:
            for stmt in located:
                if stmt.statement_type not in STATEMENT_LABELS:
                    continue  # skip Changes in Equity etc. for Module 1 scope
                block = self._extract_statement(pdf, stmt)
                key = f"{stmt.basis.lower()}_{stmt.statement_type}"
                company.statements[key] = block

        # --- Build standardised (mapped) view + derived fields --------------
        for basis in ("standalone", "consolidated"):
            bs = company.statements.get(f"{basis}_balance_sheet")
            pl = company.statements.get(f"{basis}_profit_and_loss")
            cf = company.statements.get(f"{basis}_cash_flow")
            if bs or pl or cf:
                company.mapped[basis] = taxonomy.build_mapped_financials(basis, bs, pl, cf)

        # --- Validation / tie-out checks --------------------------------------
        company.validation_results = validators.run_all_checks(company)

        return company

    def _get_report_title(self) -> Optional[str]:
        try:
            with pdfplumber.open(self.pdf_path) as pdf:
                text = pdf.pages[0].extract_text() or ""
                lines = [l.strip() for l in text.split("\n") if l.strip()]
                return lines[-1] if lines else None
        except Exception:
            return None

    def _extract_statement(self, pdf, stmt: LocatedStatement) -> StatementBlock:
        block = StatementBlock(
            statement_type=STATEMENT_LABELS[stmt.statement_type],
            basis=stmt.basis,
            page_range=list(range(stmt.start_page, stmt.end_page + 1)),
        )
        stop = False
        for page_no in range(stmt.start_page, stmt.end_page + 1):
            if stop:
                break
            page = pdf.pages[page_no - 1]
            result = reconstruct_page_rows(page, page_no=page_no)

            if block.period_label_current is None and result["period_current"]:
                block.period_label_current = result["period_current"]
                block.period_label_previous = result["period_previous"]

            # Unit disclosure e.g. "(All amounts in Rs. crores, unless
            # otherwise stated)" — capture once from the raw page text.
            if block.unit is None:
                raw_text = page.extract_text() or ""
                m = re.search(r"\(All amounts in ([^)]+)\)", raw_text)
                if m:
                    unit_text = m.group(1).strip()
                    unit_text = re.sub(r",?\s*unless otherwise stated\.?$", "", unit_text, flags=re.IGNORECASE).strip()
                    unit_text = unit_text.replace("H crores", "Rs. Crores").replace("H crore", "Rs. Crore")
                    block.unit = unit_text

            for r in result["rows"]:
                li = LineItem(
                    label=r.label,
                    note=r.note,
                    value_current=r.value_current,
                    value_previous=r.value_previous,
                    section=r.section,
                    is_subtotal=bool(re.search(r"\btotal\b", r.label, re.IGNORECASE)),
                    page_no=r.page_no,
                )
                block.line_items.append(li)

                # Cash Flow Statement: stop once we hit the Ind AS 7 method
                # note — everything after that is a supplementary
                # reconciliation sub-table with a different column layout,
                # not part of the core statement.
                if stmt.statement_type == "cash_flow":
                    page_text = page.extract_text() or ""
                    if CFS_END_MARKER.search(page_text) and _label_is_near_end(r.label):
                        pass  # handled by the page-level check below

            if stmt.statement_type == "cash_flow":
                page_text = page.extract_text() or ""
                if CFS_END_MARKER.search(page_text):
                    stop = True

        return block


def _label_is_near_end(label: str) -> bool:
    return "cash and cash equivalents at the end" in label.lower()

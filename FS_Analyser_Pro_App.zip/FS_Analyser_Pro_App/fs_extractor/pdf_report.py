"""
FS Analyser Pro — PDF Report Generator

Same principle as the PPTX generator: every figure here comes from
Modules 1-5's already-validated output. "Recommendations" are templated,
data-driven statements tied to a specific finding, not generated prose.
"""
from __future__ import annotations

from typing import Optional, Any, Dict, List

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak,
    HRFlowable, Frame, PageTemplate, BaseDocTemplate, NextPageTemplate,
)
from reportlab.graphics.shapes import Drawing, String
from reportlab.graphics.charts.barcharts import VerticalBarChart
from reportlab.graphics.charts.lineplots import LinePlot
from reportlab.graphics.charts.legends import Legend

NAVY = colors.HexColor("#1F3864")
GOLD = colors.HexColor("#BF9000")
LIGHT_GOLD = colors.HexColor("#FDF2CC")
GREY = colors.HexColor("#595959")
GREEN = colors.HexColor("#D9EAD3")
RED = colors.HexColor("#F4CCCC")
WHITE = colors.white

SEV_COLORS = {"CRITICAL": colors.HexColor("#C00000"), "HIGH": colors.HexColor("#E06666"),
              "MEDIUM": colors.HexColor("#F9CB9C"), "LOW": colors.HexColor("#FFE599"),
              "NONE": colors.HexColor("#D9EAD3")}


def _fmt(v, dp=1, suffix=""):
    if v is None:
        return "n/a"
    try:
        return f"{v:,.{dp}f}{suffix}"
    except (TypeError, ValueError):
        return str(v)


def _styles():
    ss = getSampleStyleSheet()
    ss.add(ParagraphStyle("TitleBig", parent=ss["Title"], fontSize=28, textColor=NAVY, spaceAfter=6))
    ss.add(ParagraphStyle("SubtitleGold", parent=ss["Normal"], fontSize=14, textColor=GOLD, spaceAfter=20))
    ss.add(ParagraphStyle("SectionHeading", parent=ss["Heading1"], fontSize=18, textColor=colors.white,
                           backColor=NAVY, borderPadding=(8, 10, 8, 10), spaceAfter=14))
    ss.add(ParagraphStyle("SubHeading", parent=ss["Heading2"], fontSize=12, textColor=NAVY, spaceAfter=6))
    ss.add(ParagraphStyle("Body9", parent=ss["Normal"], fontSize=9, leading=13))
    ss.add(ParagraphStyle("Body10", parent=ss["Normal"], fontSize=10, leading=14))
    ss.add(ParagraphStyle("Caption", parent=ss["Normal"], fontSize=8, textColor=GREY, leading=11))
    ss.add(ParagraphStyle("BulletBody", parent=ss["Normal"], fontSize=10, leading=15, leftIndent=14,
                           bulletIndent=2))
    return ss


def _section_header(text, styles):
    return [Paragraph(text, styles["SectionHeading"]), Spacer(1, 6)]


def _kv_table(rows, col_widths, header=None, font_size=9, wrap_cols=None):
    """wrap_cols: set of 0-indexed column indices whose string cells should
    be wrapped in a Paragraph so long text wraps within the column instead
    of overflowing into the next cell (plain strings in reportlab Table
    do not wrap on their own)."""
    wrap_style = ParagraphStyle("CellWrap", fontName="Helvetica", fontSize=font_size, leading=font_size + 2)

    def _cell(v, col_idx):
        if wrap_cols and col_idx in wrap_cols and isinstance(v, str):
            return Paragraph(v, wrap_style)
        return v

    data = []
    if header:
        data.append(header)
    for row in rows:
        data.append([_cell(v, i) for i, v in enumerate(row)])
    t = Table(data, colWidths=col_widths, repeatRows=1 if header else 0)
    style = [
        ("FONTSIZE", (0, 0), (-1, -1), font_size),
        ("FONTNAME", (0, 0), (-1, -1), "Helvetica"),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#DDDDDD")),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 5), ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]
    if header:
        style += [
            ("BACKGROUND", (0, 0), (-1, 0), NAVY),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ]
    for i in range(1 if header else 0, len(data)):
        if (i - (1 if header else 0)) % 2 == 1:
            style.append(("BACKGROUND", (0, i), (-1, i), colors.HexColor("#F5F5F5")))
    t.setStyle(TableStyle(style))
    return t


def _bar_chart_drawing(categories, series: Dict[str, List[Optional[float]]], width=460, height=180, title=""):
    d = Drawing(width, height + 30)
    if title:
        d.add(String(width / 2, height + 12, title, textAnchor="middle", fontSize=11, fillColor=NAVY, fontName="Helvetica-Bold"))
    chart = VerticalBarChart()
    chart.x, chart.y = 50, 10
    chart.width, chart.height = width - 100, height - 20
    clean_series = [[v if v is not None else 0 for v in vals] for vals in series.values()]
    chart.data = clean_series
    chart.categoryAxis.categoryNames = categories
    chart.categoryAxis.labels.fontSize = 7
    chart.categoryAxis.labels.angle = 20
    chart.categoryAxis.labels.dy = -10
    chart.valueAxis.labels.fontSize = 7
    palette = [NAVY, GOLD, colors.HexColor("#5B8AC7"), colors.HexColor("#7F6000")]
    for i in range(len(clean_series)):
        chart.bars[i].fillColor = palette[i % len(palette)]
    d.add(chart)
    if len(series) > 1:
        legend = Legend()
        legend.x = width - 90
        legend.y = height + 10
        legend.fontSize = 7
        legend.colorNamePairs = [(palette[i % len(palette)], name) for i, name in enumerate(series.keys())]
        d.add(legend)
    return d


def _line_chart_drawing(categories, series: Dict[str, List[Optional[float]]], width=460, height=180, title=""):
    d = Drawing(width, height + 30)
    if title:
        d.add(String(width / 2, height + 12, title, textAnchor="middle", fontSize=11, fillColor=NAVY, fontName="Helvetica-Bold"))
    chart = LinePlot()
    chart.x, chart.y = 55, 15
    chart.width, chart.height = width - 110, height - 30
    palette = [NAVY, GOLD, colors.HexColor("#5B8AC7")]
    data = []
    for vals in series.values():
        pts = [(i, v if v is not None else 0) for i, v in enumerate(vals)]
        data.append(pts)
    chart.data = data
    for i in range(len(data)):
        chart.lines[i].strokeColor = palette[i % len(palette)]
        chart.lines[i].strokeWidth = 2
        chart.lines[i].symbol = None
    chart.xValueAxis.valueMin = 0
    chart.xValueAxis.valueMax = max(1, len(categories) - 1)
    chart.xValueAxis.labels.fontSize = 6
    chart.xValueAxis.labelTextFormat = lambda v: categories[int(round(v))] if 0 <= int(round(v)) < len(categories) else ""
    chart.xValueAxis.valueSteps = list(range(len(categories)))
    chart.yValueAxis.labels.fontSize = 7
    d.add(chart)
    if len(series) > 1:
        legend = Legend()
        legend.x = width - 90
        legend.y = height + 10
        legend.fontSize = 7
        legend.colorNamePairs = [(palette[i % len(palette)], name) for i, name in enumerate(series.keys())]
        d.add(legend)
    return d


def build_pdf_report(company, mapped_sa, mapped_co, ra_sa, ra_co, rf_sa, rf_co,
                      trends, risk_report, output_path: str) -> str:
    styles = _styles()
    doc = SimpleDocTemplate(output_path, pagesize=A4,
                             leftMargin=1.6 * cm, rightMargin=1.6 * cm,
                             topMargin=1.4 * cm, bottomMargin=1.6 * cm,
                             title="FS Analyser Pro Report")
    elems = []
    company_name = company.company_name or company.report_title or "Company"
    f = mapped_sa.fields if mapped_sa else {}
    r = ra_sa.ratios if ra_sa else {}

    # ---------------- TITLE PAGE ----------------
    elems.append(Spacer(1, 5 * cm))
    elems.append(Paragraph(company_name, styles["TitleBig"]))
    elems.append(Paragraph("Financial Statement Analysis — FS Analyser Pro", styles["SubtitleGold"]))
    elems.append(HRFlowable(width="100%", thickness=1, color=GOLD))
    elems.append(Spacer(1, 8 * cm))
    elems.append(Paragraph("General-purpose, non-financial-services company scope — see Appendix for disclaimer.",
                            styles["Caption"]))
    elems.append(PageBreak())

    # ---------------- TABLE OF CONTENTS ----------------
    elems += _section_header("Table of Contents", styles)
    toc_items = [
        "1. Executive Summary", "2. Financial Statements (Standalone)", "3. Ratio Analysis",
        "4. Financial Trends & Charts", "5. Risk Register", "6. Auditor Findings",
        "7. Red Flag Detection", "8. Recommendations", "9. Appendix — Methodology & Disclaimer",
    ]
    for item in toc_items:
        elems.append(Paragraph(item, styles["Body10"]))
        elems.append(Spacer(1, 4))
    elems.append(PageBreak())

    # ---------------- EXECUTIVE SUMMARY ----------------
    elems += _section_header("1. Executive Summary", styles)
    kpi_rows = [
        ["Revenue (FY26)", _fmt(f.get("revenue")), f"YoY Growth: {_fmt(r.get('revenue_growth_pct'), 2, '%')}"],
        ["EBITDA (Operating)", _fmt(f.get("ebitda_operating")), f"Margin: {_fmt(r.get('ebitda_margin_pct_fy26'), 2, '%')}"],
        ["PAT (Total)", _fmt(f.get("pat_total")), f"Net Margin: {_fmt(r.get('net_profit_margin_pct_fy26'), 2, '%')}"],
        ["Total Assets", _fmt(f.get("total_assets")), f"Total Equity: {_fmt(f.get('total_equity'))}"],
        ["Current Ratio", _fmt(r.get("current_ratio_fy26"), 2, "x"), f"Debt-Equity: {_fmt(r.get('debt_equity_ratio_fy26'), 2, 'x')}"],
    ]
    elems.append(_kv_table(kpi_rows, [5 * cm, 5 * cm, 7 * cm], header=["Metric", "Value", "Context"]))
    elems.append(Spacer(1, 14))
    if risk_report and risk_report.business_implications:
        elems.append(Paragraph("Risk &amp; Auditor Highlights", styles["SubHeading"]))
        for line in risk_report.business_implications[:8]:
            elems.append(Paragraph(f"•  {line}", styles["BulletBody"]))
    elems.append(PageBreak())

    # ---------------- FINANCIAL STATEMENTS ----------------
    elems += _section_header("2. Financial Statements — Standalone Summary", styles)
    elems.append(Paragraph("Balance Sheet", styles["SubHeading"]))
    bs_rows = [
        ["Total Assets", _fmt(f.get("total_assets")), _fmt(f.get("total_assets_prev"))],
        ["Non-Current Assets", _fmt(f.get("non_current_assets")), _fmt(f.get("non_current_assets_prev"))],
        ["Current Assets", _fmt(f.get("current_assets")), _fmt(f.get("current_assets_prev"))],
        ["Total Equity", _fmt(f.get("total_equity")), _fmt(f.get("total_equity_prev"))],
        ["Non-Current Liabilities", _fmt(f.get("non_current_liabilities")), _fmt(f.get("non_current_liabilities_prev"))],
        ["Current Liabilities", _fmt(f.get("current_liabilities")), _fmt(f.get("current_liabilities_prev"))],
    ]
    elems.append(_kv_table(bs_rows, [7 * cm, 5 * cm, 5 * cm], header=["Balance Sheet", "FY26", "FY25"]))
    elems.append(Spacer(1, 12))
    elems.append(Paragraph("Profit &amp; Loss", styles["SubHeading"]))
    pl_rows = [
        ["Revenue", _fmt(f.get("revenue")), _fmt(f.get("revenue_prev"))],
        ["COGS", _fmt(f.get("cogs")), _fmt(f.get("cogs_prev"))],
        ["EBITDA (Operating)", _fmt(f.get("ebitda_operating")), _fmt(f.get("ebitda_operating_prev"))],
        ["PBT (Continuing)", _fmt(f.get("pbt_continuing")), _fmt(f.get("pbt_continuing_prev"))],
        ["PAT (Total)", _fmt(f.get("pat_total")), _fmt(f.get("pat_total_prev"))],
    ]
    elems.append(_kv_table(pl_rows, [7 * cm, 5 * cm, 5 * cm], header=["Profit & Loss", "FY26", "FY25"]))
    elems.append(Spacer(1, 12))
    elems.append(Paragraph("Cash Flow", styles["SubHeading"]))
    cf_rows = [
        ["Operating CF", _fmt(f.get("operating_cash_flow")), _fmt(f.get("operating_cash_flow_prev"))],
        ["Investing CF", _fmt(f.get("investing_cash_flow")), _fmt(f.get("investing_cash_flow_prev"))],
        ["Financing CF", _fmt(f.get("financing_cash_flow")), _fmt(f.get("financing_cash_flow_prev"))],
        ["Free Cash Flow", _fmt(f.get("free_cash_flow")), _fmt(f.get("free_cash_flow_prev"))],
    ]
    elems.append(_kv_table(cf_rows, [7 * cm, 5 * cm, 5 * cm], header=["Cash Flow", "FY26", "FY25"]))
    elems.append(PageBreak())

    # ---------------- RATIO ANALYSIS ----------------
    elems += _section_header("3. Ratio Analysis — Standalone", styles)
    ratio_rows = [
        ["Gross Margin %", _fmt(r.get("gross_margin_pct_fy26"), 2), _fmt(r.get("gross_margin_pct_fy25"), 2)],
        ["EBITDA Margin %", _fmt(r.get("ebitda_margin_pct_fy26"), 2), _fmt(r.get("ebitda_margin_pct_fy25"), 2)],
        ["Net Profit Margin %", _fmt(r.get("net_profit_margin_pct_fy26"), 2), _fmt(r.get("net_profit_margin_pct_fy25"), 2)],
        ["ROE (Closing) %", _fmt(r.get("roe_closing_pct_fy26"), 2), _fmt(r.get("roe_closing_pct_fy25"), 2)],
        ["Current Ratio (x)", _fmt(r.get("current_ratio_fy26"), 2), _fmt(r.get("current_ratio_fy25"), 2)],
        ["Debt-Equity (x)", _fmt(r.get("debt_equity_ratio_fy26"), 2), _fmt(r.get("debt_equity_ratio_fy25"), 2)],
        ["Interest Coverage (x)", _fmt(r.get("interest_coverage_ratio_fy26"), 2), _fmt(r.get("interest_coverage_ratio_fy25"), 2)],
        ["Cash Conversion Cycle (days)", _fmt(r.get("cash_conversion_cycle_closing_fy26"), 1),
         _fmt(r.get("cash_conversion_cycle_closing_fy25"), 1)],
    ]
    elems.append(_kv_table(ratio_rows, [8 * cm, 4.5 * cm, 4.5 * cm], header=["Ratio", "FY26", "FY25"], font_size=10))
    elems.append(Spacer(1, 10))
    elems.append(Paragraph("Formulas disclosed in Module 2 workbook — no qualitative labels applied.", styles["Caption"]))
    elems.append(PageBreak())

    # ---------------- CHARTS ----------------
    elems += _section_header("4. Financial Trends &amp; Charts", styles)
    if trends and trends.get("turnover") and trends.get("pat"):
        years = trends["turnover"].years
        elems.append(_line_chart_drawing(years, {"Turnover": trends["turnover"].values, "PAT": trends["pat"].values},
                                          title="Turnover & PAT Trend"))
    else:
        elems.append(_bar_chart_drawing(["FY25", "FY26"], {"Revenue": [f.get("revenue_prev"), f.get("revenue")]},
                                         title="Revenue (2-Year)"))
    elems.append(Spacer(1, 10))
    elems.append(_bar_chart_drawing(["FY25", "FY26"],
                                     {"Operating CF": [f.get("operating_cash_flow_prev"), f.get("operating_cash_flow")],
                                      "Investing CF": [f.get("investing_cash_flow_prev"), f.get("investing_cash_flow")],
                                      "Financing CF": [f.get("financing_cash_flow_prev"), f.get("financing_cash_flow")]},
                                     title="Cash Flow by Activity"))
    elems.append(Spacer(1, 10))
    elems.append(_bar_chart_drawing(
        ["Non-Curr. Assets", "Curr. Assets", "Equity", "Non-Curr. Liab.", "Curr. Liab."],
        {"FY26": [f.get("non_current_assets"), f.get("current_assets"), f.get("total_equity"),
                  f.get("non_current_liabilities"), f.get("current_liabilities")]},
        title="Assets vs Liabilities (FY26)"))
    elems.append(PageBreak())

    # ---------------- RISK REGISTER ----------------
    elems += _section_header("5. Risk Register", styles)
    if risk_report and risk_report.risk_register_found:
        risk_rows = [[e.title, e.category_normalized, e.level_of_change, str(len(e.capitals_impacted))]
                     for e in risk_report.risk_entries]
        elems.append(_kv_table(risk_rows, [5.5 * cm, 5 * cm, 3 * cm, 3.5 * cm],
                                header=["Risk", "Category", "Trend", "Capitals Impacted"], font_size=8,
                                wrap_cols={0, 1}))
        elems.append(Spacer(1, 8))
        elems.append(Paragraph("Trend = company-disclosed Level of Change (Likelihood proxy). "
                                "Capitals Impacted = Impact proxy. Neither company independently publishes a "
                                "probability or severity rating.", styles["Caption"]))
    else:
        elems.append(Paragraph("No structured risk register was found in this filing. A script cannot reliably "
                                "paraphrase free-form risk narrative without a structured template to parse — "
                                "see Module 5 workbook for details.", styles["Body10"]))
    elems.append(PageBreak())

    # ---------------- AUDITOR FINDINGS ----------------
    elems += _section_header("6. Auditor Findings", styles)
    if risk_report and risk_report.auditor_findings:
        af_rows = []
        for af in risk_report.auditor_findings:
            af_rows.append([af.basis, af.opinion_type, str(af.kam_count),
                             "Yes" if af.eom_present else "No",
                             "Clean" if af.icfr_opinion_clean else ("Flagged" if af.icfr_opinion_clean is False else "n/d")])
        elems.append(_kv_table(af_rows, [3 * cm, 5 * cm, 2.5 * cm, 2.5 * cm, 3 * cm],
                                header=["Basis", "Opinion", "KAM Count", "EOM", "ICFR"], font_size=9,
                                wrap_cols={1}))
        elems.append(Spacer(1, 10))
        for af in risk_report.auditor_findings:
            if af.kam_titles:
                elems.append(Paragraph(f"<b>{af.basis} Key Audit Matters:</b>", styles["Body10"]))
                for t in af.kam_titles:
                    elems.append(Paragraph(f"•  {t}", styles["BulletBody"]))
                elems.append(Spacer(1, 6))
    else:
        elems.append(Paragraph("No Independent Auditor's Report was located in this filing.", styles["Body10"]))
    elems.append(PageBreak())

    # ---------------- RED FLAGS ----------------
    elems += _section_header("7. Red Flag Detection — Standalone", styles)
    if rf_sa:
        rows = [[fl.check, fl.severity, str(fl.metric_value)] for fl in rf_sa.flags]
        t = _kv_table(rows, [9 * cm, 3 * cm, 5 * cm], header=["Check", "Severity", "Value"], font_size=9,
                      wrap_cols={0})
        style_add = []
        for i, fl in enumerate(rf_sa.flags, start=1):
            style_add.append(("BACKGROUND", (1, i), (1, i), SEV_COLORS.get(fl.severity, WHITE)))
        t.setStyle(TableStyle(style_add))
        elems.append(t)
        elems.append(Spacer(1, 8))
        elems.append(Paragraph("9 quantitative checks — Auditor/Related-Party/Governance covered separately (Module 5).",
                                styles["Caption"]))
    else:
        elems.append(Paragraph("No red flag data available.", styles["Body10"]))
    elems.append(PageBreak())

    # ---------------- RECOMMENDATIONS ----------------
    elems += _section_header("8. Recommendations", styles)
    elems.append(Paragraph("Templated, tied directly to a specific finding above — not a generated narrative.",
                            styles["Caption"]))
    elems.append(Spacer(1, 8))
    recs = []
    if rf_sa:
        for fl in rf_sa.flags:
            if fl.severity != "NONE":
                recs.append(f"[{fl.severity}] Review '{fl.check}' — {fl.description}")
    if risk_report:
        for af in risk_report.auditor_findings:
            if af.opinion_type and "Unmodified" not in af.opinion_type:
                recs.append(f"[{af.basis}] Auditor's opinion is '{af.opinion_type}' — review the qualification "
                            f"in full before relying on the financial statements.")
            if af.kam_count:
                recs.append(f"[{af.basis}] {af.kam_count} Key Audit Matter(s) identified — discuss with the "
                            f"Audit Committee: {', '.join(af.kam_titles[:3])}.")
        increased = [rr.title for rr in risk_report.risk_entries if rr.level_of_change.lower() == "increased"]
        if increased:
            recs.append("Monitor risks flagged by the company as INCREASING: " + "; ".join(increased) + ".")
    if not recs:
        recs.append("No red flags, audit qualifications, or increasing risk trends were identified from the "
                     "checks this tool performs — continue routine monitoring.")
    for line in recs[:12]:
        elems.append(Paragraph(f"•  {line}", styles["BulletBody"]))
    elems.append(PageBreak())

    # ---------------- APPENDIX ----------------
    elems += _section_header("9. Appendix — Scope, Methodology &amp; Disclaimer", styles)
    appendix_lines = [
        "<b>Scope:</b> built for a general-purpose, non-financial-services company reporting under Ind-AS "
        "Schedule III (Division I). NOT applicable to banks, NBFCs, insurance, or other regulated "
        "financial-services entities (different Schedule III division and statement format).",
        "All figures are extracted mechanically from the uploaded PDF and independently tie-out validated "
        "(see Module 1 Validation sheet) — this does not constitute financial, investment, tax, legal, or "
        "audit advice, nor a substitute for professional judgement or statutory audit.",
        "Red Flag Detection covers 9 quantitative checks only — auditor qualifications, contingent "
        "liabilities, related-party transactions, and corporate governance are NOT assessed by that module "
        "(see Module 5 for auditor/risk findings instead).",
        "Risk Likelihood/Impact fields are company-disclosed proxies (Level of Change / Capitals Impacted) "
        "— neither company independently publishes a probability or severity rating.",
        "'Debt' in leverage ratios uses Lease Liabilities where no separate Borrowings line exists on the "
        "Balance Sheet — see Module 2 Formula Disclosures.",
        "Always verify key figures against the original Annual Report before relying on them for any decision.",
    ]
    for line in appendix_lines:
        elems.append(Paragraph(f"•  {line}", ParagraphStyle("AppBullet", parent=styles["BulletBody"], textColor=GREY)))
        elems.append(Spacer(1, 4))

    doc.build(elems)
    return output_path

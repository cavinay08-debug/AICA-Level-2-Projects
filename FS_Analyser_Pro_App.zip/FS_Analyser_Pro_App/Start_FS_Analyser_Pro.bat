@echo off
title FS Analyser Pro
cd /d "%~dp0"

echo ============================================
echo   FS Analyser Pro - Starting Up
echo ============================================
echo.

where python >nul 2>nul
if %errorlevel% neq 0 (
    echo ERROR: Python was not found on this computer.
    echo Please install Python from https://www.python.org/downloads/
    echo IMPORTANT: during install, tick "Add Python to PATH".
    pause
    exit /b 1
)

echo Checking / installing requirements (only installs what's missing)...
python -m pip install -r requirements.txt --quiet
if %errorlevel% neq 0 (
    echo.
    echo WARNING: There was a problem installing requirements.
    echo Try running this manually: pip install -r requirements.txt
    pause
)

echo.
echo Launching FS Analyser Pro in your browser...
echo (Close this black window to stop the app)
echo.
python -m streamlit run app.py

pause

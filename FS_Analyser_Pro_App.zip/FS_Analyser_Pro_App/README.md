# FS Analyser Pro — App Edition

A browser-based app wrapping Modules 1-4 (PDF Extraction, Ratio Analysis,
Long-Term Trend, Red Flag Detection) behind one interface: upload an
Annual Report PDF, click a button per section, download each report, or
download everything as one ZIP.

---

## 1. Setup (one-time, on your own machine)

**Easiest option — double-click launcher:**
- **Windows**: double-click `Start_FS_Analyser_Pro.bat`
- **Mac**: double-click `Start_FS_Analyser_Pro.command` (first time only, macOS may
  block it — right-click the file → Open, then confirm "Open" on the security
  prompt. After that, double-clicking works normally.)

These check for Python, install requirements automatically, and launch the
app in your browser — no command line needed after this point.

**Manual option (if the launcher doesn't work, or on Linux):**

You need Python 3.9+ installed. Then, in a terminal, from this folder:

```bash
pip install -r requirements.txt
```

That's it — no other accounts, API keys, or paid services needed. Everything
runs locally on your machine; no data leaves your computer.

## 2. Run the app

If you used the double-click launcher above, the app is already running —
skip to Section 3.

Otherwise, from a terminal in this folder:

```bash
streamlit run app.py
```

Your browser should open automatically to `http://localhost:8501`. If it
doesn't, open that address manually. To stop the app, go back to the
terminal (or the black launcher window) and press `Ctrl+C`, or just close
that window.

### Important: don't double-click app.py directly
`app.py` is a Python script, not a program your operating system knows how
to run on its own — double-clicking it will do nothing or flash and close.
Always use the launcher file, or the `streamlit run app.py` command, never
`app.py` itself.

### Important: confirm you're running the current build
The app displays a small line under the title: **"Build 2026-08-06.8"**. If
you update the app files later and don't see a new build number after
restarting, you're running a stale copy — check you extracted the new ZIP
over (or instead of) the old folder, and that any old `streamlit run`
process was fully stopped (`Ctrl+C`) before starting the new one.

## 3. Using the app

1. **Step 1 — Upload Annual Report**: click "Browse files" and select the
   company's Annual Report PDF. Optionally type the company name (used on
   report cover sheets). The app does **four** passes over the PDF here,
   each with its own progress spinner:
   - Extract the financial statements (Balance Sheet, P&L, Cash Flow)
   - Look for a company-disclosed multi-year "Long-term Track Record" table
   - Compute ratios and red-flag checks (fast — uses data already extracted)
   - Scan for the Risk Register and Independent Auditor's Report(s) —
     this pass alone can take a minute or more on a large filing, since it
     has to scan hundreds of pages looking for report titles

   For a large filing (400+ pages) the combined Step 1 can take **2-3
   minutes**. Watch for the four spinner messages in sequence rather than
   assuming the app has frozen.

   Once done, you'll see:
   - A tie-out validation result (e.g. "26 of 26 checks passed")
   - "Statements found: ..." — confirms Module 1 worked
   - "Mapped bases available for ratio analysis: ..." — if this says NONE,
     several buttons below will be disabled; see Section 4
   - "Long-term Track Record table found: ..." — tells you up front whether
     the Trend sheet will have data
   - "Risk & Auditor scan: ..." — tells you how many risks and Auditor's
     Reports were found before you generate Module 5

2. **Step 2 — Generate Section Reports**: five buttons, one per module —
   - **Module 1 — Financial Statement Extraction** → Standalone &
     Consolidated Balance Sheet, P&L, Cash Flow Statement, with formulas
     and tie-out validation.
   - **Module 2 — Ratio Analysis** → Growth, margin, return, liquidity,
     leverage, efficiency and per-share ratios, formulas disclosed.
   - **Module 3 — Long-Term Trend** → the company's own disclosed
     multi-year track record table (CAGR, YoY growth, direction) — only
     enabled if such a table was found in Step 1.
   - **Module 4 — Red Flag Detection** → 9 quantitative rule-based checks.
   - **Module 5 — Risk & Auditor Analysis** → categorised risk register
     (where the filing discloses one in a structured format), plus
     auditor opinion, Key Audit Matters, Emphasis of Matter, and Internal
     Financial Controls findings.

   Each is its own separate workbook. Each button becomes a download link
   once clicked; generate any combination, in any order, and regenerate at
   any time.

3. **Step 3 — Interactive Dashboard**: renders live from data already
   computed in Step 1 — no extra PDF scan, no button needed. Includes KPI
   cards, a Revenue/EBITDA/PAT trend chart, margin analysis, cash flow,
   assets vs liabilities, a debt/capex trend, ratio gauges, a risk
   heatmap (Impact = Capitals Impacted, Trend = company-disclosed Level of
   Change — see the chart's own axis labels for the caveat), a year
   comparison chart, and a colour-coded financial scorecard.

4. **Step 4 — Presentation & PDF Report**: two buttons generate a full
   board-ready deck / document from the same validated data as Step 2 —
   Title, TOC, Executive Summary, Financial Statements, Ratio Analysis,
   Financial Trends (charts), Risk Register, Auditor Findings, Red Flag
   Detection, Recommendations, and an Appendix with the scope note and
   disclaimer. "Recommendations" are templated statements tied directly
   to a specific figure or finding above them — not AI-generated prose.

5. **Step 5 — Consolidated Report**: click "Build Consolidated ZIP" to
   bundle everything generated in Steps 2 and 4 into a single ZIP with a
   README listing its contents. This only includes what you've already
   generated — generate the sections you want first.

## 4. If something goes wrong

- **A button looks clickable (navy blue) but clicking it does nothing at
  all** — buttons are now styled visibly **grey** with a "not-allowed"
  cursor when disabled — if a button looks navy blue and clickable but
  does nothing, you are running an old build (check the build-number line
  under the title, Section 2).
- **"Mapped bases available for ratio analysis: NONE"** — Module 1 located
  statement pages but couldn't map any line items to standard fields. This
  usually means the report uses different Schedule III wording than
  `fs_extractor/taxonomy.py` expects. Send the PDF (or company name/FY) so
  the label matching can be extended.
- **"Could not locate any financial statements in this PDF"** — the
  extraction engine looks for standard Ind-AS Schedule III statement
  titles ("Standalone Balance Sheet", etc.). A report using materially
  different titling may need a small addition to `fs_extractor/locator.py`
  (see the code comments there).
- **Some tie-out checks failed** — the app will still let you generate
  reports, but flags this so you know to treat the ratios with caution.
  Check the "Validation & Tie-Outs" or "Not Assessed" areas of the
  generated workbooks for specifics.
- **Report generation now fails with a red error box** — this is
  intentional (added in this build): any real failure now surfaces a full
  error message and traceback in the app instead of failing silently.
  Copy the error text if you need help diagnosing it further.
- **App won't start / import errors** — confirm you ran
  `pip install -r requirements.txt` in the same Python environment you're
  using to run `streamlit run app.py`.

## 5. Folder structure

```
.
├── Start_FS_Analyser_Pro.bat       <- Windows: double-click this
├── Start_FS_Analyser_Pro.command   <- Mac: double-click this
├── app.py                           <- do NOT double-click; run via the launcher
│                                        above, or `streamlit run app.py`
├── requirements.txt
└── fs_extractor/
    ├── __init__.py
    ├── models.py               (data classes)
    ├── locator.py               (finds statement page ranges)
    ├── row_reconstructor.py     (coordinate-based row parsing engine)
    ├── taxonomy.py               (standard field mapping + formulas)
    ├── validators.py             (tie-out checks)
    ├── extractor.py               (Module 1 orchestrator)
    ├── export.py                   (Module 1 Excel writer)
    ├── ratios.py                    (Module 2 ratio engine)
    ├── trend_extractor.py            (Module 3 — finds disclosed track record)
    ├── trends.py                      (Module 3 — CAGR/YoY/direction)
    ├── red_flags.py                    (Module 4 rule-based checks)
    ├── export_ratios.py                 (Modules 2-4 Excel writers)
    ├── risk_auditor.py                    (Module 5 — risk & auditor extraction)
    ├── export_risk_auditor.py               (Module 5 Excel writer)
    ├── dashboard.py                           (Plotly figure builders — Step 3)
    ├── pptx_report.py                          (PowerPoint report generator)
    └── pdf_report.py                            (PDF report generator)
```

## 6. Known limitations (carried over from the underlying modules)

**Tested and validated against two companies with materially different
report formats:** Hindustan Unilever Limited (26/26 tie-out checks pass)
and Nestlé India Limited (22/22 tie-out checks pass). Beyond unit-level
checks, every button in this app (all 5 module reports, the PowerPoint
report, the PDF report, and the Consolidated ZIP) was clicked through the
actual Streamlit runtime via automated testing for both companies, plus
the fresh/before-upload state — not just tested as isolated Python
functions. The engine
generalises across real differences observed between them — no
"Standalone"/"Consolidated" prefix on some titles, repeated headers on
continuation pages, a "Notes" vs "Note" column header, a different
rupee-symbol font substitution glyph, no continuing/discontinued
operations split, different subtotal phrasing ("Total Non-Current
Assets" vs "Total - Non-current assets"), different Cash Flow subtotal
wording with no "[A]/[B]/[C]" suffix, a differently-titled and
differently-formatted multi-year highlights table ("10-Year Financial
Highlights" with a mix of fiscal-year and calendar-year column labels,
vs "Long-term Track Record"), and an "Exceptional items" sign convention
that ADDS for one company and SUBTRACTS for the other. None of this is
guaranteed to cover a third company's filing perfectly — if you try one
that doesn't work, the diagnostic captions in Step 1 (Statements found /
Mapped bases / Long-term Track Record table) will tell you exactly which
stage failed.

- The statement locator relies on standard Schedule III title wording —
  tested against Hindustan Unilever Limited's and Nestlé India Limited's
  FY26 filings (see the generalisation notes above). A third company
  using a materially different convention may still need a small
  addition to `fs_extractor/locator.py` or `fs_extractor/taxonomy.py`.
- Growth ratios and average-balance return/efficiency ratios need a
  comparative year beyond what a single PDF provides for the current
  year's own growth calc — flagged as "n/a (needs 3rd year)" in the
  workbook rather than estimated.
- Red Flag Detection covers 9 quantitative checks only — Auditor
  Qualifications, Contingent Liabilities, Related Party concerns, Going
  Concern and Corporate Governance checks are explicitly listed as "Not
  Assessed" in that workbook, not silently passed.
- "Debt" in leverage ratios uses Lease Liabilities where no separate
  Borrowings line exists on the Balance Sheet — this assumption is
  disclosed in the workbook itself and may not fit every company.
- **Module 5 (Risk & Auditor Analysis)** only parses a risk register when
  the filing uses a structured template with explicit "Category of Risk:"
  / "Level of Change:" tags (observed: HUL). Where a company discusses
  risk narratively instead (observed: Nestlé), this is reported honestly
  as "no structured risk register found" rather than forcing a low-quality
  parse of free-form text — the same reasoning that excluded MD&A
  summarisation. "Likelihood" and "Impact" in the Risk Register are
  company-disclosed proxies (Level of Change / Capitals Impacted count),
  not an independently-derived probability or severity rating. Auditor
  opinion type, Key Audit Matter titles, Emphasis of Matter presence, and
  ICFR status are identified via pattern-matching against standard
  SA-700-series boilerplate — always verify against the source pages
  cited, this is not a substantive audit review.
- The **Dashboard** (Step 3) and **PowerPoint/PDF reports** (Step 4) only
  visualise/restate data already computed by Modules 1-5 — they do not
  introduce any new figures. "Recommendations" in the PPTX/PDF are
  templated statements tied directly to a specific red flag, KAM, or
  risk trend already shown elsewhere in the same report — not
  AI-generated prose.
- This app does not include an MD&A summarisation feature: a genuinely
  deterministic (no-LLM) script can reliably extract numbers from a PDF
  because numbers have fixed formats, but it cannot reliably read and
  faithfully condense free-form narrative text — that requires actual
  language understanding. Every mechanical alternative either reproduces
  verbatim chunks of copyrighted text or stitches together an
  un-paraphrased outline that isn't really a summary. This was excluded
  as a genuine capability limit, not a scope choice.

"""
green_capstone_tool.py
Green Building & Green Finance Risk Analyser -- Analytical Engine

AI Tools Capstone Project
Green Sustainable Financing for a Rs. 1,000 Crore Green Real Estate Project in India
Prepared by: Surinder Kumar Kalra, FCA

Purpose
-------
This module is the deterministic quantitative engine described in the Project
Summary Document, Section 2 and Section 3 ("Tool Files"). It performs every
numerical calculation -- Product Matrix scoring, Sensitivity Analysis,
Monte Carlo simulation, Green Value-at-Risk, and financing-plan sizing.

Nothing in this file is AI-generated arithmetic. All figures are computed
deterministically from the input parameters. The Gemini API (see
prompts/system_prompt.txt) is only ever handed the *already-computed*
numbers and asked to narrate them -- it is never asked to calculate anything.

Usage
-----
    python green_capstone_tool.py --input examples/sample_input.json --outdir outputs/

Outputs written to --outdir:
    product_matrix.csv
    sensitivity_analysis.csv
    monte_carlo_results.json
    financing_plan.csv
    ai_narrative.txt   (Gemini narrative if GEMINI_API_KEY is set, else local fallback)
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from dataclasses import dataclass, field
from typing import Any

import numpy as np
import pandas as pd


# --------------------------------------------------------------------------
# 1. Default project parameters (Rs. 1,000 crore approved structure)
# --------------------------------------------------------------------------

DEFAULT_INPUT: dict[str, Any] = {
    "project_name": "Green Harmony Smart Eco Township",
    "location": "Gurugram, Haryana",
    "project_cost_cr": 1000.0,
    "expected_sales_value_cr": 1650.0,
    "funding_sources": [
        {"name": "Home Buyers' Instalments", "amount_cr": 400.0, "cost_of_capital_pct": 0.0},
        {"name": "Green Private Equity (PE) Fund", "amount_cr": 230.0, "cost_of_capital_pct": 14.0},
        {"name": "Green Construction Loan", "amount_cr": 150.0, "cost_of_capital_pct": 8.5},
        {"name": "Promoters' Equity", "amount_cr": 120.0, "cost_of_capital_pct": 16.0},
        {"name": "Green Bonds", "amount_cr": 100.0, "cost_of_capital_pct": 7.3},
    ],
    "contingent_sources": [
        {"name": "Carbon Finance (GoI CCTS Offset Mechanism)", "amount_cr": 20.0,
         "risk_weighted_cost_pct": 20.0, "status": "Contingent - excluded from committed total"},
    ],
    "monte_carlo": {
        "iterations": 10000,
        "cost_escalation_mean_pct": 8.0,
        "cost_escalation_std_pct": 6.0,
        "sales_realisation_mean_pct": 96.0,
        "sales_realisation_std_pct": 6.0,
        "interest_rate_drag_mean_pct": 1.5,
        "interest_rate_drag_std_pct": 1.0,
        "climate_event_probability": 0.05,
        "climate_event_cost_impact_cr_mean": 60.0,
        "climate_event_cost_impact_cr_std": 20.0,
        "confidence_level_pct": 95,
        "random_seed": 42,
    },
    "sensitivity_scenarios": [
        {"name": "Base Case", "cost_escalation_pct": 0, "sales_realisation_pct": 100},
        {"name": "Mild Stress", "cost_escalation_pct": 10, "sales_realisation_pct": 95},
        {"name": "Moderate Stress", "cost_escalation_pct": 20, "sales_realisation_pct": 90},
        {"name": "Severe Stress", "cost_escalation_pct": 30, "sales_realisation_pct": 80},
    ],
    "green_finance_products": [
        {"name": "Green Term Loan", "liquidity": "Medium", "stability": "High",
         "esg": "High", "climate_resilience": "Medium", "risk": "Low"},
        {"name": "Green Bonds (Use-of-Proceeds)", "liquidity": "Low", "stability": "High",
         "esg": "High", "climate_resilience": "Medium", "risk": "Low"},
        {"name": "Green Private Equity", "liquidity": "Low", "stability": "Medium",
         "esg": "High", "climate_resilience": "Medium", "risk": "Medium"},
        {"name": "Sustainability-Linked Loan (SLL)", "liquidity": "Medium", "stability": "Medium",
         "esg": "Medium", "climate_resilience": "Medium", "risk": "Medium"},
        {"name": "Home Buyers' Instalments", "liquidity": "High", "stability": "Medium",
         "esg": "Low", "climate_resilience": "Low", "risk": "Medium"},
        {"name": "Blended Finance (DFI-backed)", "liquidity": "Low", "stability": "High",
         "esg": "High", "climate_resilience": "High", "risk": "Low"},
        {"name": "Promoters' Equity", "liquidity": "Low", "stability": "High",
         "esg": "Low", "climate_resilience": "Low", "risk": "Low"},
    ],
}

_RATING_SCORE = {"Low": 1, "Medium": 2, "High": 3}


# --------------------------------------------------------------------------
# 2. Financing Plan and Green WACC
# --------------------------------------------------------------------------

def build_financing_plan(inputs: dict[str, Any]) -> pd.DataFrame:
    sources = inputs["funding_sources"]
    total = sum(s["amount_cr"] for s in sources)
    project_cost = inputs["project_cost_cr"]

    if abs(total - project_cost) > 0.01:
        raise ValueError(
            f"Validation failed: funding sources sum to Rs.{total:.2f} cr, "
            f"which does not equal the stated project cost of Rs.{project_cost:.2f} cr. "
            f"Per the Master Prompt-1 validation requirement, this must be corrected "
            f"before any downstream figure is trusted."
        )

    rows = []
    wacc = 0.0
    for s in sources:
        pct_of_total = s["amount_cr"] / total * 100.0
        weighted_contribution = pct_of_total / 100.0 * s["cost_of_capital_pct"]
        wacc += weighted_contribution
        rows.append({
            "Funding Source": s["name"],
            "Amount (Rs. cr.)": round(s["amount_cr"], 2),
            "% of Total": round(pct_of_total, 2),
            "Cost of Capital (%)": s["cost_of_capital_pct"],
            "Weighted Contribution (%)": round(weighted_contribution, 2),
        })
    rows.append({
        "Funding Source": "TOTAL / Green WACC",
        "Amount (Rs. cr.)": round(total, 2),
        "% of Total": 100.0,
        "Cost of Capital (%)": "",
        "Weighted Contribution (%)": round(wacc, 2),
    })
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------
# 3. Green Financing Product Matrix
# --------------------------------------------------------------------------

def build_product_matrix(inputs: dict[str, Any]) -> pd.DataFrame:
    rows = []
    for p in inputs["green_finance_products"]:
        composite = np.mean([
            _RATING_SCORE[p["liquidity"]],
            _RATING_SCORE[p["stability"]],
            _RATING_SCORE[p["esg"]],
            _RATING_SCORE[p["climate_resilience"]],
            4 - _RATING_SCORE[p["risk"]],  # invert risk: lower risk = higher score
        ])
        rows.append({
            "Green Finance Product": p["name"],
            "Liquidity Rating": p["liquidity"],
            "Funding Stability Rating": p["stability"],
            "ESG Rating": p["esg"],
            "Climate Resilience Rating": p["climate_resilience"],
            "Financial Risk Rating": p["risk"],
            "Composite Score (1-3)": round(composite, 2),
        })
    df = pd.DataFrame(rows).sort_values("Composite Score (1-3)", ascending=False).reset_index(drop=True)
    df.insert(0, "Overall Ranking", range(1, len(df) + 1))
    return df


# --------------------------------------------------------------------------
# 4. Sensitivity Analysis (deterministic four-point stress grid)
# --------------------------------------------------------------------------

def build_sensitivity_analysis(inputs: dict[str, Any]) -> pd.DataFrame:
    project_cost = inputs["project_cost_cr"]
    base_sales = inputs["expected_sales_value_cr"]
    rows = []
    for sc in inputs["sensitivity_scenarios"]:
        cost = project_cost * (1 + sc["cost_escalation_pct"] / 100.0)
        revenue = base_sales * (sc["sales_realisation_pct"] / 100.0)
        margin = revenue - cost
        return_pct = margin / cost * 100.0
        rows.append({
            "Scenario": sc["name"],
            "Cost Esc. %": sc["cost_escalation_pct"],
            "Sales Realisation %": sc["sales_realisation_pct"],
            "Cost (Rs. cr.)": round(cost, 1),
            "Revenue (Rs. cr.)": round(revenue, 1),
            "Margin (Rs. cr.)": round(margin, 1),
            "Return %": round(return_pct, 1),
        })
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------
# 5. Monte Carlo Simulation and Green VaR
# --------------------------------------------------------------------------

def run_monte_carlo(inputs: dict[str, Any]) -> dict[str, Any]:
    mc = inputs["monte_carlo"]
    rng = np.random.default_rng(mc.get("random_seed", 42))
    n = int(mc["iterations"])

    project_cost = inputs["project_cost_cr"]
    base_sales = inputs["expected_sales_value_cr"]

    cost_escalation = rng.normal(mc["cost_escalation_mean_pct"], mc["cost_escalation_std_pct"], n)
    sales_realisation = rng.normal(mc["sales_realisation_mean_pct"], mc["sales_realisation_std_pct"], n)
    interest_drag = rng.normal(mc["interest_rate_drag_mean_pct"], mc["interest_rate_drag_std_pct"], n)

    climate_event = rng.random(n) < mc["climate_event_probability"]
    climate_cost = np.where(
        climate_event,
        rng.normal(mc["climate_event_cost_impact_cr_mean"], mc["climate_event_cost_impact_cr_std"], n),
        0.0,
    )
    climate_cost = np.clip(climate_cost, 0, None)

    cost_escalation = np.clip(cost_escalation, -100, None)
    sales_realisation = np.clip(sales_realisation, 0, None)

    simulated_cost = project_cost * (1 + cost_escalation / 100.0) + climate_cost
    simulated_revenue = base_sales * (sales_realisation / 100.0)
    interest_cost_drag_cr = project_cost * (interest_drag / 100.0)

    margin = simulated_revenue - simulated_cost - interest_cost_drag_cr
    return_pct = margin / simulated_cost * 100.0

    conf = mc["confidence_level_pct"]
    lower_pctl = 100 - conf
    expected_margin = float(np.mean(margin))
    pctl_low = float(np.percentile(margin, lower_pctl))
    pctl_high = float(np.percentile(margin, conf))
    green_var = expected_margin - pctl_low
    green_var_ratio_pct = green_var / project_cost * 100.0
    prob_loss_pct = float(np.mean(margin < 0) * 100.0)

    return {
        "iterations": n,
        "confidence_level_pct": conf,
        "expected_net_margin_cr": round(expected_margin, 1),
        "expected_return_pct": round(float(np.mean(return_pct)), 2),
        f"p{lower_pctl}_margin_cr": round(pctl_low, 1),
        f"p{lower_pctl}_return_pct": round(float(np.percentile(return_pct, lower_pctl)), 2),
        f"p{conf}_margin_cr": round(pctl_high, 1),
        "probability_loss_making_pct": round(prob_loss_pct, 2),
        "green_var_cr": round(green_var, 1),
        "green_var_ratio_pct": round(green_var_ratio_pct, 2),
        "climate_event_frequency_pct": round(float(np.mean(climate_event) * 100), 2),
        "notes": (
            "Green VaR is the gap between expected margin and the margin at the "
            f"{lower_pctl}th percentile (i.e. a 1-in-{int(100/lower_pctl)} downside case), "
            "not the worst possible outcome. Computed on the approved Rs.1,000 crore "
            "structure (Section 4.1 of the Project Summary)."
        ),
    }


# --------------------------------------------------------------------------
# 5A. Plain-Language Explanatory Notes (Green WACC, Sensitivity, Green VaR)
# --------------------------------------------------------------------------
#
# These functions add explanatory paragraphs -- distinct from the AI
# narrative -- that a non-technical Board reader can use to understand what
# each output actually means. They are built deterministically from the
# already-computed figures (same discipline as the rest of this file: no
# invented numbers), and are written directly into each run's output so the
# explanation travels with the numbers, in the GUI tabs and in the CLI run.

def explain_green_wacc(financing_plan: pd.DataFrame, wacc: float) -> str:
    """One paragraph explaining what Green WACC is and how this run's figure
    was built, referencing the actual weighted contributions in this run."""
    contributors = financing_plan[financing_plan["Funding Source"] != "TOTAL / Green WACC"]
    cheapest = contributors.loc[contributors["Cost of Capital (%)"].idxmin()]
    costliest = contributors.loc[contributors["Cost of Capital (%)"].idxmax()]
    return (
        f"Green WACC (Green Weighted Average Cost of Capital) is the blended cost of every "
        f"funding source in the plan, each weighted by its share of the total. It answers a "
        f"single question: 'across everything financing this project, what does each rupee of "
        f"capital cost on average?' In this run it is {wacc:.2f}%, built from {len(contributors)} "
        f"sources ranging from {cheapest['Funding Source']} at {cheapest['Cost of Capital (%)']}% "
        f"(cheapest) to {costliest['Funding Source']} at {costliest['Cost of Capital (%)']}% "
        f"(costliest). A lower Green WACC is not automatically better -- shifting the mix toward "
        f"cheaper sources (e.g. more Home Buyers' Instalments, fewer high-cost instruments) reduces "
        f"the blended cost but can also reduce funding diversification and stability, which is why "
        f"Green WACC is read together with the Green VaR and Sensitivity results below, not in "
        f"isolation."
    )


def explain_sensitivity(sensitivity: pd.DataFrame) -> str:
    """One paragraph explaining the four-point stress grid using this run's own numbers."""
    base = sensitivity.iloc[0]
    worst = sensitivity.iloc[-1]
    breakeven_close = worst["Return %"] < 5
    tail = (
        f"margin turns thin (Return {worst['Return %']}%) but does not go negative"
        if not breakeven_close
        else f"margin nearly disappears (Return {worst['Return %']}%), close to breakeven"
    )
    return (
        f"Sensitivity Analysis is a deterministic 'what if' test: it re-runs the project cash flow "
        f"under {len(sensitivity)} fixed, hand-picked combinations of cost overrun and slower sales, "
        f"one variable pair at a time, so a reader can trace exactly how margin erodes as conditions "
        f"worsen. In this run, the Base Case (no stress) returns {base['Return %']}%; by the most "
        f"severe scenario tested ('{worst['Scenario']}', {worst['Cost Esc. %']}% cost escalation "
        f"combined with sales realisation of only {worst['Sales Realisation %']}%), {tail}. Unlike "
        f"Monte Carlo, Sensitivity Analysis does not assign a probability to each scenario -- it is "
        f"a quick, explainable story for a Board that wants to see the shape of the downside before "
        f"looking at the full probability distribution."
    )


def explain_green_var(mc_result: dict) -> str:
    """One paragraph explaining Green VaR, expanding on the shorter note already in mc_result."""
    conf = mc_result["confidence_level_pct"]
    lower_pctl = 100 - conf
    odds = int(round(100 / lower_pctl)) if lower_pctl else None
    return (
        f"Green Value-at-Risk (Green VaR) is not the worst amount the project could ever lose -- it "
        f"is a realistic planning cushion. Out of {mc_result['iterations']:,} simulated outcomes, the "
        f"expected margin is Rs.{mc_result['expected_net_margin_cr']} cr; Green VaR of "
        f"Rs.{mc_result['green_var_cr']} cr is the gap between that expected figure and the margin in "
        f"a bad-case run at the {lower_pctl}th percentile -- roughly a 1-in-{odds} downside year, not "
        f"a once-in-a-generation catastrophe. Expressed as a ratio to project cost, it is "
        f"{mc_result['green_var_ratio_pct']}%, which is the figure a lender or investor uses to judge "
        f"whether the proposed funding structure's headroom is adequate. The probability of the "
        f"simulation producing an outright loss in this run is {mc_result['probability_loss_making_pct']}%."
    )


def build_explanatory_notes(financing_plan: pd.DataFrame, sensitivity: pd.DataFrame,
                             mc_result: dict, wacc: float) -> str:
    return (
        "EXPLANATORY NOTES -- Green WACC, Sensitivity Analysis and Green VaR\n"
        "(Plain-language explanation of each output, generated from this run's own figures.\n"
        "Distinct from the AI Narrative below, which is the Board-summary paragraph.)\n\n"
        "1. GREEN WACC\n" + explain_green_wacc(financing_plan, wacc) + "\n\n"
        "2. SENSITIVITY ANALYSIS\n" + explain_sensitivity(sensitivity) + "\n\n"
        "3. GREEN VaR (MONTE CARLO)\n" + explain_green_var(mc_result)
    )


# --------------------------------------------------------------------------
# 6. AI Narrative (Gemini API call, with offline fallback)
# --------------------------------------------------------------------------

def _load_system_prompt() -> str:
    here = os.path.dirname(os.path.abspath(__file__))
    candidates = [
        os.path.join(here, "..", "Prompt_Files", "system_prompt.txt"),
        os.path.join(here, "prompts", "system_prompt.txt"),
    ]
    for c in candidates:
        if os.path.exists(c):
            with open(c, "r", encoding="utf-8") as f:
                return f.read()
    return (
        "You are a Green Finance narrative assistant. Interpret only the validated "
        "numbers provided. Never invent or alter a figure."
    )


def generate_ai_narrative(project_name: str, location: str, mc_result: dict, wacc: float) -> str:
    """
    Calls Gemini if GEMINI_API_KEY is set in the environment; otherwise returns a
    deterministic local fallback built only from the already-computed numbers, so
    the demo never depends on live internet access (Project Summary, Section 3).
    """
    api_key = os.environ.get("GEMINI_API_KEY", "").strip()

    payload_summary = (
        f"Project: {project_name} ({location}). "
        f"Green WACC: {wacc:.2f}%. "
        f"Monte Carlo iterations: {mc_result['iterations']}. "
        f"Expected net margin: Rs.{mc_result['expected_net_margin_cr']} cr. "
        f"Green VaR ({mc_result['confidence_level_pct']}% confidence): "
        f"Rs.{mc_result['green_var_cr']} cr ({mc_result['green_var_ratio_pct']}% of project cost). "
        f"Probability of a loss-making outcome: {mc_result['probability_loss_making_pct']}%."
    )

    if not api_key:
        return (
            f"[LOCAL FALLBACK NARRATIVE -- no GEMINI_API_KEY configured]\n\n"
            f"For {project_name} ({location}), the Monte Carlo simulation "
            f"({mc_result['iterations']:,} iterations) indicates an expected net margin of "
            f"Rs.{mc_result['expected_net_margin_cr']} crore, against a Green WACC of "
            f"{wacc:.2f}%. The {mc_result['confidence_level_pct']}% Green Value-at-Risk is "
            f"Rs.{mc_result['green_var_cr']} crore ({mc_result['green_var_ratio_pct']}% of "
            f"project cost), meaning a cushion of that order should be held against a bad-case "
            f"outcome rather than committed entirely to debt. The probability of a loss-making "
            f"result under simulated stress is {mc_result['probability_loss_making_pct']}%, which "
            f"is a manageable, not alarming, level of risk for a project of this size. This "
            f"narrative reflects only the validated Python outputs above; no figure has been "
            f"independently estimated by the narrative layer."
        )

    try:
        import google.generativeai as genai  # type: ignore

        genai.configure(api_key=api_key)
        model = genai.GenerativeModel("gemini-1.5-flash")
        system_prompt = _load_system_prompt()
        response = model.generate_content(
            f"{system_prompt}\n\nValidated data (do not alter any figure):\n{payload_summary}"
        )
        return response.text.strip()
    except Exception as exc:  # pragma: no cover - network/env dependent
        return (
            f"[GEMINI CALL FAILED -- falling back to local narrative. Reason: {exc}]\n\n"
            + generate_ai_narrative.__wrapped__(project_name, location, mc_result, wacc)  # type: ignore
            if hasattr(generate_ai_narrative, "__wrapped__")
            else f"[GEMINI CALL FAILED: {exc}] " + payload_summary
        )


# --------------------------------------------------------------------------
# 7. Orchestration
# --------------------------------------------------------------------------

def run_all(inputs: dict[str, Any], outdir: str) -> dict[str, Any]:
    os.makedirs(outdir, exist_ok=True)

    financing_plan = build_financing_plan(inputs)
    product_matrix = build_product_matrix(inputs)
    sensitivity = build_sensitivity_analysis(inputs)
    mc_result = run_monte_carlo(inputs)

    wacc_row = financing_plan[financing_plan["Funding Source"] == "TOTAL / Green WACC"]
    wacc = float(wacc_row["Weighted Contribution (%)"].iloc[0])

    narrative = generate_ai_narrative(
        inputs["project_name"], inputs["location"], mc_result, wacc
    )
    explanatory_notes = build_explanatory_notes(financing_plan, sensitivity, mc_result, wacc)

    financing_plan.to_csv(os.path.join(outdir, "financing_plan.csv"), index=False)
    product_matrix.to_csv(os.path.join(outdir, "product_matrix.csv"), index=False)
    sensitivity.to_csv(os.path.join(outdir, "sensitivity_analysis.csv"), index=False)
    with open(os.path.join(outdir, "monte_carlo_results.json"), "w", encoding="utf-8") as f:
        json.dump(mc_result, f, indent=2)
    with open(os.path.join(outdir, "ai_narrative.txt"), "w", encoding="utf-8") as f:
        f.write(narrative)
    with open(os.path.join(outdir, "explanatory_notes.txt"), "w", encoding="utf-8") as f:
        f.write(explanatory_notes)

    return {
        "financing_plan": financing_plan,
        "product_matrix": product_matrix,
        "sensitivity": sensitivity,
        "monte_carlo": mc_result,
        "green_wacc_pct": wacc,
        "ai_narrative": narrative,
        "explanatory_notes": explanatory_notes,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Green Building & Green Finance Risk Analyser engine")
    parser.add_argument("--input", type=str, default=None, help="Path to a sample_input.json file")
    parser.add_argument("--outdir", type=str, default="outputs", help="Directory to write results to")
    args = parser.parse_args()

    if args.input:
        with open(args.input, "r", encoding="utf-8") as f:
            inputs = json.load(f)
    else:
        inputs = DEFAULT_INPUT

    results = run_all(inputs, args.outdir)

    print(f"Green WACC: {results['green_wacc_pct']:.2f}%")
    print(f"Green VaR ({results['monte_carlo']['confidence_level_pct']}%): "
          f"Rs.{results['monte_carlo']['green_var_cr']} cr "
          f"({results['monte_carlo']['green_var_ratio_pct']}% of project cost)")
    print(f"Expected Net Margin: Rs.{results['monte_carlo']['expected_net_margin_cr']} cr")
    print(f"Probability of Loss: {results['monte_carlo']['probability_loss_making_pct']}%")
    print(f"\nOutputs written to: {os.path.abspath(args.outdir)}")
    print("(See explanatory_notes.txt for plain-language explanations of Green WACC, "
          "Sensitivity Analysis and Green VaR.)")


if __name__ == "__main__":
    main()

"""
app_gui.py
Green Building & Green Finance Risk Analyser -- Desktop GUI (CustomTkinter)

Prepared by: Surinder Kumar Kalra, FCA
AI Tools Capstone Project -- Rs. 1,000 Crore Green Real Estate Project

This is the user-interface layer only (Project Summary, Section 2 / Section
3, "Tool Files" table). No calculation happens in this file -- every number
shown comes from green_capstone_tool.py. This file's only job is to collect
project parameters, call the engine, and display the results.

Run:
    python app_gui.py

Package as a Windows executable:
    See Executable_File/HOW_TO_BUILD_THE_EXE.txt (PyInstaller, Day 1 tool).
"""

import json
import os
import threading
import tkinter.filedialog as filedialog
import tkinter.messagebox as messagebox

try:
    import customtkinter as ctk
except ImportError:  # pragma: no cover
    raise SystemExit(
        "customtkinter is not installed. Run: pip install customtkinter --break-system-packages"
    )

from green_capstone_tool import DEFAULT_INPUT, run_all

ctk.set_appearance_mode("light")
ctk.set_default_color_theme("green")


class GreenFinanceApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Green Building & Green Finance Risk Analyser")
        self.geometry("1000x700")

        self.inputs = json.loads(json.dumps(DEFAULT_INPUT))  # deep copy
        self.results = None

        self._build_header()
        self._build_input_panel()
        self._build_results_panel()

    # ------------------------------------------------------------------
    def _build_header(self):
        header = ctk.CTkFrame(self, fg_color="#1B4332", corner_radius=0)
        header.pack(fill="x")
        ctk.CTkLabel(
            header,
            text="Green Building & Green Finance Risk Analyser",
            font=ctk.CTkFont(size=20, weight="bold"),
            text_color="white",
        ).pack(pady=(14, 0), padx=16, anchor="w")
        ctk.CTkLabel(
            header,
            text="Rs. 1,000 Crore Green Sustainable Residential Township  |  "
                 "Green Harmony Smart Eco Township, Gurugram",
            font=ctk.CTkFont(size=12),
            text_color="#D8F3DC",
        ).pack(pady=(0, 14), padx=16, anchor="w")

    # ------------------------------------------------------------------
    def _build_input_panel(self):
        panel = ctk.CTkFrame(self)
        panel.pack(fill="x", padx=16, pady=12)

        ctk.CTkLabel(panel, text="Project Cost (Rs. cr.)").grid(row=0, column=0, padx=8, pady=8, sticky="w")
        self.project_cost_var = ctk.StringVar(value=str(self.inputs["project_cost_cr"]))
        ctk.CTkEntry(panel, textvariable=self.project_cost_var, width=120).grid(row=0, column=1, padx=8)

        ctk.CTkLabel(panel, text="Expected Sales Value (Rs. cr.)").grid(row=0, column=2, padx=8, pady=8, sticky="w")
        self.sales_var = ctk.StringVar(value=str(self.inputs["expected_sales_value_cr"]))
        ctk.CTkEntry(panel, textvariable=self.sales_var, width=120).grid(row=0, column=3, padx=8)

        ctk.CTkLabel(panel, text="Monte Carlo Iterations").grid(row=0, column=4, padx=8, pady=8, sticky="w")
        self.iter_var = ctk.StringVar(value=str(self.inputs["monte_carlo"]["iterations"]))
        ctk.CTkEntry(panel, textvariable=self.iter_var, width=100).grid(row=0, column=5, padx=8)

        btn_frame = ctk.CTkFrame(panel, fg_color="transparent")
        btn_frame.grid(row=1, column=0, columnspan=6, pady=(8, 4), sticky="w", padx=8)

        ctk.CTkButton(btn_frame, text="Load Parameters JSON...",
                      command=self.load_json).pack(side="left", padx=(0, 8))
        ctk.CTkButton(btn_frame, text="Run Risk Analysis", fg_color="#2D6A4F",
                      hover_color="#1B4332", command=self.run_analysis_threaded).pack(side="left")
        self.status_label = ctk.CTkLabel(btn_frame, text="", text_color="#40916C")
        self.status_label.pack(side="left", padx=12)

    # ------------------------------------------------------------------
    def _build_results_panel(self):
        self.tabs = ctk.CTkTabview(self)
        self.tabs.pack(fill="both", expand=True, padx=16, pady=(0, 16))
        for name in ["Financing Plan", "Product Matrix", "Sensitivity",
                     "Monte Carlo / Green VaR", "Explanatory Notes", "AI Narrative"]:
            self.tabs.add(name)
            box = ctk.CTkTextbox(self.tabs.tab(name), font=ctk.CTkFont(family="Consolas", size=12))
            box.pack(fill="both", expand=True, padx=8, pady=8)
            setattr(self, "_box_" + name.split()[0].lower(), box)

    # ------------------------------------------------------------------
    def load_json(self):
        path = filedialog.askopenfilename(filetypes=[("JSON files", "*.json")])
        if not path:
            return
        with open(path, "r", encoding="utf-8") as f:
            self.inputs = json.load(f)
        self.project_cost_var.set(str(self.inputs["project_cost_cr"]))
        self.sales_var.set(str(self.inputs["expected_sales_value_cr"]))
        self.iter_var.set(str(self.inputs["monte_carlo"]["iterations"]))
        self.status_label.configure(text=f"Loaded: {os.path.basename(path)}")

    def run_analysis_threaded(self):
        threading.Thread(target=self.run_analysis, daemon=True).start()

    def run_analysis(self):
        try:
            self.inputs["project_cost_cr"] = float(self.project_cost_var.get())
            self.inputs["expected_sales_value_cr"] = float(self.sales_var.get())
            self.inputs["monte_carlo"]["iterations"] = int(self.iter_var.get())
        except ValueError:
            messagebox.showerror("Invalid input", "Project cost, sales value and iterations must be numeric.")
            return

        self.status_label.configure(text="Running \u2014 Product Matrix, Sensitivity, Monte Carlo...")
        try:
            outdir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "Supporting_Data")
            self.results = run_all(self.inputs, outdir)
        except Exception as exc:
            messagebox.showerror("Analysis failed", str(exc))
            self.status_label.configure(text="Failed \u2014 see error dialog")
            return

        self._render_results()
        self.status_label.configure(text="Done \u2014 outputs written to Supporting_Data/")

    # ------------------------------------------------------------------
    def _render_results(self):
        r = self.results

        self._box_financing.delete("1.0", "end")
        self._box_financing.insert("end", r["financing_plan"].to_string(index=False))

        self._box_product.delete("1.0", "end")
        self._box_product.insert("end", r["product_matrix"].to_string(index=False))

        self._box_sensitivity.delete("1.0", "end")
        self._box_sensitivity.insert("end", r["sensitivity"].to_string(index=False))

        mc = r["monte_carlo"]
        self._box_monte.delete("1.0", "end")
        self._box_monte.insert("end", json.dumps(mc, indent=2))

        self._box_explanatory.delete("1.0", "end")
        self._box_explanatory.insert("end", r["explanatory_notes"])

        self._box_ai.delete("1.0", "end")
        self._box_ai.insert("end", r["ai_narrative"])


if __name__ == "__main__":
    app = GreenFinanceApp()
    app.mainloop()

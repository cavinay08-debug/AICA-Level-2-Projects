@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (echo Run setup_windows.bat first.& exit /b 1)
call .venv\Scripts\activate.bat
python -m unittest discover -s tests -v
if errorlevel 1 exit /b 1
python -m PyInstaller --noconfirm --clean "Desi Fintax ASG GSTN Verifier.spec"
if errorlevel 1 exit /b 1
echo Build complete under dist.
endlocal

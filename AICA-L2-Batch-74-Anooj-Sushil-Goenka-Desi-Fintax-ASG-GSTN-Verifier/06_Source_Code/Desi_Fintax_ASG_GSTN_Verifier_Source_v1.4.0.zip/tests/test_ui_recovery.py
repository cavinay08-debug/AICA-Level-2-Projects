import unittest

from app.ui.main_window import MainWindow


class Item:
    def __init__(self, value):
        self.value = value

    def text(self):
        return self.value


class Queue:
    def __init__(self, statuses):
        self.statuses = statuses
        self.selected = None
        self.cleared = False

    def rowCount(self):
        return len(self.statuses)

    def item(self, row, column):
        return Item(self.statuses[row] if column == 6 else f"GSTIN-{row}")

    def selectRow(self, row):
        self.selected = row

    def scrollToItem(self, item):
        pass

    def clearSelection(self):
        self.cleared = True

    def setCurrentCell(self, row, column):
        self.selected = None


class QueueCompletionTests(unittest.TestCase):
    def test_selects_next_pending_item(self):
        window = MainWindow.__new__(MainWindow)
        window.queue = Queue(["Verified", "Pending"])
        self.assertTrue(window.select_next_pending())
        self.assertEqual(1, window.queue.selected)

    def test_end_of_queue_clears_last_verified_selection(self):
        window = MainWindow.__new__(MainWindow)
        window.queue = Queue(["Verified", "Verified"])
        self.assertFalse(window.select_next_pending())
        self.assertTrue(window.queue.cleared)
        self.assertIsNone(window.queue.selected)


if __name__ == "__main__":
    unittest.main()

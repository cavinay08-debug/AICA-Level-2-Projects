import sqlite3
import tempfile
import unittest
from pathlib import Path

from app.database import Repository
from app.models import Invoice, Project, VerificationResult
from app.services.aggregation import aggregate_invoices
from app.services.gstin import checksum_character


def gstin(prefix):
    return prefix + checksum_character(prefix)


class RecoveryTests(unittest.TestCase):
    def test_legacy_schema_migrates_in_place(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "legacy.sqlite3"
            db = sqlite3.connect(path)
            db.executescript("CREATE TABLE schema_version(version INTEGER NOT NULL); INSERT INTO schema_version VALUES(1); CREATE TABLE suppliers(id INTEGER PRIMARY KEY, project_id INTEGER, gstin TEXT, queue_status TEXT);")
            db.close()
            Repository(path)
            db = sqlite3.connect(path)
            columns = {row[1] for row in db.execute("PRAGMA table_info(suppliers)")}
            version = db.execute("SELECT version FROM schema_version").fetchone()[0]
            db.close()
            self.assertTrue({"last_error", "last_attempt_at", "retry_count"}.issubset(columns))
            self.assertEqual(4, version)

    def test_reset_preserves_verified_supplier(self):
        with tempfile.TemporaryDirectory() as folder:
            repo = Repository(Path(folder) / "db.sqlite3")
            project = repo.create_project(Project(name="P", client_name="C", financial_year="FY 2025-26"))
            pending = gstin("27AAAAA0000A1Z")
            verified = gstin("29BBBBB1111B1Z")
            invoices = [Invoice(gstin=pending), Invoice(gstin=verified)]
            repo.import_records(project, invoices, aggregate_invoices(invoices))
            repo.set_queue_status(project, pending, "Portal Error", "temporary failure")
            repo.set_queue_status(project, verified, "Skipped")
            repo.save_verification(project, "FY 2025-26", VerificationResult(verified, status="Active"))
            repo.reset_project_queue(project)
            rows = {row["gstin"]: row for row in repo.supplier_rows(project)}
            self.assertEqual("Pending", rows[pending]["queue_status"])
            self.assertEqual("", rows[pending]["last_error"])
            self.assertEqual("Skipped", rows[verified]["queue_status"])


if __name__ == "__main__":
    unittest.main()

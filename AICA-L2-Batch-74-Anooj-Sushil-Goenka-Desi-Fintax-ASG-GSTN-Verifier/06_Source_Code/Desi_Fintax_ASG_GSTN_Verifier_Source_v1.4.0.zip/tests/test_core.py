import tempfile,unittest
from decimal import Decimal
from pathlib import Path
from app.database import Repository
from app.exporters import export_excel,export_pdf
from app.models import Invoice,Project,ReturnPeriod,VerificationResult
from app.services.aggregation import aggregate_invoices
from app.services.backup import create_backup,test_backup
from app.services.evidence import evidence_filename
from app.services.filing import apply_filing,apply_generic_due_dates,expected_periods,filing_conclusion,parse_financial_year
from app.services.gstin import checksum_character,extract_gstins,normalize_gstin,parse_bulk,validate_gstin

def make_gstin(prefix="27AAAAA0000A1Z"):return prefix+checksum_character(prefix)

class GSTINTests(unittest.TestCase):
    def test_validation_normalization_extraction(self):
        value=make_gstin(); self.assertTrue(validate_gstin(value).valid); self.assertEqual(value,normalize_gstin(" "+value.lower()+" ")); self.assertEqual([value],extract_gstins("GSTIN: "+value+".")); self.assertFalse(validate_gstin("27INVALID").valid)
    def test_bulk_deduplicates(self):
        value=make_gstin(); valid,invalid=parse_bulk(f"{value},{value}\n27INVALID"); self.assertEqual([value],valid); self.assertEqual(1,len(invalid))
    def test_100_invoice_aggregation(self):
        value=make_gstin(); rows=[Invoice(gstin=value,taxable_value=Decimal("100"),total_gst=Decimal("18")) for _ in range(100)]; result=aggregate_invoices(rows); self.assertEqual(1,len(result)); self.assertEqual(100,result[0].invoice_count); self.assertEqual(Decimal("10000"),result[0].taxable_value)

class FilingTests(unittest.TestCase):
    def test_monthly_quarterly_and_change(self):
        self.assertEqual(12,len(expected_periods("FY 2024-25"))); q={m:"Quarterly" for m in ("Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec","Jan","Feb","Mar")}; self.assertEqual(4,len(expected_periods("2024-25",q))); self.assertEqual(10,len(expected_periods("2024-25",{"Apr":"Quarterly","May":"Quarterly","Jun":"Quarterly"}))); self.assertEqual((2024,2025),parse_financial_year("FY 2024-25"))
    def test_delay(self):
        p=expected_periods("2024-25")[0]; apply_filing(p,"2024-06-01"); self.assertGreater(p.delay_days,0); self.assertEqual("Filed with delay",filing_conclusion([p]))

    def test_generic_portal_due_dates_and_delay(self):
        monthly=ReturnPeriod("April","Monthly (inferred)",filing_date="25/05/2025",filing_status="Filed")
        quarterly=ReturnPeriod("June","Quarterly (inferred)",filing_date="25/07/2025",filing_status="Filed")
        gstr1=ReturnPeriod("June","Quarterly (inferred)",filing_date="13/07/2025",filing_status="Filed",return_type="GSTR-1/IFF")
        apply_generic_due_dates([monthly,quarterly,gstr1],"FY 2025-26","27DTNPS6692P1Z9")
        self.assertEqual(("2025-05-20",5),(monthly.due_date,monthly.delay_days))
        self.assertEqual(("2025-07-22",3),(quarterly.due_date,quarterly.delay_days))
        self.assertEqual(("2025-07-13",0),(gstr1.due_date,gstr1.delay_days))

class PersistenceReportTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.root=Path(self.temp.name); self.repo=Repository(self.root/"test.sqlite3"); self.pid=self.repo.create_project(Project(name="Test Matter",client_name="ABC Ltd",financial_year="FY 2024-25")); self.gstin=make_gstin()
    def tearDown(self):self.temp.cleanup()
    def test_cross_import_dedupe_history_exports_backup(self):
        for amount in (100,200):
            inv=[Invoice(gstin=self.gstin,taxable_value=Decimal(amount),total_gst=Decimal("18"))]; self.repo.import_records(self.pid,inv,aggregate_invoices(inv))
        rows=self.repo.supplier_rows(self.pid); self.assertEqual(1,len(rows)); self.assertEqual(2,rows[0]["invoice_count"]); self.assertEqual(300,float(rows[0]["taxable_value"])); self.repo.save_verification(self.pid,"FY 2024-25",VerificationResult(self.gstin,status="Active")); self.repo.save_verification(self.pid,"FY 2024-25",VerificationResult(self.gstin,status="Cancelled"))
        with self.repo.connect() as db:self.assertEqual(2,db.execute("SELECT COUNT(*) FROM verifications").fetchone()[0])
        project=self.repo.get_project(self.pid); suppliers=self.repo.supplier_rows(self.pid); x=export_excel(self.root/"r.xlsx",project,suppliers,self.repo.invoice_rows(self.pid),[],[],[]); p=export_pdf(self.root/"r.pdf",project,suppliers,[],[]); self.assertGreater(x.stat().st_size,1000); self.assertGreater(p.stat().st_size,1000); z=create_backup(self.repo.path,self.root/"b.zip"); test_backup(z); self.assertEqual(f"{self.gstin}_24-25.pdf",evidence_filename(self.gstin,"FY 2024-25"))
    def test_projects_are_strictly_isolated(self):
        second=self.repo.create_project(Project(name="Second Client",client_name="XYZ Ltd",financial_year="FY 2025-26")); one=[Invoice(gstin=self.gstin,taxable_value=Decimal("100"))]; other_prefix="29BBBBB1111B1Z"; other_gstin=other_prefix+checksum_character(other_prefix); two=[Invoice(gstin=other_gstin,taxable_value=Decimal("900"))]; self.repo.import_records(self.pid,one,aggregate_invoices(one)); self.repo.import_records(second,two,aggregate_invoices(two)); first_rows=self.repo.supplier_rows(self.pid); second_rows=self.repo.supplier_rows(second); self.assertEqual([self.gstin],[row["gstin"] for row in first_rows]); self.assertEqual([other_gstin],[row["gstin"] for row in second_rows]); self.assertEqual(100,float(first_rows[0]["taxable_value"])); self.assertEqual(900,float(second_rows[0]["taxable_value"])); self.assertEqual(1,len(self.repo.invoice_rows(self.pid))); self.assertEqual(1,len(self.repo.invoice_rows(second)))

if __name__=="__main__":unittest.main()

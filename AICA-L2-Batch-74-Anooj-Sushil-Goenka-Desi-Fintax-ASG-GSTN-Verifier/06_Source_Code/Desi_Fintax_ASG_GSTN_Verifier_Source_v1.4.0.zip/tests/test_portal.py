import tempfile,unittest
from pathlib import Path
from PIL import Image
from app.config import GST_PORTAL_URL
from app.models import ReturnPeriod
from app.portal.providers import PortalBrowserProvider

class PortalWorkflowTests(unittest.TestCase):
    def test_current_official_search_route(self):self.assertEqual("https://services.gst.gov.in/services/searchtp",GST_PORTAL_URL)
    def test_public_response_field_mapping(self):
        provider=PortalBrowserProvider(); data={"lgnm":"ABC PRIVATE LIMITED","tradeNam":"ABC","sts":"Active","rgdt":"01/07/2017","ctb":"Private Limited Company"}; self.assertEqual("ABC PRIVATE LIMITED",provider._pick(data,"lgnm","legalName")); self.assertEqual("Active",provider._pick(data,"sts","status"))
    def test_financial_year_matches_full_portal_label(self):
        provider=PortalBrowserProvider(); self.assertEqual("2025",provider._financial_year_start("FY 2025-26")); self.assertIn(provider._financial_year_start("FY 2025-26"),"2025-2026")
    def test_full_month_tax_periods_are_captured(self):
        provider=PortalBrowserProvider(); self.assertEqual("March",provider._tax_period(["2025-2026","March","21/04/2026","Filed"])); self.assertEqual("September",provider._tax_period(["2025-2026","September","16/10/2025","Filed"]))
    def test_frequency_is_inferred_from_period_gaps(self):
        provider=PortalBrowserProvider(); rows=[ReturnPeriod(period,"") for period in ("March","December","September","June","May","April")]; provider._infer_filing_frequencies(rows); values={row.period:row.frequency for row in rows}; self.assertEqual("Monthly (inferred)",values["April"]); self.assertEqual("Monthly (inferred)",values["May"]); self.assertEqual("Monthly (inferred)",values["June"]); self.assertEqual("Quarterly (inferred)",values["September"]); self.assertEqual("Quarterly (inferred)",values["December"]); self.assertEqual("Quarterly (inferred)",values["March"])
    def test_evidence_pdf_falls_back_to_screenshot(self):
        class Page:
            def pdf(self,**kwargs):raise RuntimeError("visible browser cannot print")
            def screenshot(self,path,full_page):Image.new("RGB",(900,1200),"white").save(path)
        provider=PortalBrowserProvider(); provider.page=Page(); provider.gstin="27AAAAA0000A1Z5"; provider.financial_year="FY 2025-26"
        with tempfile.TemporaryDirectory() as folder:
            path,digest=provider.save_evidence(Path(folder)); self.assertTrue(path.exists()); self.assertGreater(path.stat().st_size,500); self.assertEqual(64,len(digest))
    def test_sweb_9000_is_explained_as_login_routing_error(self):
        provider=PortalBrowserProvider(); provider.last_error="SWEB_9000"; provider.logged_in=False
        self.assertFalse(provider.logged_in); self.assertEqual("SWEB_9000",provider.last_error)

if __name__=="__main__":unittest.main()

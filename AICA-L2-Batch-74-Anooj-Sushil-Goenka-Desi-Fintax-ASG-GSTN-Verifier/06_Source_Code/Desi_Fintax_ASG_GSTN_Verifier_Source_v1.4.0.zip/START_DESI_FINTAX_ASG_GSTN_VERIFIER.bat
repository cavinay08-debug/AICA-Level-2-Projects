@echo off
setlocal
cd /d "%~dp0"
set "APP_EXE=%~dp0Standalone EXE\Desi Fintax ASG GSTN Verifier\Desi Fintax ASG GSTN Verifier.exe"
if not exist "%APP_EXE%" (
  echo Application EXE was not found.
  echo Expected: %APP_EXE%
  echo Please use the installer in the Installer folder.
  pause
  exit /b 1
)
start "Desi Fintax ASG GSTN Verifier" "%APP_EXE%"
exit /b 0

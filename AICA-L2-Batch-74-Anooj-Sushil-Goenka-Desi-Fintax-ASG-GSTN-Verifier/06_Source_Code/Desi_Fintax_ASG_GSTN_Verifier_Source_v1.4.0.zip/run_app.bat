@echo off
setlocal
cd /d "%~dp0"
set "PACKAGED_EXE=%~dp0Standalone EXE\Desi Fintax ASG GSTN Verifier\Desi Fintax ASG GSTN Verifier.exe"
if exist "%PACKAGED_EXE%" (
  start "Desi Fintax ASG GSTN Verifier" "%PACKAGED_EXE%"
  exit /b 0
)
if not exist ".venv\Scripts\python.exe" (
  echo Standalone EXE not found and source environment is not installed.
  echo Run setup_windows.bat once, or reinstall the application.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" main.py
if errorlevel 1 pause
endlocal

from pathlib import Path
from openpyxl import Workbook
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import Alignment,Font,PatternFill
from openpyxl.utils import get_column_letter
NAVY,GOLD,WHITE,RED="102A43","C79A3B","FFFFFF","FDECEC"
MONEY_FIELDS={"taxable_value","igst","cgst","sgst","cess","total_gst","invoice_value","notice_amount"}
def _rows(items):return [dict(item) for item in items]
def _friendly(key):return key.replace("_"," ").title().replace("Gstin","GSTIN").replace("Gstr","GSTR")
def _write_table(ws,data,columns=None):
    columns=columns or (list(data[0]) if data else ["message"]); data=data or [{"message":"No records available"}]
    for col,key in enumerate(columns,1):
        cell=ws.cell(1,col,_friendly(key)); cell.fill=PatternFill("solid",fgColor=NAVY); cell.font=Font(color=WHITE,bold=True); cell.alignment=Alignment(horizontal="center")
    for r,item in enumerate(data,2):
        for c,key in enumerate(columns,1):
            value=item.get(key,""); cell=ws.cell(r,c,value)
            if key in MONEY_FIELDS:
                try:cell.value=float(value or 0)
                except (TypeError,ValueError):pass
                cell.number_format='₹ #,##,##0.00;[Red]-₹ #,##,##0.00'
    ws.freeze_panes="A2"; ws.auto_filter.ref=ws.dimensions; ws.row_dimensions[1].height=28
    for index,column in enumerate(columns,1):ws.column_dimensions[get_column_letter(index)].width=min(45,max(12,len(_friendly(column))+2,*(len(str(ws.cell(r,index).value or "")) for r in range(2,min(ws.max_row,100)+1))))
def export_excel(path,project,suppliers,invoices,returns,evidence,invalid,import_log=(),period_summary=()):
    supplier_data,invoice_data,return_data=_rows(suppliers),_rows(invoices),_rows(returns); evidence_data,invalid_data=_rows(evidence),_rows(invalid); period_data=_rows(period_summary); wb=Workbook(); ws=wb.active; ws.title="Summary"
    ws.merge_cells("A1:D1"); ws["A1"]="DESI FINTAX | ASG GSTN VERIFIER"; ws["A1"].font=Font(size=18,bold=True,color=WHITE); ws["A1"].fill=PatternFill("solid",fgColor=NAVY); ws["A1"].alignment=Alignment(horizontal="center")
    ws.merge_cells("A2:D2"); ws["A2"]="CA Anooj Sushil Goenka | Mobile: 9833049094 | WhatsApp: 9028593321"; ws["A2"].font=Font(bold=True,color=NAVY); ws["A2"].alignment=Alignment(horizontal="center")
    totals=lambda key:sum(float(row.get(key) or 0) for row in supplier_data)
    metrics=[("Project",project["name"]),("Client",project["client_name"]),("Financial Year",project["financial_year"]),("Unique GSTINs",len(supplier_data)),("Invoice Records",len(invoice_data)),("Invalid GSTINs",len(invalid_data)),("Total Taxable Value",totals("taxable_value")),("Total IGST",totals("igst")),("Total CGST",totals("cgst")),("Total SGST",totals("sgst")),("Total Cess",totals("cess")),("Total GST",totals("total_gst")),("Total Invoice Value",totals("invoice_value")),("Total Notice Amount",totals("notice_amount")),("Active Suppliers",sum(1 for r in supplier_data if str(r.get("registration_status","")).lower()=="active")),("Cancelled Suppliers",sum(1 for r in supplier_data if "cancel" in str(r.get("registration_status","")).lower())),("Verification Failures",sum(1 for r in supplier_data if not r.get("verified_at")))]
    for idx,(label,value) in enumerate(metrics,4):ws.cell(idx,1,label).font=Font(bold=True,color=NAVY); ws.cell(idx,2,value); ws.cell(idx,2).number_format='₹ #,##,##0.00' if label.startswith("Total ") else "General"
    ws.column_dimensions["A"].width=28; ws.column_dimensions["B"].width=30
    exceptions=invalid_data+[r for r in supplier_data if any(x in str(r.get("registration_status","")).lower() for x in ("cancel","suspend")) or int(r.get("not_filed_count") or 0)>0 or int(r.get("delayed_count") or 0)>0]
    for title,data in {"Supplier Summary":supplier_data,"Period GSTIN Summary":period_data,"Invoice Details":invoice_data,"Return Filing Status":return_data,"Exceptions":exceptions,"Evidence Index":evidence_data,"Import Log":_rows(import_log)}.items():_write_table(wb.create_sheet(title),data)
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True); wb.save(path); return path

from __future__ import annotations

import re
from abc import ABC,abstractmethod
from datetime import datetime
from pathlib import Path
from typing import Any

from app.config import GST_PORTAL_URL,data_root
from app.models import ReturnPeriod,VerificationResult
from app.services.evidence import evidence_filename,sha256_file
from app.services.filing import apply_generic_due_dates


class GSTDataProvider(ABC):
    @abstractmethod
    def start_verification(self,gstin:str,financial_year:str)->str:...
    @abstractmethod
    def capture_result(self)->VerificationResult:...
    def close(self)->None:pass


class ManualEntryProvider(GSTDataProvider):
    def __init__(self,result:VerificationResult|None=None):self.result=result
    def start_verification(self,gstin,financial_year):
        if self.result is None:self.result=VerificationResult(gstin=gstin,source="Manual",remarks=f"Financial year: {financial_year}")
        return "MANUAL"
    def capture_result(self):
        if self.result is None:raise RuntimeError("No manual verification is active")
        return self.result


class AuthorisedGSPProvider(GSTDataProvider):
    """Contract for a future documented, licensed GSP adapter."""
    def __init__(self,base_url,client_id="",client_secret=""):self.base_url,self.client_id,self.client_secret=base_url,client_id,client_secret
    def start_verification(self,gstin,financial_year):raise RuntimeError("Configure a documented authorised GSP adapter first")
    def capture_result(self):raise RuntimeError("No authorised GSP response is active")


class PortalBrowserProvider(GSTDataProvider):
    """Automates the official visible page; login/CAPTCHA/MFA always remain manual."""
    LABELS={
        "legal_name":("Legal Name of Business","Legal Name"),"trade_name":("Trade Name",),
        "status":("GSTIN / UIN Status","Status"),"registration_date":("Date of Registration","Effective Date of registration"),
        "cancellation_date":("Date of Cancellation","Effective Date of Cancellation"),"taxpayer_type":("Taxpayer Type",),
        "constitution":("Constitution of Business",),"state_jurisdiction":("State Jurisdiction",),
        "centre_jurisdiction":("Centre Jurisdiction",),"nature_of_business":("Nature of Business Activities","Nature of Business")}
    def __init__(self,portal_url=GST_PORTAL_URL):
        self.portal_url=portal_url or GST_PORTAL_URL; self._playwright=self.context=self.page=None; self.gstin=self.financial_year=""; self.logged_in=False; self.headless:bool|None=None; self.public_headless_supported=True; self.last_response:dict[str,Any]={}; self.last_error=""; self.started_at:datetime|None=None; self.login_pending=False
    def _ensure_browser(self,headless:bool=True):
        if self.page is not None and self.headless==headless:
            try:
                if not self.page.is_closed():return
            except Exception:pass
        try:from playwright.sync_api import sync_playwright
        except ImportError as exc:raise RuntimeError("Playwright is not installed in this build") from exc
        if self.context:
            try:self.context.close()
            except Exception:pass
            self.context=self.page=None
        if self._playwright is None:self._playwright=sync_playwright().start()
        self.context=self._playwright.chromium.launch_persistent_context(str(data_root()/"browser-profile"),channel="msedge",headless=headless,viewport={"width":1365,"height":900},accept_downloads=False); self.page=self.context.pages[0] if self.context.pages else self.context.new_page(); self.headless=headless
    def _safe_goto(self,url):
        """Accept GST's normal chained redirects instead of treating them as failures."""
        try:return self.page.goto(url,wait_until="domcontentloaded",timeout=90000)
        except Exception as exc:
            message=str(exc).lower()
            if "interrupted by another navigation" not in message:raise
            self.page.wait_for_timeout(1200)
            if self.page.url and self.page.url!="about:blank":return None
            raise
    def _body(self):
        try:return self.page.locator("body").inner_text(timeout=3000)
        except Exception:return ""
    def _login_boxes(self):
        def visible(selector):
            matches=self.page.locator(selector)
            for index in range(matches.count()):
                item=matches.nth(index)
                if item.is_visible():return item
            return matches.first
        return visible("input[placeholder*='Username'], input[name='user_name']"),visible("input[placeholder*='Password'], input[name='user_pass']")
    def open_login(self,username="",password=""):
        self._ensure_browser(False); self.logged_in=False; self.login_pending=True; self.last_error=""
        if "/services/login" not in self.page.url:self._safe_goto("https://services.gst.gov.in/services/login")
        # GST's Angular handlers attach after DOMContentLoaded. Submitting too
        # early looks like a successful click but performs no login action.
        self.page.wait_for_timeout(1800)
        body=self._body()
        if "Scheduled Downtime" in body:raise RuntimeError("GST Portal is under scheduled downtime. Retry after services resume.")
        user_box,password_box=self._login_boxes()
        if username and user_box.count():user_box.fill(username)
        if password and password_box.count():password_box.fill(password)
        self.page.wait_for_timeout(300)
        self.page.bring_to_front()
        if not username or not password:return "CREDENTIALS_REQUIRED"
        captcha=self._captcha_box()
        if captcha is not None:
            captcha.focus(); return "LOGIN_CAPTCHA_REQUIRED"
        button=self.page.get_by_role("button",name=re.compile(r"^Login$",re.I)).first
        if button.count():
            button.click(); self.page.wait_for_timeout(1500)
        return self.login_status()
    def login_status(self):
        if self.page is None:return "LOGIN_REQUIRED"
        body=self._body(); url=self.page.url.lower()
        if "scheduled downtime" in body.lower():self.last_error="GST Portal is under scheduled downtime."; return "PORTAL_ERROR"
        if "invalid captcha" in body.lower():self.last_error="The CAPTCHA was not accepted. Enter the new CAPTCHA and try again."; return "CAPTCHA_ERROR"
        if self._captcha_box() is not None:return "LOGIN_CAPTCHA_REQUIRED"
        if "/services/login" in url:
            errors=self.page.locator(".alert-danger,.error,.text-danger").all_text_contents()
            if errors:self.last_error=" ".join(x.strip() for x in errors if x.strip())
            return "LOGIN_ERROR" if self.last_error else "LOGIN_WAITING"
        if "accessdenied" in url:return "LOGIN_REQUIRED"
        self.logged_in=True; self.login_pending=False; return "LOGGED_IN"
    def _goto_search(self):
        # Always enter through the supported menu URL. GST redirects this to
        # /services/auth/searchtp for a valid logged-in session.
        response=self._safe_goto(self.portal_url)
        status=response.status if response is not None else 0
        try:body=self.page.locator("body").inner_text(timeout=3000)
        except Exception:body=""
        if status>=500 or "Scheduled Downtime" in body:
            raise RuntimeError("GST Portal is temporarily unavailable (scheduled downtime / HTTP 503). Please retry after the portal resumes service.")
        return response
    def _gstin_box(self):
        try:self.page.wait_for_selector("input[placeholder*='GSTIN']",state="visible",timeout=30000)
        except Exception:pass
        for locator in (self.page.get_by_role("textbox",name=re.compile("GSTIN.*UIN",re.I)).first,self.page.locator("input[placeholder*='GSTIN']").first,self.page.locator("input[ng-model*='GSTIN']").first):
            if locator.count() and locator.is_visible():return locator
        raise RuntimeError("GSTIN search box was not found. GST Portal layout may have changed.")
    def _captcha_box(self):
        for selector in ("input[placeholder*='Captcha']","input[placeholder*='captcha']","input[ng-model*='captcha']","input[id*='captcha']","input[name*='captcha']"):
            locator=self.page.locator(selector).first
            if locator.count() and locator.is_visible():return locator
        for locator in (self.page.locator("input[placeholder*='Characters shown']").first,self.page.get_by_role("textbox",name=re.compile("characters.*image",re.I)).first):
            if locator.count() and locator.is_visible():return locator
        return None
    def _enter_gstin(self,box,gstin):
        """Use real keyboard events because GST may attach CAPTCHA/UI logic to keyup/blur."""
        box.click(); box.press("Control+A"); box.type(gstin,delay=65); box.press("Tab"); self.page.wait_for_timeout(900)
    def _search_button(self):
        button=self.page.get_by_role("button",name=re.compile(r"^Search$",re.I)).first
        if button.count() and button.is_visible():return button
        return self.page.locator("button:has-text('Search')").first
    def _submit_search(self)->str:
        button=self._search_button()
        try:
            with self.page.expect_response(lambda response:"/services/api/search/taxpayerDetails" in response.url,timeout=35000) as pending:button.click()
            response=pending.value
            try:raw=response.json() or {}
            except Exception:raw={}
            nested=raw.get("data") if isinstance(raw,dict) else None
            self.last_response=nested if isinstance(nested,dict) else raw if isinstance(raw,dict) else {}
            success=bool(self.last_response and any(key in self.last_response for key in ("lgnm","legalName","tradeNam","sts","gstin")))
            self.last_error="" if success else str(raw.get("message") or raw.get("errorCode") or "")
            if self.last_error:
                # The current pre-login search screen can return SWEB_9000
                # without displaying a CAPTCHA. This is an unauthenticated
                # public-search rejection, not a taxpayer/GSTIN result. Route
                # into the saved client login and resume the same GSTIN.
                if not self.logged_in and self.last_error.upper()=="SWEB_9000":
                    self.last_error="Public GST search requires portal login for this request."
                    return "LOGIN_REQUIRED"
                return "PORTAL_ERROR"
            return "RESULT_READY" if self.last_response or self.result_ready() else "SEARCH_SUBMITTED"
        except Exception:
            return "SEARCH_SUBMITTED"
    def start_verification(self,gstin,financial_year):
        self._ensure_browser(False if self.logged_in or not self.public_headless_supported else True); self.gstin,self.financial_year=gstin,financial_year; self.last_response={}; self.last_error=""; self.started_at=datetime.now()
        if "searchtp" not in self.page.url.lower():
            self._goto_search()
        if "accessdenied" in self.page.url.lower() or "/services/login" in self.page.url.lower():return "LOGIN_REQUIRED"
        try:box=self._gstin_box()
        except RuntimeError:
            if not self.headless:raise
            # The GST Portal may refuse to render its Angular search form in
            # headless mode. Retry visibly once, then retain visible mode for
            # the rest of this batch instead of repeating the failed attempt.
            self.public_headless_supported=False; self._ensure_browser(False)
            self._goto_search(); box=self._gstin_box()
        self._enter_gstin(box,gstin); captcha=self._captcha_box()
        if not self.headless:self.page.bring_to_front()
        if captcha is not None:
            if self.headless:
                self._ensure_browser(False); self._goto_search(); self._enter_gstin(self._gstin_box(),gstin); captcha=self._captcha_box()
            if captcha is not None:
                captcha.focus()
                return "CAPTCHA_REQUIRED"
        return self._submit_search()
    def submit_after_captcha(self,value=""):
        captcha=self._captcha_box()
        if captcha is None:return "NO_CAPTCHA_FIELD"
        if value:
            captcha.click(); captcha.press("Control+A"); captcha.type(value.strip(),delay=80); captcha.press("Tab"); self.page.wait_for_timeout(350)
        if not captcha.input_value().strip():return "CAPTCHA_EMPTY"
        return self._submit_search() if "searchtp" in self.page.url.lower() else self._submit_login()
    def _submit_login(self):
        button=self.page.get_by_role("button",name=re.compile(r"^Login$",re.I)).first
        if not button.count():return "LOGIN_WAITING"
        button.click(); self.page.wait_for_timeout(1200); return self.login_status()
    def result_ready(self)->bool:
        if self.last_response and not self.last_error and any(key in self.last_response for key in ("lgnm","legalName","tradeNam","sts","gstin")):return True
        if self.page is None:return False
        try:
            text=self.page.locator("body").inner_text(timeout=3000)
            return bool(re.search(r"Legal Name of Business\s*[:\-]?\s*\S+",text,re.I))
        except Exception:return False
    def wait_status(self)->str:
        if self.login_pending:return self.login_status()
        body=self._body().lower() if self.page is not None else ""
        if "invalid captcha" in body or "captcha entered is incorrect" in body:
            self.last_error="The CAPTCHA was not accepted. Enter the refreshed CAPTCHA and submit again."; return "CAPTCHA_ERROR"
        if self.page is not None and self._captcha_box() is not None:return "CAPTCHA_REQUIRED"
        if self.page is not None and ("accessdenied" in self.page.url.lower() or "/services/login" in self.page.url.lower()):return "LOGIN_REQUIRED"
        if self.result_ready():return "RESULT_READY"
        if self.last_error:return "PORTAL_ERROR"
        if self.started_at and (datetime.now()-self.started_at).total_seconds()>180:return "TIMEOUT"
        return "WAITING"
    def reset_current(self,restart_browser=False):
        self.last_response={}; self.last_error=""; self.started_at=None; self.gstin=self.financial_year=""
        if restart_browser:
            if self.context:
                try:self.context.close()
                except Exception:pass
            self.context=self.page=None; self.logged_in=False; self.login_pending=False; self.headless=None
    @staticmethod
    def _extract_label(text,labels):
        for label in labels:
            match=re.search(re.escape(label)+r"\s*[:\-]?\s*([^\n]+)",text,re.I)
            if match:return match.group(1).strip()
        return ""
    @staticmethod
    def _pick(data:dict,*keys):
        for key in keys:
            value=data.get(key)
            if value not in (None,"",[]):return str(value)
        return ""
    @staticmethod
    def _financial_year_start(value:str)->str:
        match=re.search(r"\b(20\d{2})\b",value or "")
        return match.group(1) if match else ""
    @staticmethod
    def _tax_period(parts:list[str])->str:
        month=re.compile(r"\b(April|May|June|July|August|September|October|November|December|January|February|March|Apr|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec|Jan|Feb|Mar|Q[1-4])\b",re.I)
        return next((match.group(1) for part in parts if (match:=month.search(part))),"")
    @staticmethod
    def _infer_filing_frequencies(rows:list[ReturnPeriod])->None:
        order={name:index for index,names in enumerate((("april","apr"),("may",),("june","jun"),("july","jul"),("august","aug"),("september","sep","sept"),("october","oct"),("november","nov"),("december","dec"),("january","jan"),("february","feb"),("march","mar"))) for name in names}
        ordered=sorted(((order[row.period.strip().lower()],row) for row in rows if row.period.strip().lower() in order),key=lambda item:item[0])
        for position,(month_index,row) in enumerate(ordered):
            if position==0:gap=(ordered[1][0]-month_index) if len(ordered)>1 else 1
            else:gap=month_index-ordered[position-1][0]
            row.frequency="Quarterly (inferred)" if gap>=3 else "Monthly (inferred)"
            row.remarks+=(" | " if row.remarks else "")+"Frequency inferred from spacing between displayed tax periods; GST Portal filing table does not state frequency."
    def prepare_filing_table(self)->None:
        """Best-effort official UI navigation after taxpayer profile appears."""
        if self.page is None:return
        try:
            show=self.page.get_by_role("button",name=re.compile("SHOW FILING TABLE",re.I)).first
            if not show.count():show=self.page.get_by_text(re.compile("^SHOW FILING TABLE$",re.I)).first
            if show.count() and show.is_visible():show.click(); self.page.wait_for_timeout(1400)
            fy=self.financial_year.upper().replace("FY","").strip(); start_year=self._financial_year_start(fy)
            selects=self.page.locator("select")
            selected=None
            for index in range(selects.count()):
                select=selects.nth(index)
                if not select.is_visible():continue
                options=select.locator("option").all_text_contents()
                match=next((option.strip() for option in options if fy in option or (start_year and start_year in option)),"")
                if match:select.select_option(label=match); selected=select; self.page.wait_for_timeout(400); break
            if selected is None:raise RuntimeError(f"Financial year {fy} was not available in the GST filing table")
            buttons=self.page.get_by_role("button",name=re.compile(r"^Search$",re.I))
            visible=[buttons.nth(i) for i in range(buttons.count()) if buttons.nth(i).is_visible()]
            if visible:visible[-1].click(); self.page.wait_for_timeout(1800)
        except Exception as exc:
            self.last_error=f"Taxpayer details were found, but the requested filing table could not be opened: {exc}"
            raise RuntimeError(self.last_error) from exc
    def capture_result(self):
        if self.page is None:raise RuntimeError("No GST Portal session is active")
        self.prepare_filing_table(); text=self.page.locator("body").inner_text(timeout=30000); data=self.last_response if isinstance(self.last_response,dict) else {}
        values={field:self._extract_label(text,labels) for field,labels in self.LABELS.items()}
        values["legal_name"]=values["legal_name"] or self._pick(data,"lgnm","legalName","legal_name")
        values["trade_name"]=values["trade_name"] or self._pick(data,"tradeNam","tradeName","trade_name")
        values["status"]=values["status"] or self._pick(data,"sts","status") or "Manual Review Required"
        values["registration_date"]=values["registration_date"] or self._pick(data,"rgdt","registrationDate")
        values["cancellation_date"]=values["cancellation_date"] or self._pick(data,"cxdt","cancellationDate")
        values["taxpayer_type"]=values["taxpayer_type"] or self._pick(data,"dty","taxpayerType")
        values["constitution"]=values["constitution"] or self._pick(data,"ctb","constitution")
        values["state_jurisdiction"]=values["state_jurisdiction"] or self._pick(data,"stj","stateJurisdiction")
        values["centre_jurisdiction"]=values["centre_jurisdiction"] or self._pick(data,"ctj","centreJurisdiction")
        nba=data.get("nba",[]) if isinstance(data,dict) else []
        if not values["nature_of_business"] and nba:values["nature_of_business"]=", ".join(map(str,nba))
        if not values["legal_name"]:raise RuntimeError(f"Taxpayer result was not available{': '+self.last_error if self.last_error else ''}")
        rows=[]; filing_tables=[]
        for pattern,return_type in ((r"Filing details for GSTR\s*-?\s*3B","GSTR-3B"),(r"Filing details for GSTR\s*-?\s*1\s*/?\s*IFF","GSTR-1/IFF")):
            heading=self.page.get_by_text(re.compile(pattern,re.I)).first
            if heading.count() and heading.is_visible():filing_tables.append((heading.locator("xpath=following::table[1]"),return_type))
        if not filing_tables:
            for candidate in self.page.locator("table").all():
                try:
                    header=candidate.locator("tr").first.inner_text()
                    if "Financial Year" in header and "Tax Period" in header and "Date of filing" in header:filing_tables.append((candidate,"GSTR-3B"))
                except Exception:continue
        for table,return_type in filing_tables:
            table_rows=[]
            try:
                html_rows=table.locator("tr")
                for index in range(html_rows.count()):
                    parts=[part.strip() for part in html_rows.nth(index).locator("th,td").all_text_contents() if part.strip()]
                    if len(parts)<3 or not any(self._financial_year_start(part)==self._financial_year_start(self.financial_year) for part in parts):continue
                    combined=" | ".join(parts)
                    period=self._tax_period(parts)
                    filing_date=next((match.group(0) for part in parts if (match:=re.search(r"\b\d{1,2}[-/]\d{1,2}[-/]\d{4}\b",part))),"")
                    frequency=next((part for part in parts if part.lower() in ("monthly","quarterly")),"As displayed")
                    displayed_status=next((part for part in parts if part.lower() in ("filed","not filed")),"")
                    status=displayed_status or ("Filed" if filing_date else "Not Filed")
                    table_rows.append(ReturnPeriod(period or "Portal row",frequency,filing_status=status,filing_date=filing_date,remarks=combined,return_type=return_type))
            except Exception:continue
            self._infer_filing_frequencies(table_rows); rows.extend(table_rows)
        if not rows:raise RuntimeError(f"The FY {self.financial_year} filing table opened, but no return-filing rows were captured")
        apply_generic_due_dates(rows,self.financial_year,self.gstin)
        source="GST Portal - Logged-in Browser" if self.logged_in else "GST Portal - Public Browser"
        return VerificationResult(gstin=self.gstin,source=source,returns=rows,**values)
    def save_evidence(self,folder:Path,dated=False):
        if self.page is None:raise RuntimeError("No GST Portal page is available for PDF evidence")
        folder.mkdir(parents=True,exist_ok=True); path=folder/evidence_filename(self.gstin,self.financial_year,dated)
        try:
            self.page.pdf(path=str(path),format="A4",print_background=True,display_header_footer=True,header_template="<span></span>",footer_template="<div style='font-size:8px;width:100%;text-align:center'>GST Portal evidence | <span class='url'></span> | <span class='date'></span></div>",margin={"top":"10mm","bottom":"15mm"})
        except Exception as pdf_error:
            # Some installed Edge versions reject page.pdf() in a visible
            # persistent session. Preserve the evidence by printing a full-
            # page screenshot to PDF instead of losing the completed result.
            screenshot=path.with_suffix(".evidence.png")
            try:
                from PIL import Image
                self.page.screenshot(path=str(screenshot),full_page=True)
                with Image.open(screenshot) as image:image.convert("RGB").save(path,"PDF",resolution=150.0)
            except Exception as fallback_error:
                raise RuntimeError(f"GST details were captured, but the PDF could not be created. Browser PDF error: {pdf_error}; fallback error: {fallback_error}") from fallback_error
            finally:
                try:screenshot.unlink(missing_ok=True)
                except Exception:pass
        if not path.exists() or path.stat().st_size<500:raise RuntimeError("GST evidence PDF was created but is empty")
        return path,sha256_file(path)
    def close(self):
        if self.context:self.context.close()
        if self._playwright:self._playwright.stop()
        self.context=self.page=self._playwright=None

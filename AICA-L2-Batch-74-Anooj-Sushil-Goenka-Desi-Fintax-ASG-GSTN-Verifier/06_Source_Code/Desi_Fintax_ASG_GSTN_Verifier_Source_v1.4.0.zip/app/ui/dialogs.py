from datetime import date
from PySide6.QtWidgets import QComboBox,QDialog,QDialogButtonBox,QFormLayout,QLineEdit,QTextEdit,QVBoxLayout
from app.models import Project,VerificationResult
class ProjectDialog(QDialog):
    def __init__(self,parent=None,project=None,credentials=None):
        super().__init__(parent); self.setWindowTitle("Edit Client Project" if project else "Create Verification Project"); self.resize(580,620); form=QFormLayout(); self.fields={}; credentials=credentials or {}
        for key,label in (("name","Project Name *"),("client_name","Client Name"),("client_gstin","Client GSTIN"),("tax_period","Tax Period"),("notice_type","Notice Type"),("notice_reference","Notice Reference"),("notice_date","Notice Date"),("jurisdiction","Department / Jurisdiction")):
            w=QLineEdit(); self.fields[key]=w; form.addRow(label,w)
        today=date.today(); current_start=today.year if today.month>=4 else today.year-1; financial_years=[f"FY {year}-{str(year+1)[-2:]}" for year in range(current_start,2016,-1)]; fy=QComboBox(); fy.setEditable(True); fy.addItems(financial_years+[""]); self.fields["financial_year"]=fy; form.insertRow(3,"Financial Year",fy); remarks=QTextEdit(); remarks.setMaximumHeight(85); self.fields["remarks"]=remarks; form.addRow("Remarks",remarks); buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel); buttons.accepted.connect(self._accept); buttons.rejected.connect(self.reject); layout=QVBoxLayout(self); layout.addLayout(form); layout.addWidget(buttons)
        self.login_username=QLineEdit(credentials.get("username","")); self.login_password=QLineEdit(credentials.get("password","")); self.login_password.setEchoMode(QLineEdit.Password); form.insertRow(4,"GST Portal Login ID",self.login_username); form.insertRow(5,"GST Portal Password",self.login_password)
        if project:
            for key,widget in self.fields.items():
                value=str(project[key] or "")
                if isinstance(widget,QComboBox):widget.setCurrentText(value)
                elif isinstance(widget,QTextEdit):widget.setPlainText(value)
                else:widget.setText(value)
    def _accept(self):
        if self.fields["name"].text().strip():self.accept()
        else:self.fields["name"].setFocus()
    def project(self):
        values={k:(v.currentText() if isinstance(v,QComboBox) else v.toPlainText() if isinstance(v,QTextEdit) else v.text()).strip() for k,v in self.fields.items()}; return Project(**values)
    def credentials(self):return {"username":self.login_username.text().strip(),"password":self.login_password.text()}
class ManualVerificationDialog(QDialog):
    def __init__(self,gstin,parent=None):
        super().__init__(parent); self.gstin=gstin; self.setWindowTitle(f"Manual Verification - {gstin}"); self.resize(520,440); form=QFormLayout(); self.fields={}
        for key,label in (("legal_name","Legal Name"),("trade_name","Trade Name"),("registration_date","Registration Date"),("cancellation_date","Cancellation Date"),("taxpayer_type","Taxpayer Type"),("constitution","Constitution"),("state_jurisdiction","State Jurisdiction"),("centre_jurisdiction","Centre Jurisdiction")):
            w=QLineEdit(); self.fields[key]=w; form.addRow(label,w)
        status=QComboBox(); status.addItems(["Active","Cancelled","Suspended","Not Registered","Manual Review Required"]); self.fields["status"]=status; form.insertRow(2,"Registration Status",status); remarks=QTextEdit(); remarks.setMaximumHeight(70); self.fields["remarks"]=remarks; form.addRow("Remarks",remarks); buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel); buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject); layout=QVBoxLayout(self); layout.addLayout(form); layout.addWidget(buttons)
    def result(self):
        values={k:(v.currentText() if isinstance(v,QComboBox) else v.toPlainText() if isinstance(v,QTextEdit) else v.text()).strip() for k,v in self.fields.items()}; return VerificationResult(gstin=self.gstin,source="Manual Entry",**values)

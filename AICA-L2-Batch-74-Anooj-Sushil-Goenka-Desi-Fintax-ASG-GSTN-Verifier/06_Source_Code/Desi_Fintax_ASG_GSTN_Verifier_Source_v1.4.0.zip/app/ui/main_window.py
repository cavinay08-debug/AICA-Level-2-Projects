import logging
import urllib.request
from datetime import datetime
from pathlib import Path
from PySide6.QtCore import Qt,QTimer
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import QAbstractItemView,QCheckBox,QComboBox,QFileDialog,QFormLayout,QFrame,QGridLayout,QGroupBox,QHBoxLayout,QLabel,QLineEdit,QMainWindow,QMessageBox,QProgressBar,QPushButton,QStackedWidget,QTabWidget,QTableWidget,QTableWidgetItem,QTextEdit,QVBoxLayout,QWidget
from app.config import APP_NAME,GST_PORTAL_URL,MOBILE,PROFESSIONAL_NAME,WHATSAPP,data_root,database_path,resource_path
from app.database import Repository
from app.exporters import export_excel,export_pdf
from app.importers import ExcelImporter,PDFImporter
from app.models import Invoice
from app.portal import PortalBrowserProvider
from app.services.aggregation import aggregate_invoices
from app.services.backup import create_backup,restore_backup
from app.services.gstin import parse_bulk
from app.security import SecretStore
from app.ui.dialogs import ManualVerificationDialog,ProjectDialog
LOG=logging.getLogger(__name__)

class MainWindow(QMainWindow):
    NAV=("Client Dashboard","Projects","Import","Verify GSTINs","Results","Reports & Backup","Settings")
    def __init__(self):
        super().__init__(); self.setWindowTitle(APP_NAME); self.resize(1360,820); self.setMinimumSize(1050,680); self.repo=Repository(); self.project_id=None; self.provider=None; self.metrics={}; self.batch_paused=False; self.secrets=SecretStore(); self.portal_busy=False; self.capture_in_progress=False; self.login_resume_gstin=""
        if "quicklinks/searchtxp" in self.repo.setting("portal_url",""):self.repo.set_setting("portal_url",GST_PORTAL_URL)
        self.portal_timer=QTimer(self); self.portal_timer.setInterval(1500); self.portal_timer.timeout.connect(self.poll_portal)
        root=QWidget(); self.setCentralWidget(root); box=QHBoxLayout(root); box.setContentsMargins(0,0,0,0); box.setSpacing(0); box.addWidget(self._sidebar()); right=QWidget(); rightbox=QVBoxLayout(right); rightbox.setContentsMargins(0,0,0,0); rightbox.setSpacing(0); self.project_banner=QLabel("NO CLIENT PROJECT SELECTED - open Projects to begin"); self.project_banner.setStyleSheet("background:#C79A3B;color:#102A43;padding:10px 18px;font-weight:700"); rightbox.addWidget(self.project_banner); self.stack=QStackedWidget(); rightbox.addWidget(self.stack,1); box.addWidget(right,1)
        for build in (self.dashboard_page,self.projects_page,self.import_page,self.queue_page,self.combined_results_page,self.reports_backup_page,self.settings_page):self.stack.addWidget(build())
        self.refresh_projects(); self.refresh_all(); self.statusBar().showMessage("Ready - create or select one client project")
    def _sidebar(self):
        side=QFrame(); side.setObjectName("Sidebar"); layout=QVBoxLayout(side); layout.setContentsMargins(0,0,0,12); logo=QLabel(); p=resource_path("assets/desi_fintax_logo.jpeg")
        if p.exists():logo.setPixmap(QPixmap(str(p)).scaled(175,90,Qt.KeepAspectRatio,Qt.SmoothTransformation)); logo.setAlignment(Qt.AlignCenter); logo.setStyleSheet("background:white;margin:12px;border-radius:6px")
        layout.addWidget(logo); brand=QLabel("DESI FINTAX\nASG GSTN VERIFIER"); brand.setObjectName("Brand"); layout.addWidget(brand); contact=QLabel(f"{PROFESSIONAL_NAME}\nM: {MOBILE} | WA: {WHATSAPP}"); contact.setObjectName("Contact"); layout.addWidget(contact)
        for i,name in enumerate(self.NAV):b=QPushButton(name); b.setProperty("nav",True); b.setCheckable(True); b.setChecked(i==0); b.clicked.connect(lambda checked,x=i:self.navigate(x)); layout.addWidget(b)
        layout.addStretch(); return side
    def navigate(self,index):
        self.stack.setCurrentIndex(index)
        for b in self.findChildren(QPushButton):
            if b.property("nav"):b.setChecked(b.text()==self.NAV[index])
        if self.project_id:self.refresh_all()
    @staticmethod
    def page(title,subtitle):
        page=QWidget(); layout=QVBoxLayout(page); layout.setContentsMargins(22,18,22,18); h=QLabel(title); h.setStyleSheet("font-size:22pt;font-weight:700;color:#102A43"); layout.addWidget(h); s=QLabel(subtitle); s.setProperty("muted",True); layout.addWidget(s); return page,layout
    @staticmethod
    def table(columns):
        t=QTableWidget(0,len(columns)); t.setHorizontalHeaderLabels(columns); t.setAlternatingRowColors(True); t.setSortingEnabled(True); t.setSelectionBehavior(QAbstractItemView.SelectRows); t.setEditTriggers(QAbstractItemView.NoEditTriggers); t.verticalHeader().setVisible(False); t.horizontalHeader().setStretchLastSection(True); return t
    def dashboard_page(self):
        page,l=self.page("Client Dashboard","Only the currently selected client project is shown"); cards=QGridLayout(); labels=("Suppliers","Pending","Issues","Notice Amount")
        for i,label in enumerate(labels):f=QFrame(); v=QVBoxLayout(f); a=QLabel(label); a.setProperty("muted",True); n=QLabel("0"); n.setProperty("metric",True); v.addWidget(a); v.addWidget(n); cards.addWidget(f,i//4,i%4); self.metrics[label]=n
        l.addLayout(cards); self.progress=QProgressBar(); self.progress.setFormat("Current project verification: %p%"); l.addWidget(self.progress); self.dashboard=self.table(["GSTIN","Supplier","Status","Invoices","Total GST","Notice Amount","Verification"]); l.addWidget(self.dashboard,1); return page
    def projects_page(self):
        page,l=self.page("Projects","Separate verification history, encrypted GST login and evidence for each client matter"); bar=QHBoxLayout(); new=QPushButton("+ New Project"); new.clicked.connect(self.new_project); edit=QPushButton("Edit Project / GST Login"); edit.clicked.connect(self.edit_project); op=QPushButton("Open Selected Project"); op.clicked.connect(self.select_project); bar.addWidget(new); bar.addWidget(edit); bar.addWidget(op); bar.addStretch(); l.addLayout(bar); self.projects=self.table(["ID","Project Name","Client","Client GSTIN","Financial Year","Notice Reference","Created"]); self.projects.doubleClicked.connect(self.select_project); l.addWidget(self.projects,1); return page
    def import_page(self):
        page,l=self.page("Import Data","Every GSTR-2A/2B import is retained under the active client project and selected period")
        context=QGroupBox("Import Context"); form=QFormLayout(context); self.import_type=QComboBox(); self.import_type.addItems(["GSTR-2B","GSTR-2A","Other"]); self.import_fy=QComboBox(); self.import_fy.setEditable(True); self.import_fy.addItems(self.financial_years()); self.import_period=QComboBox(); self.import_period.setEditable(True); self.import_period.addItems(["Annual","April","May","June","July","August","September","October","November","December","January","February","March"]); form.addRow("Statement type",self.import_type); form.addRow("Financial year",self.import_fy); form.addRow("Import period",self.import_period); l.addWidget(context)
        bar=QHBoxLayout(); e=QPushButton("Import Excel / GSTR-2A or 2B"); e.clicked.connect(self.import_excel); p=QPushButton("Import PDF"); p.clicked.connect(self.import_pdf); t=QPushButton("Save Excel Template"); t.clicked.connect(self.save_template); bar.addWidget(e); bar.addWidget(p); bar.addWidget(t); bar.addStretch(); l.addLayout(bar); g=QGroupBox("Manual / Bulk GSTIN Entry"); q=QVBoxLayout(g); self.bulk=QTextEdit(); self.bulk.setPlaceholderText("Paste GSTINs separated by new lines, commas, semicolons, spaces or tabs"); q.addWidget(self.bulk); add=QPushButton("Validate and Add"); add.clicked.connect(self.import_bulk); q.addWidget(add); l.addWidget(g); self.import_status=QLabel("No import performed in this session."); self.import_status.setWordWrap(True); l.addWidget(self.import_status); l.addStretch(); return page
    def queue_page(self):
        page,l=self.page("Verify GSTINs","Login ID, password and GSTIN entry are automatic; only a portal CAPTCHA remains manual"); bar=QHBoxLayout(); self.queue_search=QLineEdit(); self.queue_search.setPlaceholderText("Filter active client suppliers"); self.queue_search.textChanged.connect(self.refresh_queue); login=QPushButton("Login / Continue"); login.clicked.connect(self.open_login); start=QPushButton("Start Automatic Verification"); start.clicked.connect(self.start_batch); manual=QPushButton("Manual Fallback"); manual.clicked.connect(self.manual_verification); [bar.addWidget(x) for x in (self.queue_search,login,start,manual)]; l.addLayout(bar)
        search_context=QHBoxLayout(); search_context.addWidget(QLabel("Search FY")); self.verify_fy=QComboBox(); self.verify_fy.setEditable(True); self.verify_fy.addItems(self.financial_years()); search_context.addWidget(self.verify_fy); search_context.addWidget(QLabel("Imported period / filter")); self.verify_period=QComboBox(); self.verify_period.setEditable(True); self.verify_period.addItems(["Annual","April","May","June","July","August","September","October","November","December","January","February","March"]); search_context.addWidget(self.verify_period); search_context.addStretch(); l.addLayout(search_context)
        self.portal_status=QLabel("Ready. Select a GSTIN or start the project queue."); self.portal_status.setStyleSheet("background:#EAF2F8;padding:10px;border-radius:5px;font-weight:600"); self.portal_status.setWordWrap(True); l.addWidget(self.portal_status); captcha=QHBoxLayout(); self.captcha_input=QLineEdit(); self.captcha_input.setPlaceholderText("When CAPTCHA appears in Edge, type it here"); self.captcha_submit=QPushButton("Submit CAPTCHA & Continue"); self.captcha_submit.clicked.connect(self.submit_captcha); captcha.addWidget(self.captcha_input); captcha.addWidget(self.captcha_submit); l.addLayout(captcha); controls=QHBoxLayout(); skip=QPushButton("Skip"); skip.clicked.connect(lambda:self.set_queue("Skipped")); pause=QPushButton("Pause"); pause.clicked.connect(self.pause_batch); resume=QPushButton("Resume"); resume.clicked.connect(self.resume_batch); retry=QPushButton("Retry Selected Now"); retry.clicked.connect(self.retry_selected); reset=QPushButton("Reset Project Queue"); reset.clicked.connect(self.reset_project_queue); [controls.addWidget(x) for x in (skip,pause,resume,retry,reset)]; controls.addStretch(); l.addLayout(controls); self.queue=self.table(["GSTIN","Supplier","Invoices","FY / Import Period","Status","Verified At","Queue","Last Error"]); l.addWidget(self.queue,1); return page

    @staticmethod
    def financial_years():
        today=datetime.now(); current=today.year if today.month>=4 else today.year-1
        return [f"FY {year}-{str(year+1)[-2:]}" for year in range(current,2016,-1)]

    def current_import_meta(self,filename="",duplicates=0,sheets=()):
        period=self.import_period.currentText().strip() or "Annual"
        return {"filename":filename,"file_type":self.import_type.currentText(),"sheet_name":", ".join(sheets),"duplicates":duplicates,"financial_year":self.import_fy.currentText().strip(),"period_type":"Annual" if period.lower()=="annual" else "Monthly","tax_period":period}

    def combined_results_page(self):
        page,l=self.page("Results","All details for the active client project in one place"); tabs=QTabWidget(); supplier=QWidget(); sl=QVBoxLayout(supplier); bar=QHBoxLayout(); self.result_search=QLineEdit(); self.result_search.setPlaceholderText("Search supplier results"); self.result_search.textChanged.connect(self.refresh_results); self.result_filter=QComboBox(); self.result_filter.addItems(["All","Active","Cancelled","Suspended","Pending","Missing GSTR-3B","Delayed"]); self.result_filter.currentTextChanged.connect(self.refresh_results); bar.addWidget(self.result_search); bar.addWidget(self.result_filter); sl.addLayout(bar); self.results=self.table(["GSTIN","Supplier","Legal Name","Trade Name","Status","Reg. Date","Cancel Date","Invoices","Taxable","IGST","CGST","SGST","Cess","GST","Invoice Value","Notice Amount","Expected","Filed","Missing","Delayed","Verified At","Remarks"]); sl.addWidget(self.results); tabs.addTab(supplier,"Supplier Summary")
        self.filings=self.table(["GSTIN","FY","Return","Period","Frequency","Due Date","Status","Filing Date","Delay","ARN","Remarks"]); tabs.addTab(self.filings,"GSTR-3B")
        invoice=QWidget(); il=QVBoxLayout(invoice); self.invoice_search=QLineEdit(); self.invoice_search.setPlaceholderText("Search invoice details"); self.invoice_search.textChanged.connect(self.refresh_invoices); il.addWidget(self.invoice_search); self.invoices=self.table(["GSTIN","Supplier","Invoice No.","Date","Taxable","IGST","CGST","SGST","Cess","GST","Invoice Value","Notice Amount","Source","Sheet","Row","Remarks"]); il.addWidget(self.invoices); tabs.addTab(invoice,"Invoices")
        self.exceptions=self.table(["Type","GSTIN / Value","Supplier","Reason / Status","Amount","Source"]); tabs.addTab(self.exceptions,"Exceptions")
        self.evidence=self.table(["GSTIN","FY","PDF Filename","Path","Captured At","SHA-256"]); tabs.addTab(self.evidence,"Evidence PDFs"); l.addWidget(tabs,1); return page

    def reports_backup_page(self):
        page,l=self.page("Reports & Backup","Exports and backup for the active client project"); reports=QGroupBox("Current Client Project Reports"); rl=QVBoxLayout(reports); e=QPushButton("Export Excel Workbook"); e.clicked.connect(self.export_xlsx); p=QPushButton("Export PDF Report"); p.clicked.connect(self.export_pdf); rl.addWidget(e); rl.addWidget(p); self.report_status=QLabel("Select a client project before exporting."); self.report_status.setWordWrap(True); rl.addWidget(self.report_status); l.addWidget(reports); backup=QGroupBox("Application Backup"); bl=QHBoxLayout(backup); create=QPushButton("Create ZIP Backup"); create.clicked.connect(self.backup); restore=QPushButton("Restore Backup"); restore.clicked.connect(self.restore); bl.addWidget(create); bl.addWidget(restore); l.addWidget(backup); l.addStretch(); return page
    def results_page(self):
        page,l=self.page("Supplier Results","One GSTIN per row with invoice-wise amounts aggregated supplier-wise"); bar=QHBoxLayout(); self.result_search=QLineEdit(); self.result_search.setPlaceholderText("Search results"); self.result_search.textChanged.connect(self.refresh_results); self.result_filter=QComboBox(); self.result_filter.addItems(["All","Active","Cancelled","Suspended","Pending","Missing GSTR-3B","Delayed"]); self.result_filter.currentTextChanged.connect(self.refresh_results); bar.addWidget(self.result_search); bar.addWidget(self.result_filter); l.addLayout(bar); self.results=self.table(["GSTIN","Supplier Name","Legal Name","Trade Name","Status","Reg. Date","Cancel Date","Invoices","Taxable Value","IGST","CGST","SGST","Cess","Total GST","Invoice Value","Notice Amount","Expected","Filed","Not Filed","Delayed","Verified At","Remarks"]); l.addWidget(self.results,1); return page
    def filing_page(self):
        page,l=self.page("GSTR-3B Filing Details","Return filing does not establish invoice-level payment of tax"); self.filings=self.table(["GSTIN","Financial Year","Return","Tax Period","Frequency","Due Date","Status","Filing Date","Delay Days","ARN","Remarks"]); l.addWidget(self.filings,1); return page
    def invoice_page(self):
        page,l=self.page("Invoice Details","Original invoice-level data retained for reconciliation"); self.invoice_search=QLineEdit(); self.invoice_search.setPlaceholderText("Filter GSTIN, supplier or invoice number"); self.invoice_search.textChanged.connect(self.refresh_invoices); l.addWidget(self.invoice_search); self.invoices=self.table(["GSTIN","Supplier","Invoice No.","Invoice Date","Taxable Value","IGST","CGST","SGST","Cess","Total GST","Invoice Value","Notice Amount","Source File","Sheet","Row","Remarks"]); l.addWidget(self.invoices,1); return page
    def exceptions_page(self):
        page,l=self.page("Exceptions","Invalid GSTINs, adverse status, missing returns, delays and pending review"); self.exceptions=self.table(["Type","GSTIN / Value","Supplier","Reason / Status","Amount","Source / Verification"]); l.addWidget(self.exceptions,1); return page
    def evidence_page(self):
        page,l=self.page("Evidence Index","Short filenames with capture time and SHA-256 integrity hash"); self.evidence=self.table(["GSTIN","Financial Year","Filename","Path","Captured At","SHA-256"]); l.addWidget(self.evidence,1); return page
    def reports_page(self):
        page,l=self.page("Reports","Branded Excel workbook and litigation-friendly consolidated PDF"); e=QPushButton("Export Professional Excel Workbook"); e.clicked.connect(self.export_xlsx); p=QPushButton("Export Consolidated PDF Report"); p.clicked.connect(self.export_pdf); l.addWidget(e); l.addWidget(p); self.report_status=QLabel("Reports include Desi Fintax branding, aggregate amounts, exceptions, filing status and evidence index."); l.addWidget(self.report_status); l.addStretch(); return page
    def settings_page(self):
        page,l=self.page("Settings","The application works through the GST Portal without an API subscription"); g=QGroupBox("GST Portal Automation"); f=QFormLayout(g); self.portal_url=QLineEdit(self.repo.setting("portal_url",GST_PORTAL_URL)); f.addRow("Official Search Page",self.portal_url); save=QPushButton("Save Portal Setting"); save.clicked.connect(lambda:self.repo.set_setting("portal_url",self.portal_url.text().strip())); f.addRow("",save); l.addWidget(g); note=QLabel("You do not need an API provider. Public/browser verification is the default. Add GSP details only if you later purchase an authorised service."); note.setWordWrap(True); note.setStyleSheet("background:#E9F7EF;padding:10px;border-radius:5px"); l.addWidget(note); self.api_toggle=QCheckBox("I have purchased authorised GSP/API access"); l.addWidget(self.api_toggle)
        self.api_group=QGroupBox("Optional Authorised GSP / API Provider"); af=QFormLayout(self.api_group); saved=self.secrets.load(); self.api_fields={}
        for key,label in (("provider","Provider Name"),("base_url","API Base URL"),("client_id","Client ID"),("client_secret","Client Secret"),("username","Username"),("password","Password / Token")):
            w=QLineEdit(saved.get(key,"")); self.api_fields[key]=w
            if key in ("client_secret","password"):w.setEchoMode(QLineEdit.Password)
            af.addRow(label,w)
        actions=QHBoxLayout(); api_save=QPushButton("Save Encrypted Settings"); api_save.clicked.connect(self.save_api); api_test=QPushButton("Test Connection"); api_test.clicked.connect(self.test_api); actions.addWidget(api_save); actions.addWidget(api_test); af.addRow("",actions); self.api_group.setVisible(False); self.api_toggle.toggled.connect(self.api_group.setVisible); l.addWidget(self.api_group); about=QLabel(f"{APP_NAME}\n{PROFESSIONAL_NAME}\nMobile: {MOBILE} | WhatsApp: {WHATSAPP}\nDatabase: {database_path()}"); l.addWidget(about); l.addStretch(); return page
    def require_project(self):
        if self.project_id:return True
        QMessageBox.information(self,"Select Project","Create or open a verification project first."); self.navigate(1); return False
    def project(self):return self.repo.get_project(self.project_id) if self.project_id else None
    def project_credentials(self,project_id=None):
        data=self.secrets.load(); return data.get("project_credentials",{}).get(str(project_id or self.project_id),{})
    def save_project_credentials(self,project_id,credentials):
        data=self.secrets.load(); projects=data.setdefault("project_credentials",{}); projects[str(project_id)]={"username":credentials.get("username",""),"password":credentials.get("password","")}; self.secrets.save(data)
    def new_project(self):
        d=ProjectDialog(self)
        if d.exec():self.project_id=self.repo.create_project(d.project()); self.save_project_credentials(self.project_id,d.credentials()); self.refresh_all(); self.navigate(0)
    def edit_project(self):
        row=self.projects.currentRow()
        project_id=int(self.projects.item(row,0).text()) if row>=0 else self.project_id
        if not project_id:QMessageBox.information(self,"Select Project","Select the client project to edit first."); return
        project=self.repo.get_project(project_id); d=ProjectDialog(self,project,self.project_credentials(project_id))
        if d.exec():self.repo.update_project(project_id,d.project()); self.save_project_credentials(project_id,d.credentials()); self.project_id=project_id; self.refresh_all(); QMessageBox.information(self,"Project Updated","Client details and encrypted GST Portal login were saved.")
    def select_project(self):
        row=self.projects.currentRow()
        if row>=0:self.project_id=int(self.projects.item(row,0).text()); self.clear_project_tables(); self.refresh_all(); self.navigate(0)
    def refresh_projects(self):self.populate(self.projects,[[r[k] for k in ("id","name","client_name","client_gstin","financial_year","notice_reference","created_at")] for r in self.repo.list_projects()])
    def import_excel(self):
        if not self.require_project():return
        path,_=QFileDialog.getOpenFileName(self,"Import Excel / GSTR-2A","","Excel (*.xlsx *.xlsm *.xls)")
        if path:
            try:
                r=ExcelImporter().import_file(path); a=aggregate_invoices(r.invoices); meta=self.current_import_meta(Path(path).name,r.duplicates,r.sheets); self.repo.import_records(self.project_id,r.invoices,a,r.invalid,meta); self.verify_fy.setCurrentText(meta["financial_year"]); self.verify_period.setCurrentText(meta["tax_period"])
                invalid_note=(" Invalid: "+", ".join(f"{x[0]} ({x[4]} row {x[5]})" for x in r.invalid)) if r.invalid else " No invalid GSTIN was found."
                self.import_status.setText(f"Imported {len(r.invoices)} rows for {meta['financial_year']} / {meta['tax_period']}; {len(a)} unique GSTINs; {r.duplicates} duplicate occurrences.{invalid_note}"); self.refresh_all()
            except Exception as exc:self.error("Excel import failed",exc)
    def import_pdf(self):
        if not self.require_project():return
        path,_=QFileDialog.getOpenFileName(self,"Import PDF","","PDF (*.pdf)")
        if path:
            try:
                i,x=PDFImporter().import_file(path); meta=self.current_import_meta(Path(path).name,0,("PDF",)); self.repo.import_records(self.project_id,i,aggregate_invoices(i),x,meta); self.verify_fy.setCurrentText(meta["financial_year"]); self.verify_period.setCurrentText(meta["tax_period"]); self.import_status.setText(f"Extracted {len(i)} valid GSTINs for {meta['financial_year']} / {meta['tax_period']}; {len(x)} invalid values."); self.refresh_all()
            except Exception as exc:self.error("PDF import failed",exc)
    def import_bulk(self):
        if not self.require_project():return
        valid,invalid=parse_bulk(self.bulk.toPlainText()); invoices=[Invoice(gstin=g,source_file="Manual / Bulk Paste",source_sheet="Paste") for g in valid]; meta=self.current_import_meta("Manual / Bulk Paste",0,("Paste",)); self.repo.import_records(self.project_id,invoices,aggregate_invoices(invoices),[(x.normalized,x.normalized,x.reason,"Manual / Bulk Paste","Paste",0) for x in invalid],meta); self.bulk.clear(); self.import_status.setText(f"Added {len(valid)} valid GSTINs for {meta['financial_year']} / {meta['tax_period']}; excluded {len(invalid)} invalid entries."); self.refresh_all()
    def save_template(self):
        source=resource_path("templates/Desi_Fintax_GSTIN_Import_Template.xlsx"); path,_=QFileDialog.getSaveFileName(self,"Save Template","Desi_Fintax_GSTIN_Import_Template.xlsx","Excel (*.xlsx)")
        if path:
            try:Path(path).write_bytes(source.read_bytes())
            except Exception as exc:self.error("Template save failed",exc)
    def selected_gstin(self):
        row=self.queue.currentRow(); return self.queue.item(row,0).text() if row>=0 else ""
    def open_login(self):
        if not self.require_project():return
        try:
            if self.provider is None:self.provider=PortalBrowserProvider(self.portal_url.text().strip() or GST_PORTAL_URL)
            credentials=self.project_credentials()
            if not credentials.get("username") or not credentials.get("password"):
                self.portal_status.setText("GST login ID/password are missing. Open Projects > Edit Project / GST Login and save them."); self.navigate(1); return
            self.portal_busy=True; status=self.provider.open_login(credentials["username"],credentials["password"]); self.handle_login_status(status); self.portal_timer.start()
        except Exception as exc:self.portal_failure("GST login could not start",exc,self.selected_gstin())
    def handle_login_status(self,status):
        if status=="LOGGED_IN":
            self.portal_busy=False; self.portal_timer.stop(); self.portal_status.setText("GST Portal login completed. Continuing the verification queue automatically...")
            if self.login_resume_gstin:self.select_gstin(self.login_resume_gstin); QTimer.singleShot(250,self.start_portal)
        elif status in ("LOGIN_CAPTCHA_REQUIRED","CAPTCHA_ERROR"):
            self.portal_status.setText(self.provider.last_error or "Login details were entered. Read the CAPTCHA shown in Edge, type it in the CAPTCHA box here, then click Submit CAPTCHA & Continue."); self.captcha_input.setFocus()
        elif status=="LOGIN_ERROR":
            self.portal_busy=False; self.portal_timer.stop(); self.portal_status.setText(self.provider.last_error or "GST Portal did not accept the login. Check the client login ID/password in Projects and click Login / Continue.")
        elif status=="CREDENTIALS_REQUIRED":self.portal_status.setText("Save the client GST login ID and password under Projects > Edit Project / GST Login.")
        else:self.portal_status.setText("Login details entered. Waiting for GST Portal to complete login or request CAPTCHA...")
    def start_batch(self):
        if not self.require_project():return
        self.batch_paused=False
        gstin=self.selected_gstin()
        row=self.queue.currentRow()
        if not gstin or row<0 or self.queue.item(row,6).text() not in ("Pending","Retry","Portal Error","Timed Out"):
            self.select_next_pending(); gstin=self.selected_gstin()
        if not gstin:self.portal_status.setText("No pending GSTIN remains in this client project."); return
        self.start_portal()
    def start_portal(self):
        if not self.require_project():return
        if self.batch_paused:QMessageBox.information(self,"Batch Paused","Click Resume Batch before starting another GSTIN."); return
        gstin=self.selected_gstin()
        if not gstin:return
        try:
            if self.provider is None:self.provider=PortalBrowserProvider(self.portal_url.text().strip() or GST_PORTAL_URL)
            search_fy=self.verify_fy.currentText().strip() or self.project()["financial_year"] or "CURRENT"; self.portal_busy=True; self.repo.set_queue_status(self.project_id,gstin,"Searching"); self.portal_status.setText(f"Searching {gstin} automatically for {search_fy}..."); status=self.provider.start_verification(gstin,search_fy)
            if status=="LOGIN_REQUIRED":
                self.login_resume_gstin=gstin; self.repo.set_queue_status(self.project_id,gstin,"Waiting for Login"); self.portal_status.setText("GST Portal requires login. Entering the saved client login ID and password automatically..."); self.open_login(); return
            elif status=="CAPTCHA_REQUIRED":
                self.repo.set_queue_status(self.project_id,gstin,"Waiting for CAPTCHA"); self.portal_status.setText(f"{gstin} was entered automatically. Read the CAPTCHA shown in Edge, type it in the CAPTCHA box in this software, then click Submit CAPTCHA & Continue. Everything after that is automatic."); self.captcha_input.setFocus(); self.portal_timer.start()
            elif status=="RESULT_READY":QTimer.singleShot(100,self.capture_portal)
            elif status=="PORTAL_ERROR":
                self.portal_busy=False; message=self.provider.last_error or "GST Portal rejected the request"; self.repo.set_queue_status(self.project_id,gstin,"Portal Error",message); self.portal_status.setText(f"{message}. Click Retry Selected Now; if the session expired, login will restart automatically.")
            else:
                self.repo.set_queue_status(self.project_id,gstin,"Waiting for Result"); self.portal_status.setText(f"{gstin} submitted. Waiting for GST Portal result; capture and PDF are automatic."); self.portal_timer.start()
            self.refresh_queue()
        except Exception as exc:self.portal_failure("GST Portal search could not start",exc,gstin)
    def submit_captcha(self):
        if not self.provider:QMessageBox.information(self,"No Portal Session","Click Login / Continue or Start Automatic Verification first."); return
        value=self.captcha_input.text().strip()
        if not value:QMessageBox.information(self,"Enter CAPTCHA","Type the CAPTCHA displayed in the GST Portal Edge window first."); return
        try:
            status=self.provider.submit_after_captcha(value); self.captcha_input.clear()
            if status in ("LOGGED_IN","LOGIN_WAITING","LOGIN_ERROR","LOGIN_CAPTCHA_REQUIRED","CAPTCHA_ERROR"):self.handle_login_status(status)
            elif status=="RESULT_READY":QTimer.singleShot(100,self.capture_portal)
            elif status in ("CAPTCHA_EMPTY","NO_CAPTCHA_FIELD"):self.portal_status.setText("The CAPTCHA field is no longer visible. Wait briefly or click Retry Selected Now.")
            else:self.portal_status.setText("CAPTCHA submitted. Waiting for the GST Portal result..."); self.portal_timer.start()
        except Exception as exc:self.portal_failure("CAPTCHA could not be submitted",exc,self.selected_gstin() or getattr(self.provider,"gstin",""))
    def poll_portal(self):
        if not self.provider or self.batch_paused or not self.portal_busy:return
        status=self.provider.wait_status()
        if status in ("LOGGED_IN","LOGIN_WAITING","LOGIN_ERROR","LOGIN_CAPTCHA_REQUIRED","CAPTCHA_ERROR"):self.handle_login_status(status)
        elif status=="LOGIN_REQUIRED":
            self.portal_timer.stop(); self.portal_busy=False; self.portal_status.setText("GST Portal session expired. Click Login / Continue; saved login details will be entered automatically.")
        elif status=="CAPTCHA_REQUIRED":
            self.portal_status.setText("CAPTCHA is waiting in Edge. Type it in the CAPTCHA box here and click Submit CAPTCHA & Continue."); self.captcha_input.setFocus()
        elif status=="RESULT_READY":self.portal_timer.stop(); self.capture_portal()
        elif status=="PORTAL_ERROR":
            self.portal_timer.stop(); self.portal_busy=False; gstin=self.provider.gstin; message=self.provider.last_error or "GST Portal returned an error"; self.repo.set_queue_status(self.project_id,gstin,"Portal Error",message); self.portal_status.setText(f"{message}. Click Retry Selected Now."); self.refresh_queue(); self.select_gstin(gstin)
        elif status=="TIMEOUT":
            self.portal_timer.stop(); self.portal_busy=False; gstin=self.provider.gstin; message="GST Portal did not return a result within three minutes"; self.repo.set_queue_status(self.project_id,gstin,"Timed Out",message); self.portal_status.setText(f"{message}. Click Retry Selected Now."); self.refresh_queue(); self.select_gstin(gstin)
    def capture_portal(self):
        if not self.provider or not self.require_project() or self.capture_in_progress or not self.portal_busy:return
        self.capture_in_progress=True
        try:
            self.portal_timer.stop(); r=self.provider.capture_result(); fy=self.verify_fy.currentText().strip() or self.project()["financial_year"]; folder=data_root()/"projects"/str(self.project_id)/"evidence"; path,digest=self.provider.save_evidence(folder,dated=any(row["gstin"]==r.gstin for row in self.repo.evidence_rows(self.project_id))); vid=self.repo.save_verification(self.project_id,fy,r); self.repo.add_evidence(self.project_id,vid,r.gstin,fy,path.name,str(path),datetime.now().astimezone().isoformat(timespec="seconds"),digest); self.repo.set_queue_status(self.project_id,r.gstin,"Verified"); self.portal_busy=False; self.refresh_all(); has_next=self.select_next_pending()
            if not self.batch_paused and has_next:self.portal_status.setText(f"Verified {r.gstin}. Evidence saved as {path.name}. Moving to the next supplier..."); QTimer.singleShot(500,self.start_portal)
            else:self.portal_status.setText(f"Project queue completed. Verified {r.gstin}; evidence saved as {path.name}. No pending GSTIN remains.")
        except Exception as exc:self.portal_failure("GST Portal result could not be captured",exc,getattr(self.provider,"gstin",self.selected_gstin()))
        finally:self.capture_in_progress=False
    def manual_verification(self):
        if not self.require_project():return
        gstin=self.selected_gstin()
        if gstin:
            d=ManualVerificationDialog(gstin,self)
            if d.exec():self.repo.save_verification(self.project_id,self.project()["financial_year"],d.result()); self.repo.set_queue_status(self.project_id,gstin,"Verified - Manual"); self.refresh_all(); self.select_next_pending()
    def set_queue(self,status):
        gstin=self.selected_gstin()
        if gstin:self.repo.set_queue_status(self.project_id,gstin,status); self.refresh_queue(); self.select_next_pending()
    def pause_batch(self):self.batch_paused=True; self.portal_timer.stop(); self.portal_status.setText("Verification paused. Current browser session is retained.")
    def resume_batch(self):
        self.batch_paused=False; self.portal_status.setText("Verification resumed. Checking the current GST Portal state...")
        if self.provider and self.portal_busy:
            try:
                status=self.provider.wait_status()
                if status in ("RESULT_READY","CAPTCHA_REQUIRED","LOGGED_IN","LOGIN_WAITING","LOGIN_CAPTCHA_REQUIRED"):self.portal_timer.start(); self.poll_portal(); return
            except Exception:LOG.exception("Existing portal session could not resume")
        self.portal_busy=False; self.start_batch()
    def retry_selected(self):
        if not self.require_project():return
        gstin=self.selected_gstin() or getattr(self.provider,"gstin","")
        if not gstin:self.select_next_pending(); gstin=self.selected_gstin()
        if not gstin:self.portal_status.setText("No GSTIN is available to retry."); return
        self.portal_timer.stop(); self.batch_paused=False; self.portal_busy=False
        if self.provider:
            try:self.provider.reset_current(restart_browser=True)
            except Exception:LOG.exception("Portal reset failed")
        self.repo.set_queue_status(self.project_id,gstin,"Pending"); self.refresh_queue(); self.select_gstin(gstin); self.portal_status.setText(f"Restarting {gstin} from a clean portal state..."); QTimer.singleShot(100,self.start_portal)
    def reset_project_queue(self):
        if not self.require_project():return
        self.portal_timer.stop(); self.portal_busy=False; self.batch_paused=False
        if self.provider:
            try:self.provider.reset_current(restart_browser=True)
            except Exception:LOG.exception("Portal reset failed")
        self.repo.reset_project_queue(self.project_id); self.refresh_queue(); self.select_next_pending(); self.portal_status.setText("All unverified GSTINs in this client project were reset to Pending. Click Start Automatic Verification.")
    def select_gstin(self,gstin):
        for row in range(self.queue.rowCount()):
            if self.queue.item(row,0).text()==gstin:self.queue.selectRow(row); self.queue.scrollToItem(self.queue.item(row,0)); return True
        return False
    def select_next_pending(self):
        for row in range(self.queue.rowCount()):
            if self.queue.item(row,6).text() in ("Pending","Retry"):
                self.queue.selectRow(row); self.queue.scrollToItem(self.queue.item(row,0)); return True
        self.queue.clearSelection(); self.queue.setCurrentCell(-1,-1); return False
    @staticmethod
    def friendly_portal_error(exc):
        text=str(exc)
        low=text.lower()
        if "interrupted by another navigation" in low:return "GST Portal redirected to another page. The session has been reset; click Retry Selected Now."
        if "timeout" in low:return "GST Portal did not respond in time. Check the portal window, then click Retry Selected Now."
        if "scheduled downtime" in low or "503" in low:return "GST Portal is temporarily unavailable or under scheduled downtime. Retry after services resume."
        if "access denied" in low:return "GST Portal session expired. Click Login / Continue and retry."
        if "search box was not found" in low:return "GST search page did not load. Login again or click Retry Selected Now."
        return text.split("Call log:",1)[0].strip()
    def portal_failure(self,title,exc,gstin=""):
        LOG.exception(title); self.portal_timer.stop(); self.portal_busy=False
        message=self.friendly_portal_error(exc)
        if gstin and self.project_id:self.repo.set_queue_status(self.project_id,gstin,"Retry",message)
        self.portal_status.setText(f"{message} The GSTIN remains available for retry."); self.refresh_queue()
        if gstin:self.select_gstin(gstin)
    def save_api(self):
        data=self.secrets.load(); data.update({k:v.text().strip() for k,v in self.api_fields.items()}); self.secrets.save(data); QMessageBox.information(self,"API Settings","Provider credentials were encrypted and saved locally.")
    def test_api(self):
        url=self.api_fields["base_url"].text().strip()
        if not url:QMessageBox.information(self,"API Settings","Enter the documented authorised provider base URL first."); return
        try:
            request=urllib.request.Request(url,method="HEAD",headers={"User-Agent":APP_NAME}); response=urllib.request.urlopen(request,timeout=15); QMessageBox.information(self,"Connection Test",f"Provider endpoint responded with HTTP {response.status}. Authentication-specific testing occurs through the provider adapter.")
        except Exception as exc:self.error("API connection test failed",exc)
    def export_xlsx(self):
        if not self.require_project():return
        folder=data_root()/"projects"/str(self.project_id)/"reports"; folder.mkdir(parents=True,exist_ok=True); path,_=QFileDialog.getSaveFileName(self,"Export Excel",str(folder/f"Desi_Fintax_GSTN_Verification_{self.project_id}.xlsx"),"Excel (*.xlsx)")
        if path:
            try:export_excel(path,self.project(),self.repo.supplier_rows(self.project_id),self.repo.invoice_rows(self.project_id),self.repo.return_rows(self.project_id),self.repo.evidence_rows(self.project_id),self.repo.invalid_rows(self.project_id),self.repo.import_log(self.project_id),self.repo.period_summary(self.project_id)); self.report_status.setText(f"Saved consolidated and period-wise workbook: {path}")
            except Exception as exc:self.error("Excel export failed",exc)
    def export_pdf(self):
        if not self.require_project():return
        folder=data_root()/"projects"/str(self.project_id)/"reports"; folder.mkdir(parents=True,exist_ok=True); path,_=QFileDialog.getSaveFileName(self,"Export PDF",str(folder/f"Desi_Fintax_GSTN_Verification_{self.project_id}.pdf"),"PDF (*.pdf)")
        if path:
            try:export_pdf(path,self.project(),self.repo.supplier_rows(self.project_id),self.repo.return_rows(self.project_id),self.repo.evidence_rows(self.project_id)); self.report_status.setText(f"Saved: {path}")
            except Exception as exc:self.error("PDF export failed",exc)
    def backup(self):
        path,_=QFileDialog.getSaveFileName(self,"Create Backup",f"Desi_Fintax_Backup_{datetime.now():%Y%m%d_%H%M}.zip","ZIP (*.zip)")
        if path:
            try:create_backup(database_path(),Path(path),data_root()/"projects"); QMessageBox.information(self,"Backup Complete",f"Created and integrity-tested:\n{path}")
            except Exception as exc:self.error("Backup failed",exc)
    def restore(self):
        path,_=QFileDialog.getOpenFileName(self,"Restore Backup","","ZIP (*.zip)")
        if path and QMessageBox.warning(self,"Confirm Restore","Current data will be replaced after integrity checks. Continue?",QMessageBox.Yes|QMessageBox.No)==QMessageBox.Yes:
            try:restore_backup(Path(path),database_path(),data_root()/"projects"); self.repo=Repository(); self.project_id=None; self.refresh_all(); QMessageBox.information(self,"Restore Complete","Backup restored.")
            except Exception as exc:self.error("Restore failed",exc)
    def refresh_all(self):
        self.refresh_projects()
        self.update_project_banner()
        if not self.project_id:self.clear_project_tables(); return
        self.sync_period_context(); self.refresh_queue(); self.refresh_results(); self.refresh_invoices(); self.refresh_filings(); self.refresh_exceptions(); self.refresh_evidence(); self.refresh_dashboard()

    def sync_period_context(self):
        if getattr(self,"_context_project_id",None)==self.project_id:return
        project=self.project(); latest=self.repo.latest_import_context(self.project_id)
        fy=(latest["financial_year"] if latest and latest["financial_year"] else project["financial_year"]) or self.financial_years()[0]
        period=(latest["tax_period"] if latest and latest["tax_period"] else project["tax_period"]) or "Annual"
        self.import_fy.setCurrentText(fy); self.import_period.setCurrentText(period); self.verify_fy.setCurrentText(fy); self.verify_period.setCurrentText(period); self._context_project_id=self.project_id
    def update_project_banner(self):
        project=self.project()
        if not project:self.project_banner.setText("NO CLIENT PROJECT SELECTED - open Projects to begin"); return
        self.project_banner.setText(f"ACTIVE CLIENT: {project['client_name'] or 'Unnamed Client'}   |   PROJECT: {project['name']}   |   FY: {project['financial_year'] or 'Current'}   |   PROJECT ID: {project['id']}")
    def clear_project_tables(self):
        for name in ("dashboard","queue","results","filings","invoices","exceptions","evidence"):
            table=getattr(self,name,None)
            if table is not None:table.setRowCount(0)
    def refresh_queue(self):
        if not self.project_id:return
        term=self.queue_search.text().lower(); fy=self.verify_fy.currentText().strip() or self.project()["financial_year"]; period=self.verify_period.currentText().strip(); context=fy+(f" / {period}" if period and period!="Annual" else ""); rows=[]
        for r in self.repo.supplier_rows(self.project_id):
            if term and term not in (r["gstin"]+" "+(r["supplier_name"] or "")).lower():continue
            rows.append([r["gstin"],r["supplier_name"],r["invoice_count"],context,r["registration_status"] or "",r["verified_at"] or "",r["queue_status"] or ("Verified" if r["verified_at"] else "Pending"),r["last_error"] or ""])
        self.populate(self.queue,rows)
    def refresh_results(self):
        if not self.project_id:return
        term=self.result_search.text().lower(); filt=self.result_filter.currentText(); rows=[]
        for r in self.repo.supplier_rows(self.project_id):
            hay=" ".join(str(r[k] or "") for k in ("gstin","supplier_name","legal_name","trade_name","registration_status")).lower()
            if term and term not in hay:continue
            if filt in ("Active","Cancelled","Suspended") and filt.lower() not in str(r["registration_status"] or "").lower():continue
            if filt=="Pending" and r["verified_at"]:continue
            if filt=="Missing GSTR-3B" and not int(r["not_filed_count"] or 0):continue
            if filt=="Delayed" and not int(r["delayed_count"] or 0):continue
            rows.append([r[k] or "" for k in ("gstin","supplier_name","legal_name","trade_name","registration_status","registration_date","cancellation_date","invoice_count","taxable_value","igst","cgst","sgst","cess","total_gst","invoice_value","notice_amount","expected_count","filed_count","not_filed_count","delayed_count","verified_at","verification_remarks")])
        self.populate(self.results,rows)
    def refresh_invoices(self):
        if not self.project_id:return
        term=self.invoice_search.text().lower(); rows=[]
        for r in self.repo.invoice_rows(self.project_id):
            if term and term not in (str(r["gstin"])+" "+str(r["supplier_name"])+" "+str(r["invoice_number"])).lower():continue
            rows.append([r[k] or "" for k in ("gstin","supplier_name","invoice_number","invoice_date","taxable_value","igst","cgst","sgst","cess","total_gst","invoice_value","notice_amount","source_file","source_sheet","row_number","remarks")])
        self.populate(self.invoices,rows)
    def refresh_filings(self):
        if self.project_id:self.populate(self.filings,[[r[k] or "" for k in ("gstin","financial_year","return_type","tax_period","frequency","due_date","filing_status","filing_date","delay_days","arn","remarks")] for r in self.repo.return_rows(self.project_id)])
    def refresh_exceptions(self):
        if not self.project_id:return
        rows=[["Invalid GSTIN",r["raw_value"],"",r["reason"],"",f"{r['source_file'] or 'Import'} / {r['source_sheet'] or ''} / row {r['row_number'] or '-'}"] for r in self.repo.invalid_rows(self.project_id)]
        for r in self.repo.supplier_rows(self.project_id):
            status=str(r["registration_status"] or "")
            if any(x in status.lower() for x in ("cancel","suspend")):rows.append(["Registration",r["gstin"],r["supplier_name"],status,r["notice_amount"],r["verified_at"]])
            if int(r["not_filed_count"] or 0):rows.append(["Missing GSTR-3B",r["gstin"],r["supplier_name"],f"{r['not_filed_count']} applicable period(s)",r["notice_amount"],r["verified_at"]])
            if int(r["delayed_count"] or 0):rows.append(["Delayed GSTR-3B",r["gstin"],r["supplier_name"],f"{r['delayed_count']} delayed period(s)",r["notice_amount"],r["verified_at"]])
            if not r["verified_at"]:rows.append(["Manual Review",r["gstin"],r["supplier_name"],"Portal verification pending",r["notice_amount"],""])
        self.populate(self.exceptions,rows)
    def refresh_evidence(self):
        if self.project_id:self.populate(self.evidence,[[r[k] or "" for k in ("gstin","financial_year","filename","path","captured_at","sha256")] for r in self.repo.evidence_rows(self.project_id)])
    def refresh_dashboard(self):
        rows=self.repo.supplier_rows(self.project_id); total=len(rows); verified=sum(bool(r["verified_at"]) for r in rows); issues=sum(any(x in str(r["registration_status"] or "").lower() for x in ("cancel","suspend")) or int(r["not_filed_count"] or 0)>0 or int(r["delayed_count"] or 0)>0 for r in rows); values={"Suppliers":total,"Pending":total-verified,"Issues":issues,"Notice Amount":f"INR {sum(float(r['notice_amount'] or 0) for r in rows):,.0f}"}
        for k,v in values.items():self.metrics[k].setText(str(v))
        self.progress.setValue(round(verified*100/total) if total else 0); self.populate(self.dashboard,[[r["gstin"],r["legal_name"] or r["supplier_name"],r["registration_status"] or "Pending",r["invoice_count"],r["total_gst"],r["notice_amount"],"Verified" if r["verified_at"] else "Pending"] for r in rows])
    @staticmethod
    def populate(table,data):
        table.setSortingEnabled(False); table.setRowCount(len(data))
        for i,row in enumerate(data):
            for j,value in enumerate(row):table.setItem(i,j,QTableWidgetItem(str(value if value is not None else "")))
        table.resizeColumnsToContents(); table.setSortingEnabled(True)
    def error(self,title,exc):LOG.exception(title); QMessageBox.critical(self,title,f"{exc}\n\nTechnical details were written to the application log.")
    def closeEvent(self,event):
        if self.provider:
            try:self.provider.close()
            except Exception:LOG.exception("Browser close failed")
        event.accept()

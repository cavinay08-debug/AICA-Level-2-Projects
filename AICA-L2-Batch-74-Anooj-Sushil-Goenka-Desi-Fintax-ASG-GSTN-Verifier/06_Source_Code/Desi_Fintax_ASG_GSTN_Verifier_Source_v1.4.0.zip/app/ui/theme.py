STYLESHEET="""
QWidget{font-family:'Segoe UI';font-size:10pt;color:#243B53} QMainWindow,QStackedWidget,QDialog{background:#F4F7FA}
#Sidebar{background:#102A43;min-width:215px;max-width:215px} #Brand{color:white;font-size:16pt;font-weight:700;padding:18px 12px 4px} #Contact{color:#BCCCDC;padding:2px 12px 14px;font-size:8.5pt}
QPushButton[nav='true']{background:transparent;color:#D9E2EC;border:0;padding:10px 14px;text-align:left} QPushButton[nav='true']:hover,QPushButton[nav='true']:checked{background:#243B53;color:white;border-left:4px solid #C79A3B}
QPushButton{background:#102A43;color:white;border:0;border-radius:5px;padding:8px 14px;font-weight:600} QPushButton:hover{background:#243B53} QPushButton[secondary='true']{background:#D9E2EC;color:#102A43}
QLineEdit,QComboBox,QTextEdit,QDateEdit,QSpinBox{background:white;border:1px solid #BCCCDC;border-radius:4px;padding:6px} QTableWidget{background:white;alternate-background-color:#F5F7FA;gridline-color:#D9E2EC;border:1px solid #D9E2EC} QHeaderView::section{background:#102A43;color:white;padding:7px;border:0;font-weight:600}
QGroupBox{font-weight:700;color:#102A43;border:1px solid #D9E2EC;border-radius:7px;margin-top:12px;padding-top:12px;background:white} QGroupBox::title{subcontrol-origin:margin;left:12px;padding:0 5px} QLabel[metric='true']{font-size:22pt;font-weight:700;color:#102A43} QLabel[muted='true']{color:#627D98} QProgressBar{border:1px solid #BCCCDC;border-radius:4px;text-align:center;background:white} QProgressBar::chunk{background:#C79A3B}
"""

import json,os
from pathlib import Path
from cryptography.fernet import Fernet
from app.config import data_root

class SecretStore:
    def __init__(self,folder:Path|None=None):self.folder=folder or data_root(); self.key_path=self.folder/".credentials.key"; self.store_path=self.folder/".credentials.enc"
    def _key(self):
        if self.key_path.exists():return self.key_path.read_bytes()
        key=Fernet.generate_key(); self.key_path.write_bytes(key)
        try:os.chmod(self.key_path,0o600)
        except OSError:pass
        return key
    def save(self,secrets:dict[str,str]):self.store_path.write_bytes(Fernet(self._key()).encrypt(json.dumps(secrets).encode()))
    def load(self):return {} if not self.store_path.exists() else json.loads(Fernet(self._key()).decrypt(self.store_path.read_bytes()).decode())
    def clear(self):
        if self.store_path.exists():self.store_path.unlink()

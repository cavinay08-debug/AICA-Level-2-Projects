"""Desi Fintax ASG GSTN Verifier."""

__version__ = "1.4.0"

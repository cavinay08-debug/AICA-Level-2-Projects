from __future__ import annotations

import sqlite3
from pathlib import Path

from app.config import database_path
from app.models import Invoice, Project, SupplierAggregate, VerificationResult

SCHEMA = """
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS schema_version(version INTEGER NOT NULL);
INSERT INTO schema_version(version) SELECT 4 WHERE NOT EXISTS(SELECT 1 FROM schema_version);
CREATE TABLE IF NOT EXISTS projects(id INTEGER PRIMARY KEY,name TEXT NOT NULL,client_name TEXT,client_gstin TEXT,financial_year TEXT,tax_period TEXT,notice_type TEXT,notice_reference TEXT,notice_date TEXT,jurisdiction TEXT,remarks TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS imported_files(id INTEGER PRIMARY KEY,project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,filename TEXT,file_type TEXT,sheet_name TEXT,total_rows INTEGER,gstins_found INTEGER,unique_gstins INTEGER,duplicates INTEGER,invalid_gstins INTEGER,financial_year TEXT,period_type TEXT DEFAULT 'Annual',tax_period TEXT DEFAULT 'Annual',imported_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS suppliers(id INTEGER PRIMARY KEY,project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,gstin TEXT NOT NULL,supplier_name TEXT,invoice_count INTEGER DEFAULT 0,taxable_value TEXT DEFAULT '0',igst TEXT DEFAULT '0',cgst TEXT DEFAULT '0',sgst TEXT DEFAULT '0',cess TEXT DEFAULT '0',total_gst TEXT DEFAULT '0',invoice_value TEXT DEFAULT '0',notice_amount TEXT DEFAULT '0',validation_status TEXT DEFAULT 'Valid',validation_reason TEXT,queue_status TEXT DEFAULT 'Pending',UNIQUE(project_id,gstin));
CREATE TABLE IF NOT EXISTS invoices(id INTEGER PRIMARY KEY,project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,gstin TEXT,supplier_name TEXT,invoice_number TEXT,invoice_date TEXT,taxable_value TEXT,igst TEXT,cgst TEXT,sgst TEXT,cess TEXT,total_gst TEXT,invoice_value TEXT,notice_amount TEXT,remarks TEXT,source_file TEXT,source_sheet TEXT,row_number INTEGER,imported_file_id INTEGER REFERENCES imported_files(id));
CREATE TABLE IF NOT EXISTS verifications(id INTEGER PRIMARY KEY,project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,gstin TEXT NOT NULL,legal_name TEXT,trade_name TEXT,registration_status TEXT,registration_date TEXT,cancellation_date TEXT,taxpayer_type TEXT,constitution TEXT,state_jurisdiction TEXT,centre_jurisdiction TEXT,nature_of_business TEXT,principal_state TEXT,source TEXT,verified_at TEXT,remarks TEXT);
CREATE TABLE IF NOT EXISTS return_filings(id INTEGER PRIMARY KEY,verification_id INTEGER NOT NULL REFERENCES verifications(id) ON DELETE CASCADE,financial_year TEXT,return_type TEXT DEFAULT 'GSTR-3B',tax_period TEXT,frequency TEXT,due_date TEXT,filing_status TEXT,filing_date TEXT,delay_days INTEGER,arn TEXT,remarks TEXT);
CREATE TABLE IF NOT EXISTS evidence(id INTEGER PRIMARY KEY,project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,verification_id INTEGER REFERENCES verifications(id),gstin TEXT,financial_year TEXT,filename TEXT,path TEXT,captured_at TEXT,sha256 TEXT);
CREATE TABLE IF NOT EXISTS invalid_gstins(id INTEGER PRIMARY KEY,project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,raw_value TEXT,normalized_value TEXT,reason TEXT,source_file TEXT,source_sheet TEXT,row_number INTEGER,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS app_settings(key TEXT PRIMARY KEY,value TEXT);
CREATE TABLE IF NOT EXISTS audit_logs(id INTEGER PRIMARY KEY,action TEXT,entity_type TEXT,entity_id TEXT,details TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS idx_invoice_project_gstin ON invoices(project_id,gstin);
CREATE INDEX IF NOT EXISTS idx_verification_project_gstin ON verifications(project_id,gstin,verified_at);
"""

class ManagedConnection(sqlite3.Connection):
    """SQLite connection that commits/rolls back and always releases its Windows file handle."""
    def __exit__(self,exc_type,exc_value,traceback):
        try:return super().__exit__(exc_type,exc_value,traceback)
        finally:self.close()


class Repository:
    def __init__(self,path:str|Path|None=None):
        self.path=Path(path) if path else database_path(); self.path.parent.mkdir(parents=True,exist_ok=True); self.initialize()
    def connect(self):
        db=sqlite3.connect(self.path,factory=ManagedConnection); db.row_factory=sqlite3.Row; db.execute("PRAGMA foreign_keys=ON"); return db
    def initialize(self):
        with self.connect() as db:
            db.executescript(SCHEMA)
            columns={row[1] for row in db.execute("PRAGMA table_info(suppliers)")}
            if "queue_status" not in columns:db.execute("ALTER TABLE suppliers ADD COLUMN queue_status TEXT DEFAULT 'Pending'")
            if "last_error" not in columns:db.execute("ALTER TABLE suppliers ADD COLUMN last_error TEXT DEFAULT ''")
            if "last_attempt_at" not in columns:db.execute("ALTER TABLE suppliers ADD COLUMN last_attempt_at TEXT")
            if "retry_count" not in columns:db.execute("ALTER TABLE suppliers ADD COLUMN retry_count INTEGER DEFAULT 0")
            for table,column,declaration in (("imported_files","financial_year","TEXT"),("imported_files","period_type","TEXT DEFAULT 'Annual'"),("imported_files","tax_period","TEXT DEFAULT 'Annual'"),("invoices","imported_file_id","INTEGER REFERENCES imported_files(id)"),("invalid_gstins","source_sheet","TEXT")):
                existing={row[1] for row in db.execute(f"PRAGMA table_info({table})")}
                if column not in existing:db.execute(f"ALTER TABLE {table} ADD COLUMN {column} {declaration}")
            db.execute("UPDATE schema_version SET version=4")
    def create_project(self,project:Project)->int:
        fields=("name","client_name","client_gstin","financial_year","tax_period","notice_type","notice_reference","notice_date","jurisdiction","remarks")
        with self.connect() as db:
            cur=db.execute(f"INSERT INTO projects({','.join(fields)}) VALUES({','.join('?' for _ in fields)})",tuple(getattr(project,f) for f in fields)); project_id=int(cur.lastrowid); self._audit(db,"CREATE","project",project_id,project.name); return project_id
    def list_projects(self):
        with self.connect() as db:return list(db.execute("SELECT * FROM projects ORDER BY updated_at DESC,id DESC"))
    def get_project(self,project_id:int):
        with self.connect() as db:return db.execute("SELECT * FROM projects WHERE id=?",(project_id,)).fetchone()
    def update_project(self,project_id:int,project:Project):
        fields=("name","client_name","client_gstin","financial_year","tax_period","notice_type","notice_reference","notice_date","jurisdiction","remarks")
        with self.connect() as db:
            db.execute(f"UPDATE projects SET {','.join(f+'=?' for f in fields)},updated_at=CURRENT_TIMESTAMP WHERE id=?",tuple(getattr(project,f) for f in fields)+(project_id,)); self._audit(db,"UPDATE","project",project_id,project.name)
    def import_records(self,project_id:int,invoices:list[Invoice],aggregates:list[SupplierAggregate],invalid:list[tuple]=[],import_meta:dict|None=None):
        with self.connect() as db:
            meta=import_meta or {}; imported_file_id=None
            if meta:
                cur=db.execute("""INSERT INTO imported_files(project_id,filename,file_type,sheet_name,total_rows,gstins_found,unique_gstins,duplicates,invalid_gstins,financial_year,period_type,tax_period)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",(project_id,meta.get("filename",""),meta.get("file_type","Other"),meta.get("sheet_name",""),len(invoices),len(invoices),len(aggregates),int(meta.get("duplicates",0)),len(invalid),meta.get("financial_year",""),meta.get("period_type","Annual"),meta.get("tax_period","Annual")))
                imported_file_id=int(cur.lastrowid)
            fields=tuple(Invoice.__dataclass_fields__)
            db.executemany(f"INSERT INTO invoices(project_id,{','.join(fields)},imported_file_id) VALUES(?,{','.join('?' for _ in fields)},?)",[(project_id,*(str(getattr(i,f)) for f in fields),imported_file_id) for i in invoices])
            for a in aggregates:
                values=(a.supplier_name,a.invoice_count,*(str(getattr(a,f)) for f in ("taxable_value","igst","cgst","sgst","cess","total_gst","invoice_value","notice_amount")))
                db.execute("""INSERT INTO suppliers(project_id,gstin,supplier_name,invoice_count,taxable_value,igst,cgst,sgst,cess,total_gst,invoice_value,notice_amount) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(project_id,gstin) DO UPDATE SET supplier_name=COALESCE(NULLIF(excluded.supplier_name,''),suppliers.supplier_name),invoice_count=suppliers.invoice_count+excluded.invoice_count,taxable_value=CAST(suppliers.taxable_value AS REAL)+CAST(excluded.taxable_value AS REAL),igst=CAST(suppliers.igst AS REAL)+CAST(excluded.igst AS REAL),cgst=CAST(suppliers.cgst AS REAL)+CAST(excluded.cgst AS REAL),sgst=CAST(suppliers.sgst AS REAL)+CAST(excluded.sgst AS REAL),cess=CAST(suppliers.cess AS REAL)+CAST(excluded.cess AS REAL),total_gst=CAST(suppliers.total_gst AS REAL)+CAST(excluded.total_gst AS REAL),invoice_value=CAST(suppliers.invoice_value AS REAL)+CAST(excluded.invoice_value AS REAL),notice_amount=CAST(suppliers.notice_amount AS REAL)+CAST(excluded.notice_amount AS REAL)""",(project_id,a.gstin,*values))
            invalid_rows=[]
            for row in invalid:
                padded=tuple(row)+("","",0)
                raw,normalised,reason,source_file,source_sheet,row_number=padded[:6]
                invalid_rows.append((project_id,raw,normalised,reason,source_file,source_sheet,row_number))
            db.executemany("INSERT INTO invalid_gstins(project_id,raw_value,normalized_value,reason,source_file,source_sheet,row_number) VALUES(?,?,?,?,?,?,?)",invalid_rows); self._audit(db,"IMPORT","project",project_id,f"{len(invoices)} invoice rows; {len(aggregates)} GSTINs")
    def supplier_rows(self,project_id:int):
        query="""SELECT s.*,v.legal_name,v.trade_name,v.registration_status,v.registration_date,v.cancellation_date,v.source,v.verified_at,v.remarks AS verification_remarks,(SELECT COUNT(*) FROM return_filings rf WHERE rf.verification_id=v.id) expected_count,(SELECT COUNT(*) FROM return_filings rf WHERE rf.verification_id=v.id AND rf.filing_status LIKE 'Filed%') filed_count,(SELECT COUNT(*) FROM return_filings rf WHERE rf.verification_id=v.id AND rf.filing_status NOT LIKE 'Filed%') not_filed_count,(SELECT COUNT(*) FROM return_filings rf WHERE rf.verification_id=v.id AND rf.delay_days>0) delayed_count FROM suppliers s LEFT JOIN verifications v ON v.id=(SELECT vv.id FROM verifications vv WHERE vv.project_id=s.project_id AND vv.gstin=s.gstin ORDER BY vv.verified_at DESC,vv.id DESC LIMIT 1) WHERE s.project_id=? ORDER BY s.gstin"""
        with self.connect() as db:return list(db.execute(query,(project_id,)))
    def invoice_rows(self,project_id:int):
        with self.connect() as db:return list(db.execute("""SELECT i.*,f.financial_year AS import_financial_year,f.period_type AS import_period_type,f.tax_period AS import_tax_period,f.file_type AS import_type,f.filename AS import_filename
            FROM invoices i LEFT JOIN imported_files f ON f.id=i.imported_file_id WHERE i.project_id=? ORDER BY i.gstin,i.id""",(project_id,)))

    def import_log(self,project_id:int):
        with self.connect() as db:return list(db.execute("SELECT * FROM imported_files WHERE project_id=? ORDER BY imported_at,id",(project_id,)))

    def latest_import_context(self,project_id:int):
        with self.connect() as db:return db.execute("SELECT * FROM imported_files WHERE project_id=? ORDER BY imported_at DESC,id DESC LIMIT 1",(project_id,)).fetchone()

    def period_summary(self,project_id:int):
        with self.connect() as db:return list(db.execute("""SELECT COALESCE(f.financial_year,'Unspecified') financial_year,COALESCE(f.tax_period,'Unspecified') tax_period,COALESCE(f.period_type,'Legacy') period_type,i.gstin,MAX(NULLIF(i.supplier_name,'')) supplier_name,COUNT(*) invoice_count,
            SUM(CAST(i.taxable_value AS REAL)) taxable_value,SUM(CAST(i.igst AS REAL)) igst,SUM(CAST(i.cgst AS REAL)) cgst,SUM(CAST(i.sgst AS REAL)) sgst,SUM(CAST(i.cess AS REAL)) cess,SUM(CAST(i.total_gst AS REAL)) total_gst,SUM(CAST(i.invoice_value AS REAL)) invoice_value
            FROM invoices i LEFT JOIN imported_files f ON f.id=i.imported_file_id WHERE i.project_id=? GROUP BY f.financial_year,f.tax_period,f.period_type,i.gstin ORDER BY f.financial_year,f.tax_period,i.gstin""",(project_id,)))
    def save_verification(self,project_id:int,financial_year:str,result:VerificationResult)->int:
        fields=("gstin","legal_name","trade_name","status","registration_date","cancellation_date","taxpayer_type","constitution","state_jurisdiction","centre_jurisdiction","nature_of_business","principal_state","source","verified_at","remarks"); columns=tuple("registration_status" if f=="status" else f for f in fields)
        with self.connect() as db:
            cur=db.execute(f"INSERT INTO verifications(project_id,{','.join(columns)}) VALUES(?,{','.join('?' for _ in fields)})",(project_id,*(getattr(result,f) for f in fields))); verification_id=int(cur.lastrowid)
            for p in result.returns:db.execute("INSERT INTO return_filings(verification_id,financial_year,return_type,tax_period,frequency,due_date,filing_status,filing_date,delay_days,arn,remarks) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(verification_id,financial_year,p.return_type,p.period,p.frequency,p.due_date,p.filing_status,p.filing_date,p.delay_days,p.arn,p.remarks))
            self._audit(db,"VERIFY","supplier",result.gstin,result.source); return verification_id
    def return_rows(self,project_id:int):
        with self.connect() as db:return list(db.execute("SELECT v.gstin,rf.* FROM return_filings rf JOIN verifications v ON v.id=rf.verification_id WHERE v.project_id=? ORDER BY v.gstin,rf.id",(project_id,)))
    def evidence_rows(self,project_id:int):
        with self.connect() as db:return list(db.execute("SELECT * FROM evidence WHERE project_id=? ORDER BY captured_at DESC",(project_id,)))
    def add_evidence(self,project_id,verification_id,gstin,fy,filename,path,captured_at,sha256):
        with self.connect() as db:db.execute("INSERT INTO evidence(project_id,verification_id,gstin,financial_year,filename,path,captured_at,sha256) VALUES(?,?,?,?,?,?,?,?)",(project_id,verification_id,gstin,fy,filename,path,captured_at,sha256))
    def invalid_rows(self,project_id:int):
        with self.connect() as db:return list(db.execute("SELECT * FROM invalid_gstins WHERE project_id=?",(project_id,)))
    def setting(self,key,default=""):
        with self.connect() as db:
            row=db.execute("SELECT value FROM app_settings WHERE key=?",(key,)).fetchone(); return row[0] if row else default
    def set_setting(self,key,value):
        with self.connect() as db:db.execute("INSERT INTO app_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(key,value))
    def set_queue_status(self,project_id,gstin,status,error=""):
        with self.connect() as db:
            retry_increment=1 if status in ("Retry","Portal Error","Timed Out") else 0
            db.execute("UPDATE suppliers SET queue_status=?,last_error=?,last_attempt_at=CURRENT_TIMESTAMP,retry_count=COALESCE(retry_count,0)+? WHERE project_id=? AND gstin=?",(status,error,retry_increment,project_id,gstin)); self._audit(db,"QUEUE", "supplier",gstin,status+(f": {error}" if error else ""))
    def reset_project_queue(self,project_id):
        with self.connect() as db:
            db.execute("""UPDATE suppliers SET queue_status='Pending',last_error='',last_attempt_at=NULL
                WHERE project_id=? AND NOT EXISTS(
                    SELECT 1 FROM verifications v WHERE v.project_id=suppliers.project_id AND v.gstin=suppliers.gstin
                )""",(project_id,)); self._audit(db,"RESET_QUEUE","project",project_id,"All unverified GSTINs reset to Pending")
    @staticmethod
    def _audit(db,action,entity_type,entity_id,details):db.execute("INSERT INTO audit_logs(action,entity_type,entity_id,details) VALUES(?,?,?,?)",(action,entity_type,str(entity_id),details))

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal


@dataclass(slots=True)
class Project:
    name: str
    client_name: str = ""
    client_gstin: str = ""
    financial_year: str = ""
    tax_period: str = ""
    notice_type: str = ""
    notice_reference: str = ""
    notice_date: str = ""
    jurisdiction: str = ""
    remarks: str = ""
    id: int | None = None


@dataclass(slots=True)
class Invoice:
    gstin: str
    supplier_name: str = ""
    invoice_number: str = ""
    invoice_date: str = ""
    taxable_value: Decimal = Decimal("0")
    igst: Decimal = Decimal("0")
    cgst: Decimal = Decimal("0")
    sgst: Decimal = Decimal("0")
    cess: Decimal = Decimal("0")
    total_gst: Decimal = Decimal("0")
    invoice_value: Decimal = Decimal("0")
    notice_amount: Decimal = Decimal("0")
    remarks: str = ""
    source_file: str = ""
    source_sheet: str = ""
    row_number: int = 0


@dataclass(slots=True)
class SupplierAggregate:
    gstin: str
    supplier_name: str = ""
    invoice_count: int = 0
    taxable_value: Decimal = Decimal("0")
    igst: Decimal = Decimal("0")
    cgst: Decimal = Decimal("0")
    sgst: Decimal = Decimal("0")
    cess: Decimal = Decimal("0")
    total_gst: Decimal = Decimal("0")
    invoice_value: Decimal = Decimal("0")
    notice_amount: Decimal = Decimal("0")


@dataclass(slots=True)
class ReturnPeriod:
    period: str
    frequency: str
    due_date: str = ""
    filing_status: str = "Not Available"
    filing_date: str = ""
    delay_days: int | None = None
    arn: str = ""
    remarks: str = ""
    return_type: str = "GSTR-3B"


@dataclass(slots=True)
class VerificationResult:
    gstin: str
    legal_name: str = ""
    trade_name: str = ""
    status: str = "Manual Review Required"
    registration_date: str = ""
    cancellation_date: str = ""
    taxpayer_type: str = ""
    constitution: str = ""
    state_jurisdiction: str = ""
    centre_jurisdiction: str = ""
    nature_of_business: str = ""
    principal_state: str = ""
    source: str = "Manual"
    verified_at: str = field(default_factory=lambda: datetime.now().astimezone().isoformat(timespec="seconds"))
    remarks: str = ""
    returns: list[ReturnPeriod] = field(default_factory=list)

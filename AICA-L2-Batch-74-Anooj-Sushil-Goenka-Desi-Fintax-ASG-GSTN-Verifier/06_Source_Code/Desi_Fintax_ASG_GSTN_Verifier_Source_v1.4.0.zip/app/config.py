from __future__ import annotations

import os
import sys
from pathlib import Path

APP_NAME = "Desi Fintax ASG GSTN Verifier"
APP_VERSION = "1.4.0"
PUBLISHER = "Desi Fintax"
PROFESSIONAL_NAME = "CA Anooj Sushil Goenka"
MOBILE = "9833049094"
WHATSAPP = "9028593321"
GST_PORTAL_URL = "https://services.gst.gov.in/services/searchtp"


def resource_path(relative: str) -> Path:
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parents[1]))
    return base / relative


def data_root() -> Path:
    override = os.getenv("DESI_FINTAX_DATA_DIR")
    root = Path(override) if override else Path(os.getenv("LOCALAPPDATA", Path.home())) / "DesiFintax" / "ASGGSTNVerifier"
    root.mkdir(parents=True, exist_ok=True)
    for child in ("projects", "backups", "logs", "browser-profile"):
        (root / child).mkdir(exist_ok=True)
    return root


def database_path() -> Path:
    return data_root() / "asg_gstn_verifier.sqlite3"

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any
import pandas as pd
from app.models import Invoice
from app.services.aggregation import money
from app.services.gstin import validate_gstin

CANONICAL={
"gstin":("supplier gstin","gstin","gstin of supplier","gstin of supplier/recipient","ctin","gstin/uin of supplier"),
"supplier_name":("supplier name","trade/legal name","supplier legal name","name of supplier"),
"invoice_number":("invoice number","invoice no","invoice no.","inum"),"invoice_date":("invoice date","date of invoice","idt"),
"taxable_value":("taxable value","taxable amount","txval"),"igst":("igst","integrated tax","integrated tax amount"),
"cgst":("cgst","central tax","central tax amount"),"sgst":("sgst","state/ut tax","state tax","state/ut tax amount"),
"cess":("cess","cess amount"),"total_gst":("total gst","gst amount","total tax"),"invoice_value":("invoice value","invoice amount","val"),
"notice_amount":("notice amount","disputed amount"),"remarks":("remarks","remark")}

def _clean(value:object)->str:return re.sub(r"\s+"," ",str(value or "").strip().lower())

@dataclass(slots=True)
class ImportResult:
    invoices:list[Invoice]; invalid:list[tuple[str,str,str,str,str,int]]; duplicates:int; sheets:list[str]; detected_mapping:dict[str,str]

def _looks_like_gstin(value: object) -> bool:
    candidate=re.sub(r"[^A-Za-z0-9]","",str(value or "")).upper()
    return len(candidate) in (14,15,16) and candidate[:2].isdigit() and any(ch.isalpha() for ch in candidate)

class ExcelImporter:
    @staticmethod
    def sheets(path):return list(pd.ExcelFile(path).sheet_names)
    @staticmethod
    def detect_header(path,sheet_name):
        preview=pd.read_excel(path,sheet_name=sheet_name,header=None,nrows=30,dtype=object); best_score,best_row,best_mapping=-1,0,{}
        for row_idx,row in preview.iterrows():
            headings={_clean(v):str(v).strip() for v in row if pd.notna(v)}; mapping={}
            for field,aliases in CANONICAL.items():
                for heading,original in headings.items():
                    if heading in aliases or any(alias in heading for alias in aliases if len(alias)>5):mapping[field]=original; break
            score=len(mapping)+(5 if "gstin" in mapping else 0)
            if score>best_score:best_score,best_row,best_mapping=score,row_idx,mapping
        return best_row,best_mapping
    def import_file(self,path,mapping=None,sheet_names=None):
        path=Path(path); chosen=sheet_names or self.sheets(path); invoices=[]; invalid=[]; all_mapping={}; seen=set(); occurrences=0
        for sheet in chosen:
            header,detected=self.detect_header(path,sheet); active=dict(detected); active.update(mapping or {})
            if "gstin" not in active:continue
            all_mapping.update(active); frame=pd.read_excel(path,sheet_name=sheet,header=header,dtype=object)
            for index,row in frame.iterrows():
                raw=row.get(active["gstin"],"")
                if pd.isna(raw) or not str(raw).strip():continue
                check=validate_gstin(raw)
                if not check.valid:
                    if _looks_like_gstin(raw):invalid.append((str(raw),check.normalized,check.reason,path.name,sheet,int(index)+header+2))
                    continue
                occurrences+=1; seen.add(check.normalized); values={}
                for field in Invoice.__dataclass_fields__:
                    column=active.get(field); value=row.get(column,"") if column else ""; values[field]="" if pd.isna(value) else value
                values["gstin"]=check.normalized
                for field in ("taxable_value","igst","cgst","sgst","cess","total_gst","invoice_value","notice_amount"):values[field]=money(values[field])
                if not values["total_gst"]:values["total_gst"]=values["igst"]+values["cgst"]+values["sgst"]+values["cess"]
                values.update(source_file=path.name,source_sheet=sheet,row_number=int(index)+header+2); invoices.append(Invoice(**values))
        if not invoices and not invalid:raise ValueError("No GSTIN column was detected in the selected workbook")
        return ImportResult(invoices,invalid,occurrences-len(seen),chosen,all_mapping)

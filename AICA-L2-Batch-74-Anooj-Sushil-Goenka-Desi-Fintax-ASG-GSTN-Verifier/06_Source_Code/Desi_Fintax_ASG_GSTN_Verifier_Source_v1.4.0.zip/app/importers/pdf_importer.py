from pathlib import Path
from app.models import Invoice
from app.services.gstin import extract_gstins,validate_gstin

class PDFImporter:
    def extract_text(self,path,use_ocr=True):
        try:import fitz
        except ImportError as exc:raise RuntimeError("PyMuPDF is required for PDF import") from exc
        document=fitz.open(path)
        if document.needs_pass:raise ValueError("The PDF is password-protected")
        text="\n".join(page.get_text("text") for page in document)
        if text.strip() or not use_ocr:return text
        try:
            import pytesseract
            from PIL import Image
        except ImportError as exc:raise RuntimeError("OCR is required for this scanned PDF; install Tesseract and pytesseract") from exc
        chunks=[]
        for page in document:
            pix=page.get_pixmap(matrix=fitz.Matrix(2,2),alpha=False); image=Image.frombytes("RGB",(pix.width,pix.height),pix.samples); chunks.append(pytesseract.image_to_string(image))
        return "\n".join(chunks)
    def import_file(self,path,use_ocr=True):
        unique=list(dict.fromkeys(extract_gstins(self.extract_text(path,use_ocr)))); invoices=[]; invalid=[]
        for gstin in unique:
            result=validate_gstin(gstin)
            if result.valid:invoices.append(Invoice(gstin=result.normalized,source_file=Path(path).name,source_sheet="PDF"))
            else:invalid.append((gstin,result.normalized,result.reason,Path(path).name,"PDF",0))
        return invoices,invalid

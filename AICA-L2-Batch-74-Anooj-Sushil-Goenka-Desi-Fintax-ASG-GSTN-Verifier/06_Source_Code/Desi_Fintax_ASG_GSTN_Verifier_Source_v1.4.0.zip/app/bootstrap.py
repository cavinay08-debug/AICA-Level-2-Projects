import logging,sys
from app.config import APP_NAME,data_root
def run():
    log_path=data_root()/"logs"/"application.log"; logging.basicConfig(filename=log_path,level=logging.INFO,format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    try:
        from PySide6.QtGui import QIcon
        from PySide6.QtWidgets import QApplication,QMessageBox
        from app.config import resource_path
        from app.ui.main_window import MainWindow
        from app.ui.theme import STYLESHEET
    except ImportError as exc:print(f"Missing desktop dependency: {exc}. Run setup_windows.bat.",file=sys.stderr); return 2
    app=QApplication(sys.argv); app.setApplicationName(APP_NAME); app.setOrganizationName("Desi Fintax"); app.setStyleSheet(STYLESHEET); logo=resource_path("assets/desi_fintax_logo.jpeg")
    if logo.exists():app.setWindowIcon(QIcon(str(logo)))
    try:window=MainWindow(); window.show(); return app.exec()
    except Exception as exc:logging.exception("Fatal application error"); QMessageBox.critical(None,APP_NAME,f"The application could not start.\n\n{exc}\n\nSee: {log_path}"); return 1

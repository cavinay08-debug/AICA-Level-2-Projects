import hashlib
from datetime import datetime
from pathlib import Path

def evidence_filename(gstin:str,financial_year:str,dated:bool=False,when:datetime|None=None)->str:
    fy=financial_year.upper().replace("FY","").replace(" ","") or "CURRENT"; short=fy[2:] if len(fy)>=7 and fy[:2].isdigit() else fy; suffix=(when or datetime.now()).strftime("_%d%m%y") if dated else ""; return f"{gstin}_{short}{suffix}.pdf"

def sha256_file(path):
    digest=hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b""):digest.update(chunk)
    return digest.hexdigest()

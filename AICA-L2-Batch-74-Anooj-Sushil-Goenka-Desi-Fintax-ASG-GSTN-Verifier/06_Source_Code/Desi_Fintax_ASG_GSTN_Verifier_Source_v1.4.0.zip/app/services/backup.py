import json,shutil,sqlite3,tempfile,zipfile
from datetime import datetime
from pathlib import Path

def test_backup(path:Path):
    with zipfile.ZipFile(path) as archive:
        bad=archive.testzip()
        if bad:raise ValueError(f"Backup integrity failure at {bad}")
        if "manifest.json" not in archive.namelist():raise ValueError("Backup manifest is missing")

def create_backup(database:Path,destination:Path,project_folder:Path|None=None)->Path:
    destination.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="desifintax_backup_") as temp:
        temp_path=Path(temp); db_copy=temp_path/database.name; source=sqlite3.connect(database); target=sqlite3.connect(db_copy)
        with target:source.backup(target)
        target.close(); source.close(); manifest={"application":"Desi Fintax ASG GSTN Verifier","created_at":datetime.now().astimezone().isoformat(),"database":database.name}; (temp_path/"manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
        with zipfile.ZipFile(destination,"w",zipfile.ZIP_DEFLATED) as archive:
            archive.write(db_copy,db_copy.name); archive.write(temp_path/"manifest.json","manifest.json")
            if project_folder and project_folder.exists():
                for file in project_folder.rglob("*"):
                    if file.is_file():archive.write(file,Path("project_files")/file.relative_to(project_folder))
    test_backup(destination); return destination

def restore_backup(path:Path,database:Path,project_folder:Path|None=None):
    test_backup(path)
    with tempfile.TemporaryDirectory(prefix="desifintax_restore_") as temp:
        temp_path=Path(temp)
        with zipfile.ZipFile(path) as archive:archive.extractall(temp_path)
        candidates=list(temp_path.glob("*.sqlite3"))
        if not candidates:raise ValueError("Database is missing from backup")
        check=sqlite3.connect(candidates[0]); status=check.execute("PRAGMA integrity_check").fetchone()[0]; check.close()
        if status!="ok":raise ValueError("Database integrity check failed")
        database.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(candidates[0],database)
        if project_folder and (temp_path/"project_files").exists():shutil.copytree(temp_path/"project_files",project_folder,dirs_exist_ok=True)

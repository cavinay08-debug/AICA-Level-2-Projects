from __future__ import annotations

from collections import OrderedDict
from decimal import Decimal, InvalidOperation

from app.models import Invoice, SupplierAggregate
from app.services.gstin import normalize_gstin


def money(value: object) -> Decimal:
    if value is None or value == "":
        return Decimal("0")
    try:
        cleaned = str(value).replace(",", "").replace("₹", "").strip()
        return Decimal(cleaned) if cleaned and cleaned.lower() != "nan" else Decimal("0")
    except (InvalidOperation, ValueError):
        return Decimal("0")


def aggregate_invoices(invoices: list[Invoice]) -> list[SupplierAggregate]:
    grouped: OrderedDict[str, SupplierAggregate] = OrderedDict()
    for invoice in invoices:
        key = normalize_gstin(invoice.gstin)
        item = grouped.setdefault(key, SupplierAggregate(gstin=key, supplier_name=invoice.supplier_name))
        item.invoice_count += 1
        if not item.supplier_name and invoice.supplier_name:
            item.supplier_name = invoice.supplier_name
        for field in ("taxable_value", "igst", "cgst", "sgst", "cess", "total_gst", "invoice_value", "notice_amount"):
            setattr(item, field, getattr(item, field) + money(getattr(invoice, field)))
    return list(grouped.values())

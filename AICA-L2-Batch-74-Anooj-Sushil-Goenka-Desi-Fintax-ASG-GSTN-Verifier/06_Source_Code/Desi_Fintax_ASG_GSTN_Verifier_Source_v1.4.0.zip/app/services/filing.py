from __future__ import annotations

import calendar
from datetime import date, datetime

from app.models import ReturnPeriod

MONTHS = ("Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan", "Feb", "Mar")
QUARTERS = (("Apr", "May", "Jun"), ("Jul", "Aug", "Sep"), ("Oct", "Nov", "Dec"), ("Jan", "Feb", "Mar"))


def parse_financial_year(value: str) -> tuple[int, int]:
    cleaned = value.upper().replace("FY", "").strip()
    start_text, end_text = cleaned.split("-", 1)
    start = int(start_text)
    if len(end_text) == 2:
        end = (start // 100) * 100 + int(end_text)
        if end < start:
            end += 100
    else:
        end = int(end_text)
    if end != start + 1:
        raise ValueError("Financial year must span exactly one year")
    return start, end


def _month_year(month: str, start: int, end: int) -> tuple[int, int]:
    month_num = list(calendar.month_abbr).index(month)
    return (start if month_num >= 4 else end), month_num


def _due(month: str, start: int, end: int, day: int) -> date:
    year, month_num = _month_year(month, start, end)
    if month_num == 12:
        return date(year + 1, 1, day)
    return date(year, month_num + 1, day)


def expected_periods(financial_year: str, frequency_by_month: dict[str, str] | None = None) -> list[ReturnPeriod]:
    start, end = parse_financial_year(financial_year)
    frequencies = {month: "Monthly" for month in MONTHS}
    if frequency_by_month:
        frequencies.update({key.title()[:3]: value.title() for key, value in frequency_by_month.items()})
    result: list[ReturnPeriod] = []
    for quarter in QUARTERS:
        if all(frequencies[month] == "Quarterly" for month in quarter):
            due = _due(quarter[-1], start, end, 22)
            result.append(ReturnPeriod("-".join(quarter), "Quarterly", due.isoformat(), "Not Filed"))
        else:
            for month in quarter:
                due = _due(month, start, end, 20)
                result.append(ReturnPeriod(month, frequencies[month], due.isoformat(), "Not Filed"))
    return result


def apply_filing(period: ReturnPeriod, filing_date: str, arn: str = "") -> ReturnPeriod:
    filed, due = date.fromisoformat(filing_date), date.fromisoformat(period.due_date)
    period.filing_date, period.arn, period.filing_status = filing_date, arn, "Filed"
    period.delay_days = max(0, (filed - due).days)
    return period


GROUP_A_STATE_CODES = {"22", "23", "24", "26", "27", "29", "30", "31", "32", "33", "34", "35", "36", "37"}
GENERIC_DUE_NOTE = "Generic statutory due date used; notification-based extensions or taxpayer-specific relief are not applied."


def _normalise_month(period: str) -> str:
    value = (period or "").strip().lower()
    aliases = {name.lower(): name[:3] for name in calendar.month_name if name}
    aliases.update({name.lower(): name for name in MONTHS})
    return aliases.get(value, value[:3].title())


def _parse_portal_date(value: str) -> date | None:
    for pattern in ("%d/%m/%Y", "%d-%m-%Y", "%Y-%m-%d"):
        try:return datetime.strptime((value or "").strip(), pattern).date()
        except ValueError:pass
    return None


def generic_due_date(financial_year: str, period: str, frequency: str, return_type: str, gstin: str = "") -> date:
    start, end = parse_financial_year(financial_year)
    month = _normalise_month(period)
    quarterly = "quarter" in (frequency or "").lower()
    return_name = (return_type or "GSTR-3B").upper()
    if "1" in return_name and "3B" not in return_name:
        day = 13 if quarterly else 11
    elif quarterly:
        day = 22 if (gstin or "")[:2] in GROUP_A_STATE_CODES else 24
    else:
        day = 20
    return _due(month, start, end, day)


def apply_generic_due_dates(periods: list[ReturnPeriod], financial_year: str, gstin: str = "") -> list[ReturnPeriod]:
    for period in periods:
        try:
            due = generic_due_date(financial_year, period.period, period.frequency, period.return_type, gstin)
            period.due_date = due.isoformat()
            filed = _parse_portal_date(period.filing_date)
            period.delay_days = max(0, (filed - due).days) if filed else None
            period.remarks += (" | " if period.remarks else "") + GENERIC_DUE_NOTE
        except (ValueError, IndexError):
            period.remarks += (" | " if period.remarks else "") + "Generic due date could not be calculated for this portal row."
    return periods


def filing_conclusion(periods: list[ReturnPeriod]) -> str:
    if not periods:
        return "Portal data unavailable"
    if any(p.filing_status.lower() not in {"filed", "filed late"} for p in periods):
        return "Some applicable GSTR-3B not filed"
    if any((p.delay_days or 0) > 0 for p in periods):
        return "Filed with delay"
    return "All applicable GSTR-3B filed"

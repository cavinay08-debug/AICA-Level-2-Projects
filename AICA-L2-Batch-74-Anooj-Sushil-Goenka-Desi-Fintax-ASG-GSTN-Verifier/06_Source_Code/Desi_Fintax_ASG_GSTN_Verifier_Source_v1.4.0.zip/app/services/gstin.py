from __future__ import annotations

import re
from dataclasses import dataclass

GSTIN_PATTERN = re.compile(r"^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$")
GSTIN_EXTRACT_PATTERN = re.compile(r"(?<![A-Z0-9])[0-9]{2}\s*[A-Z]{5}\s*[0-9]{4}\s*[A-Z]\s*[1-9A-Z]\s*Z\s*[0-9A-Z](?![A-Z0-9])", re.I)
_ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"


@dataclass(frozen=True, slots=True)
class GSTINValidation:
    normalized: str
    valid: bool
    reason: str = ""


def normalize_gstin(value: object) -> str:
    return re.sub(r"[^A-Z0-9]", "", str(value or "").upper().strip())


def checksum_character(first_14: str) -> str:
    factor, total = 2, 0
    for char in reversed(first_14):
        code = _ALPHABET.index(char)
        addend = factor * code
        factor = 1 if factor == 2 else 2
        total += (addend // 36) + (addend % 36)
    return _ALPHABET[(36 - (total % 36)) % 36]


def validate_gstin(value: object, verify_checksum: bool = True) -> GSTINValidation:
    raw = str(value or "").strip()
    gstin = normalize_gstin(raw)
    if not raw:
        return GSTINValidation(gstin, False, "Blank GSTIN")
    if len(gstin) != 15:
        return GSTINValidation(gstin, False, "GSTIN must contain exactly 15 alphanumeric characters")
    if not GSTIN_PATTERN.fullmatch(gstin):
        return GSTINValidation(gstin, False, "GSTIN structure is invalid")
    if verify_checksum and checksum_character(gstin[:14]) != gstin[14]:
        return GSTINValidation(gstin, False, "GSTIN checksum is invalid")
    return GSTINValidation(gstin, True)


def extract_gstins(text: str) -> list[str]:
    return [normalize_gstin(match.group(0)) for match in GSTIN_EXTRACT_PATTERN.finditer(text.upper())]


def parse_bulk(text: str) -> tuple[list[str], list[GSTINValidation]]:
    tokens = re.split(r"[\s,;]+", text.strip()) if text.strip() else []
    valid, invalid, seen = [], [], set()
    for token in tokens:
        result = validate_gstin(token)
        if result.valid:
            if result.normalized not in seen:
                valid.append(result.normalized)
                seen.add(result.normalized)
        else:
            invalid.append(result)
    return valid, invalid

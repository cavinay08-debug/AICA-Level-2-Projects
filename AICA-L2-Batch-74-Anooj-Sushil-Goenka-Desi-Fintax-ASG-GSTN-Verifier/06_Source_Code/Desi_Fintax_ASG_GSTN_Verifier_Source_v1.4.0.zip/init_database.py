"""Create or safely migrate the local SQLite database."""
from app.database import Repository

if __name__=="__main__":
    repository=Repository()
    print(f"Database ready: {repository.path}")

#define MyAppName "Desi Fintax ASG GSTN Verifier"
#define MyAppVersion "1.4.0"
#define MyAppPublisher "Desi Fintax - CA Anooj Sushil Goenka"
#define MyAppExeName "Desi Fintax ASG GSTN Verifier.exe"
[Setup]
AppId={{8EA743D1-0868-4D7A-AB20-DF43F59F6419}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={localappdata}\Programs\Desi Fintax\ASG GSTN Verifier
DefaultGroupName=Desi Fintax
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir=installer_output
OutputBaseFilename=Desi_Fintax_ASG_GSTN_Verifier_Setup_1.4.0
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayIcon={app}\{#MyAppExeName}
[Files]
Source: "dist\Desi Fintax ASG GSTN Verifier\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
[Icons]
Name: "{autoprograms}\Desi Fintax\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon
[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Shortcuts:"; Flags: checkedonce
[Dirs]
Name: "{localappdata}\DesiFintax\ASGGSTNVerifier"; Permissions: users-modify
Name: "{localappdata}\DesiFintax\ASGGSTNVerifier\projects"; Permissions: users-modify
[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch {#MyAppName}"; Flags: nowait postinstall skipifsilent
[Code]
function EdgeInstalled(): Boolean;
begin Result := FileExists(ExpandConstant('{pf}\Microsoft\Edge\Application\msedge.exe')) or FileExists(ExpandConstant('{pf32}\Microsoft\Edge\Application\msedge.exe')); end;
function InitializeSetup(): Boolean;
begin Result := True; if not EdgeInstalled() then MsgBox('Microsoft Edge was not detected. GST Portal browser verification requires Edge.',mbInformation,MB_OK); end;

# Legal Sources & GST Statutory Compliance Reference

**Law verified as of: 17 August 2026**

> **Educational & Professional Assistance Notice**:  
> This documentation and the associated SmartExpense CA application provide preliminary analytical assistance for Indian Chartered Accountants, tax practitioners, and business owners. It does NOT constitute legal or professional tax advice, nor does it replace professional judgement, reconciliations against the live GST Portal, or statutory audits. GST laws, notifications, and circulars are subject to periodic amendments by the GST Council and Central Board of Indirect Taxes & Customs (CBIC). Always verify the current position with a qualified Chartered Accountant before filing returns.

---

## 1. Primary Official Regulatory Sources

All statutory interpretations and rules implemented in this tool are derived from the following primary official portals:

- **Central Board of Indirect Taxes and Customs (CBIC GST Portal)**: [https://cbic-gst.gov.in/](https://cbic-gst.gov.in/)
  - Acts, Rules, Notifications, Circulars, and Flyers on GST.
- **GST Common Portal (Goods and Services Tax Network - GSTN)**: [https://www.gst.gov.in/](https://www.gst.gov.in/)
  - GSTR-2B generation rules, return filing advisories, and system manuals.
- **The Gazette of India (Extraordinary Notifications)**: [https://egazette.gov.in/](https://egazette.gov.in/)
  - Official legislative amendments enacted through Finance Acts and Gazette Notifications.

---

## 2. Statutory Provisions & Rules Reference Matrix

### A. Section 16 — Eligibility and Conditions for Taking Input Tax Credit (ITC)

#### Section 16(1) | General Business Eligibility
- **Citation**: Central Goods and Services Tax (CGST) Act, 2017 — Section 16(1).
- **Rule Summary**: Every registered person is entitled to take credit of input tax charged on any supply of goods or services or both which are used or intended to be used in the course or furtherance of their business.
- **App Rule**: Expenses marked as "Personal" or not in furtherance of business are strictly ineligible.

#### Section 16(2) | Mandatory Conditions for Claiming ITC
A registered person cannot claim ITC unless **all five** statutory conditions are satisfied:
1. **Clause (a) - Tax Invoice / Debit Note**: Possession of a valid tax invoice, debit note, or other prescribed tax-paying document issued by a registered supplier under Section 31 (CGST Rules, Rule 36(1)).
2. **Clause (aa) / (ba) - GSTR-2B Statement**: The details of the invoice or debit note have been furnished by the supplier in GSTR-1 / IFF and communicated to the recipient in auto-generated statement GSTR-2B under Section 38.
3. **Clause (b) - Receipt of Goods or Services**: The registered person has actually received the goods or services or both (including deemed receipt under explanation for bill-to-ship-to models).
4. **Clause (c) - Tax Paid to the Government**: Subject to Section 41, the tax charged in respect of such supply has been actually paid to the Government, either in cash or through utilization of admissible ITC.
5. **Clause (d) - Return Furnished**: The recipient has furnished the valid return under Section 39 (GSTR-3B).

- **App Treatment**:
  - If tax invoice is missing or goods/services are not received $\rightarrow$ **Ineligible / CA Review Required**.
  - If GSTR-2B is "No" or "Not Checked" $\rightarrow$ **CA Review Required** (flags reconciliation requirement without assuming immediate permanent loss).

#### Second Proviso to Section 16(2) & Rule 37 | 180-Day Payment Condition
- **Citation**: CGST Act Section 16(2) Second Proviso read with CGST Rules Rule 37.
- **Rule Summary**: Where a recipient fails to pay the supplier the amount towards the value of supply along with tax payable thereon within a period of **180 days** from the date of issue of invoice, an amount equal to the ITC availed must be paid/reversed by the recipient along with applicable interest under Section 50. The credit can be reclaimed subsequently upon actual payment.
- **App Treatment**: When payment status is "Unpaid" or "Partially Paid" and the elapsed time from invoice date exceeds 180 days $\rightarrow$ **CA Review Required** with note: *"Potential 180-day non-payment reversal/interest liability. Verify supplier ledger balance."*

#### Section 16(4) | Statutory Time Limit for Claiming ITC
- **Citation**: CGST Act Section 16(4) (Amended via Finance Act, 2022, effective 1st October 2022).
- **Rule Summary**: A registered person cannot claim ITC in respect of any invoice or debit note for supply of goods or services after the **thirtieth day of November (30th November)** following the end of the financial year to which such invoice or debit note pertains, or furnishing of the relevant annual return under Section 44, whichever is earlier.
- **App Treatment**: Invoices belonging to a prior financial year where the 30th November cutoff has passed are flagged for **CA Review Required** / Time-limit expiry check.

---

### B. Section 17 — Apportionment of Credit & Blocked Credits

#### Section 17(1) & 17(2) | Apportionment for Mixed & Exempt Supplies
- **Citation**: CGST Act Section 17(1), 17(2) read with CGST Rules, Rule 42 (Inputs/Input Services) & Rule 43 (Capital Goods).
- **Rule Summary**:
  - If goods/services are used partly for business and partly for other purposes (personal), only credit attributable to business purposes is admissible (Section 17(1)).
  - If goods/services are used partly for effecting taxable supplies (including zero-rated supplies) and partly for exempt supplies, only credit attributable to taxable/zero-rated supplies is admissible (Section 17(2)).
- **App Treatment**: Items flagged with partial business use or partial exempt outward supplies trigger **CA Review Required** with guidance to apply Rule 42/Rule 43 reversal mechanisms.

#### Section 17(5) | Specific Blocked Credits ("Negative List")
Under Section 17(5), input tax credit is blocked on specific goods and services, unless specific statutory exceptions apply:

1. **Section 17(5)(a) & (aa) — Motor Vehicles and Conveyances**:
   - *General Rule*: Blocked for motor vehicles for transportation of persons having approved seating capacity of $\le 13$ persons (including driver).
   - *Statutory Exceptions*: Allowed if used for:
     - (A) Further supply of such motor vehicles;
     - (B) Transportation of passengers;
     - (C) Imparting training on driving such motor vehicles.
   - *App Treatment*: Automatically prompts for vehicle category/usage exception.

2. **Section 17(5)(b)(i) — Food, Beverages, Outdoor Catering, Health Services**:
   - *General Rule*: Blocked for food and beverages, outdoor catering, beauty treatment, health services, cosmetic and plastic surgery.
   - *Statutory Exception*: Allowed where inward supply is used for making an outward taxable supply of the same category of goods/services or as an element of a taxable composite/mixed supply.

3. **Section 17(5)(b)(ii) — Club, Health, and Fitness Centre Memberships**:
   - *General Rule*: Blocked across all commercial operations.

4. **Section 17(5)(b)(iii) — Rent-a-cab, Life Insurance, Health Insurance**:
   - *General Rule*: Blocked unless:
     - (A) The Government notifies it as obligatory for an employer to provide to its employees under any law for the time being in force (e.g., Factories Act, statutory worker insurance); or
     - (B) Inward supply is used for making an outward taxable supply of the same category.

5. **Section 17(5)(b)(iv) — Travel Benefits to Employees on Vacation**:
   - *General Rule*: Blocked (e.g., Leave Travel Concession - LTC, personal vacation perks).

6. **Section 17(5)(c) — Works Contract Services for Construction of Immovable Property**:
   - *General Rule*: Blocked when supplied for construction of an immovable property (other than plant and machinery), except where it is an input service for further supply of works contract service.

7. **Section 17(5)(d) — Construction of Immovable Property on Own Account**:
   - *General Rule*: Blocked on goods or services received by a taxable person for construction of an immovable property (other than plant or machinery) on his own account including when used in the course or furtherance of business, to the extent capitalized.

8. **Section 17(5)(e) — Composition Scheme Supplies**:
   - *General Rule*: Taxes paid under Section 10 (composition levy) cannot be claimed as ITC.

9. **Section 17(5)(f) — Non-Resident Taxable Persons**:
   - *General Rule*: Blocked on goods/services received by a non-resident taxable person, except on goods imported by him.

10. **Section 17(5)(g) — Personal Consumption**:
    - *General Rule*: Strictly blocked on goods or services or both used for personal consumption.

11. **Section 17(5)(h) — Lost, Stolen, Destroyed, Written Off, or Gifts/Free Samples**:
    - *General Rule*: Blocked for goods lost, stolen, destroyed, written off, or disposed of by way of gift or free samples.

12. **Section 17(5)(i) — Penalties, Seizure, and Demand Taxes (Sections 74, 129, 130)**:
    - *General Rule*: Any tax paid in accordance with the provisions of Sections 74 (fraudulent evasion), 129 (detention/seizure), and 130 (confiscation of goods/conveyances).

---

## 3. GSTIN Format Verification Standard

According to GST Rules, every Indian GSTIN is a 15-character alphanumeric code structured as:
- **Digits 1–2**: 2-digit State/UT code (01 to 38, e.g., 27 for Maharashtra, 07 for Delhi, 29 for Karnataka, 33 for Tamil Nadu, 06 for Haryana, etc.).
- **Characters 3–12**: 10-character PAN (Permanent Account Number) formatted as 5 letters, 4 digits, 1 letter (e.g., `ABCDE1234F`).
- **Character 13**: 1 alphanumeric entity number representing the number of registrations for the same PAN within that state (e.g., `1`, `2`, `Z`).
- **Character 14**: Default alphabet `Z`.
- **Character 15**: 1 alphanumeric checksum check digit.

> **Format Check vs Portal Validity Notice**:  
> Regex pattern validation `^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$` confirms syntactic conformance only. It does **not** prove that the GSTIN is active, genuine, non-cancelled, or matching the supplier's legal trade name on the GST Portal.

---

## 4. Place of Supply & Tax Component Validation Rules

- **Intra-State Supplies**: Supplier State Code $==$ Place of Supply / Recipient State Code $\rightarrow$ **CGST + SGST/UTGST** (Equal split, IGST must be 0).
- **Inter-State Supplies**: Supplier State Code $\ne$ Place of Supply / Recipient State Code $\rightarrow$ **IGST** (CGST and SGST must both be 0).
- **Validation Constraint**: Simultaneous non-zero entries for both IGST and (CGST or SGST) are flagged as an invalid tax distribution unless corrected.

---

## 5. Maintenance & Future Rule Updates for Chartered Accountants

When statutory amendments are gazetted:
1. Update this `LEGAL_SOURCES.md` file with the notification number, circular date, and rationale.
2. Modify the deterministic rules defined in `src/lib/itcRules.ts`.
3. Run the automated test suite (`npm test`) to verify that all regression test cases pass and edge cases are preserved.

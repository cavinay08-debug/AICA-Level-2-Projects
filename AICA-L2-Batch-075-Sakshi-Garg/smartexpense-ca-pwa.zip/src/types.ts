/**
 * SmartExpense CA - Core TypeScript Types & Interfaces
 * Comprehensive type definitions for Expense Management and GST ITC Review
 */

export type ExpenseCategory =
  | 'Office supplies'
  | 'Professional fees'
  | 'Software and subscriptions'
  | 'Rent'
  | 'Telephone and internet'
  | 'Advertising and marketing'
  | 'Business travel'
  | 'Food and beverages'
  | 'Employee welfare'
  | 'Motor vehicle / car expenses'
  | 'Insurance'
  | 'Club / fitness membership'
  | 'Construction / civil works'
  | 'Personal expense'
  | 'Capital goods'
  | 'Other';

export type SupplierPaymentStatus = 'Paid' | 'Unpaid' | 'Partially paid';

export type TriStateConfirmation = 'Yes' | 'No' | 'Not confirmed';

export type Gstr2bStatus = 'Yes' | 'No' | 'Not checked';

export type BusinessUse = 'Yes' | 'No' | 'Partly';

export type TaxableOutwardSupply = 'Yes' | 'No' | 'Partly' | 'Not confirmed';

export type SpecialException =
  | 'No'
  | 'Further supply of same category'
  | 'Passenger transport'
  | 'Driving training'
  | 'Statutory employer obligation'
  | 'Other / not sure';

export type ItcStatus = 'Eligible' | 'Ineligible' | 'CA Review Required';

export interface DecisionTrailStep {
  stepCode: string;
  stepName: string;
  status: 'pass' | 'fail' | 'review';
  finding: string;
  statutoryReference: string;
  sourceUrl: string;
}

export interface ItcDecision {
  status: ItcStatus;
  primaryReason: string;
  detailedReason: string;
  legalReference: string;
  sourceUrl: string;
  recommendedAction: string;
  decisionTrail: DecisionTrailStep[];
  flags: string[];
  eligibleAmount: number;
  blockedAmount: number;
  reviewAmount: number;
}

export interface ExpenseFormData {
  invoiceNumber: string;
  invoiceDate: string; // YYYY-MM-DD
  supplierName: string;
  supplierGstin: string;
  recipientGstin: string;
  description: string;
  category: ExpenseCategory;
  suggestedCategory?: ExpenseCategory;
  categoryMatchReason?: string;
  taxableValue: number;
  cgstAmount: number;
  sgstAmount: number;
  igstAmount: number;
  cessAmount: number;
  totalAmount: number;
  supplierPaymentStatus: SupplierPaymentStatus;
  paymentDate?: string; // YYYY-MM-DD
  goodsServicesReceived: TriStateConfirmation;
  taxInvoiceAvailable: 'Yes' | 'No';
  reflectedInGstr2b: Gstr2bStatus;
  usedForBusiness: BusinessUse;
  usedForTaxableOutwardSupply: TaxableOutwardSupply;
  specialException: SpecialException;
  notes?: string;
}

export interface Expense extends ExpenseFormData {
  id: string;
  createdAt: string;
  updatedAt: string;
  totalGst: number;
  itcDecision: ItcDecision;
}

export interface FilterState {
  searchQuery: string;
  statusFilter: ItcStatus | 'All';
  categoryFilter: ExpenseCategory | 'All';
  paymentFilter: SupplierPaymentStatus | 'All';
  monthFilter: string; // 'All' or 'YYYY-MM'
  sortBy: 'date' | 'amount' | 'gst' | 'supplier' | 'status';
  sortOrder: 'asc' | 'desc';
}

export interface DashboardSummary {
  totalExpenseAmount: number;
  totalGstAmount: number;
  eligibleItcAmount: number;
  ineligibleItcAmount: number;
  reviewItcAmount: number;
  totalExpenseCount: number;
  eligibleCount: number;
  ineligibleCount: number;
  reviewCount: number;
  categoryBreakdown: { category: ExpenseCategory; count: number; totalAmount: number; gstAmount: number }[];
  statusBreakdown: { status: ItcStatus; count: number; amount: number; gstAmount: number }[];
  monthlyBreakdown: { month: string; monthLabel: string; totalAmount: number; gstAmount: number; eligibleGst: number }[];
}

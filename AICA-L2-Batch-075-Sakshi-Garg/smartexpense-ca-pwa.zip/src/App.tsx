/**
 * SmartExpense CA - Main Application Component
 * AI-Assisted Expense Classification & GST ITC Review Tool
 */

import React, { useEffect, useState } from 'react';
import { CsvImportModal } from './components/CsvImportModal';
import { DashboardView } from './components/DashboardView';
import { ExpenseDetailModal } from './components/ExpenseDetailModal';
import { ExpenseFormModal } from './components/ExpenseFormModal';
import { ExpenseRegisterView } from './components/ExpenseRegisterView';
import { Header } from './components/Header';
import { LegalSourcesModal } from './components/LegalSourcesModal';
import { PwaInstallModal } from './components/PwaInstallModal';
import { getInitialExpenses } from './data/demoExpenses';
import { usePwa } from './hooks/usePwa';
import { exportExpenseRegisterCsv, exportItcSummaryCsv } from './lib/csvExport';
import { formatINR } from './lib/gstUtils';
import { evaluateItcEligibility } from './lib/itcRules';
import { Expense, ExpenseFormData, FilterState } from './types';
import { CheckCircle2, X } from 'lucide-react';

const STORAGE_KEY = 'smartexpense_ca_records_v1';

export default function App() {
  // PWA State & Handlers
  const { isInstallable, isOnline, hasUpdate, installApp, reloadApp } = usePwa();
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);

  // Load expenses from Local Storage or fallback to the 10 demo records
  const [expenses, setExpenses] = useState<Expense[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          // Re-evaluate decisions to ensure latest rules engine logic
          return parsed.map((item: any) => {
            const totalGst = (item.cgstAmount || 0) + (item.sgstAmount || 0) + (item.igstAmount || 0) + (item.cessAmount || 0);
            const itcDecision = evaluateItcEligibility(item);
            return {
              ...item,
              totalGst,
              itcDecision,
            };
          });
        }
      }
    } catch (e) {
      console.error('Failed to load stored expenses', e);
    }
    return getInitialExpenses();
  });

  // Save to Local Storage on change
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(expenses));
    } catch (e) {
      console.error('Failed to save expenses to localStorage', e);
    }
  }, [expenses]);

  // Main UI Navigation Tab
  const [activeTab, setActiveTab] = useState<'dashboard' | 'register'>('dashboard');

  // Filter & Search State
  const [filterState, setFilterState] = useState<FilterState>({
    searchQuery: '',
    statusFilter: 'All',
    categoryFilter: 'All',
    paymentFilter: 'All',
    monthFilter: 'All',
    sortBy: 'date',
    sortOrder: 'desc',
  });

  // Modals State
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [selectedExpense, setSelectedExpense] = useState<Expense | null>(null);
  const [isLegalModalOpen, setIsLegalModalOpen] = useState(false);

  // Success Notification Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Save (Create or Update) Expense Handler
  const handleSaveExpense = (formData: ExpenseFormData, existingId?: string) => {
    const totalGst = (formData.cgstAmount || 0) + (formData.sgstAmount || 0) + (formData.igstAmount || 0) + (formData.cessAmount || 0);
    const itcDecision = evaluateItcEligibility(formData);

    if (existingId) {
      // Update existing record
      setExpenses((prev) =>
        prev.map((exp) => {
          if (exp.id === existingId) {
            return {
              ...formData,
              id: existingId,
              createdAt: exp.createdAt,
              updatedAt: new Date().toISOString(),
              totalGst,
              itcDecision,
            };
          }
          return exp;
        })
      );
      setToastMessage(`Updated invoice ${formData.invoiceNumber}`);
    } else {
      // Create new record
      const newExpense: Expense = {
        ...formData,
        id: `exp-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        totalGst,
        itcDecision,
      };
      setExpenses((prev) => [newExpense, ...prev]);
      setToastMessage(`Added invoice ${formData.invoiceNumber} (${itcDecision.status})`);
    }

    setIsAddModalOpen(false);
    setEditingExpense(null);
  };

  // Bulk Import Invoices Handler
  const handleImportExpenses = (newExpenses: Expense[]) => {
    if (!newExpenses.length) return;
    setExpenses((prev) => [...newExpenses, ...prev]);
    
    let eligibleCount = 0;
    let eligibleAmount = 0;
    newExpenses.forEach((e) => {
      if (e.itcDecision.status === 'Eligible') {
        eligibleCount++;
        eligibleAmount += e.totalGst;
      }
    });

    setToastMessage(
      `Imported & assessed ${newExpenses.length} invoices successfully (${eligibleCount} eligible for ${formatINR(eligibleAmount)} ITC)`
    );
  };

  // Delete Expense Handler
  const handleDeleteExpense = (id: string) => {
    setExpenses((prev) => prev.filter((e) => e.id !== id));
    if (selectedExpense?.id === id) {
      setSelectedExpense(null);
    }
  };

  // Reset Demo Data Handler
  const handleResetDemoData = () => {
    const demoData = getInitialExpenses();
    setExpenses(demoData);
    setToastMessage('Reset 10 statutory demo invoices');
  };

  // Clear All Data Handler
  const handleClearAllData = () => {
    setExpenses([]);
    setToastMessage('Cleared all expense records');
  };

  // Navigate to Register with quick filters
  const handleNavigateToRegister = (filterOverrides?: Partial<FilterState>) => {
    if (filterOverrides) {
      setFilterState((prev) => ({ ...prev, ...filterOverrides }));
    }
    setActiveTab('register');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="bg-indigo-900 text-white px-4 py-2.5 text-xs font-semibold flex items-center justify-between shadow-md transition-all sticky top-0 z-50">
          <div className="max-w-7xl mx-auto w-full flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{toastMessage}</span>
            </div>
            <button
              type="button"
              onClick={() => setToastMessage(null)}
              className="text-slate-300 hover:text-white p-1 rounded-md transition-colors"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Top Header & Navigation */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenAddModal={() => {
          setEditingExpense(null);
          setIsAddModalOpen(true);
        }}
        onOpenImportModal={() => setIsImportModalOpen(true)}
        onOpenLegalModal={() => setIsLegalModalOpen(true)}
        onOpenInstallModal={() => setIsInstallModalOpen(true)}
        isInstallable={isInstallable}
        isOnline={isOnline}
        hasUpdate={hasUpdate}
        onReloadUpdate={reloadApp}
        onResetDemoData={handleResetDemoData}
        onClearAllData={handleClearAllData}
        onExportRegisterCsv={() => exportExpenseRegisterCsv(expenses)}
        onExportSummaryCsv={() => exportItcSummaryCsv(expenses)}
        totalExpensesCount={expenses.length}
      />

      {/* Main View Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6">
        {activeTab === 'dashboard' ? (
          <DashboardView
            expenses={expenses}
            onSelectExpense={(exp) => setSelectedExpense(exp)}
            onOpenAddModal={() => {
              setEditingExpense(null);
              setIsAddModalOpen(true);
            }}
            onOpenImportModal={() => setIsImportModalOpen(true)}
            onNavigateToRegister={handleNavigateToRegister}
            filterState={filterState}
            setFilterState={setFilterState}
          />
        ) : (
          <ExpenseRegisterView
            expenses={expenses}
            onSelectExpense={(exp) => setSelectedExpense(exp)}
            onEditExpense={(exp) => {
              setEditingExpense(exp);
              setIsAddModalOpen(true);
            }}
            onDeleteExpense={handleDeleteExpense}
            onOpenAddModal={() => {
              setEditingExpense(null);
              setIsAddModalOpen(true);
            }}
            onOpenImportModal={() => setIsImportModalOpen(true)}
            onExportCsv={() => exportExpenseRegisterCsv(expenses)}
            filterState={filterState}
            setFilterState={setFilterState}
          />
        )}
      </main>

      {/* Footer Notice */}
      <footer className="border-t border-slate-200 bg-white py-4 px-4 text-center text-xs text-slate-500 shadow-xs">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>
            <strong className="font-semibold text-slate-700">SmartExpense CA</strong> • Progressive Web App (PWA) • AI-Assisted GST ITC Review
          </span>
          <span className="text-[11px] text-slate-400">
            Offline Ready • Law verified as of: 17 Aug 2026 • Local-first storage
          </span>
        </div>
      </footer>

      {/* Add / Edit Expense Modal */}
      <ExpenseFormModal
        isOpen={isAddModalOpen}
        onClose={() => {
          setIsAddModalOpen(false);
          setEditingExpense(null);
        }}
        onSave={handleSaveExpense}
        initialExpense={editingExpense}
      />

      {/* CSV Bulk Import Modal */}
      <CsvImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        onImportExpenses={handleImportExpenses}
      />

      {/* Expense Compliance Detail & Trail Modal */}
      <ExpenseDetailModal
        expense={selectedExpense}
        isOpen={!!selectedExpense}
        onClose={() => setSelectedExpense(null)}
        onEdit={(exp) => {
          setSelectedExpense(null);
          setEditingExpense(exp);
          setIsAddModalOpen(true);
        }}
        onDelete={handleDeleteExpense}
      />

      {/* Legal Sources & Statutory Framework Guide Modal */}
      <LegalSourcesModal
        isOpen={isLegalModalOpen}
        onClose={() => setIsLegalModalOpen(false)}
      />

      {/* PWA Install & Offline Guide Modal */}
      <PwaInstallModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
        isInstallable={isInstallable}
        onInstall={installApp}
      />
    </div>
  );
}

/**
 * SmartExpense CA - PWA Reactive Hook
 */

import { useEffect, useState } from 'react';
import { pwaManager } from '../lib/pwa';

export function usePwa() {
  const [isInstallable, setIsInstallable] = useState(pwaManager.canInstall());
  const [isInstalled, setIsInstalled] = useState(pwaManager.isInstalled());
  const [hasUpdate, setHasUpdate] = useState(pwaManager.hasUpdate());
  const [isOnline, setIsOnline] = useState(
    typeof window !== 'undefined' ? window.navigator.onLine : true
  );

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    const unsubscribe = pwaManager.subscribe(() => {
      setIsInstallable(pwaManager.canInstall());
      setIsInstalled(pwaManager.isInstalled());
      setHasUpdate(pwaManager.hasUpdate());
    });

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      unsubscribe();
    };
  }, []);

  const installApp = async () => {
    return await pwaManager.triggerInstall();
  };

  const reloadApp = () => {
    if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
      navigator.serviceWorker.controller.postMessage({ type: 'SKIP_WAITING' });
    }
    window.location.reload();
  };

  return {
    isInstallable,
    isInstalled,
    hasUpdate,
    isOnline,
    installApp,
    reloadApp,
  };
}

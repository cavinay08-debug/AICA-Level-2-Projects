/**
 * SmartExpense CA - Comprehensive Expense & ITC Audit Detail Modal
 * Displays complete invoice attributes, classification path, rule-by-rule decision trail,
 * statutory references, and next audit actions for the CA.
 */

import {
  AlertTriangle,
  BookOpen,
  Calendar,
  CheckCircle2,
  Clock,
  Download,
  Edit2,
  ExternalLink,
  FileText,
  Info,
  Layers,
  Receipt,
  Scale,
  ShieldAlert,
  Sparkles,
  Tag,
  Trash2,
  Wallet,
  X,
  XCircle,
} from 'lucide-react';
import React from 'react';
import { formatDateDDMMYYYY, formatINR } from '../lib/gstUtils';
import { Expense, ItcStatus } from '../types';

interface ExpenseDetailModalProps {
  expense: Expense | null;
  isOpen: boolean;
  onClose: () => void;
  onEdit: (expense: Expense) => void;
  onDelete: (expenseId: string) => void;
}

export const ExpenseDetailModal: React.FC<ExpenseDetailModalProps> = ({
  expense,
  isOpen,
  onClose,
  onEdit,
  onDelete,
}) => {
  if (!isOpen || !expense) return null;

  const decision = expense.itcDecision;

  const getStatusBanner = (status: ItcStatus) => {
    if (status === 'Eligible') {
      return {
        bg: 'bg-emerald-50 border-emerald-200 text-emerald-800',
        badge: 'bg-emerald-100 text-emerald-800 border-emerald-200',
        icon: <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />,
        headline: 'Eligible ITC (Preliminary Admissible)',
        subtext: 'Preliminary eligibility result—final claim remains subject to verification and applicable GST law.',
      };
    }
    if (status === 'Ineligible') {
      return {
        bg: 'bg-rose-50 border-rose-200 text-rose-800',
        badge: 'bg-rose-100 text-rose-800 border-rose-200',
        icon: <XCircle className="w-6 h-6 text-rose-600 shrink-0" />,
        headline: 'Ineligible / Blocked ITC',
        subtext: 'ITC is blocked under Section 17(5) or disqualified under Section 16/17 statutory conditions.',
      };
    }
    return {
      bg: 'bg-amber-50 border-amber-200 text-amber-800',
      badge: 'bg-amber-100 text-amber-800 border-amber-200',
      icon: <AlertTriangle className="w-6 h-6 text-amber-600 shrink-0" />,
      headline: 'CA Review Required',
      subtext: 'Incomplete facts, Rule 37 180-day reversal review, Rule 42/43 apportionment, or statutory exception verification needed.',
    };
  };

  const banner = getStatusBanner(decision.status);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-2xl shadow-xl w-full max-w-4xl max-h-[92vh] flex flex-col text-slate-700 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/80">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 border border-indigo-100 flex items-center justify-center">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-slate-900">Invoice #{expense.invoiceNumber}</h2>
                <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold border ${banner.badge}`}>
                  {decision.status}
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Issued by <strong className="text-slate-700">{expense.supplierName}</strong> on{' '}
                {formatDateDDMMYYYY(expense.invoiceDate)}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                onClose();
                onEdit(expense);
              }}
              className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
              title="Edit Invoice"
            >
              <Edit2 className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => {
                if (window.confirm('Delete this invoice?')) {
                  onDelete(expense.id);
                  onClose();
                }
              }}
              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
              title="Delete Invoice"
            >
              <Trash2 className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors ml-2 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs">
          {/* High Visibility Status Banner */}
          <div className={`p-4 rounded-xl border flex items-start gap-3.5 ${banner.bg}`}>
            {banner.icon}
            <div className="space-y-1">
              <h3 className="font-bold text-sm text-slate-900">{banner.headline}</h3>
              <p className="text-xs opacity-95 leading-relaxed">{banner.subtext}</p>
              <div className="pt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] font-mono font-medium">
                <span>Statutory Ref: {decision.legalReference}</span>
                <span>•</span>
                <span>GST Incurred: {formatINR(expense.totalGst)}</span>
                <span>•</span>
                <span>Eligible Pool: {formatINR(decision.eligibleAmount)}</span>
              </div>
            </div>
          </div>

          {/* Classification & Accounting Context */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
              <span>AI Classification Journey & Accounting Category</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-xs">
                <span className="text-[11px] text-slate-500 block mb-0.5">Automated Suggestion:</span>
                <span className="font-semibold text-indigo-700 text-sm">
                  {expense.suggestedCategory || expense.category}
                </span>
                <p className="text-[10px] text-slate-500 mt-1">
                  {expense.categoryMatchReason || 'Derived from keyword matching on item description.'}
                </p>
              </div>

              <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-xs">
                <span className="text-[11px] text-slate-500 block mb-0.5">Final Selected Category:</span>
                <span className="font-semibold text-slate-900 text-sm">{expense.category}</span>
                <p className="text-[10px] text-slate-500 mt-1">
                  Confirmed by Chartered Accountant / User in purchase register.
                </p>
              </div>
            </div>

            {expense.description && (
              <div className="p-2.5 bg-white rounded-xl border border-slate-200 text-slate-700 shadow-xs">
                <span className="text-[10px] uppercase font-bold text-slate-500 block mb-0.5">
                  Line Item Description:
                </span>
                <p className="text-xs">{expense.description}</p>
              </div>
            )}
          </div>

          {/* Complete Invoice Particulars & Tax Split Table */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <Receipt className="w-3.5 h-3.5 text-indigo-600" />
              <span>Invoice Particulars & Tax Components</span>
            </h4>

            {/* Grid of Attributes */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="p-2.5 bg-white rounded-xl border border-slate-200 shadow-xs">
                <span className="text-[10px] text-slate-500 block font-medium">Supplier GSTIN</span>
                <span className="font-mono font-semibold text-slate-900 uppercase">
                  {expense.supplierGstin || 'Not provided'}
                </span>
              </div>
              <div className="p-2.5 bg-white rounded-xl border border-slate-200 shadow-xs">
                <span className="text-[10px] text-slate-500 block font-medium">Recipient GSTIN</span>
                <span className="font-mono font-semibold text-slate-900 uppercase">
                  {expense.recipientGstin || 'Not provided'}
                </span>
              </div>
              <div className="p-2.5 bg-white rounded-xl border border-slate-200 shadow-xs">
                <span className="text-[10px] text-slate-500 block font-medium">Supplier Payment</span>
                <span
                  className={`font-semibold ${
                    expense.supplierPaymentStatus === 'Paid'
                      ? 'text-emerald-700'
                      : expense.supplierPaymentStatus === 'Unpaid'
                      ? 'text-rose-700'
                      : 'text-amber-700'
                  }`}
                >
                  {expense.supplierPaymentStatus}{' '}
                  {expense.paymentDate ? `(${formatDateDDMMYYYY(expense.paymentDate)})` : ''}
                </span>
              </div>
              <div className="p-2.5 bg-white rounded-xl border border-slate-200 shadow-xs">
                <span className="text-[10px] text-slate-500 block font-medium">GSTR-2B Statement</span>
                <span
                  className={`font-semibold ${
                    expense.reflectedInGstr2b === 'Yes'
                      ? 'text-emerald-700'
                      : expense.reflectedInGstr2b === 'No'
                      ? 'text-rose-700'
                      : 'text-amber-700'
                  }`}
                >
                  {expense.reflectedInGstr2b === 'Yes'
                    ? 'Reflected & Matched'
                    : expense.reflectedInGstr2b === 'No'
                    ? 'Not in 2B'
                    : 'Not checked'}
                </span>
              </div>
            </div>

            {/* Valuation Table */}
            <div className="overflow-x-auto pt-1">
              <table className="w-full text-left text-xs bg-white rounded-xl overflow-hidden border border-slate-200 shadow-xs">
                <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200 text-[11px]">
                  <tr>
                    <th className="py-2.5 px-3">Taxable Value</th>
                    <th className="py-2.5 px-3">CGST</th>
                    <th className="py-2.5 px-3">SGST / UTGST</th>
                    <th className="py-2.5 px-3">IGST</th>
                    <th className="py-2.5 px-3">Cess</th>
                    <th className="py-2.5 px-3 text-right">Total Invoice Value</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono text-slate-800">
                  <tr>
                    <td className="py-2.5 px-3">{formatINR(expense.taxableValue)}</td>
                    <td className="py-2.5 px-3 text-indigo-600 font-medium">{formatINR(expense.cgstAmount)}</td>
                    <td className="py-2.5 px-3 text-indigo-600 font-medium">{formatINR(expense.sgstAmount)}</td>
                    <td className="py-2.5 px-3 text-indigo-600 font-medium">{formatINR(expense.igstAmount)}</td>
                    <td className="py-2.5 px-3">{formatINR(expense.cessAmount)}</td>
                    <td className="py-2.5 px-3 text-right font-bold text-slate-900">
                      {formatINR(expense.totalAmount)}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Rule-by-Rule Decision Trail */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <Scale className="w-3.5 h-3.5 text-amber-600" />
                <span>Deterministic Statutory Decision Trail</span>
              </h4>
              <span className="text-[10px] text-slate-500 font-mono">
                {decision.decisionTrail.length} rule checks performed
              </span>
            </div>

            <div className="space-y-2">
              {decision.decisionTrail.map((step, idx) => {
                let badgeClass = 'bg-emerald-50 text-emerald-800 border-emerald-200';
                let icon = <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />;

                if (step.status === 'fail') {
                  badgeClass = 'bg-rose-50 text-rose-800 border-rose-200';
                  icon = <XCircle className="w-4 h-4 text-rose-600 shrink-0" />;
                } else if (step.status === 'review') {
                  badgeClass = 'bg-amber-50 text-amber-800 border-amber-200';
                  icon = <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />;
                }

                return (
                  <div
                    key={idx}
                    className="p-3 bg-white rounded-xl border border-slate-200 shadow-xs space-y-1.5"
                  >
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <div className="flex items-center gap-2">
                        {icon}
                        <span className="font-semibold text-slate-900 text-xs">{step.stepName}</span>
                      </div>
                      <span className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold border ${badgeClass}`}>
                        {step.status.toUpperCase()}
                      </span>
                    </div>

                    <p className="text-slate-600 text-[11px] pl-6 leading-relaxed">
                      {step.finding}
                    </p>

                    <div className="pl-6 pt-1 flex items-center justify-between text-[10px] text-slate-500 font-mono">
                      <span>{step.statutoryReference}</span>
                      <a
                        href={step.sourceUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="text-indigo-600 hover:underline flex items-center gap-0.5 font-semibold"
                      >
                        <span>CBIC Source</span>
                        <ExternalLink className="w-2.5 h-2.5" />
                      </a>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Recommended Next Action for Chartered Accountant */}
          <div className="p-4 bg-indigo-50 border border-indigo-200 rounded-xl space-y-2 text-indigo-950">
            <div className="flex items-center gap-2 font-bold text-xs text-indigo-900">
              <Info className="w-4 h-4 text-indigo-600" />
              <span>Recommended Next Action for Compliance:</span>
            </div>
            <p className="text-xs leading-relaxed text-indigo-900">
              {decision.recommendedAction}
            </p>
          </div>

          {/* Statutory Educational Disclaimer */}
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-[11px] text-slate-500 leading-relaxed space-y-1">
            <span className="font-semibold text-slate-700 flex items-center gap-1">
              <ShieldAlert className="w-3.5 h-3.5 text-amber-600" />
              Educational & Professional Assistance Disclaimer:
            </span>
            <p>
              This tool provides a preliminary compliance review based on entered data. It does not replace professional judgement, GST portal reconciliation, or legal advice.
            </p>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-slate-200 bg-slate-50/80 flex items-center justify-between text-xs text-slate-500">
          <span>SmartExpense CA • GST Compliance Engine</span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                onClose();
                onEdit(expense);
              }}
              className="px-3.5 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-xl font-medium transition-colors shadow-xs cursor-pointer"
            >
              Edit Details
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-medium transition-colors shadow-xs cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

/**
 * SmartExpense CA - Compliance & ITC Analytics Dashboard
 */

import {
  AlertCircle,
  AlertTriangle,
  ArrowUpRight,
  BarChart3,
  Calendar,
  CheckCircle2,
  ChevronRight,
  Clock,
  Filter,
  Layers,
  PieChart,
  PlusCircle,
  Receipt,
  Search,
  ShieldAlert,
  Wallet,
  XCircle,
} from 'lucide-react';
import React, { useMemo } from 'react';
import { formatDateDDMMYYYY, formatINR, roundTwoDecimals } from '../lib/gstUtils';
import { Expense, ExpenseCategory, FilterState, ItcStatus } from '../types';

interface DashboardViewProps {
  expenses: Expense[];
  onSelectExpense: (expense: Expense) => void;
  onOpenAddModal: () => void;
  onOpenImportModal: () => void;
  onNavigateToRegister: (filterOverrides?: Partial<FilterState>) => void;
  filterState: FilterState;
  setFilterState: React.Dispatch<React.SetStateAction<FilterState>>;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  expenses,
  onSelectExpense,
  onOpenAddModal,
  onOpenImportModal,
  onNavigateToRegister,
  filterState,
  setFilterState,
}) => {
  // Aggregate Metrics based on all expenses (or filtered if user applies filters)
  const filteredExpenses = useMemo(() => {
    return expenses.filter((exp) => {
      // Status Filter
      if (filterState.statusFilter !== 'All' && exp.itcDecision.status !== filterState.statusFilter) {
        return false;
      }
      // Category Filter
      if (filterState.categoryFilter !== 'All' && exp.category !== filterState.categoryFilter) {
        return false;
      }
      // Month Filter
      if (filterState.monthFilter !== 'All') {
        const expMonth = exp.invoiceDate?.substring(0, 7); // YYYY-MM
        if (expMonth !== filterState.monthFilter) return false;
      }
      // Search
      if (filterState.searchQuery.trim() !== '') {
        const q = filterState.searchQuery.toLowerCase();
        const match =
          exp.invoiceNumber.toLowerCase().includes(q) ||
          exp.supplierName.toLowerCase().includes(q) ||
          exp.description.toLowerCase().includes(q) ||
          exp.supplierGstin.toLowerCase().includes(q);
        if (!match) return false;
      }
      return true;
    });
  }, [expenses, filterState]);

  // Overall Financial Totals
  const totals = useMemo(() => {
    let totalExpense = 0;
    let totalTaxable = 0;
    let totalGst = 0;
    let eligibleItc = 0;
    let ineligibleItc = 0;
    let reviewItc = 0;

    let eligibleCount = 0;
    let ineligibleCount = 0;
    let reviewCount = 0;

    for (const exp of filteredExpenses) {
      totalExpense += exp.totalAmount || 0;
      totalTaxable += exp.taxableValue || 0;
      totalGst += exp.totalGst || 0;

      if (exp.itcDecision.status === 'Eligible') {
        eligibleItc += exp.totalGst || 0;
        eligibleCount++;
      } else if (exp.itcDecision.status === 'Ineligible') {
        ineligibleItc += exp.totalGst || 0;
        ineligibleCount++;
      } else {
        reviewItc += exp.totalGst || 0;
        reviewCount++;
      }
    }

    return {
      totalExpense: roundTwoDecimals(totalExpense),
      totalTaxable: roundTwoDecimals(totalTaxable),
      totalGst: roundTwoDecimals(totalGst),
      eligibleItc: roundTwoDecimals(eligibleItc),
      ineligibleItc: roundTwoDecimals(ineligibleItc),
      reviewItc: roundTwoDecimals(reviewItc),
      eligibleCount,
      ineligibleCount,
      reviewCount,
      totalCount: filteredExpenses.length,
    };
  }, [filteredExpenses]);

  // Category Breakdown Aggregation
  const categoryStats = useMemo(() => {
    const map = new Map<ExpenseCategory, { count: number; totalAmount: number; totalGst: number; eligibleGst: number }>();

    for (const exp of filteredExpenses) {
      const existing = map.get(exp.category) || { count: 0, totalAmount: 0, totalGst: 0, eligibleGst: 0 };
      existing.count += 1;
      existing.totalAmount += exp.totalAmount;
      existing.totalGst += exp.totalGst;
      if (exp.itcDecision.status === 'Eligible') {
        existing.eligibleGst += exp.totalGst;
      }
      map.set(exp.category, existing);
    }

    return Array.from(map.entries())
      .map(([category, data]) => ({
        category,
        ...data,
      }))
      .sort((a, b) => b.totalAmount - a.totalAmount);
  }, [filteredExpenses]);

  // Monthly Trend Chart Aggregation
  const monthlyStats = useMemo(() => {
    const map = new Map<string, { monthKey: string; monthLabel: string; totalAmount: number; gstAmount: number; eligibleGst: number; count: number }>();

    for (const exp of filteredExpenses) {
      if (!exp.invoiceDate) continue;
      const monthKey = exp.invoiceDate.substring(0, 7); // YYYY-MM
      const dateObj = new Date(`${monthKey}-01`);
      const monthLabel = isNaN(dateObj.getTime())
        ? monthKey
        : dateObj.toLocaleDateString('en-IN', { month: 'short', year: 'numeric' });

      const existing = map.get(monthKey) || {
        monthKey,
        monthLabel,
        totalAmount: 0,
        gstAmount: 0,
        eligibleGst: 0,
        count: 0,
      };

      existing.totalAmount += exp.totalAmount;
      existing.gstAmount += exp.totalGst;
      if (exp.itcDecision.status === 'Eligible') {
        existing.eligibleGst += exp.totalGst;
      }
      existing.count += 1;
      map.set(monthKey, existing);
    }

    return Array.from(map.values()).sort((a, b) => a.monthKey.localeCompare(b.monthKey));
  }, [filteredExpenses]);

  // Max value for monthly chart scaling
  const maxMonthlyAmount = useMemo(() => {
    if (monthlyStats.length === 0) return 1;
    return Math.max(...monthlyStats.map((m) => m.totalAmount), 1);
  }, [monthlyStats]);

  // Items requiring immediate CA review
  const urgentReviewItems = useMemo(() => {
    return filteredExpenses
      .filter((exp) => exp.itcDecision.status === 'CA Review Required')
      .slice(0, 5);
  }, [filteredExpenses]);

  // List of unique months for filter dropdown
  const availableMonths = useMemo(() => {
    const set = new Set<string>();
    for (const exp of expenses) {
      if (exp.invoiceDate && exp.invoiceDate.length >= 7) {
        set.add(exp.invoiceDate.substring(0, 7));
      }
    }
    return Array.from(set).sort().reverse();
  }, [expenses]);

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner & Filters Bar */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-indigo-600" />
              <span>GST Compliance & ITC Audit Overview</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Preliminary classification summary & Section 16/17 statutory distribution
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              type="button"
              onClick={onOpenAddModal}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Record Expense</span>
            </button>
            <button
              type="button"
              onClick={onOpenImportModal}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 text-xs font-semibold rounded-xl shadow-xs transition-colors"
            >
              <Receipt className="w-4 h-4 text-indigo-600" />
              <span>Import Invoices (CSV)</span>
            </button>
            <button
              type="button"
              onClick={() => onNavigateToRegister()}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 text-xs font-semibold rounded-xl shadow-xs transition-colors"
            >
              <span>View Full Register</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Filter Controls Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 pt-3 border-t border-slate-100 text-xs">
          {/* Search Box */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              placeholder="Search supplier, invoice..."
              value={filterState.searchQuery}
              onChange={(e) => setFilterState((prev) => ({ ...prev, searchQuery: e.target.value }))}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-slate-800 placeholder-slate-400 focus:outline-hidden focus:bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 text-xs"
            />
          </div>

          {/* Month Filter */}
          <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5">
            <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <select
              value={filterState.monthFilter}
              onChange={(e) => setFilterState((prev) => ({ ...prev, monthFilter: e.target.value }))}
              className="w-full bg-transparent text-slate-800 focus:outline-hidden text-xs"
            >
              <option value="All" className="bg-white text-slate-900">All Months</option>
              {availableMonths.map((m) => {
                const d = new Date(`${m}-01`);
                const label = isNaN(d.getTime()) ? m : d.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });
                return (
                  <option key={m} value={m} className="bg-white text-slate-900">
                    {label}
                  </option>
                );
              })}
            </select>
          </div>

          {/* ITC Status Filter */}
          <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5">
            <Filter className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <select
              value={filterState.statusFilter}
              onChange={(e) => setFilterState((prev) => ({ ...prev, statusFilter: e.target.value as ItcStatus | 'All' }))}
              className="w-full bg-transparent text-slate-800 focus:outline-hidden text-xs"
            >
              <option value="All" className="bg-white text-slate-900">All ITC Statuses</option>
              <option value="Eligible" className="bg-white text-emerald-700">Eligible Only</option>
              <option value="Ineligible" className="bg-white text-rose-700">Ineligible / Blocked</option>
              <option value="CA Review Required" className="bg-white text-amber-700">CA Review Required</option>
            </select>
          </div>

          {/* Category Filter */}
          <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5">
            <Layers className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <select
              value={filterState.categoryFilter}
              onChange={(e) => setFilterState((prev) => ({ ...prev, categoryFilter: e.target.value as ExpenseCategory | 'All' }))}
              className="w-full bg-transparent text-slate-800 focus:outline-hidden text-xs truncate"
            >
              <option value="All" className="bg-white text-slate-900">All Categories</option>
              <option value="Software and subscriptions" className="bg-white text-slate-900">Software & Subscriptions</option>
              <option value="Professional fees" className="bg-white text-slate-900">Professional Fees</option>
              <option value="Food and beverages" className="bg-white text-slate-900">Food & Beverages</option>
              <option value="Employee welfare" className="bg-white text-slate-900">Employee Welfare</option>
              <option value="Motor vehicle / car expenses" className="bg-white text-slate-900">Motor Vehicle Expenses</option>
              <option value="Capital goods" className="bg-white text-slate-900">Capital Goods</option>
              <option value="Office supplies" className="bg-white text-slate-900">Office Supplies</option>
              <option value="Rent" className="bg-white text-slate-900">Rent</option>
              <option value="Telephone and internet" className="bg-white text-slate-900">Telephone & Internet</option>
              <option value="Advertising and marketing" className="bg-white text-slate-900">Advertising & Marketing</option>
              <option value="Insurance" className="bg-white text-slate-900">Insurance</option>
              <option value="Club / fitness membership" className="bg-white text-slate-900">Club & Fitness</option>
              <option value="Construction / civil works" className="bg-white text-slate-900">Construction / Civil Works</option>
              <option value="Personal expense" className="bg-white text-slate-900">Personal Expense</option>
              <option value="Other" className="bg-white text-slate-900">Other</option>
            </select>
          </div>
        </div>
      </div>

      {/* KPI Stat Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* Total Expenses */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs relative overflow-hidden flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-slate-500 text-xs font-medium mb-1">
              <span>Total Invoice Amount</span>
              <Receipt className="w-4 h-4 text-slate-400" />
            </div>
            <div className="text-xl font-bold text-slate-900 tracking-tight font-mono">
              {formatINR(totals.totalExpense)}
            </div>
          </div>
          <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
            <span>Taxable: {formatINR(totals.totalTaxable)}</span>
            <span className="font-semibold text-slate-700">{totals.totalCount} invoices</span>
          </div>
        </div>

        {/* Total GST Incurred */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs relative overflow-hidden flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-slate-500 text-xs font-medium mb-1">
              <span>Total GST Incurred</span>
              <Wallet className="w-4 h-4 text-indigo-600" />
            </div>
            <div className="text-xl font-bold text-indigo-600 tracking-tight font-mono">
              {formatINR(totals.totalGst)}
            </div>
          </div>
          <div className="mt-3 pt-2 border-t border-slate-100 text-[11px] text-slate-500 flex items-center justify-between">
            <span>Gross input tax pool</span>
            <span className="text-indigo-600 font-semibold">100% Incurred</span>
          </div>
        </div>

        {/* Potentially Eligible ITC */}
        <div
          onClick={() => onNavigateToRegister({ statusFilter: 'Eligible' })}
          className="bg-emerald-50/70 border border-emerald-200/80 hover:border-emerald-300 rounded-2xl p-4 shadow-xs relative overflow-hidden flex flex-col justify-between cursor-pointer transition-all hover:bg-emerald-50 group"
        >
          <div>
            <div className="flex items-center justify-between text-emerald-800 text-xs font-semibold mb-1">
              <span>Eligible ITC (Preliminary)</span>
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="text-xl font-bold text-emerald-700 tracking-tight font-mono">
              {formatINR(totals.eligibleItc)}
            </div>
          </div>
          <div className="mt-3 pt-2 border-t border-emerald-200/60 flex items-center justify-between text-[11px] text-emerald-700">
            <span>GSTR-3B Table 4(A)</span>
            <span className="font-semibold group-hover:underline flex items-center">
              {totals.eligibleCount} items <ArrowUpRight className="w-3 h-3 ml-0.5" />
            </span>
          </div>
        </div>

        {/* Ineligible / Blocked ITC */}
        <div
          onClick={() => onNavigateToRegister({ statusFilter: 'Ineligible' })}
          className="bg-rose-50/70 border border-rose-200/80 hover:border-rose-300 rounded-2xl p-4 shadow-xs relative overflow-hidden flex flex-col justify-between cursor-pointer transition-all hover:bg-rose-50 group"
        >
          <div>
            <div className="flex items-center justify-between text-rose-800 text-xs font-semibold mb-1">
              <span>Ineligible / Blocked</span>
              <XCircle className="w-4 h-4 text-rose-600" />
            </div>
            <div className="text-xl font-bold text-rose-700 tracking-tight font-mono">
              {formatINR(totals.ineligibleItc)}
            </div>
          </div>
          <div className="mt-3 pt-2 border-t border-rose-200/60 flex items-center justify-between text-[11px] text-rose-700">
            <span>Sec 17(5) / Non-biz</span>
            <span className="font-semibold group-hover:underline flex items-center">
              {totals.ineligibleCount} items <ArrowUpRight className="w-3 h-3 ml-0.5" />
            </span>
          </div>
        </div>

        {/* CA Review Required */}
        <div
          onClick={() => onNavigateToRegister({ statusFilter: 'CA Review Required' })}
          className="bg-amber-50/70 border border-amber-200/80 hover:border-amber-300 rounded-2xl p-4 shadow-xs relative overflow-hidden flex flex-col justify-between cursor-pointer transition-all hover:bg-amber-50 group"
        >
          <div>
            <div className="flex items-center justify-between text-amber-800 text-xs font-semibold mb-1">
              <span>CA Review Required</span>
              <AlertTriangle className="w-4 h-4 text-amber-600" />
            </div>
            <div className="text-xl font-bold text-amber-700 tracking-tight font-mono">
              {formatINR(totals.reviewItc)}
            </div>
          </div>
          <div className="mt-3 pt-2 border-t border-amber-200/60 flex items-center justify-between text-[11px] text-amber-700">
            <span>Rule 37 / 42 / Reconcile</span>
            <span className="font-semibold group-hover:underline flex items-center">
              {totals.reviewCount} items <ArrowUpRight className="w-3 h-3 ml-0.5" />
            </span>
          </div>
        </div>
      </div>

      {/* Visual Analytics Grid: ITC Donut Breakdown + Monthly Trend */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* ITC Distribution Meter */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <PieChart className="w-4 h-4 text-indigo-600" />
              <span>ITC Statutory Allocation</span>
            </h3>
            <span className="text-xs text-slate-500 font-mono">
              Total GST: {formatINR(totals.totalGst)}
            </span>
          </div>

          {/* Visual Percentage Bar */}
          <div className="space-y-2">
            <div className="h-4 w-full bg-slate-100 rounded-full overflow-hidden flex p-0.5 border border-slate-200">
              {totals.totalGst > 0 ? (
                <>
                  <div
                    style={{ width: `${(totals.eligibleItc / totals.totalGst) * 100}%` }}
                    className="bg-emerald-500 h-full rounded-l-full transition-all"
                    title={`Eligible: ${formatINR(totals.eligibleItc)}`}
                  ></div>
                  <div
                    style={{ width: `${(totals.ineligibleItc / totals.totalGst) * 100}%` }}
                    className="bg-rose-500 h-full transition-all"
                    title={`Ineligible: ${formatINR(totals.ineligibleItc)}`}
                  ></div>
                  <div
                    style={{ width: `${(totals.reviewItc / totals.totalGst) * 100}%` }}
                    className="bg-amber-500 h-full rounded-r-full transition-all"
                    title={`CA Review: ${formatINR(totals.reviewItc)}`}
                  ></div>
                </>
              ) : (
                <div className="w-full bg-slate-200 h-full rounded-full"></div>
              )}
            </div>

            {/* Legend Stats */}
            <div className="space-y-2.5 pt-2 text-xs">
              <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl border border-slate-200/70">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-emerald-500"></span>
                  <span className="text-slate-700 font-medium">Eligible Credit</span>
                </div>
                <div className="text-right">
                  <div className="font-bold text-emerald-700 font-mono">{formatINR(totals.eligibleItc)}</div>
                  <div className="text-[10px] text-slate-500">
                    {totals.totalGst > 0 ? Math.round((totals.eligibleItc / totals.totalGst) * 100) : 0}% of GST
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl border border-slate-200/70">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-rose-500"></span>
                  <span className="text-slate-700 font-medium">Ineligible / Blocked</span>
                </div>
                <div className="text-right">
                  <div className="font-bold text-rose-700 font-mono">{formatINR(totals.ineligibleItc)}</div>
                  <div className="text-[10px] text-slate-500">
                    {totals.totalGst > 0 ? Math.round((totals.ineligibleItc / totals.totalGst) * 100) : 0}% of GST
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl border border-slate-200/70">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-amber-500"></span>
                  <span className="text-slate-700 font-medium">CA Review Required</span>
                </div>
                <div className="text-right">
                  <div className="font-bold text-amber-700 font-mono">{formatINR(totals.reviewItc)}</div>
                  <div className="text-[10px] text-slate-500">
                    {totals.totalGst > 0 ? Math.round((totals.reviewItc / totals.totalGst) * 100) : 0}% of GST
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Monthly Expense & Tax Trend */}
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-indigo-600" />
                <span>Monthly Expense & GST Trend</span>
              </h3>
              <p className="text-xs text-slate-500">Total invoice volume by financial periods</p>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="flex items-center gap-1.5 text-slate-600 font-medium">
                <span className="w-2.5 h-2.5 rounded-sm bg-indigo-600"></span> Total Expense
              </span>
              <span className="flex items-center gap-1.5 text-emerald-700 font-medium">
                <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500"></span> Eligible GST
              </span>
            </div>
          </div>

          {/* Bar Chart Visualization */}
          {monthlyStats.length > 0 ? (
            <div className="space-y-3 py-2">
              {monthlyStats.map((item) => {
                const totalPct = Math.min(100, Math.max(8, (item.totalAmount / maxMonthlyAmount) * 100));

                return (
                  <div key={item.monthKey} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-slate-800">{item.monthLabel}</span>
                      <span className="text-slate-500 font-mono">
                        {formatINR(item.totalAmount)} ({item.count} bills)
                      </span>
                    </div>
                    <div className="h-6 w-full bg-slate-100 rounded-lg overflow-hidden flex border border-slate-200 p-0.5">
                      <div
                        style={{ width: `${totalPct}%` }}
                        className="bg-indigo-600 hover:bg-indigo-700 h-full rounded-md transition-all relative flex items-center justify-between px-2 text-[10px] text-white font-medium shadow-xs"
                      >
                        <span className="truncate">Tax: {formatINR(item.gstAmount)}</span>
                        {item.eligibleGst > 0 && (
                          <span className="text-emerald-200 text-[10px] font-semibold">
                            Eligible: {formatINR(item.eligibleGst)}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="py-12 text-center text-xs text-slate-400">
              No monthly expense records match the active filter criteria.
            </div>
          )}

          <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
            <span>Aggregated across all registered tax invoices</span>
            <button
              type="button"
              onClick={() => onNavigateToRegister()}
              className="text-indigo-600 hover:text-indigo-700 font-semibold flex items-center gap-1"
            >
              <span>View detailed register</span>
              <ChevronRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>

      {/* Category Breakdown & Urgent CA Attention Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Category Breakdown Table */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Layers className="w-4 h-4 text-indigo-600" />
              <span>Expense Breakdown by Accounting Category</span>
            </h3>
            <span className="text-xs text-slate-500">{categoryStats.length} active categories</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-semibold">
                  <th className="pb-2.5">Category</th>
                  <th className="pb-2.5 text-center">Bills</th>
                  <th className="pb-2.5 text-right">Total Amount</th>
                  <th className="pb-2.5 text-right">GST</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {categoryStats.slice(0, 7).map((item) => (
                  <tr
                    key={item.category}
                    onClick={() => onNavigateToRegister({ categoryFilter: item.category })}
                    className="hover:bg-slate-50 cursor-pointer transition-colors group"
                  >
                    <td className="py-2.5 font-medium text-slate-800 group-hover:text-indigo-600">
                      {item.category}
                    </td>
                    <td className="py-2.5 text-center text-slate-500">
                      <span className="px-1.5 py-0.5 bg-slate-100 text-slate-700 rounded text-[11px] font-medium">
                        {item.count}
                      </span>
                    </td>
                    <td className="py-2.5 text-right font-mono text-slate-800">
                      {formatINR(item.totalAmount)}
                    </td>
                    <td className="py-2.5 text-right font-mono text-indigo-600 font-semibold">
                      {formatINR(item.totalGst)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Urgent CA Review Action Center */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-1">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600" />
                <span>Action Items: Requiring CA Verification</span>
              </h3>
              <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[11px] font-semibold">
                {urgentReviewItems.length} items
              </span>
            </div>
            <p className="text-xs text-slate-500 mb-3">
              Invoices with 180-day flags, Rule 42 apportionment, or pending statutory proofs
            </p>

            <div className="space-y-2.5">
              {urgentReviewItems.length > 0 ? (
                urgentReviewItems.map((exp) => (
                  <div
                    key={exp.id}
                    onClick={() => onSelectExpense(exp)}
                    className="p-3 bg-slate-50 hover:bg-amber-50/60 rounded-xl border border-slate-200 hover:border-amber-300 transition-all cursor-pointer group"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="font-semibold text-slate-900 text-xs group-hover:text-amber-800 flex items-center gap-2">
                          <span>{exp.supplierName}</span>
                          <span className="text-[10px] text-slate-500 font-mono">
                            #{exp.invoiceNumber}
                          </span>
                        </div>
                        <div className="text-[11px] text-amber-700 mt-1 flex items-center gap-1 font-medium">
                          <Clock className="w-3 h-3 shrink-0" />
                          <span>{exp.itcDecision.primaryReason}</span>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <div className="text-xs font-bold text-slate-900 font-mono">
                          {formatINR(exp.totalGst)}
                        </div>
                        <span className="text-[10px] text-slate-500">GST at stake</span>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="py-8 text-center bg-slate-50 rounded-xl border border-slate-200/80 p-4">
                  <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto mb-2 opacity-80" />
                  <p className="text-xs font-semibold text-slate-800">No Pending CA Review Flags</p>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    All filtered invoices have passed clean preliminary evaluation.
                  </p>
                </div>
              )}
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="text-slate-500 text-[11px]">
              Click any invoice to review full decision trail & statutory checklist
            </span>
            <button
              type="button"
              onClick={() => onNavigateToRegister({ statusFilter: 'CA Review Required' })}
              className="text-amber-700 hover:text-amber-800 font-semibold flex items-center gap-1"
            >
              <span>View all flags</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

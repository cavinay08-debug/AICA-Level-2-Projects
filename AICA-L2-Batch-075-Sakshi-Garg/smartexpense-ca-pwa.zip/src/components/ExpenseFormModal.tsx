/**
 * SmartExpense CA - Add/Edit Expense Form Modal
 * Features keyword-based AI category suggestion, live GSTIN format checking,
 * tax split validation, and real-time ITC compliance decision preview.
 */

import {
  AlertCircle,
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  HelpCircle,
  Info,
  Layers,
  Percent,
  Receipt,
  Scale,
  Sparkles,
  X,
  XCircle,
} from 'lucide-react';
import React, { useEffect, useMemo, useState } from 'react';
import { classifyExpense } from '../lib/classifier';
import {
  INDIAN_STATE_CODES,
  formatINR,
  roundTwoDecimals,
  validateGstinFormat,
  validateTaxConsistency,
} from '../lib/gstUtils';
import { evaluateItcEligibility } from '../lib/itcRules';
import {
  BusinessUse,
  Expense,
  ExpenseCategory,
  ExpenseFormData,
  Gstr2bStatus,
  SpecialException,
  SupplierPaymentStatus,
  TaxableOutwardSupply,
  TriStateConfirmation,
} from '../types';

const CATEGORIES: ExpenseCategory[] = [
  'Office supplies',
  'Professional fees',
  'Software and subscriptions',
  'Rent',
  'Telephone and internet',
  'Advertising and marketing',
  'Business travel',
  'Food and beverages',
  'Employee welfare',
  'Motor vehicle / car expenses',
  'Insurance',
  'Club / fitness membership',
  'Construction / civil works',
  'Personal expense',
  'Capital goods',
  'Other',
];

interface ExpenseFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (expenseData: ExpenseFormData, existingId?: string) => void;
  initialExpense?: Expense | null;
}

export const ExpenseFormModal: React.FC<ExpenseFormModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialExpense,
}) => {
  const [formData, setFormData] = useState<ExpenseFormData>({
    invoiceNumber: '',
    invoiceDate: new Date().toISOString().substring(0, 10),
    supplierName: '',
    supplierGstin: '',
    recipientGstin: '27AACCU1234M1Z1',
    description: '',
    category: 'Software and subscriptions',
    suggestedCategory: undefined,
    categoryMatchReason: undefined,
    taxableValue: 10000,
    cgstAmount: 900,
    sgstAmount: 900,
    igstAmount: 0,
    cessAmount: 0,
    totalAmount: 11800,
    supplierPaymentStatus: 'Paid',
    paymentDate: new Date().toISOString().substring(0, 10),
    goodsServicesReceived: 'Yes',
    taxInvoiceAvailable: 'Yes',
    reflectedInGstr2b: 'Yes',
    usedForBusiness: 'Yes',
    usedForTaxableOutwardSupply: 'Yes',
    specialException: 'No',
    notes: '',
  });

  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [taxMode, setTaxMode] = useState<'intra' | 'inter'>('intra'); // intra: CGST+SGST, inter: IGST
  const [activeTab, setActiveTab] = useState<'details' | 'tax' | 'compliance'>('details');

  // Populate when editing
  useEffect(() => {
    if (initialExpense) {
      setFormData({
        invoiceNumber: initialExpense.invoiceNumber,
        invoiceDate: initialExpense.invoiceDate,
        supplierName: initialExpense.supplierName,
        supplierGstin: initialExpense.supplierGstin,
        recipientGstin: initialExpense.recipientGstin,
        description: initialExpense.description,
        category: initialExpense.category,
        suggestedCategory: initialExpense.suggestedCategory,
        categoryMatchReason: initialExpense.categoryMatchReason,
        taxableValue: initialExpense.taxableValue,
        cgstAmount: initialExpense.cgstAmount,
        sgstAmount: initialExpense.sgstAmount,
        igstAmount: initialExpense.igstAmount,
        cessAmount: initialExpense.cessAmount,
        totalAmount: initialExpense.totalAmount,
        supplierPaymentStatus: initialExpense.supplierPaymentStatus,
        paymentDate: initialExpense.paymentDate,
        goodsServicesReceived: initialExpense.goodsServicesReceived,
        taxInvoiceAvailable: initialExpense.taxInvoiceAvailable,
        reflectedInGstr2b: initialExpense.reflectedInGstr2b,
        usedForBusiness: initialExpense.usedForBusiness,
        usedForTaxableOutwardSupply: initialExpense.usedForTaxableOutwardSupply,
        specialException: initialExpense.specialException,
        notes: initialExpense.notes || '',
      });
      if (initialExpense.igstAmount > 0) {
        setTaxMode('inter');
      } else {
        setTaxMode('intra');
      }
    } else {
      // Default reset
      setFormData({
        invoiceNumber: '',
        invoiceDate: new Date().toISOString().substring(0, 10),
        supplierName: '',
        supplierGstin: '',
        recipientGstin: '27AACCU1234M1Z1',
        description: '',
        category: 'Software and subscriptions',
        suggestedCategory: undefined,
        categoryMatchReason: undefined,
        taxableValue: 10000,
        cgstAmount: 900,
        sgstAmount: 900,
        igstAmount: 0,
        cessAmount: 0,
        totalAmount: 11800,
        supplierPaymentStatus: 'Paid',
        paymentDate: new Date().toISOString().substring(0, 10),
        goodsServicesReceived: 'Yes',
        taxInvoiceAvailable: 'Yes',
        reflectedInGstr2b: 'Yes',
        usedForBusiness: 'Yes',
        usedForTaxableOutwardSupply: 'Yes',
        specialException: 'No',
        notes: '',
      });
      setTaxMode('intra');
    }
    setFormErrors({});
  }, [initialExpense, isOpen]);

  // AI-Assisted Classification suggestion
  const aiSuggestion = useMemo(() => {
    return classifyExpense(formData.description, formData.supplierName);
  }, [formData.description, formData.supplierName]);

  // Live GSTIN format check
  const gstinValidation = useMemo(() => {
    return validateGstinFormat(formData.supplierGstin);
  }, [formData.supplierGstin]);

  // Total amount auto-calculation
  const calculatedTotal = useMemo(() => {
    const taxable = roundTwoDecimals(formData.taxableValue || 0);
    const cgst = roundTwoDecimals(formData.cgstAmount || 0);
    const sgst = roundTwoDecimals(formData.sgstAmount || 0);
    const igst = roundTwoDecimals(formData.igstAmount || 0);
    const cess = roundTwoDecimals(formData.cessAmount || 0);
    return roundTwoDecimals(taxable + cgst + sgst + igst + cess);
  }, [formData.taxableValue, formData.cgstAmount, formData.sgstAmount, formData.igstAmount, formData.cessAmount]);

  // Synchronize totalAmount
  useEffect(() => {
    setFormData((prev) => ({ ...prev, totalAmount: calculatedTotal }));
  }, [calculatedTotal]);

  // Live ITC Compliance Decision Preview
  const liveDecision = useMemo(() => {
    return evaluateItcEligibility(formData);
  }, [formData]);

  // Apply Quick GST Rate Helper (e.g. 18%, 12%, 5%, 28%)
  const applyGstRate = (ratePercent: number) => {
    const taxable = roundTwoDecimals(formData.taxableValue || 0);
    const totalTax = roundTwoDecimals((taxable * ratePercent) / 100);

    if (taxMode === 'intra') {
      const halfTax = roundTwoDecimals(totalTax / 2);
      setFormData((prev) => ({
        ...prev,
        cgstAmount: halfTax,
        sgstAmount: halfTax,
        igstAmount: 0,
      }));
    } else {
      setFormData((prev) => ({
        ...prev,
        cgstAmount: 0,
        sgstAmount: 0,
        igstAmount: totalTax,
      }));
    }
  };

  const handleTaxModeChange = (mode: 'intra' | 'inter') => {
    setTaxMode(mode);
    const currentTax = (formData.cgstAmount || 0) + (formData.sgstAmount || 0) + (formData.igstAmount || 0);
    if (mode === 'intra') {
      const half = roundTwoDecimals(currentTax / 2);
      setFormData((prev) => ({
        ...prev,
        cgstAmount: half,
        sgstAmount: half,
        igstAmount: 0,
      }));
    } else {
      setFormData((prev) => ({
        ...prev,
        cgstAmount: 0,
        sgstAmount: 0,
        igstAmount: roundTwoDecimals(currentTax),
      }));
    }
  };

  // Form Submission Validation
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errors: Record<string, string> = {};

    if (!formData.invoiceNumber.trim()) {
      errors.invoiceNumber = 'Invoice Number is required.';
    }
    if (!formData.invoiceDate) {
      errors.invoiceDate = 'Invoice Date is required.';
    }
    if (!formData.supplierName.trim()) {
      errors.supplierName = 'Supplier Name is required.';
    }
    if (formData.taxableValue <= 0) {
      errors.taxableValue = 'Taxable Value must be greater than 0.';
    }

    // Negative value checks
    if (formData.taxableValue < 0 || formData.cgstAmount < 0 || formData.sgstAmount < 0 || formData.igstAmount < 0 || formData.cessAmount < 0) {
      errors.tax = 'Amounts cannot be negative.';
    }

    // Mutual exclusivity tax check
    const taxCheck = validateTaxConsistency(
      formData.taxableValue,
      formData.cgstAmount,
      formData.sgstAmount,
      formData.igstAmount
    );
    if (!taxCheck.isValid) {
      errors.tax = taxCheck.error || 'Invalid tax configuration.';
    }

    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }

    // Save
    onSave(
      {
        ...formData,
        suggestedCategory: aiSuggestion.category,
        categoryMatchReason: aiSuggestion.explanation,
      },
      initialExpense?.id
    );
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-2xl shadow-xl w-full max-w-4xl max-h-[92vh] flex flex-col text-slate-700 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/80">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 border border-indigo-100 flex items-center justify-center font-bold">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">
                {initialExpense ? 'Edit Expense & Review ITC' : 'Record New Expense Invoice'}
              </h2>
              <p className="text-xs text-slate-500">
                GST Input Tax Credit Classification & Section 16/17 Validation
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation for Step Clarity */}
        <div className="flex border-b border-slate-200 bg-slate-50/50 px-6 gap-6 text-xs font-semibold">
          <button
            type="button"
            onClick={() => setActiveTab('details')}
            className={`py-3 border-b-2 transition-colors flex items-center gap-2 ${
              activeTab === 'details'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <span>1. Invoice & Supplier</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('tax')}
            className={`py-3 border-b-2 transition-colors flex items-center gap-2 ${
              activeTab === 'tax'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <span>2. Valuation & Tax Split</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('compliance')}
            className={`py-3 border-b-2 transition-colors flex items-center gap-2 ${
              activeTab === 'compliance'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <span>3. Section 16/17 Compliance Questions</span>
          </button>
        </div>

        {/* Form Body with Live Preview Sidebar */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto flex flex-col md:flex-row">
          {/* Main Form Fields (2/3 width) */}
          <div className="flex-1 p-6 space-y-5 border-b md:border-b-0 md:border-r border-slate-200">
            {/* Global Error Banner */}
            {Object.keys(formErrors).length > 0 && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                <div>
                  <strong className="block">Please correct the highlighted errors:</strong>
                  <ul className="list-disc pl-4 mt-0.5 space-y-0.5 text-rose-700">
                    {Object.values(formErrors).map((err, i) => (
                      <li key={i}>{err}</li>
                    ))}
                  </ul>
                </div>
              </div>
            )}

            {/* TAB 1: INVOICE & SUPPLIER DETAILS */}
            {activeTab === 'details' && (
              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Invoice Number */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Invoice Number <span className="text-rose-600">*</span>
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. INV-2026-0042"
                      value={formData.invoiceNumber}
                      onChange={(e) => setFormData({ ...formData, invoiceNumber: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 font-mono"
                    />
                  </div>

                  {/* Invoice Date */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Invoice Date (DD/MM/YYYY) <span className="text-rose-600">*</span>
                    </label>
                    <input
                      type="date"
                      value={formData.invoiceDate}
                      onChange={(e) => setFormData({ ...formData, invoiceDate: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-hidden focus:bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 font-mono"
                    />
                  </div>
                </div>

                {/* Supplier Name */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Supplier Legal / Trade Name <span className="text-rose-600">*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Acme Cloud Infrastructure Technologies Pvt Ltd"
                    value={formData.supplierName}
                    onChange={(e) => setFormData({ ...formData, supplierName: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                  />
                </div>

                {/* Supplier GSTIN with Live Format Validator */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-semibold text-slate-700">
                      Supplier GSTIN (15 Digits)
                    </label>
                    {formData.supplierGstin && (
                      <span
                        className={`text-[11px] font-semibold flex items-center gap-1 ${
                          gstinValidation.isValid ? 'text-emerald-700' : 'text-amber-700'
                        }`}
                      >
                        {gstinValidation.isValid ? (
                          <>
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            <span>{gstinValidation.stateName} (Valid Format)</span>
                          </>
                        ) : (
                          <>
                            <AlertTriangle className="w-3 h-3 text-amber-600" />
                            <span>Invalid Format</span>
                          </>
                        )}
                      </span>
                    )}
                  </div>
                  <input
                    type="text"
                    placeholder="e.g. 27AABCC1234F1Z5"
                    value={formData.supplierGstin}
                    onChange={(e) => setFormData({ ...formData, supplierGstin: e.target.value.toUpperCase() })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 font-mono uppercase"
                    maxLength={15}
                  />
                  <p className="text-[10px] text-slate-500 mt-1">
                    Format check: 2 digits State Code + 10 char PAN + Entity number + 'Z' + Checksum. Does not prove active live portal status.
                  </p>
                </div>

                {/* Recipient GSTIN */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Recipient GSTIN (Your Registered Entity)
                  </label>
                  <input
                    type="text"
                    placeholder="27AACCU1234M1Z1"
                    value={formData.recipientGstin}
                    onChange={(e) => setFormData({ ...formData, recipientGstin: e.target.value.toUpperCase() })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 font-mono uppercase"
                    maxLength={15}
                  />
                </div>

                {/* Expense Description */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Expense Description & Line Item Details
                  </label>
                  <textarea
                    rows={2}
                    placeholder="e.g. Annual AWS Cloud Hosting Server, JetBrains IDE License, or Executive Flight Ticket"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                  />
                </div>

                {/* AI-Assisted Category Suggester Pill & Selector */}
                <div className="p-3.5 bg-indigo-50/40 rounded-xl border border-indigo-100 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 text-xs text-indigo-700 font-semibold">
                      <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                      <span>AI Category Recommendation</span>
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-700 border border-indigo-200 font-semibold">
                      Confidence: {aiSuggestion.confidence}
                    </span>
                  </div>

                  <div className="flex items-center justify-between bg-white p-2.5 rounded-xl border border-indigo-100 text-xs shadow-xs">
                    <div>
                      <span className="text-slate-500 text-[11px] block">Suggested Category:</span>
                      <strong className="text-slate-900 text-sm">{aiSuggestion.category}</strong>
                      <p className="text-[10px] text-slate-500 mt-0.5">{aiSuggestion.explanation}</p>
                    </div>
                    {formData.category !== aiSuggestion.category && (
                      <button
                        type="button"
                        onClick={() => setFormData({ ...formData, category: aiSuggestion.category })}
                        className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-[11px] font-semibold transition-colors shrink-0 shadow-xs"
                      >
                        Apply Suggestion
                      </button>
                    )}
                  </div>

                  {/* Category Selection Override */}
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Final Selected Accounting Category (Editable by User):
                    </label>
                    <select
                      value={formData.category}
                      onChange={(e) => setFormData({ ...formData, category: e.target.value as ExpenseCategory })}
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-hidden focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                    >
                      {CATEGORIES.map((cat) => (
                        <option key={cat} value={cat}>
                          {cat}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    type="button"
                    onClick={() => setActiveTab('tax')}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-xl shadow-xs flex items-center gap-1 transition-colors"
                  >
                    <span>Proceed to Valuation & Tax</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}

            {/* TAB 2: VALUATION & TAX BREAKDOWN */}
            {activeTab === 'tax' && (
              <div className="space-y-4">
                {/* Tax Mode Switch: Intra-State vs Inter-State */}
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                  <span className="text-xs font-semibold text-slate-700 block">
                    Select Place of Supply / Tax Structure:
                  </span>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => handleTaxModeChange('intra')}
                      className={`py-2 px-3 rounded-xl text-xs font-semibold transition-all ${
                        taxMode === 'intra'
                          ? 'bg-indigo-600 text-white shadow-xs'
                          : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      Intra-State (CGST + SGST)
                    </button>
                    <button
                      type="button"
                      onClick={() => handleTaxModeChange('inter')}
                      className={`py-2 px-3 rounded-xl text-xs font-semibold transition-all ${
                        taxMode === 'inter'
                          ? 'bg-indigo-600 text-white shadow-xs'
                          : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      Inter-State (IGST)
                    </button>
                  </div>
                </div>

                {/* Taxable Value */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Taxable Base Value (₹) <span className="text-rose-600">*</span>
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.taxableValue}
                    onChange={(e) => setFormData({ ...formData, taxableValue: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-hidden focus:bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 font-mono"
                  />
                </div>

                {/* Quick GST Rate Buttons */}
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1.5">
                    Quick Standard GST Rates:
                  </label>
                  <div className="flex items-center gap-2 flex-wrap">
                    {[5, 12, 18, 28].map((rate) => (
                      <button
                        key={rate}
                        type="button"
                        onClick={() => applyGstRate(rate)}
                        className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 rounded-lg text-xs font-mono font-semibold transition-colors"
                      >
                        {rate}% GST
                      </button>
                    ))}
                    <button
                      type="button"
                      onClick={() => setFormData((prev) => ({ ...prev, cgstAmount: 0, sgstAmount: 0, igstAmount: 0 }))}
                      className="px-3 py-1 bg-slate-50 hover:bg-slate-100 text-slate-600 border border-slate-200 rounded-lg text-xs font-mono transition-colors"
                    >
                      0% (Nil / Exempt)
                    </button>
                  </div>
                </div>

                {/* Tax Component Inputs */}
                {taxMode === 'intra' ? (
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        CGST Amount (₹)
                      </label>
                      <input
                        type="number"
                        min="0"
                        step="0.01"
                        value={formData.cgstAmount}
                        onChange={(e) => setFormData({ ...formData, cgstAmount: parseFloat(e.target.value) || 0 })}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-mono focus:outline-hidden focus:bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        SGST / UTGST Amount (₹)
                      </label>
                      <input
                        type="number"
                        min="0"
                        step="0.01"
                        value={formData.sgstAmount}
                        onChange={(e) => setFormData({ ...formData, sgstAmount: parseFloat(e.target.value) || 0 })}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-mono focus:outline-hidden focus:bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                      />
                    </div>
                  </div>
                ) : (
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Integrated Tax / IGST Amount (₹)
                    </label>
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={formData.igstAmount}
                      onChange={(e) => setFormData({ ...formData, igstAmount: parseFloat(e.target.value) || 0 })}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-mono focus:outline-hidden focus:bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                    />
                  </div>
                )}

                {/* Cess (Optional) */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    GST Compensation Cess (₹, Optional)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.cessAmount}
                    onChange={(e) => setFormData({ ...formData, cessAmount: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-mono focus:outline-hidden focus:bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                  />
                </div>

                {/* Auto-Calculated Total Amount Display */}
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
                  <div>
                    <span className="text-[11px] text-slate-500 block font-medium">
                      Calculated Total Invoice Amount:
                    </span>
                    <span className="text-lg font-bold text-slate-900 font-mono">
                      {formatINR(calculatedTotal)}
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-[11px] text-slate-500 block">Total GST Component:</span>
                    <span className="text-sm font-bold text-indigo-600 font-mono">
                      {formatINR((formData.cgstAmount || 0) + (formData.sgstAmount || 0) + (formData.igstAmount || 0) + (formData.cessAmount || 0))}
                    </span>
                  </div>
                </div>

                <div className="pt-2 flex justify-between">
                  <button
                    type="button"
                    onClick={() => setActiveTab('details')}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl transition-colors"
                  >
                    Back
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveTab('compliance')}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-xl shadow-xs flex items-center gap-1 transition-colors"
                  >
                    <span>Proceed to Section 16/17 Audit</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}

            {/* TAB 3: SECTION 16 & 17 COMPLIANCE QUESTIONS */}
            {activeTab === 'compliance' && (
              <div className="space-y-4">
                {/* Supplier Payment Status & 180 Days */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Supplier Payment Status
                    </label>
                    <select
                      value={formData.supplierPaymentStatus}
                      onChange={(e) => setFormData({ ...formData, supplierPaymentStatus: e.target.value as SupplierPaymentStatus })}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-hidden focus:bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                    >
                      <option value="Paid">Paid</option>
                      <option value="Unpaid">Unpaid</option>
                      <option value="Partially paid">Partially paid</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Payment Date (if paid)
                    </label>
                    <input
                      type="date"
                      value={formData.paymentDate || ''}
                      onChange={(e) => setFormData({ ...formData, paymentDate: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-mono focus:outline-hidden focus:bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                    />
                  </div>
                </div>

                {/* Section 16 Conditions Matrix */}
                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                  <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                    Section 16 Statutory Verification Checklist:
                  </h4>

                  {/* 1. Tax Invoice Available */}
                  <div className="flex items-center justify-between text-xs py-1 border-b border-slate-200/80">
                    <span className="text-slate-700 font-medium">Valid Tax Invoice / Debit Note in possession?</span>
                    <select
                      value={formData.taxInvoiceAvailable}
                      onChange={(e) => setFormData({ ...formData, taxInvoiceAvailable: e.target.value as 'Yes' | 'No' })}
                      className="bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-800 shadow-xs focus:outline-hidden focus:border-indigo-500"
                    >
                      <option value="Yes">Yes</option>
                      <option value="No">No (Blocked)</option>
                    </select>
                  </div>

                  {/* 2. Goods / Services Received */}
                  <div className="flex items-center justify-between text-xs py-1 border-b border-slate-200/80">
                    <span className="text-slate-700 font-medium">Goods or services physically received?</span>
                    <select
                      value={formData.goodsServicesReceived}
                      onChange={(e) => setFormData({ ...formData, goodsServicesReceived: e.target.value as TriStateConfirmation })}
                      className="bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-800 shadow-xs focus:outline-hidden focus:border-indigo-500"
                    >
                      <option value="Yes">Yes</option>
                      <option value="No">No</option>
                      <option value="Not confirmed">Not confirmed</option>
                    </select>
                  </div>

                  {/* 3. GSTR-2B Statement */}
                  <div className="flex items-center justify-between text-xs py-1 border-b border-slate-200/80">
                    <span className="text-slate-700 font-medium">Reflected & matched in auto-drafted GSTR-2B?</span>
                    <select
                      value={formData.reflectedInGstr2b}
                      onChange={(e) => setFormData({ ...formData, reflectedInGstr2b: e.target.value as Gstr2bStatus })}
                      className="bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-800 shadow-xs focus:outline-hidden focus:border-indigo-500"
                    >
                      <option value="Yes">Yes</option>
                      <option value="No">No</option>
                      <option value="Not checked">Not checked</option>
                    </select>
                  </div>

                  {/* 4. Business Use */}
                  <div className="flex items-center justify-between text-xs py-1 border-b border-slate-200/80">
                    <span className="text-slate-700 font-medium">Used strictly in course/furtherance of business?</span>
                    <select
                      value={formData.usedForBusiness}
                      onChange={(e) => setFormData({ ...formData, usedForBusiness: e.target.value as BusinessUse })}
                      className="bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-800 shadow-xs focus:outline-hidden focus:border-indigo-500"
                    >
                      <option value="Yes">Yes (100% Business)</option>
                      <option value="No">No (Personal)</option>
                      <option value="Partly">Partly (Rule 42 Apportionment)</option>
                    </select>
                  </div>

                  {/* 5. Taxable Outward Supply */}
                  <div className="flex items-center justify-between text-xs py-1">
                    <span className="text-slate-700 font-medium">Used for making taxable/zero-rated supplies?</span>
                    <select
                      value={formData.usedForTaxableOutwardSupply}
                      onChange={(e) => setFormData({ ...formData, usedForTaxableOutwardSupply: e.target.value as TaxableOutwardSupply })}
                      className="bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-800 shadow-xs focus:outline-hidden focus:border-indigo-500"
                    >
                      <option value="Yes">Yes (Taxable / Export)</option>
                      <option value="No">No (Exempt only)</option>
                      <option value="Partly">Partly (Common Credit)</option>
                      <option value="Not confirmed">Not confirmed</option>
                    </select>
                  </div>
                </div>

                {/* Section 17(5) Special Exception Case */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Is this a Special Statutory Exception Case? (Section 17(5) proviso)
                  </label>
                  <select
                    value={formData.specialException}
                    onChange={(e) => setFormData({ ...formData, specialException: e.target.value as SpecialException })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-hidden focus:bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                  >
                    <option value="No">No Special Exception</option>
                    <option value="Further supply of same category">Further supply of same category (e.g. sub-contract catering / car resale / works contract)</option>
                    <option value="Passenger transport">Passenger transportation business (commercial taxi/bus fleet)</option>
                    <option value="Driving training">Driving training school vehicle</option>
                    <option value="Statutory employer obligation">Statutory employer obligation under law (e.g. Factories Act, worker insurance)</option>
                    <option value="Other / not sure">Other / Not sure (Flags for CA review)</option>
                  </select>
                </div>

                {/* Notes & Document Reference */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Audit Notes & Physical Document Reference
                  </label>
                  <textarea
                    rows={2}
                    placeholder="e.g. GRN #1042 attached, vendor payment voucher #88, or board resolution approval."
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Real-Time Compliance Decision Preview Sidebar (1/3 width) */}
          <div className="w-full md:w-80 bg-slate-50/80 p-5 space-y-4 flex flex-col justify-between border-t md:border-t-0 md:border-l border-slate-200">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                  <Scale className="w-4 h-4 text-indigo-600" />
                  <span>Live ITC Audit Preview</span>
                </h3>
                <span className="text-[10px] text-slate-400 font-medium">Rules Engine</span>
              </div>

              {/* Status Outcome Banner */}
              <div
                className={`p-3.5 rounded-xl border flex flex-col gap-1.5 ${
                  liveDecision.status === 'Eligible'
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                    : liveDecision.status === 'Ineligible'
                    ? 'bg-rose-50 border-rose-200 text-rose-800'
                    : 'bg-amber-50 border-amber-200 text-amber-800'
                }`}
              >
                <div className="flex items-center gap-2 font-bold text-sm">
                  {liveDecision.status === 'Eligible' && <CheckCircle2 className="w-5 h-5 text-emerald-600" />}
                  {liveDecision.status === 'Ineligible' && <XCircle className="w-5 h-5 text-rose-600" />}
                  {liveDecision.status === 'CA Review Required' && <AlertTriangle className="w-5 h-5 text-amber-600" />}
                  <span>{liveDecision.status}</span>
                </div>
                <p className="text-xs opacity-90 leading-snug">
                  {liveDecision.primaryReason}
                </p>
                <div className="text-[10px] opacity-75 font-mono pt-1 border-t border-current/20">
                  {liveDecision.legalReference}
                </div>
              </div>

              {/* Financial Split Preview */}
              <div className="p-3 bg-white rounded-xl border border-slate-200 space-y-2 text-xs shadow-xs">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Total Invoice Amount:</span>
                  <span className="font-mono font-bold text-slate-900">{formatINR(calculatedTotal)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Total GST Component:</span>
                  <span className="font-mono font-bold text-indigo-600">
                    {formatINR((formData.cgstAmount || 0) + (formData.sgstAmount || 0) + (formData.igstAmount || 0) + (formData.cessAmount || 0))}
                  </span>
                </div>
                <div className="pt-1.5 border-t border-slate-100 flex items-center justify-between font-semibold">
                  <span className="text-emerald-700">Admissible Credit:</span>
                  <span className="font-mono text-emerald-700 font-bold">
                    {formatINR(liveDecision.eligibleAmount)}
                  </span>
                </div>
              </div>

              {/* Active Compliance Flags */}
              {liveDecision.flags.length > 0 && (
                <div className="space-y-1.5">
                  <span className="text-[11px] font-semibold text-slate-600 block">
                    Statutory Flags & Caveats:
                  </span>
                  <div className="space-y-1">
                    {liveDecision.flags.map((flag, idx) => (
                      <div
                        key={idx}
                        className="text-[10px] p-2 bg-amber-50 border border-amber-200 text-amber-800 rounded-lg flex items-start gap-1.5 font-medium"
                      >
                        <Info className="w-3 h-3 text-amber-600 shrink-0 mt-0.5" />
                        <span>{flag}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Save & Cancel Action Buttons */}
            <div className="pt-4 border-t border-slate-200 space-y-2">
              <button
                type="submit"
                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-xs transition-all active:scale-98 cursor-pointer"
              >
                {initialExpense ? 'Update Invoice & Decision' : 'Save Invoice & Record Decision'}
              </button>
              <button
                type="button"
                onClick={onClose}
                className="w-full py-2 bg-white hover:bg-slate-100 text-slate-600 border border-slate-200 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

/**
 * SmartExpense CA - CSV Bulk Import & Batch Assessment Modal
 * Provides drag-and-drop / file upload, copy-paste CSV mode, download sample template,
 * live batch statutory evaluation, preview filter chips, and selective import.
 */

import {
  AlertCircle,
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  Download,
  FileSpreadsheet,
  FileText,
  Filter,
  HelpCircle,
  Layers,
  Percent,
  Plus,
  Receipt,
  Scale,
  Sparkles,
  Trash2,
  UploadCloud,
  X,
  XCircle,
} from 'lucide-react';
import React, { useId, useMemo, useRef, useState } from 'react';
import {
  CsvImportSummary,
  downloadCsvTemplate,
  parseInvoiceCsv,
  ParsedCsvRowResult,
} from '../lib/csvImporter';
import { formatDateDDMMYYYY, formatINR } from '../lib/gstUtils';
import { Expense, ItcStatus } from '../types';

interface CsvImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImportExpenses: (expenses: Expense[]) => void;
}

export const CsvImportModal: React.FC<CsvImportModalProps> = ({
  isOpen,
  onClose,
  onImportExpenses,
}) => {
  const fileInputId = useId();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [dragActive, setDragActive] = useState(false);
  const [fileName, setFileName] = useState<string | null>(null);
  const [rawCsvText, setRawCsvText] = useState<string>('');
  const [inputMode, setInputMode] = useState<'upload' | 'paste'>('upload');

  const [importSummary, setImportSummary] = useState<CsvImportSummary | null>(null);
  const [selectedRowIndices, setSelectedRowIndices] = useState<Set<number>>(new Set());
  const [previewFilter, setPreviewFilter] = useState<'All' | ItcStatus | 'Errors'>('All');

  // Process text into batch summary
  const processCsv = (text: string, name?: string) => {
    if (!text.trim()) {
      setImportSummary(null);
      setSelectedRowIndices(new Set());
      return;
    }

    try {
      const summary = parseInvoiceCsv(text);
      setImportSummary(summary);
      if (name) setFileName(name);

      // Select all non-error rows by default
      const initialSelected = new Set<number>();
      summary.rows.forEach((r, idx) => {
        if (r.validationStatus !== 'error') {
          initialSelected.add(idx);
        }
      });
      setSelectedRowIndices(initialSelected);
    } catch (err) {
      console.error('Failed to parse CSV', err);
    }
  };

  const handleFileUpload = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      setRawCsvText(text);
      processCsv(text, file.name);
    };
    reader.readAsText(file);
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  };

  const handleReset = () => {
    setFileName(null);
    setRawCsvText('');
    setImportSummary(null);
    setSelectedRowIndices(new Set());
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Toggle single row selection
  const toggleRowSelection = (idx: number) => {
    const next = new Set(selectedRowIndices);
    if (next.has(idx)) {
      next.delete(idx);
    } else {
      next.add(idx);
    }
    setSelectedRowIndices(next);
  };

  // Filtered rows for preview table
  const filteredRows = useMemo(() => {
    if (!importSummary) return [];
    return importSummary.rows.filter((r) => {
      if (previewFilter === 'All') return true;
      if (previewFilter === 'Errors') return r.validationStatus === 'error';
      return r.expense.itcDecision.status === previewFilter;
    });
  }, [importSummary, previewFilter]);

  // Total selected expenses
  const selectedExpenses = useMemo(() => {
    if (!importSummary) return [];
    return importSummary.rows
      .filter((_, idx) => selectedRowIndices.has(idx) && _.validationStatus !== 'error')
      .map((r) => r.expense);
  }, [importSummary, selectedRowIndices]);

  // Selected metrics
  const selectedMetrics = useMemo(() => {
    let taxable = 0;
    let gst = 0;
    let eligible = 0;
    let blocked = 0;
    let review = 0;

    selectedExpenses.forEach((exp) => {
      taxable += exp.taxableValue || 0;
      gst += exp.totalGst || 0;
      if (exp.itcDecision.status === 'Eligible') eligible += exp.totalGst || 0;
      else if (exp.itcDecision.status === 'Ineligible') blocked += exp.totalGst || 0;
      else review += exp.totalGst || 0;
    });

    return { taxable, gst, eligible, blocked, review };
  }, [selectedExpenses]);

  // Toggle all filtered rows
  const handleToggleAllFiltered = () => {
    const allFilteredSelected = filteredRows.every((_, idx) => {
      const originalIdx = importSummary?.rows.indexOf(_);
      return originalIdx !== undefined && selectedRowIndices.has(originalIdx);
    });

    const next = new Set(selectedRowIndices);
    filteredRows.forEach((r) => {
      const originalIdx = importSummary?.rows.indexOf(r);
      if (originalIdx !== undefined && r.validationStatus !== 'error') {
        if (allFilteredSelected) {
          next.delete(originalIdx);
        } else {
          next.add(originalIdx);
        }
      }
    });
    setSelectedRowIndices(next);
  };

  const handleCommitImport = () => {
    if (selectedExpenses.length === 0) return;
    onImportExpenses(selectedExpenses);
    onClose();
    handleReset();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-2xl shadow-xl w-full max-w-6xl max-h-[92vh] flex flex-col text-slate-700 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 border border-indigo-100 flex items-center justify-center font-bold">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-slate-900">
                  Bulk Upload & Batch Assess Invoices (CSV)
                </h2>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-700 border border-indigo-200">
                  Section 16 & 17 Compliant
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Import dozens of vendor invoices simultaneously with automated ITC classification and statutory audit
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Top Helper Banner & Template Download */}
          <div className="bg-gradient-to-r from-indigo-50/60 to-slate-50 border border-indigo-100 rounded-2xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-xs font-bold text-indigo-900">
                <Sparkles className="w-4 h-4 text-indigo-600" />
                <span>All "Add Expense" Input Attributes Supported</span>
              </div>
              <p className="text-xs text-slate-600 max-w-2xl leading-relaxed">
                Includes Invoice #, Date, Supplier GSTIN, Taxable Value, CGST/SGST/IGST breakdown, Payment status (180 days), GSTR-2B confirmation, and Section 17(5) special exception flags.
              </p>
            </div>

            <button
              type="button"
              onClick={downloadCsvTemplate}
              className="flex items-center gap-2 px-3.5 py-2 bg-white hover:bg-slate-50 text-indigo-700 border border-indigo-200 text-xs font-semibold rounded-xl shadow-xs transition-colors shrink-0"
            >
              <Download className="w-4 h-4 text-indigo-600" />
              <span>Download CSV Template (.csv)</span>
            </button>
          </div>

          {/* Upload / Input Tabs */}
          {!importSummary ? (
            <div className="space-y-4">
              <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
                <button
                  type="button"
                  onClick={() => setInputMode('upload')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
                    inputMode === 'upload'
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  <UploadCloud className="w-3.5 h-3.5" />
                  <span>Upload CSV File</span>
                </button>
                <button
                  type="button"
                  onClick={() => setInputMode('paste')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
                    inputMode === 'paste'
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Paste CSV / Excel Data</span>
                </button>
              </div>

              {inputMode === 'upload' ? (
                /* Drag & Drop File Zone */
                <div
                  onDragEnter={handleDrag}
                  onDragLeave={handleDrag}
                  onDragOver={handleDrag}
                  onDrop={handleDrop}
                  className={`border-2 border-dashed rounded-2xl p-8 text-center transition-all flex flex-col items-center justify-center gap-3 ${
                    dragActive
                      ? 'border-indigo-500 bg-indigo-50/50 scale-[0.99]'
                      : 'border-slate-300 bg-slate-50/50 hover:bg-slate-50 hover:border-slate-400'
                  }`}
                >
                  <input
                    ref={fileInputRef}
                    id={fileInputId}
                    type="file"
                    accept=".csv,text/csv,text/plain"
                    className="hidden"
                    onChange={(e) => {
                      if (e.target.files && e.target.files[0]) {
                        handleFileUpload(e.target.files[0]);
                      }
                    }}
                  />

                  <div className="w-14 h-14 rounded-2xl bg-indigo-100 text-indigo-600 flex items-center justify-center shadow-xs">
                    <UploadCloud className="w-7 h-7" />
                  </div>

                  <div className="space-y-1">
                    <p className="text-sm font-semibold text-slate-800">
                      Drag and drop your invoice CSV file here, or{' '}
                      <label
                        htmlFor={fileInputId}
                        className="text-indigo-600 hover:text-indigo-700 underline cursor-pointer font-bold"
                      >
                        browse computer
                      </label>
                    </p>
                    <p className="text-xs text-slate-500">
                      Supports .csv format exported from Tally, Zoho Books, SAP, Excel, or our statutory template
                    </p>
                  </div>
                </div>
              ) : (
                /* Paste CSV Textarea */
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-slate-700">
                      Paste CSV content (including header row):
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        // Quick demo load
                        downloadCsvTemplate();
                      }}
                      className="text-[11px] text-indigo-600 hover:underline"
                    >
                      Need sample data? Download template
                    </button>
                  </div>
                  <textarea
                    rows={8}
                    placeholder="Invoice Number,Invoice Date,Supplier Name,Supplier GSTIN,Category,Taxable Value,CGST,SGST,IGST,Payment Status&#10;INV-2026-01,2026-08-10,Amazon Web Services India,27AABCC1234F1Z5,Software and subscriptions,50000,4500,4500,0,Paid"
                    value={rawCsvText}
                    onChange={(e) => setRawCsvText(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-mono text-slate-800 placeholder-slate-400 focus:outline-hidden focus:bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                  />
                  <div className="flex justify-end">
                    <button
                      type="button"
                      disabled={!rawCsvText.trim()}
                      onClick={() => processCsv(rawCsvText, 'Pasted_Data.csv')}
                      className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors flex items-center gap-1.5"
                    >
                      <span>Parse & Run ITC Audit</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            /* Live Assessment Preview Dashboard & Table */
            <div className="space-y-5">
              {/* File Info Bar & Reset */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-3 bg-slate-100 rounded-xl border border-slate-200 text-xs">
                <div className="flex items-center gap-2">
                  <FileSpreadsheet className="w-4 h-4 text-indigo-600" />
                  <span className="font-semibold text-slate-900">{fileName || 'Uploaded CSV'}</span>
                  <span className="text-slate-500 font-mono">
                    ({importSummary.totalRows} invoices parsed)
                  </span>
                </div>
                <button
                  type="button"
                  onClick={handleReset}
                  className="text-slate-500 hover:text-rose-600 font-semibold flex items-center gap-1 self-start sm:self-auto transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Upload Different File</span>
                </button>
              </div>

              {/* Assessment Metrics Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-3">
                  <div className="text-[11px] text-slate-500 font-medium">Total Invoices</div>
                  <div className="text-lg font-bold text-slate-900 font-mono mt-0.5">
                    {importSummary.totalRows}
                  </div>
                  <div className="text-[10px] text-slate-500 font-mono">
                    Tax: {formatINR(importSummary.totalGstAmount)}
                  </div>
                </div>

                <div className="bg-emerald-50/70 border border-emerald-200 rounded-xl p-3">
                  <div className="text-[11px] text-emerald-800 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    <span>Eligible ITC</span>
                  </div>
                  <div className="text-lg font-bold text-emerald-700 font-mono mt-0.5">
                    {formatINR(importSummary.eligibleItcAmount)}
                  </div>
                  <div className="text-[10px] text-emerald-700 font-medium">
                    {importSummary.eligibleCount} bills eligible
                  </div>
                </div>

                <div className="bg-rose-50/70 border border-rose-200 rounded-xl p-3">
                  <div className="text-[11px] text-rose-800 font-semibold flex items-center gap-1">
                    <XCircle className="w-3 h-3 text-rose-600" />
                    <span>Ineligible / Blocked</span>
                  </div>
                  <div className="text-lg font-bold text-rose-700 font-mono mt-0.5">
                    {formatINR(importSummary.ineligibleItcAmount)}
                  </div>
                  <div className="text-[10px] text-rose-700 font-medium">
                    {importSummary.ineligibleCount} bills under Sec 17(5)
                  </div>
                </div>

                <div className="bg-amber-50/70 border border-amber-200 rounded-xl p-3">
                  <div className="text-[11px] text-amber-800 font-semibold flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3 text-amber-600" />
                    <span>CA Review Required</span>
                  </div>
                  <div className="text-lg font-bold text-amber-700 font-mono mt-0.5">
                    {formatINR(importSummary.reviewItcAmount)}
                  </div>
                  <div className="text-[10px] text-amber-700 font-medium">
                    {importSummary.reviewCount} bills with audit flags
                  </div>
                </div>
              </div>

              {/* Filter Tabs & Selection Row */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
                <div className="flex items-center gap-1.5 flex-wrap text-xs">
                  <button
                    type="button"
                    onClick={() => setPreviewFilter('All')}
                    className={`px-2.5 py-1 rounded-lg font-semibold transition-colors ${
                      previewFilter === 'All'
                        ? 'bg-indigo-600 text-white shadow-xs'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    All ({importSummary.totalRows})
                  </button>
                  <button
                    type="button"
                    onClick={() => setPreviewFilter('Eligible')}
                    className={`px-2.5 py-1 rounded-lg font-semibold transition-colors flex items-center gap-1 ${
                      previewFilter === 'Eligible'
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100'
                    }`}
                  >
                    <CheckCircle2 className="w-3 h-3" />
                    <span>Eligible ({importSummary.eligibleCount})</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPreviewFilter('Ineligible')}
                    className={`px-2.5 py-1 rounded-lg font-semibold transition-colors flex items-center gap-1 ${
                      previewFilter === 'Ineligible'
                        ? 'bg-rose-600 text-white shadow-xs'
                        : 'bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100'
                    }`}
                  >
                    <XCircle className="w-3 h-3" />
                    <span>Ineligible ({importSummary.ineligibleCount})</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPreviewFilter('CA Review Required')}
                    className={`px-2.5 py-1 rounded-lg font-semibold transition-colors flex items-center gap-1 ${
                      previewFilter === 'CA Review Required'
                        ? 'bg-amber-600 text-white shadow-xs'
                        : 'bg-amber-50 text-amber-700 border border-amber-200 hover:bg-amber-100'
                    }`}
                  >
                    <AlertTriangle className="w-3 h-3" />
                    <span>CA Review ({importSummary.reviewCount})</span>
                  </button>
                  {importSummary.errorCount > 0 && (
                    <button
                      type="button"
                      onClick={() => setPreviewFilter('Errors')}
                      className={`px-2.5 py-1 rounded-lg font-semibold transition-colors flex items-center gap-1 ${
                        previewFilter === 'Errors'
                          ? 'bg-rose-800 text-white shadow-xs'
                          : 'bg-rose-100 text-rose-900 border border-rose-300'
                      }`}
                    >
                      <AlertCircle className="w-3 h-3" />
                      <span>Errors ({importSummary.errorCount})</span>
                    </button>
                  )}
                </div>

                <div className="flex items-center gap-2 text-xs">
                  <button
                    type="button"
                    onClick={handleToggleAllFiltered}
                    className="text-indigo-600 hover:text-indigo-800 font-semibold"
                  >
                    Toggle Filtered Selection
                  </button>
                  <span className="text-slate-300">|</span>
                  <span className="text-slate-600">
                    <strong className="text-slate-900">{selectedExpenses.length}</strong> selected for import
                  </span>
                </div>
              </div>

              {/* Invoices Preview Table */}
              <div className="border border-slate-200 rounded-xl overflow-hidden shadow-xs">
                <div className="overflow-x-auto max-h-80">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase tracking-wider font-semibold text-[11px] sticky top-0 z-10">
                      <tr>
                        <th className="py-2.5 px-3 w-10 text-center">
                          <input
                            type="checkbox"
                            checked={
                              filteredRows.length > 0 &&
                              filteredRows.every((r) => {
                                const idx = importSummary.rows.indexOf(r);
                                return selectedRowIndices.has(idx);
                              })
                            }
                            onChange={handleToggleAllFiltered}
                            className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                          />
                        </th>
                        <th className="py-2.5 px-3">Row #</th>
                        <th className="py-2.5 px-3">Date</th>
                        <th className="py-2.5 px-3">Invoice #</th>
                        <th className="py-2.5 px-3">Supplier & GSTIN</th>
                        <th className="py-2.5 px-3">Category</th>
                        <th className="py-2.5 px-3 text-right">Taxable</th>
                        <th className="py-2.5 px-3 text-right">GST</th>
                        <th className="py-2.5 px-3">ITC Status</th>
                        <th className="py-2.5 px-3">Statutory Finding / Flags</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 bg-white">
                      {filteredRows.map((item) => {
                        const originalIndex = importSummary.rows.indexOf(item);
                        const isSelected = selectedRowIndices.has(originalIndex);
                        const exp = item.expense;

                        return (
                          <tr
                            key={originalIndex}
                            onClick={() => item.validationStatus !== 'error' && toggleRowSelection(originalIndex)}
                            className={`hover:bg-slate-50 transition-colors cursor-pointer ${
                              item.validationStatus === 'error' ? 'bg-rose-50/40 opacity-75' : ''
                            }`}
                          >
                            <td className="py-2 px-3 text-center" onClick={(e) => e.stopPropagation()}>
                              <input
                                type="checkbox"
                                disabled={item.validationStatus === 'error'}
                                checked={isSelected}
                                onChange={() => toggleRowSelection(originalIndex)}
                                className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                              />
                            </td>
                            <td className="py-2 px-3 font-mono text-slate-500">
                              #{item.rowNumber}
                            </td>
                            <td className="py-2 px-3 font-mono text-slate-700 whitespace-nowrap">
                              {formatDateDDMMYYYY(exp.invoiceDate)}
                            </td>
                            <td className="py-2 px-3 font-mono font-medium text-slate-900 whitespace-nowrap">
                              {exp.invoiceNumber}
                            </td>
                            <td className="py-2 px-3 max-w-[200px]">
                              <div className="font-semibold text-slate-900 truncate" title={exp.supplierName}>
                                {exp.supplierName}
                              </div>
                              <div className="text-[10px] font-mono text-slate-500">
                                {exp.supplierGstin || 'No GSTIN'}
                              </div>
                            </td>
                            <td className="py-2 px-3">
                              <span className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded text-[11px] font-medium truncate block max-w-[140px]" title={exp.category}>
                                {exp.category}
                              </span>
                            </td>
                            <td className="py-2 px-3 text-right font-mono text-slate-800 whitespace-nowrap">
                              {formatINR(exp.taxableValue)}
                            </td>
                            <td className="py-2 px-3 text-right font-mono font-bold text-indigo-600 whitespace-nowrap">
                              {formatINR(exp.totalGst)}
                            </td>
                            <td className="py-2 px-3 whitespace-nowrap">
                              {exp.itcDecision.status === 'Eligible' && (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                                  <CheckCircle2 className="w-3 h-3" />
                                  <span>Eligible</span>
                                </span>
                              )}
                              {exp.itcDecision.status === 'Ineligible' && (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-rose-50 text-rose-700 border border-rose-200">
                                  <XCircle className="w-3 h-3" />
                                  <span>Ineligible</span>
                                </span>
                              )}
                              {exp.itcDecision.status === 'CA Review Required' && (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-amber-50 text-amber-700 border border-amber-200">
                                  <AlertTriangle className="w-3 h-3" />
                                  <span>CA Review</span>
                                </span>
                              )}
                            </td>
                            <td className="py-2 px-3 max-w-xs">
                              <div className="truncate text-slate-700 text-[11px]" title={exp.itcDecision.primaryReason}>
                                {exp.itcDecision.primaryReason}
                              </div>
                              {item.validationWarnings.length > 0 && (
                                <div className="text-[10px] text-amber-700 font-medium truncate mt-0.5">
                                  {item.validationWarnings[0]}
                                </div>
                              )}
                              {item.validationErrors.length > 0 && (
                                <div className="text-[10px] text-rose-700 font-bold truncate mt-0.5">
                                  Error: {item.validationErrors[0]}
                                </div>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 border-t border-slate-200 bg-slate-50 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="text-xs text-slate-600">
            {importSummary && (
              <span className="flex items-center gap-2">
                <span>Selected: <strong className="text-slate-900 font-bold">{selectedExpenses.length}</strong> of {importSummary.totalRows}</span>
                <span className="text-slate-300">•</span>
                <span className="text-emerald-700 font-semibold">Eligible ITC: {formatINR(selectedMetrics.eligible)}</span>
                <span className="text-slate-300">•</span>
                <span className="text-rose-700 font-semibold">Blocked: {formatINR(selectedMetrics.blocked)}</span>
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 text-xs font-semibold rounded-xl shadow-xs transition-colors"
            >
              Cancel
            </button>
            {importSummary && (
              <button
                type="button"
                disabled={selectedExpenses.length === 0}
                onClick={handleCommitImport}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-semibold rounded-xl shadow-xs transition-all flex items-center gap-2 active:scale-95"
              >
                <Plus className="w-4 h-4" />
                <span>Import & Assess {selectedExpenses.length} Invoices</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

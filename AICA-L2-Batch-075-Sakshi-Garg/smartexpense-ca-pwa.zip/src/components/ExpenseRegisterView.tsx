/**
 * SmartExpense CA - Full Expense Register & Audit Ledger
 */

import {
  AlertTriangle,
  ArrowUpDown,
  Calendar,
  CheckCircle2,
  Download,
  Edit2,
  Eye,
  FileSpreadsheet,
  Filter,
  PlusCircle,
  Search,
  Trash2,
  UploadCloud,
  X,
  XCircle,
} from 'lucide-react';
import React, { useMemo } from 'react';
import { formatDateDDMMYYYY, formatINR } from '../lib/gstUtils';
import { Expense, ExpenseCategory, FilterState, ItcStatus, SupplierPaymentStatus } from '../types';

interface ExpenseRegisterViewProps {
  expenses: Expense[];
  onSelectExpense: (expense: Expense) => void;
  onEditExpense: (expense: Expense) => void;
  onDeleteExpense: (expenseId: string) => void;
  onOpenAddModal: () => void;
  onOpenImportModal: () => void;
  onExportCsv: () => void;
  filterState: FilterState;
  setFilterState: React.Dispatch<React.SetStateAction<FilterState>>;
}

export const ExpenseRegisterView: React.FC<ExpenseRegisterViewProps> = ({
  expenses,
  onSelectExpense,
  onEditExpense,
  onDeleteExpense,
  onOpenAddModal,
  onOpenImportModal,
  onExportCsv,
  filterState,
  setFilterState,
}) => {
  // Status filter quick pill counts
  const statusCounts = useMemo(() => {
    let eligible = 0;
    let ineligible = 0;
    let review = 0;

    for (const exp of expenses) {
      if (exp.itcDecision.status === 'Eligible') eligible++;
      else if (exp.itcDecision.status === 'Ineligible') ineligible++;
      else review++;
    }

    return {
      all: expenses.length,
      eligible,
      ineligible,
      review,
    };
  }, [expenses]);

  // Filtered and Sorted Expenses
  const filteredAndSortedExpenses = useMemo(() => {
    let result = expenses.filter((exp) => {
      // Status Filter
      if (filterState.statusFilter !== 'All' && exp.itcDecision.status !== filterState.statusFilter) {
        return false;
      }
      // Category Filter
      if (filterState.categoryFilter !== 'All' && exp.category !== filterState.categoryFilter) {
        return false;
      }
      // Payment Filter
      if (filterState.paymentFilter !== 'All' && exp.supplierPaymentStatus !== filterState.paymentFilter) {
        return false;
      }
      // Search Filter
      if (filterState.searchQuery.trim() !== '') {
        const q = filterState.searchQuery.toLowerCase();
        const match =
          exp.invoiceNumber.toLowerCase().includes(q) ||
          exp.supplierName.toLowerCase().includes(q) ||
          exp.description.toLowerCase().includes(q) ||
          (exp.supplierGstin && exp.supplierGstin.toLowerCase().includes(q)) ||
          exp.category.toLowerCase().includes(q);
        if (!match) return false;
      }
      return true;
    });

    // Sorting
    result = [...result].sort((a, b) => {
      let comparison = 0;
      if (filterState.sortBy === 'date') {
        comparison = new Date(b.invoiceDate).getTime() - new Date(a.invoiceDate).getTime();
      } else if (filterState.sortBy === 'amount') {
        comparison = b.totalAmount - a.totalAmount;
      } else if (filterState.sortBy === 'gst') {
        comparison = b.totalGst - a.totalGst;
      } else if (filterState.sortBy === 'supplier') {
        comparison = a.supplierName.localeCompare(b.supplierName);
      } else if (filterState.sortBy === 'status') {
        comparison = a.itcDecision.status.localeCompare(b.itcDecision.status);
      }

      return filterState.sortOrder === 'asc' ? -comparison : comparison;
    });

    return result;
  }, [expenses, filterState]);

  const handleSort = (field: FilterState['sortBy']) => {
    if (filterState.sortBy === field) {
      setFilterState((prev) => ({
        ...prev,
        sortOrder: prev.sortOrder === 'asc' ? 'desc' : 'asc',
      }));
    } else {
      setFilterState((prev) => ({
        ...prev,
        sortBy: field,
        sortOrder: 'desc',
      }));
    }
  };

  const getStatusBadge = (status: ItcStatus) => {
    if (status === 'Eligible') {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 whitespace-nowrap">
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span>Eligible</span>
        </span>
      );
    }
    if (status === 'Ineligible') {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200 whitespace-nowrap">
          <XCircle className="w-3.5 h-3.5" />
          <span>Ineligible</span>
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200 whitespace-nowrap">
        <AlertTriangle className="w-3.5 h-3.5" />
        <span>CA Review</span>
      </span>
    );
  };

  return (
    <div className="space-y-5 pb-12">
      {/* Top Header Controls */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              <span>B2B Purchase & Expense Register</span>
            </h2>
            <p className="text-xs text-slate-500">
              Search, filter, and audit tax invoices against CGST Section 16 & Section 17 rules
            </p>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <button
              type="button"
              onClick={onOpenImportModal}
              className="flex items-center gap-1.5 px-3 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 text-xs font-semibold rounded-xl shadow-xs transition-all active:scale-95"
            >
              <UploadCloud className="w-3.5 h-3.5 text-indigo-600" />
              <span>Import CSV</span>
            </button>
            <button
              type="button"
              onClick={onExportCsv}
              className="flex items-center gap-1.5 px-3 py-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 text-xs font-semibold rounded-xl shadow-xs transition-colors"
            >
              <Download className="w-3.5 h-3.5 text-indigo-600" />
              <span>Export CSV</span>
            </button>
            <button
              type="button"
              onClick={onOpenAddModal}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Add Expense</span>
            </button>
          </div>
        </div>

        {/* Status Quick Filter Chips */}
        <div className="flex items-center gap-2 flex-wrap text-xs pt-1">
          <button
            type="button"
            onClick={() => setFilterState((prev) => ({ ...prev, statusFilter: 'All' }))}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-all ${
              filterState.statusFilter === 'All'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-slate-50 text-slate-600 border border-slate-200 hover:bg-slate-100'
            }`}
          >
            All Invoices ({statusCounts.all})
          </button>
          <button
            type="button"
            onClick={() => setFilterState((prev) => ({ ...prev, statusFilter: 'Eligible' }))}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-all flex items-center gap-1.5 ${
              filterState.statusFilter === 'Eligible'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-emerald-50/70 text-emerald-700 border border-emerald-200 hover:bg-emerald-100/70'
            }`}
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Eligible ({statusCounts.eligible})</span>
          </button>
          <button
            type="button"
            onClick={() => setFilterState((prev) => ({ ...prev, statusFilter: 'Ineligible' }))}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-all flex items-center gap-1.5 ${
              filterState.statusFilter === 'Ineligible'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'bg-rose-50/70 text-rose-700 border border-rose-200 hover:bg-rose-100/70'
            }`}
          >
            <XCircle className="w-3.5 h-3.5" />
            <span>Ineligible ({statusCounts.ineligible})</span>
          </button>
          <button
            type="button"
            onClick={() => setFilterState((prev) => ({ ...prev, statusFilter: 'CA Review Required' }))}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-all flex items-center gap-1.5 ${
              filterState.statusFilter === 'CA Review Required'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-amber-50/70 text-amber-700 border border-amber-200 hover:bg-amber-100/70'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>CA Review Required ({statusCounts.review})</span>
          </button>
        </div>

        {/* Detailed Search & Dropdown Filters */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3 border-t border-slate-100 text-xs">
          {/* Search Box */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              placeholder="Search by supplier, invoice #, description, GSTIN..."
              value={filterState.searchQuery}
              onChange={(e) => setFilterState((prev) => ({ ...prev, searchQuery: e.target.value }))}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-slate-800 placeholder-slate-400 focus:outline-hidden focus:bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 text-xs"
            />
            {filterState.searchQuery && (
              <button
                type="button"
                onClick={() => setFilterState((prev) => ({ ...prev, searchQuery: '' }))}
                className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-700"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Category Dropdown */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 flex items-center gap-2">
            <span className="text-slate-500 shrink-0">Category:</span>
            <select
              value={filterState.categoryFilter}
              onChange={(e) => setFilterState((prev) => ({ ...prev, categoryFilter: e.target.value as ExpenseCategory | 'All' }))}
              className="w-full bg-transparent text-slate-800 focus:outline-hidden truncate text-xs"
            >
              <option value="All" className="bg-white text-slate-900">All Categories</option>
              <option value="Software and subscriptions" className="bg-white text-slate-900">Software & Subscriptions</option>
              <option value="Professional fees" className="bg-white text-slate-900">Professional Fees</option>
              <option value="Food and beverages" className="bg-white text-slate-900">Food & Beverages</option>
              <option value="Employee welfare" className="bg-white text-slate-900">Employee Welfare</option>
              <option value="Motor vehicle / car expenses" className="bg-white text-slate-900">Motor Vehicle Expenses</option>
              <option value="Capital goods" className="bg-white text-slate-900">Capital Goods</option>
              <option value="Office supplies" className="bg-white text-slate-900">Office Supplies</option>
              <option value="Rent" className="bg-white text-slate-900">Rent</option>
              <option value="Telephone and internet" className="bg-white text-slate-900">Telephone & Internet</option>
              <option value="Advertising and marketing" className="bg-white text-slate-900">Advertising & Marketing</option>
              <option value="Insurance" className="bg-white text-slate-900">Insurance</option>
              <option value="Club / fitness membership" className="bg-white text-slate-900">Club & Fitness</option>
              <option value="Construction / civil works" className="bg-white text-slate-900">Construction / Civil Works</option>
              <option value="Personal expense" className="bg-white text-slate-900">Personal Expense</option>
              <option value="Other" className="bg-white text-slate-900">Other</option>
            </select>
          </div>

          {/* Payment Status Dropdown */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 flex items-center gap-2">
            <span className="text-slate-500 shrink-0">Payment:</span>
            <select
              value={filterState.paymentFilter}
              onChange={(e) => setFilterState((prev) => ({ ...prev, paymentFilter: e.target.value as SupplierPaymentStatus | 'All' }))}
              className="w-full bg-transparent text-slate-800 focus:outline-hidden text-xs"
            >
              <option value="All" className="bg-white text-slate-900">All Payments</option>
              <option value="Paid" className="bg-white text-emerald-700">Paid Only</option>
              <option value="Unpaid" className="bg-white text-rose-700">Unpaid Only</option>
              <option value="Partially paid" className="bg-white text-amber-700">Partially Paid</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Expense Table */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600">
            <thead className="bg-slate-50/80 border-b border-slate-200 text-slate-500 uppercase tracking-wider font-semibold text-[11px]">
              <tr>
                <th
                  onClick={() => handleSort('date')}
                  className="py-3 px-4 cursor-pointer hover:text-slate-900 transition-colors"
                >
                  <div className="flex items-center gap-1">
                    <span>Date</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('supplier')}
                  className="py-3 px-4 cursor-pointer hover:text-slate-900 transition-colors"
                >
                  <div className="flex items-center gap-1">
                    <span>Supplier & GSTIN</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th className="py-3 px-4">Invoice #</th>
                <th className="py-3 px-4">Category</th>
                <th
                  onClick={() => handleSort('amount')}
                  className="py-3 px-4 text-right cursor-pointer hover:text-slate-900 transition-colors"
                >
                  <div className="flex items-center justify-end gap-1">
                    <span>Total Amount</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('gst')}
                  className="py-3 px-4 text-right cursor-pointer hover:text-slate-900 transition-colors"
                >
                  <div className="flex items-center justify-end gap-1">
                    <span>Total GST</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('status')}
                  className="py-3 px-4 cursor-pointer hover:text-slate-900 transition-colors"
                >
                  <div className="flex items-center gap-1">
                    <span>ITC Status</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th className="py-3 px-4">Statutory Finding / Reason</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredAndSortedExpenses.length > 0 ? (
                filteredAndSortedExpenses.map((exp) => (
                  <tr
                    key={exp.id}
                    className="hover:bg-slate-50 transition-colors group cursor-pointer"
                    onClick={() => onSelectExpense(exp)}
                  >
                    {/* Invoice Date */}
                    <td className="py-3.5 px-4 font-mono text-slate-700 whitespace-nowrap">
                      {formatDateDDMMYYYY(exp.invoiceDate)}
                    </td>

                    {/* Supplier & GSTIN */}
                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-slate-900 group-hover:text-indigo-600 transition-colors">
                        {exp.supplierName}
                      </div>
                      <div className="text-[10px] font-mono text-slate-500 mt-0.5">
                        {exp.supplierGstin || 'No GSTIN'}
                      </div>
                    </td>

                    {/* Invoice # */}
                    <td className="py-3.5 px-4 font-mono text-slate-600 whitespace-nowrap">
                      {exp.invoiceNumber}
                    </td>

                    {/* Category */}
                    <td className="py-3.5 px-4">
                      <span className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded text-[11px] font-medium">
                        {exp.category}
                      </span>
                    </td>

                    {/* Total Amount */}
                    <td className="py-3.5 px-4 text-right font-mono font-semibold text-slate-900 whitespace-nowrap">
                      {formatINR(exp.totalAmount)}
                    </td>

                    {/* Total GST */}
                    <td className="py-3.5 px-4 text-right font-mono font-bold text-indigo-600 whitespace-nowrap">
                      {formatINR(exp.totalGst)}
                    </td>

                    {/* ITC Status Badge */}
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      {getStatusBadge(exp.itcDecision.status)}
                    </td>

                    {/* Key Reason */}
                    <td className="py-3.5 px-4 max-w-xs">
                      <div className="truncate text-slate-700" title={exp.itcDecision.primaryReason}>
                        {exp.itcDecision.primaryReason}
                      </div>
                      {exp.itcDecision.flags.length > 0 && (
                        <div className="text-[10px] text-amber-700 font-medium truncate mt-0.5">
                          {exp.itcDecision.flags[0]}
                        </div>
                      )}
                    </td>

                    {/* Actions */}
                    <td
                      className="py-3.5 px-4 text-right whitespace-nowrap"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          type="button"
                          onClick={() => onSelectExpense(exp)}
                          title="View Full Compliance Trail"
                          className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-slate-100 rounded-lg transition-colors"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onEditExpense(exp)}
                          title="Edit Invoice"
                          className="p-1.5 text-slate-400 hover:text-amber-600 hover:bg-slate-100 rounded-lg transition-colors"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            if (window.confirm(`Delete invoice ${exp.invoiceNumber} from ${exp.supplierName}?`)) {
                              onDeleteExpense(exp.id);
                            }
                          }}
                          title="Delete Invoice"
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-slate-100 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-400">
                    <div className="max-w-sm mx-auto space-y-2">
                      <Search className="w-8 h-8 text-slate-300 mx-auto" />
                      <p className="text-sm font-semibold text-slate-800">No Invoices Found</p>
                      <p className="text-xs text-slate-500">
                        No purchase records match the current filter or search criteria.
                      </p>
                      <button
                        type="button"
                        onClick={() =>
                          setFilterState({
                            searchQuery: '',
                            statusFilter: 'All',
                            categoryFilter: 'All',
                            paymentFilter: 'All',
                            monthFilter: 'All',
                            sortBy: 'date',
                            sortOrder: 'desc',
                          })
                        }
                        className="mt-2 text-xs font-semibold text-indigo-600 hover:underline"
                      >
                        Reset All Filters
                      </button>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Footer Summary */}
        <div className="bg-slate-50 px-5 py-3 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <span>
            Showing <strong className="text-slate-800">{filteredAndSortedExpenses.length}</strong> of{' '}
            <strong className="text-slate-800">{expenses.length}</strong> recorded invoices
          </span>
          <span className="text-[11px] text-slate-400">
            Click on any row to open the complete rule-by-rule decision trail
          </span>
        </div>
      </div>
    </div>
  );
};

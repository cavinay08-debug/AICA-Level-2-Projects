/**
 * SmartExpense CA - Legal Sources & Statutory Framework Viewer Modal
 */

import { AlertTriangle, BookOpen, CheckCircle2, ExternalLink, HelpCircle, Scale, ShieldAlert, X } from 'lucide-react';
import React, { useState } from 'react';

interface LegalSourcesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LegalSourcesModal: React.FC<LegalSourcesModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'matrix' | 'disclaimer' | 'maintenance'>('matrix');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-2xl shadow-xl w-full max-w-4xl max-h-[90vh] flex flex-col text-slate-700 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/80">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 border border-amber-200 flex items-center justify-center">
              <Scale className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <span>GST Legal Sources & Statutory Rules Reference</span>
              </h2>
              <p className="text-xs text-emerald-700 font-semibold">
                Law verified as of: 17 August 2026 • Primary CBIC Sources
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Navigation */}
        <div className="flex border-b border-slate-200 bg-slate-50/50 px-6 gap-6 text-sm font-semibold">
          <button
            type="button"
            onClick={() => setActiveTab('matrix')}
            className={`py-3 border-b-2 transition-colors flex items-center gap-2 ${
              activeTab === 'matrix'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Statutory Provisions Matrix</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('disclaimer')}
            className={`py-3 border-b-2 transition-colors flex items-center gap-2 ${
              activeTab === 'disclaimer'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <ShieldAlert className="w-4 h-4" />
            <span>Legal Disclaimer & Scope</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('maintenance')}
            className={`py-3 border-b-2 transition-colors flex items-center gap-2 ${
              activeTab === 'maintenance'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Scale className="w-4 h-4" />
            <span>CA Rule Maintenance</span>
          </button>
        </div>

        {/* Modal Content Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-sm">
          {activeTab === 'matrix' && (
            <>
              {/* Primary Official Links Banner */}
              <div className="bg-slate-50 rounded-xl p-4 border border-slate-200">
                <h3 className="text-xs uppercase tracking-wider text-slate-500 font-semibold mb-2">
                  Official Primary Government Portals
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <a
                    href="https://cbic-gst.gov.in/"
                    target="_blank"
                    rel="noreferrer"
                    className="p-3 bg-white rounded-xl border border-slate-200 hover:border-indigo-500 flex items-center justify-between text-xs text-indigo-600 transition-colors group shadow-xs"
                  >
                    <div>
                      <span className="font-semibold text-slate-900 block">CBIC GST Portal</span>
                      <span className="text-[11px] text-slate-500">Acts, Rules, Circulars</span>
                    </div>
                    <ExternalLink className="w-4 h-4 text-slate-400 group-hover:text-indigo-600" />
                  </a>
                  <a
                    href="https://www.gst.gov.in/"
                    target="_blank"
                    rel="noreferrer"
                    className="p-3 bg-white rounded-xl border border-slate-200 hover:border-indigo-500 flex items-center justify-between text-xs text-indigo-600 transition-colors group shadow-xs"
                  >
                    <div>
                      <span className="font-semibold text-slate-900 block">GST Common Portal</span>
                      <span className="text-[11px] text-slate-500">GSTR-2B & Returns</span>
                    </div>
                    <ExternalLink className="w-4 h-4 text-slate-400 group-hover:text-indigo-600" />
                  </a>
                  <a
                    href="https://egazette.gov.in/"
                    target="_blank"
                    rel="noreferrer"
                    className="p-3 bg-white rounded-xl border border-slate-200 hover:border-indigo-500 flex items-center justify-between text-xs text-indigo-600 transition-colors group shadow-xs"
                  >
                    <div>
                      <span className="font-semibold text-slate-900 block">Official Gazette</span>
                      <span className="text-[11px] text-slate-500">Finance Act Notifications</span>
                    </div>
                    <ExternalLink className="w-4 h-4 text-slate-400 group-hover:text-indigo-600" />
                  </a>
                </div>
              </div>

              {/* Statutory Rules Accordion List */}
              <div className="space-y-4">
                {/* Section 16 */}
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="text-xs font-semibold px-2 py-0.5 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200">
                        Section 16(1) & 16(2)
                      </span>
                      <h4 className="font-semibold text-slate-900 mt-1">General Business ITC & Mandatory Conditions</h4>
                    </div>
                    <a
                      href="https://cbic-gst.gov.in/cbec-portal-ui/openUrl?path=/pdf/cgst-act.pdf"
                      target="_blank"
                      rel="noreferrer"
                      className="text-xs text-indigo-600 hover:underline flex items-center gap-1 shrink-0 font-semibold"
                    >
                      <span>Read Section 16</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                  <p className="text-slate-600 text-xs leading-relaxed">
                    ITC is entitled on goods/services used in the course or furtherance of business. To claim credit, all five conditions must be met: (1) Possession of valid Tax Invoice / Debit note under Section 31, (2) Invoice reflected in auto-generated GSTR-2B, (3) Actual receipt of goods/services, (4) Tax payment to Govt by supplier, and (5) Filing of GSTR-3B return.
                  </p>
                </div>

                {/* 180-Day Rule */}
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="text-xs font-semibold px-2 py-0.5 rounded-lg bg-amber-50 text-amber-800 border border-amber-200">
                        Section 16(2) 2nd Proviso & Rule 37
                      </span>
                      <h4 className="font-semibold text-slate-900 mt-1">180-Day Supplier Payment Condition</h4>
                    </div>
                  </div>
                  <p className="text-slate-600 text-xs leading-relaxed">
                    Where the recipient fails to pay the supplier the value of supply plus tax within <strong>180 days</strong> from the invoice date, an amount equal to the ITC availed must be reversed in GSTR-3B with applicable interest under Section 50. The credit can be reclaimed upon actual payment.
                  </p>
                </div>

                {/* Section 16(4) */}
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="text-xs font-semibold px-2 py-0.5 rounded-lg bg-sky-50 text-sky-800 border border-sky-200">
                        Section 16(4)
                      </span>
                      <h4 className="font-semibold text-slate-900 mt-1">Statutory Time Limit for Claiming ITC</h4>
                    </div>
                  </div>
                  <p className="text-slate-600 text-xs leading-relaxed">
                    No ITC can be claimed in respect of any invoice or debit note after <strong>30th November</strong> following the end of financial year to which the invoice pertains, or filing of the relevant Annual Return (GSTR-9), whichever is earlier (amended via Finance Act 2022).
                  </p>
                </div>

                {/* Section 17(1), 17(2) & Rules 42/43 */}
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="text-xs font-semibold px-2 py-0.5 rounded-lg bg-purple-50 text-purple-800 border border-purple-200">
                        Section 17(1), 17(2) & Rules 42 / 43
                      </span>
                      <h4 className="font-semibold text-slate-900 mt-1">Apportionment for Mixed & Exempt Supplies</h4>
                    </div>
                  </div>
                  <p className="text-slate-600 text-xs leading-relaxed">
                    Where goods/services are used partly for business and partly for other purposes (personal), only the business portion is allowed (Sec 17(1)). Where used partly for taxable and partly for exempt supplies, credit must be apportioned monthly based on exempt turnover ratio under Rule 42 (Inputs/Services) and Rule 43 (Capital Goods).
                  </p>
                </div>

                {/* Section 17(5) Blocked Credits */}
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="text-xs font-semibold px-2 py-0.5 rounded-lg bg-rose-50 text-rose-800 border border-rose-200">
                        Section 17(5)
                      </span>
                      <h4 className="font-semibold text-slate-900 mt-1">Specific Blocked Credits ("Negative List")</h4>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-600">
                    <div className="p-2.5 bg-white rounded-xl border border-slate-200 shadow-xs">
                      <strong className="text-rose-700 block mb-1">17(5)(a) Motor Vehicles (≤13 seats):</strong>
                      Blocked unless used for further supply of vehicles, passenger transport, or driving training.
                    </div>
                    <div className="p-2.5 bg-white rounded-xl border border-slate-200 shadow-xs">
                      <strong className="text-rose-700 block mb-1">17(5)(b)(i) Food, Beverage & Catering:</strong>
                      Blocked unless inward supply is used for outward taxable supply of the same category.
                    </div>
                    <div className="p-2.5 bg-white rounded-xl border border-slate-200 shadow-xs">
                      <strong className="text-rose-700 block mb-1">17(5)(b)(ii) Club & Gym Memberships:</strong>
                      Strictly blocked across all commercial operations.
                    </div>
                    <div className="p-2.5 bg-white rounded-xl border border-slate-200 shadow-xs">
                      <strong className="text-rose-700 block mb-1">17(5)(b)(iii) Life/Health Insurance & Cabs:</strong>
                      Blocked unless statutory employer obligation under law (e.g. Factories Act).
                    </div>
                    <div className="p-2.5 bg-white rounded-xl border border-slate-200 shadow-xs">
                      <strong className="text-rose-700 block mb-1">17(5)(c) & (d) Works Contract / Construction:</strong>
                      Blocked on immovable property to the extent capitalized in accounts (excluding plant & machinery).
                    </div>
                    <div className="p-2.5 bg-white rounded-xl border border-slate-200 shadow-xs">
                      <strong className="text-rose-700 block mb-1">17(5)(g) & (h) Personal / Lost / Free Gifts:</strong>
                      Blocked on personal consumption, lost, stolen, destroyed goods, or promotional free gifts.
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}

          {activeTab === 'disclaimer' && (
            <div className="space-y-4">
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 space-y-2">
                <div className="flex items-center gap-2 font-bold text-amber-800">
                  <AlertTriangle className="w-5 h-5 shrink-0 text-amber-600" />
                  <span>Educational & Professional Assistance Project</span>
                </div>
                <p className="text-xs leading-relaxed text-amber-800">
                  SmartExpense CA is built strictly as a decision-support, educational, and preliminary analytical tool for Indian Chartered Accountants, tax consultants, and finance teams.
                </p>
              </div>

              <div className="space-y-3 text-xs text-slate-600 leading-relaxed">
                <h4 className="font-semibold text-slate-900 text-sm">Key Regulatory Limitations:</h4>
                <ul className="list-disc pl-5 space-y-2">
                  <li>
                    <strong>No Legal Finality:</strong> The status results (Eligible / Ineligible / CA Review Required) are preliminary indicators computed from user-entered facts. They do not constitute formal tax advice or legal certification.
                  </li>
                  <li>
                    <strong>GSTIN Format Validation:</strong> The syntactic GSTIN format validation confirms pattern conformance (State Code + PAN + Entity + Z + Checksum) only. It does <em>not</em> verify whether the GSTIN is active, cancelled, or suspended on the live GST portal.
                  </li>
                  <li>
                    <strong>GSTR-2B Reconciliation:</strong> The tool notes GSTR-2B reflection as a checklist indicator; it does not connect to the live GST Portal API or auto-download JSON statements.
                  </li>
                  <li>
                    <strong>Fact-Specific Caveats:</strong> When factual ambiguity exists (such as capitalized vs revenue civil repairs, or composite supply catering contracts), the engine conservatively returns <em>CA Review Required</em> to ensure professional human judgement is applied.
                  </li>
                </ul>
              </div>
            </div>
          )}

          {activeTab === 'maintenance' && (
            <div className="space-y-4 text-xs text-slate-600 leading-relaxed">
              <div className="p-4 bg-indigo-50 border border-indigo-200 rounded-xl">
                <h4 className="font-semibold text-indigo-950 text-sm mb-1">
                  How Chartered Accountants Can Update Rules in the Future
                </h4>
                <p className="text-slate-700">
                  The business logic in this application is strictly isolated within a clean, deterministic TypeScript module located at <code className="px-1.5 py-0.5 bg-white border border-indigo-200 text-indigo-700 rounded font-mono text-[11px]">src/lib/itcRules.ts</code>.
                </p>
              </div>

              <div className="space-y-2">
                <h5 className="font-semibold text-slate-900">Updating Process:</h5>
                <ol className="list-decimal pl-5 space-y-2">
                  <li>
                    <strong>Check Official Gazette:</strong> When a new GST Notification or Circular is issued by CBIC (e.g. extending Section 16(4) time-limits or amending Section 17(5) exceptions), record the notification in <code className="px-1.5 py-0.5 bg-slate-100 text-slate-800 rounded font-mono text-[11px]">LEGAL_SOURCES.md</code>.
                  </li>
                  <li>
                    <strong>Update Rules Logic:</strong> Adjust the corresponding conditional check inside <code className="px-1.5 py-0.5 bg-slate-100 text-slate-800 rounded font-mono text-[11px]">evaluateItcEligibility()</code> in <code className="px-1.5 py-0.5 bg-slate-100 text-slate-800 rounded font-mono text-[11px]">src/lib/itcRules.ts</code>.
                  </li>
                  <li>
                    <strong>Run Automated Test Suite:</strong> Execute <code className="px-1.5 py-0.5 bg-slate-100 text-slate-800 rounded font-mono text-[11px]">npm test</code> to ensure all regression boundary test cases continue to pass without syntax errors.
                  </li>
                </ol>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-slate-200 bg-slate-50/80 flex items-center justify-between text-xs text-slate-500">
          <span>SmartExpense CA • Section 16 & 17 Compliance Guide</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-xl transition-colors shadow-xs cursor-pointer"
          >
            Close Guide
          </button>
        </div>
      </div>
    </div>
  );
};

/**
 * SmartExpense CA - PWA Install & Offline Guide Modal
 */

import {
  Apple,
  CheckCircle2,
  Compass,
  Download,
  HardDrive,
  Laptop,
  Layers,
  Monitor,
  Share2,
  ShieldCheck,
  Smartphone,
  Sparkles,
  WifiOff,
  X,
} from 'lucide-react';
import React, { useState } from 'react';

interface PwaInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  isInstallable: boolean;
  onInstall: () => Promise<boolean>;
}

export const PwaInstallModal: React.FC<PwaInstallModalProps> = ({
  isOpen,
  onClose,
  isInstallable,
  onInstall,
}) => {
  const [platformTab, setPlatformTab] = useState<'desktop' | 'ios' | 'android'>('desktop');
  const [installing, setInstalling] = useState(false);

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    setInstalling(true);
    try {
      const outcome = await onInstall();
      if (outcome) {
        onClose();
      }
    } finally {
      setInstalling(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-2xl shadow-xl w-full max-w-xl flex flex-col text-slate-700 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold shadow-xs">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-slate-900">
                  Install SmartExpense CA
                </h2>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                  PWA Ready
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Install as a native desktop or mobile application with offline GST audit capabilities
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* PWA Key Benefits */}
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-center space-y-1">
              <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto">
                <WifiOff className="w-4 h-4" />
              </div>
              <div className="text-xs font-bold text-slate-900">100% Offline</div>
              <div className="text-[10px] text-slate-500">Audit ITC & tax rules without internet</div>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-center space-y-1">
              <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
                <HardDrive className="w-4 h-4" />
              </div>
              <div className="text-xs font-bold text-slate-900">Zero Latency</div>
              <div className="text-[10px] text-slate-500">Instant app launch from dock or desktop</div>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-center space-y-1">
              <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center mx-auto">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <div className="text-xs font-bold text-slate-900">Secure Storage</div>
              <div className="text-[10px] text-slate-500">Local browser persistence and CSV export</div>
            </div>
          </div>

          {/* Quick Install Prompt Action if browser triggered event */}
          {isInstallable ? (
            <div className="bg-indigo-50 border border-indigo-200 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="space-y-0.5 text-center sm:text-left">
                <div className="text-xs font-bold text-indigo-950 flex items-center justify-center sm:justify-start gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Direct Browser Installation Available</span>
                </div>
                <div className="text-[11px] text-indigo-800">
                  Click the button to install SmartExpense CA to your operating system.
                </div>
              </div>
              <button
                type="button"
                disabled={installing}
                onClick={handleInstallClick}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl shadow-xs transition-all flex items-center gap-1.5 shrink-0 active:scale-95"
              >
                <Download className="w-4 h-4" />
                <span>{installing ? 'Installing...' : 'Install App Now'}</span>
              </button>
            </div>
          ) : null}

          {/* Platform Step-by-Step Instructions */}
          <div className="space-y-3">
            <div className="text-xs font-bold text-slate-900 flex items-center justify-between">
              <span>Installation Steps by Device</span>
              <div className="flex items-center gap-1 bg-slate-100 p-0.5 rounded-lg">
                <button
                  type="button"
                  onClick={() => setPlatformTab('desktop')}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors flex items-center gap-1 ${
                    platformTab === 'desktop'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <Laptop className="w-3 h-3" />
                  <span>Desktop</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPlatformTab('ios')}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors flex items-center gap-1 ${
                    platformTab === 'ios'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <Apple className="w-3 h-3" />
                  <span>iOS (Safari)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPlatformTab('android')}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors flex items-center gap-1 ${
                    platformTab === 'android'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <Smartphone className="w-3 h-3" />
                  <span>Android</span>
                </button>
              </div>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-xs space-y-3">
              {platformTab === 'desktop' && (
                <ol className="space-y-2 text-slate-600 list-decimal list-inside">
                  <li>
                    In <strong className="text-slate-800">Google Chrome</strong> or <strong className="text-slate-800">Microsoft Edge</strong>, look for the <strong className="text-indigo-600">Install icon (⊞ or ⬇)</strong> in the right corner of your address bar.
                  </li>
                  <li>
                    Click <strong>Install SmartExpense CA</strong>.
                  </li>
                  <li>
                    The application will open in its own dedicated, distraction-free desktop window with taskbar/dock integration.
                  </li>
                </ol>
              )}

              {platformTab === 'ios' && (
                <ol className="space-y-2 text-slate-600 list-decimal list-inside">
                  <li>
                    Open this app in <strong className="text-slate-800">Safari</strong> on your iPhone or iPad.
                  </li>
                  <li>
                    Tap the <strong className="text-indigo-600 flex-inline items-center gap-1"><Share2 className="w-3.5 h-3.5 inline text-indigo-600" /> Share button</strong> in the toolbar.
                  </li>
                  <li>
                    Scroll down and select <strong className="text-slate-800">"Add to Home Screen"</strong>.
                  </li>
                  <li>
                    Tap <strong className="text-indigo-600">Add</strong> in the top right corner. The icon will appear on your home screen.
                  </li>
                </ol>
              )}

              {platformTab === 'android' && (
                <ol className="space-y-2 text-slate-600 list-decimal list-inside">
                  <li>
                    Open this app in <strong className="text-slate-800">Chrome</strong> on your Android phone.
                  </li>
                  <li>
                    Tap the <strong>three vertical dots (⋮)</strong> menu in the top right.
                  </li>
                  <li>
                    Select <strong className="text-indigo-600">"Install app"</strong> or <strong className="text-slate-800">"Add to Home screen"</strong>.
                  </li>
                  <li>
                    Confirm to add SmartExpense CA to your App Drawer and Home screen.
                  </li>
                </ol>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="text-[11px] text-slate-500">
            Powered by Service Workers & Cache Storage
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-semibold rounded-xl transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

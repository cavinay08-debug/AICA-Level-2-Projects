/**
 * SmartExpense CA - Header Component
 */

import {
  BookOpen,
  CheckCircle2,
  Download,
  FileSpreadsheet,
  HardDrive,
  Laptop,
  PlusCircle,
  RefreshCw,
  RotateCw,
  ShieldAlert,
  Smartphone,
  Trash2,
  UploadCloud,
  Wifi,
  WifiOff,
} from 'lucide-react';
import React, { useState } from 'react';

interface HeaderProps {
  activeTab: 'dashboard' | 'register';
  setActiveTab: (tab: 'dashboard' | 'register') => void;
  onOpenAddModal: () => void;
  onOpenImportModal: () => void;
  onOpenLegalModal: () => void;
  onOpenInstallModal: () => void;
  isInstallable: boolean;
  isOnline: boolean;
  hasUpdate: boolean;
  onReloadUpdate: () => void;
  onResetDemoData: () => void;
  onClearAllData: () => void;
  onExportRegisterCsv: () => void;
  onExportSummaryCsv: () => void;
  totalExpensesCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onOpenAddModal,
  onOpenImportModal,
  onOpenLegalModal,
  onOpenInstallModal,
  isInstallable,
  isOnline,
  hasUpdate,
  onReloadUpdate,
  onResetDemoData,
  onClearAllData,
  onExportRegisterCsv,
  onExportSummaryCsv,
  totalExpensesCount,
}) => {
  const [showExportMenu, setShowExportMenu] = useState(false);
  const [showDataMenu, setShowDataMenu] = useState(false);

  return (
    <header className="bg-white text-slate-900 border-b border-slate-200 sticky top-0 z-30 shadow-xs">
      {/* Offline Alert Strip if offline */}
      {!isOnline && (
        <div className="bg-amber-500 text-white px-4 py-1.5 text-xs font-semibold flex items-center justify-between shadow-xs">
          <div className="max-w-7xl mx-auto w-full flex items-center justify-between">
            <div className="flex items-center gap-2">
              <WifiOff className="w-3.5 h-3.5 animate-bounce" />
              <span>Offline Mode Active • Full local GST classification & ITC evaluation available without internet</span>
            </div>
            <span className="text-[11px] bg-amber-600/60 px-2 py-0.5 rounded text-white font-mono">
              Offline Storage Enabled
            </span>
          </div>
        </div>
      )}

      {/* Service Worker Update Prompt Banner */}
      {hasUpdate && (
        <div className="bg-indigo-900 text-white px-4 py-2 text-xs font-semibold flex items-center justify-between shadow-xs">
          <div className="max-w-7xl mx-auto w-full flex items-center justify-between">
            <div className="flex items-center gap-2">
              <RotateCw className="w-3.5 h-3.5 text-indigo-300 animate-spin" />
              <span>A new version of SmartExpense CA is ready!</span>
            </div>
            <button
              type="button"
              onClick={onReloadUpdate}
              className="bg-indigo-600 hover:bg-indigo-500 text-white px-3 py-1 rounded-lg text-xs font-bold transition-colors"
            >
              Update Now
            </button>
          </div>
        </div>
      )}

      {/* Top Banner Notice */}
      <div className="bg-slate-50/90 px-4 sm:px-6 py-1.5 text-xs text-slate-600 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200/80">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
            Law Verified: 17 Aug 2026
          </span>
          <span className="text-slate-300 hidden sm:inline">|</span>
          <span className="hidden sm:inline text-slate-500">CBIC GST & CGST Act 2017 Regulatory Framework</span>
        </div>
        <div className="flex items-center gap-2">
          {/* Online/Offline Status Indicator */}
          <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold border ${
            isOnline 
              ? 'bg-emerald-50 text-emerald-700 border-emerald-200' 
              : 'bg-amber-50 text-amber-800 border-amber-300'
          }`}>
            {isOnline ? <Wifi className="w-3 h-3 text-emerald-600" /> : <WifiOff className="w-3 h-3 text-amber-600" />}
            <span>{isOnline ? 'Online' : 'Offline'}</span>
          </span>

          <button
            type="button"
            onClick={onOpenLegalModal}
            className="text-amber-800 hover:text-amber-900 bg-amber-50 hover:bg-amber-100/80 px-2 py-0.5 rounded-full border border-amber-200/80 font-medium transition-colors flex items-center gap-1"
          >
            <ShieldAlert className="w-3.5 h-3.5 text-amber-600" />
            <span>Educational Tool • Not Legal Advice</span>
          </button>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        {/* Brand */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center shadow-xs font-bold text-white text-xl">
              ₹
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold tracking-tight text-slate-900">SmartExpense CA</h1>
                <span className="px-2 py-0.5 text-[11px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200 rounded-full">
                  PWA • ITC Review
                </span>
              </div>
              <p className="text-xs text-slate-500 hidden sm:block">
                AI-Assisted Expense Classification & GST ITC Review for Indian Chartered Accountants
              </p>
            </div>
          </div>
        </div>

        {/* Center Navigation Tabs */}
        <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 self-start md:self-auto">
          <button
            type="button"
            onClick={() => setActiveTab('dashboard')}
            className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${
              activeTab === 'dashboard'
                ? 'bg-white text-slate-900 shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            Compliance Dashboard
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('register')}
            className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all flex items-center gap-1.5 ${
              activeTab === 'register'
                ? 'bg-white text-slate-900 shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            <span>Expense Register</span>
            <span className="px-1.5 py-0.2 bg-slate-200 text-slate-700 rounded-full text-xs font-semibold">
              {totalExpensesCount}
            </span>
          </button>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Add Expense Button */}
          <button
            type="button"
            onClick={onOpenAddModal}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded-xl shadow-xs transition-all active:scale-95"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Add Expense</span>
          </button>

          {/* Bulk Import CSV Button */}
          <button
            type="button"
            onClick={onOpenImportModal}
            title="Bulk Upload & Assess Invoices from CSV"
            className="flex items-center gap-1.5 px-3 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 text-sm font-medium rounded-xl shadow-xs transition-all active:scale-95"
          >
            <UploadCloud className="w-4 h-4 text-indigo-600" />
            <span>Import CSV</span>
          </button>

          {/* PWA Install App Button */}
          <button
            type="button"
            onClick={onOpenInstallModal}
            title="Install SmartExpense CA Progressive Web App"
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300/80 text-sm font-medium rounded-xl shadow-xs transition-all active:scale-95"
          >
            <Download className="w-4 h-4 text-indigo-600" />
            <span className="hidden sm:inline">Install App</span>
          </button>

          {/* Legal Reference Modal Trigger */}
          <button
            type="button"
            onClick={onOpenLegalModal}
            title="View GST Law & Section Reference Guide"
            className="flex items-center gap-1.5 px-3 py-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 text-sm font-medium rounded-xl shadow-xs transition-colors"
          >
            <BookOpen className="w-4 h-4 text-amber-600" />
            <span className="hidden sm:inline">Legal Reference</span>
          </button>

          {/* Export CSV Dropdown */}
          <div className="relative">
            <button
              type="button"
              onClick={() => {
                setShowExportMenu(!showExportMenu);
                setShowDataMenu(false);
              }}
              className="flex items-center gap-1.5 px-3 py-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 text-sm font-medium rounded-xl shadow-xs transition-colors"
            >
              <Download className="w-4 h-4 text-sky-600" />
              <span>Export</span>
            </button>

            {showExportMenu && (
              <div className="absolute right-0 mt-2 w-60 bg-white border border-slate-200 rounded-xl shadow-xl py-1.5 z-50 text-xs animate-in fade-in zoom-in-95 duration-100">
                <button
                  type="button"
                  onClick={() => {
                    onExportRegisterCsv();
                    setShowExportMenu(false);
                  }}
                  className="w-full text-left px-4 py-2.5 hover:bg-slate-50 text-slate-700 flex flex-col transition-colors"
                >
                  <span className="font-semibold text-slate-900">Full Expense Register (CSV)</span>
                  <span className="text-slate-500 text-[11px]">All invoice fields + ITC status</span>
                </button>
                <div className="border-t border-slate-100 my-1"></div>
                <button
                  type="button"
                  onClick={() => {
                    onExportSummaryCsv();
                    setShowExportMenu(false);
                  }}
                  className="w-full text-left px-4 py-2.5 hover:bg-slate-50 text-slate-700 flex flex-col transition-colors"
                >
                  <span className="font-semibold text-slate-900">Audit Summary Report (CSV)</span>
                  <span className="text-slate-500 text-[11px]">Eligible, Blocked, & Category totals</span>
                </button>
              </div>
            )}
          </div>

          {/* Demo Data Management Menu */}
          <div className="relative">
            <button
              type="button"
              onClick={() => {
                setShowDataMenu(!showDataMenu);
                setShowExportMenu(false);
              }}
              title="Manage Demo Data"
              className="p-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 rounded-xl shadow-xs transition-colors"
            >
              <RefreshCw className="w-4 h-4" />
            </button>

            {showDataMenu && (
              <div className="absolute right-0 mt-2 w-52 bg-white border border-slate-200 rounded-xl shadow-xl py-1.5 z-50 text-xs animate-in fade-in zoom-in-95 duration-100">
                <button
                  type="button"
                  onClick={() => {
                    onResetDemoData();
                    setShowDataMenu(false);
                  }}
                  className="w-full text-left px-4 py-2.5 hover:bg-slate-50 text-slate-700 flex items-center gap-2 transition-colors"
                >
                  <RefreshCw className="w-3.5 h-3.5 text-sky-600" />
                  <span className="font-medium text-slate-800">Reset 10 Demo Records</span>
                </button>
                <div className="border-t border-slate-100 my-1"></div>
                <button
                  type="button"
                  onClick={() => {
                    if (window.confirm('Are you sure you want to clear all expenses from local storage?')) {
                      onClearAllData();
                    }
                    setShowDataMenu(false);
                  }}
                  className="w-full text-left px-4 py-2.5 hover:bg-rose-50 text-rose-700 flex items-center gap-2 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                  <span className="font-medium">Clear All Expenses</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};


/**
 * SmartExpense CA - CSV Import & Batch Assessment Engine
 * Parses, cleans, normalizes, validates, and runs deterministic ITC compliance evaluation on bulk invoices.
 */

import Papa from 'papaparse';
import { classifyExpense } from './classifier';
import { roundTwoDecimals, validateGstinFormat, validateTaxConsistency } from './gstUtils';
import { evaluateItcEligibility } from './itcRules';
import {
  BusinessUse,
  Expense,
  ExpenseCategory,
  ExpenseFormData,
  Gstr2bStatus,
  SpecialException,
  SupplierPaymentStatus,
  TaxableOutwardSupply,
  TriStateConfirmation,
} from '../types';

export interface ParsedCsvRowResult {
  rowNumber: number;
  raw: Record<string, string>;
  formData: ExpenseFormData;
  expense: Expense;
  validationStatus: 'valid' | 'warning' | 'error';
  validationErrors: string[];
  validationWarnings: string[];
}

export interface CsvImportSummary {
  totalRows: number;
  validCount: number;
  warningCount: number;
  errorCount: number;
  eligibleCount: number;
  ineligibleCount: number;
  reviewCount: number;
  totalTaxableValue: number;
  totalGstAmount: number;
  eligibleItcAmount: number;
  ineligibleItcAmount: number;
  reviewItcAmount: number;
  rows: ParsedCsvRowResult[];
}

const VALID_CATEGORIES: ExpenseCategory[] = [
  'Office supplies',
  'Professional fees',
  'Software and subscriptions',
  'Rent',
  'Telephone and internet',
  'Advertising and marketing',
  'Business travel',
  'Food and beverages',
  'Employee welfare',
  'Motor vehicle / car expenses',
  'Insurance',
  'Club / fitness membership',
  'Construction / civil works',
  'Personal expense',
  'Capital goods',
  'Other',
];

/**
 * Normalizes header keys by trimming, lowercasing, and stripping special characters.
 */
function normalizeKey(key: string): string {
  return key
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '')
    .trim();
}

/**
 * Parses numeric values safely from strings that might contain INR symbols, commas, or spaces.
 */
export function parseNumeric(val: any, fallback = 0): number {
  if (val === undefined || val === null) return fallback;
  if (typeof val === 'number') return isNaN(val) ? fallback : val;
  const cleaned = String(val)
    .replace(/[₹$,\s]/g, '')
    .trim();
  if (!cleaned) return fallback;
  const num = parseFloat(cleaned);
  return isNaN(num) ? fallback : roundTwoDecimals(num);
}

/**
 * Parses dates in various formats (DD/MM/YYYY, DD-MM-YYYY, YYYY-MM-DD, etc.) to standard ISO YYYY-MM-DD.
 */
export function parseDateToIso(dateStr: any): string {
  if (!dateStr) return new Date().toISOString().substring(0, 10);
  const trimmed = String(dateStr).trim();
  if (!trimmed) return new Date().toISOString().substring(0, 10);

  // YYYY-MM-DD
  if (/^\d{4}-\d{1,2}-\d{1,2}$/.test(trimmed)) {
    const parts = trimmed.split('-');
    const y = parts[0];
    const m = parts[1].padStart(2, '0');
    const d = parts[2].padStart(2, '0');
    return `${y}-${m}-${d}`;
  }

  // DD/MM/YYYY or DD-MM-YYYY or DD.MM.YYYY
  const dmyMatch = trimmed.match(/^(\d{1,2})[\/\-\.](\d{1,2})[\/\-\.](\d{4})$/);
  if (dmyMatch) {
    const d = dmyMatch[1].padStart(2, '0');
    const m = dmyMatch[2].padStart(2, '0');
    const y = dmyMatch[3];
    return `${y}-${m}-${d}`;
  }

  // MM/DD/YYYY check
  const fallbackDate = new Date(trimmed);
  if (!isNaN(fallbackDate.getTime())) {
    return fallbackDate.toISOString().substring(0, 10);
  }

  return new Date().toISOString().substring(0, 10);
}

/**
 * Maps raw CSV object to standard ExpenseFormData keys.
 */
export function mapCsvRowToFormData(row: Record<string, string>, index: number): ExpenseFormData {
  const normMap: Record<string, string> = {};
  for (const [k, v] of Object.entries(row)) {
    normMap[normalizeKey(k)] = typeof v === 'string' ? v.trim() : String(v || '').trim();
  }

  // Helper to lookup multiple possible header aliases
  const getField = (aliases: string[]): string => {
    for (const alias of aliases) {
      const norm = normalizeKey(alias);
      if (normMap[norm] !== undefined && normMap[norm] !== '') {
        return normMap[norm];
      }
    }
    return '';
  };

  const invoiceNumber = getField([
    'Invoice Number',
    'Invoice No',
    'Invoice #',
    'Inv No',
    'Doc No',
    'invoicenumber',
    'invoiceno',
  ]) || `INV-${new Date().getFullYear()}-${String(index + 1).padStart(4, '0')}`;

  const rawDate = getField(['Invoice Date', 'Invoice Date (DD/MM/YYYY)', 'Date', 'Inv Date', 'Doc Date', 'invoicedate']);
  const invoiceDate = parseDateToIso(rawDate);

  const supplierName = getField([
    'Supplier Name',
    'Vendor Name',
    'Supplier',
    'Party Name',
    'Vendor',
    'suppliername',
  ]) || 'Unknown Vendor';

  const supplierGstin = getField([
    'Supplier GSTIN',
    'Vendor GSTIN',
    'GSTIN',
    'Supplier GSTIN / UIN',
    'suppliergstin',
  ]).toUpperCase();

  const recipientGstin = (
    getField(['Recipient GSTIN', 'Buyer GSTIN', 'Our GSTIN', 'recipientgstin']) || '27AACCU1234M1Z1'
  ).toUpperCase();

  const description = getField([
    'Description',
    'Expense Description',
    'Item Description',
    'Particulars',
    'Line Item',
    'description',
  ]);

  const rawCategory = getField(['Category', 'Expense Category', 'Accounting Head', 'category']);
  let category: ExpenseCategory = 'Other';
  let suggestedCategory: ExpenseCategory | undefined;
  let categoryMatchReason: string | undefined;

  // Validate or auto-classify category
  const matchedCategory = VALID_CATEGORIES.find(
    (c) => c.toLowerCase() === rawCategory.toLowerCase()
  );

  if (matchedCategory) {
    category = matchedCategory;
  } else {
    // Run AI / keyword classifier based on description and vendor
    const aiResult = classifyExpense(description, supplierName);
    category = aiResult.category;
    suggestedCategory = aiResult.category;
    categoryMatchReason = `Auto-classified: ${aiResult.explanation}`;
  }

  // Financials
  const taxableValue = parseNumeric(
    getField(['Taxable Value', 'Taxable Amount', 'Base Amount', 'Taxable Value (INR)', 'taxablevalue', 'taxable'])
  );

  let cgstAmount = parseNumeric(getField(['CGST', 'CGST Amount', 'CGST (INR)', 'cgstamount', 'cgst']));
  let sgstAmount = parseNumeric(getField(['SGST', 'SGST Amount', 'SGST (INR)', 'UTGST', 'sgstamount', 'sgst']));
  let igstAmount = parseNumeric(getField(['IGST', 'IGST Amount', 'IGST (INR)', 'Integrated Tax', 'igstamount', 'igst']));
  const cessAmount = parseNumeric(getField(['Cess', 'Cess Amount', 'Compensation Cess', 'cessamount', 'cess']));

  // Check if GST Rate column is provided e.g. "18%" or "18"
  const rateVal = getField(['GST Rate', 'Rate', 'Tax Rate', 'gstrate']);
  if (taxableValue > 0 && cgstAmount === 0 && sgstAmount === 0 && igstAmount === 0 && rateVal) {
    const rateNum = parseNumeric(rateVal.replace('%', ''));
    if (rateNum > 0) {
      // Default to intra-state unless supplier state differs from recipient state
      const isInter =
        supplierGstin.length >= 2 &&
        recipientGstin.length >= 2 &&
        supplierGstin.substring(0, 2) !== recipientGstin.substring(0, 2);

      const totalTax = roundTwoDecimals((taxableValue * rateNum) / 100);
      if (isInter) {
        igstAmount = totalTax;
      } else {
        cgstAmount = roundTwoDecimals(totalTax / 2);
        sgstAmount = roundTwoDecimals(totalTax / 2);
      }
    }
  }

  const calculatedTotal = roundTwoDecimals(taxableValue + cgstAmount + sgstAmount + igstAmount + cessAmount);
  const rawTotal = parseNumeric(
    getField(['Total Amount', 'Total', 'Invoice Value', 'Total Invoice Amount (INR)', 'totalamount', 'total'])
  );
  const totalAmount = rawTotal > 0 ? rawTotal : calculatedTotal;

  // Payment Status
  const rawPayment = getField(['Payment Status', 'Supplier Payment Status', 'Payment', 'Status', 'paymentstatus']).toLowerCase();
  let supplierPaymentStatus: SupplierPaymentStatus = 'Paid';
  if (rawPayment.includes('unpaid') || rawPayment === 'no' || rawPayment === 'pending' || rawPayment === 'due') {
    supplierPaymentStatus = 'Unpaid';
  } else if (rawPayment.includes('part')) {
    supplierPaymentStatus = 'Partially paid';
  }

  const rawPayDate = getField(['Payment Date', 'Paid Date', 'paymentdate']);
  const paymentDate = rawPayDate ? parseDateToIso(rawPayDate) : supplierPaymentStatus === 'Paid' ? invoiceDate : undefined;

  // Compliance Flags
  const rawInvoiceAvail = getField(['Tax Invoice Available', 'Tax Invoice in Possession', 'Invoice Copy', 'taxinvoiceavailable']).toLowerCase();
  const taxInvoiceAvailable: 'Yes' | 'No' = rawInvoiceAvail === 'no' || rawInvoiceAvail === 'n' ? 'No' : 'Yes';

  const rawGoodsRec = getField(['Goods/Services Received', 'Goods Received', 'GRN Done', 'Receipt Confirmed', 'goodsservicesreceived']).toLowerCase();
  let goodsServicesReceived: TriStateConfirmation = 'Yes';
  if (rawGoodsRec === 'no' || rawGoodsRec === 'n') {
    goodsServicesReceived = 'No';
  } else if (rawGoodsRec.includes('transit') || rawGoodsRec.includes('unconfirmed') || rawGoodsRec.includes('not confirmed') || rawGoodsRec.includes('pending')) {
    goodsServicesReceived = 'Not confirmed';
  }

  const raw2b = getField(['Reflected in GSTR-2B', 'GSTR-2B Reflected', '2B Reflected', '2B Status', 'reflectedingstr2b']).toLowerCase();
  let reflectedInGstr2b: Gstr2bStatus = 'Yes';
  if (raw2b === 'no' || raw2b === 'n' || raw2b.includes('missing') || raw2b.includes('not reflected')) {
    reflectedInGstr2b = 'No';
  } else if (raw2b.includes('not checked') || raw2b.includes('unverified') || raw2b.includes('pending') || raw2b.includes('check')) {
    reflectedInGstr2b = 'Not checked';
  }

  const rawBiz = getField(['Business Use', 'Used for Business', 'Business Furtherance', 'usedforbusiness']).toLowerCase();
  let usedForBusiness: BusinessUse = 'Yes';
  if (rawBiz === 'no' || rawBiz === 'personal') {
    usedForBusiness = 'No';
  } else if (rawBiz.includes('part') || rawBiz.includes('mixed')) {
    usedForBusiness = 'Partly';
  }

  const rawOutward = getField(['Taxable Outward Supply', 'Used for Taxable Outward Supply', 'Outward Supply', 'usedfortaxableoutwardsupply']).toLowerCase();
  let usedForTaxableOutwardSupply: TaxableOutwardSupply = 'Yes';
  if (rawOutward === 'no' || rawOutward.includes('exempt')) {
    usedForTaxableOutwardSupply = 'No';
  } else if (rawOutward.includes('part') || rawOutward.includes('common')) {
    usedForTaxableOutwardSupply = 'Partly';
  } else if (rawOutward.includes('unconfirmed') || rawOutward.includes('not sure')) {
    usedForTaxableOutwardSupply = 'Not confirmed';
  }

  const rawException = getField(['Special Exception', 'Section 17(5) Exception', 'Exception', 'specialexception']);
  let specialException: SpecialException = 'No';
  if (rawException) {
    const low = rawException.toLowerCase();
    if (low.includes('same category') || low.includes('sub-contract') || low.includes('resale')) {
      specialException = 'Further supply of same category';
    } else if (low.includes('passenger') || low.includes('transport') || low.includes('taxi')) {
      specialException = 'Passenger transport';
    } else if (low.includes('driving') || low.includes('training')) {
      specialException = 'Driving training';
    } else if (low.includes('statutory') || low.includes('obligation') || low.includes('mandatory') || low.includes('factories act')) {
      specialException = 'Statutory employer obligation';
    } else if (low.includes('other') || low.includes('sure')) {
      specialException = 'Other / not sure';
    }
  }

  const notes = getField(['Notes', 'Remarks', 'Audit Notes', 'notes']);

  return {
    invoiceNumber,
    invoiceDate,
    supplierName,
    supplierGstin,
    recipientGstin,
    description: description || `${category} invoice from ${supplierName}`,
    category,
    suggestedCategory,
    categoryMatchReason,
    taxableValue,
    cgstAmount,
    sgstAmount,
    igstAmount,
    cessAmount,
    totalAmount,
    supplierPaymentStatus,
    paymentDate,
    goodsServicesReceived,
    taxInvoiceAvailable,
    reflectedInGstr2b,
    usedForBusiness,
    usedForTaxableOutwardSupply,
    specialException,
    notes,
  };
}

/**
 * Validates a single row and compiles evaluation trail.
 */
export function validateAndEvaluateRow(formData: ExpenseFormData, rowNumber: number, raw: Record<string, string>): ParsedCsvRowResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  // Validation rules
  if (!formData.invoiceNumber || formData.invoiceNumber.trim() === '') {
    errors.push('Missing Invoice Number');
  }
  if (!formData.supplierName || formData.supplierName.trim() === '') {
    errors.push('Missing Supplier Name');
  }
  if (formData.taxableValue <= 0) {
    warnings.push('Taxable base value is ₹0 or empty');
  }

  // GSTIN check
  if (formData.supplierGstin) {
    const gstinCheck = validateGstinFormat(formData.supplierGstin);
    if (!gstinCheck.isValid) {
      warnings.push(`Supplier GSTIN syntax warning (${formData.supplierGstin}): ${gstinCheck.message}`);
    }
  } else {
    warnings.push('Supplier GSTIN is not provided');
  }

  // Tax consistency
  const taxCheck = validateTaxConsistency(
    formData.taxableValue,
    formData.cgstAmount,
    formData.sgstAmount,
    formData.igstAmount
  );
  if (!taxCheck.isValid) {
    warnings.push(taxCheck.error || 'Simultaneous IGST and CGST/SGST detected');
  }

  // Run Rules Engine
  const totalGst = roundTwoDecimals(
    (formData.cgstAmount || 0) + (formData.sgstAmount || 0) + (formData.igstAmount || 0) + (formData.cessAmount || 0)
  );
  const itcDecision = evaluateItcEligibility(formData);

  const expense: Expense = {
    ...formData,
    id: `csv-${Date.now()}-${rowNumber}-${Math.random().toString(36).substring(2, 6)}`,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    totalGst,
    itcDecision,
  };

  const validationStatus: 'valid' | 'warning' | 'error' =
    errors.length > 0 ? 'error' : warnings.length > 0 ? 'warning' : 'valid';

  return {
    rowNumber,
    raw,
    formData,
    expense,
    validationStatus,
    validationErrors: errors,
    validationWarnings: warnings,
  };
}

/**
 * Parses raw CSV string or file into structured results and summary metrics.
 */
export function parseInvoiceCsv(csvText: string): CsvImportSummary {
  const parseResult = Papa.parse<Record<string, string>>(csvText, {
    header: true,
    skipEmptyLines: 'greedy',
    transformHeader: (header) => header.trim(),
  });

  const parsedRows: ParsedCsvRowResult[] = [];
  let validCount = 0;
  let warningCount = 0;
  let errorCount = 0;

  let eligibleCount = 0;
  let ineligibleCount = 0;
  let reviewCount = 0;

  let totalTaxableValue = 0;
  let totalGstAmount = 0;
  let eligibleItcAmount = 0;
  let ineligibleItcAmount = 0;
  let reviewItcAmount = 0;

  parseResult.data.forEach((rawRow, index) => {
    // Check if row has any non-empty value
    const hasData = Object.values(rawRow).some((v) => v && String(v).trim() !== '');
    if (!hasData) return;

    const rowNum = index + 1;
    const formData = mapCsvRowToFormData(rawRow, index);
    const rowResult = validateAndEvaluateRow(formData, rowNum, rawRow);

    parsedRows.push(rowResult);

    if (rowResult.validationStatus === 'error') {
      errorCount++;
    } else if (rowResult.validationStatus === 'warning') {
      warningCount++;
      validCount++;
    } else {
      validCount++;
    }

    const exp = rowResult.expense;
    totalTaxableValue += exp.taxableValue || 0;
    totalGstAmount += exp.totalGst || 0;

    if (exp.itcDecision.status === 'Eligible') {
      eligibleCount++;
      eligibleItcAmount += exp.totalGst || 0;
    } else if (exp.itcDecision.status === 'Ineligible') {
      ineligibleCount++;
      ineligibleItcAmount += exp.totalGst || 0;
    } else {
      reviewCount++;
      reviewItcAmount += exp.totalGst || 0;
    }
  });

  return {
    totalRows: parsedRows.length,
    validCount,
    warningCount,
    errorCount,
    eligibleCount,
    ineligibleCount,
    reviewCount,
    totalTaxableValue: roundTwoDecimals(totalTaxableValue),
    totalGstAmount: roundTwoDecimals(totalGstAmount),
    eligibleItcAmount: roundTwoDecimals(eligibleItcAmount),
    ineligibleItcAmount: roundTwoDecimals(ineligibleItcAmount),
    reviewItcAmount: roundTwoDecimals(reviewItcAmount),
    rows: parsedRows,
  };
}

/**
 * Generates and downloads the comprehensive CSV import template.
 */
export function downloadCsvTemplate(): void {
  const templateHeaders = [
    'Invoice Number',
    'Invoice Date',
    'Supplier Name',
    'Supplier GSTIN',
    'Recipient GSTIN',
    'Category',
    'Description',
    'Taxable Value',
    'CGST',
    'SGST',
    'IGST',
    'Cess',
    'Total Amount',
    'Payment Status',
    'Payment Date',
    'Tax Invoice Available',
    'Goods/Services Received',
    'Reflected in GSTR-2B',
    'Business Use',
    'Taxable Outward Supply',
    'Special Exception',
    'Notes',
  ];

  const sampleRows = [
    [
      'INV-2026-801',
      '2026-08-05',
      'Atlassian Software Systems India Pvt Ltd',
      '27AABCA9876C1Z5',
      '27AACCU1234M1Z1',
      'Software and subscriptions',
      'Jira & Confluence Cloud Enterprise Annual Licenses',
      '150000.00',
      '13500.00',
      '13500.00',
      '0.00',
      '0.00',
      '177000.00',
      'Paid',
      '2026-08-05',
      'Yes',
      'Yes',
      'Yes',
      'Yes',
      'Yes',
      'No',
      'Enterprise subscription for internal dev team',
    ],
    [
      'INV-2026-802',
      '2026-07-28',
      'BMW Motorrad Service Centre',
      '27AAACB5544K1ZR',
      '27AACCU1234M1Z1',
      'Motor vehicle / car expenses',
      'Corporate Director sedan routine servicing and brake pad replacement',
      '45000.00',
      '6300.00',
      '6300.00',
      '0.00',
      '0.00',
      '57600.00',
      'Paid',
      '2026-07-28',
      'Yes',
      'Yes',
      'Yes',
      'Yes',
      'Yes',
      'No',
      'Vehicle seating capacity <= 13 (Section 17(5)(a) blocked)',
    ],
    [
      'INV-2025-412',
      '2025-11-10',
      'Prime IT Hardware Solutions LLP',
      '07AAAFP4421M1Z3',
      '27AACCU1234M1Z1',
      'Office supplies',
      'Dell Server Rack & high performance monitors',
      '80000.00',
      '0.00',
      '0.00',
      '14400.00',
      '0.00',
      '94400.00',
      'Unpaid',
      '',
      'Yes',
      'Yes',
      'Yes',
      'Yes',
      'Yes',
      'No',
      'Unpaid for > 180 days (Rule 37 reversal flag)',
    ],
    [
      'INV-2026-804',
      '2026-08-12',
      'Taj Lands End Luxury Dining & Hospitality',
      '27AABCT2345K1Z8',
      '27AACCU1234M1Z1',
      'Food and beverages',
      'Executive client banquet dinner and fine dining catering',
      '32000.00',
      '2880.00',
      '2880.00',
      '0.00',
      '0.00',
      '37760.00',
      'Paid',
      '2026-08-12',
      'Yes',
      'Yes',
      'Yes',
      'Yes',
      'Yes',
      'No',
      'Section 17(5)(b)(i) food and beverages blocked credit',
    ],
    [
      'INV-2026-805',
      '2026-08-14',
      'Cloudflare Inc CDN & Security Services',
      '27AABCC8899D1ZQ',
      '27AACCU1234M1Z1',
      'Software and subscriptions',
      'Enterprise WAF and DDoS Protection annual tier',
      '60000.00',
      '5400.00',
      '5400.00',
      '0.00',
      '0.00',
      '70800.00',
      'Paid',
      '2026-08-14',
      'Yes',
      'Yes',
      'No',
      'Yes',
      'Yes',
      'No',
      'Pending vendor GSTR-1 filing; missing in GSTR-2B',
    ],
  ];

  const csvString = Papa.unparse({
    fields: templateHeaders,
    data: sampleRows,
  });

  const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', 'SmartExpense_CA_Invoice_Import_Template.csv');
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

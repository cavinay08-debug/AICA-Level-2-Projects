/**
 * SmartExpense CA - Automated Test Suite for GST ITC Rules Engine
 * Tests mandatory compliance checks, Section 16 conditions, Section 17(5) blocked credits,
 * 180-day rule, time limits, and tax split consistency.
 */

import { describe, expect, it } from 'vitest';
import { ExpenseFormData } from '../types';
import { validateGstinFormat, validateTaxConsistency } from './gstUtils';
import { evaluateItcEligibility } from './itcRules';

const baseValidExpense: ExpenseFormData = {
  invoiceNumber: 'INV-2026-001',
  invoiceDate: '2026-06-15',
  supplierName: 'CloudInfra Tech Solutions Pvt Ltd',
  supplierGstin: '27AABCC1234F1Z5', // Maharashtra
  recipientGstin: '27AACCS9876E1Z2',
  description: 'Monthly AWS Cloud Hosting & Kubernetes Cluster',
  category: 'Software and subscriptions',
  taxableValue: 50000,
  cgstAmount: 4500,
  sgstAmount: 4500,
  igstAmount: 0,
  cessAmount: 0,
  totalAmount: 59000,
  supplierPaymentStatus: 'Paid',
  paymentDate: '2026-06-20',
  goodsServicesReceived: 'Yes',
  taxInvoiceAvailable: 'Yes',
  reflectedInGstr2b: 'Yes',
  usedForBusiness: 'Yes',
  usedForTaxableOutwardSupply: 'Yes',
  specialException: 'No',
  notes: 'Production server hosting bill',
};

describe('GST ITC Rules Engine - Statutory Compliance Tests', () => {
  // Test 1: Eligible business software expense
  it('1. should evaluate a fully compliant business software subscription as Eligible', () => {
    const result = evaluateItcEligibility(baseValidExpense);
    expect(result.status).toBe('Eligible');
    expect(result.eligibleAmount).toBe(9000);
    expect(result.blockedAmount).toBe(0);
    expect(result.reviewAmount).toBe(0);
    expect(result.detailedReason).toContain('Preliminary eligibility result');
  });

  // Test 2: Personal expense
  it('2. should evaluate a personal non-business expense as Ineligible under Section 17(1) & 17(5)(g)', () => {
    const personalExpense: ExpenseFormData = {
      ...baseValidExpense,
      category: 'Personal expense',
      description: 'Personal grocery and home appliances for residence',
      usedForBusiness: 'No',
    };
    const result = evaluateItcEligibility(personalExpense);
    expect(result.status).toBe('Ineligible');
    expect(result.blockedAmount).toBe(9000);
    expect(result.flags).toContain('Personal / Non-Business Expense');
  });

  // Test 3: Food and beverages without exception
  it('3. should evaluate food and catering expenses without exception as Ineligible under Section 17(5)(b)(i)', () => {
    const foodExpense: ExpenseFormData = {
      ...baseValidExpense,
      category: 'Food and beverages',
      description: 'Client buffet dinner at luxury restaurant',
      specialException: 'No',
    };
    const result = evaluateItcEligibility(foodExpense);
    expect(result.status).toBe('Ineligible');
    expect(result.blockedAmount).toBe(9000);
    expect(result.primaryReason).toContain('Food & Beverages');
  });

  // Test 4: Food and beverages with outward-supply exception
  it('4. should evaluate food and beverages with outward-supply exception as CA Review Required', () => {
    const foodWithException: ExpenseFormData = {
      ...baseValidExpense,
      category: 'Food and beverages',
      description: 'Sub-contracted catering for corporate event',
      specialException: 'Further supply of same category',
    };
    const result = evaluateItcEligibility(foodWithException);
    expect(result.status).toBe('CA Review Required');
    expect(result.reviewAmount).toBe(9000);
    expect(result.flags.some((f) => f.includes('Outward Supply Exception'))).toBe(true);
  });

  // Test 5: Unpaid invoice beyond 180 days
  it('5. should flag unpaid invoices older than 180 days for CA Review under Rule 37', () => {
    const oldUnpaidExpense: ExpenseFormData = {
      ...baseValidExpense,
      invoiceDate: '2025-01-10', // Well over 180 days ago from 2026
      supplierPaymentStatus: 'Unpaid',
      paymentDate: undefined,
    };
    const result = evaluateItcEligibility(oldUnpaidExpense);
    expect(result.status).toBe('CA Review Required');
    expect(result.flags.some((f) => f.includes('Unpaid > 180 Days'))).toBe(true);
  });

  // Test 6: Missing invoice document
  it('6. should evaluate missing tax invoice document as Ineligible under Section 16(2)(a)', () => {
    const missingInvoice: ExpenseFormData = {
      ...baseValidExpense,
      taxInvoiceAvailable: 'No',
    };
    const result = evaluateItcEligibility(missingInvoice);
    expect(result.status).toBe('Ineligible');
    expect(result.flags).toContain('No Tax Invoice in Possession');
  });

  // Test 7: Invalid GSTIN format
  it('7. should flag invalid supplier GSTIN format as CA Review Required', () => {
    const invalidGstinExpense: ExpenseFormData = {
      ...baseValidExpense,
      supplierGstin: 'INVALID_GSTIN_123',
    };
    const result = evaluateItcEligibility(invalidGstinExpense);
    expect(result.status).toBe('CA Review Required');
    expect(result.flags).toContain('Invalid Supplier GSTIN Syntax');
  });

  // Test 8: Mixed taxable/exempt use
  it('8. should flag mixed taxable and exempt outward supply for Rule 42/43 apportionment review', () => {
    const mixedUseExpense: ExpenseFormData = {
      ...baseValidExpense,
      usedForTaxableOutwardSupply: 'Partly',
    };
    const result = evaluateItcEligibility(mixedUseExpense);
    expect(result.status).toBe('CA Review Required');
    expect(result.flags.some((f) => f.includes('Common Credit'))).toBe(true);
  });

  // Test 9: Motor vehicle with and without statutory exception
  it('9a. should evaluate passenger motor vehicle without exception as Ineligible under Section 17(5)(a)', () => {
    const carExpense: ExpenseFormData = {
      ...baseValidExpense,
      category: 'Motor vehicle / car expenses',
      description: 'Executive sedan car periodic servicing and engine repair',
      specialException: 'No',
    };
    const result = evaluateItcEligibility(carExpense);
    expect(result.status).toBe('Ineligible');
    expect(result.flags).toContain('Blocked Motor Vehicle Credit under Section 17(5)(a)');
  });

  it('9b. should flag motor vehicle with passenger transport exception for CA Review', () => {
    const cabServiceExpense: ExpenseFormData = {
      ...baseValidExpense,
      category: 'Motor vehicle / car expenses',
      description: 'Commercial taxi fleet maintenance',
      specialException: 'Passenger transport',
    };
    const result = evaluateItcEligibility(cabServiceExpense);
    expect(result.status).toBe('CA Review Required');
    expect(result.flags.some((f) => f.includes('Motor Vehicle Exception'))).toBe(true);
  });

  // Test 10: Section 16(4) Date/time-limit boundary cases
  it('10. should flag invoices with passed Section 16(4) 30th November deadline for CA Review', () => {
    const ancientExpense: ExpenseFormData = {
      ...baseValidExpense,
      invoiceDate: '2023-05-15', // FY 2023-24 (Deadline was 30 Nov 2024, now 2026)
    };
    const result = evaluateItcEligibility(ancientExpense);
    expect(result.status).toBe('CA Review Required');
    expect(result.flags.some((f) => f.includes('Section 16(4) Cutoff'))).toBe(true);
  });

  // Test 11: IGST versus CGST + SGST tax split validation
  it('11. should detect invalid simultaneous IGST and CGST+SGST entry', () => {
    const invalidTax = validateTaxConsistency(10000, 900, 900, 1800);
    expect(invalidTax.isValid).toBe(false);
    expect(invalidTax.error).toContain('Under GST laws, an invoice cannot simultaneously have both');

    const invalidTaxExpense: ExpenseFormData = {
      ...baseValidExpense,
      cgstAmount: 900,
      sgstAmount: 900,
      igstAmount: 1800,
    };
    const result = evaluateItcEligibility(invalidTaxExpense);
    expect(result.status).toBe('CA Review Required');
    expect(result.flags).toContain('Invalid Tax Component Combination');
  });

  it('12. should validate correct GSTIN syntax and extract state name', () => {
    const valid = validateGstinFormat('07AAAAA0000A1Z5');
    expect(valid.isValid).toBe(true);
    expect(valid.stateName).toBe('Delhi');

    const invalid = validateGstinFormat('12345');
    expect(invalid.isValid).toBe(false);
  });
});

/**
 * SmartExpense CA - GST Utility Functions
 * Handles Indian GSTIN format checks, currency/date formatting, tax validation, and FY date calculations.
 */

export const INDIAN_STATE_CODES: Record<string, string> = {
  '01': 'Jammu & Kashmir',
  '02': 'Himachal Pradesh',
  '03': 'Punjab',
  '04': 'Chandigarh',
  '05': 'Uttarakhand',
  '06': 'Haryana',
  '07': 'Delhi',
  '08': 'Rajasthan',
  '09': 'Uttar Pradesh',
  '10': 'Bihar',
  '11': 'Sikkim',
  '12': 'Arunachal Pradesh',
  '13': 'Nagaland',
  '14': 'Manipur',
  '15': 'Mizoram',
  '16': 'Tripura',
  '17': 'Meghalaya',
  '18': 'Assam',
  '19': 'West Bengal',
  '20': 'Jharkhand',
  '21': 'Odisha',
  '22': 'Chhattisgarh',
  '23': 'Madhya Pradesh',
  '24': 'Gujarat',
  '26': 'Dadra & Nagar Haveli and Daman & Diu',
  '27': 'Maharashtra',
  '28': 'Andhra Pradesh',
  '29': 'Karnataka',
  '30': 'Goa',
  '31': 'Lakshadweep',
  '32': 'Kerala',
  '33': 'Tamil Nadu',
  '34': 'Puducherry',
  '35': 'Andaman & Nicobar Islands',
  '36': 'Telangana',
  '37': 'Andhra Pradesh (New)',
  '38': 'Ladakh',
  '97': 'Other Territory',
  '99': 'Centre Jurisdiction',
};

// Standard GSTIN Regex: 2 digits state code, 10 alphanumeric PAN, 1 entity digit, 'Z', 1 checksum char
export const GSTIN_REGEX = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;

export interface GstinValidationResult {
  isValid: boolean;
  stateCode?: string;
  stateName?: string;
  pan?: string;
  message: string;
  disclaimer: string;
}

/**
 * Validates GSTIN structure syntactically.
 * Clarifies that this is a format check only and does not establish live portal status.
 */
export function validateGstinFormat(gstin: string | undefined | null): GstinValidationResult {
  const disclaimer = 'Notice: Syntactic format check only. Does not confirm active registration or filing status on the live GST Portal.';
  
  if (!gstin || gstin.trim() === '') {
    return {
      isValid: false,
      message: 'GSTIN is empty or missing.',
      disclaimer,
    };
  }

  const cleanGstin = gstin.trim().toUpperCase();

  if (cleanGstin.length !== 15) {
    return {
      isValid: false,
      message: `GSTIN must be exactly 15 alphanumeric characters (found ${cleanGstin.length}).`,
      disclaimer,
    };
  }

  if (!GSTIN_REGEX.test(cleanGstin)) {
    return {
      isValid: false,
      message: 'GSTIN format is invalid. Expected format: 2-digit State + 10-char PAN + Entity code + Z + Checksum.',
      disclaimer,
    };
  }

  const stateCode = cleanGstin.substring(0, 2);
  const pan = cleanGstin.substring(2, 12);
  const stateName = INDIAN_STATE_CODES[stateCode] || 'Unknown State Code';

  return {
    isValid: true,
    stateCode,
    stateName,
    pan,
    message: `Valid format (${stateName})`,
    disclaimer,
  };
}

/**
 * Safely rounds decimal numbers to 2 places.
 */
export function roundTwoDecimals(value: number): number {
  if (isNaN(value) || !isFinite(value)) return 0;
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

/**
 * Formats a numeric amount to Indian Rupee (INR) currency format (e.g. ₹1,23,456.78).
 */
export function formatINR(amount: number): string {
  const safeAmount = roundTwoDecimals(amount || 0);
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(safeAmount);
}

/**
 * Formats a Date object or YYYY-MM-DD string to Indian standard DD/MM/YYYY.
 */
export function formatDateDDMMYYYY(dateInput: string | Date | undefined | null): string {
  if (!dateInput) return '-';
  try {
    let d: Date;
    if (typeof dateInput === 'string') {
      if (dateInput.includes('T')) {
        d = new Date(dateInput);
      } else {
        const parts = dateInput.split('-');
        if (parts.length === 3) {
          d = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
        } else {
          d = new Date(dateInput);
        }
      }
    } else {
      d = dateInput;
    }

    if (isNaN(d.getTime())) return String(dateInput);

    const day = String(d.getDate()).padStart(2, '0');
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const year = d.getFullYear();
    return `${day}/${month}/${year}`;
  } catch {
    return String(dateInput);
  }
}

/**
 * Calculates Indian Financial Year for a given invoice date.
 * E.g., '2025-05-12' -> { fyString: '2025-26', fyEndYear: 2026, sec16_4Deadline: '2026-11-30' }
 */
export function getFinancialYearInfo(invoiceDateStr: string): {
  fyString: string;
  fyStartYear: number;
  fyEndYear: number;
  sec16_4Deadline: string; // YYYY-MM-DD
  isDeadlinePassed: boolean;
  daysToDeadline: number;
} {
  const d = new Date(invoiceDateStr);
  const year = d.getFullYear();
  const month = d.getMonth() + 1; // 1-12

  let fyStartYear: number;
  let fyEndYear: number;

  if (month >= 4) {
    // April to December
    fyStartYear = year;
    fyEndYear = year + 1;
  } else {
    // January to March
    fyStartYear = year - 1;
    fyEndYear = year;
  }

  const fyShort = `${fyStartYear}-${String(fyEndYear).slice(-2)}`;
  const sec16_4Deadline = `${fyEndYear}-11-30`;

  const deadlineDate = new Date(fyEndYear, 10, 30, 23, 59, 59); // 30 Nov of following year
  const today = new Date();
  const diffTime = deadlineDate.getTime() - today.getTime();
  const daysToDeadline = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  const isDeadlinePassed = daysToDeadline < 0;

  return {
    fyString: fyShort,
    fyStartYear,
    fyEndYear,
    sec16_4Deadline,
    isDeadlinePassed,
    daysToDeadline,
  };
}

/**
 * Calculates calendar days elapsed between invoice date and reference date (or current date).
 */
export function calculateDaysElapsed(invoiceDateStr: string, referenceDateStr?: string): number {
  try {
    const invDate = new Date(invoiceDateStr);
    const refDate = referenceDateStr ? new Date(referenceDateStr) : new Date();
    const diffTime = refDate.getTime() - invDate.getTime();
    return Math.max(0, Math.floor(diffTime / (1000 * 60 * 60 * 24)));
  } catch {
    return 0;
  }
}

/**
 * Tax validation helper: ensures valid CGST/SGST vs IGST entry.
 */
export function validateTaxConsistency(taxable: number, cgst: number, sgst: number, igst: number): {
  isValid: boolean;
  error?: string;
} {
  const safeCgst = roundTwoDecimals(cgst || 0);
  const safeSgst = roundTwoDecimals(sgst || 0);
  const safeIgst = roundTwoDecimals(igst || 0);

  // Negative checks
  if (taxable < 0 || safeCgst < 0 || safeSgst < 0 || safeIgst < 0) {
    return {
      isValid: false,
      error: 'Invoice and tax amounts cannot be negative.',
    };
  }

  // Mutual exclusivity check between IGST and CGST+SGST
  if (safeIgst > 0 && (safeCgst > 0 || safeSgst > 0)) {
    return {
      isValid: false,
      error: 'Tax split error: Under GST laws, an invoice cannot simultaneously have both Inter-State Tax (IGST) and Intra-State Taxes (CGST / SGST). Please enter either IGST or CGST+SGST.',
    };
  }

  // Intra-state CGST & SGST balance check (in Indian GST, CGST rate equals SGST rate)
  if ((safeCgst > 0 || safeSgst > 0) && Math.abs(safeCgst - safeSgst) > 0.5) {
    return {
      isValid: true, // allowed with warning
      error: 'Warning: For intra-state supplies, CGST and SGST amounts are usually equal. Please verify tax rate split.',
    };
  }

  return { isValid: true };
}

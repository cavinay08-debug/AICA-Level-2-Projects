/**
 * SmartExpense CA - AI-Assisted Expense Classifier (Rule-based NLP Engine)
 * Analyzes natural language expense descriptions and supplier names to suggest accounting categories.
 */

import { ExpenseCategory } from '../types';

export interface CategorySuggestion {
  category: ExpenseCategory;
  confidence: 'High' | 'Medium' | 'Low';
  matchedKeywords: string[];
  explanation: string;
}

interface CategoryKeywordRule {
  category: ExpenseCategory;
  primaryKeywords: string[];
  secondaryKeywords: string[];
  description: string;
}

const CATEGORY_RULES: CategoryKeywordRule[] = [
  {
    category: 'Software and subscriptions',
    primaryKeywords: [
      'adobe', 'aws', 'amazon web services', 'azure', 'google cloud', 'gcp', 'cloud hosting',
      'saas', 'subscription', 'software', 'zoom', 'github', 'gitlab', 'jetbrains', 'slack',
      'jira', 'atlassian', 'microsoft 365', 'google workspace', 'server hosting', 'domain',
      'antivirus', 'canva', 'figma', 'notion', 'hubspot', 'salesforce', 'crm', 'erp software',
      'digital ocean', 'godaddy', 'namecheap', 'quickbooks', 'tally', 'zoho', 'chatgpt', 'openai'
    ],
    secondaryKeywords: ['license', 'api', 'monthly plan', 'annual plan', 'app', 'tool', 'portal'],
    description: 'Digital tools, cloud computing infrastructure, and recurring software licenses.',
  },
  {
    category: 'Professional fees',
    primaryKeywords: [
      'advocate', 'lawyer', 'legal counsel', 'chartered accountant', 'audit fee', 'statutory audit',
      'tax consultant', 'advisory fees', 'consulting fees', 'retainer fee', 'director sitting fee',
      'valuation fee', 'certifying fee', 'company secretary', 'cs firm', 'compliance fee',
      'attorney', 'notary', 'counsel'
    ],
    secondaryKeywords: ['consultant', 'professional service', 'retainership', 'opinion', 'appearance'],
    description: 'Legal, taxation, secretarial, technical, and management consultancy services.',
  },
  {
    category: 'Business travel',
    primaryKeywords: [
      'flight', 'air ticket', 'indigo', 'air india', 'vistara', 'spicejet', 'hotel stay', 'lodging',
      'cab fare', 'uber', 'ola', 'taxi', 'train ticket', 'irctc', 'railway', 'airport cab',
      'boarding', 'travel booking', 'makemytrip', 'yatra', 'cleartrip', 'business trip'
    ],
    secondaryKeywords: ['travel', 'booking', 'fare', 'toll tax', 'transit', 'accommodation'],
    description: 'Official travel, passenger transport, flight tickets, and hotel accommodation.',
  },
  {
    category: 'Food and beverages',
    primaryKeywords: [
      'restaurant', 'catering', 'buffet', 'lunch', 'dinner', 'swiggy', 'zomato', 'canteen',
      'pantry snacks', 'coffee', 'tea', 'cafe', 'starbucks', 'barbeque nation', 'food order',
      'refreshments', 'client lunch', 'staff meal', 'breakfast', 'pantry supplies'
    ],
    secondaryKeywords: ['food', 'beverage', 'eating', 'beverages', 'dining', 'catering service'],
    description: 'Client hospitality, catering, restaurant bills, and pantry food supplies.',
  },
  {
    category: 'Motor vehicle / car expenses',
    primaryKeywords: [
      'car repair', 'car service', 'fuel', 'petrol', 'diesel', 'cng', 'motor insurance',
      'vehicle maintenance', 'tyre replacement', 'wheel alignment', 'driver salary',
      'fleet service', 'garage bill', 'car washing', 'vehicle spare parts', 'fastag'
    ],
    secondaryKeywords: ['vehicle', 'car', 'automobile', 'motor', 'auto service', 'mileage'],
    description: 'Running, repair, servicing, and fueling expenses of four-wheelers and two-wheelers.',
  },
  {
    category: 'Capital goods',
    primaryKeywords: [
      'laptop', 'macbook', 'desktop pc', 'computer monitor', 'printer', 'office furniture',
      'ergonomic chair', 'office desk', 'conference table', 'server rack', 'machinery',
      'air conditioner', 'generator', 'refrigerator', 'heavy equipment', 'plant and machinery'
    ],
    secondaryKeywords: ['asset', 'hardware', 'appliance', 'fixed asset', 'capital equipment'],
    description: 'Capital assets, electronics, machinery, and furniture capitalized in balance sheet.',
  },
  {
    category: 'Office supplies',
    primaryKeywords: [
      'stationery', 'printer paper', 'a4 rim', 'toner cartridge', 'ink bottle', 'pen',
      'stapler', 'box files', 'envelopes', 'office supplies', 'whiteboard', 'markers',
      'register notebook', 'courier packing'
    ],
    secondaryKeywords: ['supplies', 'paper', 'stationer', 'desk accessories'],
    description: 'General consumables, stationery, packaging, and printing paper.',
  },
  {
    category: 'Rent',
    primaryKeywords: [
      'office rent', 'building rent', 'godown rent', 'warehouse rent', 'premises rent',
      'coworking space', 'wework', 'awfis', 'innov8', 'monthly rent', 'lease agreement',
      'office lease', 'shop rent'
    ],
    secondaryKeywords: ['rent', 'lease', 'tenancy', 'co-working', 'premises'],
    description: 'Commercial rental and lease payments for office premises or godowns.',
  },
  {
    category: 'Telephone and internet',
    primaryKeywords: [
      'broadband', 'fiber internet', 'airtel', 'jio fiber', 'act fibernet', 'tata tele',
      'mobile postpaid', 'telephone bill', 'landline', 'wi-fi bill', 'sim card recharge',
      'telecom bill', 'leased line'
    ],
    secondaryKeywords: ['internet', 'phone', 'cellular', 'telecommunication', 'connection'],
    description: 'Telecommunications, high-speed broadband, leased lines, and mobile connections.',
  },
  {
    category: 'Advertising and marketing',
    primaryKeywords: [
      'google ads', 'meta ads', 'facebook ads', 'instagram ads', 'linkedin ads', 'hoarding',
      'billboard', 'marketing agency', 'seo services', 'pr agency', 'pamphlets', 'branding',
      'exhibition stall', 'digital marketing', 'sponsorship', 'ad campaign'
    ],
    secondaryKeywords: ['advertisement', 'promo', 'publicity', 'marketing', 'media'],
    description: 'Online and offline promotional campaigns, print ads, hoardings, and agency fees.',
  },
  {
    category: 'Insurance',
    primaryKeywords: [
      'general insurance', 'fire insurance', 'burglary insurance', 'marine insurance',
      'transit insurance', 'professional indemnity', 'directors liability', 'keyman insurance',
      'stock insurance', 'asset insurance', 'h वरिष्ठ', 'policy premium'
    ],
    secondaryKeywords: ['insurance premium', 'policy', 'underwriting', 'coverage'],
    description: 'Commercial and asset insurance policies protecting business risks.',
  },
  {
    category: 'Employee welfare',
    primaryKeywords: [
      'employee uniform', 'staff safety gear', 'team lunch', 'annual party', 'diwali gift',
      'employee health checkup', 'medical camp', 'first aid supplies', 'staff welfare',
      'team offsite', 'employee festival'
    ],
    secondaryKeywords: ['welfare', 'staff event', 'employee perk', 'safety kit'],
    description: 'Expenditures incurred on staff wellbeing, statutory safety, and events.',
  },
  {
    category: 'Club / fitness membership',
    primaryKeywords: [
      'gym membership', 'fitness club', 'country club', 'golf club membership', 'sports club',
      'cult.fit', 'gold gym', 'health club membership', 'club subscription'
    ],
    secondaryKeywords: ['gym', 'fitness', 'club', 'sports facility'],
    description: 'Recreational and health memberships for executives or staff.',
  },
  {
    category: 'Construction / civil works',
    primaryKeywords: [
      'civil construction', 'building construction', 'masonry works', 'brickwork', 'cement',
      'plumbing contractor', 'electrical wiring contractor', 'painting works', 'flooring tile work',
      'interior fitout', 'immovable property repair', 'works contract'
    ],
    secondaryKeywords: ['renovation', 'civil work', 'contractor', 'structural work', 'cement work'],
    description: 'Civil construction, structural renovation, and works contract on immovable property.',
  },
  {
    category: 'Personal expense',
    primaryKeywords: [
      'home grocery', 'personal clothing', 'family trip', 'school fees', 'tuition fees',
      'home utility bill', 'residential electricity', 'domestic maid', 'personal jewelry',
      'personal electronics', 'personal loan payment'
    ],
    secondaryKeywords: ['personal', 'domestic', 'household', 'private use'],
    description: 'Non-business personal consumption or family expenditure.',
  },
];

/**
 * Classifies an expense based on text entered in description and supplier name.
 */
export function classifyExpense(description: string, supplierName?: string): CategorySuggestion {
  const combinedText = `${description || ''} ${supplierName || ''}`.toLowerCase().trim();

  if (!combinedText) {
    return {
      category: 'Other',
      confidence: 'Low',
      matchedKeywords: [],
      explanation: 'No description provided. Defaulting to Other.',
    };
  }

  let bestCategory: ExpenseCategory = 'Other';
  let bestScore = 0;
  let bestMatchedKeywords: string[] = [];
  let bestDescription = '';

  for (const rule of CATEGORY_RULES) {
    let score = 0;
    const matches: string[] = [];

    // Check primary keywords (weight: 3)
    for (const kw of rule.primaryKeywords) {
      if (combinedText.includes(kw.toLowerCase())) {
        score += 3;
        matches.push(kw);
      }
    }

    // Check secondary keywords (weight: 1)
    for (const kw of rule.secondaryKeywords) {
      if (combinedText.includes(kw.toLowerCase())) {
        score += 1;
        matches.push(kw);
      }
    }

    if (score > bestScore) {
      bestScore = score;
      bestCategory = rule.category;
      bestMatchedKeywords = matches;
      bestDescription = rule.description;
    }
  }

  if (bestScore >= 3) {
    return {
      category: bestCategory,
      confidence: bestScore >= 6 ? 'High' : 'Medium',
      matchedKeywords: bestMatchedKeywords,
      explanation: `Suggested '${bestCategory}' based on keyword matches: [${bestMatchedKeywords.slice(0, 3).join(', ')}]. ${bestDescription}`,
    };
  }

  return {
    category: 'Other',
    confidence: 'Low',
    matchedKeywords: [],
    explanation: 'Could not confidently match a specific category keyword. Please select the most appropriate category.',
  };
}

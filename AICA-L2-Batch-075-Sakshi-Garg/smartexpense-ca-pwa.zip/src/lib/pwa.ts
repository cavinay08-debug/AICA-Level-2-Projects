/**
 * SmartExpense CA - PWA Lifecycle & Installation Manager
 */

export interface BeforeInstallPromptEvent extends Event {
  readonly platforms: string[];
  readonly userChoice: Promise<{
    outcome: 'accepted' | 'dismissed';
    platform: string;
  }>;
  prompt(): Promise<void>;
}

class PwaManager {
  private deferredPrompt: BeforeInstallPromptEvent | null = null;
  private isAppInstalled = false;
  private updateAvailable = false;
  private listeners: Array<() => void> = [];

  constructor() {
    if (typeof window !== 'undefined') {
      // Check standalone mode
      if (
        window.matchMedia('(display-mode: standalone)').matches ||
        (window.navigator as any).standalone === true
      ) {
        this.isAppInstalled = true;
      }

      window.addEventListener('beforeinstallprompt', (e) => {
        e.preventDefault();
        this.deferredPrompt = e as BeforeInstallPromptEvent;
        this.notifyListeners();
      });

      window.addEventListener('appinstalled', () => {
        this.isAppInstalled = true;
        this.deferredPrompt = null;
        this.notifyListeners();
      });
    }
  }

  public registerServiceWorker(): void {
    if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker
          .register('/sw.js')
          .then((registration) => {
            // Check for updates
            registration.addEventListener('updatefound', () => {
              const newWorker = registration.installing;
              if (newWorker) {
                newWorker.addEventListener('statechange', () => {
                  if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                    this.updateAvailable = true;
                    this.notifyListeners();
                  }
                });
              }
            });
          })
          .catch((err) => {
            console.log('SW registration skipped/failed:', err);
          });
      });
    }
  }

  public canInstall(): boolean {
    return !!this.deferredPrompt && !this.isAppInstalled;
  }

  public isInstalled(): boolean {
    return this.isAppInstalled;
  }

  public hasUpdate(): boolean {
    return this.updateAvailable;
  }

  public async triggerInstall(): Promise<boolean> {
    if (!this.deferredPrompt) {
      return false;
    }
    try {
      await this.deferredPrompt.prompt();
      const choice = await this.deferredPrompt.userChoice;
      if (choice.outcome === 'accepted') {
        this.deferredPrompt = null;
        this.notifyListeners();
        return true;
      }
    } catch (e) {
      console.error('Error triggering PWA install prompt', e);
    }
    return false;
  }

  public subscribe(callback: () => void): () => void {
    this.listeners.push(callback);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== callback);
    };
  }

  private notifyListeners(): void {
    this.listeners.forEach((cb) => cb());
  }
}

export const pwaManager = new PwaManager();

/**
 * SmartExpense CA - Deterministic GST Input Tax Credit (ITC) Rules Engine
 * 
 * Implements strict statutory evaluations according to the CGST Act 2017 & CGST Rules.
 * Source references are linked to LEGAL_SOURCES.md and CBIC official portals.
 */

import { DecisionTrailStep, ExpenseFormData, ItcDecision, ItcStatus } from '../types';
import { calculateDaysElapsed, getFinancialYearInfo, roundTwoDecimals, validateGstinFormat, validateTaxConsistency } from './gstUtils';

const CBIC_BASE_URL = 'https://cbic-gst.gov.in/';

/**
 * Main Deterministic Rules Engine Evaluator.
 * Takes user entered expense details and produces a structured, transparent compliance review.
 */
export function evaluateItcEligibility(formData: ExpenseFormData): ItcDecision {
  const decisionTrail: DecisionTrailStep[] = [];
  const flags: string[] = [];
  const totalGst = roundTwoDecimals((formData.cgstAmount || 0) + (formData.sgstAmount || 0) + (formData.igstAmount || 0) + (formData.cessAmount || 0));

  let overallStatus: ItcStatus = 'Eligible';
  let primaryReason = 'All statutory Section 16 conditions and documentary requirements are preliminarily satisfied.';
  let detailedReason = 'The expense is incurred for business furtherance, backed by a valid tax invoice, reflected in GSTR-2B, and does not fall under Section 17(5) blocked credit provisions.';
  let legalReference = 'CGST Act 2017 - Section 16(1) & 16(2)';
  let sourceUrl = `${CBIC_BASE_URL}cbec-portal-ui/openUrl?path=/pdf/cgst-act.pdf`;
  let recommendedAction = 'Preliminary eligibility confirmed. Proceed with standard GSTR-3B reconciliation and ledger posting.';

  // -------------------------------------------------------------
  // SECTION A: MANDATORY INFORMATION & FORMAT CHECKS
  // -------------------------------------------------------------

  const missingFields: string[] = [];
  if (!formData.invoiceNumber || formData.invoiceNumber.trim() === '') missingFields.push('Invoice Number');
  if (!formData.invoiceDate) missingFields.push('Invoice Date');
  if (!formData.supplierName || formData.supplierName.trim() === '') missingFields.push('Supplier Name');
  if (formData.taxableValue === undefined || formData.taxableValue <= 0) missingFields.push('Taxable Value (> 0)');

  if (missingFields.length > 0) {
    decisionTrail.push({
      stepCode: 'CHK_MANDATORY_FIELDS',
      stepName: 'Mandatory Information Check',
      status: 'review',
      finding: `Missing critical mandatory fields: ${missingFields.join(', ')}.`,
      statutoryReference: 'CGST Rules 2017 - Rule 36(2) (Mandatory particulars on invoice)',
      sourceUrl: CBIC_BASE_URL,
    });
    flags.push(`Incomplete Details: ${missingFields.join(', ')}`);
    overallStatus = 'CA Review Required';
    primaryReason = 'Insufficient information to assess ITC.';
    detailedReason = `Key statutory invoice details are missing: ${missingFields.join(', ')}. Complete invoice information is necessary before claiming ITC in GSTR-3B.`;
    recommendedAction = `Obtain and input the missing invoice details (${missingFields.join(', ')}) from the physical/digital supplier invoice.`;
  } else {
    decisionTrail.push({
      stepCode: 'CHK_MANDATORY_FIELDS',
      stepName: 'Mandatory Information Check',
      status: 'pass',
      finding: 'All primary invoice attributes are populated.',
      statutoryReference: 'CGST Rules 2017 - Rule 36(2)',
      sourceUrl: CBIC_BASE_URL,
    });
  }

  // Supplier GSTIN Format check
  if (formData.supplierGstin && formData.supplierGstin.trim() !== '') {
    const gstinCheck = validateGstinFormat(formData.supplierGstin);
    if (!gstinCheck.isValid) {
      decisionTrail.push({
        stepCode: 'CHK_GSTIN_FORMAT',
        stepName: 'Supplier GSTIN Validation',
        status: 'review',
        finding: `Supplier GSTIN format error: ${gstinCheck.message}`,
        statutoryReference: 'CGST Act 2017 - Section 25 & Rule 36(2)',
        sourceUrl: CBIC_BASE_URL,
      });
      flags.push('Invalid Supplier GSTIN Syntax');
      if ((overallStatus as ItcStatus) !== 'Ineligible') {
        overallStatus = 'CA Review Required';
        primaryReason = 'Invalid Supplier GSTIN format.';
        detailedReason = `The entered supplier GSTIN (${formData.supplierGstin}) fails standard format validation rules. Note: Format check does not verify active status on the portal.`;
        recommendedAction = 'Verify the supplier GSTIN on the official GST Portal (Services > Search Taxpayer) to confirm active registration and correct trade name.';
      }
    } else {
      decisionTrail.push({
        stepCode: 'CHK_GSTIN_FORMAT',
        stepName: 'Supplier GSTIN Validation',
        status: 'pass',
        finding: `Valid GSTIN syntax matching State: ${gstinCheck.stateName || 'Registered State'}. (Format check only)`,
        statutoryReference: 'CGST Act 2017 - Section 25',
        sourceUrl: CBIC_BASE_URL,
      });
    }
  } else {
    decisionTrail.push({
      stepCode: 'CHK_GSTIN_FORMAT',
      stepName: 'Supplier GSTIN Validation',
      status: 'review',
      finding: 'Supplier GSTIN is not provided (Unregistered supplier or missing).',
      statutoryReference: 'CGST Act 2017 - Section 16(2)(a)',
      sourceUrl: CBIC_BASE_URL,
    });
    flags.push('Missing Supplier GSTIN');
    if ((overallStatus as ItcStatus) !== 'Ineligible') {
      overallStatus = 'CA Review Required';
      primaryReason = 'Supplier GSTIN is missing.';
      detailedReason = 'ITC cannot be claimed on B2B invoices without a valid registered Supplier GSTIN unless subject to Reverse Charge Mechanism (RCM).';
      recommendedAction = 'Verify whether supplier is registered under GST. If registered, collect valid tax invoice with supplier GSTIN.';
    }
  }

  // Tax Split Consistency Check
  const taxCheck = validateTaxConsistency(
    formData.taxableValue,
    formData.cgstAmount,
    formData.sgstAmount,
    formData.igstAmount
  );
  if (!taxCheck.isValid) {
    decisionTrail.push({
      stepCode: 'CHK_TAX_SPLIT',
      stepName: 'Tax Component Consistency',
      status: 'fail',
      finding: taxCheck.error || 'Tax split is invalid.',
      statutoryReference: 'IGST Act 2017 - Section 5 & CGST Act - Section 9',
      sourceUrl: CBIC_BASE_URL,
    });
    flags.push('Invalid Tax Component Combination');
    overallStatus = 'CA Review Required';
    primaryReason = 'Conflicting tax components (IGST + CGST/SGST).';
    detailedReason = taxCheck.error || 'An invoice cannot have simultaneous IGST and CGST/SGST amounts.';
    recommendedAction = 'Correct the tax breakdown in the invoice entry according to the place of supply (Intra-state: CGST+SGST, Inter-state: IGST).';
  } else {
    decisionTrail.push({
      stepCode: 'CHK_TAX_SPLIT',
      stepName: 'Tax Component Consistency',
      status: 'pass',
      finding: 'Tax components conform to standard intra/inter-state rules.',
      statutoryReference: 'CGST Act Section 9 & IGST Act Section 5',
      sourceUrl: CBIC_BASE_URL,
    });
  }

  // -------------------------------------------------------------
  // SECTION B: SECTION 16 CORE CONDITIONS
  // -------------------------------------------------------------

  // 1. Possession of Valid Tax Invoice (Section 16(2)(a))
  if (formData.taxInvoiceAvailable === 'No') {
    decisionTrail.push({
      stepCode: 'CHK_SEC16_INVOICE_DOC',
      stepName: 'Possession of Tax Invoice / Debit Note',
      status: 'fail',
      finding: 'Registered person is not in possession of a valid tax invoice or debit note.',
      statutoryReference: 'CGST Act 2017 - Section 16(2)(a) read with Rule 36(1)',
      sourceUrl: CBIC_BASE_URL,
    });
    flags.push('No Tax Invoice in Possession');
    overallStatus = 'Ineligible';
    primaryReason = 'Tax invoice or debit note is not available.';
    detailedReason = 'Section 16(2)(a) explicitly mandates physical or digital possession of a valid tax invoice or debit note issued under Section 31 to claim ITC.';
    legalReference = 'CGST Act 2017 - Section 16(2)(a) & CGST Rules - Rule 36(1)';
    recommendedAction = 'Do not claim ITC in GSTR-3B until a valid tax invoice complying with Rule 46 is obtained from the vendor.';
  } else {
    decisionTrail.push({
      stepCode: 'CHK_SEC16_INVOICE_DOC',
      stepName: 'Possession of Tax Invoice / Debit Note',
      status: 'pass',
      finding: 'Valid tax invoice / debit note is in possession.',
      statutoryReference: 'CGST Act 2017 - Section 16(2)(a)',
      sourceUrl: CBIC_BASE_URL,
    });
  }

  // 2. Receipt of Goods / Services (Section 16(2)(b))
  if (formData.goodsServicesReceived === 'No') {
    decisionTrail.push({
      stepCode: 'CHK_SEC16_RECEIPT',
      stepName: 'Actual Receipt of Goods/Services',
      status: 'fail',
      finding: 'Goods or services have not been received.',
      statutoryReference: 'CGST Act 2017 - Section 16(2)(b)',
      sourceUrl: CBIC_BASE_URL,
    });
    flags.push('Goods/Services Not Received');
    overallStatus = 'Ineligible';
    primaryReason = 'Goods or services have not been received.';
    detailedReason = 'Under Section 16(2)(b), ITC cannot be claimed prior to actual receipt of goods or performance of services (subject to bill-to-ship-to deemed receipt).';
    legalReference = 'CGST Act 2017 - Section 16(2)(b)';
    recommendedAction = 'Defer ITC claim to the tax period in which goods or services are physically received or delivered.';
  } else if (formData.goodsServicesReceived === 'Not confirmed') {
    decisionTrail.push({
      stepCode: 'CHK_SEC16_RECEIPT',
      stepName: 'Actual Receipt of Goods/Services',
      status: 'review',
      finding: 'Receipt of goods/services is unconfirmed.',
      statutoryReference: 'CGST Act 2017 - Section 16(2)(b)',
      sourceUrl: CBIC_BASE_URL,
    });
    flags.push('Unconfirmed Receipt of Goods/Services');
    if (overallStatus !== 'Ineligible') {
      overallStatus = 'CA Review Required';
      primaryReason = 'Receipt of goods/services is not confirmed.';
      detailedReason = 'Section 16(2)(b) requires verification of delivery notes, goods receipt notes (GRN), or service completion reports before claiming credit.';
      recommendedAction = 'Verify Goods Receipt Note (GRN), transporter consignment note, or service acceptance sign-off before claiming.';
    }
  } else {
    decisionTrail.push({
      stepCode: 'CHK_SEC16_RECEIPT',
      stepName: 'Actual Receipt of Goods/Services',
      status: 'pass',
      finding: 'Goods / services confirmed as received.',
      statutoryReference: 'CGST Act 2017 - Section 16(2)(b)',
      sourceUrl: CBIC_BASE_URL,
    });
  }

  // 3. Business Use / Purpose (Section 16(1) & 17(1))
  if (formData.usedForBusiness === 'No' || formData.category === 'Personal expense') {
    decisionTrail.push({
      stepCode: 'CHK_SEC16_BUSINESS_USE',
      stepName: 'Business Furtherance & Non-Personal Use',
      status: 'fail',
      finding: 'Expense is purely personal or non-business.',
      statutoryReference: 'CGST Act 2017 - Section 16(1), Section 17(1) & Section 17(5)(g)',
      sourceUrl: CBIC_BASE_URL,
    });
    flags.push('Personal / Non-Business Expense');
    overallStatus = 'Ineligible';
    primaryReason = 'Non-business / personal expense.';
    detailedReason = 'ITC is strictly restricted to supplies used in the course or furtherance of business under Section 16(1). Section 17(5)(g) explicitly blocks credit for personal consumption.';
    legalReference = 'CGST Act 2017 - Section 16(1), 17(1) & 17(5)(g)';
    recommendedAction = 'Mark as ineligible in GSTR-3B Table 4(D)(2) or exclude from input tax credit ledger entirely.';
  } else if (formData.usedForBusiness === 'Partly') {
    decisionTrail.push({
      stepCode: 'CHK_SEC16_BUSINESS_USE',
      stepName: 'Business Furtherance & Non-Personal Use',
      status: 'review',
      finding: 'Expense is used partly for business and partly for personal purposes.',
      statutoryReference: 'CGST Act 2017 - Section 17(1) read with CGST Rules - Rule 42',
      sourceUrl: CBIC_BASE_URL,
    });
    flags.push('Mixed Business/Personal Use (Rule 42 Apportionment Required)');
    if (overallStatus !== 'Ineligible') {
      overallStatus = 'CA Review Required';
      primaryReason = 'Partly business and personal use.';
      detailedReason = 'Section 17(1) requires proportionate reversal of ITC attributable to personal or non-business use as prescribed under CGST Rule 42.';
      legalReference = 'CGST Act 2017 - Section 17(1) & CGST Rules - Rule 42';
      recommendedAction = 'Perform proportionate monthly credit apportionment under Rule 42. Ineligible portion must be reversed in GSTR-3B Table 4(B)(2).';
    }
  } else {
    decisionTrail.push({
      stepCode: 'CHK_SEC16_BUSINESS_USE',
      stepName: 'Business Furtherance & Non-Personal Use',
      status: 'pass',
      finding: 'Supply is confirmed for business furtherance.',
      statutoryReference: 'CGST Act 2017 - Section 16(1)',
      sourceUrl: CBIC_BASE_URL,
    });
  }

  // 4. Taxable vs Exempt Outward Supplies (Section 17(2))
  if (formData.usedForTaxableOutwardSupply === 'No') {
    decisionTrail.push({
      stepCode: 'CHK_SEC17_TAXABLE_OUTWARD',
      stepName: 'Outward Supply Characterization',
      status: 'fail',
      finding: 'Exclusively used for effecting exempt or non-taxable supplies.',
      statutoryReference: 'CGST Act 2017 - Section 17(2) read with Rule 42/43',
      sourceUrl: CBIC_BASE_URL,
    });
    flags.push('Exclusively for Exempt Outward Supply');
    overallStatus = 'Ineligible';
    primaryReason = 'Inward supply used exclusively for exempt supplies.';
    detailedReason = 'Section 17(2) restricts ITC where goods or services are used exclusively for effecting exempt supplies (including non-taxable and nil-rated supplies).';
    legalReference = 'CGST Act 2017 - Section 17(2)';
    recommendedAction = 'Reverse full ITC in GSTR-3B Table 4(B)(1) as ineligible under Section 17(2) / Rule 42.';
  } else if (formData.usedForTaxableOutwardSupply === 'Partly' || formData.usedForTaxableOutwardSupply === 'Not confirmed') {
    decisionTrail.push({
      stepCode: 'CHK_SEC17_TAXABLE_OUTWARD',
      stepName: 'Outward Supply Characterization',
      status: 'review',
      finding: `Used ${formData.usedForTaxableOutwardSupply === 'Partly' ? 'partly' : 'unconfirmed'} for taxable vs exempt outward supplies.`,
      statutoryReference: 'CGST Act 2017 - Section 17(2) read with Rule 42 (Inputs) & Rule 43 (Capital Goods)',
      sourceUrl: CBIC_BASE_URL,
    });
    flags.push('Common Credit (Rule 42/43 Apportionment Review)');
    if (overallStatus !== 'Ineligible') {
      overallStatus = 'CA Review Required';
      primaryReason = 'Common credit requiring turnover-based apportionment.';
      detailedReason = 'Section 17(2) mandates reversal of common credit in proportion to exempt turnover over total turnover for the tax period under Rule 42 (inputs) or Rule 43 (capital goods).';
      legalReference = 'CGST Act 2017 - Section 17(2) & CGST Rules - Rule 42/43';
      recommendedAction = 'Compute turnover ratio (Exempt Turnover / Total Turnover) for the tax period and reverse proportionate ITC in GSTR-3B Table 4(B)(1).';
    }
  } else {
    decisionTrail.push({
      stepCode: 'CHK_SEC17_TAXABLE_OUTWARD',
      stepName: 'Outward Supply Characterization',
      status: 'pass',
      finding: 'Used exclusively for taxable or zero-rated exports/SEZ supplies.',
      statutoryReference: 'CGST Act 2017 - Section 17(2)',
      sourceUrl: CBIC_BASE_URL,
    });
  }

  // 5. GSTR-2B Statement Reflection (Section 16(2)(aa) / 16(2)(ba))
  if (formData.reflectedInGstr2b === 'No' || formData.reflectedInGstr2b === 'Not checked') {
    decisionTrail.push({
      stepCode: 'CHK_SEC16_GSTR2B',
      stepName: 'GSTR-2B Auto-Drafted Statement Reflection',
      status: 'review',
      finding: `Invoice is ${formData.reflectedInGstr2b === 'No' ? 'NOT reflected' : 'NOT checked'} in auto-generated GSTR-2B.`,
      statutoryReference: 'CGST Act 2017 - Section 16(2)(aa)/(ba) & Section 38',
      sourceUrl: `${CBIC_BASE_URL}cbec-portal-ui/openUrl?path=/pdf/cgst-act.pdf`,
    });
    flags.push(`GSTR-2B Status: ${formData.reflectedInGstr2b}`);
    if (overallStatus !== 'Ineligible') {
      overallStatus = 'CA Review Required';
      primaryReason = 'Invoice not verified in GSTR-2B.';
      detailedReason = 'Under Section 16(2)(aa) and Section 38, ITC can only be availed if communicated in the auto-generated statement GSTR-2B. Note: This indicates a reconciliation requirement before filing, not an immediate permanent forfeiture.';
      legalReference = 'CGST Act 2017 - Section 16(2)(aa) & Section 38';
      recommendedAction = 'Reconcile purchase register against current GSTR-2B download. Follow up with vendor to file GSTR-1/IFF if missing.';
    }
  } else {
    decisionTrail.push({
      stepCode: 'CHK_SEC16_GSTR2B',
      stepName: 'GSTR-2B Auto-Drafted Statement Reflection',
      status: 'pass',
      finding: 'Invoice confirmed as reflected and matched in GSTR-2B.',
      statutoryReference: 'CGST Act 2017 - Section 16(2)(aa)',
      sourceUrl: CBIC_BASE_URL,
    });
  }

  // 6. 180-Day Supplier Payment Condition (Second Proviso to Sec 16(2) & Rule 37)
  if (formData.invoiceDate) {
    const elapsedDays = calculateDaysElapsed(formData.invoiceDate, formData.paymentDate);
    const isUnpaidOver180 = (formData.supplierPaymentStatus === 'Unpaid' || formData.supplierPaymentStatus === 'Partially paid') && elapsedDays > 180;

    if (isUnpaidOver180) {
      decisionTrail.push({
        stepCode: 'CHK_SEC16_180_DAYS',
        stepName: '180-Day Supplier Payment Rule',
        status: 'review',
        finding: `Invoice is unpaid/partially paid and ${elapsedDays} days have elapsed from invoice date (Threshold: 180 days).`,
        statutoryReference: 'Second Proviso to CGST Act Section 16(2) read with CGST Rules Rule 37',
        sourceUrl: CBIC_BASE_URL,
      });
      flags.push(`Unpaid > 180 Days (${elapsedDays} days elapsed)`);
      if (overallStatus !== 'Ineligible') {
        overallStatus = 'CA Review Required';
        primaryReason = 'Potential 180-day non-payment ITC reversal.';
        detailedReason = `Under the second proviso to Section 16(2) and Rule 37, where payment is not made within 180 days from the invoice date (${elapsedDays} days elapsed), the availed ITC must be reversed along with interest under Section 50. ITC can be re-availed upon actual payment.`;
        legalReference = 'CGST Act 2017 - Section 16(2) 2nd Proviso & Rule 37';
        recommendedAction = 'Verify accounts payable ledger. If unpaid beyond 180 days, reverse ITC in GSTR-3B Table 4(B)(2) and calculate interest under Section 50. Reclaim once paid.';
      }
    } else {
      decisionTrail.push({
        stepCode: 'CHK_SEC16_180_DAYS',
        stepName: '180-Day Supplier Payment Rule',
        status: 'pass',
        finding: formData.supplierPaymentStatus === 'Paid'
          ? 'Supplier is marked as fully paid.'
          : `Within 180-day payment window (${elapsedDays} days elapsed).`,
        statutoryReference: 'CGST Act Section 16(2) 2nd Proviso',
        sourceUrl: CBIC_BASE_URL,
      });
    }
  }

  // 7. Statutory Time-Limit (Section 16(4))
  if (formData.invoiceDate) {
    const fyInfo = getFinancialYearInfo(formData.invoiceDate);
    if (fyInfo.isDeadlinePassed) {
      decisionTrail.push({
        stepCode: 'CHK_SEC16_4_TIMELIMIT',
        stepName: 'Section 16(4) Statutory Time Limit',
        status: 'review',
        finding: `Invoice pertains to FY ${fyInfo.fyString}. Standard 30th November statutory deadline (${fyInfo.sec16_4Deadline}) has passed.`,
        statutoryReference: 'CGST Act 2017 - Section 16(4) (Amended via Finance Act 2022)',
        sourceUrl: CBIC_BASE_URL,
      });
      flags.push(`Section 16(4) Cutoff (${fyInfo.sec16_4Deadline}) Passed`);
      if (overallStatus !== 'Ineligible') {
        overallStatus = 'CA Review Required';
        primaryReason = 'Statutory ITC time limit (30th November) may have expired.';
        detailedReason = `Section 16(4) bars claiming ITC after 30th November following the end of financial year (${fyInfo.sec16_4Deadline}) or date of filing Annual Return (GSTR-9), whichever is earlier.`;
        legalReference = 'CGST Act 2017 - Section 16(4)';
        recommendedAction = 'Check whether the Annual Return for FY ' + fyInfo.fyString + ' was filed prior to 30th November and whether any court reliefs/circulars apply.';
      }
    } else {
      decisionTrail.push({
        stepCode: 'CHK_SEC16_4_TIMELIMIT',
        stepName: 'Section 16(4) Statutory Time Limit',
        status: 'pass',
        finding: `Pertains to FY ${fyInfo.fyString}. Within valid time-limit window (Cutoff: ${fyInfo.sec16_4Deadline}, ${fyInfo.daysToDeadline} days remaining).`,
        statutoryReference: 'CGST Act 2017 - Section 16(4)',
        sourceUrl: CBIC_BASE_URL,
      });
    }
  }

  // -------------------------------------------------------------
  // SECTION C: SECTION 17(5) BLOCKED CREDITS & STATUTORY EXCEPTIONS
  // -------------------------------------------------------------

  const category = formData.category;
  const exception = formData.specialException;

  // 1. Food and Beverages / Outdoor Catering (Section 17(5)(b)(i))
  if (category === 'Food and beverages') {
    if (exception === 'Further supply of same category') {
      decisionTrail.push({
        stepCode: 'CHK_SEC17_5_FOOD',
        stepName: 'Food & Beverages Blocked Credit Check',
        status: 'review',
        finding: 'Exception claimed: Inward supply used for outward taxable supply of same category or composite catering.',
        statutoryReference: 'CGST Act 2017 - Section 17(5)(b)(i) proviso',
        sourceUrl: CBIC_BASE_URL,
      });
      flags.push('Food & Beverages: Outward Supply Exception Claimed');
      if (overallStatus !== 'Ineligible') {
        overallStatus = 'CA Review Required';
        primaryReason = 'Food & beverage credit subject to outward supply exception verification.';
        detailedReason = 'ITC on food/beverages is generally blocked under Section 17(5)(b)(i) unless used for making an outward taxable supply of the same category or as an element of composite catering/event supply.';
        legalReference = 'CGST Act 2017 - Section 17(5)(b)(i)';
        recommendedAction = 'Verify sales invoices and client contracts to confirm that food/catering was billed outwards as a taxable composite supply.';
      }
    } else {
      decisionTrail.push({
        stepCode: 'CHK_SEC17_5_FOOD',
        stepName: 'Food & Beverages Blocked Credit Check',
        status: 'fail',
        finding: 'Blocked credit: Food, beverages, restaurant dining, or catering without statutory exception.',
        statutoryReference: 'CGST Act 2017 - Section 17(5)(b)(i)',
        sourceUrl: CBIC_BASE_URL,
      });
      flags.push('Blocked Credit under Section 17(5)(b)(i)');
      overallStatus = 'Ineligible';
      primaryReason = 'Blocked credit on Food & Beverages (Section 17(5)(b)(i)).';
      detailedReason = 'Input tax credit on food and beverages, outdoor catering, beauty treatment, and health services is explicitly blocked under Section 17(5)(b)(i) unless provided as an outward taxable supply.';
      legalReference = 'CGST Act 2017 - Section 17(5)(b)(i)';
      recommendedAction = 'Report in GSTR-3B Table 4(D)(1) as Ineligible ITC under Section 17(5). Do not claim in eligible ITC pool.';
    }
  }

  // 2. Motor Vehicles / Passenger Vehicles (Section 17(5)(a))
  if (category === 'Motor vehicle / car expenses') {
    const validVehicleExceptions = ['Further supply of same category', 'Passenger transport', 'Driving training'];
    if (validVehicleExceptions.includes(exception)) {
      decisionTrail.push({
        stepCode: 'CHK_SEC17_5_VEHICLE',
        stepName: 'Motor Vehicle Blocked Credit Check',
        status: 'review',
        finding: `Exception claimed: Vehicle used for ${exception.toLowerCase()}.`,
        statutoryReference: 'CGST Act 2017 - Section 17(5)(a)(A)-(C)',
        sourceUrl: CBIC_BASE_URL,
      });
      flags.push(`Motor Vehicle Exception: ${exception}`);
      if (overallStatus !== 'Ineligible') {
        overallStatus = 'CA Review Required';
        primaryReason = `Motor vehicle expense subject to '${exception}' exception verification.`;
        detailedReason = 'ITC on passenger motor vehicles (seating capacity <= 13) is blocked unless used for further supply of vehicles, passenger transport business, or imparting driving training under Section 17(5)(a).';
        legalReference = 'CGST Act 2017 - Section 17(5)(a)';
        recommendedAction = 'Inspect vehicle registration certificate (RC), permit type (commercial vs private), and business license to validate statutory exception.';
      }
    } else {
      decisionTrail.push({
        stepCode: 'CHK_SEC17_5_VEHICLE',
        stepName: 'Motor Vehicle Blocked Credit Check',
        status: 'fail',
        finding: 'Blocked credit: Passenger motor vehicle repair, servicing, or fueling with <= 13 seating capacity without qualifying commercial exception.',
        statutoryReference: 'CGST Act 2017 - Section 17(5)(a) & 17(5)(ab)',
        sourceUrl: CBIC_BASE_URL,
      });
      flags.push('Blocked Motor Vehicle Credit under Section 17(5)(a)');
      overallStatus = 'Ineligible';
      primaryReason = 'Blocked credit on Motor Vehicles (Section 17(5)(a)).';
      detailedReason = 'Under Section 17(5)(a) and 17(5)(ab), ITC on motor vehicles for transportation of persons (seating capacity <= 13) and related insurance, servicing, and repair is blocked unless used for qualifying commercial activities.';
      legalReference = 'CGST Act 2017 - Section 17(5)(a) & 17(5)(ab)';
      recommendedAction = 'Report as blocked credit in GSTR-3B Table 4(D)(1). Do not claim.';
    }
  }

  // 3. Club / Fitness Memberships (Section 17(5)(b)(ii))
  if (category === 'Club / fitness membership') {
    decisionTrail.push({
      stepCode: 'CHK_SEC17_5_CLUB',
      stepName: 'Club / Fitness Membership Check',
      status: 'fail',
      finding: 'Blocked credit: Membership of a club, health, and fitness centre is strictly non-creditable.',
      statutoryReference: 'CGST Act 2017 - Section 17(5)(b)(ii)',
      sourceUrl: CBIC_BASE_URL,
    });
    flags.push('Blocked Credit under Section 17(5)(b)(ii)');
    overallStatus = 'Ineligible';
    primaryReason = 'Blocked credit on Club / Fitness Memberships (Section 17(5)(b)(ii)).';
    detailedReason = 'Section 17(5)(b)(ii) strictly blocks ITC on membership fees for clubs, gyms, health, and fitness centres regardless of business justification.';
    legalReference = 'CGST Act 2017 - Section 17(5)(b)(ii)';
    recommendedAction = 'Disallow credit and classify under GSTR-3B Table 4(D)(1).';
  }

  // 4. Employee Welfare & Statutory Obligation (Section 17(5)(b)(iii)/(iv))
  if (category === 'Employee welfare') {
    if (exception === 'Statutory employer obligation') {
      decisionTrail.push({
        stepCode: 'CHK_SEC17_5_WELFARE',
        stepName: 'Employee Welfare Blocked Credit Check',
        status: 'review',
        finding: 'Exception claimed: Supply is obligatory for employer to provide under statutory law.',
        statutoryReference: 'Proviso to CGST Act Section 17(5)(b)',
        sourceUrl: CBIC_BASE_URL,
      });
      flags.push('Employee Welfare: Statutory Employer Obligation Exception');
      if (overallStatus !== 'Ineligible') {
        overallStatus = 'CA Review Required';
        primaryReason = 'Employee welfare credit subject to statutory obligation verification.';
        detailedReason = 'Under the proviso to Section 17(5)(b), ITC on employee welfare/insurance/cabs is allowed ONLY IF it is obligatory for the employer to provide it under a specific statutory law (e.g. Factories Act 1948 mandatory canteen/safety or statutory night shift drop).';
        legalReference = 'Proviso to CGST Act 2017 - Section 17(5)(b)';
        recommendedAction = 'Document the specific statutory provision (e.g., Factories Act 1948, state industrial standing orders) mandating this provision to employees.';
      }
    } else {
      decisionTrail.push({
        stepCode: 'CHK_SEC17_5_WELFARE',
        stepName: 'Employee Welfare Blocked Credit Check',
        status: 'review',
        finding: 'Employee welfare expenses, gifts, and recreational events require scrutiny for non-business perks or statutory exemptions.',
        statutoryReference: 'CGST Act 2017 - Section 17(5)(b) & Section 17(5)(h)',
        sourceUrl: CBIC_BASE_URL,
      });
      flags.push('Employee Welfare Review Required');
      if (overallStatus !== 'Ineligible') {
        overallStatus = 'CA Review Required';
        primaryReason = 'Employee welfare requires CA factual verification.';
        detailedReason = 'Gifts to employees exceeding statutory limits, personal benefits, or recreational club expenses may be blocked under Section 17(5)(b) or 17(5)(h).';
        legalReference = 'CGST Act 2017 - Section 17(5)(b)';
        recommendedAction = 'Verify whether expense represents statutory worker safety/protective gear (eligible) vs employee personal gifts/recreation (blocked).';
      }
    }
  }

  // 5. Construction / Works Contract on Immovable Property (Section 17(5)(c) & 17(5)(d))
  if (category === 'Construction / civil works') {
    if (exception === 'Further supply of same category') {
      decisionTrail.push({
        stepCode: 'CHK_SEC17_5_WORKS_CONTRACT',
        stepName: 'Works Contract & Construction Check',
        status: 'review',
        finding: 'Exception claimed: Works contract service used as input for further works contract service.',
        statutoryReference: 'CGST Act 2017 - Section 17(5)(c) proviso',
        sourceUrl: CBIC_BASE_URL,
      });
      flags.push('Works Contract: Sub-contracting Exception Claimed');
      if (overallStatus !== 'Ineligible') {
        overallStatus = 'CA Review Required';
        primaryReason = 'Works contract credit subject to sub-contracting verification.';
        detailedReason = 'ITC on works contract for immovable property is blocked unless it is an input service for further supply of works contract service or for plant and machinery.';
        legalReference = 'CGST Act 2017 - Section 17(5)(c)';
        recommendedAction = 'Verify main works contract agreement and client billing to prove that inward service is directly utilized for executing an outward works contract.';
      }
    } else {
      decisionTrail.push({
        stepCode: 'CHK_SEC17_5_WORKS_CONTRACT',
        stepName: 'Works Contract & Construction Check',
        status: 'review',
        finding: 'Construction on immovable property requires verification of capitalization vs revenue repair, or plant and machinery exclusion.',
        statutoryReference: 'CGST Act 2017 - Section 17(5)(c) & 17(5)(d)',
        sourceUrl: CBIC_BASE_URL,
      });
      flags.push('Civil Construction / Immovable Property Capitalization Check');
      if (overallStatus !== 'Ineligible') {
        overallStatus = 'CA Review Required';
        primaryReason = 'Construction on immovable property requires CA capitalization review.';
        detailedReason = 'Under Section 17(5)(c) and 17(5)(d), ITC is blocked on goods/services for construction of immovable property to the extent capitalized in books, unless constructing plant & machinery.';
        legalReference = 'CGST Act 2017 - Section 17(5)(c) & 17(5)(d)';
        recommendedAction = 'Inspect financial accounts: If charged to Profit & Loss as routine repair/maintenance, credit is generally eligible; if capitalized to building asset account, credit is strictly blocked.';
      }
    }
  }

  // 6. Capital Goods (Rule 43 Review)
  if (category === 'Capital goods') {
    decisionTrail.push({
      stepCode: 'CHK_CAPITAL_GOODS_DEPRECIATION',
      stepName: 'Capital Goods & Income Tax Depreciation Check',
      status: 'review',
      finding: 'Capital asset: Ensure no double-benefit (Depreciation on GST component under Income Tax Act Section 32).',
      statutoryReference: 'CGST Act 2017 - Section 16(3) & CGST Rules - Rule 43',
      sourceUrl: CBIC_BASE_URL,
    });
    flags.push('Capital Goods: Section 16(3) Depreciation Rule Check');
    if (overallStatus === 'Eligible') {
      // Eligible, but add high-priority CA note regarding Section 16(3)
      detailedReason = 'Preliminary eligibility confirmed. Note: Ensure income tax depreciation is claimed ONLY on base cost, not on the GST component (Section 16(3)).';
      recommendedAction = 'Confirm in fixed asset register that GST is not capitalized for Income Tax depreciation purposes.';
    }
  }

  // -------------------------------------------------------------
  // SECTION D: FINAL STATUS REFINEMENT & ALLOCATION AMOUNTS
  // -------------------------------------------------------------

  if (overallStatus === 'Eligible') {
    primaryReason = 'Preliminary eligibility confirmed.';
    detailedReason = 'Preliminary eligibility result—final claim remains subject to verification and applicable GST law.';
    legalReference = 'CGST Act 2017 - Section 16(1) & 16(2)';
    recommendedAction = 'Eligible to claim in GSTR-3B Table 4(A)(5) (All other ITC) or Table 4(A)(4) (Inputs/Capital goods) during the monthly return cycle.';
  }

  const eligibleAmount = overallStatus === 'Eligible' ? totalGst : 0;
  const blockedAmount = overallStatus === 'Ineligible' ? totalGst : 0;
  const reviewAmount = overallStatus === 'CA Review Required' ? totalGst : 0;

  return {
    status: overallStatus,
    primaryReason,
    detailedReason,
    legalReference,
    sourceUrl,
    recommendedAction,
    decisionTrail,
    flags,
    eligibleAmount,
    blockedAmount,
    reviewAmount,
  };
}

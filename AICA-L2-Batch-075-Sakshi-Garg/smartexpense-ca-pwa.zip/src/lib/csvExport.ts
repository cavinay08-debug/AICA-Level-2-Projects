/**
 * SmartExpense CA - CSV Export Utilities
 * Generates structured, standard CSV reports for Expense Registers and GST ITC Compliance Audits.
 */

import { Expense } from '../types';
import { formatDateDDMMYYYY, roundTwoDecimals } from './gstUtils';

/**
 * Escapes CSV special characters and quotes.
 */
function escapeCsv(value: string | number | undefined | null): string {
  if (value === undefined || value === null) return '""';
  const str = String(value).replace(/"/g, '""');
  return `"${str}"`;
}

/**
 * Exports the full Expense Register as a downloadable CSV file.
 */
export function exportExpenseRegisterCsv(expenses: Expense[], fileName = 'SmartExpense_CA_GST_Register.csv'): void {
  const headers = [
    'Invoice Number',
    'Invoice Date (DD/MM/YYYY)',
    'Supplier Name',
    'Supplier GSTIN',
    'Recipient GSTIN',
    'Category',
    'Description',
    'Taxable Value (INR)',
    'CGST (INR)',
    'SGST (INR)',
    'IGST (INR)',
    'Cess (INR)',
    'Total GST (INR)',
    'Total Invoice Amount (INR)',
    'Payment Status',
    'Payment Date',
    'Goods/Services Received',
    'Tax Invoice Available',
    'Reflected in GSTR-2B',
    'Business Use',
    'Taxable Outward Supply',
    'Special Exception',
    'ITC Status',
    'Primary Statutory Reason',
    'Legal Reference',
    'Recommended Action',
    'Flags',
    'Notes',
  ];

  const rows = expenses.map((exp) => [
    escapeCsv(exp.invoiceNumber),
    escapeCsv(formatDateDDMMYYYY(exp.invoiceDate)),
    escapeCsv(exp.supplierName),
    escapeCsv(exp.supplierGstin),
    escapeCsv(exp.recipientGstin),
    escapeCsv(exp.category),
    escapeCsv(exp.description),
    escapeCsv(roundTwoDecimals(exp.taxableValue)),
    escapeCsv(roundTwoDecimals(exp.cgstAmount)),
    escapeCsv(roundTwoDecimals(exp.sgstAmount)),
    escapeCsv(roundTwoDecimals(exp.igstAmount)),
    escapeCsv(roundTwoDecimals(exp.cessAmount)),
    escapeCsv(roundTwoDecimals(exp.totalGst)),
    escapeCsv(roundTwoDecimals(exp.totalAmount)),
    escapeCsv(exp.supplierPaymentStatus),
    escapeCsv(exp.paymentDate ? formatDateDDMMYYYY(exp.paymentDate) : '-'),
    escapeCsv(exp.goodsServicesReceived),
    escapeCsv(exp.taxInvoiceAvailable),
    escapeCsv(exp.reflectedInGstr2b),
    escapeCsv(exp.usedForBusiness),
    escapeCsv(exp.usedForTaxableOutwardSupply),
    escapeCsv(exp.specialException),
    escapeCsv(exp.itcDecision.status),
    escapeCsv(exp.itcDecision.primaryReason),
    escapeCsv(exp.itcDecision.legalReference),
    escapeCsv(exp.itcDecision.recommendedAction),
    escapeCsv(exp.itcDecision.flags.join('; ')),
    escapeCsv(exp.notes || ''),
  ]);

  const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\r\n');
  downloadBlob(csvContent, fileName, 'text/csv;charset=utf-8;');
}

/**
 * Exports an executive GST ITC Audit Summary CSV.
 */
export function exportItcSummaryCsv(expenses: Expense[], fileName = 'SmartExpense_CA_ITC_Summary.csv'): void {
  const totalTaxable = roundTwoDecimals(expenses.reduce((s, e) => s + e.taxableValue, 0));
  const totalGst = roundTwoDecimals(expenses.reduce((s, e) => s + e.totalGst, 0));
  const eligibleItc = roundTwoDecimals(expenses.filter((e) => e.itcDecision.status === 'Eligible').reduce((s, e) => s + e.totalGst, 0));
  const ineligibleItc = roundTwoDecimals(expenses.filter((e) => e.itcDecision.status === 'Ineligible').reduce((s, e) => s + e.totalGst, 0));
  const reviewItc = roundTwoDecimals(expenses.filter((e) => e.itcDecision.status === 'CA Review Required').reduce((s, e) => s + e.totalGst, 0));

  const content = [
    'SmartExpense CA - GST ITC Audit Summary Report',
    `"Generated On","${formatDateDDMMYYYY(new Date())}"`,
    `"Law Verified As Of","17 August 2026"`,
    `"Disclaimer","Educational & professional assistance project. Does not replace formal statutory audit or GST Portal reconciliation."`,
    '',
    'EXECUTIVE METRICS (INR),AMOUNT (INR),RECORD COUNT',
    `"Total Taxable Value",${totalTaxable},${expenses.length}`,
    `"Total GST Incurred",${totalGst},${expenses.length}`,
    `"Potentially Eligible ITC (GSTR-3B Table 4(A))",${eligibleItc},${expenses.filter((e) => e.itcDecision.status === 'Eligible').length}`,
    `"Ineligible / Blocked ITC (Section 17(5) / 17(1))",${ineligibleItc},${expenses.filter((e) => e.itcDecision.status === 'Ineligible').length}`,
    `"CA Review Required (Rule 37 / Rule 42 / Unverified)",${reviewItc},${expenses.filter((e) => e.itcDecision.status === 'CA Review Required').length}`,
    '',
    'CATEGORY WISE BREAKDOWN',
    'Category,Record Count,Taxable Value (INR),GST Incurred (INR),Eligible ITC (INR),Ineligible ITC (INR),Review ITC (INR)',
  ];

  const categories = Array.from(new Set(expenses.map((e) => e.category)));
  for (const cat of categories) {
    const catExpenses = expenses.filter((e) => e.category === cat);
    const catTaxable = roundTwoDecimals(catExpenses.reduce((s, e) => s + e.taxableValue, 0));
    const catGst = roundTwoDecimals(catExpenses.reduce((s, e) => s + e.totalGst, 0));
    const catEligible = roundTwoDecimals(catExpenses.filter((e) => e.itcDecision.status === 'Eligible').reduce((s, e) => s + e.totalGst, 0));
    const catIneligible = roundTwoDecimals(catExpenses.filter((e) => e.itcDecision.status === 'Ineligible').reduce((s, e) => s + e.totalGst, 0));
    const catReview = roundTwoDecimals(catExpenses.filter((e) => e.itcDecision.status === 'CA Review Required').reduce((s, e) => s + e.totalGst, 0));

    content.push(
      `${escapeCsv(cat)},${catExpenses.length},${catTaxable},${catGst},${catEligible},${catIneligible},${catReview}`
    );
  }

  downloadBlob(content.join('\r\n'), fileName, 'text/csv;charset=utf-8;');
}

function downloadBlob(content: string, filename: string, mimeType: string): void {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

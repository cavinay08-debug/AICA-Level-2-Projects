# Payroll Auditor — desktop build

React + Vite renderer wrapped in Electron, packaged as a portable Windows `.exe`.

## Prerequisites
Node.js 18 or later. Build the Windows executable on Windows — cross-building
from Linux or macOS needs Wine and is not worth the trouble.

## Setup

    npm install

## Run in development
Hot reload, DevTools open in a detached window.

    npm run electron:dev

## Run as a plain web app
No Electron involved. Useful for checking the UI quickly.

    npm run dev          # http://localhost:5173
    npm run build        # static files in dist/, deployable to any host

## Build the executable

    npm run dist         # release/Payroll Auditor.exe  — single portable file
    npm run dist:installer   # release/  — NSIS installer with a directory choice

`portable` produces one self-contained file that runs with no installation, the
same shape as the Commodity Arbitrage build. `nsis` produces a conventional
installer if you want Start Menu entries and an uninstaller.

## What lives where

    electron/main.cjs     window, download-save dialog, external link handling
    electron/preload.cjs  contextBridge surface — empty until you need native APIs
    src/App.jsx           the audit engine, rules, and the entire UI
    src/main.jsx          React mount plus locally bundled IBM Plex fonts
    vite.config.js        base "./" so the bundle loads over file://

## Notes before you ship this

Fonts are bundled rather than pulled from Google Fonts, so the app renders
correctly with no network.

The audit engine currently runs in the renderer. That is fine while the rules
live in one file. Once the statutory parameters become a real database with
state, zone and scheduled-employment variants, move the engine and the rules
store into the main process and expose it over `contextBridge` — the preload
file is already set up for that.

Nothing is persisted between sessions. Imported registers and edited parameters
are lost on close. Add `electron-store` or SQLite in the main process when you
want that.

Statutory rates in the rules engine are placeholders and must be replaced with
the notifications in force before this is used on real payroll.

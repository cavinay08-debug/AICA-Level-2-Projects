/* ============================================================================
   AUDIT ENGINE — statutory parameters, wage computation, compliance rules,
   and the salary structure optimiser.

   Wage basis: Code on Wages, 2019 s.2(y) as in force from 21 November 2025.
   The same definition is carried into the Code on Social Security, 2020
   s.2(88), so PF, ESI, gratuity and bonus all compute off one wage figure.
   ========================================================================== */

export const DEFAULT_PARAMS = {
  period: "March 2026",
  periodMonth: 3,
  state: "Maharashtra",
  establishment: "Sample Industries Pvt. Ltd.",
  location: "Nagpur",
  estSize: 420,

  // --- wage definition -----------------------------------------------------
  wageFloorPct: 50,          // first proviso to s.2(y)
  includeErPfInRemuneration: true,   // MoLE FAQ 16.03.2026 — in the denominator
  includeBonusInRemuneration: true,  // statutory bonus — in the denominator
  includeOtInRemuneration: true,     // overtime is an excluded component (a)-(i)

  // --- provident fund ------------------------------------------------------
  pfCeiling: 15000,
  pfRateEmployee: 12,
  pfRateEmployer: 12,
  epsCap: 1250,

  // --- employees' state insurance -----------------------------------------
  esicWageLimit: 21000,
  esicWageLimitDisability: 25000,
  esicRateEmployee: 0.75,
  esicRateEmployer: 3.25,
  esicBase: "code",          // "code" = SS Code wages | "gross" = legacy gross
  esicPeriodEndMonths: [3, 9], // contribution periods Apr-Sep and Oct-Mar

  // --- bonus, gratuity -----------------------------------------------------
  bonusEligibilityWage: 21000,
  bonusCalcCeiling: 7000,
  bonusMinPct: 8.33,
  bonusMaxPct: 20,
  gratuityMinYears: 5,
  gratuityFixedTermProRata: true, // SS Code — no five-year bar for fixed term

  // --- hours, deductions, payment -----------------------------------------
  otMultiplier: 2,
  otQuarterCapHours: 125,
  standardHoursPerDay: 8,
  deductionCapPct: 50,
  wagePayByDay: 7,

  // --- state levies --------------------------------------------------------
  // upto: null means "and above". Infinity must never be used here — it
  // serialises to null through JSON and silently loses the cap on reload.
  ptSlabs: [
    { upto: 7500, amt: 0 },
    { upto: 10000, amt: 175 },
    { upto: null, amt: 200 },
  ],
  ptWomenExemptUpto: 25000,
  lwfEmployee: 25,
  lwfEmployer: 75,

  minWage: {
    I: { unskilled: 13500, semiskilled: 14500, skilled: 15800 },
    II: { unskilled: 12600, semiskilled: 13500, skilled: 14700 },
    III: { unskilled: 11800, semiskilled: 12700, skilled: 13800 },
  },
};

/* --------------------------------------------------------------------------
   Sample register. Replaceable through CSV import.
   -------------------------------------------------------------------------- */

export const E = (o) => ({
  daysInMonth: 26, otHours: 0, otPaid: 0, conveyance: 0, otherAllow: 0,
  retaining: 0, advance: 0, otherDed: 0, tds: 0, lwf: 0, bonusPaidYtd: 0,
  bankCredited: true, uan: "", esicNo: "", prevCovered: false,
  disability: false, ...o,
});

export const REGISTER = [
  E({ id: "EMP-0104", name: "Ramesh Pawar", gender: "M", dept: "Production", desig: "Machine Operator", skill: "skilled", zone: "I", doj: "2016-06-01", type: "Permanent", daysPresent: 26, basic: 12000, da: 4000, hra: 6400, special: 5600, otHours: 20, otPaid: 3077, pfEmp: 1800, pfEr: 1800, esicEmp: 0, pt: 200, creditDay: 5, bonusPaidYtd: 15800 , uan: "100234567801", esicNo: "3113456701" }),
  E({ id: "EMP-0118", name: "Sunita Kadam", gender: "F", dept: "Production", desig: "Machine Operator", skill: "skilled", zone: "I", doj: "2017-02-14", type: "Permanent", daysPresent: 26, basic: 10500, da: 3500, hra: 5600, special: 4900, pfEmp: 1680, pfEr: 1680, esicEmp: 0, pt: 0, creditDay: 5, bonusPaidYtd: 14000 , uan: "100234567802", esicNo: "3113456702" }),
  E({ id: "EMP-0231", name: "Ajay Kulkarni", gender: "M", dept: "Packing", desig: "Helper", skill: "unskilled", zone: "I", doj: "2023-08-01", type: "Fixed Term", daysPresent: 26, basic: 9000, da: 4500, hra: 5400, special: 4600, pfEmp: 1080, pfEr: 1080, esicEmp: 0, pt: 200, creditDay: 6, bonusPaidYtd: 13500, prevCovered: true , uan: "", esicNo: "3113456703" }),
  E({ id: "EMP-0244", name: "Farhan Shaikh", gender: "M", dept: "Packing", desig: "Helper", skill: "unskilled", zone: "I", doj: "2024-01-15", type: "Fixed Term", daysPresent: 24, basic: 7500, da: 3000, hra: 4200, special: 3300, pfEmp: 1260, pfEr: 1260, esicEmp: 135, pt: 200, creditDay: 6, bonusPaidYtd: 10500, bankCredited: false , uan: "100234567804", esicNo: "3113456704" }),
  E({ id: "EMP-0301", name: "Priya Deshmukh", gender: "F", dept: "Quality", desig: "QA Inspector", skill: "skilled", zone: "I", doj: "2019-04-01", type: "Permanent", daysPresent: 26, basic: 16000, da: 4000, hra: 8000, special: 8000, pfEmp: 1800, pfEr: 1800, esicEmp: 0, pt: 200, creditDay: 5, bonusPaidYtd: 15800 , uan: "100234567805", esicNo: "3113456705" }),
  E({ id: "EMP-0312", name: "Nikhil Rane", gender: "M", dept: "Quality", desig: "QA Inspector", skill: "skilled", zone: "I", doj: "2019-07-22", type: "Permanent", daysPresent: 26, basic: 16800, da: 4200, hra: 8400, special: 8400, pfEmp: 1800, pfEr: 1800, esicEmp: 0, pt: 200, creditDay: 5, bonusPaidYtd: 15800 , uan: "100234567806", esicNo: "3113456706" }),
  E({ id: "EMP-0355", name: "Mangesh Tayde", gender: "M", dept: "Maintenance", desig: "Fitter", skill: "skilled", zone: "II", doj: "2014-11-03", type: "Permanent", daysPresent: 26, basic: 11000, da: 3800, hra: 5920, special: 5080, otHours: 46, otPaid: 4400, pfEmp: 1776, pfEr: 1776, esicEmp: 0, pt: 200, creditDay: 5, bonusPaidYtd: 14700 , uan: "100234567807", esicNo: "3113456707" }),
  E({ id: "EMP-0361", name: "Sameer Joshi", gender: "M", dept: "Maintenance", desig: "Electrician", skill: "skilled", zone: "II", doj: "2021-07-10", type: "Permanent", daysPresent: 25, basic: 11000, da: 3600, hra: 5840, special: 5060, pfEmp: 1752, pfEr: 1752, esicEmp: 0, pt: 200, advance: 6000, otherDed: 6500, creditDay: 11, bonusPaidYtd: 14600 , uan: "100234567808", esicNo: "3113456708" }),
  E({ id: "EMP-0402", name: "Vaishali More", gender: "F", dept: "Stores", desig: "Store Assistant", skill: "semiskilled", zone: "I", doj: "2022-09-05", type: "Permanent", daysPresent: 26, basic: 11000, da: 3700, hra: 3400, special: 1900, pfEmp: 1764, pfEr: 1764, esicEmp: 0, pt: 0, creditDay: 5, bonusPaidYtd: 14500 , uan: "100234567809", esicNo: "3113456709" }),
  E({ id: "EMP-0417", name: "Imran Qureshi", gender: "M", dept: "Stores", desig: "Store Assistant", skill: "semiskilled", zone: "I", doj: "2023-02-20", type: "Permanent", daysPresent: 26, basic: 11200, da: 3800, hra: 3450, special: 1750, pfEmp: 1800, pfEr: 1800, esicEmp: 113, pt: 175, creditDay: 5, bonusPaidYtd: 14500 , uan: "100234567810", esicNo: "" }),
  E({ id: "EMP-0503", name: "Anjali Bhosale", gender: "F", dept: "Administration", desig: "HR Executive", skill: "skilled", zone: "I", doj: "2020-06-15", type: "Permanent", daysPresent: 26, basic: 18000, da: 0, hra: 9000, special: 15000, pfEmp: 1800, pfEr: 1800, esicEmp: 0, pt: 200, creditDay: 5, bonusPaidYtd: 15800 , uan: "100234567811", esicNo: "3113456711" }),
  E({ id: "EMP-0511", name: "Rohit Ingle", gender: "M", dept: "Administration", desig: "Accounts Executive", skill: "skilled", zone: "I", doj: "2018-01-08", type: "Permanent", daysPresent: 26, basic: 14000, da: 0, hra: 6500, special: 19500, pfEmp: 1800, pfEr: 1800, esicEmp: 0, pt: 200, creditDay: 5, bonusPaidYtd: 0 , uan: "100234567812", esicNo: "3113456712" }),
  E({ id: "EMP-0620", name: "Kavita Sarode", gender: "F", dept: "Housekeeping", desig: "Attendant", skill: "unskilled", zone: "III", doj: "2024-11-01", type: "Fixed Term", daysPresent: 23, basic: 6800, da: 2200, hra: 2700, special: 1300, pfEmp: 1080, pfEr: 1080, esicEmp: 68, pt: 0, creditDay: 14, bonusPaidYtd: 0, bankCredited: false , uan: "", esicNo: "3113456713" }),
  E({ id: "EMP-0634", name: "Deepak Wankhede", gender: "M", dept: "Housekeeping", desig: "Attendant", skill: "unskilled", zone: "III", doj: "2023-05-19", type: "Permanent", daysPresent: 27, basic: 8200, da: 3800, hra: 3000, special: 2000, pfEmp: 1440, pfEr: 1440, esicEmp: 90, pt: 0, creditDay: 14, bonusPaidYtd: 11800 , uan: "100234567814", esicNo: "3113456714" }),
  E({ id: "EMP-0701", name: "Sagar Bawankar", gender: "M", dept: "Production", desig: "Trade Apprentice", skill: "unskilled", zone: "I", doj: "2025-09-01", type: "Apprentice", daysPresent: 26, basic: 9000, da: 2000, hra: 0, special: 0, pfEmp: 0, pfEr: 0, esicEmp: 0, pt: 200, creditDay: 5, bonusPaidYtd: 0 , uan: "", esicNo: "" }),
];

/* --------------------------------------------------------------------------
   Helpers
   -------------------------------------------------------------------------- */

export const SEV = {
  Critical: { w: 28, rank: 4 },
  High: { w: 16, rank: 3 },
  Medium: { w: 8, rank: 2 },
  Low: { w: 3, rank: 1 },
};

export const r0 = (n) => Math.round(n || 0);

/** Professional tax for a wage, tolerant of a missing or open-ended top slab. */
export function ptForWage(gross, P) {
  const slabs = Array.isArray(P.ptSlabs) && P.ptSlabs.length ? P.ptSlabs : DEFAULT_PARAMS.ptSlabs;
  const hit = slabs.find((s) => s.upto == null || gross <= s.upto);
  return Number((hit || slabs[slabs.length - 1] || { amt: 0 }).amt) || 0;
}
export const inr = (n) => "\u20B9" + Math.round(n || 0).toLocaleString("en-IN");
export const pct = (n) => `${(n || 0).toFixed(1)}%`;

const AUDIT_DATE = new Date("2026-03-31");
const yearsBetween = (iso) => (AUDIT_DATE - new Date(iso)) / (365.25 * 864e5);

/* --------------------------------------------------------------------------
   Wage computation under s.2(y)
   -------------------------------------------------------------------------- */

export function computeWages(e, P) {
  const included = e.basic + e.da + e.retaining;      // s.2(y) inclusions

  // Excluded components, clauses (a) to (i). Gratuity (j) and retrenchment
  // compensation (k) are ring-fenced and never enter the add-back test.
  const excludedAllowances = e.hra + e.conveyance + e.special + e.otherAllow;
  const excludedOt = P.includeOtInRemuneration ? e.otPaid : 0;
  const excludedErPf = P.includeErPfInRemuneration ? e.pfEr : 0;
  const excludedBonus = P.includeBonusInRemuneration ? e.bonusPaidYtd / 12 : 0;
  const excluded = excludedAllowances + excludedOt + excludedErPf + excludedBonus;

  const remuneration = included + excluded;
  const floor = remuneration * (P.wageFloorPct / 100);
  const addBack = Math.max(0, excluded - floor);
  const wages = included + addBack;

  return {
    included, excluded, excludedAllowances, excludedOt, excludedErPf,
    excludedBonus, remuneration, floor, addBack, wages,
    includedShare: remuneration ? (included / remuneration) * 100 : 0,
    compliantStructure: addBack === 0,
  };
}

export function derive(e, P) {
  const w = computeWages(e, P);
  const gross = e.basic + e.da + e.retaining + e.hra + e.conveyance +
    e.special + e.otherAllow + e.otPaid;
  const deductions = e.pfEmp + e.esicEmp + e.pt + e.lwf + e.tds + e.advance + e.otherDed;
  return {
    ...e, w,
    wages: w.wages,
    gross,
    deductions,
    net: gross - deductions,
    service: yearsBetween(e.doj),
  };
}

/* --------------------------------------------------------------------------
   Salary structure optimiser — restructure to compliance at constant cost
   -------------------------------------------------------------------------- */

export function optimise(e, P) {
  const cur = computeWages(e, P);
  const mwFull = P.minWage[e.zone]?.[e.skill] ?? 0;

  // Cost to the employer is held constant. Only the split changes.
  const payableGross = e.basic + e.da + e.retaining + e.hra + e.conveyance +
    e.special + e.otherAllow;

  // Target wages: the higher of the statutory floor and the minimum rate.
  const remunerationEst = cur.remuneration;
  const targetWages = Math.max(
    remunerationEst * (P.wageFloorPct / 100),
    mwFull,
    cur.included
  );
  const target = Math.min(targetWages, payableGross); // cannot exceed what is paid

  // Keep DA proportionate where the employer already runs one.
  const daShare = cur.included ? e.da / cur.included : 0;
  const newDa = r0(target * daShare);
  const newBasic = r0(target - newDa);

  // Remaining amount is split HRA-first, capped at 40% of basic + DA,
  // with the balance to special allowance.
  const rest = payableGross - target;
  const newHra = r0(Math.min(rest, target * 0.4));
  const newSpecial = r0(rest - newHra);

  const proposed = {
    ...e, basic: newBasic, da: newDa, retaining: 0,
    hra: newHra, special: newSpecial, conveyance: 0, otherAllow: 0,
  };
  const nw = computeWages(proposed, P);

  const pfBase = (x) => Math.min(x, P.pfCeiling);
  const pfNow = r0((pfBase(cur.wages) * P.pfRateEmployee) / 100);
  const pfNew = r0((pfBase(nw.wages) * P.pfRateEmployee) / 100);
  const gratNow = r0((cur.wages * 15) / 26);
  const gratNew = r0((nw.wages * 15) / 26);

  return {
    current: { basic: e.basic, da: e.da, hra: e.hra, special: e.special + e.conveyance + e.otherAllow, wages: cur.wages, share: cur.includedShare },
    proposed: { basic: newBasic, da: newDa, hra: newHra, special: newSpecial, wages: nw.wages, share: nw.includedShare },
    payableGross,
    pfNow, pfNew, pfDelta: pfNew - pfNow,
    employerCostDelta: (pfNew - pfNow), // employer PF moves with the base
    takeHomeDelta: -(pfNew - pfNow),    // employee share rises by the same amount
    gratuityAccrualDelta: gratNew - gratNow,
    compliant: nw.compliantStructure && nw.wages >= mwFull - 1,
    minWage: mwFull,
  };
}

/* --------------------------------------------------------------------------
   Compliance rules
   -------------------------------------------------------------------------- */

export function auditEmployee(raw, P, all) {
  const e = derive(raw, P);
  const F = [];
  const add = (f) => F.push(f);
  const proRata = Math.min(e.daysPresent / e.daysInMonth, 1);
  const apprentice = e.type === "Apprentice";
  const fixedTerm = e.type === "Fixed Term";

  /* MW-01 — minimum wages -------------------------------------------------*/
  const mwFull = apprentice ? 0 : P.minWage[e.zone]?.[e.skill] ?? 0;
  const mwDue = mwFull * proRata;
  if (mwFull && e.wages < mwDue - 1) {
    const short = mwDue - e.wages;
    add({
      code: "MW-01", title: "Wages below the notified minimum rate",
      sev: short / mwDue > 0.12 ? "Critical" : "High",
      act: "Code on Wages, 2019", sec: "s.5 r/w s.6",
      computed: mwDue, paid: e.wages, delta: short, exposure: short * 12,
      plain: `Wages under s.2(y) work out to ${inr(e.wages)} for ${e.daysPresent} days worked, against the notified rate of ${inr(mwDue)} for the ${e.skill} category in Zone ${e.zone}.`,
      legal: "Minimum wages are payable on wages as defined in s.2(y). Allowances outside the definition cannot be set off against the minimum rate, so a structure heavy on HRA and special allowance does not discharge the obligation even where gross pay looks adequate.",
      fix: `Raise basic and dearness allowance so that wages reach at least ${inr(mwFull)} a month, and pay arrears of ${inr(short)} for each month the shortfall ran.`,
    });
  }

  /* WD-02 — the fifty per cent floor -------------------------------------*/
  if (!e.w.compliantStructure) {
    add({
      code: "WD-02", title: "Wage component below half of total remuneration",
      sev: e.w.includedShare < 40 ? "High" : "Medium",
      act: "Code on Wages, 2019", sec: "s.2(y), first proviso",
      computed: e.w.floor, paid: e.w.included, delta: e.w.addBack,
      exposure: e.w.addBack * 0.24 * 12,
      plain: `Basic and dearness allowance are ${pct(e.w.includedShare)} of total remuneration of ${inr(e.w.remuneration)}. ${inr(e.w.addBack)} of the excluded components is therefore deemed to be wages.`,
      legal: "Where the excluded components in clauses (a) to (i) exceed one-half of total remuneration, the excess is added back and treated as wages. Employer provident fund contribution and statutory bonus count toward total remuneration but are not themselves wages. Gratuity and retrenchment compensation are ring-fenced from the calculation.",
      fix: `Restructure so basic and dearness allowance reach ${inr(e.w.floor)}. The optimiser produces a cost-neutral split. Until then, PF, gratuity, bonus and overtime must all compute on the deemed figure of ${inr(e.w.wages)}, not on ${inr(e.w.included)}.`,
    });
  }

  /* PF-03/04/05 — provident fund -----------------------------------------*/
  const pfBase = Math.min(e.wages, P.pfCeiling);
  const pfDue = apprentice ? 0 : r0((pfBase * P.pfRateEmployee) / 100);
  if (pfDue > 0 && e.pfEmp === 0) {
    add({
      code: "PF-03", title: "No provident fund contribution for a covered employee",
      sev: "Critical", act: "Code on Social Security, 2020", sec: "s.16",
      computed: pfDue, paid: 0, delta: pfDue, exposure: pfDue * 2 * 12 * 1.25,
      plain: "Wages fall within the coverage threshold but no contribution appears in the register.",
      legal: "Membership is compulsory from the date of joining. Non-remittance attracts interest under s.42 and damages of up to one hundred per cent of the arrears.",
      fix: `Enrol the employee, remit ${inr(pfDue * 2)} a month across both shares, and file a revised return with interest and damages.`,
    });
  } else if (pfDue > 0 && Math.abs(e.pfEmp - pfDue) > 2) {
    const short = pfDue - e.pfEmp;
    add({
      code: "PF-04",
      title: short > 0 ? "Provident fund computed on an understated wage base" : "Provident fund deducted above the statutory base",
      sev: short > 0 ? "High" : "Low",
      act: "Code on Social Security, 2020", sec: "s.16 r/w s.2(88)",
      computed: pfDue, paid: e.pfEmp, delta: Math.abs(short),
      exposure: Math.max(short, 0) * 2 * 12,
      plain: `Contribution of ${inr(e.pfEmp)} does not match ${P.pfRateEmployee}% of the wage base of ${inr(pfBase)}.`,
      legal: "The Social Security Code adopts the wage definition in the Code on Wages, so the base includes any amount added back under the fifty per cent proviso. Splitting pay into allowances to depress the base does not survive that test.",
      fix: `Recompute on ${inr(pfBase)} and settle the difference of ${inr(Math.abs(short) * 2)} a month across both shares.`,
    });
  }
  if (pfDue > 0 && !e.uan) {
    add({
      code: "PF-05", title: "Universal account number not recorded",
      sev: "Medium", act: "Code on Social Security, 2020", sec: "s.142",
      computed: null, paid: null, delta: 0, exposure: 5000,
      plain: "A contributing employee has no UAN on record, so remittances cannot be traced to a member account.",
      legal: "An Aadhaar-seeded universal account number is mandatory for establishing identity and for filing the electronic challan-cum-return.",
      fix: "Generate or link the UAN, complete Aadhaar seeding and KYC, then re-file the affected returns.",
    });
  }

  /* ES-06/07/08/09 — employees' state insurance ---------------------------*/
  const esicLimit = e.disability ? P.esicWageLimitDisability : P.esicWageLimit;
  // Coverage is still tested on gross monthly wages excluding overtime — the
  // pre-Code threshold continues pending finalisation of rules. Only the
  // contribution base moved to the s.2(88) wage definition on 21.11.2025.
  const esicTestWage = e.gross - e.otPaid;
  const esicCovered = !apprentice && esicTestWage <= esicLimit;
  const esicContribBase = P.esicBase === "gross" ? e.gross : e.wages;
  const esicDue = esicCovered ? r0((esicContribBase * P.esicRateEmployee) / 100) : 0;
  const esicErDue = esicCovered ? r0((esicContribBase * P.esicRateEmployer) / 100) : 0;

  if (esicCovered && e.esicEmp === 0) {
    add({
      code: "ES-06", title: "Employee within the insurance wage limit is not covered",
      sev: "Critical", act: "Code on Social Security, 2020", sec: "s.29 r/w s.31",
      computed: esicDue, paid: 0, delta: esicDue,
      exposure: (esicDue + esicErDue) * 12 * 1.12,
      plain: `Wages of ${inr(esicTestWage)} are at or below the limit of ${inr(esicLimit)}, but no contribution has been made.`,
      legal: "Coverage follows the wage limit automatically and now extends across the country rather than to notified areas alone. Failure to pay attracts interest at twelve per cent together with damages, and denies the employee medical and cash benefits.",
      fix: `Register the employee and remit ${inr(esicDue + esicErDue)} a month across both shares.`,
    });
  } else if (esicCovered && Math.abs(e.esicEmp - esicDue) > 2) {
    const short = esicDue - e.esicEmp;
    add({
      code: "ES-07",
      title: short > 0 ? "Insurance contribution short of the prescribed rate" : "Insurance contribution computed on the pre-Code gross basis",
      sev: short > 0 ? "Medium" : "Low",
      act: "Code on Social Security, 2020", sec: "s.29 r/w s.2(88)",
      computed: esicDue, paid: e.esicEmp, delta: Math.abs(short),
      exposure: Math.abs(short) * 12,
      plain: `Deduction of ${inr(e.esicEmp)} differs from ${P.esicRateEmployee}% of the wage base of ${inr(esicContribBase)}.`,
      legal: "From 21 November 2025 the wage definition in the Social Security Code governs the computation of insurance contributions, displacing the definition in the Employees' State Insurance Act, 1948. Overtime remains outside wages unless it is caught by the fifty per cent add-back, so a gross-based deduction now over-collects in most structures.",
      fix: short > 0
        ? `Correct the deduction to ${inr(esicDue)} and adjust in the current contribution period.`
        : `Move the contribution base to wages as defined. The over-remittance of ${inr(Math.abs(short))} a month is recoverable but the basis should be corrected before the next return.`,
    });
  }
  if (esicCovered && !e.esicNo) {
    add({
      code: "ES-08", title: "Insurance number missing for a covered employee",
      sev: "Medium", act: "Code on Social Security, 2020", sec: "s.29",
      computed: null, paid: null, delta: 0, exposure: 5000,
      plain: "No insurance number is on record, so the employee and dependants cannot claim benefits.",
      legal: "Particulars for allotment of an insurance number must be furnished within ten days of the employee becoming insurable.",
      fix: "File the declaration, obtain the insurance number and issue the identity card.",
    });
  }
  if (!apprentice && !esicCovered && e.prevCovered && e.esicEmp === 0) {
    const endsThisMonth = P.esicPeriodEndMonths.includes(P.periodMonth);
    add({
      code: "ES-09", title: "Contribution stopped mid contribution period after crossing the limit",
      sev: "High", act: "Code on Social Security, 2020", sec: "s.29; ESI (General) Regulations r.50",
      computed: null, paid: 0, delta: 0, exposure: 30000,
      plain: `Wages crossed ${inr(esicLimit)} during the contribution period and deduction stopped in the same month.${endsThisMonth ? " The period closes at the end of this month." : ""}`,
      legal: "An employee whose wages exceed the limit part way through a contribution period continues to be an insured person until the end of that period. Contributions must run to the close of the April to September or October to March cycle, not from the month of the increase.",
      fix: "Restore the contribution for the remaining months of the period and file a revised return for the months already skipped.",
    });
  }

  /* PT-10 — professional tax ---------------------------------------------*/
  const ptDue = e.gender === "F" && e.gross <= P.ptWomenExemptUpto
    ? 0
    : ptForWage(e.gross, P);
  if (Math.abs(e.pt - ptDue) > 0) {
    add({
      code: "PT-10",
      title: e.pt < ptDue ? "Professional tax deducted short of the slab" : "Professional tax deducted where none is due",
      sev: "Medium",
      act: "Maharashtra State Tax on Professions, Trades, Callings and Employments Act, 1975",
      sec: "s.4 r/w Schedule I",
      computed: ptDue, paid: e.pt, delta: Math.abs(ptDue - e.pt),
      exposure: Math.abs(ptDue - e.pt) * 12 * 1.2,
      plain: `The slab for gross pay of ${inr(e.gross)} is ${inr(ptDue)} against ${inr(e.pt)} deducted.`,
      legal: "Professional tax is a state levy and is unaffected by the labour codes. It is charged on gross salary, and the employer remains liable to pay it whether or not it was recovered from the employee.",
      fix: e.pt < ptDue
        ? `Recover ${inr(ptDue - e.pt)} and pay it with the monthly return.`
        : "Refund the excess and correct the slab mapping in the payroll master.",
    });
  }

  /* LW-11 — labour welfare fund ------------------------------------------*/
  if (e.lwf === 0 && [6, 12].includes(P.periodMonth)) {
    add({
      code: "LW-11", title: "Labour welfare fund contribution not deducted",
      sev: "Low", act: "Maharashtra Labour Welfare Fund Act, 1953", sec: "s.6BB",
      computed: P.lwfEmployee, paid: 0, delta: P.lwfEmployee,
      exposure: (P.lwfEmployee + P.lwfEmployer) * 2,
      plain: "The half-yearly contribution falls due in this wage period but does not appear in the register.",
      legal: "Contributions are payable twice a year and must be remitted with the prescribed return.",
      fix: `Deduct ${inr(P.lwfEmployee)} and remit ${inr(P.lwfEmployee + P.lwfEmployer)} with the return.`,
    });
  }

  /* BO-12 — statutory bonus ----------------------------------------------*/
  if (!apprentice && e.wages <= P.bonusEligibilityWage && e.service > 0.08) {
    const calcBase = Math.max(P.bonusCalcCeiling, mwFull);
    const bonusDue = r0((Math.min(e.wages, calcBase) * P.bonusMinPct * 12) / 100);
    if (e.bonusPaidYtd < bonusDue - 50) {
      add({
        code: "BO-12", title: "Statutory bonus short of the minimum payable",
        sev: e.bonusPaidYtd === 0 ? "High" : "Medium",
        act: "Code on Wages, 2019", sec: "s.26 r/w s.28",
        computed: bonusDue, paid: e.bonusPaidYtd, delta: bonusDue - e.bonusPaidYtd,
        exposure: (bonusDue - e.bonusPaidYtd) * 1.5,
        plain: `Minimum bonus works out to ${inr(bonusDue)} for the year against ${inr(e.bonusPaidYtd)} recorded.`,
        legal: "An employee drawing wages within the eligibility limit who has worked at least thirty days is entitled to a minimum of 8.33% of wages, computed on the higher of the calculation ceiling and the applicable minimum rate, regardless of allocable surplus.",
        fix: `Pay the balance of ${inr(bonusDue - e.bonusPaidYtd)} within eight months of the close of the accounting year and record it in the bonus register.`,
      });
    }
  }

  /* OT-13/14 — overtime ---------------------------------------------------*/
  if (e.otHours > 0) {
    const hourly = e.wages / (e.daysInMonth * P.standardHoursPerDay);
    const otDue = r0(e.otHours * hourly * P.otMultiplier);
    if (e.otPaid < otDue - 20) {
      add({
        code: "OT-13", title: "Overtime paid below twice the ordinary rate",
        sev: "High",
        act: "Occupational Safety, Health and Working Conditions Code, 2020",
        sec: "s.26 r/w Code on Wages s.14",
        computed: otDue, paid: e.otPaid, delta: otDue - e.otPaid,
        exposure: (otDue - e.otPaid) * 12,
        plain: `${e.otHours} overtime hours attract ${inr(otDue)} at twice the ordinary rate against ${inr(e.otPaid)} paid.`,
        legal: "Work beyond eight hours in a day or forty-eight hours in a week is paid at not less than twice the ordinary rate. The ordinary rate is derived from wages as defined, which includes any amount added back under the fifty per cent proviso.",
        fix: `Pay arrears of ${inr(otDue - e.otPaid)} and correct the overtime rate formula so it draws on the wage figure rather than on basic alone.`,
      });
    }
    if (e.otHours * 3 > P.otQuarterCapHours) {
      add({
        code: "OT-14", title: "Overtime projected to breach the quarterly ceiling",
        sev: "Medium",
        act: "Occupational Safety, Health and Working Conditions Code, 2020", sec: "s.25",
        computed: P.otQuarterCapHours, paid: e.otHours * 3,
        delta: e.otHours * 3 - P.otQuarterCapHours, exposure: 25000,
        plain: `At ${e.otHours} hours a month the quarterly total reaches ${e.otHours * 3} against a ceiling of ${P.otQuarterCapHours}.`,
        legal: "Overtime in a quarter may not exceed the prescribed limit even with the employee's consent. This is a working conditions offence, separate from any wage shortfall.",
        fix: "Redistribute the load or add a shift, and keep the overtime register with written consent on file.",
      });
    }
  }

  /* DE-15 — deduction ceiling --------------------------------------------*/
  const dedPct = e.gross ? (e.deductions / e.gross) * 100 : 0;
  if (dedPct > P.deductionCapPct) {
    const cap = e.gross * (P.deductionCapPct / 100);
    add({
      code: "DE-15", title: "Total deductions exceed half of wages",
      sev: "Critical", act: "Code on Wages, 2019", sec: "s.18(1)",
      computed: cap, paid: e.deductions, delta: e.deductions - cap,
      exposure: (e.deductions - cap) * 12,
      plain: `Deductions of ${inr(e.deductions)} are ${pct(dedPct)} of pay of ${inr(e.gross)}.`,
      legal: "Deductions in a wage period may not exceed fifty per cent, or seventy-five per cent where payments to a cooperative society are involved. Recovery beyond that is an unauthorised deduction, refundable with compensation.",
      fix: `Cap this period's recovery at ${inr(cap)} and reschedule the balance across later periods.`,
    });
  }

  /* WP-16/17 — payment ----------------------------------------------------*/
  if (e.creditDay > P.wagePayByDay) {
    add({
      code: "WP-16", title: "Wages credited after the prescribed date",
      sev: e.creditDay > P.wagePayByDay + 4 ? "High" : "Medium",
      act: "Code on Wages, 2019", sec: "s.17(1)(b)",
      computed: P.wagePayByDay, paid: e.creditDay,
      delta: e.creditDay - P.wagePayByDay, exposure: 24000,
      plain: `Pay reached the account on day ${e.creditDay} of the following month against a due date of day ${P.wagePayByDay}.`,
      legal: "Wages for a monthly wage period are payable before the expiry of the seventh day of the following month where fewer than one thousand persons are employed, and the tenth day otherwise.",
      fix: "Move the payroll cut-off earlier and fund the disbursement account by the fifth so credits settle inside the statutory window.",
    });
  }
  if (!e.bankCredited) {
    add({
      code: "WP-17", title: "No bank credit evidence for wages paid",
      sev: "High", act: "Code on Wages, 2019", sec: "s.15",
      computed: null, paid: null, delta: 0, exposure: 20000,
      plain: "The bank transfer file carries no matching credit for this employee for the wage period.",
      legal: "Wages are payable in current coin, by cheque, or by credit to a bank account. Where electronic payment is notified for a class of establishment, cash ceases to be a valid discharge.",
      fix: "Obtain the acquittance or bank advice for this record and move the payment to bank credit from the next cycle.",
    });
  }

  /* ER-18 — equal remuneration -------------------------------------------*/
  const peers = all.filter((p) =>
    p.desig === e.desig && p.skill === e.skill &&
    p.gender !== e.gender && p.type !== "Apprentice");
  if (peers.length && e.gender === "F") {
    const peerAvg = peers.reduce((s, p) => s + p.wages, 0) / peers.length;
    const gap = peerAvg - e.wages;
    if (gap / peerAvg > 0.05) {
      add({
        code: "ER-18", title: "Pay differential between men and women doing the same work",
        sev: "Critical", act: "Code on Wages, 2019", sec: "s.3 r/w s.4",
        computed: peerAvg, paid: e.wages, delta: gap, exposure: gap * 12 * 1.5,
        plain: `Wages of ${inr(e.wages)} are ${pct((gap / peerAvg) * 100)} below the average of ${inr(peerAvg)} for men in the same designation and skill category.`,
        legal: "No discrimination is permitted in wages for the same work or work of a similar nature. Reducing anyone's wages to achieve compliance is expressly barred, so the differential must be closed upward.",
        fix: `Raise wages to ${inr(peerAvg)} and document the pay-band rationale for every grade so the structure survives an inspection.`,
      });
    }
  }

  /* GR-19/20 — gratuity ---------------------------------------------------*/
  if (e.service >= P.gratuityMinYears) {
    const liability = r0((e.wages * 15 * Math.floor(e.service)) / 26);
    add({
      code: "GR-19", title: "Gratuity liability accrued and to be provided for",
      sev: "Low", act: "Code on Social Security, 2020", sec: "s.53",
      computed: liability, paid: null, delta: 0, exposure: liability,
      plain: `${Math.floor(e.service)} completed years create an accrued liability of ${inr(liability)} at fifteen days' wages a year on the s.2(88) wage figure.`,
      legal: "Gratuity is payable on superannuation, retirement, resignation or death after five years of continuous service, computed on wages last drawn. The wage figure rose for most structures when the fifty per cent proviso took effect, so the liability carried in the books may be understated.",
      fix: "Recognise the liability on an actuarial basis and consider funding it through an approved trust or insurer.",
    });
  } else if (fixedTerm && P.gratuityFixedTermProRata && e.service > 0.5) {
    const liability = r0((e.wages * 15 * e.service) / 26);
    add({
      code: "GR-20", title: "Pro-rata gratuity accrued for a fixed term employee",
      sev: "Medium", act: "Code on Social Security, 2020", sec: "s.53(2)",
      computed: liability, paid: null, delta: 0, exposure: liability,
      plain: `${e.service.toFixed(1)} years of fixed term service create a pro-rata liability of ${inr(liability)}, payable irrespective of the five-year threshold.`,
      legal: "The Social Security Code entitles a fixed term employee to gratuity in proportion to the period served, removing the five-year qualifying condition that applied under the Payment of Gratuity Act. Fixed term staff are also entitled to the same wages, benefits and bonus eligibility as permanent employees doing similar work.",
      fix: "Provide for pro-rata gratuity on every fixed term contract and settle it at the end of the term rather than treating it as unearned.",
    });
  }

  /* AT-21 — attendance ----------------------------------------------------*/
  if (e.daysPresent > e.daysInMonth) {
    add({
      code: "AT-21", title: "Days paid exceed days in the wage period",
      sev: "High", act: "Code on Wages, 2019", sec: "s.50",
      computed: e.daysInMonth, paid: e.daysPresent,
      delta: e.daysPresent - e.daysInMonth, exposure: 15000,
      plain: "The muster roll shows more paid days than the wage period contains.",
      legal: "The wage register and muster roll must reconcile. A mismatch undermines the evidentiary value of the whole register during an inspection.",
      fix: "Reconcile the attendance log against the muster roll and correct the register entry.",
    });
  }

  const penalty = F.reduce((s, f) => s + SEV[f.sev].w, 0);
  const compliance = Math.max(0, 100 - penalty);
  const band = compliance >= 90 ? "Very Low" : compliance >= 75 ? "Low"
    : compliance >= 55 ? "Medium" : compliance >= 35 ? "High" : "Critical";
  const gratuity = F.filter((f) => f.code.startsWith("GR")).reduce((s, f) => s + f.exposure, 0);
  const exposure = F.reduce((s, f) => s + (f.code.startsWith("GR") ? 0 : f.exposure || 0), 0);

  return { ...e, findings: F, compliance, risk: 100 - compliance, band, exposure, gratuity };
}

export function runAudit(register, P) {
  const base = register.map((e) => derive(e, P));
  return register.map((e) => auditEmployee(e, P, base));
}

/* ============================================================================
   Period selection
   ========================================================================== */

export const MONTHS = ["April", "May", "June", "July", "August", "September",
  "October", "November", "December", "January", "February", "March"];

export const MONTH_NO = {
  January: 1, February: 2, March: 3, April: 4, May: 5, June: 6,
  July: 7, August: 8, September: 9, October: 10, November: 11, December: 12,
};

export const FY_LIST = ["2023-24", "2024-25", "2025-26", "2026-27"];

/** Calendar year a month falls in for a given financial year. */
export const calendarYear = (fy, month) => {
  const start = Number(fy.slice(0, 4));
  return MONTH_NO[month] >= 4 ? start : start + 1;
};

export const periodKey = (fy, month) => `${fy}|${month}`;
export const periodLabel = (fy, month) => `${month} ${calendarYear(fy, month)}`;

/** Contribution period an ESI month belongs to. */
export const contributionPeriod = (month) =>
  MONTH_NO[month] >= 4 && MONTH_NO[month] <= 9 ? "April to September" : "October to March";

/** Merge a chosen period into the parameter set the rules read from. */
export const withPeriod = (P, fy, month) => ({
  ...P,
  fy, month,
  period: periodLabel(fy, month),
  periodMonth: MONTH_NO[month],
});

/* ============================================================================
   Post-processing: reconciliation findings, auditor observations, dismissals
   ========================================================================== */

export function rescore(e) {
  const penalty = e.findings.reduce((s, f) => s + (SEV[f.sev]?.w || 0), 0);
  const compliance = Math.max(0, 100 - penalty);
  const band = compliance >= 90 ? "Very Low" : compliance >= 75 ? "Low"
    : compliance >= 55 ? "Medium" : compliance >= 35 ? "High" : "Critical";
  const gratuity = e.findings.filter((f) => f.code.startsWith("GR"))
    .reduce((s, f) => s + (f.exposure || 0), 0);
  const exposure = e.findings
    .reduce((s, f) => s + (f.code.startsWith("GR") ? 0 : f.exposure || 0), 0);
  return { ...e, compliance, risk: 100 - compliance, band, exposure, gratuity };
}

export const dismissKey = (empId, code) => `${empId}|${code}`;

/**
 * Folds reconciliation findings and auditor observations into the audit, then
 * removes anything the auditor has dismissed and rescores each record.
 */
export function finalise(audited, { extras = {}, custom = [], dismissed = {} } = {}) {
  return audited.map((e) => {
    const added = [...(extras[e.id] || []), ...custom.filter((c) => c.empId === e.id)];
    const findings = [...e.findings, ...added]
      .filter((f) => !dismissed[dismissKey(e.id, f.code)]);
    return rescore({ ...e, findings });
  });
}

/** Auditor observations are findings too — same shape, different origin. */
export function toObservation(o, n) {
  return {
    code: o.code || `AO-${String(n).padStart(2, "0")}`,
    title: o.title,
    sev: o.sev,
    act: o.act,
    sec: o.sec || "Auditor observation",
    computed: null, paid: null, delta: 0,
    exposure: Number(o.exposure) || 0,
    plain: o.observation,
    legal: o.basis || "Recorded by the auditor on review of records and discussion with management. Not generated by the rules engine.",
    fix: o.recommendation,
    manual: true,
    empId: o.empId || "",
    scope: o.empId ? "employee" : "establishment",
  };
}

export const OBSERVATION_ACTS = [
  "Code on Wages, 2019",
  "Code on Social Security, 2020",
  "Occupational Safety, Health and Working Conditions Code, 2020",
  "Industrial Relations Code, 2020",
  "Maharashtra Shops and Establishments Act",
  "Maharashtra Labour Welfare Fund Act, 1953",
  "Maharashtra Profession Tax Act, 1975",
  "Internal control observation",
  "Documentation and records",
];

export const DISMISS_REASONS = [
  "Not applicable to this establishment",
  "Already rectified — evidence on record",
  "Data error in the uploaded register",
  "Accepted by management, action agreed",
  "Duplicate of another finding",
  "Covered by a separate engagement",
];


/* ============================================================================
   Saved state repair

   Anything persisted through JSON can come back subtly wrong: Infinity and
   NaN become null, and a file written by an older build may be missing keys
   added since. Repair on load rather than trusting the file.
   ========================================================================== */

export function sanitizeParams(saved) {
  const P = { ...DEFAULT_PARAMS, ...(saved || {}) };

  // Slabs: drop malformed rows, coerce numbers, and guarantee an open-ended top.
  const slabs = (Array.isArray(P.ptSlabs) ? P.ptSlabs : [])
    .filter((s) => s && typeof s === "object" && Number.isFinite(Number(s.amt)))
    .map((s) => ({
      upto: s.upto == null || !Number.isFinite(Number(s.upto)) ? null : Number(s.upto),
      amt: Number(s.amt),
    }));
  if (!slabs.length) {
    P.ptSlabs = DEFAULT_PARAMS.ptSlabs.map((s) => ({ ...s }));
  } else {
    const capped = slabs.filter((s) => s.upto != null).sort((a, b) => a.upto - b.upto);
    const open = slabs.filter((s) => s.upto == null);
    P.ptSlabs = [...capped, open.length ? open[open.length - 1] : { upto: null, amt: capped[capped.length - 1].amt }];
  }

  // Every numeric parameter must be a finite number.
  for (const [k, v] of Object.entries(DEFAULT_PARAMS)) {
    if (typeof v === "number" && !Number.isFinite(Number(P[k]))) P[k] = v;
  }

  // Minimum wage grid: fill any zone or skill the saved file lacks.
  const mw = P.minWage && typeof P.minWage === "object" ? P.minWage : {};
  P.minWage = Object.fromEntries(Object.entries(DEFAULT_PARAMS.minWage).map(([zone, skills]) => [
    zone,
    Object.fromEntries(Object.entries(skills).map(([skill, def]) => {
      const val = Number(mw?.[zone]?.[skill]);
      return [skill, Number.isFinite(val) ? val : def];
    })),
  ]));

  if (!Array.isArray(P.esicPeriodEndMonths) || !P.esicPeriodEndMonths.length)
    P.esicPeriodEndMonths = [...DEFAULT_PARAMS.esicPeriodEndMonths];

  return P;
}

/** An employee row from a saved file or a CSV, with every field made safe. */
export function sanitizeEmployee(raw) {
  const e = E(raw || {});
  const numeric = ["daysInMonth", "daysPresent", "basic", "da", "retaining", "hra",
    "conveyance", "special", "otherAllow", "otHours", "otPaid", "pfEmp", "pfEr",
    "esicEmp", "pt", "lwf", "tds", "advance", "otherDed", "bonusPaidYtd", "creditDay"];
  for (const k of numeric) {
    const n = Number(e[k]);
    e[k] = Number.isFinite(n) ? n : 0;
  }
  if (!e.daysInMonth) e.daysInMonth = 26;
  e.id = String(e.id ?? "").trim() || "EMP-?";
  e.name = String(e.name ?? "").trim() || e.id;
  e.uan = String(e.uan ?? "").trim();
  e.esicNo = String(e.esicNo ?? "").trim();
  e.zone = ["I", "II", "III"].includes(e.zone) ? e.zone : "I";
  e.skill = ["unskilled", "semiskilled", "skilled"].includes(e.skill) ? e.skill : "unskilled";
  e.gender = e.gender === "F" ? "F" : "M";
  e.type = String(e.type ?? "").trim() || "Permanent";
  e.dept = String(e.dept ?? "").trim() || "Unassigned";
  e.desig = String(e.desig ?? "").trim() || "\u2014";
  e.doj = /^\d{4}-\d{2}-\d{2}$/.test(String(e.doj)) ? e.doj : "2020-01-01";
  return e;
}

export const sanitizePeriods = (periods) => {
  const out = {};
  for (const [k, v] of Object.entries(periods || {})) {
    if (!v || typeof v !== "object") continue;
    out[k] = {
      register: (Array.isArray(v.register) ? v.register : []).map(sanitizeEmployee),
      ecrText: typeof v.ecrText === "string" ? v.ecrText : "",
      esicText: typeof v.esicText === "string" ? v.esicText : "",
    };
  }
  return out;
};

/* ============================================================================
   SALARY SHEET INPUT

   Required columns are the ones an ordinary payroll export already carries.
   Optional columns each switch on further checks; the sheet is accepted
   without them and the app reports what is dormant rather than failing.
   ========================================================================== */

const key = (s) => String(s || "").toLowerCase().replace(/[^a-z0-9]/g, "");

export const SHEET_COLUMNS = [
  // --- required ---------------------------------------------------------
  { field: "id",         label: "Emp Code",    required: true,  aliases: ["empcode", "employeecode", "empid", "employeeid", "code"] },
  { field: "name",       label: "Name",        required: true,  aliases: ["name", "employeename", "membername"] },
  { field: "dept",       label: "Dept",        required: true,  aliases: ["dept", "department"] },
  { field: "skill",      label: "Skill Level", required: true,  aliases: ["skilllevel", "skill", "category", "skillcategory"] },
  { field: "esicNo",     label: "ESIC No",     required: true,  aliases: ["esicno", "esicnumber", "ipnumber", "ip", "insurancenumber"] },
  { field: "uan",        label: "PF Number",   required: true,  aliases: ["pfnumber", "uan", "uannumber", "pfno", "pfuan"] },
  { field: "gender",     label: "gender",      required: true,  aliases: ["gender", "sex"] },
  { field: "daysPresent",label: "days present",required: true,  aliases: ["dayspresent", "days", "daysworked", "presentdays", "paiddays"] },
  { field: "basic",      label: "Basic",       required: true,  aliases: ["basic", "basicwage", "basicsalary"] },
  { field: "da",         label: "DA",          required: true,  aliases: ["da", "dearnessallowance", "vda"] },
  { field: "hra",        label: "HRA",         required: true,  aliases: ["hra", "houserentallowance"] },
  { field: "special",    label: "other",       required: true,  aliases: ["other", "otherallowance", "others", "special", "specialallowance", "otherallowances"] },
  { field: "sheetGross", label: "Gross",       required: true,  aliases: ["gross", "grosswages", "grosssalary", "totalearnings"] },
  { field: "pfEmp",      label: "pf",          required: true,  aliases: ["pf", "pfdeduction", "epf", "pfemployee", "employeepf"] },
  { field: "esicEmp",    label: "esic",        required: true,  aliases: ["esic", "esi", "esicdeduction", "esiemployee"] },
  { field: "pt",         label: "pt",          required: true,  aliases: ["pt", "professiontax", "professionaltax", "ptax"] },
  { field: "lwf",        label: "lwf",         required: true,  aliases: ["lwf", "labourwelfarefund", "lwfdeduction"] },
  { field: "sheetDed",   label: "total ded",   required: true,  aliases: ["totalded", "totaldeduction", "totaldeductions", "deductions"] },
  { field: "sheetNet",   label: "net",         required: true,  aliases: ["net", "netpay", "netsalary", "netpayable", "takehome"] },

  // --- optional, each unlocking checks ----------------------------------
  { field: "doj",         label: "DOJ",           aliases: ["doj", "dateofjoining", "joiningdate"],
    unlocks: ["Statutory bonus (BO-12)", "Gratuity accrual (GR-19, GR-20)"] },
  { field: "type",        label: "Type",          aliases: ["type", "employmenttype", "category2", "nature"],
    unlocks: ["Apprentice exclusions", "Fixed term pro-rata gratuity (GR-20)"] },
  { field: "zone",        label: "Zone",          aliases: ["zone", "area", "wagezone"],
    unlocks: ["Zone-specific minimum wage (MW-01)"] },
  { field: "otHours",     label: "OT Hours",      aliases: ["othours", "overtimehours", "othrs"],
    unlocks: ["Overtime rate (OT-13)", "Quarterly hour ceiling (OT-14)"] },
  { field: "otPaid",      label: "OT Amount",     aliases: ["otamount", "overtimeamount", "otpaid", "overtime"],
    unlocks: ["Overtime rate (OT-13)"] },
  { field: "creditDay",   label: "Credit Day",    aliases: ["creditday", "paydate", "salarycreditday", "creditdate"],
    unlocks: ["Wage payment date (WP-16)"] },
  { field: "bankCredited",label: "Bank Paid",     aliases: ["bankpaid", "bankcredited", "paidbybank", "banktransfer"],
    unlocks: ["Bank credit evidence (WP-17)"] },
  { field: "bonusPaidYtd",label: "Bonus Paid YTD",aliases: ["bonuspaidytd", "bonusytd", "bonuspaid", "bonus"],
    unlocks: ["Statutory bonus (BO-12)"] },
  { field: "daysInMonth", label: "Days in Month", aliases: ["daysinmonth", "monthdays", "totaldays", "payabledays"],
    unlocks: ["Attendance reconciliation (AT-21)"] },
  { field: "desig",       label: "Designation",   aliases: ["designation", "desig", "role", "post"],
    unlocks: ["Equal remuneration by role (ER-18)"] },
  { field: "pfEr",        label: "Employer PF",   aliases: ["employerpf", "pfer", "erpf", "pfemployer"],
    unlocks: ["Employer share in the 50% test (WD-02)"] },
];

const NUMERIC = new Set(["daysPresent", "basic", "da", "hra", "special", "sheetGross",
  "pfEmp", "esicEmp", "pt", "lwf", "sheetDed", "sheetNet", "otHours", "otPaid",
  "creditDay", "bonusPaidYtd", "daysInMonth", "pfEr"]);

const SKILL = { unskilled: "unskilled", us: "unskilled", u: "unskilled",
  semiskilled: "semiskilled", semi: "semiskilled", ss: "semiskilled", s: "semiskilled",
  skilled: "skilled", sk: "skilled", highlyskilled: "skilled", hs: "skilled" };

/** Split a CSV line, honouring quoted fields. */
function splitCsv(line) {
  const out = []; let cur = "", q = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (c === '"') { if (q && line[i + 1] === '"') { cur += '"'; i++; } else q = !q; }
    else if ((c === "," || c === "\t") && !q) { out.push(cur); cur = ""; }
    else cur += c;
  }
  out.push(cur);
  return out.map((s) => s.trim());
}

export function parseSalarySheet(text) {
  const lines = String(text).split(/\r?\n/).filter((l) => l.trim());
  if (!lines.length) return { rows: [], errors: ["The file is empty."], found: [], missing: [], optional: [] };

  const head = splitCsv(lines[0]).map(key);
  const map = {};
  const found = [], missing = [], optionalFound = [], optionalMissing = [];

  for (const col of SHEET_COLUMNS) {
    const i = head.findIndex((h) => h === key(col.label) || col.aliases.includes(h));
    if (i >= 0) { map[col.field] = i; (col.required ? found : optionalFound).push(col); }
    else (col.required ? missing : optionalMissing).push(col);
  }

  const errors = [];
  if (missing.length)
    errors.push(`Missing required column${missing.length === 1 ? "" : "s"}: ${missing.map((c) => c.label).join(", ")}.`);
  if (map.id == null || map.name == null)
    return { rows: [], errors, found, missing, optionalFound, optionalMissing };

  const rows = [];
  const arithmetic = [];

  lines.slice(1).forEach((line, n) => {
    const c = splitCsv(line);
    if (!c.join("").trim()) return;
    const raw = {};
    for (const [field, i] of Object.entries(map)) {
      let v = c[i] ?? "";
      if (NUMERIC.has(field)) v = Number(String(v).replace(/[₹,\s]/g, "")) || 0;
      raw[field] = v;
    }
    if (!String(raw.id).trim() && !String(raw.name).trim()) return;

    raw.skill = SKILL[key(raw.skill)] || "unskilled";
    raw.gender = /^f/i.test(String(raw.gender)) ? "F" : "M";
    raw.bankCredited = map.bankCredited == null
      ? true
      : !/^(n|no|false|0)$/i.test(String(raw.bankCredited).trim());
    raw.uan = String(raw.uan ?? "").replace(/\s/g, "");
    raw.esicNo = String(raw.esicNo ?? "").replace(/\s/g, "");
    if (map.daysInMonth == null || !raw.daysInMonth) raw.daysInMonth = 26;
    if (map.creditDay == null) raw.creditDay = 0;   // 0 suppresses the date check

    const e = sanitizeEmployee(raw);

    /* The sheet states its own totals. Recompute and keep the difference so a
       broken formula shows up as a finding rather than passing silently. */
    const gross = e.basic + e.da + e.hra + e.special + e.otPaid;
    const ded = e.pfEmp + e.esicEmp + e.pt + e.lwf + e.advance + e.otherDed + e.tds;
    const net = gross - ded;
    const d = {
      gross: raw.sheetGross ? gross - raw.sheetGross : 0,
      ded: raw.sheetDed ? ded - raw.sheetDed : 0,
      net: raw.sheetNet ? net - raw.sheetNet : 0,
    };
    if (Math.abs(d.gross) > 1 || Math.abs(d.ded) > 1 || Math.abs(d.net) > 1)
      arithmetic.push({ id: e.id, name: e.name, line: n + 2, ...d,
        sheetGross: raw.sheetGross, sheetDed: raw.sheetDed, sheetNet: raw.sheetNet,
        calcGross: gross, calcDed: ded, calcNet: net });

    rows.push(e);
  });

  if (!rows.length) errors.push("No employee rows were read from the file.");

  return { rows, errors, found, missing, optionalFound, optionalMissing, arithmetic };
}

/** Findings for rows whose stated totals do not match their own components. */
export function arithmeticFindings(arithmetic) {
  const extras = {};
  for (const a of arithmetic) {
    const parts = [];
    if (Math.abs(a.gross) > 1) parts.push(`gross states ${inr(a.sheetGross)} against ${inr(a.calcGross)} from the components`);
    if (Math.abs(a.ded) > 1) parts.push(`total deductions state ${inr(a.sheetDed)} against ${inr(a.calcDed)}`);
    if (Math.abs(a.net) > 1) parts.push(`net states ${inr(a.sheetNet)} against ${inr(a.calcNet)}`);
    (extras[a.id] = extras[a.id] || []).push({
      code: "SH-22", title: "The salary sheet does not agree with itself",
      sev: "High", act: "Code on Wages, 2019", sec: "s.50; register of wages",
      computed: a.calcGross, paid: a.sheetGross, delta: Math.abs(a.gross || a.ded || a.net),
      exposure: Math.abs(a.gross || a.ded || a.net) * 12,
      plain: `On row ${a.line}, ${parts.join("; ")}.`,
      legal: "The wage register must be internally consistent. A stated total that does not follow from the components on the same row means either the register or the payment is wrong, and an inspector will test the arithmetic before anything else.",
      fix: "Trace the row against the payment actually made and correct whichever of the two is wrong before the register is signed.",
    });
  }
  return extras;
}

/* ============================================================================
   CROSS-RETURN CHECKS

   The provident fund return and the insurance contribution list describe the
   same workforce for the same month, filed with two different authorities.
   Read together they contradict each other far more often than either does
   on its own, and the contradiction is what an inspector finds.

   The two documents share no common key: the EPFO statement carries the UAN,
   the ESIC list carries the insurance number. Where a salary sheet is loaded
   it holds both, and matching is exact. Without one, matching falls back to
   the name and every such match is reported as soft.
   ========================================================================== */

import { inr, pct, r0 } from "./engine.js";

const norm = (s) => String(s || "").toUpperCase().replace(/[^A-Z ]/g, "").replace(/\s+/g, " ").trim();

/* Names are filed inconsistently — initials, middle names dropped, order
   swapped. Compare on the set of name parts rather than the whole string. */
function nameScore(a, b) {
  const A = norm(a).split(" ").filter(Boolean);
  const B = norm(b).split(" ").filter(Boolean);
  if (!A.length || !B.length) return 0;
  const hits = A.filter((w) => B.includes(w)).length;
  return hits / Math.max(A.length, B.length);
}

function linkRows(pf, esic, register) {
  const pfRows = pf?.rows || [];
  const esRows = esic?.rows || [];
  const links = [];
  const usedEs = new Set();

  const byUan = new Map();
  const byIp = new Map();
  (register || []).forEach((e) => {
    if (e.uan) byUan.set(String(e.uan).trim(), e);
    if (e.esicNo) byIp.set(String(e.esicNo).trim(), e);
  });

  pfRows.forEach((p) => {
    const emp = byUan.get(String(p.uan).trim()) || null;
    let match = null, how = null;

    if (emp && emp.esicNo) {
      match = esRows.find((x) => String(x.ip).trim() === String(emp.esicNo).trim());
      if (match) how = "identifier";
    }
    if (!match) {
      let best = null, bestScore = 0;
      esRows.forEach((x) => {
        if (usedEs.has(x)) return;
        const sc = nameScore(p.name, x.name);
        if (sc > bestScore) { bestScore = sc; best = x; }
      });
      if (best && bestScore >= 0.6) { match = best; how = bestScore === 1 ? "name" : "partial name"; }
    }
    if (match) usedEs.add(match);
    links.push({ pf: p, esic: match, emp, how });
  });

  esRows.forEach((x) => {
    if (usedEs.has(x)) return;
    links.push({ pf: null, esic: x, emp: byIp.get(String(x.ip).trim()) || null, how: null });
  });

  return links;
}

export function crossCheckReturns({ pf, esic, register = [], P }) {
  const F = [];
  const add = (f) => F.push(f);
  const links = linkRows(pf, esic, register);
  const haveBoth = !!(pf?.rows?.length && esic?.rows?.length);

  /* --- the two documents must describe the same month ------------------ */
  if (haveBoth && pf.header?.period && esic.header?.period) {
    const a = pf.header.period, b = esic.header.period;
    if (a.month !== b.month || a.year !== b.year) {
      add({
        code: "XR-49", title: "The two returns are for different months",
        sev: "High", act: "Audit scope", sec: "Document control",
        exposure: 0, rows: [],
        plain: `The provident fund statement covers ${a.label} and the insurance list covers ${b.label}.`,
        legal: "Comparing returns for different periods produces findings that are artefacts of the mismatch rather than real defaults.",
        fix: "Load the statement and the contribution list for the same month before relying on any cross-return finding below.",
      });
    }
  }

  /* --- in the insurance list, working, but absent from the fund return -- */
  const missingPf = links.filter((l) => !l.pf && l.esic && l.esic.days > 0);
  if (haveBoth && missingPf.length) {
    add({
      code: "XR-50", title: "Worked and insured, but absent from the provident fund return",
      sev: "Critical", act: "Code on Social Security, 2020", sec: "s.16 r/w s.42",
      exposure: missingPf.length * 2400 * 12,
      rows: missingPf.map((l) => ({
        name: l.esic.name, id: l.esic.ip,
        detail: `${l.esic.days} days, ${inr(l.esic.wages)} wages declared to the insurance authority`,
      })),
      plain: `${missingPf.length} ${missingPf.length === 1 ? "person is" : "people are"} shown as having worked the month in the insurance contribution list, with wages declared and contribution paid, but ${missingPf.length === 1 ? "does" : "do"} not appear in the provident fund return for the same month.`,
      legal: "The establishment has certified to one authority that these people worked and earned wages, and to the other that they do not exist. Provident fund membership is compulsory from the date of joining for anyone drawing wages within the threshold. The insurance return is admissible evidence of the employment the fund return omits, so this is the single easiest default for an inspector to establish.",
      fix: "Enrol each person, generate the universal account number, and file a supplementary return with contributions from the date of joining together with interest under s.42 and damages.",
    });
  }

  /* --- in the fund return but absent from the insurance list ------------ */
  const limit = P?.esicWageLimit || 21000;
  const missingEsi = links.filter(
    (l) => l.pf && !l.esic && l.pf.grossWages > 0 && l.pf.grossWages <= limit);
  if (haveBoth && missingEsi.length) {
    add({
      code: "XR-51", title: "Within the insurance wage limit but absent from the contribution list",
      sev: "Critical", act: "Code on Social Security, 2020", sec: "s.29 r/w s.31",
      exposure: missingEsi.length * 800 * 12,
      rows: missingEsi.map((l) => ({
        name: l.pf.name, id: l.pf.uan,
        detail: `${inr(l.pf.grossWages)} gross declared to the fund, at or under the limit of ${inr(limit)}`,
      })),
      plain: `${missingEsi.length} member${missingEsi.length === 1 ? "" : "s"} of the provident fund return ${missingEsi.length === 1 ? "draws" : "draw"} wages within the insurance threshold but ${missingEsi.length === 1 ? "does" : "do"} not appear in the contribution list.`,
      legal: "Coverage follows the wage limit automatically. An employee omitted from the return has no medical or cash benefit cover, and any claim arising in the benefit period becomes the establishment's own cost.",
      fix: "Register each person, obtain the insurance number, and file a supplementary return for the contribution period with both shares and interest.",
    });
  }

  /* --- the same person, two different wage figures ---------------------- */
  const wageGaps = links
    .filter((l) => l.pf && l.esic && l.esic.days > 0 && l.esic.wages > 0)
    .map((l) => ({ ...l, gap: l.pf.grossWages - l.esic.wages }))
    .filter((l) => Math.abs(l.gap) > 1);

  if (wageGaps.length) {
    const under = wageGaps.filter((l) => l.gap > 0);
    const monthly = under.reduce(
      (s, l) => s + r0(l.gap * ((P?.esicRateEmployee ?? 0.75) + (P?.esicRateEmployer ?? 3.25)) / 100), 0);
    add({
      code: "XR-52", title: "The same employee is declared at two different wages",
      sev: "Critical", act: "Code on Social Security, 2020", sec: "s.29 r/w s.2(88); s.16",
      exposure: monthly * 12 * 1.12,
      rows: wageGaps.map((l) => ({
        name: l.pf.name, id: l.pf.uan,
        detail: `${inr(l.pf.grossWages)} to the fund against ${inr(l.esic.wages)} to the insurance authority, a difference of ${inr(Math.abs(l.gap))}`,
      })),
      plain: `${wageGaps.length} ${wageGaps.length === 1 ? "employee is" : "employees are"} declared at one wage in the provident fund return and a different wage in the insurance contribution list for the same month.`,
      legal: "Both returns are filed on the same statutory wage definition under s.2(88). Two different figures for one employee in one month means at least one return is wrong on its face, and the lower one understates the contribution due. Because both documents are filed by the establishment itself, neither can be explained as a third party's error.",
      fix: under.length
        ? `Establish which figure reflects wages actually paid, correct the understated return, and remit the difference. On the figures declared, the insurance shortfall is about ${inr(monthly)} a month across both shares before interest.`
        : "Establish which figure is correct and refile the return that is wrong.",
    });
  }

  /* --- insured persons carried with no work ----------------------------- */
  const idle = (esic?.rows || []).filter((r) => r.days === 0);
  if (idle.length) {
    const share = pct((idle.length / (esic.rows.length || 1)) * 100);
    add({
      code: "XR-53", title: "Insured persons carried on the return with no work",
      sev: idle.length / (esic.rows.length || 1) > 0.5 ? "Medium" : "Low",
      act: "Code on Social Security, 2020", sec: "s.29; ESI (General) Regulations",
      exposure: 12000, rows: idle.slice(0, 20).map((r) => ({
        name: r.name, id: r.ip, detail: r.reason || "no reason recorded",
      })),
      plain: `${idle.length} of ${esic.rows.length} insured persons, ${share} of the list, show no days worked for the month.`,
      legal: "A person who has left must be exited with the last working day recorded. Carrying leavers indefinitely with a no-work reason keeps them nominally insured without contribution, and the register cannot then be reconciled against headcount at an inspection.",
      fix: "Review each name. Record the last working day for anyone who has left, and explain in the working papers why anyone still on roll had no work in the month.",
    });
  }

  /* --- name held by the fund differs from the name filed ----------------- */
  const mismatch = (pf?.rows || []).filter((r) => r.nameMismatch);
  if (mismatch.length) {
    add({
      code: "XR-54", title: "Member name filed differs from the name held against the account",
      sev: "Medium", act: "Code on Social Security, 2020", sec: "s.142",
      exposure: mismatch.length * 4000,
      rows: mismatch.map((r) => ({
        name: r.name, id: r.uan, detail: `held against the account as ${r.nameRepository}`,
      })),
      plain: `${mismatch.length} member name${mismatch.length === 1 ? "" : "s"} in the return ${mismatch.length === 1 ? "does" : "do"} not match the name recorded against the universal account number.`,
      legal: "A name mismatch blocks withdrawal, transfer and pension claims until the record is corrected, so the contribution is paid but the benefit is not available to the member.",
      fix: "File the joint declaration to correct the record, seeding Aadhaar so the two agree.",
    });
  }

  /* --- arithmetic inside each return ------------------------------------ */
  const rate = (P?.pfRateEmployee ?? 12) / 100;
  const pfMath = (pf?.rows || []).filter(
    (r) => r.epfWages > 0 && Math.abs(r.epfContri - r0(r.epfWages * rate)) > 2);
  if (pfMath.length) {
    add({
      code: "XR-55", title: "Contribution in the fund return does not follow from the wages declared",
      sev: "High", act: "Code on Social Security, 2020", sec: "s.16",
      exposure: pfMath.reduce((s, r) => s + Math.abs(r.epfContri - r0(r.epfWages * rate)) * 12, 0),
      rows: pfMath.map((r) => ({
        name: r.name, id: r.uan,
        detail: `${inr(r.epfContri)} remitted against ${inr(r0(r.epfWages * rate))} due on wages of ${inr(r.epfWages)}`,
      })),
      plain: `${pfMath.length} member line${pfMath.length === 1 ? "" : "s"} in the return ${pfMath.length === 1 ? "carries" : "carry"} a contribution that is not the prescribed rate applied to the wages on the same line.`,
      legal: "The return is internally inconsistent. Whichever figure is wrong, the statement as filed does not support the remittance.",
      fix: "Recompute each line and file a revised return.",
    });
  }

  const esiRate = (P?.esicRateEmployee ?? 0.75) / 100;
  const esiMath = (esic?.rows || []).filter(
    (r) => r.wages > 0 && Math.abs(r.contribution - Math.ceil(r.wages * esiRate)) > 1);
  if (esiMath.length) {
    add({
      code: "XR-56", title: "Contribution in the insurance list does not follow from the wages declared",
      sev: "Medium", act: "Code on Social Security, 2020", sec: "s.29",
      exposure: esiMath.length * 3000,
      rows: esiMath.map((r) => ({
        name: r.name, id: r.ip,
        detail: `${inr(r.contribution)} against ${inr(Math.ceil(r.wages * esiRate))} due on ${inr(r.wages)}`,
      })),
      plain: `${esiMath.length} line${esiMath.length === 1 ? "" : "s"} in the contribution list ${esiMath.length === 1 ? "does" : "do"} not follow the prescribed rate.`,
      legal: "Contribution is rounded up to the next rupee on the wages declared for the person.",
      fix: "Recompute and correct the affected lines before the contribution period closes.",
    });
  }

  /* --- the returns are for different entities --------------------------- */
  if (haveBoth && pf.header?.establishment && esic.header?.employer) {
    if (nameScore(pf.header.establishment, esic.header.employer) < 0.5) {
      add({
        code: "XR-57", title: "The two returns name different establishments",
        sev: "High", act: "Audit scope", sec: "Document control",
        exposure: 0, rows: [],
        plain: `The fund return is filed for ${pf.header.establishment} and the insurance list for ${esic.header.employer}.`,
        legal: "Findings drawn from returns of two different entities are not findings about either of them.",
        fix: "Confirm both documents belong to the establishment under audit before proceeding.",
      });
    }
  }

  /* --- summary ---------------------------------------------------------- */
  const matched = links.filter((l) => l.pf && l.esic);
  const soft = matched.filter((l) => l.how !== "identifier");

  return {
    findings: F,
    links,
    summary: {
      pfMembers: pf?.rows?.length || 0,
      esicMembers: esic?.rows?.length || 0,
      esicWorking: (esic?.rows || []).filter((r) => r.days > 0).length,
      matched: matched.length,
      softMatched: soft.length,
      onlyInPf: links.filter((l) => l.pf && !l.esic).length,
      onlyInEsic: links.filter((l) => !l.pf && l.esic).length,
      pfWagesDeclared: pf?.totals?.grossWages || 0,
      esicWagesDeclared: esic?.totals?.wages || 0,
      pfContribution: pf?.totals?.epfContri || 0,
      esicContribution: esic?.totals?.contribution || 0,
      matchedOnIdentifier: matched.length - soft.length,
    },
  };
}

/* ============================================================================
   ANALYSER — reads the audit output and works out what it means.

   This is a deterministic analysis engine. It reasons over the finding set
   rather than calling a language model, so it runs offline and returns the
   same answer for the same register every time. See askAI() at the bottom for
   the hook where a model can be attached.
   ========================================================================== */

import { inr, pct, r0, optimise, SEV } from "./engine.js";

/* Each rule is attributed to an underlying cause, so a spread of symptoms
   collapses into the handful of things actually worth fixing. */
const CAUSE = {
  "WD-02": "structure", "MW-01": "structure", "PF-04": "structure",
  "OT-13": "structure", "GR-19": "structure", "GR-20": "structure",
  "PF-05": "masterdata", "ES-08": "masterdata", "WP-17": "masterdata",
  "ES-06": "coverage", "ES-09": "coverage", "PF-03": "coverage", "BO-12": "coverage",
  "ES-07": "basis", "PT-10": "basis",
  "WP-16": "calendar",
  "DE-15": "recovery", "AT-21": "register", "OT-14": "hours",
  "ER-18": "equity",
  "RC-30": "remittance", "RC-31": "remittance", "RC-32": "remittance",
  "RC-35": "remittance", "RC-36": "remittance",
  "RC-33": "register", "RC-37": "register",
};

/** Auditor observations and any unmapped rule fall through to a sensible bucket. */
const causeOf = (code) =>
  CAUSE[code] || (code.startsWith("AO") ? "observation"
    : code.startsWith("RC") ? "remittance"
    : code.startsWith("CL") ? "contract" : "register");

const CAUSE_META = {
  structure: {
    title: "Salary structures predate the new wage definition",
    why: "Every one of these findings traces back to the same thing: pay was built as a small basic with large allowances, which worked under the old law and does not survive the fifty per cent proviso. Because PF, gratuity, bonus, overtime and the minimum wage test all now read off one wage figure, a single structural defect surfaces as five or six separate exceptions.",
    fix: "Restructure once, at constant employer cost, so basic and dearness allowance clear both the statutory floor and the notified minimum rate. Most of these findings close together.",
    owner: "Payroll and Compensation",
    effort: "High",
  },
  coverage: {
    title: "Coverage logic has not caught up with the Codes",
    why: "Employees who should be enrolled are not, or contributions stopped at the wrong moment. This is a rules problem in the payroll master rather than an arithmetic one, so it recurs every month until the logic is changed.",
    fix: "Rewrite the enrolment and exit tests: coverage on gross wages against the current threshold, continuation to the end of the contribution period, and bonus eligibility read off the wage figure rather than basic.",
    owner: "Payroll operations",
    effort: "Medium",
  },
  basis: {
    title: "Contributions computed on a superseded base",
    why: "The amounts are being calculated conscientiously, just on the base that applied before 21 November 2025. This over-collects rather than under-collects in most structures, so it is a reconciliation and refund problem rather than an enforcement risk.",
    fix: "Point the contribution formula at the wage figure under s.2(88) and reconcile the difference before the contribution period closes.",
    owner: "Payroll operations",
    effort: "Low",
  },
  masterdata: {
    title: "Statutory identifiers and payment evidence missing",
    why: "Records without a UAN, an insurance number or a matching bank credit cannot be defended in an inspection even where the money was paid correctly. These are the findings that turn a clean audit into an adverse one.",
    fix: "Run a completeness sweep across the employee master and close every blank field before the next return.",
    owner: "HR operations",
    effort: "Low",
  },
  calendar: {
    title: "Payroll calendar slips the statutory window",
    why: "Credits are landing after the date the law allows. The cause is almost always a cut-off set too late rather than a funding shortfall.",
    fix: "Pull the attendance cut-off forward and fund the disbursement account by the fifth.",
    owner: "Finance",
    effort: "Low",
  },
  recovery: {
    title: "Recoveries exceed the statutory ceiling",
    why: "Advances and other recoveries are being taken in one period instead of being spread, which pushes total deductions past the limit.",
    fix: "Cap recovery per period and reschedule the balance.",
    owner: "Payroll operations",
    effort: "Low",
  },
  register: {
    title: "Registers do not reconcile",
    why: "Attendance and wage records disagree. Even small mismatches undermine the evidentiary value of the whole register.",
    fix: "Reconcile the attendance system against the muster roll each month before payroll is locked.",
    owner: "HR operations",
    effort: "Low",
  },
  hours: {
    title: "Working hours exceed the permitted ceiling",
    why: "Overtime is being used to cover a staffing gap rather than a peak. Consent does not cure a breach of the quarterly limit.",
    fix: "Treat this as a capacity decision, not a payroll one.",
    owner: "Operations",
    effort: "High",
  },
  remittance: {
    title: "The salary sheet and the statutory returns do not agree",
    why: "Deductions computed on the payroll are not landing in the challan on the same wages, for the same people, in the same amounts. An inspector reads the return, not the sheet, so a payroll that audits clean still fails on what was actually filed. Where the amount deducted exceeds the amount remitted, the gap is money taken from employees and held, which is a different order of problem from an arithmetic error.",
    fix: "Reconcile the register against the return line by line every month before filing, and treat any member present in one and absent from the other as a blocking exception rather than a note.",
    owner: "Payroll operations and Finance",
    effort: "Medium",
  },
  contract: {
    title: "Contractor compliance is not evidenced",
    why: "Liability for a contractor's default rests with the principal employer by statute and cannot be contracted away. What the file can show about verification is the only defence available when a default surfaces.",
    fix: "Make document currency and the monthly contractor statement conditions of the running bill.",
    owner: "Contracts and Compliance",
    effort: "Medium",
  },
  observation: {
    title: "Auditor observations recorded on review",
    why: "These were raised by the auditor from records and discussion rather than by the rules engine, and carry whatever weight the auditor assigned them.",
    fix: "Address each observation with the responsible function and record the management response.",
    owner: "As assigned",
    effort: "Varies",
  },
  equity: {
    title: "Pay differs by gender for the same work",
    why: "This is the finding least likely to be defensible and most likely to attract attention, because the comparison is visible on the face of the register.",
    fix: "Close the gap upward and document a written pay-band rationale for every grade.",
    owner: "HR leadership",
    effort: "Medium",
  },
};

const DEADLINE = {
  structure: "Before the next wage period",
  coverage: "Before the current contribution period closes",
  basis: "Before the next return",
  masterdata: "30 days",
  calendar: "Next payroll cycle",
  recovery: "Next payroll cycle",
  register: "Immediate",
  hours: "Current quarter",
  equity: "Immediate",
  remittance: "Before the next return is filed",
  contract: "Before the next running bill",
  observation: "As agreed with management",
};

export const EMPTY_ANALYSIS = {
  all: [], byRule: [], patterns: [], causes: [], plan: [], depts: [],
  registerRisk: [], restructure: [], nonCompliantStructures: [],
  score: 0, exposure: 0, critical: 0, clean: 0, addBackTotal: 0,
  pfDelta: 0, gratuityDelta: 0, gratuity: 0, payroll: 0,
  headline: ["No salary register has been loaded for this period."],
};

export function analyse(audited, P) {
  if (!audited.length) return EMPTY_ANALYSIS;
  const all = audited.flatMap((e) => e.findings.map((f) => ({ ...f, emp: e })));
  const n = audited.length;

  /* --- per-rule rollup ---------------------------------------------------*/
  const byRule = Object.values(
    all.reduce((m, f) => {
      m[f.code] = m[f.code] || {
        code: f.code, title: f.title, sev: f.sev, act: f.act, sec: f.sec,
        n: 0, exposure: 0, liability: 0, employees: [], cause: causeOf(f.code),
      };
      m[f.code].n++;
      // Accrued gratuity is a liability to provide for, not an exception to
      // remediate, so it is tracked separately and kept out of this rollup.
      m[f.code].exposure += f.code.startsWith("GR") ? 0 : f.exposure || 0;
      m[f.code].liability = (m[f.code].liability || 0) + (f.code.startsWith("GR") ? f.exposure || 0 : 0);
      m[f.code].employees.push(f.emp);
      return m;
    }, {})
  ).sort((a, b) => b.exposure - a.exposure);

  /* --- systemic against isolated ----------------------------------------*/
  const patterns = byRule.map((r) => ({
    ...r,
    share: (r.n / n) * 100,
    kind: r.n / n >= 0.3 ? "systemic" : r.n <= 2 ? "isolated" : "recurring",
  }));

  /* --- root causes -------------------------------------------------------*/
  const causes = Object.entries(
    patterns.reduce((m, r) => {
      (m[r.cause] = m[r.cause] || []).push(r);
      return m;
    }, {})
  )
    .map(([key, rules]) => {
      const emps = new Set();
      rules.forEach((r) => r.employees.forEach((e) => emps.add(e.id)));
      return {
        key, ...CAUSE_META[key], rules,
        employees: emps.size,
        exposure: rules.reduce((s, r) => s + r.exposure, 0),
        liability: rules.reduce((s, r) => s + (r.liability || 0), 0),
        worst: rules.reduce((a, b) => (SEV[a.sev].rank >= SEV[b.sev].rank ? a : b)).sev,
      };
    })
    .sort((a, b) => b.exposure - a.exposure);

  /* --- what the wage definition changed ---------------------------------*/
  const restructure = audited
    .filter((e) => e.type !== "Apprentice")
    .map((e) => ({ e, o: optimise(e, P) }));
  const nonCompliantStructures = audited.filter((e) => !e.w.compliantStructure);
  const addBackTotal = audited.reduce((s, e) => s + e.w.addBack, 0);
  const pfDelta = restructure.reduce((s, x) => s + Math.max(0, x.o.pfDelta), 0);
  const gratuityDelta = restructure.reduce((s, x) => s + Math.max(0, x.o.gratuityAccrualDelta), 0);

  /* --- ranked action plan ------------------------------------------------*/
  const plan = causes.map((c, i) => ({
    rank: i + 1,
    title: c.title,
    action: c.fix,
    owner: c.owner,
    effort: c.effort,
    deadline: DEADLINE[c.key],
    employees: c.employees,
    exposure: c.exposure,
    severity: c.worst,
    rules: c.rules.map((r) => r.code),
  }));

  /* --- inspection readiness ---------------------------------------------*/
  const registerRisk = [
    { doc: "Register of wages", fails: byRule.some((r) => ["WD-02", "MW-01", "AT-21"].includes(r.code)) },
    { doc: "Muster roll and attendance", fails: byRule.some((r) => r.code === "AT-21") },
    { doc: "Provident fund return", fails: byRule.some((r) => r.code.startsWith("PF")) },
    { doc: "Insurance contribution return", fails: byRule.some((r) => r.code.startsWith("ES")) },
    { doc: "Bonus register", fails: byRule.some((r) => r.code === "BO-12") },
    { doc: "Overtime register", fails: byRule.some((r) => r.code.startsWith("OT")) },
    { doc: "Bank transfer statement", fails: byRule.some((r) => ["WP-16", "WP-17"].includes(r.code)) },
    { doc: "Equal remuneration record", fails: byRule.some((r) => r.code === "ER-18") },
  ];

  /* --- department concentration -----------------------------------------*/
  const depts = Object.values(
    audited.reduce((m, e) => {
      m[e.dept] = m[e.dept] || { dept: e.dept, n: 0, risk: 0, exposure: 0, findings: 0 };
      m[e.dept].n++; m[e.dept].risk += e.risk;
      m[e.dept].exposure += e.exposure; m[e.dept].findings += e.findings.length;
      return m;
    }, {})
  ).map((d) => ({ ...d, risk: r0(d.risk / d.n) })).sort((a, b) => b.risk - a.risk);

  /* --- headline ----------------------------------------------------------*/
  const score = r0(audited.reduce((s, e) => s + e.compliance, 0) / n);
  const exposure = audited.reduce((s, e) => s + e.exposure, 0);
  const critical = all.filter((f) => f.sev === "Critical").length;
  const clean = audited.filter((e) => e.findings.length === 0).length;
  const top = causes[0];

  const headline = [
    `${all.length} exceptions across ${n} records, carrying ${inr(exposure)} of estimated exposure before interest.`,
    top
      ? `They collapse into ${causes.length} underlying cause${causes.length === 1 ? "" : "s"}. The largest is that ${top.title.toLowerCase()}, accounting for ${inr(top.exposure)} across ${top.employees} employees and ${top.rules.length} of the ${byRule.length} rules currently firing.`
      : "No exception was raised on the parameters configured.",
    nonCompliantStructures.length
      ? `${nonCompliantStructures.length} of ${n} salary structures fall below the fifty per cent floor, deeming ${inr(addBackTotal)} a month of allowances to be wages.`
      : "Every salary structure clears the fifty per cent floor.",
    critical
      ? `${critical} finding${critical === 1 ? "" : "s"} sit${critical === 1 ? "s" : ""} at critical severity and would be visible on the face of the register in an inspection.`
      : "Nothing reaches critical severity.",
    clean ? `${clean} record${clean === 1 ? "" : "s"} passed without exception.` : "",
  ].filter(Boolean);

  return {
    all, byRule, patterns, causes, plan, registerRisk, depts,
    score, exposure, critical, clean, headline,
    restructure, nonCompliantStructures, addBackTotal, pfDelta, gratuityDelta,
    gratuity: audited.reduce((s, e) => s + e.gratuity, 0),
    payroll: audited.reduce((s, e) => s + e.gross, 0),
  };
}

/* ============================================================================
   Natural language query over the audited register.
   ========================================================================== */

const INTENTS = [
  { keys: ["uan"], codes: ["PF-05"], label: "the universal account number" },
  { keys: ["insurance number", "esic number", "esi number"], codes: ["ES-08"], label: "the insurance number" },
  { keys: ["pf", "provident", "epf"], codes: ["PF-03", "PF-04", "PF-05"], label: "provident fund" },
  { keys: ["esi", "esic", "insurance"], codes: ["ES-06", "ES-07", "ES-08", "ES-09"], label: "employees' state insurance" },
  { keys: ["minimum wage", "below minimum", "underpaid", "minimum"], codes: ["MW-01"], label: "minimum wages" },
  { keys: ["structure", "50", "fifty", "basic", "wage definition"], codes: ["WD-02"], label: "the wage structure floor" },
  { keys: ["bonus"], codes: ["BO-12"], label: "statutory bonus" },
  { keys: ["overtime", "ot ", "hours"], codes: ["OT-13", "OT-14"], label: "overtime" },
  { keys: ["gratuity"], codes: ["GR-19", "GR-20"], label: "gratuity" },
  { keys: ["deduction", "recovery", "advance"], codes: ["DE-15"], label: "deductions" },
  { keys: ["late", "delay", "credit", "payment date"], codes: ["WP-16"], label: "delayed wage payment" },
  { keys: ["bank", "transfer", "cash"], codes: ["WP-17"], label: "bank transfer evidence" },
  { keys: ["equal", "gender", "women", "woman", "discrimin"], codes: ["ER-18"], label: "equal remuneration" },
  { keys: ["professional tax", "pt "], codes: ["PT-10"], label: "professional tax" },
  { keys: ["attendance", "muster", "days"], codes: ["AT-21"], label: "attendance" },
  { keys: ["challan", "ecr", "return", "remit", "reconcil"], codes: ["RC-30", "RC-31", "RC-32", "RC-33", "RC-35", "RC-36", "RC-37"], label: "the salary sheet against the statutory returns" },
];

export function query(q, audited, A) {
  const s = " " + q.toLowerCase().trim() + " ";
  if (!s.trim()) return null;

  // Risk band questions
  const band = ["critical", "high", "medium", "low"].find((b) => s.includes(b + " risk"));
  if (band) {
    const B = band === "low" ? "Low" : band[0].toUpperCase() + band.slice(1);
    const rows = audited.filter((e) => e.band === B);
    return {
      answer: `${rows.length} record${rows.length === 1 ? "" : "s"} in the ${B.toLowerCase()} band, carrying ${inr(rows.reduce((x, e) => x + e.exposure, 0))} of exposure.`,
      rows,
    };
  }

  // Department questions
  const dept = A.depts.find((d) => s.includes(d.dept.toLowerCase()));
  if (dept) {
    const rows = audited.filter((e) => e.dept === dept.dept);
    return {
      answer: `${dept.dept} has ${dept.n} employees averaging a risk score of ${dept.risk}, with ${dept.findings} findings and ${inr(dept.exposure)} of exposure.`,
      rows,
    };
  }

  // Rule-topic questions
  const hit = INTENTS.find((i) => i.keys.some((k) => s.includes(k)));
  if (hit) {
    const rows = audited.filter((e) => e.findings.some((f) => hit.codes.includes(f.code)));
    const fs = A.all.filter((f) => hit.codes.includes(f.code));
    const exp = fs.reduce((x, f) => x + (f.exposure || 0), 0);
    if (!rows.length)
      return { answer: `No exception was raised on ${hit.label} for this period.`, rows: [] };
    return {
      answer: `${rows.length} employee${rows.length === 1 ? "" : "s"} flagged on ${hit.label}, ${inr(exp)} of exposure. ${fs[0].fix}`,
      rows,
    };
  }

  // Named employee
  const emp = audited.find((e) =>
    s.includes(e.name.toLowerCase().split(" ")[0]) || s.includes(e.id.toLowerCase()));
  if (emp) {
    return {
      answer: `${emp.name} carries a risk score of ${emp.risk} in the ${emp.band.toLowerCase()} band, with ${emp.findings.length} finding${emp.findings.length === 1 ? "" : "s"} and ${inr(emp.exposure)} of exposure. Wages under s.2(y) are ${inr(emp.wages)}, ${pct(emp.w.includedShare)} of total remuneration.`,
      rows: [emp],
    };
  }

  return {
    answer: "No match. Try a topic such as provident fund, minimum wages, overtime or bonus, a department name, a risk band, or an employee name.",
    rows: [],
  };
}

/* ============================================================================
   Optional model hook.

   The analysis above is deterministic and needs no network. To put a language
   model behind the answer box instead, POST the audit summary to a provider
   from the main process (never from here — an API key in the renderer ships
   inside the asar in plain text) and return the text. The audit JSON is small
   enough to pass whole.
   ========================================================================== */
export async function askAI(question, audited, A) {
  if (!globalThis.app?.askModel) return null; // not configured — caller falls back
  return globalThis.app.askModel({
    question,
    summary: {
      score: A.score, exposure: A.exposure, headcount: audited.length,
      rules: A.byRule.map((r) => ({ code: r.code, title: r.title, n: r.n, exposure: r.exposure })),
      causes: A.causes.map((c) => ({ title: c.title, employees: c.employees, exposure: c.exposure })),
    },
  });
}

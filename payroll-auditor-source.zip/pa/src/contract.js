/* ============================================================================
   CONTRACT LABOUR COMPLIANCE

   The Contract Labour (Regulation and Abolition) Act, 1970 was repealed when
   the OSH Central Rules were notified on 8 May 2026. Contract labour now sits
   in Chapter XI of the OSH Code, with the licensing regime in s.47 and the
   operative detail in Part I of Chapter XI of the Rules.

   What changed that matters here:
     - the licence threshold moved from 20 contract workers to 50, counted
       over the preceding twelve months
     - one licence, valid five years, replaces the per-establishment,
       per-state licences that came before
     - a national licence is available in Form XXI for multi-state operations
     - a security deposit of Rs 1,000 per contract worker backs the licence,
       and the licensing authority may draw on it directly where minimum wages
       go unpaid
     - the contractor must send the principal employer an electronic statement
       within ten days of each month's close carrying the name, UAN, wages and
       contributions payable for every contract employee
     - where the contractor defaults on wages or minimum bonus, the liability
       is the principal employer's and cannot be contracted away
   ========================================================================== */

import { inr } from "./engine.js";

export const LICENCE_THRESHOLD = 50;      // s.47, preceding 12 months
export const SECURITY_PER_WORKER = 1000;  // Rule 90
export const LICENCE_VALIDITY_YEARS = 5;
export const MONTHLY_STATEMENT_DAYS = 10;

/* --------------------------------------------------------------------------
   Documents to hold on file for every contractor
   -------------------------------------------------------------------------- */

export const DOCUMENTS = [
  // --- engagement -------------------------------------------------------
  { id: "licence", stage: "Engagement", doc: "Contractor licence under s.47, or a declaration that fewer than 50 workers were engaged in the preceding twelve months",
    authority: "OSH Code s.47; OSH Rules Ch. XI Pt. I", critical: true },
  { id: "licenceNational", stage: "Engagement", doc: "National licence in Form XXI where the contractor operates in more than one State",
    authority: "OSH Rules r.88", critical: false },
  { id: "security", stage: "Engagement", doc: `Proof of security deposit at ${inr(SECURITY_PER_WORKER)} per contract worker`,
    authority: "OSH Rules r.90", critical: true },
  { id: "peReg", stage: "Engagement", doc: "Establishment registration certificate of the principal employer",
    authority: "OSH Code s.3; OSH Rules Form I and Form III", critical: true },
  { id: "agreement", stage: "Engagement", doc: "Work order or agreement setting out scope, rate, headcount and duration",
    authority: "Contractual; evidence of the nature of engagement", critical: true },
  { id: "pfCode", stage: "Engagement", doc: "Provident fund code allotment letter of the contractor",
    authority: "Code on Social Security s.16", critical: true },
  { id: "esicCode", stage: "Engagement", doc: "Employees' state insurance registration of the contractor",
    authority: "Code on Social Security s.29", critical: true },
  { id: "pan", stage: "Engagement", doc: "PAN and GST registration of the contractor",
    authority: "Tax registration; contractor identity", critical: false },
  { id: "eligibility", stage: "Engagement", doc: "Declaration that the contractor is not an undischarged insolvent and holds no disqualifying conviction in the preceding two years",
    authority: "OSH Rules r.85", critical: false },
  { id: "workerList", stage: "Engagement", doc: "List of deployed workers with UAN and insurance number",
    authority: "OSH Code Ch. XI; social security enrolment", critical: true },
  { id: "appointment", stage: "Engagement", doc: "Appointment letters in the prescribed format for every contract worker",
    authority: "OSH Code; format prescribed in the OSH Rules", critical: true },
  { id: "insurance", stage: "Engagement", doc: "Employees' compensation policy or equivalent cover",
    authority: "Code on Social Security Ch. VII", critical: false },

  // --- every month ------------------------------------------------------
  { id: "wageRegister", stage: "Monthly", doc: "Wage register and payslips for contract workers",
    authority: "Code on Wages s.50; OSH Rules registers", critical: true },
  { id: "muster", stage: "Monthly", doc: "Attendance record or muster roll",
    authority: "Code on Wages s.50", critical: true },
  { id: "bankProof", stage: "Monthly", doc: "Bank transfer statement evidencing wage disbursement",
    authority: "Code on Wages s.15, s.17", critical: true },
  { id: "statement", stage: "Monthly", doc: `Electronic statement to the principal employer within ${MONTHLY_STATEMENT_DAYS} days of month end, with name, UAN, wages and contributions payable`,
    authority: "OSH Rules, contract labour provisions", critical: true },
  { id: "pfChallan", stage: "Monthly", doc: "Provident fund electronic challan cum return and paid challan with TRRN",
    authority: "Code on Social Security s.16", critical: true },
  { id: "esicChallan", stage: "Monthly", doc: "Insurance contribution file and paid challan",
    authority: "Code on Social Security s.29", critical: true },
  { id: "otRegister", stage: "Monthly", doc: "Overtime register with written consent where applicable",
    authority: "OSH Code s.25, s.26", critical: false },
  { id: "welfare", stage: "Monthly", doc: "Record of welfare amenities provided to contract workers",
    authority: "OSH Code Ch. XI; principal employer's duty", critical: false },

  // --- periodic and on exit ---------------------------------------------
  { id: "lwf", stage: "Periodic", doc: "Labour welfare fund contribution and return, half-yearly",
    authority: "State welfare fund legislation", critical: false },
  { id: "bonus", stage: "Periodic", doc: "Bonus register and proof of payment",
    authority: "Code on Wages Ch. IV", critical: true },
  { id: "licenceRenewal", stage: "Periodic", doc: `Licence renewal record — validity runs ${LICENCE_VALIDITY_YEARS} years`,
    authority: "OSH Code s.47", critical: false },
  { id: "health", stage: "Periodic", doc: "Free annual health examination records where the establishment class requires it",
    authority: "OSH Rules r.5", critical: false },
  { id: "settlement", stage: "On exit", doc: "Full and final settlement within two working days of exit",
    authority: "Code on Wages; OSH Rules", critical: true },
  { id: "experience", stage: "On exit", doc: "Experience certificate issued on completion of the engagement",
    authority: "OSH Rules, contract labour provisions", critical: false },
];

export const DOC_STAGES = ["Engagement", "Monthly", "Periodic", "On exit"];
export const DOC_STATUS = ["Pending", "Received", "Not applicable"];

/* --------------------------------------------------------------------------
   A contractor record
   -------------------------------------------------------------------------- */

export const newContractor = (o = {}) => ({
  id: "CON-" + Math.random().toString(36).slice(2, 7).toUpperCase(),
  name: "",
  work: "",
  workers: 0,
  workersPeak12m: 0,
  coreActivity: false,
  licenceNo: "",
  licenceValidTo: "",
  securityDeposit: 0,
  wagesPaidBy: 7,          // day of the following month
  minWagePaid: true,
  statementReceived: false,
  statementDay: 0,         // day of the following month the statement arrived
  bonusPaid: true,
  settlementWithin2Days: true,
  docs: {},                // id -> "Pending" | "Received" | "Not applicable"
  ...o,
});

export const SAMPLE_CONTRACTORS = [
  newContractor({
    id: "CON-A1", name: "Sunrise Facility Services", work: "Housekeeping and canteen",
    workers: 64, workersPeak12m: 71, licenceNo: "MH/OSH/2026/00418",
    licenceValidTo: "2031-03-31", securityDeposit: 71000, wagesPaidBy: 9,
    statementReceived: true, statementDay: 16, minWagePaid: false,
    docs: {
      licence: "Received", peReg: "Received", agreement: "Received", pfCode: "Received",
      esicCode: "Received", pan: "Received", workerList: "Received", appointment: "Pending",
      security: "Received", wageRegister: "Received", muster: "Received", bankProof: "Pending",
      statement: "Received", pfChallan: "Received", esicChallan: "Pending", bonus: "Pending",
      settlement: "Received", welfare: "Pending", eligibility: "Pending", insurance: "Received",
      otRegister: "Received", lwf: "Not applicable", licenceRenewal: "Received",
      health: "Not applicable", experience: "Pending", licenceNational: "Not applicable",
    },
  }),
  newContractor({
    id: "CON-B2", name: "Vidarbha Engineering Manpower", work: "Machine operation on line 2",
    workers: 38, workersPeak12m: 52, licenceNo: "", licenceValidTo: "",
    securityDeposit: 0, wagesPaidBy: 12, coreActivity: true,
    statementReceived: false, minWagePaid: true, bonusPaid: false,
    settlementWithin2Days: false,
    docs: {
      peReg: "Received", agreement: "Received", pfCode: "Received", esicCode: "Received",
      pan: "Received", workerList: "Pending", appointment: "Pending", licence: "Pending",
      security: "Pending", wageRegister: "Received", muster: "Pending", bankProof: "Pending",
      statement: "Pending", pfChallan: "Received", esicChallan: "Received", bonus: "Pending",
      settlement: "Pending", welfare: "Pending", eligibility: "Pending", insurance: "Pending",
      otRegister: "Pending", lwf: "Pending", licenceRenewal: "Not applicable",
      health: "Not applicable", experience: "Pending", licenceNational: "Not applicable",
    },
  }),
];

/* --------------------------------------------------------------------------
   Checks
   -------------------------------------------------------------------------- */

export function auditContractor(c, P) {
  const F = [];
  const add = (f) => F.push(f);
  const needsLicence = Math.max(c.workers, c.workersPeak12m) >= LICENCE_THRESHOLD;

  /* CL-01 licence */
  if (needsLicence && !c.licenceNo) {
    add({
      code: "CL-01", title: "Contractor engaged without a licence",
      sev: "Critical", act: "Occupational Safety, Health and Working Conditions Code, 2020",
      sec: "s.47 r/w OSH Rules Ch. XI Pt. I",
      exposure: 100000,
      plain: `${Math.max(c.workers, c.workersPeak12m)} contract workers were engaged in the preceding twelve months, at or above the threshold of ${LICENCE_THRESHOLD}, but no licence number is on record.`,
      legal: "A contractor who has employed fifty or more contract workers in the preceding twelve months must hold a licence. The threshold counts the peak over the year, not the headcount on the day of inspection, so a contractor who has since scaled down still needs one.",
      fix: "Suspend fresh deployment until the licence is produced, and obtain a copy for the compliance file before the next billing cycle.",
    });
  } else if (needsLicence && c.licenceValidTo && new Date(c.licenceValidTo) < new Date()) {
    add({
      code: "CL-02", title: "Contractor licence has expired",
      sev: "Critical", act: "Occupational Safety, Health and Working Conditions Code, 2020", sec: "s.47",
      exposure: 75000,
      plain: `The licence on record expired on ${c.licenceValidTo}.`,
      legal: "Deployment on an expired licence is the same position as deployment without one. The licence now runs five years, so an expiry usually means the renewal was missed rather than that it lapsed quietly.",
      fix: "Obtain the renewed licence and hold deployment until it is on file.",
    });
  }

  /* CL-03 security deposit */
  if (needsLicence) {
    const due = Math.max(c.workers, c.workersPeak12m) * SECURITY_PER_WORKER;
    if (c.securityDeposit < due) {
      add({
        code: "CL-03", title: "Security deposit short of the prescribed amount",
        sev: "Medium", act: "OSH (Central) Rules, 2026", sec: "r.90 r/w r.86",
        exposure: due - c.securityDeposit,
        plain: `A deposit of ${inr(due)} is required at ${inr(SECURITY_PER_WORKER)} per contract worker, against ${inr(c.securityDeposit)} evidenced.`,
        legal: "The deposit is not a formality. The licensing authority may draw on it directly where minimum wages go unpaid, which makes it the first line of recovery before the principal employer is reached.",
        fix: "Obtain evidence of the full deposit, or the licence condition is unmet and the licence itself is at risk.",
      });
    }
  }

  /* CL-04 core activity */
  if (c.coreActivity) {
    add({
      code: "CL-04", title: "Contract labour engaged in a core activity",
      sev: "Critical", act: "Occupational Safety, Health and Working Conditions Code, 2020", sec: "Ch. XI",
      exposure: 150000,
      plain: `${c.name} is deployed on ${c.work || "work recorded as a core activity"}, which the establishment has classified as core.`,
      legal: "The Code prohibits engaging contract labour in the core activities of an establishment, subject to the exceptions it sets out. This is the finding most likely to lead to a claim of permanent status, and it is not cured by paperwork.",
      fix: "Reclassify the activity with a documented basis, bring the work on roll, or move it into one of the recognised exceptions. Take a view before the next inspection rather than after it.",
    });
  }

  /* CL-05 monthly statement */
  if (!c.statementReceived) {
    add({
      code: "CL-05", title: "Monthly statement from the contractor not received",
      sev: "High", act: "OSH (Central) Rules, 2026", sec: "Contract labour provisions",
      exposure: 25000,
      plain: "No electronic statement of names, universal account numbers, wages and contributions payable has been received for this period.",
      legal: `The contractor must send this statement to the principal employer within ${MONTHLY_STATEMENT_DAYS} days of the close of each month. Without it the principal employer has no basis on which to verify that contributions were actually deposited, and the duty to verify does not disappear because the statement did not arrive.`,
      fix: "Demand the statement for this period and make future billing conditional on it.",
    });
  } else if (c.statementDay > MONTHLY_STATEMENT_DAYS) {
    add({
      code: "CL-06", title: "Monthly statement received after the prescribed period",
      sev: "Low", act: "OSH (Central) Rules, 2026", sec: "Contract labour provisions",
      exposure: 5000,
      plain: `The statement arrived on day ${c.statementDay} against a limit of ${MONTHLY_STATEMENT_DAYS} days from month end.`,
      legal: "Late receipt compresses the window in which the principal employer can act on a contribution default before the statutory due date passes.",
      fix: "Set the contractual submission date at day five so there is room to act.",
    });
  }

  /* CL-07 wage payment date */
  if (c.wagesPaidBy > P.wagePayByDay) {
    add({
      code: "CL-07", title: "Contract workers paid after the statutory date",
      sev: "High", act: "Code on Wages, 2019", sec: "s.17 r/w OSH Code Ch. XI",
      exposure: 40000,
      plain: `Wages reached contract workers on day ${c.wagesPaidBy} against a due date of day ${P.wagePayByDay}.`,
      legal: "The principal employer must ensure the contractor is placed in funds in time for wages to be paid within the statutory window. Where the contractor fails, the liability to pay is the principal employer's and no indemnity clause displaces it.",
      fix: "Align the contractor payment run so funds reach them by the third, and record the disbursement proof each month.",
    });
  }

  /* CL-08 minimum wages */
  if (!c.minWagePaid) {
    add({
      code: "CL-08", title: "Minimum wages not paid to contract workers",
      sev: "Critical", act: "Code on Wages, 2019", sec: "s.5 r/w OSH Rules r.86(iv)",
      exposure: 120000,
      plain: "The wage register for this contractor shows rates below the notified minimum for the category deployed.",
      legal: "Where minimum wages go unpaid the licensing authority may draw directly on the contractor's security deposit, and the shortfall remains recoverable from the principal employer. Both routes operate independently of the contract between them.",
      fix: "Compute the shortfall worker by worker, have the contractor pay arrears against acknowledgement, and withhold the running bill until it is evidenced.",
    });
  }

  /* CL-09 bonus */
  if (!c.bonusPaid) {
    add({
      code: "CL-09", title: "Statutory bonus not paid by the contractor",
      sev: "High", act: "Code on Wages (Central) Rules, 2026", sec: "Ch. IV",
      exposure: 60000,
      plain: "No evidence of minimum bonus payment for the contract workforce is on file.",
      legal: "Where a contractor fails to pay the minimum bonus, the principal employer must pay it directly to the affected employees on receiving written notice and confirmation of the failure. The rules do not provide a recovery mechanism, so the amount is recoverable only under the contract.",
      fix: "Obtain the bonus register and payment proof, and provide for the amount if the contractor cannot evidence payment.",
    });
  }

  /* CL-10 settlement */
  if (!c.settlementWithin2Days) {
    add({
      code: "CL-10", title: "Exit dues not settled within two working days",
      sev: "Medium", act: "Code on Wages, 2019", sec: "s.17 r/w OSH Rules",
      exposure: 20000,
      plain: "Full and final settlement for exited contract workers is running beyond the two working day limit.",
      legal: "Final dues on resignation, termination or completion of the engagement must be settled within two working days. This applies to contract workers on the same footing as anyone else.",
      fix: "Build the settlement into the exit process rather than the next payroll cycle.",
    });
  }

  /* CL-11 documents */
  const missing = DOCUMENTS.filter(
    (d) => d.critical && (c.docs[d.id] || "Pending") === "Pending");
  if (missing.length) {
    add({
      code: "CL-11", title: "Mandatory documents not on file",
      sev: missing.length > 4 ? "High" : "Medium",
      act: "Occupational Safety, Health and Working Conditions Code, 2020", sec: "Ch. XI; OSH Rules",
      exposure: missing.length * 5000,
      plain: `${missing.length} document${missing.length === 1 ? "" : "s"} marked mandatory ${missing.length === 1 ? "is" : "are"} still pending: ${missing.slice(0, 4).map((d) => d.doc.split(",")[0].toLowerCase()).join("; ")}${missing.length > 4 ? "; and others" : ""}.`,
      legal: "The principal employer's liability for a contractor's default is established by statute. A file that cannot show what was verified and when leaves no defence at all when the default surfaces.",
      fix: "Close the pending items before the next billing cycle and make document currency a condition of the running bill.",
    });
  }

  const penalty = F.reduce((s, f) =>
    s + ({ Critical: 28, High: 16, Medium: 8, Low: 3 }[f.sev] || 0), 0);
  const compliance = Math.max(0, 100 - penalty);
  const band = compliance >= 90 ? "Very Low" : compliance >= 75 ? "Low"
    : compliance >= 55 ? "Medium" : compliance >= 35 ? "High" : "Critical";

  const docStats = DOCUMENTS.reduce((a, d) => {
    const st = c.docs[d.id] || "Pending";
    a[st] = (a[st] || 0) + 1;
    return a;
  }, {});

  return {
    ...c, findings: F, compliance, risk: 100 - compliance, band,
    needsLicence, docStats,
    exposure: F.reduce((s, f) => s + (f.exposure || 0), 0),
    docsPending: DOCUMENTS.filter((d) => (c.docs[d.id] || "Pending") === "Pending").length,
    docsCriticalPending: missing.length,
  };
}

export function auditContractors(list, P) {
  return list.map((c) => auditContractor(c, P));
}

export function contractSummary(audited) {
  const all = audited.flatMap((c) => c.findings);
  return {
    contractors: audited.length,
    workers: audited.reduce((s, c) => s + c.workers, 0),
    findings: all.length,
    critical: all.filter((f) => f.sev === "Critical").length,
    exposure: audited.reduce((s, c) => s + c.exposure, 0),
    score: audited.length
      ? Math.round(audited.reduce((s, c) => s + c.compliance, 0) / audited.length)
      : 100,
    unlicensed: audited.filter((c) => c.needsLicence && !c.licenceNo).length,
    docsPending: audited.reduce((s, c) => s + c.docsPending, 0),
  };
}

/* ============================================================================
   STATUTORY RETURNS — parsing and reconciliation.

   Two files come in:
     PF ECR   the electronic challan cum return text file, 11 fields per line
              separated by #~#, or a CSV carrying the same columns
     ESIC MC  the monthly contribution file, IP number and wages per line

   Reconciliation is the point of the exercise. A salary sheet that audits
   clean still means nothing if the money never reached the challan, and an
   inspector reads the return, not the sheet.
   ========================================================================== */

import { inr, r0 } from "./engine.js";

const num = (v) => {
  const n = Number(String(v ?? "").replace(/[₹,\s]/g, ""));
  return Number.isFinite(n) ? n : 0;
};
const clean = (v) => String(v ?? "").trim();
const normName = (s) =>
  String(s || "").toUpperCase().replace(/[^A-Z ]/g, "").replace(/\s+/g, " ").trim();

/* --------------------------------------------------------------------------
   PF ECR
   Field order in the standard file:
   UAN | Name | Gross wages | EPF wages | EPS wages | EDLI wages |
   EPF contribution | EPS contribution | EPF-EPS difference | NCP days | Refund
   -------------------------------------------------------------------------- */

export function parseEcr(text) {
  const lines = String(text).trim().split(/\r?\n/).filter((l) => l.trim());
  if (!lines.length) return { rows: [], format: "empty", errors: ["The file is empty."] };

  const errors = [];
  let rows = [];
  let format;

  if (lines[0].includes("#~#")) {
    format = "ECR 2.0 text";
    rows = lines.map((l, i) => {
      const f = l.split("#~#").map(clean);
      if (f.length < 10) {
        errors.push(`Line ${i + 1} has ${f.length} fields, expected 11.`);
        return null;
      }
      return {
        uan: f[0], name: f[1], grossWages: num(f[2]), epfWages: num(f[3]),
        epsWages: num(f[4]), edliWages: num(f[5]), epfContri: num(f[6]),
        epsContri: num(f[7]), diffContri: num(f[8]), ncpDays: num(f[9]),
        refund: num(f[10]),
      };
    }).filter(Boolean);
  } else {
    format = "CSV";
    const head = lines[0].split(",").map((h) => clean(h).toLowerCase().replace(/[^a-z]/g, ""));
    const idx = (...names) => {
      for (const n of names) {
        const i = head.indexOf(n);
        if (i >= 0) return i;
      }
      return -1;
    };
    const map = {
      uan: idx("uan", "uannumber"), name: idx("name", "membername", "employeename"),
      grossWages: idx("grosswages", "gross"), epfWages: idx("epfwages", "pfwages"),
      epsWages: idx("epswages"), edliWages: idx("edliwages"),
      epfContri: idx("epfcontri", "epfcontribution", "eeshare", "employeeshare"),
      epsContri: idx("epscontri", "epscontribution"),
      diffContri: idx("diffcontri", "epfepsdiff", "ershare", "employershare"),
      ncpDays: idx("ncpdays", "ncp"), refund: idx("refund"),
    };
    if (map.uan < 0 && map.name < 0)
      errors.push("No UAN or name column found. The file cannot be matched to the register.");
    rows = lines.slice(1).map((l) => {
      const c = l.split(",").map(clean);
      const g = (k) => (map[k] >= 0 ? c[map[k]] : "");
      return {
        uan: g("uan"), name: g("name"), grossWages: num(g("grossWages")),
        epfWages: num(g("epfWages")), epsWages: num(g("epsWages")),
        edliWages: num(g("edliWages")), epfContri: num(g("epfContri")),
        epsContri: num(g("epsContri")), diffContri: num(g("diffContri")),
        ncpDays: num(g("ncpDays")), refund: num(g("refund")),
      };
    }).filter((r) => r.uan || r.name);
  }

  const totals = rows.reduce((t, r) => ({
    members: t.members + 1,
    epfWages: t.epfWages + r.epfWages,
    epfContri: t.epfContri + r.epfContri,
    epsContri: t.epsContri + r.epsContri,
    diffContri: t.diffContri + r.diffContri,
  }), { members: 0, epfWages: 0, epfContri: 0, epsContri: 0, diffContri: 0 });

  return { rows, format, errors, totals };
}

/* --------------------------------------------------------------------------
   ESIC monthly contribution file
   IP number | IP name | Days worked | Total monthly wages | Reason code |
   Last working day
   -------------------------------------------------------------------------- */

export function parseEsic(text) {
  const lines = String(text).trim().split(/\r?\n/).filter((l) => l.trim());
  if (!lines.length) return { rows: [], format: "empty", errors: ["The file is empty."] };

  const errors = [];
  const sep = lines[0].includes("\t") ? "\t" : ",";
  const head = lines[0].split(sep).map((h) => clean(h).toLowerCase().replace(/[^a-z]/g, ""));
  const looksLikeHeader = head.some((h) => h.includes("ip") || h.includes("name") || h.includes("wage"));

  const idx = (...names) => {
    for (const n of names) {
      const i = head.indexOf(n);
      if (i >= 0) return i;
    }
    return -1;
  };
  const map = looksLikeHeader
    ? {
        ip: idx("ipnumber", "ip", "insurancenumber"),
        name: idx("ipname", "name", "employeename"),
        days: idx("noofdays", "days", "daysworked", "workingdays"),
        wages: idx("totalmonthlywages", "wages", "monthlywages", "grosswages"),
        reason: idx("reasoncode", "reason"),
        lastDay: idx("lastworkingday", "lastday"),
      }
    : { ip: 0, name: 1, days: 2, wages: 3, reason: 4, lastDay: 5 };

  if (map.ip < 0 && map.name < 0)
    errors.push("No insurance number or name column found. The file cannot be matched to the register.");

  const body = looksLikeHeader ? lines.slice(1) : lines;
  const rows = body.map((l) => {
    const c = l.split(sep).map(clean);
    const g = (k) => (map[k] >= 0 ? c[map[k]] : "");
    return {
      ip: g("ip"), name: g("name"), days: num(g("days")),
      wages: num(g("wages")), reason: g("reason"), lastDay: g("lastDay"),
    };
  }).filter((r) => r.ip || r.name);

  const totals = rows.reduce((t, r) => ({
    members: t.members + 1,
    wages: t.wages + r.wages,
  }), { members: 0, wages: 0 });

  return { rows, format: looksLikeHeader ? "CSV with header" : "CSV positional", errors, totals };
}

/* --------------------------------------------------------------------------
   Matching. UAN or insurance number first; name only as a fallback, and the
   fallback is reported so the auditor knows the match was soft.
   -------------------------------------------------------------------------- */

function matchRows(employees, rows, idField, rowIdField) {
  const byId = new Map();
  const byName = new Map();
  rows.forEach((r) => {
    if (r[rowIdField]) byId.set(clean(r[rowIdField]), r);
    const n = normName(r.name);
    if (n && !byName.has(n)) byName.set(n, r);
  });

  const used = new Set();
  const pairs = employees.map((e) => {
    let row = null, how = null;
    const id = clean(e[idField]);
    if (id && byId.has(id)) { row = byId.get(id); how = "identifier"; }
    else {
      const n = normName(e.name);
      if (n && byName.has(n)) { row = byName.get(n); how = "name"; }
    }
    if (row) used.add(row);
    return { e, row, how };
  });

  const orphans = rows.filter((r) => !used.has(r));
  return { pairs, orphans };
}

/* --------------------------------------------------------------------------
   Reconciliation
   -------------------------------------------------------------------------- */

const TOL = 2; // rupees

export function reconcile(audited, ecr, esic, P) {
  const extras = {};
  const push = (id, f) => { (extras[id] = extras[id] || []).push(f); };
  const summary = { pf: null, esi: null };
  const orphanRows = { pf: [], esi: [] };

  /* ---------------------------------------------------------------- PF ---*/
  if (ecr?.rows?.length) {
    const covered = audited.filter((e) => e.type !== "Apprentice");
    const { pairs, orphans } = matchRows(covered, ecr.rows, "uan", "uan");
    orphanRows.pf = orphans;

    let matched = 0, softMatched = 0, wageGap = 0, contriGap = 0;

    pairs.forEach(({ e, row, how }) => {
      const pfBase = Math.min(e.wages, P.pfCeiling);
      const dueContri = r0((pfBase * P.pfRateEmployee) / 100);

      if (!row) {
        push(e.id, {
          code: "RC-30", title: "Employee absent from the provident fund return",
          sev: "Critical", act: "Code on Social Security, 2020", sec: "s.16 r/w s.42",
          computed: dueContri, paid: 0, delta: dueContri,
          exposure: dueContri * 2 * 12 * 1.25,
          plain: `The salary sheet shows a provident fund deduction of ${inr(e.pfEmp)} but no member line appears in the electronic challan cum return for this period.`,
          legal: "A deduction made and not remitted is not merely a contribution default. Amounts deducted from wages and retained attract interest under s.42, damages, and personal liability for the officers responsible.",
          fix: `Trace the deduction of ${inr(e.pfEmp)}, remit it with interest, and file a supplementary return for this member.`,
        });
        return;
      }
      matched++;
      if (how === "name") softMatched++;

      if (Math.abs(row.epfWages - pfBase) > TOL) {
        const gap = pfBase - row.epfWages;
        wageGap += Math.max(0, gap);
        push(e.id, {
          code: "RC-31", title: "Provident fund wages in the return differ from the salary sheet",
          sev: Math.abs(gap) / Math.max(pfBase, 1) > 0.1 ? "High" : "Medium",
          act: "Code on Social Security, 2020", sec: "s.16 r/w s.2(88)",
          computed: pfBase, paid: row.epfWages, delta: Math.abs(gap),
          exposure: Math.max(0, gap) * 0.24 * 12,
          plain: `The return declares provident fund wages of ${inr(row.epfWages)} against ${inr(pfBase)} computed from the salary sheet under the s.2(88) definition.`,
          legal: "The wage figure declared in the return is the figure the authority will test. A return filed on a lower base than the salary sheet supports is the most common trigger for an inquiry under s.125.",
          fix: `Refile this member on wages of ${inr(pfBase)} and remit the difference in contribution with interest.`,
        });
      }

      if (Math.abs(row.epfContri - e.pfEmp) > TOL) {
        contriGap += e.pfEmp - row.epfContri;
        push(e.id, {
          code: "RC-32", title: "Contribution remitted differs from the amount deducted",
          sev: row.epfContri < e.pfEmp ? "Critical" : "Medium",
          act: "Code on Social Security, 2020", sec: "s.16; s.42",
          computed: e.pfEmp, paid: row.epfContri, delta: Math.abs(e.pfEmp - row.epfContri),
          exposure: Math.abs(e.pfEmp - row.epfContri) * 12 * 1.25,
          plain: `${inr(e.pfEmp)} was deducted from wages but ${inr(row.epfContri)} appears in the return.`,
          legal: row.epfContri < e.pfEmp
            ? "The shortfall is money deducted from an employee and not deposited. This is the most serious category of default under the Code and is not cured by a later payment alone."
            : "Remittance above the amount deducted usually points to a mismatch between the payroll and the return rather than a genuine excess, and should be reconciled before the annual account is closed.",
          fix: "Reconcile the payroll register against the challan line by line for this member and correct whichever record is wrong.",
        });
      }

      const absent = Math.max(0, e.daysInMonth - e.daysPresent);
      if (Math.abs(row.ncpDays - absent) > 1) {
        push(e.id, {
          code: "RC-33", title: "Non-contributory days do not match the attendance record",
          sev: "Medium", act: "Code on Social Security, 2020", sec: "s.16; EPF Scheme para 30",
          computed: absent, paid: row.ncpDays, delta: Math.abs(row.ncpDays - absent),
          exposure: 6000,
          plain: `The return shows ${row.ncpDays} non-contributory days against ${absent} days absent in the muster roll.`,
          legal: "Non-contributory days reduce the wage base declared. Where they exceed the absence the register supports, the effect is an understated contribution.",
          fix: "Align the non-contributory day field with the attendance record and refile if the contribution changes.",
        });
      }
    });

    const sheetContri = covered.reduce((s, e) => s + e.pfEmp, 0);
    summary.pf = {
      members: ecr.rows.length,
      matched, softMatched,
      missing: pairs.filter((p) => !p.row).length,
      orphans: orphans.length,
      returnWages: ecr.totals.epfWages,
      returnContri: ecr.totals.epfContri,
      sheetContri,
      variance: sheetContri - ecr.totals.epfContri,
      wageGap, contriGap,
    };
  }

  /* --------------------------------------------------------------- ESI ---*/
  if (esic?.rows?.length) {
    const covered = audited.filter(
      (e) => e.type !== "Apprentice" &&
        e.gross - e.otPaid <= (e.disability ? P.esicWageLimitDisability : P.esicWageLimit));
    const { pairs, orphans } = matchRows(covered, esic.rows, "esicNo", "ip");
    orphanRows.esi = orphans;

    let matched = 0, softMatched = 0;

    pairs.forEach(({ e, row, how }) => {
      const base = P.esicBase === "gross" ? e.gross : e.wages;
      const due = r0((base * P.esicRateEmployee) / 100);

      if (!row) {
        push(e.id, {
          code: "RC-35", title: "Insured person absent from the contribution return",
          sev: "Critical", act: "Code on Social Security, 2020", sec: "s.29 r/w s.31",
          computed: due, paid: 0, delta: due,
          exposure: (due + r0((base * P.esicRateEmployer) / 100)) * 12 * 1.12,
          plain: "The employee is within the wage limit and appears in the salary sheet, but no line appears in the contribution return for this period.",
          legal: "An omission from the return leaves the employee without medical or cash benefit cover for the entire benefit period that follows, and the establishment carries the cost of any claim that arises.",
          fix: "File a supplementary return for this insured person and remit both shares with interest.",
        });
        return;
      }
      matched++;
      if (how === "name") softMatched++;

      if (Math.abs(row.wages - base) > TOL) {
        push(e.id, {
          code: "RC-36", title: "Wages declared in the contribution return differ from the salary sheet",
          sev: row.wages < base ? "High" : "Low",
          act: "Code on Social Security, 2020", sec: "s.29 r/w s.2(88)",
          computed: base, paid: row.wages, delta: Math.abs(row.wages - base),
          exposure: Math.abs(row.wages - base) * 0.04 * 12,
          plain: `The return declares ${inr(row.wages)} against ${inr(base)} computed from the salary sheet on the ${P.esicBase === "gross" ? "gross" : "s.2(88) wage"} basis.`,
          legal: "Contribution is payable on the wages defined in the Code. A declared figure below the sheet understates both shares and is visible on any comparison of the return against the wage register.",
          fix: `Correct the declared wages to ${inr(base)} and remit the difference in the current contribution period.`,
        });
      }

      const paidDays = Math.min(e.daysPresent, e.daysInMonth);
      if (row.days > 0 && Math.abs(row.days - paidDays) > 1) {
        push(e.id, {
          code: "RC-37", title: "Days declared in the contribution return do not match attendance",
          sev: "Low", act: "Code on Social Security, 2020", sec: "s.29",
          computed: paidDays, paid: row.days, delta: Math.abs(row.days - paidDays),
          exposure: 3000,
          plain: `The return declares ${row.days} days against ${paidDays} paid days in the register.`,
          legal: "The number of days determines benefit eligibility for the insured person, so a mismatch can cost the employee a claim even where the money was paid correctly.",
          fix: "Align the days field with the muster roll before the contribution period closes.",
        });
      }
    });

    const sheetWages = covered.reduce(
      (s, e) => s + (P.esicBase === "gross" ? e.gross : e.wages), 0);
    summary.esi = {
      members: esic.rows.length,
      matched, softMatched,
      missing: pairs.filter((p) => !p.row).length,
      orphans: orphans.length,
      returnWages: esic.totals.wages,
      sheetWages,
      variance: sheetWages - esic.totals.wages,
    };
  }

  return { extras, summary, orphanRows };
}

/**
 * Members present in a return with no matching payroll record. These do not
 * attach to an employee, so they are reported at establishment level.
 */
export function orphanFindings(orphanRows) {
  const out = [];
  if (orphanRows.pf?.length) {
    out.push({
      code: "RC-34", title: "Members in the provident fund return with no payroll record",
      sev: "High", act: "Code on Social Security, 2020", sec: "s.16; s.125",
      count: orphanRows.pf.length,
      rows: orphanRows.pf,
      plain: `${orphanRows.pf.length} member${orphanRows.pf.length === 1 ? "" : "s"} appear in the return but not in the salary sheet for this period.`,
      legal: "Contributions remitted for a person the wage register does not carry point either to an employee omitted from the sheet or to a member who has left and was not exited. Both are findings; the first is the more serious.",
      fix: "Identify each member, either restore the omitted payroll record or mark the date of exit in the return.",
    });
  }
  if (orphanRows.esi?.length) {
    out.push({
      code: "RC-38", title: "Insured persons in the return with no payroll record",
      sev: "Medium", act: "Code on Social Security, 2020", sec: "s.29",
      count: orphanRows.esi.length,
      rows: orphanRows.esi,
      plain: `${orphanRows.esi.length} insured person${orphanRows.esi.length === 1 ? "" : "s"} appear in the contribution return but not in the salary sheet.`,
      legal: "A contribution return carrying people the wage register does not is difficult to explain in an inspection and suggests the two records are maintained independently.",
      fix: "Reconcile the insured person list against the current headcount and record exits with the last working day.",
    });
  }
  return out;
}

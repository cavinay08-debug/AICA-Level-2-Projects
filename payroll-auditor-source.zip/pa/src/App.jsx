import React, { useState, useMemo, useRef, useEffect } from "react";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, CartesianGrid,
} from "recharts";
import {
  ShieldAlert, FileText, Table2, SlidersHorizontal, Upload, Download, Sparkles,
  X, ChevronRight, ArrowRight, AlertTriangle, CheckCircle2, Search, Send, Printer,
  FolderUp, HardHat, Plus, RotateCcw, Trash2,
} from "lucide-react";

import { CSS } from "./styles.js";
import {
  DEFAULT_PARAMS, REGISTER, E, runAudit, optimise, inr, pct, r0, SEV,
  MONTHS, FY_LIST, periodKey, periodLabel, withPeriod, contributionPeriod,
  finalise, toObservation, dismissKey,
  sanitizeParams, sanitizePeriods, sanitizeEmployee,
  parseSalarySheet, arithmeticFindings, SHEET_COLUMNS,
} from "./engine.js";
import { readReturnPdf, pfRowsForRecon, esicRowsForRecon } from "./pdfparse.js";
import { crossCheckReturns } from "./crossreturns.js";
import { analyse, query } from "./analyser.js";
import { buildHtml, exportPdf, exportDocx, exportHtml, EMPTY_AUDITOR } from "./report.js";
import { parseEcr, parseEsic, reconcile, orphanFindings } from "./reconcile.js";
import {
  auditContractors, contractSummary, SAMPLE_CONTRACTORS, newContractor, DOCUMENTS,
} from "./contract.js";
import {
  FileDrop, ReconSummary, ObservationForm, DismissForm, ContractorCard,
} from "./panels.jsx";

const SEV_COLOR = {
  Critical: "var(--crit)", High: "var(--high)", Medium: "var(--med)", Low: "var(--low)",
};
const BAND_COLOR = { ...SEV_COLOR, "Very Low": "var(--ok)" };

/* ---------------------------------------------------------------- pieces */

const Chip = ({ children, color }) => (
  <span className="chip" style={{ color }}><span className="dot" /> {children}</span>
);

const Card = ({ title, right, children, pad = true }) => (
  <div className="card">
    {title && (
      <div className="card-h">
        <span className="card-t">{title}</span>
        {right}
      </div>
    )}
    <div className={pad ? "card-b" : ""}>{children}</div>
  </div>
);

function Finding({ f, prefix }) {
  return (
    <div className="find">
      <div className="find-margin">
        <div className="find-act">{f.act}</div>
        <div className="find-sec mono">{f.sec}</div>
        <div className="find-sec mono" style={{ marginTop: 10, color: "var(--ink-3)" }}>{f.code}</div>
      </div>
      <div className="find-body">
        <div className="find-t">
          {f.title}
          <Chip color={SEV_COLOR[f.sev]}>{f.sev}</Chip>
        </div>
        <p className="find-p">{prefix ? prefix + " " : ""}{f.plain}</p>
        {f.delta > 0 && (
          <div className="delta">
            <div>Computed<b>{f.computed == null ? "—" : inr(f.computed)}</b></div>
            <div>Recorded<b>{f.paid == null ? "—" : inr(f.paid)}</b></div>
            <div>Difference<b style={{ color: "var(--crit)" }}>{inr(f.delta)}</b></div>
            {f.exposure > 0 && <div>Est. exposure<b>{inr(f.exposure)}</b></div>}
          </div>
        )}
        <div className="find-legal serif">{f.legal}</div>
        <div className="find-fix"><b>Correction. </b>{f.fix}</div>
      </div>
    </div>
  );
}

/* Wage computation under s.2(y), shown as arithmetic an auditor can follow. */
function WageBreakdown({ e }) {
  const w = e.w;
  const seg = [
    { k: "Basic + DA", v: w.included, c: "var(--seal)" },
    { k: "Allowances", v: w.excludedAllowances, c: "#B9BCC4" },
    { k: "Overtime", v: w.excludedOt, c: "#CFD2D8" },
    { k: "Employer PF", v: w.excludedErPf, c: "#DDE0E4" },
    { k: "Bonus (1/12)", v: w.excludedBonus, c: "#E7E9EC" },
  ].filter((s) => s.v > 0.5);

  return (
    <>
      <div className="bar">
        {seg.map((s) => (
          <div key={s.k} title={`${s.k}: ${inr(s.v)}`}
            style={{ flex: s.v, background: s.c }} />
        ))}
      </div>
      <div style={{ display: "flex", gap: 14, flexWrap: "wrap", fontSize: 11, color: "var(--ink-2)" }}>
        {seg.map((s) => (
          <span key={s.k}>
            <span style={{ display: "inline-block", width: 8, height: 8, background: s.c, marginRight: 5 }} />
            {s.k} {inr(s.v)}
          </span>
        ))}
      </div>
      <div className="hr" />
      {[
        ["Total remuneration", w.remuneration],
        [`Statutory floor (50%)`, w.floor],
        ["Excluded components", w.excluded],
        ["Added back under the proviso", w.addBack],
      ].map(([k, v]) => (
        <div className="stat-line" key={k}><span>{k}</span><span>{inr(v)}</span></div>
      ))}
      <div className="stat-line" style={{ fontWeight: 600, borderBottom: 0 }}>
        <span>Wages under s.2(y)</span><span>{inr(w.wages)}</span>
      </div>
      <div style={{ fontSize: 11.5, color: w.compliantStructure ? "var(--ok)" : "var(--crit)", marginTop: 7 }}>
        {w.compliantStructure
          ? `Basic and DA are ${pct(w.includedShare)} of remuneration — the structure clears the floor.`
          : `Basic and DA are ${pct(w.includedShare)} of remuneration. ${inr(w.addBack)} is deemed to be wages.`}
      </div>
    </>
  );
}

function StructurePlan({ e, P }) {
  const o = useMemo(() => optimise(e, P), [e, P]);
  const row = (l, a, b) => (
    <div className="stat-line" key={l}><span>{l}</span><span>{inr(a)}</span></div>
  );
  return (
    <>
      <div className="struct">
        <div className="struct-col now">
          <div className="struct-k">As paid — {pct(o.current.share)} wages</div>
          {row("Basic", o.current.basic)}
          {row("Dearness allowance", o.current.da)}
          {row("House rent allowance", o.current.hra)}
          {row("Special and other", o.current.special)}
          <div className="stat-line" style={{ fontWeight: 600, borderBottom: 0 }}>
            <span>Wages s.2(y)</span><span>{inr(o.current.wages)}</span>
          </div>
        </div>
        <div className="struct-arrow"><ArrowRight size={14} /></div>
        <div className="struct-col next">
          <div className="struct-k">Proposed — {pct(o.proposed.share)} wages</div>
          {row("Basic", o.proposed.basic)}
          {row("Dearness allowance", o.proposed.da)}
          {row("House rent allowance", o.proposed.hra)}
          {row("Special and other", o.proposed.special)}
          <div className="stat-line" style={{ fontWeight: 600, borderBottom: 0 }}>
            <span>Wages s.2(y)</span><span>{inr(o.proposed.wages)}</span>
          </div>
        </div>
      </div>
      <div className="impact">
        <div><div className="k">Payable cost</div><div className="v">unchanged</div></div>
        <div><div className="k">PF each side</div>
          <div className="v" style={{ color: o.pfDelta > 0 ? "var(--high)" : "var(--ink)" }}>
            {o.pfDelta > 0 ? "+" : ""}{inr(o.pfDelta)}</div></div>
        <div><div className="k">Take-home</div>
          <div className="v" style={{ color: o.takeHomeDelta < 0 ? "var(--high)" : "var(--ok)" }}>
            {o.takeHomeDelta > 0 ? "+" : ""}{inr(o.takeHomeDelta)}</div></div>
        <div><div className="k">Gratuity accrual</div>
          <div className="v">{o.gratuityAccrualDelta > 0 ? "+" : ""}{inr(o.gratuityAccrualDelta)}</div></div>
      </div>
      <div style={{ fontSize: 12, color: "var(--ink-2)", marginTop: 9, lineHeight: 1.55 }}>
        The employer's payable cost is held constant — only the composition moves. The provident fund
        rises on both sides because the wage base is larger, which is what reduces take-home while
        raising the retirement corpus and the gratuity base.
        {o.minWage > 0 && ` The proposed wage figure also clears the notified minimum of ${inr(o.minWage)}.`}
      </div>
    </>
  );
}

/* ---------------------------------------------------------------- drawer */

function Drawer({ emp, P, onClose }) {
  if (!emp) return null;
  const earn = [
    ["Basic", emp.basic], ["Dearness allowance", emp.da], ["House rent allowance", emp.hra],
    ["Special allowance", emp.special], ["Overtime", emp.otPaid], ["Gross earnings", emp.gross],
  ];
  const ded = [
    ["Provident fund", emp.pfEmp], ["Employees' state insurance", emp.esicEmp],
    ["Professional tax", emp.pt], ["Advance", emp.advance], ["Other recovery", emp.otherDed],
    ["Total deductions", emp.deductions], ["Net payable", emp.net],
  ];
  return (
    <>
      <div className="scrim" onClick={onClose} />
      <aside className="drawer" role="dialog" aria-label={`Findings for ${emp.name}`}>
        <div className="drawer-h">
          <div style={{ flex: 1 }}>
            <div className="mono" style={{ fontSize: 11, color: "#9AA3B2", letterSpacing: ".08em" }}>{emp.id}</div>
            <div style={{ fontSize: 17, fontWeight: 600, marginTop: 3 }}>{emp.name}</div>
            <div style={{ fontSize: 12, color: "#9AA3B2", marginTop: 3 }}>
              {emp.desig} · {emp.dept} · {emp.type} · {emp.skill} · Zone {emp.zone}
            </div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div className="mono" style={{ fontSize: 26, fontWeight: 600 }}>{emp.risk}</div>
            <div style={{ fontSize: 9, letterSpacing: ".12em", textTransform: "uppercase", color: "#9AA3B2" }}>
              {emp.band} risk
            </div>
          </div>
          <button className="iconbtn" onClick={onClose} aria-label="Close"><X size={15} /></button>
        </div>

        <div style={{ padding: 18 }}>
          <div className="grid" style={{ gridTemplateColumns: "1fr 1fr" }}>
            <Card title="Earnings">
              {earn.map(([k, v], i) => (
                <div className="stat-line" key={k}
                  style={i === earn.length - 1 ? { fontWeight: 600, borderBottom: 0 } : {}}>
                  <span>{k}</span><span>{inr(v)}</span>
                </div>
              ))}
            </Card>
            <Card title="Deductions and net">
              {ded.map(([k, v], i) => (
                <div className="stat-line" key={k} style={i >= ded.length - 2 ? { fontWeight: 600 } : {}}>
                  <span>{k}</span><span>{inr(v)}</span>
                </div>
              ))}
            </Card>
          </div>

          <div style={{ marginTop: 14 }}>
            <Card title="Wage computation — Code on Wages s.2(y)">
              <WageBreakdown e={emp} />
            </Card>
          </div>

          {!emp.w.compliantStructure && emp.type !== "Apprentice" && (
            <div style={{ marginTop: 14 }}>
              <Card title="Recommended structure">
                <StructurePlan e={emp} P={P} />
              </Card>
            </div>
          )}

          <div style={{ display: "flex", alignItems: "baseline", gap: 10, margin: "20px 0 10px" }}>
            <span className="card-t">Findings</span>
            <span className="mono" style={{ fontSize: 11, color: "var(--ink-3)" }}>
              {emp.findings.length} raised · {inr(emp.exposure)} estimated exposure
            </span>
          </div>
          <div className="grid">
            {emp.findings.length === 0 ? (
              <div className="card card-b" style={{ display: "flex", gap: 9, alignItems: "center", fontSize: 13 }}>
                <CheckCircle2 size={16} color="var(--ok)" /> No exception raised against this record.
              </div>
            ) : emp.findings.map((f) => <Finding key={f.code} f={f} />)}
          </div>
        </div>
      </aside>
    </>
  );
}

/* ------------------------------------------------------------------- app */

const SUGGESTIONS = [
  "Show all PF violations",
  "Employees below minimum wages",
  "Which structures fail the 50% test",
  "Employees without UAN",
  "Show delayed salary payment",
  "Critical risk",
];

const DEFAULT_FY = "2025-26";
const DEFAULT_MONTH = "March";
const SEED_KEY = periodKey(DEFAULT_FY, DEFAULT_MONTH);

export default function App() {
  const [params, setParams] = useState(DEFAULT_PARAMS);
  const [fy, setFy] = useState(DEFAULT_FY);
  const [month, setMonth] = useState(DEFAULT_MONTH);
  // Uploaded data lives per period: salary sheet, PF return, insurance return.
  const [periods, setPeriods] = useState({ [SEED_KEY]: { register: REGISTER, ecrText: "", esicText: "" } });
  const [sheetMeta, setSheetMeta] = useState(null);
  const [reading, setReading] = useState("");
  const [contractors, setContractors] = useState(SAMPLE_CONTRACTORS);
  const [observations, setObservations] = useState([]);
  const [dismissed, setDismissed] = useState({});
  const [auditor, setAuditor] = useState(EMPTY_AUDITOR);

  const [tab, setTab] = useState("overview");
  const [sel, setSel] = useState(null);
  const [q, setQ] = useState("");
  const [bandFilter, setBandFilter] = useState("All");
  const [ask, setAsk] = useState("");
  const [answer, setAnswer] = useState(null);
  const [busy, setBusy] = useState("");
  const [toast, setToast] = useState("");
  const [showObsForm, setShowObsForm] = useState(false);
  const [dismissing, setDismissing] = useState(null);
  const [restored, setRestored] = useState(false);
  const fileRef = useRef(null);

  const key = periodKey(fy, month);
  const slot = periods[key] || { register: [], ecrText: "", esicText: "", pfPdf: null, esicPdf: null };
  const register = slot.register || [];
  const P = useMemo(() => withPeriod(params, fy, month), [params, fy, month]);

  /* ---- load and save local state ---------------------------------------*/
  useEffect(() => {
    let live = true;
    (async () => {
      let saved = null;
      try {
        saved = await window.app?.loadState?.();
      } catch {
        // Saved state could not be read. Start clean rather than fail to load.
      }
      if (!live || !saved) { setRestored(true); return; }
      // Repair anything JSON mangled or an older build wrote differently.
      try {
        setParams(sanitizeParams(saved.params));
        const per = sanitizePeriods(saved.periods);
        if (Object.keys(per).length) setPeriods(per);
        if (Array.isArray(saved.contractors) && saved.contractors.length)
          setContractors(saved.contractors.filter((c) => c && typeof c === "object")
            .map((c) => ({ ...newContractor(), ...c, docs: c.docs || {} })));
        if (Array.isArray(saved.observations)) setObservations(saved.observations.filter(Boolean));
        if (saved.dismissed && typeof saved.dismissed === "object") setDismissed(saved.dismissed);
        if (saved.auditor) setAuditor({ ...EMPTY_AUDITOR, ...saved.auditor });
        if (FY_LIST.includes(saved.fy)) setFy(saved.fy);
        if (MONTHS.includes(saved.month)) setMonth(saved.month);
      } catch {
        // A state file too damaged to repair. Start from defaults.
      }
      setRestored(true);
    })();
    return () => { live = false; };
  }, []);

  useEffect(() => {
    if (!restored || !window.app?.saveState) return;
    const t = setTimeout(() => {
      Promise.resolve(
        window.app.saveState({ params, periods, contractors, observations, dismissed, auditor, fy, month })
      ).catch(() => { /* disk unavailable — keep working in memory */ });
    }, 600);
    return () => clearTimeout(t);
  }, [restored, params, periods, contractors, observations, dismissed, auditor, fy, month]);

  /* ---- statutory returns for this period -------------------------------*/
  // A parsed portal PDF takes precedence over a raw upload for the same period.
  const ecr = useMemo(
    () => (slot.pfPdf ? pfRowsForRecon(slot.pfPdf) : slot.ecrText ? parseEcr(slot.ecrText) : null),
    [slot.pfPdf, slot.ecrText]);
  const esic = useMemo(
    () => (slot.esicPdf ? esicRowsForRecon(slot.esicPdf) : slot.esicText ? parseEsic(slot.esicText) : null),
    [slot.esicPdf, slot.esicText]);

  // The two returns are compared with each other, which works even with no
  // salary sheet loaded.
  const cross = useMemo(
    () => (slot.pfPdf || slot.esicPdf
      ? crossCheckReturns({ pf: slot.pfPdf, esic: slot.esicPdf, register, P })
      : null),
    [slot.pfPdf, slot.esicPdf, register, P]);

  const baseAudit = useMemo(() => runAudit(register, P), [register, P]);
  const recon = useMemo(
    () => (register.length && (ecr || esic) ? reconcile(baseAudit, ecr, esic, P) : null),
    [baseAudit, ecr, esic, P, register.length]);
  const orphans = useMemo(() => (recon ? orphanFindings(recon.orphanRows) : []), [recon]);

  const obsFindings = useMemo(
    () => observations.map((o, i) => toObservation(o, i + 1)), [observations]);

  const audited = useMemo(() => {
    const arith = arithmeticFindings(sheetMeta?.arithmetic || []);
    const extras = { ...(recon?.extras || {}) };
    for (const [id, list] of Object.entries(arith))
      extras[id] = [...(extras[id] || []), ...list];
    return finalise(baseAudit, { extras, custom: obsFindings, dismissed });
  }, [baseAudit, recon, obsFindings, dismissed, sheetMeta]);

  const A = useMemo(() => analyse(audited, P), [audited, P]);

  const contractAudit = useMemo(() => auditContractors(contractors, P), [contractors, P]);
  const cSum = useMemo(() => contractSummary(contractAudit), [contractAudit]);

  /* ---- dismissed findings, for the report ------------------------------*/
  const dismissedList = useMemo(() => Object.entries(dismissed).map(([k, v]) => {
    const [empId, code] = k.split("|");
    const emp = baseAudit.find((e) => e.id === empId);
    const f = emp?.findings.find((x) => x.code === code);
    return { code, empId, empName: emp?.name || empId, title: f?.title || code, ...v };
  }), [dismissed, baseAudit]);

  const reportCtx = {
    auditor, recon, contract: contractAudit, contractSummary: cSum,
    observations: obsFindings, dismissed: dismissedList, orphans,
    cross, returns: { pf: slot.pfPdf, esic: slot.esicPdf },
  };

  const hasData = register.length > 0;

  const filtered = audited.filter(
    (e) =>
      (bandFilter === "All" || e.band === bandFilter) &&
      (q === "" ||
        [e.name, e.id, e.dept, e.desig, ...e.findings.map((f) => f.title + f.act)]
          .join(" ").toLowerCase().includes(q.toLowerCase()))
  );

  const setSlot = (patch) =>
    setPeriods((prev) => ({
      ...prev,
      [key]: { ...(prev[key] || { register: [], ecrText: "", esicText: "", pfPdf: null, esicPdf: null }), ...patch },
    }));

  /* A statutory return arrives either as a portal PDF or as the raw file.
     The PDF is read here and routed by what it turns out to be. */
  const readReturn = async (file) => {
    setReading(file.name);
    try {
      if (/\.pdf$/i.test(file.name)) {
        const parsed = await readReturnPdf(new Uint8Array(await file.arrayBuffer()));
        if (parsed.kind === "pf") setSlot({ pfPdf: parsed });
        else if (parsed.kind === "esic") setSlot({ esicPdf: parsed });
        else setToast(parsed.errors?.[0] || "This PDF was not recognised.");
        if (parsed.errors?.length && parsed.kind !== "unknown" && parsed.kind !== "empty")
          setToast(parsed.errors[0]);
      } else {
        const text = await file.text();
        if (/#~#/.test(text) || /epf/i.test(text)) setSlot({ ecrText: text });
        else setSlot({ esicText: text });
      }
    } catch (err) {
      setToast("Could not read that file: " + (err?.message || err));
    } finally {
      setReading("");
      setTimeout(() => setToast(""), 7000);
    }
  };

  const readFile = (file, cb) => {
    const r = new FileReader();
    r.onload = () => cb(String(r.result));
    r.readAsText(file);
  };

  const addObservation = (o) => {
    setObservations((prev) => [...prev, o]);
    setShowObsForm(false);
  };

  const dismissFinding = (empId, code, reason, note) => {
    setDismissed((prev) => ({ ...prev, [dismissKey(empId, code)]: { reason, note, at: new Date().toISOString() } }));
    setDismissing(null);
  };

  const restoreFinding = (k) =>
    setDismissed((prev) => { const n = { ...prev }; delete n[k]; return n; });

  const removeObservation = (i) =>
    setObservations((prev) => prev.filter((_, x) => x !== i));

  const runQuery = (text) => {
    const t = (text ?? ask).trim();
    if (!t) return;
    setAsk(t);
    setAnswer(query(t, audited, A));
  };

  const download = (name, content, type) => {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([content], { type }));
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  };

  const ecrTemplate = () => {
    const guide = [
      "PF ELECTRONIC CHALLAN CUM RETURN — accepted formats",
      "",
      "1. The standard ECR text file. One member per line, eleven fields separated by #~#:",
      "",
      "   UAN#~#MEMBER NAME#~#GROSS WAGES#~#EPF WAGES#~#EPS WAGES#~#EDLI WAGES#~#" +
        "EPF CONTRIBUTION#~#EPS CONTRIBUTION#~#EPF EPS DIFFERENCE#~#NCP DAYS#~#REFUND",
      "",
      "   Example:",
      "   100234567801#~#RAMESH PAWAR#~#31077#~#15000#~#15000#~#15000#~#1800#~#1250#~#550#~#0#~#0",
      "",
      "2. A CSV carrying the same columns with a header row. Column names are matched loosely,",
      "   so uan, name, epfwages, epfcontri, ncpdays and similar are all understood.",
      "",
      "",
      "INSURANCE MONTHLY CONTRIBUTION — accepted format",
      "",
      "   CSV with a header row:",
      "   IP Number,IP Name,No of Days,Total Monthly Wages,Reason Code,Last Working Day",
      "   3113456701,RAMESH PAWAR,26,20000,,",
      "",
      "   A file with no header is read positionally in the same column order.",
      "",
      "",
      "MATCHING",
      "",
      "   Members are matched to the salary sheet on the universal account number or the insurance",
      "   number. Where the identifier is blank on either side the match falls back to name, and",
      "   every name match is reported so it can be confirmed before you rely on it.",
    ].join("\n");
    download("statutory-return-formats.txt", guide, "text/plain");
  };

  const templateCsv = () => {
    const req = SHEET_COLUMNS.filter((c) => c.required);
    const opt = SHEET_COLUMNS.filter((c) => !c.required);
    const cols = [...req, ...opt];
    const val = (e, f) => {
      if (f === "sheetGross") return e.basic + e.da + e.hra + e.special + e.otPaid;
      if (f === "sheetDed") return e.pfEmp + e.esicEmp + e.pt + e.lwf + e.advance + e.otherDed;
      if (f === "sheetNet")
        return e.basic + e.da + e.hra + e.special + e.otPaid
          - (e.pfEmp + e.esicEmp + e.pt + e.lwf + e.advance + e.otherDed);
      if (f === "bankCredited") return e.bankCredited ? "Yes" : "No";
      return e[f] ?? "";
    };
    download("salary-sheet-template.csv",
      [cols.map((c) => c.label).join(","),
       ...REGISTER.slice(0, 6).map((e) => cols.map((c) => val(e, c.field)).join(","))].join("\n"),
      "text/csv");
  };

  const importCsv = (file) => {
    const reader = new FileReader();
    reader.onload = () => {
      const parsed = parseSalarySheet(String(reader.result));
      setSheetMeta(parsed);
      if (parsed.rows.length) { setSlot({ register: parsed.rows }); setSel(null); }
      if (parsed.errors.length) {
        setToast(parsed.errors[0]);
        setTimeout(() => setToast(""), 9000);
      }
    };
    reader.readAsText(file);
  };

  const runExport = async (kind) => {
    setBusy(kind); setToast("");
    try {
      const fn = kind === "pdf" ? exportPdf : kind === "docx" ? exportDocx : exportHtml;
      setToast(await fn(audited, A, P, reportCtx));
    } catch (err) {
      setToast("Export failed: " + (err?.message || err));
    } finally {
      setBusy("");
      setTimeout(() => setToast(""), 6000);
    }
  };

  const TABS = [
    ["overview", "Overview", ShieldAlert],
    ["documents", "Documents", FolderUp],
    ["register", "Register", Table2],
    ["analyser", "Analyser", Sparkles],
    ["findings", "Findings", AlertTriangle],
    ["contract", "Contract labour", HardHat],
    ["rules", "Statutory parameters", SlidersHorizontal],
    ["report", "Report", FileText],
  ];

  const periodsWithData = Object.entries(periods)
    .filter(([, v]) => v.register?.length).map(([k]) => k);

  return (
    <div className="app">
      <style>{CSS}</style>

      <header className="mast">
        <div className="mast-mark">AP</div>
        <div>
          <h1>Payroll Compliance Auditor</h1>
          <div className="sub">{P.establishment} · {P.location} · {P.period}</div>
        </div>
        <div className="mast-meta">
          <div><div className="meta-k">Records</div><div className="meta-v mono">{audited.length}</div></div>
          <div><div className="meta-k">Exceptions</div><div className="meta-v mono">{A.all.length}</div></div>
          <div><div className="meta-k">Score</div><div className="meta-v mono">{A.score}/100</div></div>
        </div>
      </header>

      <div className="periodbar">
        <label htmlFor="fy">Financial year</label>
        <select id="fy" value={fy} onChange={(e) => { setFy(e.target.value); setSel(null); }}>
          {FY_LIST.map((y) => <option key={y} value={y}>{y}</option>)}
        </select>
        <label htmlFor="mo" style={{ marginLeft: 8 }}>Month</label>
        <select id="mo" value={month} onChange={(e) => { setMonth(e.target.value); setSel(null); }}>
          {MONTHS.map((m) => (
            <option key={m} value={m}>
              {periodLabel(fy, m)}{periods[periodKey(fy, m)]?.register?.length ? "  \u25CF" : ""}
            </option>
          ))}
        </select>
        <span style={{ fontSize: 11, color: "#7D8595", marginLeft: 10 }}>
          Contribution period {contributionPeriod(month)}
        </span>
        <div className="pstatus">
          <span><i className="pdot" style={{ background: hasData ? "var(--ok)" : "#5A6373" }} />
            Salary sheet {hasData ? `${register.length} records` : "not loaded"}</span>
          <span><i className="pdot" style={{ background: ecr ? "var(--ok)" : "#5A6373" }} />
            PF return {ecr ? `${ecr.rows.length} members` : "not loaded"}</span>
          <span><i className="pdot" style={{ background: esic ? "var(--ok)" : "#5A6373" }} />
            Insurance {esic ? `${esic.rows.length} insured` : "not loaded"}</span>
        </div>
      </div>

      <nav className="nav">
        {TABS.map(([k, label, Icon]) => (
          <button key={k} className="tab" data-on={tab === k ? "1" : "0"} onClick={() => setTab(k)}>
            <Icon size={14} /> {label}
          </button>
        ))}
      </nav>

      <main className="wrap">
        {/* ------------------------------------------------------ overview */}
        {tab === "overview" && (
          <div className="grid">
            <div className="card">
              <div className="seal-row">
                <div className="seal-box">
                  <div className="seal-ring">
                    <div style={{ textAlign: "center" }}>
                      <div className="seal-num mono">{A.score}</div>
                      <div className="seal-lab">out of 100</div>
                    </div>
                  </div>
                  <div className="seal-cap">Compliance score</div>
                </div>
                <div>
                  <div className="kpis">
                    <div className="kpi">
                      <div className="kpi-k">Payroll audited</div>
                      <div className="kpi-v mono">{inr(A.payroll)}</div>
                      <div className="kpi-n">{audited.length} records, one wage period</div>
                    </div>
                    <div className="kpi">
                      <div className="kpi-k">Estimated exposure</div>
                      <div className="kpi-v mono" style={{ color: "var(--crit)" }}>{inr(A.exposure)}</div>
                      <div className="kpi-n">arrears, damages and penalty bands</div>
                    </div>
                    <div className="kpi">
                      <div className="kpi-k">Accrued gratuity</div>
                      <div className="kpi-v mono">{inr(A.gratuity)}</div>
                      <div className="kpi-n">liability to provide for</div>
                    </div>
                    <div className="kpi">
                      <div className="kpi-k">Structures below floor</div>
                      <div className="kpi-v mono">{A.nonCompliantStructures.length}</div>
                      <div className="kpi-n">{inr(A.addBackTotal)} a month deemed wages</div>
                    </div>
                    <div className="kpi" style={{ gridColumn: "span 4", borderBottom: 0 }}>
                      <div className="kpi-k" style={{ marginBottom: 9 }}>Exceptions by severity</div>
                      <div style={{ display: "flex", height: 26, borderRadius: 2, overflow: "hidden", border: "1px solid var(--rule)" }}>
                        {Object.keys(SEV).map((k) => {
                          const n = A.all.filter((f) => f.sev === k).length;
                          return n ? (
                            <div key={k} title={`${k}: ${n}`}
                              style={{ flex: n, background: SEV_COLOR[k], color: "#fff", fontSize: 10.5, display: "grid", placeItems: "center", fontWeight: 600 }}>
                              {k} {n}
                            </div>
                          ) : null;
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid" style={{ gridTemplateColumns: "1.15fr 1fr" }}>
              <Card title="Exposure by rule" pad={false}>
                <div style={{ padding: "14px 8px 6px" }}>
                  <ResponsiveContainer width="100%" height={230}>
                    <BarChart data={A.byRule.filter((r) => r.exposure).slice(0, 7)} layout="vertical"
                      margin={{ left: 10, right: 18 }}>
                      <CartesianGrid horizontal={false} stroke="#EDEEEA" />
                      <XAxis type="number" tick={{ fontSize: 10, fill: "#8B93A1" }}
                        tickFormatter={(v) => `${Math.round(v / 1000)}k`} />
                      <YAxis type="category" dataKey="code" width={54}
                        tick={{ fontSize: 10, fill: "#5A6373", fontFamily: "IBM Plex Mono" }} />
                      <Tooltip formatter={(v) => inr(v)}
                        labelFormatter={(l) => A.byRule.find((r) => r.code === l)?.title}
                        contentStyle={{ fontSize: 12, borderRadius: 2, border: "1px solid #D9DBD4" }} />
                      <Bar dataKey="exposure" name="Exposure" radius={[0, 2, 2, 0]}>
                        {A.byRule.filter((r) => r.exposure).slice(0, 7).map((r) => (
                          <Cell key={r.code} fill={SEV_COLOR[r.sev]} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </Card>

              <Card title="Department risk" pad={false}>
                <table>
                  <thead><tr><th>Department</th><th className="num">Staff</th><th className="num">Avg risk</th><th className="num">Exposure</th></tr></thead>
                  <tbody>
                    {A.depts.map((d) => (
                      <tr key={d.dept} onClick={() => { setTab("register"); setQ(d.dept); }}>
                        <td>{d.dept}</td>
                        <td className="num">{d.n}</td>
                        <td className="num" style={{ fontWeight: 600, color: d.risk > 45 ? "var(--crit)" : d.risk > 20 ? "var(--high)" : "var(--ok)" }}>{d.risk}</td>
                        <td className="num">{inr(d.exposure)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </Card>
            </div>

            <Card title="Largest exposures">
              <div className="grid">
                {A.byRule.filter((r) => r.exposure).slice(0, 3).map((r) => {
                  const s = A.all.find((f) => f.code === r.code);
                  return <Finding key={r.code} f={s}
                    prefix={`${r.n} employee${r.n > 1 ? "s" : ""} affected.`} />;
                })}
                {!A.byRule.length && (
                  <div style={{ fontSize: 13, color: "var(--ink-2)" }}>
                    Nothing flagged on the parameters currently configured.
                  </div>
                )}
              </div>
            </Card>
          </div>
        )}


        {/* ----------------------------------------------------- documents */}
        {tab === "documents" && (
          <div className="grid">
            <Card title={`Upload for ${P.period}`}>
              <div style={{ fontSize: 12.5, color: "var(--ink-2)", lineHeight: 1.6, marginBottom: 14 }}>
                Each period holds its own salary sheet and returns. Switch the financial year and month
                above to work on a different one — nothing is overwritten. Statutory returns can be the
                PDF downloaded from the portal; the document is read directly.
              </div>
              <div className="grid" style={{ gridTemplateColumns: "repeat(auto-fit,minmax(240px,1fr))" }}>
                <FileDrop
                  label="Salary sheet"
                  hint="CSV or tab-separated. Emp Code, Name, Dept, Skill Level, ESIC No, PF Number and the wage columns."
                  accept=".csv,.txt,.tsv"
                  loaded={hasData}
                  meta={`${register.length} records loaded`}
                  onFile={(f) => importCsv(f)}
                  onClear={() => { setSlot({ register: [] }); setSheetMeta(null); setSel(null); }}
                />
                <FileDrop
                  label="Provident fund return"
                  hint="EPFO return statement PDF, or the ECR text file."
                  accept=".pdf,.txt,.csv,.ecr"
                  loaded={!!ecr}
                  meta={slot.pfPdf
                    ? `${slot.pfPdf.rows.length} members · ${slot.pfPdf.header.establishmentId || "PDF"} · ${inr(slot.pfPdf.totals.epfContri)} employee share`
                    : ecr ? `${ecr.rows.length} members · ${ecr.format}` : ""}
                  onFile={readReturn}
                  onClear={() => setSlot({ pfPdf: null, ecrText: "" })}
                />
                <FileDrop
                  label="Insurance contribution"
                  hint="ESIC monthly contribution PDF, or the contribution CSV."
                  accept=".pdf,.csv,.txt,.xls"
                  loaded={!!esic}
                  meta={slot.esicPdf
                    ? `${slot.esicPdf.rows.length} insured, ${slot.esicPdf.totals.working} worked · ${inr(slot.esicPdf.totals.wages)} wages`
                    : esic ? `${esic.rows.length} insured persons · ${esic.format}` : ""}
                  onFile={readReturn}
                  onClear={() => setSlot({ esicPdf: null, esicText: "" })}
                />
              </div>

              {reading && (
                <div style={{ marginTop: 12, fontSize: 12.5, color: "var(--ink-2)", display: "flex", gap: 8, alignItems: "center" }}>
                  <span className="spin" /> Reading {reading}
                </div>
              )}

              {[slot.pfPdf, slot.esicPdf].filter(Boolean).map((d) => (
                <div key={d.kind} style={{ marginTop: 12 }}>
                  <div className="card-t" style={{ marginBottom: 6 }}>
                    {d.kind === "pf" ? "Provident fund return" : "Insurance contribution list"} — as read
                  </div>
                  <div style={{ fontSize: 12, color: "var(--ink-2)", lineHeight: 1.6 }}>
                    {d.kind === "pf"
                      ? `${d.header.establishment || "—"} · ${d.header.establishmentId || "—"} · ${d.header.period?.label || "—"} · ${d.rows.length} members · rate ${d.header.rate}%`
                      : `${d.header.employer || "—"} · code ${d.header.employerCode || "—"} · ${d.header.period?.label || "—"} · ${d.rows.length} insured, ${d.totals.working} worked${d.header.contractorWise ? " · contractor-wise list" : ""}`}
                  </div>
                  <div style={{ fontSize: 12, marginTop: 5, color: d.selfCheck?.ok ? "var(--ok)" : "var(--crit)" }}>
                    {d.selfCheck?.ok
                      ? "Totals read from the member rows agree with the totals printed on the document."
                      : "The rows read do not add up to the totals printed on the document: " + (d.selfCheck?.notes || []).join(" ")}
                  </div>
                </div>
              ))}

              {sheetMeta && (
                <div style={{ marginTop: 16 }}>
                  <div className="card-t" style={{ marginBottom: 7 }}>Columns read from the salary sheet</div>
                  <div style={{ fontSize: 12.5, color: "var(--ink-2)", marginBottom: 8 }}>
                    {sheetMeta.found.length} of {SHEET_COLUMNS.filter((c) => c.required).length} required columns present
                    {sheetMeta.optionalFound.length ? `, plus ${sheetMeta.optionalFound.length} optional` : ""}.
                  </div>
                  {sheetMeta.missing.length > 0 && (
                    <div className="note" style={{ marginBottom: 8 }}>
                      <b>Required columns missing.</b> {sheetMeta.missing.map((c) => c.label).join(", ")}.
                      The sheet was not loaded.
                    </div>
                  )}
                  {sheetMeta.optionalMissing.length > 0 && (
                    <table>
                      <thead><tr><th>Column not supplied</th><th>Checks it would switch on</th></tr></thead>
                      <tbody>
                        {sheetMeta.optionalMissing.filter((c) => c.unlocks).map((c) => (
                          <tr key={c.field} style={{ cursor: "default" }}>
                            <td style={{ whiteSpace: "nowrap" }}>{c.label}</td>
                            <td style={{ fontSize: 12, color: "var(--ink-2)" }}>{c.unlocks.join("; ")}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                  {sheetMeta.arithmetic?.length > 0 && (
                    <div className="note">
                      <b>{sheetMeta.arithmetic.length} row{sheetMeta.arithmetic.length === 1 ? "" : "s"} do not add up.</b>{" "}
                      The stated gross, total deductions or net does not follow from the components on the
                      same row. Raised as finding SH-22 against each employee.
                    </div>
                  )}
                </div>
              )}

              <div style={{ display: "flex", gap: 8, marginTop: 14, flexWrap: "wrap" }}>
                <button className="btn ghost" onClick={templateCsv}>
                  <Download size={14} /> Salary sheet template
                </button>
                <button className="btn ghost" onClick={ecrTemplate}>
                  <Download size={14} /> Accepted return formats
                </button>
                <span style={{ fontSize: 11.5, color: "var(--ink-3)", alignSelf: "center" }}>
                  {periodsWithData.length} period{periodsWithData.length === 1 ? "" : "s"} loaded
                </span>
              </div>
            </Card>

            {cross && cross.findings.length > 0 && (
              <Card title="The two returns compared with each other">
                <div className="recon" style={{ marginBottom: 14 }}>
                  <div><div className="k">In the fund return</div><div className="v">{cross.summary.pfMembers}</div></div>
                  <div><div className="k">Insured, worked</div><div className="v">{cross.summary.esicWorking} of {cross.summary.esicMembers}</div></div>
                  <div><div className="k">Matched across both</div><div className="v">{cross.summary.matched}</div></div>
                  <div><div className="k">Only in one</div>
                    <div className="v" style={{ color: cross.summary.onlyInPf + cross.summary.onlyInEsic ? "var(--crit)" : "var(--ink)" }}>
                      {cross.summary.onlyInPf + cross.summary.onlyInEsic}</div></div>
                </div>
                <div className="grid">
                  {cross.findings.map((f) => (
                    <div className="find" key={f.code}>
                      <div className="find-margin">
                        <div className="find-act">{f.act}</div>
                        <div className="find-sec mono">{f.sec}</div>
                        <div className="find-sec mono" style={{ marginTop: 10, color: "var(--ink-3)" }}>{f.code}</div>
                      </div>
                      <div className="find-body">
                        <div className="find-t">{f.title}<Chip color={SEV_COLOR[f.sev]}>{f.sev}</Chip></div>
                        <p className="find-p">{f.plain}</p>
                        {f.rows.length > 0 && (
                          <table style={{ marginTop: 8 }}>
                            <thead><tr><th>Name</th><th>Identifier</th><th>Detail</th></tr></thead>
                            <tbody>
                              {f.rows.slice(0, 10).map((r, i) => (
                                <tr key={i} style={{ cursor: "default" }}>
                                  <td>{r.name}</td>
                                  <td className="mono" style={{ fontSize: 11 }}>{r.id}</td>
                                  <td style={{ fontSize: 12, color: "var(--ink-2)" }}>{r.detail}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        )}
                        <div className="find-legal serif">{f.legal}</div>
                        <div className="find-fix"><b>Correction. </b>{f.fix}</div>
                      </div>
                    </div>
                  ))}
                </div>
                {cross.summary.softMatched > 0 && (
                  <div className="note" style={{ marginTop: 12 }}>
                    The two returns share no common identifier — the fund statement carries the universal
                    account number and the insurance list carries the insurance number.
                    {" "}{cross.summary.softMatched} of {cross.summary.matched} people were matched on name.
                    Load the salary sheet, which carries both numbers, to match exactly.
                  </div>
                )}
              </Card>
            )}

            {recon ? (
              <Card title="Salary sheet against the statutory returns">
                <ReconSummary recon={recon} orphans={orphans} />
                <div style={{ fontSize: 12, color: "var(--ink-2)", marginTop: 14, lineHeight: 1.6 }}>
                  Member-level differences are attached to the employees concerned and appear in the
                  register, the findings and the report under codes beginning RC. Matching runs on the
                  universal account number or insurance number where present, and falls back to name —
                  any name match is reported so it can be confirmed.
                </div>
              </Card>
            ) : hasData ? (
              <Card title="Reconciliation">
                <div className="empty">
                  <b>No return loaded for this period</b>
                  The salary sheet audits on its own, but a clean sheet says nothing about what actually
                  reached the challan. Upload the provident fund return, the insurance contribution file,
                  or both, to compare them.
                </div>
              </Card>
            ) : null}
          </div>
        )}

        {/* ------------------------------------------------------ register */}
        {tab === "register" && (
          <div className="grid">
            <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
              <div className="searchbox">
                <Search size={14} color="#8B93A1" />
                <input value={q} onChange={(e) => setQ(e.target.value)}
                  placeholder="Name, ID, department, or finding" />
              </div>
              <select value={bandFilter} onChange={(e) => setBandFilter(e.target.value)}>
                {["All", "Critical", "High", "Medium", "Low", "Very Low"].map((b) => (
                  <option key={b} value={b}>{b === "All" ? "All risk bands" : b + " risk"}</option>
                ))}
              </select>
              <div style={{ marginLeft: "auto", display: "flex", gap: 8 }}>
                <button className="btn ghost" onClick={templateCsv}><Download size={14} /> CSV template</button>
                <button className="btn ghost" onClick={() => fileRef.current.click()}><Upload size={14} /> Import register</button>
                <input ref={fileRef} type="file" accept=".csv" hidden
                  onChange={(e) => e.target.files[0] && importCsv(e.target.files[0])} />
              </div>
            </div>

            <div className="card" style={{ overflow: "hidden" }}>
              <table>
                <thead>
                  <tr>
                    <th>Employee</th><th>Department</th><th>Category</th>
                    <th className="num">Gross</th><th className="num">Wages s.2(y)</th><th className="num">Wage share</th>
                    <th className="num">Findings</th><th className="num">Exposure</th><th>Risk</th><th />
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((e) => (
                    <tr key={e.id} onClick={() => setSel(e)} tabIndex={0}
                      onKeyDown={(ev) => ev.key === "Enter" && setSel(e)}>
                      <td>
                        <div style={{ fontWeight: 500 }}>{e.name}</div>
                        <div className="mono" style={{ fontSize: 10.5, color: "var(--ink-3)" }}>{e.id} · {e.desig}</div>
                      </td>
                      <td>{e.dept}</td>
                      <td style={{ fontSize: 12, color: "var(--ink-2)" }}>{e.skill}, Zone {e.zone}<br />{e.type}</td>
                      <td className="num">{inr(e.gross)}</td>
                      <td className="num">{inr(e.wages)}</td>
                      <td className="num" style={{ color: e.w.compliantStructure ? "var(--ink-2)" : "var(--crit)", fontWeight: e.w.compliantStructure ? 400 : 600 }}>
                        {pct(e.w.includedShare)}
                      </td>
                      <td className="num">{e.findings.length || "—"}</td>
                      <td className="num" style={{ color: e.exposure ? "var(--crit)" : "var(--ink-3)" }}>
                        {e.exposure ? inr(e.exposure) : "—"}
                      </td>
                      <td><Chip color={BAND_COLOR[e.band]}>{e.risk} {e.band}</Chip></td>
                      <td style={{ color: "var(--ink-3)" }}><ChevronRight size={15} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {filtered.length === 0 && (
                <div style={{ padding: 26, textAlign: "center", fontSize: 13, color: "var(--ink-2)" }}>
                  No records match. Clear the search or widen the risk band.
                </div>
              )}
            </div>
          </div>
        )}

        {/* ------------------------------------------------------ analyser */}
        {tab === "analyser" && (
          <div className="grid">
            <Card title="What this register is telling you">
              <div className="read serif">
                {A.headline.map((h, i) => <p key={i}>{h}</p>)}
              </div>
            </Card>

            <Card title="Ask the register">
              <div className="askbar">
                <Search size={15} color="var(--seal)" />
                <input value={ask} onChange={(e) => setAsk(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && runQuery()}
                  placeholder="Which employees are below minimum wages?" />
                <button className="iconbtn" onClick={() => runQuery()} aria-label="Ask"
                  style={{ borderColor: "var(--seal)", color: "var(--seal)" }}>
                  <Send size={13} />
                </button>
              </div>
              <div className="suggest">
                {SUGGESTIONS.map((s) => (
                  <button key={s} onClick={() => runQuery(s)}>{s}</button>
                ))}
              </div>
              {answer && (
                <>
                  <div className="answer">{answer.answer}</div>
                  {answer.rows.length > 0 && (
                    <table style={{ marginTop: 12 }}>
                      <thead><tr><th>Employee</th><th>Department</th><th className="num">Wages</th><th className="num">Exposure</th><th>Risk</th></tr></thead>
                      <tbody>
                        {answer.rows.map((e) => (
                          <tr key={e.id} onClick={() => setSel(e)}>
                            <td>{e.name}<div className="mono" style={{ fontSize: 10.5, color: "var(--ink-3)" }}>{e.id}</div></td>
                            <td>{e.dept}</td>
                            <td className="num">{inr(e.wages)}</td>
                            <td className="num">{e.exposure ? inr(e.exposure) : "—"}</td>
                            <td><Chip color={BAND_COLOR[e.band]}>{e.risk}</Chip></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </>
              )}
            </Card>

            <Card title="Root causes" pad={false}>
              <div style={{ padding: 14 }}>
                {A.causes.map((c, i) => (
                  <div className="cause" key={c.key}>
                    <div className="cause-h">
                      <div className="cause-n">{i + 1}</div>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 14, fontWeight: 600 }}>{c.title}</div>
                        <div className="cause-meta">
                          <span>Employees<b>{c.employees}</b></span>
                          <span>Exposure<b>{inr(c.exposure)}</b></span>
                          <span>Effort<b>{c.effort}</b></span>
                          <span>Owner<b>{c.owner}</b></span>
                        </div>
                      </div>
                      <Chip color={SEV_COLOR[c.worst]}>{c.worst}</Chip>
                    </div>
                    <div className="cause-b">
                      <div style={{ marginBottom: 8 }}>
                        {c.rules.map((r) => <span className="tag" key={r.code}>{r.code}</span>)}
                      </div>
                      <div className="read serif" style={{ fontSize: 13.5 }}>{c.why}</div>
                      <div className="find-fix" style={{ marginTop: 9 }}><b>Do this. </b>{c.fix}</div>
                    </div>
                  </div>
                ))}
                {!A.causes.length && (
                  <div style={{ fontSize: 13, color: "var(--ink-2)" }}>Nothing to analyse — the register is clean.</div>
                )}
              </div>
            </Card>

            <div className="grid" style={{ gridTemplateColumns: "1.4fr 1fr" }}>
              <Card title="Remediation plan" pad={false}>
                <table>
                  <thead><tr><th className="num">#</th><th>Action</th><th>Owner</th><th>By when</th><th className="num">Exposure</th></tr></thead>
                  <tbody>
                    {A.plan.map((p) => (
                      <tr key={p.rank} style={{ cursor: "default" }}>
                        <td className="num mono">{p.rank}</td>
                        <td>
                          <div style={{ fontWeight: 500 }}>{p.title}</div>
                          <div style={{ fontSize: 11.5, color: "var(--ink-2)", marginTop: 2 }}>{p.action}</div>
                        </td>
                        <td style={{ fontSize: 12 }}>{p.owner}<br />
                          <span style={{ color: "var(--ink-3)" }}>{p.effort} effort</span></td>
                        <td style={{ fontSize: 12 }}>{p.deadline}</td>
                        <td className="num">{inr(p.exposure)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </Card>

              <div className="grid">
                <Card title="Registers that would fail an inspection">
                  {A.registerRisk.map((r) => (
                    <div key={r.doc} style={{ display: "flex", gap: 8, alignItems: "center", padding: "5px 0", fontSize: 12.5 }}>
                      {r.fails
                        ? <AlertTriangle size={14} color="var(--crit)" style={{ flex: "none" }} />
                        : <CheckCircle2 size={14} color="var(--ok)" style={{ flex: "none" }} />}
                      <span style={{ color: r.fails ? "var(--ink)" : "var(--ink-3)" }}>{r.doc}</span>
                    </div>
                  ))}
                </Card>
                <Card title="If every structure were corrected">
                  <div className="impact" style={{ marginTop: 0 }}>
                    <div><div className="k">Deemed wages now</div><div className="v">{inr(A.addBackTotal)}</div></div>
                    <div><div className="k">PF each side</div><div className="v">+{inr(A.pfDelta)}</div></div>
                    <div><div className="k">Gratuity accrual</div><div className="v">+{inr(A.gratuityDelta)}</div></div>
                  </div>
                  <div style={{ fontSize: 12, color: "var(--ink-2)", marginTop: 10, lineHeight: 1.55 }}>
                    Monthly figures at constant payable cost. Open any flagged employee in the register
                    to see the proposed split for that record.
                  </div>
                </Card>
              </div>
            </div>

            <div className="note">
              This analysis is computed from the finding set by a deterministic engine — it runs offline
              and returns the same reading for the same register every time. It is not a language model,
              so it will not speculate beyond what the numbers support.
            </div>
          </div>
        )}

        {/* ------------------------------------------------------ findings */}
        {tab === "findings" && (
          <div className="grid">
            <Card
              title="Exceptions grouped by rule"
              right={
                <button className="btn ghost" onClick={() => setShowObsForm((v) => !v)}>
                  <Plus size={14} /> Add observation
                </button>
              }
              pad={false}
            >
              <table>
                <thead><tr><th>Rule</th><th>Exception</th><th>Severity</th><th>Spread</th><th className="num">Employees</th><th className="num">Exposure</th></tr></thead>
                <tbody>
                  {A.patterns.map((r) => (
                    <tr key={r.code} onClick={() => { setTab("register"); setQ(r.title.slice(0, 18)); }}>
                      <td className="mono" style={{ fontSize: 11.5 }}>{r.code}</td>
                      <td>{r.title}</td>
                      <td><Chip color={SEV_COLOR[r.sev]}>{r.sev}</Chip></td>
                      <td style={{ fontSize: 12, color: "var(--ink-2)" }}>{r.kind}</td>
                      <td className="num">{r.n}</td>
                      <td className="num">{r.exposure ? inr(r.exposure) : "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {!A.patterns.length && (
                <div className="empty"><b>Nothing flagged</b>
                  Every record passed on the parameters currently configured.</div>
              )}
            </Card>

            {showObsForm && (
              <ObservationForm
                employees={audited}
                onAdd={addObservation}
                onCancel={() => setShowObsForm(false)}
              />
            )}

            {observations.length > 0 && (
              <Card title={`Auditor observations (${observations.length})`} pad={false}>
                <table>
                  <thead><tr><th>Code</th><th>Observation</th><th>Severity</th><th>Attached to</th><th className="num">Exposure</th><th /></tr></thead>
                  <tbody>
                    {obsFindings.map((o, i) => (
                      <tr key={o.code} style={{ cursor: "default" }}>
                        <td className="mono" style={{ fontSize: 11.5 }}>{o.code}</td>
                        <td>{o.title}
                          <div style={{ fontSize: 11.5, color: "var(--ink-2)", marginTop: 2 }}>{o.act}</div>
                        </td>
                        <td><Chip color={SEV_COLOR[o.sev]}>{o.sev}</Chip></td>
                        <td style={{ fontSize: 12 }}>
                          {o.empId ? (audited.find((e) => e.id === o.empId)?.name || o.empId) : "Establishment"}
                        </td>
                        <td className="num">{o.exposure ? inr(o.exposure) : "—"}</td>
                        <td><button className="linkbtn danger" onClick={() => removeObservation(i)}>Delete</button></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </Card>
            )}

            {dismissedList.length > 0 && (
              <Card title={`Not carried forward (${dismissedList.length})`} pad={false}>
                <table>
                  <thead><tr><th>Rule</th><th>Employee</th><th>Exception</th><th>Reason</th><th /></tr></thead>
                  <tbody>
                    {dismissedList.map((d) => (
                      <tr key={d.code + d.empId} className="dismissed" style={{ cursor: "default" }}>
                        <td className="mono" style={{ fontSize: 11.5 }}>{d.code}</td>
                        <td>{d.empName}</td>
                        <td>{d.title}</td>
                        <td style={{ fontSize: 12 }}>{d.reason}
                          {d.note && <div style={{ color: "var(--ink-3)", fontSize: 11 }}>{d.note}</div>}
                        </td>
                        <td>
                          <button className="linkbtn" onClick={() => restoreFinding(dismissKey(d.empId, d.code))}>
                            Restore
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                <div style={{ padding: "10px 14px", fontSize: 11.5, color: "var(--ink-2)", lineHeight: 1.55 }}>
                  These are excluded from the score, the exposure and the analysis, and are listed in the
                  report with the reason so the working paper trail stays complete.
                </div>
              </Card>
            )}

            <div className="grid">
              {A.byRule.map((r) => {
                const first = A.all.find((f) => f.code === r.code);
                const emps = audited.filter((e) => e.findings.some((f) => f.code === r.code));
                return (
                  <div key={r.code}>
                    <Finding f={first} prefix={`${r.n} employee${r.n > 1 ? "s" : ""} affected.`} />
                    <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center",
                      padding: "7px 12px", border: "1px solid var(--rule)", borderTop: 0,
                      background: "#FBFBF9", fontSize: 11.5, color: "var(--ink-2)" }}>
                      <span>Remove for:</span>
                      {emps.map((e) => (
                        <button key={e.id} className="linkbtn"
                          onClick={() => setDismissing({ empId: e.id, code: r.code })}>
                          {e.name}
                        </button>
                      ))}
                    </div>
                    {dismissing?.code === r.code && (
                      <DismissForm
                        finding={first}
                        empName={audited.find((e) => e.id === dismissing.empId)?.name || dismissing.empId}
                        onDismiss={(reason, note) => dismissFinding(dismissing.empId, dismissing.code, reason, note)}
                        onCancel={() => setDismissing(null)}
                      />
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ------------------------------------------------------ contract */}
        {tab === "contract" && (
          <div className="grid">
            <Card title="Contract labour compliance">
              <div className="read serif" style={{ fontSize: 13.5, marginBottom: 14 }}>
                <p>
                  Contract labour moved into Chapter XI of the Occupational Safety, Health and Working
                  Conditions Code when the Central Rules were notified on 8 May 2026 and the Contract
                  Labour (Regulation and Abolition) Act, 1970 was repealed. A contractor who has engaged
                  fifty or more workers in the preceding twelve months needs one licence, valid five
                  years, in place of the per-establishment licences that came before. It is backed by a
                  security deposit of {inr(1000)} per worker that the licensing authority can draw on
                  directly where minimum wages go unpaid.
                </p>
                <p>
                  The part worth internalising: liability for a contractor's default in wages, bonus or
                  contributions is the principal employer's by statute. An indemnity clause changes the
                  commercial position between the parties and nothing about the statutory one.
                </p>
              </div>
              <div className="recon">
                <div><div className="k">Contractors</div><div className="v">{cSum.contractors}</div></div>
                <div><div className="k">Contract workers</div><div className="v">{cSum.workers}</div></div>
                <div><div className="k">Compliance score</div><div className="v">{cSum.score}/100</div></div>
                <div><div className="k">Without licence</div>
                  <div className="v" style={{ color: cSum.unlicensed ? "var(--crit)" : "var(--ink)" }}>{cSum.unlicensed}</div></div>
                <div><div className="k">Documents pending</div>
                  <div className="v" style={{ color: cSum.docsPending ? "var(--high)" : "var(--ink)" }}>{cSum.docsPending}</div></div>
                <div><div className="k">Exposure</div>
                  <div className="v" style={{ color: "var(--crit)" }}>{inr(cSum.exposure)}</div></div>
              </div>
            </Card>

            {contractAudit.map((c) => (
              <ContractorCard
                key={c.id} c={c}
                onChange={(next) => setContractors((prev) => prev.map((x) => (x.id === c.id ? next : x)))}
                onRemove={() => setContractors((prev) => prev.filter((x) => x.id !== c.id))}
              />
            ))}

            <div>
              <button className="btn" onClick={() => setContractors((prev) => [...prev, newContractor({ name: "New contractor" })])}>
                <Plus size={14} /> Add contractor
              </button>
            </div>

            <Card title={`Documents to hold on file — ${DOCUMENTS.length} items`}>
              <div style={{ fontSize: 12.5, color: "var(--ink-2)", lineHeight: 1.6, marginBottom: 10 }}>
                The full checklist under the Code and the Central Rules. Mark each item against a
                contractor on their Documents tab above. Items marked mandatory drive the CL-11 finding.
              </div>
              <table>
                <thead><tr><th>Stage</th><th>Document</th><th>Authority</th><th>Mandatory</th></tr></thead>
                <tbody>
                  {DOCUMENTS.map((d) => (
                    <tr key={d.id} style={{ cursor: "default" }}>
                      <td style={{ fontSize: 11.5, color: "var(--ink-2)", whiteSpace: "nowrap" }}>{d.stage}</td>
                      <td>{d.doc}</td>
                      <td style={{ fontSize: 11.5, color: "var(--ink-2)" }}>{d.authority}</td>
                      <td>{d.critical
                        ? <Chip color="var(--crit)">Yes</Chip>
                        : <span style={{ fontSize: 11.5, color: "var(--ink-3)" }}>Advisable</span>}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </Card>
          </div>
        )}

        {/* --------------------------------------------------------- rules */}
        {tab === "rules" && (
          <div className="grid">
            <div className="note">
              <b>Verify before you rely on these.</b> Minimum wage rates, professional tax slabs and
              welfare fund amounts change by notification and differ by state, zone, scheduled
              employment and skill category. The figures loaded here are placeholders so the engine has
              something to test against. Every edit re-runs the audit immediately.
            </div>

            <Card title="Wage definition — Code on Wages s.2(y)">
              <div className="grid" style={{ gridTemplateColumns: "repeat(auto-fit,minmax(200px,1fr))" }}>
                <div className="field">
                  <label>Statutory wage floor %</label>
                  <input type="number" value={params.wageFloorPct}
                    onChange={(e) => setParams({ ...params, wageFloorPct: Number(e.target.value) })} />
                </div>
                {[
                  ["includeErPfInRemuneration", "Employer PF in total remuneration"],
                  ["includeBonusInRemuneration", "Statutory bonus in total remuneration"],
                  ["includeOtInRemuneration", "Overtime in the 50% test"],
                ].map(([k, label]) => (
                  <div className="field" key={k}>
                    <label>{label}</label>
                    <select value={params[k] ? "yes" : "no"}
                      onChange={(e) => setParams({ ...params, [k]: e.target.value === "yes" })}>
                      <option value="yes">Included</option>
                      <option value="no">Excluded</option>
                    </select>
                  </div>
                ))}
                <div className="field">
                  <label>ESI contribution base</label>
                  <select value={params.esicBase}
                    onChange={(e) => setParams({ ...params, esicBase: e.target.value })}>
                    <option value="code">Wages under s.2(88) — from 21.11.2025</option>
                    <option value="gross">Gross wages — pre-Code basis</option>
                  </select>
                </div>
              </div>
              <div style={{ fontSize: 12, color: "var(--ink-2)", marginTop: 11, lineHeight: 1.55 }}>
                The Ministry has confirmed that employer provident fund contribution and statutory bonus
                count toward total remuneration for the fifty per cent test without themselves being
                wages, that overtime forms part of the excluded components in clauses (a) to (i), and
                that gratuity and retrenchment compensation are ring-fenced from the add-back. Insurance
                coverage is still tested on gross wages against the threshold below; only the
                contribution base moved to the Code definition.
              </div>
            </Card>

            <Card title="Contribution and eligibility thresholds">
              <div className="grid" style={{ gridTemplateColumns: "repeat(auto-fit,minmax(180px,1fr))" }}>
                {[
                  ["pfCeiling", "PF wage ceiling"], ["pfRateEmployee", "PF employee rate %"],
                  ["esicWageLimit", "ESI wage limit"], ["esicWageLimitDisability", "ESI limit, disability"],
                  ["esicRateEmployee", "ESI employee rate %"], ["esicRateEmployer", "ESI employer rate %"],
                  ["bonusEligibilityWage", "Bonus eligibility wage"], ["bonusCalcCeiling", "Bonus calculation ceiling"],
                  ["bonusMinPct", "Minimum bonus %"], ["deductionCapPct", "Deduction ceiling %"],
                  ["otMultiplier", "Overtime multiplier"], ["otQuarterCapHours", "Overtime hours per quarter"],
                  ["wagePayByDay", "Wages due by day"], ["gratuityMinYears", "Gratuity qualifying years"],
                  ["ptWomenExemptUpto", "PT exemption, women, upto"], ["lwfEmployee", "Welfare fund, employee"],
                ].map(([k, label]) => (
                  <div className="field" key={k}>
                    <label>{label}</label>
                    <input type="number" value={params[k]}
                      onChange={(e) => setParams({ ...params, [k]: Number(e.target.value) })} />
                  </div>
                ))}
              </div>
            </Card>

            <Card title="Minimum wages — monthly Basic + DA by zone and skill">
              <table>
                <thead><tr><th>Zone</th><th className="num">Unskilled</th><th className="num">Semi-skilled</th><th className="num">Skilled</th></tr></thead>
                <tbody>
                  {["I", "II", "III"].map((z) => (
                    <tr key={z} style={{ cursor: "default" }}>
                      <td>Zone {z}</td>
                      {["unskilled", "semiskilled", "skilled"].map((s) => (
                        <td key={s} className="num">
                          <input type="number" style={{ width: 100, textAlign: "right" }}
                            value={params.minWage[z][s]}
                            onChange={(ev) => setParams({
                              ...params,
                              minWage: { ...params.minWage, [z]: { ...params.minWage[z], [s]: Number(ev.target.value) } },
                            })} />
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </Card>

            <Card title="Rules implemented in this build">
              <table>
                <thead><tr><th>Code</th><th>Test</th><th>Authority</th></tr></thead>
                <tbody>
                  {[
                    ["MW-01", "Wages under s.2(y) against the notified minimum, pro-rated on days worked", "Code on Wages s.5, s.6"],
                    ["WD-02", "Basic and DA against the fifty per cent floor, with add-back", "Code on Wages s.2(y)"],
                    ["PF-03/04/05", "Coverage, contribution on the s.2(88) base, UAN on record", "Social Security Code s.16"],
                    ["ES-06/07/08", "Coverage on gross, contribution on Code wages, insurance number", "Social Security Code s.29"],
                    ["ES-09", "Continuation to the end of the contribution period after crossing the limit", "SS Code s.29; ESI Regulations r.50"],
                    ["PT-10", "Slab mapping including the exemption for women", "MH Profession Tax Act s.4"],
                    ["LW-11", "Half-yearly welfare fund contribution", "MH Labour Welfare Fund Act s.6BB"],
                    ["BO-12", "Minimum bonus on the higher of ceiling and minimum wage", "Code on Wages s.26"],
                    ["OT-13/14", "Twice the ordinary rate, and the quarterly hour ceiling", "OSH Code s.25, s.26"],
                    ["DE-15", "Total deductions against the wage ceiling", "Code on Wages s.18"],
                    ["WP-16/17", "Credit date and bank transfer evidence", "Code on Wages s.15, s.17"],
                    ["ER-18", "Pay differential by gender within the same role", "Code on Wages s.3, s.4"],
                    ["GR-19", "Accrued gratuity past five years on the Code wage figure", "Social Security Code s.53"],
                    ["GR-20", "Pro-rata gratuity for fixed term employees, no five-year bar", "Social Security Code s.53(2)"],
                    ["AT-21", "Paid days against days in the wage period", "Code on Wages s.50"],
                  ].map(([c, t, a]) => (
                    <tr key={c} style={{ cursor: "default" }}>
                      <td className="mono" style={{ fontSize: 11.5, whiteSpace: "nowrap" }}>{c}</td>
                      <td>{t}</td>
                      <td style={{ fontSize: 12, color: "var(--ink-2)" }}>{a}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </Card>
          </div>
        )}

        {/* -------------------------------------------------------- report */}
        {tab === "report" && (
          <div className="grid">
            <Card title="Auditor details">
              <div style={{ fontSize: 12.5, color: "var(--ink-2)", lineHeight: 1.6, marginBottom: 13 }}>
                These appear on the cover page and in the signature block at the end of the report.
                They are saved locally and carry across periods.
              </div>
              <div className="miniform">
                {[
                  ["firm", "Firm name"],
                  ["name", "Auditor or engagement partner"],
                  ["membership", "Membership or registration no."],
                  ["designation", "Designation"],
                  ["ref", "Engagement reference"],
                  ["place", "Place"],
                  ["date", "Report date"],
                ].map(([k, label]) => (
                  <div className="field" key={k}>
                    <label>{label}</label>
                    <input value={auditor[k] || ""} placeholder={k === "date" ? "9 August 2026" : ""}
                      onChange={(e) => setAuditor({ ...auditor, [k]: e.target.value })} />
                  </div>
                ))}
              </div>
              <div className="field" style={{ marginTop: 11 }}>
                <label>Scope note — appears in the executive summary</label>
                <textarea value={auditor.scopeNote || ""}
                  onChange={(e) => setAuditor({ ...auditor, scopeNote: e.target.value })}
                  placeholder="The engagement covered one wage period and did not extend to verification of statutory dues for prior periods." />
              </div>
            </Card>

            <Card
              title="Audit report"
              right={
                <div className="exportbar">
                  <button className="btn" disabled={!!busy} onClick={() => runExport("pdf")}>
                    {busy === "pdf" ? <span className="spin" /> : <Printer size={14} />} PDF
                  </button>
                  <button className="btn ghost" disabled={!!busy} onClick={() => runExport("docx")}>
                    {busy === "docx" ? <span className="spin" /> : <Download size={14} />} Word
                  </button>
                  <button className="btn ghost" disabled={!!busy} onClick={() => runExport("html")}>
                    {busy === "html" ? <span className="spin" /> : <Download size={14} />} HTML
                  </button>
                  {toast && <span className="toast">{toast}</span>}
                </div>
              }
            >
              <div style={{ fontSize: 12.5, color: "var(--ink-2)", lineHeight: 1.6, marginBottom: 12 }}>
                Executive summary, basis of audit, findings by rule, return reconciliation, contract
                labour, root cause analysis, remediation plan, the register, employee-wise findings,
                structure recommendations, auditor observations, findings not carried forward, and
                limitations with the signature block. Sections appear only when there is something to
                report. The preview below is the document itself — the PDF renders from exactly this,
                and the Word file carries the same content as editable text and tables.
              </div>
              <div className="paper">
                <iframe className="paper-frame" title="Report preview"
                  srcDoc={buildHtml(audited, A, P, { ...reportCtx, forPrint: false })} />
              </div>
            </Card>
          </div>
        )}
      </main>

      <footer style={{ padding: "18px 22px 40px", maxWidth: 1240, margin: "0 auto", fontSize: 11.5, color: "var(--ink-3)", lineHeight: 1.6 }}>
        Prototype. Statutory parameters are placeholders pending verification against the notifications
        in force. Findings are computed indicators for an auditor to review, not a legal opinion.
      </footer>

      <Drawer emp={sel} P={params} onClose={() => setSel(null)} />
    </div>
  );
}

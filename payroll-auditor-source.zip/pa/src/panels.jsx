import React, { useState } from "react";
import {
  Upload, FileCheck2, X, Plus, Trash2, RotateCcw, AlertTriangle, CheckCircle2,
} from "lucide-react";
import { inr, pct, OBSERVATION_ACTS, DISMISS_REASONS } from "./engine.js";
import { DOCUMENTS, DOC_STAGES, DOC_STATUS, newContractor, LICENCE_THRESHOLD } from "./contract.js";

const SEV_LIST = ["Critical", "High", "Medium", "Low"];
const SEV_COLOR = {
  Critical: "var(--crit)", High: "var(--high)", Medium: "var(--med)", Low: "var(--low)",
};

/* ==========================================================================
   File drop
   ========================================================================== */

export function FileDrop({ label, hint, accept, loaded, meta, onFile, onClear }) {
  const ref = React.useRef(null);
  return (
    <div>
      <div
        className={"drop" + (loaded ? " filled" : "")}
        onClick={() => ref.current.click()}
        onDragOver={(e) => e.preventDefault()}
        onDrop={(e) => {
          e.preventDefault();
          if (e.dataTransfer.files[0]) onFile(e.dataTransfer.files[0]);
        }}
        role="button" tabIndex={0}
        onKeyDown={(e) => e.key === "Enter" && ref.current.click()}
      >
        {loaded ? <FileCheck2 size={17} color="var(--ok)" /> : <Upload size={17} color="var(--ink-3)" />}
        <b>{label}</b>
        <span>{loaded ? meta : hint}</span>
        <input ref={ref} type="file" accept={accept} hidden
          onChange={(e) => e.target.files[0] && onFile(e.target.files[0])} />
      </div>
      {loaded && (
        <div style={{ textAlign: "right", marginTop: 6 }}>
          <button className="linkbtn danger" onClick={onClear}>Remove this file</button>
        </div>
      )}
    </div>
  );
}

/* ==========================================================================
   Reconciliation summary
   ========================================================================== */

export function ReconSummary({ recon, orphans }) {
  if (!recon || (!recon.summary.pf && !recon.summary.esi)) return null;
  const { pf, esi } = recon.summary;
  const cell = (k, v, bad) => (
    <div key={k}>
      <div className="k">{k}</div>
      <div className="v" style={bad ? { color: "var(--crit)" } : undefined}>{v}</div>
    </div>
  );
  return (
    <>
      {pf && (
        <>
          <div className="card-t" style={{ marginBottom: 8 }}>Provident fund — challan against sheet</div>
          <div className="recon">
            {cell("Members in return", pf.members)}
            {cell("Missing from return", pf.missing, pf.missing > 0)}
            {cell("In return, not in sheet", pf.orphans, pf.orphans > 0)}
            {cell("Deducted per sheet", inr(pf.sheetContri))}
            {cell("Remitted per return", inr(pf.returnContri), Math.abs(pf.variance) > 2)}
            {cell("Variance", inr(pf.variance), Math.abs(pf.variance) > 2)}
          </div>
        </>
      )}
      {esi && (
        <>
          <div className="card-t" style={{ margin: "16px 0 8px" }}>Insurance — return against sheet</div>
          <div className="recon">
            {cell("Insured in return", esi.members)}
            {cell("Missing from return", esi.missing, esi.missing > 0)}
            {cell("In return, not in sheet", esi.orphans, esi.orphans > 0)}
            {cell("Wages per sheet", inr(esi.sheetWages))}
            {cell("Wages per return", inr(esi.returnWages), Math.abs(esi.variance) > 2)}
            {cell("Variance", inr(esi.variance), Math.abs(esi.variance) > 2)}
          </div>
        </>
      )}
      {orphans?.length > 0 && (
        <div style={{ marginTop: 14 }}>
          {orphans.map((o) => (
            <div className="find" key={o.code} style={{ marginBottom: 10 }}>
              <div className="find-margin">
                <div className="find-act">{o.act}</div>
                <div className="find-sec mono">{o.sec}</div>
                <div className="find-sec mono" style={{ marginTop: 10, color: "var(--ink-3)" }}>{o.code}</div>
              </div>
              <div className="find-body">
                <div className="find-t">{o.title}
                  <span className="chip" style={{ color: SEV_COLOR[o.sev] }}>
                    <span className="dot" /> {o.sev}
                  </span>
                </div>
                <p className="find-p">{o.plain}</p>
                <table style={{ marginTop: 8 }}>
                  <thead><tr><th>Identifier</th><th>Name in return</th></tr></thead>
                  <tbody>
                    {o.rows.slice(0, 8).map((r, i) => (
                      <tr key={i} style={{ cursor: "default" }}>
                        <td className="mono">{r.uan || r.ip || "—"}</td>
                        <td>{r.name}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                <div className="find-fix"><b>Correction. </b>{o.fix}</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </>
  );
}

/* ==========================================================================
   Auditor observation form
   ========================================================================== */

export function ObservationForm({ employees, onAdd, onCancel }) {
  const [o, setO] = useState({
    title: "", sev: "Medium", act: OBSERVATION_ACTS[0], sec: "",
    observation: "", recommendation: "", exposure: "", empId: "",
  });
  const set = (k) => (e) => setO({ ...o, [k]: e.target.value });
  const ready = o.title.trim() && o.observation.trim() && o.recommendation.trim();

  return (
    <div className="rowform">
      <div style={{ display: "flex", alignItems: "center", marginBottom: 11 }}>
        <span className="card-t">Record an audit observation</span>
        <button className="iconbtn" style={{ marginLeft: "auto" }} onClick={onCancel} aria-label="Cancel">
          <X size={14} />
        </button>
      </div>

      <div className="grid2">
        <div className="field" style={{ gridColumn: "1 / -1" }}>
          <label>Observation title</label>
          <input value={o.title} onChange={set("title")}
            placeholder="Appointment letters not in the prescribed format" />
        </div>
        <div className="field">
          <label>Severity</label>
          <select value={o.sev} onChange={set("sev")}>
            {SEV_LIST.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
        <div className="field">
          <label>Applicable law</label>
          <select value={o.act} onChange={set("act")}>
            {OBSERVATION_ACTS.map((a) => <option key={a} value={a}>{a}</option>)}
          </select>
        </div>
        <div className="field">
          <label>Section or rule</label>
          <input value={o.sec} onChange={set("sec")} placeholder="s.6; prescribed format" />
        </div>
        <div className="field">
          <label>Attach to</label>
          <select value={o.empId} onChange={set("empId")}>
            <option value="">Establishment as a whole</option>
            {employees.map((e) => (
              <option key={e.id} value={e.id}>{e.id} — {e.name}</option>
            ))}
          </select>
        </div>
        <div className="field">
          <label>Estimated exposure</label>
          <input type="number" value={o.exposure} onChange={set("exposure")} placeholder="0" />
        </div>
      </div>

      <div className="field" style={{ marginTop: 10 }}>
        <label>Observation</label>
        <textarea value={o.observation} onChange={set("observation")}
          placeholder="What was seen on review, and against which records." />
      </div>
      <div className="field" style={{ marginTop: 10 }}>
        <label>Recommendation</label>
        <textarea value={o.recommendation} onChange={set("recommendation")}
          placeholder="What management should do, and by when." />
      </div>

      <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
        <button className="btn" disabled={!ready} onClick={() => onAdd(o)}>
          <Plus size={14} /> Add to findings
        </button>
        <button className="btn ghost" onClick={onCancel}>Cancel</button>
        {!ready && (
          <span style={{ fontSize: 11.5, color: "var(--ink-3)", alignSelf: "center" }}>
            Title, observation and recommendation are needed.
          </span>
        )}
      </div>
    </div>
  );
}

/* ==========================================================================
   Dismiss control
   ========================================================================== */

export function DismissForm({ finding, empName, onDismiss, onCancel }) {
  const [reason, setReason] = useState(DISMISS_REASONS[0]);
  const [note, setNote] = useState("");
  return (
    <div className="rowform">
      <div className="card-t" style={{ marginBottom: 10 }}>
        Remove {finding.code} for {empName}
      </div>
      <div className="grid2">
        <div className="field" style={{ gridColumn: "1 / -1" }}>
          <label>Reason not carried forward</label>
          <select value={reason} onChange={(e) => setReason(e.target.value)}>
            {DISMISS_REASONS.map((r) => <option key={r} value={r}>{r}</option>)}
          </select>
        </div>
        <div className="field" style={{ gridColumn: "1 / -1" }}>
          <label>Working note</label>
          <input value={note} onChange={(e) => setNote(e.target.value)}
            placeholder="Evidence seen, reference, person spoken to" />
        </div>
      </div>
      <div style={{ display: "flex", gap: 8, marginTop: 11 }}>
        <button className="btn" onClick={() => onDismiss(reason, note)}>
          <Trash2 size={14} /> Remove finding
        </button>
        <button className="btn ghost" onClick={onCancel}>Cancel</button>
      </div>
      <div style={{ fontSize: 11.5, color: "var(--ink-2)", marginTop: 9, lineHeight: 1.5 }}>
        The finding leaves the score, the exposure and the analysis, and is listed in the report
        under findings not carried forward with this reason. It is not deleted.
      </div>
    </div>
  );
}

/* ==========================================================================
   Contractor editor
   ========================================================================== */

export function ContractorCard({ c, onChange, onRemove }) {
  const [tab, setTab] = useState("detail");
  const set = (k, v) => onChange({ ...c, [k]: v });
  const setDoc = (id, v) => onChange({ ...c, docs: { ...c.docs, [id]: v } });

  const field = (k, label, type = "text") => (
    <div className="field" key={k}>
      <label>{label}</label>
      <input type={type} value={c[k] ?? ""} 
        onChange={(e) => set(k, type === "number" ? Number(e.target.value) : e.target.value)} />
    </div>
  );
  const bool = (k, label, yes = "Yes", no = "No") => (
    <div className="field" key={k}>
      <label>{label}</label>
      <select value={c[k] ? "y" : "n"} onChange={(e) => set(k, e.target.value === "y")}>
        <option value="y">{yes}</option>
        <option value="n">{no}</option>
      </select>
    </div>
  );

  return (
    <div className="card" style={{ marginBottom: 14 }}>
      <div className="card-h">
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 14.5, fontWeight: 600 }}>{c.name || "Unnamed contractor"}</div>
          <div style={{ fontSize: 11.5, color: "var(--ink-2)", marginTop: 2 }}>
            {c.work || "no scope recorded"} · {c.workers} deployed
            {c.needsLicence ? ` · licence required at ${LICENCE_THRESHOLD}+` : " · below the licence threshold"}
          </div>
        </div>
        <span className="chip" style={{ color: SEV_COLOR[c.band] || "var(--ok)" }}>
          <span className="dot" /> {c.risk} {c.band}
        </span>
        <button className="iconbtn" onClick={onRemove} aria-label="Remove contractor">
          <Trash2 size={13} />
        </button>
      </div>

      <div className="nav" style={{ padding: "0 14px", borderBottom: "1px solid var(--rule-2)" }}>
        {[["detail", "Details"], ["docs", `Documents (${c.docsPending} pending)`],
          ["findings", `Findings (${c.findings.length})`]].map(([k, l]) => (
          <button key={k} className="tab" data-on={tab === k ? "1" : "0"}
            style={{ padding: "10px 13px", fontSize: 12.5 }} onClick={() => setTab(k)}>{l}</button>
        ))}
      </div>

      {tab === "detail" && (
        <div className="card-b">
          <div className="miniform">
            {field("name", "Contractor name")}
            {field("work", "Nature of work")}
            {field("workers", "Workers deployed now", "number")}
            {field("workersPeak12m", "Peak over 12 months", "number")}
            {field("licenceNo", "Licence number")}
            {field("licenceValidTo", "Licence valid to", "date")}
            {field("securityDeposit", "Security deposit held", "number")}
            {field("wagesPaidBy", "Wages paid by day", "number")}
            {field("statementDay", "Monthly statement received on day", "number")}
            {bool("coreActivity", "Deployed on a core activity")}
            {bool("minWagePaid", "Minimum wages paid")}
            {bool("statementReceived", "Monthly statement received")}
            {bool("bonusPaid", "Statutory bonus paid")}
            {bool("settlementWithin2Days", "Exit dues settled in two days")}
          </div>
        </div>
      )}

      {tab === "docs" && (
        <div>
          {DOC_STAGES.map((stage) => {
            const rows = DOCUMENTS.filter((d) => d.stage === stage);
            if (!rows.length) return null;
            return (
              <div key={stage}>
                <div className="stage">{stage}</div>
                <table className="docgrid">
                  <tbody>
                    {rows.map((d) => {
                      const st = c.docs[d.id] || "Pending";
                      return (
                        <tr key={d.id} style={{ cursor: "default" }}
                          className={d.critical && st === "Pending" ? "docrow-crit" : ""}>
                          <td>
                            {d.doc}
                            {d.critical && (
                              <span className="chip" style={{ color: "var(--crit)", marginLeft: 6 }}>
                                <span className="dot" /> mandatory
                              </span>
                            )}
                            <div style={{ fontSize: 10.5, color: "var(--ink-3)", marginTop: 3 }}>{d.authority}</div>
                          </td>
                          <td style={{ width: 150 }}>
                            <select value={st} onChange={(e) => setDoc(d.id, e.target.value)}
                              style={{ width: "100%" }}>
                              {DOC_STATUS.map((s) => <option key={s} value={s}>{s}</option>)}
                            </select>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            );
          })}
        </div>
      )}

      {tab === "findings" && (
        <div className="card-b">
          {c.findings.length === 0 ? (
            <div style={{ display: "flex", gap: 9, alignItems: "center", fontSize: 13 }}>
              <CheckCircle2 size={16} color="var(--ok)" /> Nothing flagged against this contractor.
            </div>
          ) : (
            <div className="grid">
              {c.findings.map((f) => (
                <div className="find" key={f.code}>
                  <div className="find-margin">
                    <div className="find-act">{f.act}</div>
                    <div className="find-sec mono">{f.sec}</div>
                    <div className="find-sec mono" style={{ marginTop: 10, color: "var(--ink-3)" }}>{f.code}</div>
                  </div>
                  <div className="find-body">
                    <div className="find-t">{f.title}
                      <span className="chip" style={{ color: SEV_COLOR[f.sev] }}>
                        <span className="dot" /> {f.sev}
                      </span>
                    </div>
                    <p className="find-p">{f.plain}</p>
                    <div className="find-legal serif">{f.legal}</div>
                    <div className="find-fix"><b>Correction. </b>{f.fix}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export { newContractor };

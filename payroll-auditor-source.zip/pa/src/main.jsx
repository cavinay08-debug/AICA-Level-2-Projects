import React from "react";
import { createRoot } from "react-dom/client";

// Fonts bundled locally (latin subset only) so the app renders offline.
import "@fontsource/ibm-plex-sans/latin-400.css";
import "@fontsource/ibm-plex-sans/latin-500.css";
import "@fontsource/ibm-plex-sans/latin-600.css";
import "@fontsource/ibm-plex-sans/latin-700.css";
import "@fontsource/ibm-plex-mono/latin-400.css";
import "@fontsource/ibm-plex-mono/latin-500.css";
import "@fontsource/ibm-plex-mono/latin-600.css";
import "@fontsource/ibm-plex-serif/latin-400.css";
import "@fontsource/ibm-plex-serif/latin-600.css";

// PDF text extraction runs in a worker; point it at the bundled copy so the
// app works with no network.
import * as pdfjs from "pdfjs-dist/legacy/build/pdf.mjs";
import pdfWorker from "pdfjs-dist/legacy/build/pdf.worker.min.mjs?url";
pdfjs.GlobalWorkerOptions.workerSrc = pdfWorker;

import App from "./App.jsx";

document.body.style.margin = "0";

/* If the interface fails to mount, draw the reason on screen. A blank window
   tells the user nothing and tells us nothing either. */
function fatal(err) {
  const root = document.getElementById("root");
  if (!root) return;
  root.innerHTML = `
    <div style="font:14px/1.6 Segoe UI,system-ui,sans-serif;color:#161A22;padding:40px;max-width:760px">
      <h1 style="font-size:19px;margin:0 0 12px">The interface could not start</h1>
      <p style="margin:0 0 14px;color:#5A6373">
        This is a fault in the application, not in your data. Nothing you have
        saved is affected.
      </p>
      <pre style="background:#F4F4F0;border:1px solid #D9DBD4;padding:14px;border-radius:3px;
        white-space:pre-wrap;font:12px/1.5 Consolas,monospace;overflow:auto;max-height:340px">${
        String((err && err.stack) || err).replace(/[<>&]/g, (c) => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;" }[c]))
      }</pre>
      <p style="margin:16px 0 0;color:#5A6373">
        If this persists, extract the application zip again to a local folder
        such as C:\\PayrollAuditor and exclude that folder in your antivirus.
      </p>
    </div>`;
}

class Boundary extends React.Component {
  constructor(p) { super(p); this.state = { err: null }; }
  static getDerivedStateFromError(err) { return { err }; }
  componentDidCatch(err) { fatal(err); }
  render() { return this.state.err ? null : this.props.children; }
}

try {
  createRoot(document.getElementById("root")).render(
    <React.StrictMode>
      <Boundary><App /></Boundary>
    </React.StrictMode>
  );
} catch (err) {
  fatal(err);
}

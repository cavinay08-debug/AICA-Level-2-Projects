/* Design system for the auditor UI — shared by every tab. */
export const CSS = `
:root{
  --ink:#161A22;        /* body text, near-black with a cool cast */
  --ink-2:#5A6373;      /* secondary */
  --ink-3:#8B93A1;      /* tertiary */
  --paper:#EDEEEA;      /* app background — ledger stock */
  --card:#FFFFFF;
  --rule:#D9DBD4;       /* ruled line */
  --rule-2:#E8E9E4;
  --seal:#4B3FA8;       /* stamp violet — the one accent */
  --seal-wash:#EFEDFA;
  --crit:#A32218;
  --high:#C1611B;
  --med:#8A6A00;
  --low:#4B5563;
  --ok:#1F6B4A;
  --ok-wash:#E9F2ED;
}
*{box-sizing:border-box}
.app{
  font-family:'IBM Plex Sans',ui-sans-serif,system-ui,sans-serif;
  color:var(--ink); background:var(--paper); min-height:100vh;
  -webkit-font-smoothing:antialiased;
}
.mono{font-family:'IBM Plex Mono',ui-monospace,monospace;font-variant-numeric:tabular-nums}
.serif{font-family:'IBM Plex Serif',Georgia,serif}

/* ---- masthead ---- */
.mast{background:var(--ink);color:#EDEEEA;padding:14px 22px;display:flex;align-items:center;gap:18px;flex-wrap:wrap}
.mast-mark{width:30px;height:30px;border:1.5px solid #EDEEEA;display:grid;place-items:center;font-weight:700;font-size:13px;letter-spacing:.02em}
.mast h1{font-size:15px;font-weight:600;margin:0;letter-spacing:.01em}
.mast .sub{font-size:11px;color:#9AA3B2;letter-spacing:.09em;text-transform:uppercase;margin-top:1px}
.mast-meta{margin-left:auto;display:flex;gap:26px;align-items:center}
.meta-k{font-size:9.5px;letter-spacing:.11em;text-transform:uppercase;color:#7D8595}
.meta-v{font-size:12.5px;color:#EDEEEA;margin-top:2px}

/* ---- nav ---- */
.nav{display:flex;gap:0;border-bottom:1px solid var(--rule);background:var(--card);padding:0 22px;overflow-x:auto}
.tab{appearance:none;background:none;border:0;border-bottom:2px solid transparent;padding:13px 16px;font:inherit;font-size:13px;
  color:var(--ink-2);cursor:pointer;display:flex;align-items:center;gap:7px;white-space:nowrap}
.tab:hover{color:var(--ink)}
.tab[data-on="1"]{color:var(--seal);border-bottom-color:var(--seal);font-weight:600}
.tab:focus-visible{outline:2px solid var(--seal);outline-offset:-2px}

.wrap{max-width:1240px;margin:0 auto;padding:22px}
.grid{display:grid;gap:14px}

/* ---- cards ---- */
.card{background:var(--card);border:1px solid var(--rule);border-radius:3px}
.card-h{padding:11px 14px;border-bottom:1px solid var(--rule-2);display:flex;align-items:center;justify-content:space-between;gap:10px}
.card-t{font-size:10px;letter-spacing:.12em;text-transform:uppercase;color:var(--ink-3);font-weight:600}
.card-b{padding:14px}

/* ---- score seal (signature element) ---- */
.seal-row{display:grid;grid-template-columns:200px 1fr;gap:0;align-items:stretch}
.seal-box{border-right:1px solid var(--rule-2);padding:18px 16px;display:flex;flex-direction:column;justify-content:center}
.seal-ring{width:118px;height:118px;border-radius:50%;border:1.5px solid var(--seal);display:grid;place-items:center;
  position:relative;margin:0 auto;background:var(--seal-wash)}
.seal-ring:after{content:"";position:absolute;inset:6px;border:1px dashed var(--seal);border-radius:50%;opacity:.45}
.seal-num{font-size:34px;font-weight:600;line-height:1;color:var(--seal)}
.seal-lab{font-size:8.5px;letter-spacing:.14em;text-transform:uppercase;color:var(--seal);margin-top:5px}
.seal-cap{text-align:center;font-size:10px;letter-spacing:.1em;text-transform:uppercase;color:var(--ink-3);margin-top:12px}

/* ---- kpi ---- */
.kpis{display:grid;grid-template-columns:repeat(4,1fr)}
.kpi{padding:14px 16px;border-right:1px solid var(--rule-2);border-bottom:1px solid var(--rule-2)}
.kpi:nth-child(4n){border-right:0}
.kpi-k{font-size:9.5px;letter-spacing:.1em;text-transform:uppercase;color:var(--ink-3)}
.kpi-v{font-size:21px;font-weight:600;margin-top:5px;line-height:1.1}
.kpi-n{font-size:11px;color:var(--ink-2);margin-top:3px}

/* ---- table ---- */
table{width:100%;border-collapse:collapse;font-size:13px}
th{font-size:9.5px;letter-spacing:.1em;text-transform:uppercase;color:var(--ink-3);text-align:left;
  padding:9px 12px;border-bottom:1px solid var(--rule);font-weight:600;background:#FBFBF9;position:sticky;top:0}
td{padding:9px 12px;border-bottom:1px solid var(--rule-2);vertical-align:middle}
tbody tr{cursor:pointer}
tbody tr:hover{background:#FAFAF7}
.num{text-align:right;font-family:'IBM Plex Mono',monospace;font-variant-numeric:tabular-nums}

/* ---- chips ---- */
.chip{display:inline-flex;align-items:center;gap:5px;font-size:10px;font-weight:600;letter-spacing:.06em;
  text-transform:uppercase;padding:3px 7px;border-radius:2px;border:1px solid currentColor;white-space:nowrap}
.dot{width:6px;height:6px;border-radius:50%;background:currentColor;flex:none}

/* ---- finding: the marginal-citation card ---- */
.find{display:grid;grid-template-columns:150px 1fr;border:1px solid var(--rule);border-radius:3px;background:var(--card);overflow:hidden}
.find-margin{border-right:1px solid var(--rule);background:#FBFBF9;padding:12px 12px}
.find-act{font-size:10.5px;font-weight:600;line-height:1.35}
.find-sec{font-size:10px;color:var(--ink-2);margin-top:5px;line-height:1.4}
.find-body{padding:12px 14px}
.find-t{font-size:13.5px;font-weight:600;display:flex;align-items:center;gap:9px;flex-wrap:wrap}
.find-p{font-size:12.5px;color:var(--ink-2);line-height:1.55;margin:7px 0 0}
.find-legal{font-size:12px;line-height:1.6;margin-top:9px;padding-left:11px;border-left:2px solid var(--rule)}
.find-fix{font-size:12.5px;margin-top:9px;padding:8px 10px;background:var(--ok-wash);border-radius:2px;line-height:1.5}
.delta{display:flex;gap:22px;margin-top:10px;flex-wrap:wrap}
.delta div{font-size:10px;letter-spacing:.08em;text-transform:uppercase;color:var(--ink-3)}
.delta b{display:block;font-size:14px;font-family:'IBM Plex Mono',monospace;font-weight:600;color:var(--ink);margin-top:2px;letter-spacing:0;text-transform:none}

/* ---- drawer ---- */
.scrim{position:fixed;inset:0;background:rgba(22,26,34,.42);z-index:40}
.drawer{position:fixed;top:0;right:0;bottom:0;width:min(720px,100%);background:var(--paper);z-index:41;
  overflow-y:auto;box-shadow:-2px 0 24px rgba(0,0,0,.16);animation:slide .22s ease}
@keyframes slide{from{transform:translateX(22px);opacity:.4}to{transform:none;opacity:1}}
.drawer-h{position:sticky;top:0;background:var(--ink);color:#EDEEEA;padding:16px 20px;display:flex;gap:14px;align-items:flex-start;z-index:2}
.iconbtn{appearance:none;background:none;border:1px solid var(--rule);color:inherit;border-radius:2px;
  width:28px;height:28px;display:grid;place-items:center;cursor:pointer;flex:none}
.iconbtn:hover{background:rgba(255,255,255,.1)}

/* ---- controls ---- */
.btn{appearance:none;font:inherit;font-size:12.5px;font-weight:500;padding:7px 13px;border-radius:2px;
  border:1px solid var(--ink);background:var(--ink);color:#fff;cursor:pointer;display:inline-flex;align-items:center;gap:7px}
.btn:hover{opacity:.88}
.btn.ghost{background:transparent;color:var(--ink);border-color:var(--rule)}
.btn.ghost:hover{background:#F5F5F1}
.btn:focus-visible{outline:2px solid var(--seal);outline-offset:2px}
input,select{font:inherit;font-size:12.5px;padding:6px 9px;border:1px solid var(--rule);border-radius:2px;background:#fff;color:var(--ink)}
input:focus,select:focus{outline:2px solid var(--seal);outline-offset:-1px;border-color:var(--seal)}
.field{display:flex;flex-direction:column;gap:4px}
.field label{font-size:9.5px;letter-spacing:.1em;text-transform:uppercase;color:var(--ink-3)}

.note{font-size:11.5px;color:var(--ink-2);line-height:1.6;background:#FBF7E8;border:1px solid #E6DCBA;padding:10px 12px;border-radius:3px}
.searchbox{display:flex;align-items:center;gap:8px;border:1px solid var(--rule);background:#fff;border-radius:2px;padding:0 10px}
.searchbox input{border:0;outline:0;padding:7px 0;width:230px}
.searchbox input:focus{outline:0}
.hr{height:1px;background:var(--rule-2);margin:16px 0}
.stat-line{display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px dotted var(--rule);font-size:12.5px}
.stat-line span:last-child{font-family:'IBM Plex Mono',monospace;font-variant-numeric:tabular-nums}

@media (max-width:860px){
  .seal-row{grid-template-columns:1fr}
  .seal-box{border-right:0;border-bottom:1px solid var(--rule-2)}
  .kpis{grid-template-columns:repeat(2,1fr)}
  .kpi:nth-child(4n){border-right:1px solid var(--rule-2)}
  .kpi:nth-child(2n){border-right:0}
  .find{grid-template-columns:1fr}
  .find-margin{border-right:0;border-bottom:1px solid var(--rule)}
  .mast-meta{width:100%;margin-left:0;gap:18px}
}
@media (prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}

/* ---- analyser ---- */
.read{font-size:14.5px;line-height:1.62;max-width:78ch}
.read p{margin:0 0 10px}
.cause{border:1px solid var(--rule);border-radius:3px;background:var(--card);overflow:hidden;margin-bottom:10px}
.cause-h{display:flex;gap:12px;align-items:flex-start;padding:12px 14px;border-bottom:1px solid var(--rule-2)}
.cause-n{width:24px;height:24px;border:1px solid var(--seal);color:var(--seal);border-radius:50%;
  display:grid;place-items:center;font-size:11px;font-weight:700;flex:none;font-family:'IBM Plex Mono',monospace}
.cause-b{padding:12px 14px 14px}
.cause-meta{display:flex;gap:16px;flex-wrap:wrap;margin-top:8px;font-size:10px;letter-spacing:.08em;
  text-transform:uppercase;color:var(--ink-3)}
.cause-meta b{font-family:'IBM Plex Mono',monospace;color:var(--ink);letter-spacing:0;text-transform:none;font-size:12.5px}
.tag{font-family:'IBM Plex Mono',monospace;font-size:10px;background:#F2F2EE;border:1px solid var(--rule);
  padding:1px 5px;border-radius:2px;color:var(--ink-2);margin-right:4px;display:inline-block}
.askbar{display:flex;gap:8px;align-items:center;border:1px solid var(--seal);background:#fff;border-radius:2px;padding:0 12px}
.askbar input{border:0;outline:0;padding:11px 0;flex:1;font-size:13.5px}
.askbar input:focus{outline:0}
.answer{border-left:2.5px solid var(--seal);padding:2px 0 2px 13px;margin-top:12px;font-size:13.5px;line-height:1.6}
.suggest{display:flex;gap:6px;flex-wrap:wrap;margin-top:9px}
.suggest button{appearance:none;font:inherit;font-size:11.5px;color:var(--ink-2);background:#F6F6F2;
  border:1px solid var(--rule);border-radius:11px;padding:4px 10px;cursor:pointer}
.suggest button:hover{background:#EDEDE8;color:var(--ink)}

/* ---- structure optimiser ---- */
.struct{display:grid;grid-template-columns:1fr 26px 1fr;gap:0;align-items:stretch;border:1px solid var(--rule);border-radius:3px;overflow:hidden}
.struct-col{padding:12px 14px}
.struct-col.now{background:#FBFAF6}
.struct-col.next{background:var(--ok-wash)}
.struct-arrow{display:grid;place-items:center;background:#fff;border-left:1px solid var(--rule);border-right:1px solid var(--rule);color:var(--ink-3)}
.struct-k{font-size:9.5px;letter-spacing:.11em;text-transform:uppercase;color:var(--ink-3);margin-bottom:7px}
.bar{display:flex;height:9px;border-radius:2px;overflow:hidden;margin:9px 0 7px;border:1px solid var(--rule)}
.impact{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:0;border:1px solid var(--rule);border-radius:3px;margin-top:10px}
.impact div{padding:10px 12px;border-right:1px solid var(--rule-2)}
.impact div:last-child{border-right:0}
.impact .k{font-size:9px;letter-spacing:.1em;text-transform:uppercase;color:var(--ink-3)}
.impact .v{font-family:'IBM Plex Mono',monospace;font-size:15px;font-weight:600;margin-top:3px}

/* ---- report ---- */
.paper{background:#fff;border:1px solid var(--rule);border-radius:3px;overflow:hidden}
.paper-frame{width:100%;height:660px;border:0;display:block;background:#fff}
.exportbar{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
.toast{font-size:12px;color:var(--ok);margin-left:4px}
.spin{display:inline-block;width:11px;height:11px;border:2px solid currentColor;border-right-color:transparent;
  border-radius:50%;animation:sp .6s linear infinite}
@keyframes sp{to{transform:rotate(360deg)}}

/* ---- period bar ---- */
.periodbar{display:flex;gap:8px;align-items:center;background:#20242E;padding:8px 22px;
  border-bottom:1px solid #2C313C;flex-wrap:wrap}
.periodbar label{font-size:9px;letter-spacing:.12em;text-transform:uppercase;color:#7D8595;margin-right:2px}
.periodbar select{background:#2A2F3A;color:#EDEEEA;border:1px solid #3A404C;font-size:12.5px;padding:5px 8px}
.periodbar select:focus{outline:2px solid var(--seal);outline-offset:-1px}
.pstatus{display:flex;gap:14px;margin-left:auto;flex-wrap:wrap}
.pstatus span{font-size:11px;color:#9AA3B2;display:flex;align-items:center;gap:5px}
.pdot{width:7px;height:7px;border-radius:50%;flex:none}

/* ---- upload ---- */
.drop{border:1.5px dashed var(--rule);border-radius:3px;padding:18px 16px;text-align:center;
  background:#FBFBF9;cursor:pointer;transition:border-color .15s}
.drop:hover{border-color:var(--seal);background:#FAFAFE}
.drop b{display:block;font-size:13.5px;margin-bottom:3px}
.drop span{font-size:11.5px;color:var(--ink-2);line-height:1.5;display:block}
.drop.filled{border-style:solid;border-color:var(--ok);background:var(--ok-wash)}
.filemeta{display:flex;gap:16px;flex-wrap:wrap;margin-top:9px;font-size:11px;color:var(--ink-2)}
.filemeta b{font-family:'IBM Plex Mono',monospace;color:var(--ink);font-size:12px;display:block}

/* ---- reconciliation ---- */
.recon{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:0;
  border:1px solid var(--rule);border-radius:3px;overflow:hidden}
.recon div{padding:11px 13px;border-right:1px solid var(--rule-2)}
.recon div:last-child{border-right:0}
.recon .k{font-size:9px;letter-spacing:.1em;text-transform:uppercase;color:var(--ink-3)}
.recon .v{font-family:'IBM Plex Mono',monospace;font-size:16px;font-weight:600;margin-top:3px}

/* ---- contractor ---- */
.docgrid td:first-child{width:52%}
.docrow-crit{border-left:2px solid var(--crit)}
.stage{font-size:9px;letter-spacing:.11em;text-transform:uppercase;color:var(--ink-3);
  padding:12px 12px 5px;font-weight:600}
.miniform{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px}

/* ---- findings controls ---- */
.dismissed{opacity:.55}
.linkbtn{appearance:none;background:none;border:0;font:inherit;font-size:11.5px;color:var(--seal);
  cursor:pointer;padding:0;text-decoration:underline;text-underline-offset:2px}
.linkbtn:hover{color:var(--ink)}
.linkbtn.danger{color:var(--crit)}
.rowform{border:1px solid var(--seal);border-radius:3px;padding:13px;background:#FAFAFE;margin-top:10px}
.rowform .grid2{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px}
textarea{font:inherit;font-size:12.5px;padding:7px 9px;border:1px solid var(--rule);border-radius:2px;
  background:#fff;color:var(--ink);resize:vertical;min-height:62px;width:100%}
textarea:focus{outline:2px solid var(--seal);outline-offset:-1px;border-color:var(--seal)}
.empty{padding:34px 20px;text-align:center;color:var(--ink-2);font-size:13.5px;line-height:1.6}
.empty b{display:block;font-size:15px;color:var(--ink);margin-bottom:6px}
`;


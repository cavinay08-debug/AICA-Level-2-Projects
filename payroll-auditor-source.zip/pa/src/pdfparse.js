/* ============================================================================
   STATUTORY RETURN PDFs

   Reads the two documents an establishment actually holds:

     EPFO   Return Statement (Regular Return) — member-wise UAN, wages and
            contribution remitted
     ESIC   Monthly Contribution Details — IP-wise days, wages and employee
            contribution

   Text is mapped through the page viewport before anything else. The EPFO
   statement is written on a page with /Rotate 90, so its table comes out
   column-major from the raw text layer; the viewport transform puts every
   item into display coordinates and both documents then read as ordinary
   rows. Without that step the EPFO table parses as nonsense.

   Scanned documents carry no text layer and cannot be read here. The parser
   says so rather than returning empty results.
   ========================================================================== */

import * as pdfjs from "pdfjs-dist/legacy/build/pdf.mjs";

/* Rebuild visual lines from the text layer. -------------------------------- */
export async function pdfLines(data) {
  const doc = await pdfjs.getDocument({
    data: data instanceof Uint8Array ? data : new Uint8Array(data),
    useSystemFonts: true,
    isEvalSupported: false,
  }).promise;

  const pages = [];
  for (let p = 1; p <= doc.numPages; p++) {
    const page = await doc.getPage(p);
    const viewport = page.getViewport({ scale: 1 });
    const content = await page.getTextContent();

    const rows = [];
    for (const item of content.items) {
      if (!item.str || !item.str.trim()) continue;
      const t = pdfjs.Util.transform(viewport.transform, item.transform);
      const x = t[4], y = t[5];
      let row = rows.find((r) => Math.abs(r.y - y) <= 4);
      if (!row) rows.push((row = { y, items: [] }));
      row.items.push({ x, s: item.str });
    }

    pages.push(
      rows.sort((a, b) => a.y - b.y).map((r) => {
        const items = r.items.sort((a, b) => a.x - b.x);
        return {
          y: r.y,
          items,
          text: items.map((i) => i.s).join(" ").replace(/\s+/g, " ").trim(),
        };
      })
    );
  }
  await doc.destroy();
  return pages;
}

const flat = (pages) => pages.flat().map((r) => r.text);
const allRows = (pages) => pages.flat();
const money = (v) => Number(String(v ?? "").replace(/[₹,\s]/g, "")) || 0;
const MONTHS_SHORT = {
  jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6,
  jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12,
};

function readPeriod(text) {
  const m = /\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*[\s-]+(\d{4})/i.exec(text);
  return m ? { month: MONTHS_SHORT[m[1].toLowerCase()], year: Number(m[2]), label: `${m[1]}-${m[2]}` } : null;
}

/* ==========================================================================
   Which document is this?
   ========================================================================== */

export function identifyPdf(pages) {
  const head = flat(pages).slice(0, 30).join(" ").toLowerCase();
  if (!head.trim()) return "empty";
  if (head.includes("provident fund") || head.includes("return statement")) return "pf";
  if (head.includes("contribution details") || head.includes("employer code")) return "esic";
  return "unknown";
}

/* ==========================================================================
   EPFO Return Statement
   ========================================================================== */

export function parsePfPdf(pages) {
  const lines = flat(pages);
  const all = lines.join("\n");
  const errors = [];

  const grab = (re) => { const m = re.exec(all); return m ? m[1].trim() : ""; };
  const header = {
    establishment: grab(/Name of Establishment\s+(.+)/),
    establishmentId: grab(/Establishment Id\s+([A-Z0-9]+)/i),
    rate: money(grab(/Contribution Rate \(%\)\s+(\d+)/)),
    returnFileId: grab(/Return File Id\s+(\d+)/i),
    uploadedAt: grab(/Uploaded Date Time\s+(.+?)(?:\s+Total Members|$)/m),
    totalMembers: money(grab(/Total Members\s+(\d+)/i)),
    remarks: grab(/Remarks\s+(.+)/),
    period: readPeriod(lines.slice(0, 4).join(" ")),
  };
  const declared = {
    epf: money(grab(/Total EPF Contribution\s+([\d,]+)/i)),
    eps: money(grab(/Total EPS Contribution\s+([\d,]+)/i)),
    epfEps: money(grab(/Total EPF-EPS Contribution\s+([\d,]+)/i)),
    refunds: money(grab(/Total Refund of Advances\s+([\d,]+)/i)),
  };

  /* Member rows are read by position, not by text. Long names wrap onto the
     lines above and below the figures, and the two name columns wrap in
     parallel, so joining the text of those lines interleaves them. Each item
     is assigned to a column by its x instead. */
  const rows = [];
  const body = allRows(pages);

  const isNum = (t) => /^#?[\d,]+(\.\d+)?$/.test(t.trim());
  const num = (t) => money(String(t).replace("#", ""));

  body.forEach((row) => {
    const it = row.items;
    if (it.length < 3) return;
    const serial = it[0], uanItem = it[1];
    if (!/^\d{1,4}$/.test(serial.s.trim())) return;
    if (!/^\d{12}$/.test(uanItem.s.trim())) return;

    const figures = it.filter((x) => x.x >= 300 && x.x < 800 && isNum(x.s));
    if (figures.length < 8) return;                    // not a member row

    const n = figures.slice(0, 8).map((f) => num(f.s));
    const numericStart = Math.min(...figures.map((f) => f.x));
    const nameFrom = uanItem.x + 40;
    const nameTo = numericStart - 20;

    /* Name fragments sit within a few points of the figures row. Members are
       roughly 24 points apart, so a window of 8 cannot reach a neighbour. */
    const near = body.filter((r) => Math.abs(r.y - row.y) <= 8);
    const nameItems = near.flatMap((r) =>
      r.items.filter((x) => x.x >= nameFrom && x.x < nameTo && /[A-Za-z]/.test(x.s))
        .map((x) => ({ ...x, y: r.y })));

    let nameReturn = "", nameRepo = "";
    if (nameItems.length) {
      // Two name columns: split at the widest gap between x positions.
      const xs = [...new Set(nameItems.map((i) => Math.round(i.x)))].sort((a, b) => a - b);
      let cut = Infinity, gap = 0;
      for (let i = 1; i < xs.length; i++) {
        if (xs[i] - xs[i - 1] > gap) { gap = xs[i] - xs[i - 1]; cut = (xs[i] + xs[i - 1]) / 2; }
      }
      const join = (list) => list.sort((a, b) => a.y - b.y || a.x - b.x)
        .map((i) => i.s.trim()).join(" ").replace(/\s+/g, " ").trim();
      const left = nameItems.filter((i) => i.x < cut);
      const right = nameItems.filter((i) => i.x >= cut);
      nameReturn = join(left.length ? left : nameItems);
      nameRepo = right.length ? join(right) : nameReturn;
    }

    // The narrow trailing column is non-contributory days.
    const ncpItem = near.flatMap((r) => r.items)
      .find((x) => x.x >= 800 && isNum(x.s));

    rows.push({
      sl: Number(serial.s), uan: uanItem.s.trim(),
      name: nameReturn, nameRepository: nameRepo,
      nameMismatch: !!nameReturn && !!nameRepo &&
        nameReturn.toUpperCase() !== nameRepo.toUpperCase(),
      grossWages: n[0], epfWages: n[1], epsWages: n[2], edliWages: n[3],
      epfContri: n[4], epsContri: n[5], diffContri: n[6], refund: n[7],
      ncpDays: ncpItem ? num(ncpItem.s) : 0,
      deferredPension: figures.slice(0, 8).some((f) => f.s.includes("#")),
    });
  });

  rows.sort((a, b) => a.sl - b.sl);

  if (!rows.length) errors.push("No member rows were found in the return statement.");
  if (header.totalMembers && rows.length !== header.totalMembers)
    errors.push(`The statement declares ${header.totalMembers} members but ${rows.length} rows were read.`);

  const totals = rows.reduce((t, r) => ({
    members: t.members + 1,
    epfWages: t.epfWages + r.epfWages,
    grossWages: t.grossWages + r.grossWages,
    epfContri: t.epfContri + r.epfContri,
    epsContri: t.epsContri + r.epsContri,
    diffContri: t.diffContri + r.diffContri,
  }), { members: 0, epfWages: 0, grossWages: 0, epfContri: 0, epsContri: 0, diffContri: 0 });

  /* The document states its own totals. If the rows do not add up to them,
     the read is wrong and nothing downstream should be trusted. */
  const checks = [];
  if (declared.epf && Math.abs(declared.epf - totals.epfContri) > 2)
    checks.push(`Employee contribution reads ${totals.epfContri} against ${declared.epf} declared.`);
  if (declared.eps && Math.abs(declared.eps - totals.epsContri) > 2)
    checks.push(`Pension contribution reads ${totals.epsContri} against ${declared.eps} declared.`);
  if (declared.epfEps && Math.abs(declared.epfEps - totals.diffContri) > 2)
    checks.push(`Employer difference reads ${totals.diffContri} against ${declared.epfEps} declared.`);

  return {
    kind: "pf", format: "EPFO return statement (PDF)",
    header, declared, rows, totals, errors,
    selfCheck: { ok: checks.length === 0, notes: checks },
  };
}

/* ==========================================================================
   ESIC Monthly Contribution Details
   ========================================================================== */

export function parseEsicPdf(pages) {
  const lines = flat(pages);
  const all = lines.join("\n");
  const errors = [];

  const grab = (re) => { const m = re.exec(all); return m ? m[1].trim() : ""; };
  const header = {
    employerCode: grab(/Employer Code\s*:\s*(\d+)/i),
    employer: grab(/Employer Name\s*:\s*(.+)/i),
    contractorWise: /contractor-wise/i.test(all),
    period: readPeriod(lines[0] || ""),
  };

  /* serial | 10-digit IP | name | days | wages | disabled | reason | contribution
     The reason may be absent ("-") or two words ("No Work"), so the tail is
     read from the right. */
  const ROW = /^(\d{1,4})\s+(\d{8,12})\s+(.+?)\s+(\d{1,2})\s+([\d,]+\.\d{2})\s+(\S+)\s+(.*?)\s*([\d,]+\.\d{2})$/;

  const rows = [];
  for (const line of lines) {
    const m = ROW.exec(line);
    if (!m) continue;
    const [, sl, ip, name, days, wages, disabled, reason, contri] = m;
    rows.push({
      sl: Number(sl), ip, name: name.trim(),
      days: Number(days), wages: money(wages),
      disabled: disabled !== "-" && disabled !== "",
      reason: reason.trim() === "-" ? "" : reason.trim(),
      contribution: money(contri),
    });
  }

  if (!rows.length) errors.push("No insured person rows were found in the contribution list.");

  const totals = rows.reduce((t, r) => ({
    members: t.members + 1,
    wages: t.wages + r.wages,
    contribution: t.contribution + r.contribution,
    working: t.working + (r.days > 0 ? 1 : 0),
    idle: t.idle + (r.days === 0 ? 1 : 0),
  }), { members: 0, wages: 0, contribution: 0, working: 0, idle: 0 });

  const declared = {
    wages: money(grab(/Total\s*MonthlyWages\s*:\s*([\d,]+\.\d{2})/i)),
    ipContribution: money(grab(/Total IP Contribution\s*:\s*([\d,]+\.\d{2})/i)),
  };
  const foot = /([\d,]+\.\d{2})\s+([\d,]+\.\d{2})\s+([\d,]+\.\d{2})\s+([\d,]+\.\d{2})\s+([\d,]+\.\d{2})/.exec(all);
  if (foot) {
    declared.employerContribution = money(foot[2]);
    declared.totalContribution = money(foot[3]);
    declared.governmentContribution = money(foot[4]);
  }

  const checks = [];
  if (declared.wages && Math.abs(declared.wages - totals.wages) > 2)
    checks.push(`Wages read ${totals.wages} against ${declared.wages} declared.`);
  if (declared.ipContribution && Math.abs(declared.ipContribution - totals.contribution) > 2)
    checks.push(`Employee contribution reads ${totals.contribution} against ${declared.ipContribution} declared.`);

  return {
    kind: "esic", format: "ESIC monthly contribution list (PDF)",
    header, declared, rows, totals, errors,
    selfCheck: { ok: checks.length === 0, notes: checks },
  };
}

/* ==========================================================================
   Entry point
   ========================================================================== */

export async function readReturnPdf(data) {
  const pages = await pdfLines(data);
  const kind = identifyPdf(pages);
  if (kind === "empty") {
    return {
      kind: "empty", rows: [], errors: [
        "This PDF carries no text layer, which means it is a scan or an image.",
        "Text cannot be extracted from it here. Download the statement again " +
        "from the portal as a PDF rather than scanning a printout.",
      ],
    };
  }
  if (kind === "pf") return parsePfPdf(pages);
  if (kind === "esic") return parseEsicPdf(pages);
  return {
    kind: "unknown", rows: [],
    errors: ["This does not look like an EPFO return statement or an ESIC contribution list."],
  };
}

/* Shapes the reconciliation engine already understands. --------------------*/

export const pfRowsForRecon = (parsed) => ({
  rows: parsed.rows.map((r) => ({
    uan: r.uan, name: r.name, grossWages: r.grossWages, epfWages: r.epfWages,
    epsWages: r.epsWages, edliWages: r.edliWages, epfContri: r.epfContri,
    epsContri: r.epsContri, diffContri: r.diffContri, ncpDays: r.ncpDays,
    refund: r.refund, nameMismatch: r.nameMismatch, nameRepository: r.nameRepository,
  })),
  format: parsed.format,
  errors: parsed.errors,
  totals: {
    members: parsed.totals.members, epfWages: parsed.totals.epfWages,
    epfContri: parsed.totals.epfContri, epsContri: parsed.totals.epsContri,
    diffContri: parsed.totals.diffContri,
  },
});

export const esicRowsForRecon = (parsed) => ({
  rows: parsed.rows.map((r) => ({
    ip: r.ip, name: r.name, days: r.days, wages: r.wages,
    reason: r.reason, lastDay: "", contribution: r.contribution,
  })),
  format: parsed.format,
  errors: parsed.errors,
  totals: { members: parsed.totals.members, wages: parsed.totals.wages },
});

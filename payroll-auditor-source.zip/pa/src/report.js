/* ============================================================================
   REPORT — one document model rendered three ways.

   HTML : print-quality, A4, used on screen and as the source for PDF
   PDF  : Chromium printToPDF in the Electron main process, browser print
          dialog as the fallback when running as a web page
   DOCX : a real Word file built with the docx package, not HTML renamed
   ========================================================================== */

import {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  HeadingLevel, AlignmentType, WidthType, BorderStyle, PageBreak,
} from "docx";
import { inr, pct } from "./engine.js";

const today = () =>
  new Date().toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" });

/* --------------------------------------------------------------------------
   Report context. Everything the document needs beyond the audit itself.
   -------------------------------------------------------------------------- */

export const EMPTY_AUDITOR = {
  firm: "", name: "", membership: "", designation: "",
  place: "", date: "", ref: "", scopeNote: "",
};

const esc = (x) => String(x == null ? "" : x)
  .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

const sevClass = (s) =>
  ({ Critical: "crit", High: "high", Medium: "med", Low: "low", "Very Low": "low" }[s] || "low");

/* ==========================================================================
   HTML — also the source document for PDF
   ========================================================================== */

export function buildHtml(audited, A, P, ctx = {}) {
  const {
    forPrint = true, auditor = EMPTY_AUDITOR, recon = null,
    contract = null, contractSummary: cSum = null,
    observations = [], dismissed = [], orphans = [],
    cross = null, returns = {},
  } = ctx;

  const blocks = [];
  const section = (title, html) => blocks.push({ title, html });

  /* ---------------------------------------------------------------- 1 ---*/
  section("Executive summary", `
<div class="kpis">
  <div class="kpi"><div class="k">Compliance score</div><div class="v">${A.score}/100</div></div>
  <div class="kpi"><div class="k">Exceptions</div><div class="v">${A.all.length}</div></div>
  <div class="kpi"><div class="k">Estimated exposure</div><div class="v">${inr(A.exposure)}</div></div>
  <div class="kpi"><div class="k">Accrued gratuity</div><div class="v">${inr(A.gratuity)}</div></div>
</div>
${A.headline.map((h) => `<p class="lead">${esc(h)}</p>`).join("")}
${auditor.scopeNote ? `<p>${esc(auditor.scopeNote)}</p>` : ""}`);

  /* ---------------------------------------------------------------- 2 ---*/
  section("Basis of audit", `
<p>Every record in the wage register for ${esc(P.period)} was tested against the notified minimum
rates for the applicable zone and skill category, the wage definition in s.2(y) of the Code on Wages
including the fifty per cent proviso, provident fund and employees' state insurance coverage and
contribution, professional tax, statutory bonus, overtime compensation and the quarterly hour
ceiling, the deduction ceiling, the wage payment date and bank credit evidence, equal remuneration,
gratuity accrual, and the reconciliation of paid days against the wage period.</p>
<p>Wages are computed under s.2(y) throughout. Basic pay, dearness allowance and retaining allowance
form the inclusion. Where the excluded components in clauses (a) to (i) exceed one-half of total
remuneration, the excess is added back. Employer provident fund contribution and statutory bonus
count toward total remuneration without themselves being wages; gratuity and retrenchment
compensation are ring-fenced from the calculation. The same figure drives provident fund, insurance,
bonus, overtime and gratuity, which is why a single structural defect surfaces as several findings.</p>
<p>Insurance coverage is tested on gross monthly wages excluding overtime against the threshold of
${inr(P.esicWageLimit)}, which continues to apply. The contribution itself is computed on the wage
figure under s.2(88) of the Social Security Code, the basis that replaced the definition in the
Employees' State Insurance Act, 1948 with effect from 21 November 2025.</p>
${recon ? `<p>The provident fund return and the insurance contribution file for the period were
obtained and reconciled against the salary sheet, member by member, on identifier where available
and on name where not.</p>` : `<p>No statutory return was furnished for the period, so the audit
covers the salary sheet alone. Findings on what was actually remitted could not be formed.</p>`}`);

  /* ---------------------------------------------------------------- 3 ---*/
  section("What the audit found", `
<table>
  <tr><th>Rule</th><th>Exception</th><th>Severity</th><th>Spread</th><th class="n">Records</th><th class="n">Exposure</th></tr>
  ${A.patterns.map((r) => `
    <tr><td class="mono">${esc(r.code)}</td>
      <td>${esc(r.title)}<div class="sub">${esc(r.act)} \u2014 ${esc(r.sec)}</div></td>
      <td><span class="b b-${sevClass(r.sev)}">${esc(r.sev)}</span></td>
      <td>${esc(r.kind)}</td><td class="n">${r.n}</td>
      <td class="n">${r.exposure ? inr(r.exposure) : "\u2014"}</td></tr>`).join("")}
</table>`);

  /* --------------------------------------------------------- returns ---*/
  if (cross && cross.findings.length) {
    const pf = returns.pf, es = returns.esic;
    section("The statutory returns compared with each other", `
<p>The provident fund return and the insurance contribution list describe the same workforce for the
same month, filed with two different authorities. Read together they are tested against each other
before either is tested against the salary sheet.</p>
<table>
  <tr><th>Document</th><th>Filed for</th><th>Period</th><th class="n">Members</th><th class="n">Wages declared</th><th>Read</th></tr>
  ${pf ? `<tr><td>Provident fund return statement</td><td>${esc(pf.header.establishment)}<div class="sub mono">${esc(pf.header.establishmentId)}</div></td>
    <td>${esc(pf.header.period?.label || "\u2014")}</td><td class="n">${pf.rows.length}</td>
    <td class="n">${inr(pf.totals.grossWages)}</td>
    <td>${pf.selfCheck?.ok ? "agrees with its own totals" : '<span class="em">does not agree with its own totals</span>'}</td></tr>` : ""}
  ${es ? `<tr><td>Insurance monthly contribution${es.header.contractorWise ? " (contractor-wise)" : ""}</td>
    <td>${esc(es.header.employer)}<div class="sub mono">${esc(es.header.employerCode)}</div></td>
    <td>${esc(es.header.period?.label || "\u2014")}</td><td class="n">${es.rows.length}</td>
    <td class="n">${inr(es.totals.wages)}</td>
    <td>${es.selfCheck?.ok ? "agrees with its own totals" : '<span class="em">does not agree with its own totals</span>'}</td></tr>` : ""}
</table>
${cross.findings.map((f) => `
  <div class="f">
    <div class="f-h"><span class="mono code">${esc(f.code)}</span> <b>${esc(f.title)}</b>
      <span class="b b-${sevClass(f.sev)}">${esc(f.sev)}</span></div>
    <div class="cite">${esc(f.act)} \u2014 ${esc(f.sec)}</div>
    <p>${esc(f.plain)}</p>
    ${f.rows.length ? `<table class="mini" style="min-width:80%">
      <tr><th>Name</th><th>Identifier</th><th>Detail</th></tr>
      ${f.rows.slice(0, 15).map((r) => `<tr><td>${esc(r.name)}</td>
        <td class="mono">${esc(r.id)}</td><td>${esc(r.detail)}</td></tr>`).join("")}
    </table>` : ""}
    <p class="legal">${esc(f.legal)}</p>
    <p class="fix"><b>Correction.</b> ${esc(f.fix)}</p>
  </div>`).join("")}
${cross.summary.softMatched ? `<div class="note">The two returns share no common identifier: the fund
statement carries the universal account number and the insurance list carries the insurance number.
${cross.summary.softMatched} of ${cross.summary.matched} people were matched on name alone and should be
confirmed against the wage register before the findings above are relied on.</div>` : ""}`);
  }

  /* ---------------------------------------------------------------- 4 ---*/
  if (recon) {
    const pf = recon.summary.pf, esi = recon.summary.esi;
    section("Statutory return reconciliation", `
<p>The salary sheet is one record and the challan is another. What follows compares them.</p>
${pf ? `
<h3>Provident fund — electronic challan cum return</h3>
<table>
  <tr><th>Test</th><th class="n">Salary sheet</th><th class="n">Return</th><th class="n">Variance</th></tr>
  <tr><td>Members</td><td class="n">${pf.matched + pf.missing}</td><td class="n">${pf.members}</td>
    <td class="n ${pf.missing || pf.orphans ? "em" : ""}">${pf.missing} missing, ${pf.orphans} unmatched</td></tr>
  <tr><td>Employee contribution</td><td class="n">${inr(pf.sheetContri)}</td><td class="n">${inr(pf.returnContri)}</td>
    <td class="n ${Math.abs(pf.variance) > 2 ? "em" : ""}">${inr(pf.variance)}</td></tr>
  <tr><td>Wages declared</td><td class="n">\u2014</td><td class="n">${inr(pf.returnWages)}</td>
    <td class="n ${pf.wageGap > 2 ? "em" : ""}">${pf.wageGap ? inr(pf.wageGap) + " understated" : "agreed"}</td></tr>
</table>
${pf.softMatched ? `<div class="note">${pf.softMatched} member${pf.softMatched === 1 ? "" : "s"} matched on
name rather than universal account number. Confirm each before relying on the comparison.</div>` : ""}` : ""}
${esi ? `
<h3>Employees' state insurance — monthly contribution</h3>
<table>
  <tr><th>Test</th><th class="n">Salary sheet</th><th class="n">Return</th><th class="n">Variance</th></tr>
  <tr><td>Insured persons</td><td class="n">${esi.matched + esi.missing}</td><td class="n">${esi.members}</td>
    <td class="n ${esi.missing || esi.orphans ? "em" : ""}">${esi.missing} missing, ${esi.orphans} unmatched</td></tr>
  <tr><td>Wages</td><td class="n">${inr(esi.sheetWages)}</td><td class="n">${inr(esi.returnWages)}</td>
    <td class="n ${Math.abs(esi.variance) > 2 ? "em" : ""}">${inr(esi.variance)}</td></tr>
</table>` : ""}
${orphans.length ? orphans.map((o) => `
  <div class="f"><div class="f-h"><span class="mono code">${esc(o.code)}</span> <b>${esc(o.title)}</b>
    <span class="b b-${sevClass(o.sev)}">${esc(o.sev)}</span></div>
  <div class="cite">${esc(o.act)} \u2014 ${esc(o.sec)}</div>
  <p>${esc(o.plain)}</p><p class="legal">${esc(o.legal)}</p>
  <p class="fix"><b>Correction.</b> ${esc(o.fix)}</p>
  <table class="mini"><tr><th>Identifier</th><th>Name</th></tr>
    ${o.rows.slice(0, 12).map((r) => `<tr><td class="mono">${esc(r.uan || r.ip || "\u2014")}</td><td>${esc(r.name)}</td></tr>`).join("")}
  </table></div>`).join("") : ""}
<p>Member-level differences are carried into the employee-wise findings under codes beginning RC.</p>`);
  }

  /* ---------------------------------------------------------------- 5 ---*/
  if (contract?.length) {
    section("Contract labour compliance", `
<p>Contract labour sits in Chapter XI of the Occupational Safety, Health and Working Conditions Code,
2020, operative through the Central Rules notified on 8 May 2026, which repealed the Contract Labour
(Regulation and Abolition) Act, 1970. A contractor who has engaged fifty or more contract workers in
the preceding twelve months requires a single licence valid for five years, backed by a security
deposit of ${inr(1000)} per worker that the licensing authority may draw on directly where minimum
wages go unpaid. Liability for a contractor's default in wages, bonus or contributions rests with the
principal employer and is not displaced by an indemnity.</p>
<div class="kpis">
  <div class="kpi"><div class="k">Contractors</div><div class="v">${cSum.contractors}</div></div>
  <div class="kpi"><div class="k">Contract workers</div><div class="v">${cSum.workers}</div></div>
  <div class="kpi"><div class="k">Compliance score</div><div class="v">${cSum.score}/100</div></div>
  <div class="kpi"><div class="k">Exposure</div><div class="v">${inr(cSum.exposure)}</div></div>
</div>
<table>
  <tr><th>Contractor</th><th>Work</th><th class="n">Workers</th><th>Licence</th>
    <th class="n">Docs pending</th><th class="n">Findings</th><th>Risk</th></tr>
  ${contract.map((c) => `<tr>
    <td>${esc(c.name)}<div class="sub mono">${esc(c.id)}</div></td>
    <td>${esc(c.work)}</td><td class="n">${c.workers}</td>
    <td>${c.licenceNo ? esc(c.licenceNo) : `<span class="em">${c.needsLicence ? "not held" : "below threshold"}</span>`}</td>
    <td class="n">${c.docsPending}</td><td class="n">${c.findings.length}</td>
    <td><span class="b b-${sevClass(c.band)}">${c.risk} ${esc(c.band)}</span></td></tr>`).join("")}
</table>
${contract.filter((c) => c.findings.length).map((c) => `
  <div class="emp"><h3>${esc(c.name)} <span class="b b-${sevClass(c.band)}">risk ${c.risk}</span></h3>
  <div class="sub">${esc(c.work)} \u00B7 ${c.workers} deployed, peak ${c.workersPeak12m} over twelve months
    \u00B7 ${c.docsCriticalPending} mandatory document${c.docsCriticalPending === 1 ? "" : "s"} pending</div>
  ${c.findings.map((f) => `
    <div class="f"><div class="f-h"><span class="mono code">${esc(f.code)}</span> <b>${esc(f.title)}</b>
      <span class="b b-${sevClass(f.sev)}">${esc(f.sev)}</span></div>
    <div class="cite">${esc(f.act)} \u2014 ${esc(f.sec)}</div>
    <p>${esc(f.plain)}</p><p class="legal">${esc(f.legal)}</p>
    <p class="fix"><b>Correction.</b> ${esc(f.fix)}</p></div>`).join("")}
  </div>`).join("")}`);
  }

  /* ---------------------------------------------------------------- 6 ---*/
  section("Root cause analysis",
    A.causes.map((c) => `
      <h3>${esc(c.title)}</h3>
      <div class="sub">${c.employees} employees \u00B7 ${inr(c.exposure)} exposure \u00B7 rules ${c.rules.map((r) => r.code).join(", ")}</div>
      <p>${esc(c.why)}</p>`).join("") || "<p>No exception was raised.</p>");

  /* ---------------------------------------------------------------- 7 ---*/
  section("Remediation plan", `
<table>
  <tr><th class="n">#</th><th>Action</th><th>Owner</th><th>Effort</th><th>By when</th><th class="n">Staff</th><th class="n">Exposure</th></tr>
  ${A.plan.map((p) => `<tr><td class="n">${p.rank}</td>
    <td><b>${esc(p.title)}</b><div class="sub">${esc(p.action)}</div></td>
    <td>${esc(p.owner)}</td><td>${esc(p.effort)}</td><td>${esc(p.deadline)}</td>
    <td class="n">${p.employees}</td><td class="n">${inr(p.exposure)}</td></tr>`).join("")}
</table>
<h3>Registers that would not withstand an inspection</h3>
<ul>${A.registerRisk.filter((r) => r.fails).map((r) => `<li>${esc(r.doc)}</li>`).join("") || "<li>None.</li>"}</ul>`);

  /* ---------------------------------------------------------------- 8 ---*/
  section("Employee register", `
<table>
  <tr><th>ID</th><th>Name</th><th>Department</th><th class="n">Gross</th><th class="n">Wages s.2(y)</th>
    <th class="n">Wage share</th><th class="n">Findings</th><th class="n">Exposure</th><th>Risk</th></tr>
  ${audited.map((e) => `<tr>
    <td class="mono">${esc(e.id)}</td><td>${esc(e.name)}</td><td>${esc(e.dept)}</td>
    <td class="n">${inr(e.gross)}</td><td class="n">${inr(e.wages)}</td>
    <td class="n">${pct(e.w.includedShare)}</td><td class="n">${e.findings.length || "\u2014"}</td>
    <td class="n">${e.exposure ? inr(e.exposure) : "\u2014"}</td>
    <td><span class="b b-${sevClass(e.band)}">${e.risk} ${esc(e.band)}</span></td></tr>`).join("")}
</table>`);

  /* ---------------------------------------------------------------- 9 ---*/
  section("Employee-wise findings",
    audited.filter((e) => e.findings.length).map((e) => `
      <div class="emp">
        <h3>${esc(e.id)} &nbsp;\u00B7&nbsp; ${esc(e.name)}
          <span class="b b-${sevClass(e.band)}">risk ${e.risk} \u00B7 ${esc(e.band)}</span></h3>
        <div class="sub">${esc(e.desig)}, ${esc(e.dept)} \u00B7 ${esc(e.type)} \u00B7 ${esc(e.skill)}, Zone ${esc(e.zone)}
          \u00B7 wages ${inr(e.wages)} (${pct(e.w.includedShare)} of remuneration) \u00B7 exposure ${inr(e.exposure)}</div>
        ${e.findings.map((f) => `
          <div class="f">
            <div class="f-h"><span class="mono code">${esc(f.code)}</span> <b>${esc(f.title)}</b>
              <span class="b b-${sevClass(f.sev)}">${esc(f.sev)}</span>
              ${f.manual ? '<span class="b b-low">auditor</span>' : ""}</div>
            <div class="cite">${esc(f.act)} \u2014 ${esc(f.sec)}</div>
            ${f.delta > 0 ? `<table class="mini"><tr>
                <th>Computed</th><th>Recorded</th><th>Difference</th><th>Estimated exposure</th></tr>
              <tr><td class="n">${f.computed == null ? "\u2014" : inr(f.computed)}</td>
                <td class="n">${f.paid == null ? "\u2014" : inr(f.paid)}</td>
                <td class="n em">${inr(f.delta)}</td>
                <td class="n">${f.exposure ? inr(f.exposure) : "\u2014"}</td></tr></table>` : ""}
            <p>${esc(f.plain)}</p>
            <p class="legal">${esc(f.legal)}</p>
            <p class="fix"><b>Correction.</b> ${esc(f.fix)}</p>
          </div>`).join("")}
      </div>`).join("") || "<p>No exception was raised against any record for this period.</p>");

  /* --------------------------------------------------------------- 10 ---*/
  const bad = A.restructure.filter((x) => !x.e.w.compliantStructure);
  section("Salary structure recommendations", bad.length ? `
<p>The following structures fall below the fifty per cent floor. The proposed split holds the
employer's payable cost constant and moves the composition only. The change in provident fund
reflects the higher wage base and applies to the employee and employer share alike.</p>
<table>
  <tr><th>Employee</th><th class="n">Basic / DA now</th><th class="n">Share</th>
    <th class="n">Basic / DA proposed</th><th class="n">HRA</th><th class="n">Special</th>
    <th class="n">Share</th><th class="n">PF change</th></tr>
  ${bad.map(({ e, o }) => `<tr>
    <td>${esc(e.name)}<div class="sub mono">${esc(e.id)}</div></td>
    <td class="n">${inr(o.current.basic)} / ${inr(o.current.da)}</td>
    <td class="n">${pct(o.current.share)}</td>
    <td class="n">${inr(o.proposed.basic)} / ${inr(o.proposed.da)}</td>
    <td class="n">${inr(o.proposed.hra)}</td><td class="n">${inr(o.proposed.special)}</td>
    <td class="n">${pct(o.proposed.share)}</td>
    <td class="n">${o.pfDelta > 0 ? "+" : ""}${inr(o.pfDelta)}</td></tr>`).join("")}
</table>` : "<p>Every structure clears the fifty per cent floor. No restructuring is required.</p>");

  /* --------------------------------------------------------------- 11 ---*/
  const estObs = observations.filter((o) => !o.empId);
  if (estObs.length) {
    section("Auditor observations", `
<p>Recorded by the auditor on review of records and discussion with management, outside the rules
engine. Observations attached to a named employee appear with that employee above.</p>
${estObs.map((o) => `
  <div class="f"><div class="f-h"><span class="mono code">${esc(o.code)}</span> <b>${esc(o.title)}</b>
    <span class="b b-${sevClass(o.sev)}">${esc(o.sev)}</span></div>
  <div class="cite">${esc(o.act)} \u2014 ${esc(o.sec)}</div>
  <p>${esc(o.plain)}</p>
  ${o.exposure ? `<p class="sub">Estimated exposure ${inr(o.exposure)}</p>` : ""}
  <p class="fix"><b>Recommendation.</b> ${esc(o.fix)}</p></div>`).join("")}`);
  }

  /* --------------------------------------------------------------- 12 ---*/
  if (dismissed.length) {
    section("Findings not carried forward", `
<p>The following exceptions were raised by the engine and removed by the auditor. They are recorded
here with the reason so the working paper trail is complete.</p>
<table>
  <tr><th>Rule</th><th>Employee</th><th>Exception</th><th>Reason not carried forward</th></tr>
  ${dismissed.map((d) => `<tr>
    <td class="mono">${esc(d.code)}</td><td>${esc(d.empName || d.empId)}</td>
    <td>${esc(d.title)}</td><td>${esc(d.reason)}${d.note ? ` \u2014 ${esc(d.note)}` : ""}</td></tr>`).join("")}
</table>`);
  }

  /* --------------------------------------------------------------- 13 ---*/
  section("Limitations", `
<div class="note">Minimum wage rates, professional tax slabs and welfare fund amounts applied in this
audit are those configured in the rules engine at the time of the run. They vary by state, zone,
scheduled employment and skill category and are revised by notification. Verify each against the
notification in force for this establishment before relying on the findings.</div>
<p>Exposure figures are indicative estimates of arrears, damages and penalty bands. They are not a
computation of liability and do not account for interest, limitation, or any representation the
establishment may make. This report is a compliance review for management use and is not a legal
opinion. Findings are computed indicators for review against source records.</p>
${auditor.name || auditor.firm ? `
<div class="sign">
  <div class="sign-line"></div>
  ${auditor.firm ? `<div class="sign-firm">${esc(auditor.firm)}</div>` : ""}
  ${auditor.name ? `<div class="sign-name">${esc(auditor.name)}</div>` : ""}
  ${auditor.designation ? `<div class="sign-sub">${esc(auditor.designation)}</div>` : ""}
  ${auditor.membership ? `<div class="sign-sub">Membership no. ${esc(auditor.membership)}</div>` : ""}
  <div class="sign-sub">${auditor.place ? esc(auditor.place) + " \u00B7 " : ""}${esc(auditor.date || today())}</div>
</div>` : ""}`);

  /* ------------------------------------------------------------ assemble */
  const toc = blocks.map((b, i) => `<div><b>${i + 1}</b> ${esc(b.title)}</div>`).join("");
  const body = blocks.map((b, i) =>
    `<h2><span class="num">${i + 1}</span>${esc(b.title)}</h2>${b.html}`).join("\n");

  return `<!doctype html><html lang="en"><head><meta charset="utf-8">
<title>Payroll Compliance Audit Report \u2014 ${esc(P.establishment)}</title>
<style>
@page { size: A4; margin: 18mm 16mm 20mm; }
*{box-sizing:border-box}
body{font:10.5pt/1.55 "Segoe UI",-apple-system,Helvetica,Arial,sans-serif;color:#1A1D24;margin:0;
  ${forPrint ? "" : "max-width:900px;margin:0 auto;padding:28px;"}}
h1,h2,h3{margin:0;font-weight:600}
.cover{page-break-after:always;padding-top:22mm}
.cover .rule{height:3px;background:#1A1D24;margin-bottom:14px}
.cover h1{font-size:26pt;line-height:1.15;letter-spacing:-.01em}
.cover .sub2{font-size:11pt;color:#5A6373;margin-top:10px}
.cover dl{margin-top:22mm;border-top:1px solid #D5D8D2;padding-top:12px;
  display:grid;grid-template-columns:1fr 1fr;gap:0 24px}
.cover dt{font-size:8pt;letter-spacing:.12em;text-transform:uppercase;color:#8A919D;margin-top:11px}
.cover dd{margin:2px 0 0;font-size:11pt}
.toc{font-size:10pt;margin-top:14mm;border-top:1px solid #D5D8D2;padding-top:10px}
.toc div{padding:3px 0;color:#5A6373}
.toc b{color:#1A1D24;font-weight:600;display:inline-block;width:22px}
h2{font-size:13pt;margin:22px 0 9px;padding-bottom:5px;border-bottom:2px solid #1A1D24;page-break-after:avoid}
h2 .num{color:#4B3FA8;margin-right:9px;font-variant-numeric:tabular-nums}
h3{font-size:11pt;margin:16px 0 4px;page-break-after:avoid}
p{margin:0 0 8px}
.sub{font-size:8.5pt;color:#6B7280;margin-top:2px}
.kpis{display:flex;flex-wrap:wrap;gap:0;border:1px solid #D5D8D2;margin:12px 0 16px}
.kpi{flex:1 1 25%;padding:11px 13px;border-right:1px solid #E8E9E4;min-width:130px}
.kpi:last-child{border-right:0}
.kpi .k{font-size:7.5pt;letter-spacing:.1em;text-transform:uppercase;color:#8A919D}
.kpi .v{font-size:16pt;font-weight:600;margin-top:3px;font-variant-numeric:tabular-nums}
.lead{font-size:11pt;line-height:1.6}
ul{margin:0 0 10px;padding-left:17px}
li{margin-bottom:5px}
table{width:100%;border-collapse:collapse;font-size:8.5pt;margin:8px 0 14px}
th{background:#F4F5F1;text-align:left;padding:6px 8px;border-bottom:1.5px solid #C9CCC4;
  font-size:7.5pt;letter-spacing:.07em;text-transform:uppercase;color:#5A6373;font-weight:600}
td{padding:5px 8px;border-bottom:1px solid #E8E9E4;vertical-align:top}
tr{page-break-inside:avoid}
.n{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}
.em{font-weight:600;color:#A32218}
.mono{font-family:"Cascadia Mono",Consolas,monospace;font-size:8pt}
.b{display:inline-block;font-size:7pt;font-weight:700;letter-spacing:.06em;text-transform:uppercase;
  padding:1px 5px;border:1px solid;border-radius:2px;white-space:nowrap;margin-left:5px}
.b-crit{color:#A32218}.b-high{color:#B4610F}.b-med{color:#7A5E00}.b-low{color:#4B5563}
.emp{page-break-inside:avoid;margin-bottom:16px}
.f{border-left:2.5px solid #4B3FA8;padding:8px 0 2px 11px;margin:9px 0;page-break-inside:avoid}
.f-h{font-size:10pt}
.f-h .code{color:#4B3FA8;font-weight:600;margin-right:5px}
.cite{font-family:"Cascadia Mono",Consolas,monospace;font-size:7.5pt;color:#6B7280;margin:3px 0 6px}
.legal{color:#3A3F4A;border-left:2px solid #E8E9E4;padding-left:9px;font-size:9.5pt}
.fix{background:#EDF4F0;padding:6px 9px;border-radius:2px;font-size:9.5pt}
table.mini{width:auto;min-width:58%;margin:6px 0 8px}
table.mini th{background:none;border-bottom:1px solid #D5D8D2;padding:2px 14px 2px 0}
table.mini td{border:0;padding:2px 14px 2px 0}
.note{border:1px solid #E0D9BC;background:#FBF8EC;padding:9px 11px;font-size:9pt;margin:10px 0}
.sign{margin-top:26mm;page-break-inside:avoid}
.sign-line{width:62mm;border-top:1px solid #1A1D24;margin-bottom:6px}
.sign-firm{font-size:10.5pt;font-weight:600}
.sign-name{font-size:10.5pt;margin-top:2px}
.sign-sub{font-size:9pt;color:#5A6373;margin-top:2px}
footer{margin-top:22px;padding-top:8px;border-top:1px solid #D5D8D2;font-size:8pt;color:#8A919D}
</style></head><body>

<section class="cover">
  <div class="rule"></div>
  <h1>Payroll Compliance<br>Audit Report</h1>
  <div class="sub2">Statutory audit of the wage register under the Code on Wages, 2019 and the
    Code on Social Security, 2020, in force from 21 November 2025.</div>
  <dl>
    <dt>Establishment</dt><dd>${esc(P.establishment)}</dd>
    <dt>Location</dt><dd>${esc(P.location)}, ${esc(P.state)}</dd>
    <dt>Wage period</dt><dd>${esc(P.period)}</dd>
    <dt>Financial year</dt><dd>${esc(P.fy || "\u2014")}</dd>
    <dt>Records audited</dt><dd>${audited.length}</dd>
    <dt>Compliance score</dt><dd>${A.score} out of 100</dd>
    ${auditor.firm ? `<dt>Audited by</dt><dd>${esc(auditor.firm)}</dd>` : ""}
    ${auditor.name ? `<dt>Engagement partner</dt><dd>${esc(auditor.name)}${auditor.membership ? ` (M. no. ${esc(auditor.membership)})` : ""}</dd>` : ""}
    ${auditor.ref ? `<dt>Reference</dt><dd>${esc(auditor.ref)}</dd>` : ""}
    <dt>Report date</dt><dd>${esc(auditor.date || today())}</dd>
  </dl>
  <div class="toc">${toc}</div>
</section>

${body}

<footer>${esc(P.establishment)} \u00B7 ${esc(P.period)} \u00B7 ${auditor.firm ? esc(auditor.firm) + " \u00B7 " : ""}generated ${today()}</footer>
</body></html>`;
}

/* ==========================================================================
   DOCX
   ========================================================================== */

const INK = "1A1D24", GREY = "6B7280", SEAL = "4B3FA8", RED = "A32218";

const P_ = (text, o = {}) =>
  new Paragraph({
    spacing: { after: o.after ?? 110 },
    alignment: o.align,
    children: [new TextRun({
      text, bold: o.bold, italics: o.italics, color: o.color || INK,
      size: o.size || 20, font: o.font || "Calibri",
    })],
    ...(o.heading ? { heading: o.heading } : {}),
    ...(o.border ? { border: o.border } : {}),
  });

const H = (n, text) =>
  new Paragraph({
    spacing: { before: 300, after: 140 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 12, color: INK, space: 4 } },
    children: [
      new TextRun({ text: `${n}  `, bold: true, color: SEAL, size: 26 }),
      new TextRun({ text, bold: true, color: INK, size: 26 }),
    ],
  });

const cell = (text, o = {}) =>
  new TableCell({
    width: o.width ? { size: o.width, type: WidthType.PERCENTAGE } : undefined,
    shading: o.head ? { fill: "F4F5F1" } : undefined,
    margins: { top: 60, bottom: 60, left: 90, right: 90 },
    children: [new Paragraph({
      alignment: o.right ? AlignmentType.RIGHT : AlignmentType.LEFT,
      children: [new TextRun({
        text: String(text ?? ""), bold: o.head || o.bold,
        color: o.color || (o.head ? GREY : INK), size: o.size || 17,
      })],
    })],
  });

const table = (head, rows, widths) =>
  new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 4, color: "C9CCC4" },
      bottom: { style: BorderStyle.SINGLE, size: 4, color: "C9CCC4" },
      left: { style: BorderStyle.NONE }, right: { style: BorderStyle.NONE },
      insideHorizontal: { style: BorderStyle.SINGLE, size: 2, color: "E8E9E4" },
      insideVertical: { style: BorderStyle.NONE },
    },
    rows: [
      new TableRow({
        tableHeader: true,
        children: head.map((h, i) => cell(h.label, { head: true, right: h.right, width: widths?.[i] })),
      }),
      ...rows.map((r) => new TableRow({
        children: r.map((v, i) => cell(v, { right: head[i].right, color: head[i].color })),
      })),
    ],
  });

export async function buildDocx(audited, A, P, ctx = {}) {
  const { auditor = EMPTY_AUDITOR, recon = null, contract = null,
          contractSummary: cSum = null, observations = [], dismissed = [],
          cross = null, returns = {} } = ctx;
  const kids = [];

  // cover
  kids.push(
    new Paragraph({ spacing: { after: 40 }, border: { bottom: { style: BorderStyle.SINGLE, size: 24, color: INK, space: 1 } }, children: [] }),
    new Paragraph({ spacing: { before: 260, after: 100 }, children: [new TextRun({ text: "Payroll Compliance Audit Report", bold: true, size: 52, color: INK })] }),
    P_("Statutory audit of the wage register under the Code on Wages, 2019 and the Code on Social Security, 2020, in force from 21 November 2025.", { color: GREY, size: 22, after: 500 }),
  );
  [["Establishment", P.establishment], ["Location", `${P.location}, ${P.state}`],
   ["Wage period", P.period], ["Financial year", P.fy || "\u2014"],
   ["Records audited", String(audited.length)],
   ["Compliance score", `${A.score} out of 100`],
   ...(auditor.firm ? [["Audited by", auditor.firm]] : []),
   ...(auditor.name ? [["Engagement partner", auditor.name + (auditor.membership ? ` (M. no. ${auditor.membership})` : "")]] : []),
   ...(auditor.ref ? [["Reference", auditor.ref]] : []),
   ["Report date", auditor.date || today()]].forEach(([k, v]) => {
    kids.push(new Paragraph({
      spacing: { after: 70 },
      children: [
        new TextRun({ text: k.toUpperCase() + "   ", color: GREY, size: 15, bold: true }),
        new TextRun({ text: v, color: INK, size: 20 }),
      ],
    }));
  });
  kids.push(new Paragraph({ children: [new PageBreak()] }));

  // 1 executive summary
  kids.push(H(1, "Executive summary"));
  kids.push(table(
    [{ label: "Compliance score" }, { label: "Exceptions", right: true },
     { label: "Estimated exposure", right: true }, { label: "Accrued gratuity", right: true }],
    [[`${A.score}/100`, String(A.all.length), inr(A.exposure), inr(A.gratuity)]]
  ));
  kids.push(P_("", { after: 120 }));
  A.headline.forEach((h) => kids.push(P_(h, { size: 21 })));
  if (auditor.scopeNote) kids.push(P_(auditor.scopeNote, { size: 21 }));

  // 2 basis
  kids.push(H(2, "Basis of audit"));
  kids.push(P_(`Every record in the wage register for ${P.period} was tested against the notified minimum rates for the applicable zone and skill category, the wage definition in s.2(y) of the Code on Wages including the fifty per cent proviso, provident fund and employees' state insurance coverage and contribution, professional tax, statutory bonus, overtime compensation and the quarterly hour ceiling, the deduction ceiling, the wage payment date and bank credit evidence, equal remuneration, gratuity accrual, and the reconciliation of paid days against the wage period.`));
  kids.push(P_("Wages are computed under s.2(y) throughout. Basic pay, dearness allowance and retaining allowance form the inclusion. Where the excluded components in clauses (a) to (i) exceed one-half of total remuneration, the excess is added back. Employer provident fund contribution and statutory bonus count toward total remuneration without themselves being wages; gratuity and retrenchment compensation are ring-fenced from the calculation."));
  kids.push(P_(`Insurance coverage is tested on gross monthly wages excluding overtime against the threshold of ${inr(P.esicWageLimit)}, which continues to apply. The contribution itself is computed on the wage figure under s.2(88) of the Social Security Code, the basis that replaced the definition in the Employees' State Insurance Act, 1948 with effect from 21 November 2025.`));

  // 3 findings by rule
  kids.push(H(3, "What the audit found"));
  kids.push(table(
    [{ label: "Rule" }, { label: "Exception" }, { label: "Severity" }, { label: "Spread" },
     { label: "Records", right: true }, { label: "Exposure", right: true }],
    A.patterns.map((r) => [r.code, r.title, r.sev, r.kind, String(r.n), r.exposure ? inr(r.exposure) : "\u2014"])
  ));

  let sn = 3;

  if (cross && cross.findings.length) {
    kids.push(H(++sn, "The statutory returns compared with each other"));
    kids.push(P_("The provident fund return and the insurance contribution list describe the same workforce for the same month, filed with two different authorities. Read together they are tested against each other before either is tested against the salary sheet."));
    const docRows = [];
    if (returns.pf) docRows.push(["Provident fund return", returns.pf.header.establishment || "",
      returns.pf.header.period?.label || "", String(returns.pf.rows.length), inr(returns.pf.totals.grossWages)]);
    if (returns.esic) docRows.push(["Insurance contribution list", returns.esic.header.employer || "",
      returns.esic.header.period?.label || "", String(returns.esic.rows.length), inr(returns.esic.totals.wages)]);
    if (docRows.length) kids.push(table(
      [{ label: "Document" }, { label: "Filed for" }, { label: "Period" },
       { label: "Members", right: true }, { label: "Wages declared", right: true }], docRows));
    cross.findings.forEach((f) => {
      kids.push(new Paragraph({ spacing: { before: 160, after: 30 }, children: [
        new TextRun({ text: f.code + "  ", bold: true, color: SEAL, size: 19 }),
        new TextRun({ text: f.title, bold: true, size: 19 }),
        new TextRun({ text: `   [${f.sev}]`, color: f.sev === "Critical" ? RED : GREY, size: 17, bold: true }),
      ] }));
      kids.push(P_(`${f.act} \u2014 ${f.sec}`, { color: GREY, size: 16, after: 60 }));
      kids.push(P_(f.plain, { size: 19 }));
      if (f.rows.length) {
        kids.push(table([{ label: "Name" }, { label: "Identifier" }, { label: "Detail" }],
          f.rows.slice(0, 15).map((r) => [r.name, r.id, r.detail])));
        kids.push(P_("", { after: 40 }));
      }
      kids.push(P_(f.legal, { size: 18, italics: true, color: "3A3F4A" }));
      kids.push(P_(`Correction. ${f.fix}`, { size: 19, after: 160 }));
    });
  }

  if (recon) {
    const pf = recon.summary.pf, esi = recon.summary.esi;
    kids.push(H(++sn, "Statutory return reconciliation"));
    kids.push(P_("The salary sheet is one record and the challan is another. What follows compares them."));
    if (pf) {
      kids.push(P_("Provident fund \u2014 electronic challan cum return", { bold: true, size: 22, after: 60 }));
      kids.push(table(
        [{ label: "Test" }, { label: "Salary sheet", right: true }, { label: "Return", right: true }, { label: "Variance", right: true }],
        [["Members", String(pf.matched + pf.missing), String(pf.members), `${pf.missing} missing, ${pf.orphans} unmatched`],
         ["Employee contribution", inr(pf.sheetContri), inr(pf.returnContri), inr(pf.variance)],
         ["Wages declared", "\u2014", inr(pf.returnWages), pf.wageGap ? inr(pf.wageGap) + " understated" : "agreed"]]
      ));
      kids.push(P_("", { after: 80 }));
    }
    if (esi) {
      kids.push(P_("Employees' state insurance \u2014 monthly contribution", { bold: true, size: 22, after: 60 }));
      kids.push(table(
        [{ label: "Test" }, { label: "Salary sheet", right: true }, { label: "Return", right: true }, { label: "Variance", right: true }],
        [["Insured persons", String(esi.matched + esi.missing), String(esi.members), `${esi.missing} missing, ${esi.orphans} unmatched`],
         ["Wages", inr(esi.sheetWages), inr(esi.returnWages), inr(esi.variance)]]
      ));
      kids.push(P_("", { after: 80 }));
    }
    kids.push(P_("Member-level differences are carried into the employee-wise findings under codes beginning RC."));
  }

  // 5 contract labour
  if (contract && contract.length) {
    kids.push(H(++sn, "Contract labour compliance"));
    kids.push(P_("Contract labour sits in Chapter XI of the Occupational Safety, Health and Working Conditions Code, 2020, operative through the Central Rules notified on 8 May 2026, which repealed the Contract Labour (Regulation and Abolition) Act, 1970. A contractor who has engaged fifty or more contract workers in the preceding twelve months requires a single licence valid for five years, backed by a security deposit of Rs 1,000 per worker that the licensing authority may draw on directly where minimum wages go unpaid. Liability for a contractor's default in wages, bonus or contributions rests with the principal employer and is not displaced by an indemnity."));
    kids.push(table(
      [{ label: "Contractor" }, { label: "Work" }, { label: "Workers", right: true },
       { label: "Licence" }, { label: "Docs pending", right: true }, { label: "Risk" }],
      contract.map((c) => [c.name, c.work, String(c.workers),
        c.licenceNo || (c.needsLicence ? "not held" : "below threshold"),
        String(c.docsPending), `${c.risk} ${c.band}`])
    ));
    contract.filter((c) => c.findings.length).forEach((c) => {
      kids.push(P_(`${c.name} \u2014 risk ${c.risk}, ${c.band}`, { bold: true, size: 22, after: 40 }));
      c.findings.forEach((f) => {
        kids.push(new Paragraph({ spacing: { after: 30 }, children: [
          new TextRun({ text: f.code + "  ", bold: true, color: SEAL, size: 19 }),
          new TextRun({ text: f.title, bold: true, size: 19 }),
          new TextRun({ text: `   [${f.sev}]`, color: f.sev === "Critical" ? RED : GREY, size: 17, bold: true }),
        ] }));
        kids.push(P_(`${f.act} \u2014 ${f.sec}`, { color: GREY, size: 16, after: 60 }));
        kids.push(P_(f.plain, { size: 19 }));
        kids.push(P_(f.legal, { size: 18, italics: true, color: "3A3F4A" }));
        kids.push(P_(`Correction. ${f.fix}`, { size: 19, after: 180 }));
      });
    });
  }

  // root causes
  kids.push(H(++sn, "Root cause analysis"));
  A.causes.forEach((c) => {
    kids.push(P_(c.title, { bold: true, size: 22, after: 40 }));
    kids.push(P_(`${c.employees} employees \u00B7 ${inr(c.exposure)} exposure \u00B7 rules ${c.rules.map((r) => r.code).join(", ")}`, { color: GREY, size: 17, after: 60 }));
    kids.push(P_(c.why));
  });

  // 5 plan
  kids.push(H(++sn, "Remediation plan"));
  kids.push(table(
    [{ label: "#" }, { label: "Action" }, { label: "Owner" }, { label: "Effort" },
     { label: "By when" }, { label: "Staff", right: true }, { label: "Exposure", right: true }],
    A.plan.map((p) => [String(p.rank), `${p.title}. ${p.action}`, p.owner, p.effort, p.deadline, String(p.employees), inr(p.exposure)])
  ));

  // 6 register
  kids.push(H(++sn, "Employee register"));
  kids.push(table(
    [{ label: "ID" }, { label: "Name" }, { label: "Department" }, { label: "Gross", right: true },
     { label: "Wages s.2(y)", right: true }, { label: "Findings", right: true },
     { label: "Exposure", right: true }, { label: "Risk" }],
    audited.map((e) => [e.id, e.name, e.dept, inr(e.gross), inr(e.wages),
      String(e.findings.length || "\u2014"), e.exposure ? inr(e.exposure) : "\u2014", `${e.risk} ${e.band}`])
  ));

  // 7 employee-wise findings
  kids.push(H(++sn, "Employee-wise findings"));
  audited.filter((e) => e.findings.length).forEach((e) => {
    kids.push(P_(`${e.id}  \u00B7  ${e.name}   \u2014   risk ${e.risk}, ${e.band}`, { bold: true, size: 22, after: 30 }));
    kids.push(P_(`${e.desig}, ${e.dept} \u00B7 ${e.type} \u00B7 wages ${inr(e.wages)} (${pct(e.w.includedShare)} of remuneration) \u00B7 exposure ${inr(e.exposure)}`, { color: GREY, size: 17, after: 90 }));
    e.findings.forEach((f) => {
      kids.push(new Paragraph({
        spacing: { after: 30 },
        children: [
          new TextRun({ text: f.code + "  ", bold: true, color: SEAL, size: 19 }),
          new TextRun({ text: f.title, bold: true, size: 19 }),
          new TextRun({ text: `   [${f.sev}]`, color: f.sev === "Critical" ? RED : GREY, size: 17, bold: true }),
        ],
      }));
      kids.push(P_(`${f.act} \u2014 ${f.sec}`, { color: GREY, size: 16, after: 60 }));
      if (f.delta > 0) {
        kids.push(table(
          [{ label: "Computed", right: true }, { label: "Recorded", right: true },
           { label: "Difference", right: true }, { label: "Exposure", right: true }],
          [[f.computed == null ? "\u2014" : inr(f.computed), f.paid == null ? "\u2014" : inr(f.paid),
            inr(f.delta), f.exposure ? inr(f.exposure) : "\u2014"]]
        ));
        kids.push(P_("", { after: 40 }));
      }
      kids.push(P_(f.plain, { size: 19 }));
      kids.push(P_(f.legal, { size: 18, italics: true, color: "3A3F4A" }));
      kids.push(P_(`Correction. ${f.fix}`, { size: 19, after: 200 }));
    });
  });

  // 8 structures
  kids.push(H(++sn, "Salary structure recommendations"));
  const bad = A.restructure.filter((x) => !x.e.w.compliantStructure);
  if (bad.length) {
    kids.push(P_("The following structures fall below the fifty per cent floor. The proposed split holds the employer's payable cost constant and changes the composition only. The provident fund change reflects the higher wage base and applies to the employee and employer share alike."));
    kids.push(table(
      [{ label: "Employee" }, { label: "Basic / DA now", right: true }, { label: "Share", right: true },
       { label: "Basic / DA proposed", right: true }, { label: "HRA", right: true },
       { label: "Special", right: true }, { label: "Share", right: true }, { label: "PF change", right: true }],
      bad.map(({ e, o }) => [e.name, `${inr(o.current.basic)} / ${inr(o.current.da)}`, pct(o.current.share),
        `${inr(o.proposed.basic)} / ${inr(o.proposed.da)}`, inr(o.proposed.hra), inr(o.proposed.special),
        pct(o.proposed.share), (o.pfDelta > 0 ? "+" : "") + inr(o.pfDelta)])
    ));
  } else {
    kids.push(P_("Every structure clears the fifty per cent floor. No restructuring is required."));
  }

  // 9 limitations
  const estObs = observations.filter((o) => !o.empId);
  if (estObs.length) {
    kids.push(H(++sn, "Auditor observations"));
    kids.push(P_("Recorded by the auditor on review of records and discussion with management, outside the rules engine."));
    estObs.forEach((o) => {
      kids.push(new Paragraph({ spacing: { after: 30 }, children: [
        new TextRun({ text: o.code + "  ", bold: true, color: SEAL, size: 19 }),
        new TextRun({ text: o.title, bold: true, size: 19 }),
        new TextRun({ text: `   [${o.sev}]`, color: o.sev === "Critical" ? RED : GREY, size: 17, bold: true }),
      ] }));
      kids.push(P_(`${o.act} \u2014 ${o.sec}`, { color: GREY, size: 16, after: 60 }));
      kids.push(P_(o.plain, { size: 19 }));
      if (o.exposure) kids.push(P_(`Estimated exposure ${inr(o.exposure)}`, { size: 17, color: GREY }));
      kids.push(P_(`Recommendation. ${o.fix}`, { size: 19, after: 180 }));
    });
  }

  if (dismissed.length) {
    kids.push(H(++sn, "Findings not carried forward"));
    kids.push(P_("Raised by the engine and removed by the auditor, recorded with the reason so the working paper trail is complete."));
    kids.push(table(
      [{ label: "Rule" }, { label: "Employee" }, { label: "Exception" }, { label: "Reason" }],
      dismissed.map((d) => [d.code, d.empName || d.empId, d.title, d.reason + (d.note ? " \u2014 " + d.note : "")])
    ));
  }

  kids.push(H(++sn, "Limitations"));
  kids.push(P_("Minimum wage rates, professional tax slabs and welfare fund amounts applied in this audit are those configured in the rules engine at the time of the run. They vary by state, zone, scheduled employment and skill category and are revised by notification. Verify each against the notification in force for this establishment before relying on the findings.", { italics: true }));
  kids.push(P_("Exposure figures are indicative estimates of arrears, damages and penalty bands. They are not a computation of liability and do not account for interest, limitation, or any representation the establishment may make. This report is a compliance review for management use and is not a legal opinion."));

  if (auditor.firm || auditor.name) {
    kids.push(P_("", { after: 700 }));
    kids.push(new Paragraph({ spacing: { after: 60 },
      border: { top: { style: BorderStyle.SINGLE, size: 6, color: INK, space: 2 } }, children: [] }));
    if (auditor.firm) kids.push(P_(auditor.firm, { bold: true, size: 21, after: 30 }));
    if (auditor.name) kids.push(P_(auditor.name, { size: 21, after: 20 }));
    if (auditor.designation) kids.push(P_(auditor.designation, { size: 18, color: GREY, after: 20 }));
    if (auditor.membership) kids.push(P_("Membership no. " + auditor.membership, { size: 18, color: GREY, after: 20 }));
    kids.push(P_(`${auditor.place ? auditor.place + " \u00B7 " : ""}${auditor.date || today()}`, { size: 18, color: GREY }));
  }

  const doc = new Document({
    creator: "Payroll Auditor",
    title: `Payroll Compliance Audit Report — ${P.establishment}`,
    styles: { default: { document: { run: { font: "Calibri", size: 20, color: INK } } } },
    sections: [{
      properties: { page: { margin: { top: 1000, bottom: 1100, left: 900, right: 900 } } },
      children: kids,
    }],
  });
  return Packer.toBlob(doc);
}

/* ==========================================================================
   Export routing
   ========================================================================== */

function saveBlob(blob, filename) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}

const slug = (P) => `payroll-audit-${P.period.replace(/\s+/g, "-").toLowerCase()}`;

export async function exportHtml(audited, A, P, ctx = {}) {
  saveBlob(new Blob([buildHtml(audited, A, P, ctx)], { type: "text/html" }), `${slug(P)}.html`);
  return "Saved as HTML.";
}

export async function exportDocx(audited, A, P, ctx = {}) {
  const blob = await buildDocx(audited, A, P, ctx);
  saveBlob(blob, `${slug(P)}.docx`);
  return "Saved as Word document.";
}

export async function exportPdf(audited, A, P, ctx = {}) {
  const html = buildHtml(audited, A, P, ctx);
  // In the desktop app the main process renders the PDF with Chromium.
  if (window.app?.exportPdf) {
    const res = await window.app.exportPdf(html, `${slug(P)}.pdf`);
    return res?.saved ? `Saved to ${res.path}` : "Cancelled.";
  }
  // In a browser, hand it to the print dialog and let the user pick "Save as PDF".
  const f = document.createElement("iframe");
  f.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0";
  document.body.appendChild(f);
  f.contentDocument.write(html);
  f.contentDocument.close();
  await new Promise((r) => setTimeout(r, 350));
  f.contentWindow.focus();
  f.contentWindow.print();
  setTimeout(() => f.remove(), 60000);
  return "Opened the print dialog — choose Save as PDF.";
}

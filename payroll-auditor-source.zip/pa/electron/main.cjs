const { app, BrowserWindow, shell, session, dialog, ipcMain, protocol, net } = require("electron");
const path = require("path");
const fs = require("fs");
const { pathToFileURL } = require("url");

const isDev = !app.isPackaged;

/* Chromium refuses to execute ES module scripts over file:// — it treats the
   origin as opaque and blocks them as a CORS violation, which leaves the
   window blank with no visible error. Serve the built files over a custom
   scheme instead, which has a real origin and loads modules normally. */
const APP_ORIGIN = "app://bundle";
const DIST = path.join(__dirname, "..", "dist");

protocol.registerSchemesAsPrivileged([{
  scheme: "app",
  privileges: { standard: true, secure: true, supportFetchAPI: true, stream: true },
}]);

function serveBundle() {
  protocol.handle("app", async (request) => {
    let rel;
    try {
      rel = decodeURIComponent(new URL(request.url).pathname);
    } catch {
      return new Response("Bad request", { status: 400 });
    }
    if (rel === "/" || rel === "") rel = "/index.html";

    // Keep the resolved path inside dist.
    const target = path.normalize(path.join(DIST, rel));
    if (!target.startsWith(DIST)) return new Response("Forbidden", { status: 403 });

    if (!fs.existsSync(target)) {
      // Unknown path: fall back to the entry document.
      return net.fetch(pathToFileURL(path.join(DIST, "index.html")).toString());
    }
    return net.fetch(pathToFileURL(target).toString());
  });
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1440, height: 920, minWidth: 1024, minHeight: 700,
    backgroundColor: "#EDEEEA",
    title: "Payroll Auditor",
    show: false,
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  });

  win.once("ready-to-show", () => win.show());

  if (isDev) {
    win.loadURL("http://localhost:5173");
    win.webContents.openDevTools({ mode: "detach" });
  } else {
    win.loadURL(`${APP_ORIGIN}/index.html`);
  }

  // A blank window is the worst failure mode: it looks like nothing happened.
  // Say what went wrong instead.
  win.webContents.on("did-fail-load", (_e, code, desc, url) => {
    if (code === -3) return; // aborted, usually a redirect
    dialog.showErrorBox(
      "The application could not load",
      `${desc} (${code})\n${url}\n\nIf this persists, extract the zip again — ` +
      "a file may have been removed by antivirus."
    );
  });

  win.webContents.on("render-process-gone", (_e, details) => {
    dialog.showErrorBox("The application stopped unexpectedly", String(details.reason));
  });

  win.webContents.on("preload-error", (_e, file, err) => {
    dialog.showErrorBox("A startup script failed", `${file}\n\n${err && err.message}`);
  });

  // Surface renderer exceptions that would otherwise leave an empty window.
  ipcMain.on("renderer-fatal", (_e, message) => {
    dialog.showErrorBox("The interface could not start", String(message).slice(0, 1200));
  });

  // Last resort: if nothing has painted a few seconds in, say so rather than
  // leaving the user looking at an empty window with no explanation.
  win.webContents.on("did-finish-load", async () => {
    setTimeout(async () => {
      try {
        const painted = await win.webContents.executeJavaScript(
          'document.getElementById("root") && document.getElementById("root").children.length > 0');
        if (!painted) {
          dialog.showErrorBox(
            "The interface did not load",
            "The window opened but no content was drawn.\n\n" +
            "Most often a file was removed from the application folder by " +
            "antivirus. Extract the zip again to a local folder such as " +
            "C:\\PayrollAuditor, exclude that folder in your antivirus, and " +
            "run it from there rather than from a OneDrive or network folder."
          );
        }
      } catch { /* window already closed */ }
    }, 4000);
  });

  win.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: "deny" };
  });

  return win;
}

/* PDF. The renderer sends finished HTML; Chromium lays it out offscreen and
   prints it, so what is previewed on screen is what lands in the file. */
ipcMain.handle("export-pdf", async (event, { html, filename }) => {
  const parent = BrowserWindow.fromWebContents(event.sender);

  const { canceled, filePath } = await dialog.showSaveDialog(parent, {
    title: "Save audit report",
    defaultPath: path.join(app.getPath("documents"), filename || "audit-report.pdf"),
    filters: [{ name: "PDF", extensions: ["pdf"] }],
  });
  if (canceled || !filePath) return { saved: false };

  const worker = new BrowserWindow({ show: false, webPreferences: { offscreen: true } });

  try {
    await worker.loadURL("data:text/html;charset=utf-8," + encodeURIComponent(html));
    await new Promise((r) => setTimeout(r, 500));
    const pdf = await worker.webContents.printToPDF({
      pageSize: "A4",
      printBackground: true,
      margins: { marginType: "none" },
      preferCSSPageSize: true,
    });
    fs.writeFileSync(filePath, pdf);
    return { saved: true, path: filePath };
  } catch (err) {
    dialog.showErrorBox("Could not create the PDF", String(err.message || err));
    return { saved: false, error: String(err.message || err) };
  } finally {
    if (!worker.isDestroyed()) worker.destroy();
  }
});

/* Local state. Auditor details, dismissals, observations, contractors and
   uploaded periods live in a JSON file in the user data directory. Nothing
   leaves the machine. */
const storePath = () => path.join(app.getPath("userData"), "auditor-state.json");

ipcMain.handle("store-load", async () => {
  try {
    return JSON.parse(fs.readFileSync(storePath(), "utf8"));
  } catch {
    return null; // first run, or the file was removed
  }
});

ipcMain.handle("store-save", async (_e, state) => {
  try {
    fs.writeFileSync(storePath(), JSON.stringify(state), "utf8");
    return { saved: true, path: storePath() };
  } catch (err) {
    return { saved: false, error: String(err.message || err) };
  }
});

ipcMain.handle("store-reveal", async () => {
  shell.showItemInFolder(storePath());
});

app.whenReady().then(() => {
  if (!isDev) serveBundle();

  session.defaultSession.on("will-download", (_e, item) => {
    item.setSaveDialogOptions({
      title: "Save file",
      defaultPath: path.join(app.getPath("documents"), item.getFilename()),
    });
  });

  createWindow();
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

const { contextBridge, ipcRenderer } = require("electron");

// Report renderer crashes to the main process so the user sees a reason
// instead of an empty window.
window.addEventListener("error", (e) => {
  ipcRenderer.send("renderer-fatal",
    `${e.message}\n\n${e.filename || ""}:${e.lineno || 0}\n\n${(e.error && e.error.stack) || ""}`);
});
window.addEventListener("unhandledrejection", (e) => {
  ipcRenderer.send("renderer-fatal", "Unhandled promise rejection: " + String(e.reason));
});

contextBridge.exposeInMainWorld("app", {
  platform: process.platform,
  isDesktop: true,
  // Renders finished report HTML to PDF in the main process and prompts to save.
  exportPdf: (html, filename) => ipcRenderer.invoke("export-pdf", { html, filename }),
  // Local persistence — auditor details, dismissals, observations, uploads.
  loadState: () => ipcRenderer.invoke("store-load"),
  saveState: (state) => ipcRenderer.invoke("store-save", state),
  revealState: () => ipcRenderer.invoke("store-reveal"),
});

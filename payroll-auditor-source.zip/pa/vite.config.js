import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  // Relative paths so the bundle loads from the packaged app.
  base: "./",
  build: {
    outDir: "dist",
    emptyOutDir: true,
    // The PDF library uses top-level await. This app only ever runs in the
    // Chromium bundled with Electron 31 (Chrome 126), so the older browser
    // targets Vite defaults to are not worth supporting.
    target: "esnext",
    chunkSizeWarningLimit: 1600,
  },
  optimizeDeps: { esbuildOptions: { target: "esnext" } },
  worker: { format: "es" },
  server: { port: 5173, strictPort: true },
});

-- 1. Business unit master
create table if not exists public.business_units (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name text not null,
  external_code text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
grant select on public.business_units to authenticated;
grant all on public.business_units to service_role;
alter table public.business_units enable row level security;
create policy "bu readable" on public.business_units for select to authenticated using (true);
create policy "bu admin manage" on public.business_units for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

insert into public.business_units(code,name)
values ('BU-HO','Head Office'),('BU-OPS','Operations'),('BU-COM','Commercial')
on conflict (code) do nothing;

-- 2. External linkage codes on masters
alter table public.gl_accounts add column if not exists external_code text;
alter table public.cost_centers add column if not exists external_code text;
alter table public.cost_centers add column if not exists business_unit_id uuid references public.business_units(id);

-- 3. BU + cost center captured by the requester
alter table public.invoice_requests add column if not exists business_unit_id uuid references public.business_units(id);
alter table public.invoice_requests add column if not exists cost_center_id uuid references public.cost_centers(id);

-- 4. HOD approval no longer needs a printed signed sheet upload
create or replace function public.hod_action(p_id uuid, p_action text, p_comments text)
 returns void
 language plpgsql
 security definer
 set search_path to 'public'
as $function$
declare inv public.invoice_requests; dept public.departments;
begin
  select * into inv from public.invoice_requests where id = p_id;
  if inv.id is null then raise exception 'Request not found'; end if;
  select * into dept from public.departments where id = inv.department_id;
  if not (public.has_role(auth.uid(),'hod') and dept.id = public.my_department())
     and dept.escalation_user_id is distinct from auth.uid() then
    raise exception 'Only the head of this department can act on this request';
  end if;
  if inv.status <> 'submitted' then raise exception 'Request is not awaiting HOD approval'; end if;
  if p_action <> 'approve' and coalesce(trim(p_comments),'') = '' then
    raise exception 'A comment is mandatory when rejecting or returning';
  end if;
  if p_action = 'approve' then
    update public.invoice_requests set hod_system_approved_at = now(), hod_system_approved_by = auth.uid(),
      status = 'hod_approved' where id = p_id;
  elsif p_action = 'return' then
    update public.invoice_requests set status='returned', return_reason = p_comments, hod_system_approved_at=null
      where id = p_id;
  elsif p_action = 'reject' then
    update public.invoice_requests set status='rejected', return_reason = p_comments where id = p_id;
  else raise exception 'Unknown action'; end if;
  insert into public.approvals(invoice_id,approver_id,role,action,comments)
  values (p_id, auth.uid(),'hod',p_action,p_comments);
  perform public.log_audit('invoice_requests',p_id,'hod_'||p_action, jsonb_build_object('comments',p_comments));
end; $function$;
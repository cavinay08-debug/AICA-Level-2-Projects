ALTER TABLE public.vendors ADD COLUMN IF NOT EXISTS vat_registered boolean NOT NULL DEFAULT false, ADD COLUMN IF NOT EXISTS vrn text;
ALTER TABLE public.invoice_requests
  ADD COLUMN IF NOT EXISTS vat_registered_vendor boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS vat_rate numeric NOT NULL DEFAULT 18,
  ADD COLUMN IF NOT EXISTS amount_is_gross boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS efd_receipt_no text,
  ADD COLUMN IF NOT EXISTS efd_verification_code text,
  ADD COLUMN IF NOT EXISTS efd_qr_url text,
  ADD COLUMN IF NOT EXISTS efd_scanned_at timestamp with time zone;
INSERT INTO public.app_settings(key, value) VALUES ('vat', '{"standard_rate": 18}'::jsonb) ON CONFLICT (key) DO NOTHING;
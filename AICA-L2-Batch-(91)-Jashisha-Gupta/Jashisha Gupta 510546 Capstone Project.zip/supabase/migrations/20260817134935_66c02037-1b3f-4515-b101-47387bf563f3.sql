-- ============ ENUMS ============
create type public.app_role as enum ('requester','hod','finance_checker','finance_approver','finance_staff','admin');
create type public.invoice_status as enum ('draft','submitted','hod_approved','finance_checked','finance_approved','voucher_generated','payment_request','payment_confirmed','returned','rejected','closed');
create type public.expense_type as enum ('expense','capex');
create type public.reference_type as enum ('lpo','agreement','direct');
create type public.gl_type as enum ('expense','capex','wht_payable','vendor_ap');
create type public.attachment_type as enum ('scanned_invoice','hod_approval_sheet','submission_sheet','soa_upload','reference_doc','other');
create type public.match_status as enum ('strong_match','match_no_voucher_ref','multiple_candidates','mismatch','not_found','manually_resolved');

-- ============ CORE TABLES ============
create table public.departments (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  code text,
  hod_user_id uuid,
  escalation_user_id uuid,
  approval_threshold numeric(18,2) not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.profiles (
  id uuid primary key,
  full_name text not null default '',
  email text not null default '',
  department_id uuid references public.departments(id),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  role public.app_role not null,
  unique (user_id, role)
);

create table public.vendors (
  vendor_code text primary key,
  vendor_name text not null,
  tax_id text,
  bank_details text,
  wht_category text,
  wht_applicable boolean not null default false,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.wht_rates (
  id uuid primary key default gen_random_uuid(),
  wht_category text not null,
  rate_percent numeric(6,3) not null,
  effective_from date not null default current_date,
  effective_to date,
  created_at timestamptz not null default now()
);

create table public.gl_accounts (
  gl_code text primary key,
  gl_name text not null,
  type public.gl_type not null,
  department_id uuid references public.departments(id),
  active boolean not null default true
);

create table public.cost_centers (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name text not null,
  department_id uuid references public.departments(id),
  active boolean not null default true
);

create table public.app_settings (
  key text primary key,
  value jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create sequence public.invoice_seq;
create sequence public.voucher_seq;

create table public.invoice_requests (
  id uuid primary key default gen_random_uuid(),
  request_no text unique,
  requester_id uuid not null,
  department_id uuid not null references public.departments(id),
  vendor_name_free_text text not null,
  invoice_no text not null,
  invoice_date date not null,
  currency text not null default 'TZS',
  amount numeric(18,2) not null,
  tax_amount numeric(18,2) not null default 0,
  net_amount numeric(18,2) not null default 0,
  expense_type public.expense_type not null default 'expense',
  reference_type public.reference_type not null default 'direct',
  reference_number text,
  reference_date date,
  reference_vendor_name text,
  reference_validity text,
  description text,
  status public.invoice_status not null default 'draft',
  current_stage_owner uuid,
  return_reason text,
  hod_system_approved_at timestamptz,
  hod_system_approved_by uuid,
  hod_physical_signed_uploaded_at timestamptz,
  escalation_required boolean not null default false,
  escalation_approved_at timestamptz,
  vendor_code text references public.vendors(vendor_code),
  vendor_linked_by uuid,
  vendor_linked_at timestamptz,
  budget_reference text,
  wht_applicable boolean not null default false,
  wht_rate numeric(6,3) not null default 0,
  wht_amount numeric(18,2) not null default 0,
  wht_gl_code text references public.gl_accounts(gl_code),
  wht_override_reason text,
  submission_sheet_no text,
  physical_copy_received_at timestamptz,
  physical_copy_received_by uuid,
  finance_checker_id uuid,
  finance_approver_id uuid,
  revision_round integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.invoice_lines (
  id uuid primary key default gen_random_uuid(),
  invoice_id uuid not null references public.invoice_requests(id) on delete cascade,
  gl_code text references public.gl_accounts(gl_code),
  cost_center_id uuid references public.cost_centers(id),
  amount numeric(18,2) not null default 0,
  narration text
);

create table public.approvals (
  id uuid primary key default gen_random_uuid(),
  invoice_id uuid not null references public.invoice_requests(id) on delete cascade,
  approver_id uuid not null,
  role public.app_role not null,
  action text not null,
  comments text,
  created_at timestamptz not null default now()
);

create table public.vouchers (
  id uuid primary key default gen_random_uuid(),
  voucher_no text not null,
  invoice_id uuid not null references public.invoice_requests(id),
  line_no integer not null,
  gl_code text,
  vendor_code text,
  cost_center_id uuid,
  dr_cr text not null check (dr_cr in ('DR','CR')),
  amount numeric(18,2) not null,
  wht_rate numeric(6,3),
  wht_amount numeric(18,2),
  wht_gl_code text,
  reference_type public.reference_type,
  reference_number text,
  narration text,
  exported_flag boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.checker_corrections (
  id uuid primary key default gen_random_uuid(),
  invoice_id uuid not null references public.invoice_requests(id),
  finance_checker_id uuid,
  finance_approver_id uuid,
  field_corrected text not null,
  original_value text,
  corrected_value text,
  approver_comment text not null,
  revision_round_number integer not null default 1,
  returned_at timestamptz not null default now(),
  resolved_at timestamptz
);

create table public.payment_reconciliation (
  id uuid primary key default gen_random_uuid(),
  voucher_no text,
  invoice_id uuid not null references public.invoice_requests(id),
  match_status public.match_status not null,
  accounting_system_reference text,
  matched_vendor_code text,
  matched_amount numeric(18,2),
  matched_date date,
  date_tolerance_used integer,
  candidates jsonb,
  notes text,
  matched_at timestamptz not null default now(),
  matched_by uuid
);

create table public.attachments (
  id uuid primary key default gen_random_uuid(),
  invoice_id uuid references public.invoice_requests(id) on delete cascade,
  file_url text not null,
  file_name text,
  type public.attachment_type not null default 'other',
  uploaded_by uuid not null,
  uploaded_at timestamptz not null default now()
);

create table public.audit_log (
  id uuid primary key default gen_random_uuid(),
  entity text not null,
  entity_id uuid,
  action text not null,
  user_id uuid,
  details jsonb,
  created_at timestamptz not null default now()
);

-- ============ HELPERS ============
create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role);
$$;

create or replace function public.my_department()
returns uuid language sql stable security definer set search_path = public as $$
  select department_id from public.profiles where id = auth.uid();
$$;

create or replace function public.is_finance()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = auth.uid()
    and role in ('finance_checker','finance_approver','finance_staff','admin'));
$$;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select public.has_role(auth.uid(),'admin');
$$;

create or replace function public.log_audit(_entity text, _entity_id uuid, _action text, _details jsonb)
returns void language sql security definer set search_path = public as $$
  insert into public.audit_log(entity, entity_id, action, user_id, details)
  values (_entity, _entity_id, _action, auth.uid(), coalesce(_details,'{}'::jsonb));
$$;

create or replace function public.set_updated_at() returns trigger language plpgsql set search_path = public as $$
begin new.updated_at = now(); return new; end; $$;
create trigger trg_invoice_updated before update on public.invoice_requests for each row execute function public.set_updated_at();

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id, full_name, email)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''), coalesce(new.email,''))
  on conflict (id) do nothing;
  insert into public.user_roles(user_id, role) values (new.id,'requester') on conflict do nothing;
  return new;
end; $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

create or replace function public.block_voucher_change() returns trigger language plpgsql as $$
begin raise exception 'Vouchers are immutable'; end; $$;
create trigger trg_voucher_immutable before update or delete on public.vouchers for each row execute function public.block_voucher_change();

create or replace function public.block_correction_change() returns trigger language plpgsql as $$
begin raise exception 'Correction log is append-only'; end; $$;
create trigger trg_correction_immutable before delete on public.checker_corrections for each row execute function public.block_correction_change();

-- ============ GRANTS + RLS ============
grant select, insert, update, delete on public.departments, public.profiles, public.user_roles, public.vendors,
  public.wht_rates, public.gl_accounts, public.cost_centers, public.app_settings, public.invoice_requests,
  public.invoice_lines, public.approvals, public.vouchers, public.checker_corrections,
  public.payment_reconciliation, public.attachments, public.audit_log to authenticated;
grant all on public.departments, public.profiles, public.user_roles, public.vendors,
  public.wht_rates, public.gl_accounts, public.cost_centers, public.app_settings, public.invoice_requests,
  public.invoice_lines, public.approvals, public.vouchers, public.checker_corrections,
  public.payment_reconciliation, public.attachments, public.audit_log to service_role;
grant usage on sequence public.invoice_seq, public.voucher_seq to authenticated, service_role;

alter table public.departments enable row level security;
alter table public.profiles enable row level security;
alter table public.user_roles enable row level security;
alter table public.vendors enable row level security;
alter table public.wht_rates enable row level security;
alter table public.gl_accounts enable row level security;
alter table public.cost_centers enable row level security;
alter table public.app_settings enable row level security;
alter table public.invoice_requests enable row level security;
alter table public.invoice_lines enable row level security;
alter table public.approvals enable row level security;
alter table public.vouchers enable row level security;
alter table public.checker_corrections enable row level security;
alter table public.payment_reconciliation enable row level security;
alter table public.attachments enable row level security;
alter table public.audit_log enable row level security;

create policy "read departments" on public.departments for select to authenticated using (true);
create policy "admin departments" on public.departments for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "read vendors" on public.vendors for select to authenticated using (true);
create policy "admin vendors" on public.vendors for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "read wht" on public.wht_rates for select to authenticated using (true);
create policy "admin wht" on public.wht_rates for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "read gl" on public.gl_accounts for select to authenticated using (true);
create policy "admin gl" on public.gl_accounts for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "read cc" on public.cost_centers for select to authenticated using (true);
create policy "admin cc" on public.cost_centers for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "read settings" on public.app_settings for select to authenticated using (public.is_finance());
create policy "admin settings" on public.app_settings for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "read profiles" on public.profiles for select to authenticated using (true);
create policy "update own profile" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy "admin profiles" on public.profiles for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "read own roles" on public.user_roles for select to authenticated using (user_id = auth.uid() or public.is_admin() or public.is_finance());
create policy "admin roles" on public.user_roles for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "view invoices" on public.invoice_requests for select to authenticated using (
  requester_id = auth.uid()
  or (public.has_role(auth.uid(),'hod') and department_id = public.my_department())
  or (department_id in (select id from public.departments where escalation_user_id = auth.uid()))
  or public.is_finance()
);
create policy "create own draft" on public.invoice_requests for insert to authenticated
  with check (requester_id = auth.uid() and status = 'draft');
create policy "edit own draft" on public.invoice_requests for update to authenticated
  using (requester_id = auth.uid() and status in ('draft','returned'))
  with check (requester_id = auth.uid() and status in ('draft','returned'));
create policy "delete own draft" on public.invoice_requests for delete to authenticated
  using (requester_id = auth.uid() and status = 'draft');

create policy "view lines" on public.invoice_lines for select to authenticated using (
  exists (select 1 from public.invoice_requests i where i.id = invoice_id));
create policy "checker manages lines" on public.invoice_lines for all to authenticated using (
  public.has_role(auth.uid(),'finance_checker') and exists (
    select 1 from public.invoice_requests i where i.id = invoice_id and i.status in ('hod_approved','finance_checked','returned'))
) with check (
  public.has_role(auth.uid(),'finance_checker') and exists (
    select 1 from public.invoice_requests i where i.id = invoice_id and i.status in ('hod_approved','finance_checked','returned')));
create policy "requester manages draft lines" on public.invoice_lines for all to authenticated using (
  exists (select 1 from public.invoice_requests i where i.id = invoice_id and i.requester_id = auth.uid() and i.status in ('draft','returned'))
) with check (
  exists (select 1 from public.invoice_requests i where i.id = invoice_id and i.requester_id = auth.uid() and i.status in ('draft','returned')));

create policy "view approvals" on public.approvals for select to authenticated using (
  exists (select 1 from public.invoice_requests i where i.id = invoice_id));

create policy "view vouchers" on public.vouchers for select to authenticated using (
  exists (select 1 from public.invoice_requests i where i.id = invoice_id));

create policy "view corrections" on public.checker_corrections for select to authenticated using (
  public.is_finance());

create policy "view recon" on public.payment_reconciliation for select to authenticated using (public.is_finance());
create policy "finance recon write" on public.payment_reconciliation for insert to authenticated with check (
  public.has_role(auth.uid(),'finance_staff') or public.is_admin());
create policy "finance recon update" on public.payment_reconciliation for update to authenticated using (
  public.has_role(auth.uid(),'finance_staff') or public.is_admin()) with check (true);

create policy "view attachments" on public.attachments for select to authenticated using (
  exists (select 1 from public.invoice_requests i where i.id = invoice_id) or invoice_id is null);
create policy "upload attachments" on public.attachments for insert to authenticated with check (uploaded_by = auth.uid());

create policy "view audit" on public.audit_log for select to authenticated using (public.is_finance());
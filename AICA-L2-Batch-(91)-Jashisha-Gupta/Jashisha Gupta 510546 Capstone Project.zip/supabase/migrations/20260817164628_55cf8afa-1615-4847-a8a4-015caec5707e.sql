UPDATE public.departments
SET hod_user_id = COALESCE(hod_user_id, '0587e529-c517-4b4a-a365-74883568184b'::uuid),
    escalation_user_id = '0587e529-c517-4b4a-a365-74883568184b'::uuid;
-- ===== settings + seed masters =====
insert into public.app_settings(key,value) values
 ('reconciliation', '{"date_tolerance_days":3}'::jsonb),
 ('odbc', '{"enabled":false,"connection_string":"","table_or_view":"","field_vendor_code":"vendor_code","field_amount":"amount","field_posting_date":"posting_date","field_reference":"narration"}'::jsonb)
on conflict (key) do nothing;

insert into public.departments(name,code,approval_threshold) values
 ('Finance','FIN',5000000),('Operations','OPS',5000000),('IT','IT',3000000),('Human Resources','HR',2000000)
on conflict (name) do nothing;

insert into public.gl_accounts(gl_code,gl_name,type) values
 ('5001','Office Supplies Expense','expense'),
 ('5002','Professional & Consultancy Fees','expense'),
 ('5003','Repairs & Maintenance','expense'),
 ('5004','Utilities Expense','expense'),
 ('5005','Travel & Accommodation','expense'),
 ('1501','Computer Equipment (Capex)','capex'),
 ('1502','Motor Vehicles (Capex)','capex'),
 ('1503','Furniture & Fittings (Capex)','capex'),
 ('2101','WHT Payable','wht_payable'),
 ('2001','Accounts Payable - Vendors','vendor_ap')
on conflict (gl_code) do nothing;

insert into public.cost_centers(code,name) values
 ('CC-100','Head Office'),('CC-200','Operations Centre'),('CC-300','IT Services'),('CC-400','HR & Admin')
on conflict (code) do nothing;

insert into public.vendors(vendor_code,vendor_name,tax_id,wht_category,wht_applicable) values
 ('V-1001','Acme Office Supplies Ltd','TIN-100-100','goods',false),
 ('V-1002','Bright Consulting Services','TIN-200-200','professional_services',true),
 ('V-1003','Zenith Maintenance Co.','TIN-300-300','technical_services',true),
 ('V-1004','City Power Utility','TIN-400-400','exempt',false)
on conflict (vendor_code) do nothing;

insert into public.wht_rates(wht_category,rate_percent,effective_from) values
 ('professional_services',5.000,'2024-01-01'),
 ('technical_services',2.000,'2024-01-01'),
 ('goods',0.000,'2024-01-01'),
 ('exempt',0.000,'2024-01-01');

-- ===== helper: current wht rate =====
create or replace function public.current_wht_rate(_category text)
returns numeric language sql stable security definer set search_path = public as $$
  select coalesce((select rate_percent from public.wht_rates
    where wht_category = _category and effective_from <= current_date
      and (effective_to is null or effective_to >= current_date)
    order by effective_from desc limit 1), 0);
$$;

-- ===== SUBMIT =====
create or replace function public.submit_invoice(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare inv public.invoice_requests; thr numeric;
begin
  select * into inv from public.invoice_requests where id = p_id;
  if inv.id is null then raise exception 'Request not found'; end if;
  if inv.requester_id <> auth.uid() then raise exception 'Only the requester can submit this request'; end if;
  if inv.status not in ('draft','returned') then raise exception 'Only draft or returned requests can be submitted'; end if;
  if exists (select 1 from public.invoice_requests i where i.vendor_code is not null
      and i.vendor_code = inv.vendor_code and i.invoice_no = inv.invoice_no and i.id <> inv.id) then
    raise exception 'Duplicate invoice number for this vendor';
  end if;
  select approval_threshold into thr from public.departments where id = inv.department_id;
  update public.invoice_requests set
    status = 'submitted',
    request_no = coalesce(request_no, 'REQ-' || to_char(now(),'YYYY') || '-' || lpad(nextval('public.invoice_seq')::text,5,'0')),
    escalation_required = (inv.amount > coalesce(thr,0)),
    return_reason = null
  where id = p_id;
  insert into public.approvals(invoice_id,approver_id,role,action,comments)
  values (p_id, auth.uid(),'requester','submitted', null);
  perform public.log_audit('invoice_requests',p_id,'submitted', jsonb_build_object('amount',inv.amount));
end; $$;

-- ===== HOD ACTION =====
create or replace function public.hod_action(p_id uuid, p_action text, p_comments text)
returns void language plpgsql security definer set search_path = public as $$
declare inv public.invoice_requests; dept public.departments;
begin
  select * into inv from public.invoice_requests where id = p_id;
  if inv.id is null then raise exception 'Request not found'; end if;
  select * into dept from public.departments where id = inv.department_id;
  if not (public.has_role(auth.uid(),'hod') and dept.id = public.my_department())
     and dept.escalation_user_id is distinct from auth.uid() then
    raise exception 'Only the head of this department can act on this request';
  end if;
  if inv.status <> 'submitted' then raise exception 'Request is not awaiting HOD approval'; end if;
  if p_action <> 'approve' and coalesce(trim(p_comments),'') = '' then
    raise exception 'A comment is mandatory when rejecting or returning';
  end if;
  if p_action = 'approve' then
    update public.invoice_requests set hod_system_approved_at = now(), hod_system_approved_by = auth.uid() where id = p_id;
  elsif p_action = 'return' then
    update public.invoice_requests set status='returned', return_reason = p_comments, hod_system_approved_at=null,
      hod_physical_signed_uploaded_at=null where id = p_id;
  elsif p_action = 'reject' then
    update public.invoice_requests set status='rejected', return_reason = p_comments where id = p_id;
  else raise exception 'Unknown action'; end if;
  insert into public.approvals(invoice_id,approver_id,role,action,comments)
  values (p_id, auth.uid(),'hod',p_action,p_comments);
  perform public.log_audit('invoice_requests',p_id,'hod_'||p_action, jsonb_build_object('comments',p_comments));
end; $$;

-- ===== HOD PHYSICAL SHEET =====
create or replace function public.mark_hod_physical(p_id uuid, p_file_url text, p_file_name text)
returns void language plpgsql security definer set search_path = public as $$
declare inv public.invoice_requests;
begin
  select * into inv from public.invoice_requests where id = p_id;
  if inv.id is null then raise exception 'Request not found'; end if;
  if inv.requester_id <> auth.uid() and inv.hod_system_approved_by is distinct from auth.uid() then
    raise exception 'Only the requester or approving HOD can upload the signed sheet';
  end if;
  if inv.hod_system_approved_at is null then raise exception 'System approval by HOD is required first'; end if;
  insert into public.attachments(invoice_id,file_url,file_name,type,uploaded_by)
  values (p_id,p_file_url,p_file_name,'hod_approval_sheet',auth.uid());
  update public.invoice_requests set hod_physical_signed_uploaded_at = now(), status = 'hod_approved' where id = p_id;
  perform public.log_audit('invoice_requests',p_id,'hod_physical_uploaded', '{}'::jsonb);
end; $$;

-- ===== FINANCE CHECK =====
create or replace function public.finance_check_save(
  p_id uuid, p_vendor_code text, p_wht_applicable boolean, p_wht_rate numeric,
  p_wht_amount numeric, p_wht_gl_code text, p_override_reason text, p_budget_reference text, p_lines jsonb)
returns void language plpgsql security definer set search_path = public as $$
declare inv public.invoice_requests; l jsonb; total numeric := 0; suggested numeric; cat text;
begin
  select * into inv from public.invoice_requests where id = p_id;
  if inv.id is null then raise exception 'Request not found'; end if;
  if not public.has_role(auth.uid(),'finance_checker') then raise exception 'Only a Finance Checker can perform this action'; end if;
  if inv.status not in ('hod_approved','finance_checked') then raise exception 'Request is not in the finance check stage'; end if;
  if inv.status = 'finance_checked' and inv.finance_approver_id is not null then
    raise exception 'Request is with the Finance Approver';
  end if;
  if p_vendor_code is null then raise exception 'Vendor code is mandatory'; end if;
  if not exists (select 1 from public.vendors where vendor_code = p_vendor_code and active) then
    raise exception 'Vendor code is invalid or inactive'; end if;
  if exists (select 1 from public.invoice_requests i where i.id <> p_id and i.vendor_code = p_vendor_code
      and i.invoice_no = inv.invoice_no) then
    raise exception 'Duplicate invoice number already recorded for this vendor'; end if;

  select wht_category into cat from public.vendors where vendor_code = p_vendor_code;
  suggested := public.current_wht_rate(cat);
  if p_wht_applicable and p_wht_rate is distinct from suggested and coalesce(trim(p_override_reason),'') = '' then
    raise exception 'A reason is required when overriding the suggested WHT rate';
  end if;

  delete from public.invoice_lines where invoice_id = p_id;
  for l in select * from jsonb_array_elements(coalesce(p_lines,'[]'::jsonb)) loop
    insert into public.invoice_lines(invoice_id, gl_code, cost_center_id, amount, narration)
    values (p_id, l->>'gl_code', nullif(l->>'cost_center_id','')::uuid, (l->>'amount')::numeric, l->>'narration');
    total := total + (l->>'amount')::numeric;
  end loop;
  if total <> inv.amount then raise exception 'GL allocation (%) must equal the invoice amount (%)', total, inv.amount; end if;

  update public.invoice_requests set
    vendor_code = p_vendor_code, vendor_linked_by = auth.uid(), vendor_linked_at = now(),
    wht_applicable = coalesce(p_wht_applicable,false),
    wht_rate = case when p_wht_applicable then coalesce(p_wht_rate,0) else 0 end,
    wht_amount = case when p_wht_applicable then coalesce(p_wht_amount,0) else 0 end,
    wht_gl_code = case when p_wht_applicable then p_wht_gl_code else null end,
    wht_override_reason = p_override_reason,
    budget_reference = p_budget_reference,
    finance_checker_id = auth.uid()
  where id = p_id;
  perform public.log_audit('invoice_requests',p_id,'finance_check_saved', jsonb_build_object('vendor',p_vendor_code));
end; $$;

create or replace function public.finance_forward(p_id uuid)
returns text language plpgsql security definer set search_path = public as $$
declare inv public.invoice_requests; sheet text;
begin
  select * into inv from public.invoice_requests where id = p_id;
  if not public.has_role(auth.uid(),'finance_checker') then raise exception 'Only a Finance Checker can forward this request'; end if;
  if inv.status not in ('hod_approved','finance_checked') then raise exception 'Invalid stage'; end if;
  if inv.vendor_code is null then raise exception 'Link a vendor code before forwarding'; end if;
  if not exists (select 1 from public.invoice_lines where invoice_id = p_id) then raise exception 'Add at least one GL allocation line'; end if;
  sheet := coalesce(inv.submission_sheet_no, 'ISS-' || to_char(now(),'YYYYMM') || '-' || upper(substr(replace(p_id::text,'-',''),1,8)));
  update public.invoice_requests set status='finance_checked', submission_sheet_no = sheet,
    return_reason = null, finance_checker_id = auth.uid() where id = p_id;
  insert into public.approvals(invoice_id,approver_id,role,action,comments)
  values (p_id, auth.uid(),'finance_checker','forwarded_to_approver',null);
  update public.checker_corrections set resolved_at = now()
    where invoice_id = p_id and resolved_at is null;
  perform public.log_audit('invoice_requests',p_id,'forwarded_to_approver', jsonb_build_object('sheet',sheet));
  return sheet;
end; $$;

create or replace function public.mark_physical_received(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not (public.has_role(auth.uid(),'finance_checker') or public.has_role(auth.uid(),'finance_approver')) then
    raise exception 'Only finance can confirm receipt of the physical invoice'; end if;
  update public.invoice_requests set physical_copy_received_at = now(), physical_copy_received_by = auth.uid() where id = p_id;
  perform public.log_audit('invoice_requests',p_id,'physical_copy_received','{}'::jsonb);
end; $$;

-- ===== FINANCE APPROVER =====
create or replace function public.approver_action(p_id uuid, p_action text, p_comments text, p_field_corrected text)
returns text language plpgsql security definer set search_path = public as $$
declare inv public.invoice_requests; v_no text; ln record; dr numeric := 0; cr numeric := 0; n integer := 0; orig text;
begin
  select * into inv from public.invoice_requests where id = p_id;
  if inv.id is null then raise exception 'Request not found'; end if;
  if not public.has_role(auth.uid(),'finance_approver') then raise exception 'Only a Finance Approver can perform this action'; end if;
  if inv.status <> 'finance_checked' then raise exception 'Request is not awaiting final approval'; end if;
  if inv.finance_checker_id = auth.uid() then
    raise exception 'Segregation of duties: you checked this invoice and cannot approve it';
  end if;

  if p_action = 'return' then
    if coalesce(trim(p_comments),'') = '' then raise exception 'A correction comment is mandatory'; end if;
    orig := case p_field_corrected
      when 'Vendor Code' then inv.vendor_code
      when 'Cost Center' then (select string_agg(coalesce(c.code,'-'),',') from public.invoice_lines il left join public.cost_centers c on c.id = il.cost_center_id where il.invoice_id = p_id)
      when 'GL Account' then (select string_agg(coalesce(il.gl_code,'-'),',') from public.invoice_lines il where il.invoice_id = p_id)
      when 'Reference Type' then inv.reference_type::text
      when 'Amount' then inv.amount::text
      when 'WHT' then inv.wht_rate::text || '% / ' || inv.wht_amount::text
      else null end;
    insert into public.checker_corrections(invoice_id, finance_checker_id, finance_approver_id, field_corrected,
      original_value, approver_comment, revision_round_number)
    values (p_id, inv.finance_checker_id, auth.uid(), coalesce(nullif(p_field_corrected,''),'Other'), orig, p_comments, inv.revision_round + 1);
    update public.invoice_requests set status='hod_approved', return_reason = p_comments,
      revision_round = inv.revision_round + 1 where id = p_id;
    insert into public.approvals(invoice_id,approver_id,role,action,comments)
      values (p_id, auth.uid(),'finance_approver','returned_for_revision',p_comments);
    perform public.log_audit('invoice_requests',p_id,'returned_for_revision', jsonb_build_object('field',p_field_corrected));
    return null;
  elsif p_action = 'reject' then
    if coalesce(trim(p_comments),'') = '' then raise exception 'A comment is mandatory when rejecting'; end if;
    update public.invoice_requests set status='rejected', return_reason=p_comments where id = p_id;
    insert into public.approvals(invoice_id,approver_id,role,action,comments)
      values (p_id, auth.uid(),'finance_approver','rejected',p_comments);
    perform public.log_audit('invoice_requests',p_id,'rejected','{}'::jsonb);
    return null;
  elsif p_action <> 'approve' then raise exception 'Unknown action'; end if;

  -- APPROVE -> generate voucher
  if exists (select 1 from public.vouchers where invoice_id = p_id) then raise exception 'Voucher already exists'; end if;
  v_no := 'JV-' || to_char(now(),'YYYY') || '-' || lpad(nextval('public.voucher_seq')::text,5,'0');
  for ln in select * from public.invoice_lines where invoice_id = p_id order by id loop
    n := n + 1; dr := dr + ln.amount;
    insert into public.vouchers(voucher_no,invoice_id,line_no,gl_code,cost_center_id,dr_cr,amount,
      reference_type,reference_number,narration)
    values (v_no,p_id,n,ln.gl_code,ln.cost_center_id,'DR',ln.amount,inv.reference_type,inv.reference_number,
      coalesce(ln.narration, inv.description));
  end loop;
  if n = 0 then raise exception 'No GL allocation lines exist'; end if;
  n := n + 1; cr := cr + (dr - coalesce(inv.wht_amount,0));
  insert into public.vouchers(voucher_no,invoice_id,line_no,vendor_code,dr_cr,amount,wht_rate,wht_amount,wht_gl_code,
    reference_type,reference_number,narration)
  values (v_no,p_id,n,inv.vendor_code,'CR',dr - coalesce(inv.wht_amount,0),inv.wht_rate,inv.wht_amount,inv.wht_gl_code,
    inv.reference_type,inv.reference_number,'Being invoice '||inv.invoice_no||' payable to vendor');
  if coalesce(inv.wht_amount,0) > 0 then
    if inv.wht_gl_code is null then raise exception 'WHT payable GL account is required'; end if;
    n := n + 1; cr := cr + inv.wht_amount;
    insert into public.vouchers(voucher_no,invoice_id,line_no,gl_code,dr_cr,amount,wht_rate,wht_amount,wht_gl_code,
      reference_type,reference_number,narration)
    values (v_no,p_id,n,inv.wht_gl_code,'CR',inv.wht_amount,inv.wht_rate,inv.wht_amount,inv.wht_gl_code,
      inv.reference_type,inv.reference_number,'Withholding tax on invoice '||inv.invoice_no);
  end if;
  if dr <> cr then raise exception 'Voucher is not balanced: DR % vs CR %', dr, cr; end if;

  update public.invoice_requests set status='payment_request', finance_approver_id = auth.uid(), return_reason=null where id = p_id;
  insert into public.approvals(invoice_id,approver_id,role,action,comments)
    values (p_id, auth.uid(),'finance_approver','approved',p_comments);
  perform public.log_audit('vouchers',p_id,'voucher_generated', jsonb_build_object('voucher_no',v_no,'dr',dr,'cr',cr));
  return v_no;
end; $$;

-- ===== PAYMENT CONFIRMATION =====
create or replace function public.confirm_payment(p_id uuid, p_status text, p_reference text, p_notes text,
  p_matched_amount numeric, p_matched_date date, p_candidates jsonb)
returns void language plpgsql security definer set search_path = public as $$
declare inv public.invoice_requests; v_no text; tol integer;
begin
  if not (public.has_role(auth.uid(),'finance_staff') or public.is_admin()) then
    raise exception 'Only payment processing staff can record reconciliation'; end if;
  select * into inv from public.invoice_requests where id = p_id;
  select voucher_no into v_no from public.vouchers where invoice_id = p_id limit 1;
  select coalesce((value->>'date_tolerance_days')::int,3) into tol from public.app_settings where key='reconciliation';
  insert into public.payment_reconciliation(voucher_no,invoice_id,match_status,accounting_system_reference,
    matched_vendor_code,matched_amount,matched_date,date_tolerance_used,candidates,notes,matched_by)
  values (v_no,p_id,p_status::public.match_status,p_reference,inv.vendor_code,p_matched_amount,p_matched_date,tol,p_candidates,p_notes,auth.uid());
  if p_status in ('strong_match','match_no_voucher_ref','manually_resolved') then
    update public.invoice_requests set status='payment_confirmed' where id = p_id;
  end if;
  perform public.log_audit('payment_reconciliation',p_id,'match_'||p_status, jsonb_build_object('reference',p_reference));
end; $$;

create or replace function public.close_request(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not (public.has_role(auth.uid(),'finance_staff') or public.is_admin()) then raise exception 'Not permitted'; end if;
  update public.invoice_requests set status='closed' where id = p_id and status='payment_confirmed';
  perform public.log_audit('invoice_requests',p_id,'closed','{}'::jsonb);
end; $$;

create or replace function public.mark_vouchers_exported(p_voucher_nos text[])
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_finance() then raise exception 'Not permitted'; end if;
  perform public.log_audit('vouchers',null,'exported', jsonb_build_object('vouchers',p_voucher_nos));
end; $$;

revoke execute on all functions in schema public from anon;

ALTER TABLE public.invoice_requests
  ADD CONSTRAINT invoice_requests_requester_id_fkey
  FOREIGN KEY (requester_id) REFERENCES public.profiles(id) ON DELETE RESTRICT;
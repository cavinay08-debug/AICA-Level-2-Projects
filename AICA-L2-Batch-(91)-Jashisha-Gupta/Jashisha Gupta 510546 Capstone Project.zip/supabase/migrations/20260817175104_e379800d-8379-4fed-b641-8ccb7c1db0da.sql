alter type public.attachment_type add value if not exists 'efd_receipt';
alter type public.attachment_type add value if not exists 'grn_copy';
alter type public.attachment_type add value if not exists 'email_confirmation';
alter type public.attachment_type add value if not exists 'delivery_note';
alter type public.attachment_type add value if not exists 'lpo_copy';
alter type public.attachment_type add value if not exists 'contract_copy';
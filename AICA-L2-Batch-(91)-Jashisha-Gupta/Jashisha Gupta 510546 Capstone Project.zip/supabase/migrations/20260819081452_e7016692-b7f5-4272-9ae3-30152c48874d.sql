GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_admin() TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_finance() TO authenticated;
GRANT EXECUTE ON FUNCTION public.my_department() TO authenticated;
GRANT EXECUTE ON FUNCTION public.can_view_invoice(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.log_audit(text, uuid, text, jsonb) TO authenticated;
INSERT INTO public.user_roles (user_id, role)
SELECT '0587e529-c517-4b4a-a365-74883568184b'::uuid, r
FROM unnest(ARRAY['requester','hod','finance_checker','finance_approver','finance_staff','admin']::app_role[]) AS r
ON CONFLICT (user_id, role) DO NOTHING;
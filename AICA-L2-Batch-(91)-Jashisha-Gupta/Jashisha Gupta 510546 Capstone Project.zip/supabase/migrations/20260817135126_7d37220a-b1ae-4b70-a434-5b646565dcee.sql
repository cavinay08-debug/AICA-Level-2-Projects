create policy "upload invoice docs" on storage.objects for insert to authenticated
  with check (bucket_id = 'invoice-docs');
create policy "read invoice docs" on storage.objects for select to authenticated
  using (bucket_id = 'invoice-docs');
create policy "update own invoice docs" on storage.objects for update to authenticated
  using (bucket_id = 'invoice-docs' and owner = auth.uid());
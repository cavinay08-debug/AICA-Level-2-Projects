alter table public.invoice_requests
  add column if not exists fx_remarks text,
  add column if not exists fx_rate numeric;

create or replace function public.submit_invoice(p_id uuid)
 returns void
 language plpgsql
 security definer
 set search_path to 'public'
as $function$
declare inv public.invoice_requests; thr numeric;
begin
  select * into inv from public.invoice_requests where id = p_id;
  if inv.id is null then raise exception 'Request not found'; end if;
  if inv.requester_id <> auth.uid() then raise exception 'Only the requester can submit this request'; end if;
  if inv.status not in ('draft','returned') then raise exception 'Only draft or returned requests can be submitted'; end if;
  if coalesce(inv.currency,'TZS') <> 'TZS' and coalesce(trim(inv.fx_remarks),'') = '' then
    raise exception 'Foreign currency remarks are mandatory for non-TZS invoices';
  end if;
  if exists (select 1 from public.invoice_requests i where i.vendor_code is not null
      and i.vendor_code = inv.vendor_code and i.invoice_no = inv.invoice_no and i.id <> inv.id) then
    raise exception 'Duplicate invoice number for this vendor';
  end if;
  select approval_threshold into thr from public.departments where id = inv.department_id;
  update public.invoice_requests set
    status = 'submitted',
    request_no = coalesce(request_no, 'REQ-' || to_char(now(),'YYYY') || '-' || lpad(nextval('public.invoice_seq')::text,5,'0')),
    escalation_required = (inv.amount > coalesce(thr,0)),
    return_reason = null
  where id = p_id;
  insert into public.approvals(invoice_id,approver_id,role,action,comments)
  values (p_id, auth.uid(),'requester','submitted', null);
  perform public.log_audit('invoice_requests',p_id,'submitted', jsonb_build_object('amount',inv.amount));
end; $function$;

create or replace function public.receive_physical_scan(p_code text)
 returns uuid
 language plpgsql
 security definer
 set search_path to 'public'
as $function$
declare v_id uuid; v_code text;
begin
  if not (public.is_finance()) then
    raise exception 'Only Finance can log receipt of the physical invoice';
  end if;
  v_code := upper(trim(coalesce(p_code,'')));
  if v_code = '' then raise exception 'Nothing scanned'; end if;

  -- accept a full URL, a request number, a submission sheet number or a raw id
  select id into v_id from public.invoice_requests
   where upper(coalesce(request_no,'')) = v_code
      or upper(coalesce(submission_sheet_no,'')) = v_code
      or replace(id::text,'-','') = replace(lower(v_code),'-','')
   limit 1;

  if v_id is null then
    select id into v_id from public.invoice_requests
     where v_code like '%' || upper(replace(id::text,'-','')) || '%'
        or v_code like '%' || upper(id::text) || '%'
        or v_code like '%' || upper(coalesce(request_no,'~none~')) || '%'
     limit 1;
  end if;

  if v_id is null then raise exception 'No request matches this QR code'; end if;

  update public.invoice_requests
     set physical_copy_received_at = coalesce(physical_copy_received_at, now()),
         physical_copy_received_by = coalesce(physical_copy_received_by, auth.uid())
   where id = v_id;
  perform public.log_audit('invoice_requests',v_id,'physical_copy_received_by_scan', jsonb_build_object('code',v_code));
  return v_id;
end; $function$;

create or replace function public.approver_action(p_id uuid, p_action text, p_comments text, p_field_corrected text)
 returns text
 language plpgsql
 security definer
 set search_path to 'public'
as $function$
declare inv public.invoice_requests; v_no text; ln record; dr numeric := 0; cr numeric := 0; n integer := 0; orig text;
begin
  select * into inv from public.invoice_requests where id = p_id;
  if inv.id is null then raise exception 'Request not found'; end if;
  if not public.has_role(auth.uid(),'finance_approver') then raise exception 'Only a Finance Approver can perform this action'; end if;
  if inv.status <> 'finance_checked' then raise exception 'Request is not awaiting final approval'; end if;
  if inv.finance_checker_id = auth.uid() and not public.is_admin() then
    raise exception 'Segregation of duties: you checked this invoice and cannot approve it';
  end if;

  if p_action = 'return' then
    if coalesce(trim(p_comments),'') = '' then raise exception 'A correction comment is mandatory'; end if;
    orig := case p_field_corrected
      when 'Vendor Code' then inv.vendor_code
      when 'Cost Center' then (select string_agg(coalesce(c.code,'-'),',') from public.invoice_lines il left join public.cost_centers c on c.id = il.cost_center_id where il.invoice_id = p_id)
      when 'GL Account' then (select string_agg(coalesce(il.gl_code,'-'),',') from public.invoice_lines il where il.invoice_id = p_id)
      when 'Reference Type' then inv.reference_type::text
      when 'Amount' then inv.amount::text
      when 'WHT' then inv.wht_rate::text || '% / ' || inv.wht_amount::text
      else null end;
    insert into public.checker_corrections(invoice_id, finance_checker_id, finance_approver_id, field_corrected,
      original_value, approver_comment, revision_round_number)
    values (p_id, inv.finance_checker_id, auth.uid(), coalesce(nullif(p_field_corrected,''),'Other'), orig, p_comments, inv.revision_round + 1);
    update public.invoice_requests set status='hod_approved', return_reason = p_comments,
      revision_round = inv.revision_round + 1 where id = p_id;
    insert into public.approvals(invoice_id,approver_id,role,action,comments)
      values (p_id, auth.uid(),'finance_approver','returned_for_revision',p_comments);
    perform public.log_audit('invoice_requests',p_id,'returned_for_revision', jsonb_build_object('field',p_field_corrected));
    return null;
  elsif p_action = 'reject' then
    if coalesce(trim(p_comments),'') = '' then raise exception 'A comment is mandatory when rejecting'; end if;
    update public.invoice_requests set status='rejected', return_reason=p_comments where id = p_id;
    insert into public.approvals(invoice_id,approver_id,role,action,comments)
      values (p_id, auth.uid(),'finance_approver','rejected',p_comments);
    perform public.log_audit('invoice_requests',p_id,'rejected','{}'::jsonb);
    return null;
  elsif p_action <> 'approve' then raise exception 'Unknown action'; end if;

  if exists (select 1 from public.vouchers where invoice_id = p_id) then raise exception 'Voucher already exists'; end if;
  v_no := 'JV-' || to_char(now(),'YYYY') || '-' || lpad(nextval('public.voucher_seq')::text,5,'0');
  for ln in select * from public.invoice_lines where invoice_id = p_id order by id loop
    n := n + 1; dr := dr + ln.amount;
    insert into public.vouchers(voucher_no,invoice_id,line_no,gl_code,cost_center_id,dr_cr,amount,
      reference_type,reference_number,narration)
    values (v_no,p_id,n,ln.gl_code,ln.cost_center_id,'DR',ln.amount,inv.reference_type,inv.reference_number,
      coalesce(ln.narration, inv.description));
  end loop;
  if n = 0 then raise exception 'No GL allocation lines exist'; end if;
  n := n + 1; cr := cr + (dr - coalesce(inv.wht_amount,0));
  insert into public.vouchers(voucher_no,invoice_id,line_no,vendor_code,dr_cr,amount,wht_rate,wht_amount,wht_gl_code,
    reference_type,reference_number,narration)
  values (v_no,p_id,n,inv.vendor_code,'CR',dr - coalesce(inv.wht_amount,0),inv.wht_rate,inv.wht_amount,inv.wht_gl_code,
    inv.reference_type,inv.reference_number,'Being invoice '||inv.invoice_no||' payable to vendor');
  if coalesce(inv.wht_amount,0) > 0 then
    if inv.wht_gl_code is null then raise exception 'WHT payable GL account is required'; end if;
    n := n + 1; cr := cr + inv.wht_amount;
    insert into public.vouchers(voucher_no,invoice_id,line_no,gl_code,dr_cr,amount,wht_rate,wht_amount,wht_gl_code,
      reference_type,reference_number,narration)
    values (v_no,p_id,n,inv.wht_gl_code,'CR',inv.wht_amount,inv.wht_rate,inv.wht_amount,inv.wht_gl_code,
      inv.reference_type,inv.reference_number,'Withholding tax on invoice '||inv.invoice_no);
  end if;
  if dr <> cr then raise exception 'Voucher is not balanced: DR % vs CR %', dr, cr; end if;

  update public.invoice_requests set status='payment_request', finance_approver_id = auth.uid(), return_reason=null where id = p_id;
  insert into public.approvals(invoice_id,approver_id,role,action,comments)
    values (p_id, auth.uid(),'finance_approver','approved',p_comments);
  perform public.log_audit('vouchers',p_id,'voucher_generated', jsonb_build_object('voucher_no',v_no,'dr',dr,'cr',cr));
  return v_no;
end; $function$;
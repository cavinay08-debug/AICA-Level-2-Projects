alter table public.invoice_requests
  add column if not exists declared_attachments text[] not null default '{}',
  add column if not exists attachment_receipt_status text,
  add column if not exists attachment_receipt_notes text,
  add column if not exists attachment_receipt_at timestamptz,
  add column if not exists attachment_receipt_by uuid;

drop function if exists public.finance_check_save(uuid, text, boolean, numeric, numeric, text, text, text, jsonb);

create or replace function public.finance_check_save(
  p_id uuid, p_vendor_code text, p_wht_applicable boolean, p_wht_rate numeric,
  p_wht_amount numeric, p_wht_gl_code text, p_override_reason text, p_budget_reference text, p_lines jsonb,
  p_expense_type text default null)
returns void language plpgsql security definer set search_path = public as $$
declare inv public.invoice_requests; l jsonb; total numeric := 0; suggested numeric; cat text;
begin
  select * into inv from public.invoice_requests where id = p_id;
  if inv.id is null then raise exception 'Request not found'; end if;
  if not public.has_role(auth.uid(),'finance_checker') then raise exception 'Only a Finance Checker can perform this action'; end if;
  if inv.status not in ('hod_approved','finance_checked') then raise exception 'Request is not in the finance check stage'; end if;
  if inv.status = 'finance_checked' and inv.finance_approver_id is not null then
    raise exception 'Request is with the Finance Approver';
  end if;
  if p_vendor_code is null then raise exception 'Vendor code is mandatory'; end if;
  if not exists (select 1 from public.vendors where vendor_code = p_vendor_code and active) then
    raise exception 'Vendor code is invalid or inactive'; end if;
  if exists (select 1 from public.invoice_requests i where i.id <> p_id and i.vendor_code = p_vendor_code
      and i.invoice_no = inv.invoice_no) then
    raise exception 'Duplicate invoice number already recorded for this vendor'; end if;

  select wht_category into cat from public.vendors where vendor_code = p_vendor_code;
  suggested := public.current_wht_rate(cat);
  if p_wht_applicable and p_wht_rate is distinct from suggested and coalesce(trim(p_override_reason),'') = '' then
    raise exception 'A reason is required when overriding the suggested WHT rate';
  end if;

  delete from public.invoice_lines where invoice_id = p_id;
  for l in select * from jsonb_array_elements(coalesce(p_lines,'[]'::jsonb)) loop
    insert into public.invoice_lines(invoice_id, gl_code, cost_center_id, amount, narration)
    values (p_id, l->>'gl_code', nullif(l->>'cost_center_id','')::uuid, (l->>'amount')::numeric, l->>'narration');
    total := total + (l->>'amount')::numeric;
  end loop;
  if total <> inv.amount then raise exception 'GL allocation (%) must equal the invoice amount (%)', total, inv.amount; end if;

  update public.invoice_requests set
    vendor_code = p_vendor_code, vendor_linked_by = auth.uid(), vendor_linked_at = now(),
    expense_type = coalesce(nullif(p_expense_type,'')::public.expense_type, expense_type),
    wht_applicable = coalesce(p_wht_applicable,false),
    wht_rate = case when p_wht_applicable then coalesce(p_wht_rate,0) else 0 end,
    wht_amount = case when p_wht_applicable then coalesce(p_wht_amount,0) else 0 end,
    wht_gl_code = case when p_wht_applicable then p_wht_gl_code else null end,
    wht_override_reason = p_override_reason,
    budget_reference = p_budget_reference
  where id = p_id;

  perform public.log_audit('invoice_requests',p_id,'finance_check_saved', jsonb_build_object('vendor',p_vendor_code));
end; $$;

create or replace function public.confirm_attachment_receipt(
  p_id uuid, p_confirmed boolean, p_notes text default null)
returns void language plpgsql security definer set search_path = public as $$
declare inv public.invoice_requests;
begin
  select * into inv from public.invoice_requests where id = p_id;
  if inv.id is null then raise exception 'Request not found'; end if;
  if not (public.has_role(auth.uid(),'finance_checker') or public.has_role(auth.uid(),'finance_staff') or public.is_admin()) then
    raise exception 'Only Finance can confirm attachment receipt';
  end if;

  if p_confirmed then
    update public.invoice_requests set
      attachment_receipt_status = 'confirmed',
      attachment_receipt_notes = p_notes,
      attachment_receipt_at = now(),
      attachment_receipt_by = auth.uid(),
      physical_copy_received_at = coalesce(physical_copy_received_at, now()),
      physical_copy_received_by = coalesce(physical_copy_received_by, auth.uid())
    where id = p_id;
    insert into public.approvals(invoice_id,approver_id,role,action,comments)
    values (p_id, auth.uid(),'finance_checker','attachments_confirmed', p_notes);
    perform public.log_audit('invoice_requests',p_id,'attachments_confirmed', jsonb_build_object('notes',p_notes));
  else
    if coalesce(trim(p_notes),'') = '' then
      raise exception 'State which declared attachment is missing before rejecting';
    end if;
    update public.invoice_requests set
      attachment_receipt_status = 'rejected',
      attachment_receipt_notes = p_notes,
      attachment_receipt_at = now(),
      attachment_receipt_by = auth.uid(),
      status = 'returned',
      return_reason = 'Declared attachments not received: ' || p_notes,
      current_stage_owner = requester_id
    where id = p_id;
    insert into public.approvals(invoice_id,approver_id,role,action,comments)
    values (p_id, auth.uid(),'finance_checker','attachments_rejected', p_notes);
    perform public.log_audit('invoice_requests',p_id,'attachments_rejected', jsonb_build_object('notes',p_notes));
  end if;
end; $$;

revoke all on function public.confirm_attachment_receipt(uuid, boolean, text) from public, anon;
grant execute on function public.confirm_attachment_receipt(uuid, boolean, text) to authenticated;
revoke all on function public.finance_check_save(uuid, text, boolean, numeric, numeric, text, text, text, jsonb, text) from public, anon;
grant execute on function public.finance_check_save(uuid, text, boolean, numeric, numeric, text, text, text, jsonb, text) to authenticated;
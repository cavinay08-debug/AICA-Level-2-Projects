
-- 1. search_path on trigger functions
create or replace function public.block_correction_change() returns trigger language plpgsql set search_path to 'public' as $$
begin raise exception 'Correction log is append-only'; end; $$;
create or replace function public.block_voucher_change() returns trigger language plpgsql set search_path to 'public' as $$
begin raise exception 'Vouchers are immutable'; end; $$;

-- 2. invoice visibility helper
create or replace function public.can_view_invoice(_invoice_id uuid)
returns boolean language sql stable security definer set search_path to 'public' as $$
  select exists (
    select 1 from public.invoice_requests i
    where i.id = _invoice_id
      and ( i.requester_id = auth.uid()
         or (public.has_role(auth.uid(),'hod') and i.department_id = public.my_department())
         or i.department_id in (select d.id from public.departments d where d.escalation_user_id = auth.uid())
         or public.is_finance() )
  );
$$;
revoke all on function public.can_view_invoice(uuid) from public, anon, authenticated;

-- 3. scope approvals / invoice_lines / vouchers / attachments
drop policy if exists "view approvals" on public.approvals;
create policy "view approvals" on public.approvals for select to authenticated
  using (public.can_view_invoice(invoice_id));

drop policy if exists "view lines" on public.invoice_lines;
create policy "view lines" on public.invoice_lines for select to authenticated
  using (public.can_view_invoice(invoice_id));

drop policy if exists "view vouchers" on public.vouchers;
create policy "view vouchers" on public.vouchers for select to authenticated
  using (public.can_view_invoice(invoice_id));

drop policy if exists "view attachments" on public.attachments;
create policy "view attachments" on public.attachments for select to authenticated
  using (
    (invoice_id is not null and public.can_view_invoice(invoice_id))
    or (invoice_id is null and uploaded_by = auth.uid())
  );

-- 4. profiles
drop policy if exists "read profiles" on public.profiles;
create policy "read profiles" on public.profiles for select to authenticated
  using (id = auth.uid() or public.is_admin() or public.is_finance()
         or (department_id is not null and department_id = public.my_department()));

-- 5. vendors: hide bank details at column level
revoke select on public.vendors from authenticated;
grant select (vendor_code, vendor_name, tax_id, wht_category, wht_applicable, active, created_at, vat_registered, vrn)
  on public.vendors to authenticated;
grant insert, update, delete on public.vendors to authenticated;
grant all on public.vendors to service_role;

-- 6. storage scoping
drop policy if exists "read invoice docs" on storage.objects;
create policy "read invoice docs" on storage.objects for select to authenticated
  using (bucket_id = 'invoice-docs' and (owner = auth.uid() or public.is_finance()));

drop policy if exists "upload invoice docs" on storage.objects;
create policy "upload invoice docs" on storage.objects for insert to authenticated
  with check (bucket_id = 'invoice-docs' and owner = auth.uid());

-- 7. lock down SECURITY DEFINER functions
do $$
declare f record;
begin
  for f in
    select p.oid::regprocedure as sig
    from pg_proc p join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public' and p.prosecdef
  loop
    execute format('revoke all on function %s from public, anon, authenticated', f.sig);
  end loop;
end $$;

grant execute on function
  public.submit_invoice(uuid),
  public.hod_action(uuid, text, text),
  public.mark_hod_physical(uuid, text, text),
  public.finance_check_save(uuid, text, boolean, numeric, numeric, text, text, text, jsonb, text),
  public.finance_forward(uuid),
  public.approver_action(uuid, text, text, text),
  public.confirm_payment(uuid, text, text, text, numeric, date, jsonb),
  public.confirm_attachment_receipt(uuid, boolean, text),
  public.receive_physical_scan(text),
  public.mark_physical_received(uuid),
  public.mark_vouchers_exported(text[]),
  public.close_request(uuid),
  public.current_wht_rate(text)
to authenticated;

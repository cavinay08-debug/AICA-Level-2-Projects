CREATE TABLE public.gl_postings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  source text NOT NULL DEFAULT 'odbc',
  batch_id uuid,
  voucher_no text,
  entry_date date,
  gl_code text,
  vendor_code text,
  dr_cr text,
  amount numeric NOT NULL DEFAULT 0,
  narration text,
  accounting_ref text,
  imported_by uuid,
  imported_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX gl_postings_voucher_idx ON public.gl_postings (voucher_no);
CREATE INDEX gl_postings_batch_idx ON public.gl_postings (batch_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.gl_postings TO authenticated;
GRANT ALL ON public.gl_postings TO service_role;
ALTER TABLE public.gl_postings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "finance view postings" ON public.gl_postings FOR SELECT TO authenticated USING (public.is_finance());
CREATE POLICY "finance import postings" ON public.gl_postings FOR INSERT TO authenticated WITH CHECK (public.is_finance());
CREATE POLICY "finance clear postings" ON public.gl_postings FOR DELETE TO authenticated USING (public.is_finance());
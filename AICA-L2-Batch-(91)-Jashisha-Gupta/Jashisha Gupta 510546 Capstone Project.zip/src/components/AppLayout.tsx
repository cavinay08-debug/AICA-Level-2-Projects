import { Link, useLocation, useNavigate } from "@tanstack/react-router";
import {
  LayoutDashboard,
  FileText,
  PlusCircle,
  Banknote,
  BarChart3,
  Settings,
  LogOut,
  Receipt,
  ScrollText,
  Menu,
} from "lucide-react";
import { useState, type ReactNode } from "react";
import { useAuth, type AppRole } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const ROLE_LABEL: Record<AppRole, string> = {
  requester: "Requester",
  hod: "Head of Department",
  finance_checker: "Finance Checker",
  finance_approver: "Finance Approver",
  finance_staff: "Payment Processing",
  admin: "Administrator",
};

type NavItem = { to: string; label: string; icon: typeof FileText; roles?: AppRole[] };

const NAV: NavItem[] = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/requests", label: "Invoice Requests", icon: FileText },
  { to: "/requests/new", label: "New Request", icon: PlusCircle },
  {
    to: "/payments",
    label: "Payments & Reconciliation",
    icon: Banknote,
    roles: ["finance_staff", "admin"],
  },
  {
    to: "/gl-verification",
    label: "GL Verification",
    icon: ScrollText,
    roles: ["finance_checker", "finance_approver", "finance_staff", "admin"],
  },
  {
    to: "/reports",
    label: "Reports",
    icon: BarChart3,
    roles: ["admin", "finance_approver", "finance_checker", "finance_staff"],
  },
  { to: "/admin", label: "Administration", icon: Settings, roles: ["admin"] },
];

export function AppLayout({ children }: { children: ReactNode }) {
  const { profile, roles, has, signOut } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  const items = NAV.filter((n) => !n.roles || has(...n.roles));

  return (
    <div className="flex min-h-screen bg-background">
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-40 flex w-64 flex-col bg-sidebar text-sidebar-foreground transition-transform lg:static lg:translate-x-0",
          open ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="flex items-center gap-2 border-b border-sidebar-border px-5 py-4">
          <Receipt className="h-6 w-6 text-sidebar-primary" />
          <div>
            <div className="font-display text-sm font-semibold tracking-tight">Invoice Portal</div>
            <div className="text-[11px] text-sidebar-foreground/60">Workflow &amp; Approvals</div>
          </div>
        </div>
        <nav className="flex-1 space-y-1 p-3">
          {items.map((item) => {
            const active =
              location.pathname === item.to ||
              (item.to !== "/requests/new" && location.pathname.startsWith(item.to + "/"));
            return (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setOpen(false)}
                className={cn(
                  "flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors",
                  active
                    ? "bg-sidebar-accent font-medium text-sidebar-accent-foreground"
                    : "text-sidebar-foreground/75 hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground",
                )}
              >
                <item.icon className="h-4 w-4" />
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="border-t border-sidebar-border p-4 text-xs">
          <div className="font-medium">{profile?.full_name || profile?.email}</div>
          <div className="mt-1 flex flex-wrap gap-1">
            {roles.map((r) => (
              <span
                key={r}
                className="rounded bg-sidebar-accent px-1.5 py-0.5 text-[10px] text-sidebar-accent-foreground"
              >
                {ROLE_LABEL[r]}
              </span>
            ))}
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="mt-3 w-full justify-start px-2 text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
            onClick={async () => {
              await signOut();
              navigate({ to: "/auth" });
            }}
          >
            <LogOut className="mr-2 h-4 w-4" /> Sign out
          </Button>
        </div>
      </aside>

      {open && (
        <div className="fixed inset-0 z-30 bg-foreground/40 lg:hidden" onClick={() => setOpen(false)} />
      )}

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-20 flex items-center gap-3 border-b bg-card/90 px-4 py-3 backdrop-blur lg:hidden">
          <Button variant="ghost" size="icon" onClick={() => setOpen(true)}>
            <Menu className="h-5 w-5" />
          </Button>
          <span className="font-display font-semibold">Invoice Portal</span>
        </header>
        <main className="min-w-0 flex-1 p-4 md:p-8">{children}</main>
      </div>
    </div>
  );
}

export function PageHeader({
  title,
  subtitle,
  action,
}: {
  title: string;
  subtitle?: string;
  action?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-2xl font-semibold">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

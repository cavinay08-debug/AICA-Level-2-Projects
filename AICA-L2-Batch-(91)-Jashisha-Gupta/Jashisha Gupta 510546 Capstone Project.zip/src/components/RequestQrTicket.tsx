import { useEffect, useState } from "react";
import QRCode from "qrcode";

/**
 * Digital hand-over ticket. The user department shows this QR on screen (or from
 * their phone) when delivering the physical invoice; Finance scans it to log receipt.
 */
export function RequestQrTicket({ code, className }: { code: string; className?: string }) {
  const [img, setImg] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    QRCode.toDataURL(code, { margin: 1, width: 320, errorCorrectionLevel: "M" })
      .then((url) => alive && setImg(url))
      .catch(() => alive && setImg(null));
    return () => {
      alive = false;
    };
  }, [code]);

  return (
    <div className={`flex flex-col items-center gap-2 rounded-lg border bg-card p-4 ${className ?? ""}`}>
      {img ? (
        <img src={img} alt={`QR code for ${code}`} className="size-40" />
      ) : (
        <div className="size-40 animate-pulse rounded bg-muted" />
      )}
      <div className="text-center">
        <div className="text-[10px] uppercase tracking-widest text-muted-foreground">Scan at finance</div>
        <div className="num text-base font-semibold tracking-wider">{code}</div>
      </div>
    </div>
  );
}

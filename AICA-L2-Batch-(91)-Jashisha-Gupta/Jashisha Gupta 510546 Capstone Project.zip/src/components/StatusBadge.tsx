import { STATUS_LABEL, statusClasses, type InvoiceStatus } from "@/lib/workflow";
import { cn } from "@/lib/utils";

export function StatusBadge({ status, className }: { status: InvoiceStatus; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium whitespace-nowrap",
        statusClasses(status),
        className,
      )}
    >
      {STATUS_LABEL[status] ?? status}
    </span>
  );
}

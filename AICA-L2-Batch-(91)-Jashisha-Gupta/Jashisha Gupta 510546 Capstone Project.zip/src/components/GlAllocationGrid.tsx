import { useState } from "react";
import { Check, ChevronsUpDown, Copy, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { cn } from "@/lib/utils";
import { money } from "@/lib/workflow";

export type Line = {
  id?: string;
  gl_code: string;
  cost_center_id: string;
  amount: string;
  narration: string;
};

type Option = { value: string; label: string; sub?: string };

function Picker({
  value,
  options,
  placeholder,
  onChange,
}: {
  value: string;
  options: Option[];
  placeholder: string;
  onChange: (v: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const current = options.find((o) => o.value === value);
  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          type="button"
          className={cn(
            "flex h-11 w-full items-center justify-between gap-2 rounded-none border-0 bg-transparent px-3 text-left text-sm outline-none focus:bg-accent/40",
            !current && "text-muted-foreground",
          )}
        >
          <span className="truncate">{current ? current.label : placeholder}</span>
          <ChevronsUpDown className="size-4 shrink-0 opacity-40" />
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-[380px] p-0" align="start">
        <Command>
          <CommandInput placeholder={`Search ${placeholder.toLowerCase()}…`} />
          <CommandList>
            <CommandEmpty>Nothing found.</CommandEmpty>
            <CommandGroup>
              {options.map((o) => (
                <CommandItem
                  key={o.value}
                  value={`${o.label} ${o.sub ?? ""}`}
                  onSelect={() => {
                    onChange(o.value);
                    setOpen(false);
                  }}
                >
                  <Check className={cn("mr-2 size-4", value === o.value ? "opacity-100" : "opacity-0")} />
                  <span className="truncate">{o.label}</span>
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}

/** Excel-style allocation grid: search-as-you-type pickers, keyboard friendly cells. */
export function GlAllocationGrid({
  lines,
  setLines,
  glOptions,
  ccOptions,
  total,
  currency,
  showAllGl,
  setShowAllGl,
}: {
  lines: Line[];
  setLines: React.Dispatch<React.SetStateAction<Line[]>>;
  glOptions: Option[];
  ccOptions: Option[];
  total: number;
  currency: string;
  showAllGl: boolean;
  setShowAllGl: (v: boolean) => void;
}) {
  const allocated = lines.reduce((s, l) => s + Number(l.amount || 0), 0);
  const remaining = Math.round((total - allocated) * 100) / 100;
  const patch = (i: number, p: Partial<Line>) =>
    setLines((prev) => prev.map((x, j) => (i === j ? { ...x, ...p } : x)));
  const addLine = () =>
    setLines((p) => [...p, { gl_code: "", cost_center_id: "", amount: "", narration: "" }]);

  return (
    <div className="space-y-4 rounded-lg border p-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="text-base font-semibold">GL allocation</div>
          <p className="text-sm text-muted-foreground">
            Search GL / cost center, type amount and narration. Tab moves across the row, Enter adds a new row.
          </p>
        </div>
        <span
          className={`rounded-full px-3 py-1.5 text-sm font-medium ${
            remaining === 0 ? "bg-success/15 text-success" : "bg-destructive/10 text-destructive"
          }`}
        >
          {remaining === 0 ? "Balanced" : `${money(remaining, currency)} left`}
        </span>
      </div>

      <div className="overflow-x-auto rounded-lg border">
        <table className="w-full min-w-[1100px] border-collapse text-sm">
          <thead>
            <tr className="bg-muted/60 text-left text-xs uppercase tracking-wide text-muted-foreground">
              <th className="w-10 border-b px-3 py-2.5 text-center">#</th>
              <th className="min-w-[260px] w-[30%] border-b px-3 py-2.5">GL account</th>
              <th className="min-w-[220px] w-[25%] border-b px-3 py-2.5">Cost center</th>
              <th className="min-w-[160px] w-[15%] border-b px-3 py-2.5 text-right">Amount</th>
              <th className="min-w-[300px] w-full border-b px-3 py-2.5">Narration</th>
              <th className="w-24 border-b px-3 py-2.5" />
            </tr>
          </thead>
          <tbody>
            {lines.map((l, i) => (
              <tr key={i} className="border-b last:border-0 hover:bg-muted/30">
                <td className="num border-r px-3 py-2 text-center text-sm text-muted-foreground">{i + 1}</td>
                <td className="border-r p-0">
                  <Picker
                    value={l.gl_code}
                    options={glOptions}
                    placeholder="Select GL account"
                    onChange={(v) => patch(i, { gl_code: v })}
                  />
                </td>
                <td className="border-r p-0">
                  <Picker
                    value={l.cost_center_id}
                    options={ccOptions}
                    placeholder="Select cost center"
                    onChange={(v) => patch(i, { cost_center_id: v })}
                  />
                </td>
                <td className="border-r p-0">
                  <Input
                    type="number"
                    step="0.01"
                    inputMode="decimal"
                    placeholder="0.00"
                    className="num h-11 rounded-none border-0 bg-transparent px-3 text-right text-base shadow-none focus-visible:ring-0 focus-visible:bg-accent/40"
                    value={l.amount}
                    onChange={(e) => patch(i, { amount: e.target.value })}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        if (i === lines.length - 1) addLine();
                      }
                    }}
                  />
                </td>
                <td className="border-r p-0">
                  <Input
                    placeholder="Voucher line narration"
                    className="h-11 rounded-none border-0 bg-transparent px-3 text-sm shadow-none focus-visible:ring-0 focus-visible:bg-accent/40"
                    value={l.narration}
                    onChange={(e) => patch(i, { narration: e.target.value })}
                  />
                </td>
                <td className="px-2 py-2">
                  <div className="flex items-center justify-end gap-1">
                    <button
                      type="button"
                      title="Fill remaining balance"
                      className="rounded-md p-2 text-sm font-semibold text-primary hover:bg-accent"
                      onClick={() =>
                        patch(i, { amount: (Number(l.amount || 0) + remaining).toFixed(2) })
                      }
                    >
                      =
                    </button>
                    <button
                      type="button"
                      title="Duplicate row"
                      className="rounded-md p-2 text-muted-foreground hover:bg-accent"
                      onClick={() =>
                        setLines((p) => [
                          ...p.slice(0, i + 1),
                          {
                            gl_code: l.gl_code,
                            cost_center_id: l.cost_center_id,
                            amount: l.amount,
                            narration: l.narration,
                          },
                          ...p.slice(i + 1),
                        ])
                      }
                    >
                      <Copy className="size-4" />
                    </button>
                    <button
                      type="button"
                      title="Delete row"
                      disabled={lines.length === 1}
                      className="rounded-md p-2 text-destructive hover:bg-accent disabled:opacity-30"
                      onClick={() => setLines((p) => p.filter((_, j) => j !== i))}
                    >
                      <Trash2 className="size-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr className="bg-muted/40 text-sm font-medium">
              <td className="px-3 py-2.5" colSpan={3}>
                Allocated
              </td>
              <td className={`num px-3 py-2.5 text-right text-base ${remaining === 0 ? "text-success" : "text-destructive"}`}>
                {money(allocated, currency)}
              </td>
              <td className="num px-3 py-2.5 text-sm text-muted-foreground" colSpan={2}>
                of {money(total, currency)}
              </td>
            </tr>
          </tfoot>
        </table>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <Button type="button" variant="outline" size="default" onClick={addLine}>
          <Plus className="mr-1 size-4" /> Add row
        </Button>
        <Button
          type="button"
          variant="ghost"
          size="default"
          onClick={() => {
            const each = total / lines.length;
            setLines((p) => p.map((x) => ({ ...x, amount: each.toFixed(2) })));
          }}
        >
          Split evenly
        </Button>
        <label className="ml-auto flex items-center gap-2 text-sm text-muted-foreground">
          <input type="checkbox" checked={showAllGl} onChange={(e) => setShowAllGl(e.target.checked)} />
          Show all GL accounts
        </label>
      </div>
    </div>
  );
}

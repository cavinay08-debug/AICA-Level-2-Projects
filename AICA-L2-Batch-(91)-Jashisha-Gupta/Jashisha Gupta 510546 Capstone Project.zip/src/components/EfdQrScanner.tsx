import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export type EfdScanResult = {
  raw: string;
  url: string | null;
  receiptNo: string | null;
  verificationCode: string | null;
};

export function parseEfdQr(raw: string): EfdScanResult {
  const text = raw.trim();
  let url: string | null = null;
  let receiptNo: string | null = null;
  let verificationCode: string | null = null;

  if (/^https?:\/\//i.test(text)) {
    url = text;
    try {
      const u = new URL(text);
      const params = u.searchParams;
      verificationCode =
        params.get("verificationCode") ?? params.get("code") ?? params.get("vc") ?? null;
      receiptNo =
        params.get("receiptNo") ??
        params.get("rctNo") ??
        params.get("rctvcode") ??
        null;
      if (!receiptNo) {
        const seg = u.pathname.split("/").filter(Boolean).pop();
        if (seg && /^[A-Za-z0-9-]{4,}$/.test(seg)) receiptNo = seg;
      }
    } catch {
      /* keep raw */
    }
  } else {
    receiptNo = text;
  }

  return { raw: text, url, receiptNo, verificationCode };
}

/**
 * Capture window for an external (USB / Bluetooth) QR scanner.
 * Hardware scanners type the decoded value and press Enter, so we simply keep
 * a focused input ready and submit on Enter. Manual typing works too.
 */
export function EfdQrScanner({
  open,
  onOpenChange,
  onResult,
  title = "Scan with QR scanner",
  description = "Use the external QR scanner (or type the code) — the value is captured automatically.",
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onResult: (r: EfdScanResult) => void;
  title?: string;
  description?: string;
}) {
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [value, setValue] = useState("");

  useEffect(() => {
    if (!open) return;
    setValue("");
    const t = setTimeout(() => inputRef.current?.focus(), 60);
    return () => clearTimeout(t);
  }, [open]);

  const submit = (raw: string) => {
    const text = raw.trim();
    if (!text) return;
    onResult(parseEfdQr(text));
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            submit(value);
          }}
          className="space-y-3"
        >
          <Input
            ref={inputRef}
            autoFocus
            value={value}
            onChange={(e) => setValue(e.target.value)}
            placeholder="Waiting for scanner…"
            className="font-mono"
          />
          <p className="text-xs text-muted-foreground">
            Keep this box focused and trigger the scanner. Press Enter to confirm a typed code.
          </p>
          <DialogFooter className="gap-2 sm:justify-between">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={!value.trim()}>
              Use code
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

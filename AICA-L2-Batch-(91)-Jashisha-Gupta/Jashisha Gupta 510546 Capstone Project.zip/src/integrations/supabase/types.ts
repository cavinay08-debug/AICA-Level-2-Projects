export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.15"
  }
  public: {
    Tables: {
      app_settings: {
        Row: {
          key: string
          updated_at: string
          value: Json
        }
        Insert: {
          key: string
          updated_at?: string
          value?: Json
        }
        Update: {
          key?: string
          updated_at?: string
          value?: Json
        }
        Relationships: []
      }
      approvals: {
        Row: {
          action: string
          approver_id: string
          comments: string | null
          created_at: string
          id: string
          invoice_id: string
          role: Database["public"]["Enums"]["app_role"]
        }
        Insert: {
          action: string
          approver_id: string
          comments?: string | null
          created_at?: string
          id?: string
          invoice_id: string
          role: Database["public"]["Enums"]["app_role"]
        }
        Update: {
          action?: string
          approver_id?: string
          comments?: string | null
          created_at?: string
          id?: string
          invoice_id?: string
          role?: Database["public"]["Enums"]["app_role"]
        }
        Relationships: [
          {
            foreignKeyName: "approvals_invoice_id_fkey"
            columns: ["invoice_id"]
            isOneToOne: false
            referencedRelation: "invoice_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      attachments: {
        Row: {
          file_name: string | null
          file_url: string
          id: string
          invoice_id: string | null
          type: Database["public"]["Enums"]["attachment_type"]
          uploaded_at: string
          uploaded_by: string
        }
        Insert: {
          file_name?: string | null
          file_url: string
          id?: string
          invoice_id?: string | null
          type?: Database["public"]["Enums"]["attachment_type"]
          uploaded_at?: string
          uploaded_by: string
        }
        Update: {
          file_name?: string | null
          file_url?: string
          id?: string
          invoice_id?: string | null
          type?: Database["public"]["Enums"]["attachment_type"]
          uploaded_at?: string
          uploaded_by?: string
        }
        Relationships: [
          {
            foreignKeyName: "attachments_invoice_id_fkey"
            columns: ["invoice_id"]
            isOneToOne: false
            referencedRelation: "invoice_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      audit_log: {
        Row: {
          action: string
          created_at: string
          details: Json | null
          entity: string
          entity_id: string | null
          id: string
          user_id: string | null
        }
        Insert: {
          action: string
          created_at?: string
          details?: Json | null
          entity: string
          entity_id?: string | null
          id?: string
          user_id?: string | null
        }
        Update: {
          action?: string
          created_at?: string
          details?: Json | null
          entity?: string
          entity_id?: string | null
          id?: string
          user_id?: string | null
        }
        Relationships: []
      }
      business_units: {
        Row: {
          active: boolean
          code: string
          created_at: string
          external_code: string | null
          id: string
          name: string
        }
        Insert: {
          active?: boolean
          code: string
          created_at?: string
          external_code?: string | null
          id?: string
          name: string
        }
        Update: {
          active?: boolean
          code?: string
          created_at?: string
          external_code?: string | null
          id?: string
          name?: string
        }
        Relationships: []
      }
      checker_corrections: {
        Row: {
          approver_comment: string
          corrected_value: string | null
          field_corrected: string
          finance_approver_id: string | null
          finance_checker_id: string | null
          id: string
          invoice_id: string
          original_value: string | null
          resolved_at: string | null
          returned_at: string
          revision_round_number: number
        }
        Insert: {
          approver_comment: string
          corrected_value?: string | null
          field_corrected: string
          finance_approver_id?: string | null
          finance_checker_id?: string | null
          id?: string
          invoice_id: string
          original_value?: string | null
          resolved_at?: string | null
          returned_at?: string
          revision_round_number?: number
        }
        Update: {
          approver_comment?: string
          corrected_value?: string | null
          field_corrected?: string
          finance_approver_id?: string | null
          finance_checker_id?: string | null
          id?: string
          invoice_id?: string
          original_value?: string | null
          resolved_at?: string | null
          returned_at?: string
          revision_round_number?: number
        }
        Relationships: [
          {
            foreignKeyName: "checker_corrections_invoice_id_fkey"
            columns: ["invoice_id"]
            isOneToOne: false
            referencedRelation: "invoice_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      cost_centers: {
        Row: {
          active: boolean
          business_unit_id: string | null
          code: string
          department_id: string | null
          external_code: string | null
          id: string
          name: string
        }
        Insert: {
          active?: boolean
          business_unit_id?: string | null
          code: string
          department_id?: string | null
          external_code?: string | null
          id?: string
          name: string
        }
        Update: {
          active?: boolean
          business_unit_id?: string | null
          code?: string
          department_id?: string | null
          external_code?: string | null
          id?: string
          name?: string
        }
        Relationships: [
          {
            foreignKeyName: "cost_centers_business_unit_id_fkey"
            columns: ["business_unit_id"]
            isOneToOne: false
            referencedRelation: "business_units"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "cost_centers_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      departments: {
        Row: {
          active: boolean
          approval_threshold: number
          code: string | null
          created_at: string
          escalation_user_id: string | null
          hod_user_id: string | null
          id: string
          name: string
        }
        Insert: {
          active?: boolean
          approval_threshold?: number
          code?: string | null
          created_at?: string
          escalation_user_id?: string | null
          hod_user_id?: string | null
          id?: string
          name: string
        }
        Update: {
          active?: boolean
          approval_threshold?: number
          code?: string | null
          created_at?: string
          escalation_user_id?: string | null
          hod_user_id?: string | null
          id?: string
          name?: string
        }
        Relationships: []
      }
      gl_accounts: {
        Row: {
          active: boolean
          department_id: string | null
          external_code: string | null
          gl_code: string
          gl_name: string
          type: Database["public"]["Enums"]["gl_type"]
        }
        Insert: {
          active?: boolean
          department_id?: string | null
          external_code?: string | null
          gl_code: string
          gl_name: string
          type: Database["public"]["Enums"]["gl_type"]
        }
        Update: {
          active?: boolean
          department_id?: string | null
          external_code?: string | null
          gl_code?: string
          gl_name?: string
          type?: Database["public"]["Enums"]["gl_type"]
        }
        Relationships: [
          {
            foreignKeyName: "gl_accounts_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      gl_postings: {
        Row: {
          accounting_ref: string | null
          amount: number
          batch_id: string | null
          dr_cr: string | null
          entry_date: string | null
          gl_code: string | null
          id: string
          imported_at: string
          imported_by: string | null
          narration: string | null
          source: string
          vendor_code: string | null
          voucher_no: string | null
        }
        Insert: {
          accounting_ref?: string | null
          amount?: number
          batch_id?: string | null
          dr_cr?: string | null
          entry_date?: string | null
          gl_code?: string | null
          id?: string
          imported_at?: string
          imported_by?: string | null
          narration?: string | null
          source?: string
          vendor_code?: string | null
          voucher_no?: string | null
        }
        Update: {
          accounting_ref?: string | null
          amount?: number
          batch_id?: string | null
          dr_cr?: string | null
          entry_date?: string | null
          gl_code?: string | null
          id?: string
          imported_at?: string
          imported_by?: string | null
          narration?: string | null
          source?: string
          vendor_code?: string | null
          voucher_no?: string | null
        }
        Relationships: []
      }
      invoice_lines: {
        Row: {
          amount: number
          cost_center_id: string | null
          gl_code: string | null
          id: string
          invoice_id: string
          narration: string | null
        }
        Insert: {
          amount?: number
          cost_center_id?: string | null
          gl_code?: string | null
          id?: string
          invoice_id: string
          narration?: string | null
        }
        Update: {
          amount?: number
          cost_center_id?: string | null
          gl_code?: string | null
          id?: string
          invoice_id?: string
          narration?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "invoice_lines_cost_center_id_fkey"
            columns: ["cost_center_id"]
            isOneToOne: false
            referencedRelation: "cost_centers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoice_lines_gl_code_fkey"
            columns: ["gl_code"]
            isOneToOne: false
            referencedRelation: "gl_accounts"
            referencedColumns: ["gl_code"]
          },
          {
            foreignKeyName: "invoice_lines_invoice_id_fkey"
            columns: ["invoice_id"]
            isOneToOne: false
            referencedRelation: "invoice_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      invoice_requests: {
        Row: {
          amount: number
          amount_is_gross: boolean
          attachment_receipt_at: string | null
          attachment_receipt_by: string | null
          attachment_receipt_notes: string | null
          attachment_receipt_status: string | null
          budget_reference: string | null
          business_unit_id: string | null
          cost_center_id: string | null
          created_at: string
          currency: string
          current_stage_owner: string | null
          declared_attachments: string[]
          department_id: string
          description: string | null
          efd_qr_url: string | null
          efd_receipt_no: string | null
          efd_scanned_at: string | null
          efd_verification_code: string | null
          escalation_approved_at: string | null
          escalation_required: boolean
          expense_type: Database["public"]["Enums"]["expense_type"]
          finance_approver_id: string | null
          finance_checker_id: string | null
          fx_rate: number | null
          fx_remarks: string | null
          hod_physical_signed_uploaded_at: string | null
          hod_system_approved_at: string | null
          hod_system_approved_by: string | null
          id: string
          invoice_date: string
          invoice_no: string
          net_amount: number
          physical_copy_received_at: string | null
          physical_copy_received_by: string | null
          reference_date: string | null
          reference_number: string | null
          reference_type: Database["public"]["Enums"]["reference_type"]
          reference_validity: string | null
          reference_vendor_name: string | null
          request_no: string | null
          requester_id: string
          return_reason: string | null
          revision_round: number
          status: Database["public"]["Enums"]["invoice_status"]
          submission_sheet_no: string | null
          tax_amount: number
          updated_at: string
          vat_rate: number
          vat_registered_vendor: boolean
          vendor_code: string | null
          vendor_linked_at: string | null
          vendor_linked_by: string | null
          vendor_name_free_text: string
          wht_amount: number
          wht_applicable: boolean
          wht_gl_code: string | null
          wht_override_reason: string | null
          wht_rate: number
        }
        Insert: {
          amount: number
          amount_is_gross?: boolean
          attachment_receipt_at?: string | null
          attachment_receipt_by?: string | null
          attachment_receipt_notes?: string | null
          attachment_receipt_status?: string | null
          budget_reference?: string | null
          business_unit_id?: string | null
          cost_center_id?: string | null
          created_at?: string
          currency?: string
          current_stage_owner?: string | null
          declared_attachments?: string[]
          department_id: string
          description?: string | null
          efd_qr_url?: string | null
          efd_receipt_no?: string | null
          efd_scanned_at?: string | null
          efd_verification_code?: string | null
          escalation_approved_at?: string | null
          escalation_required?: boolean
          expense_type?: Database["public"]["Enums"]["expense_type"]
          finance_approver_id?: string | null
          finance_checker_id?: string | null
          fx_rate?: number | null
          fx_remarks?: string | null
          hod_physical_signed_uploaded_at?: string | null
          hod_system_approved_at?: string | null
          hod_system_approved_by?: string | null
          id?: string
          invoice_date: string
          invoice_no: string
          net_amount?: number
          physical_copy_received_at?: string | null
          physical_copy_received_by?: string | null
          reference_date?: string | null
          reference_number?: string | null
          reference_type?: Database["public"]["Enums"]["reference_type"]
          reference_validity?: string | null
          reference_vendor_name?: string | null
          request_no?: string | null
          requester_id: string
          return_reason?: string | null
          revision_round?: number
          status?: Database["public"]["Enums"]["invoice_status"]
          submission_sheet_no?: string | null
          tax_amount?: number
          updated_at?: string
          vat_rate?: number
          vat_registered_vendor?: boolean
          vendor_code?: string | null
          vendor_linked_at?: string | null
          vendor_linked_by?: string | null
          vendor_name_free_text: string
          wht_amount?: number
          wht_applicable?: boolean
          wht_gl_code?: string | null
          wht_override_reason?: string | null
          wht_rate?: number
        }
        Update: {
          amount?: number
          amount_is_gross?: boolean
          attachment_receipt_at?: string | null
          attachment_receipt_by?: string | null
          attachment_receipt_notes?: string | null
          attachment_receipt_status?: string | null
          budget_reference?: string | null
          business_unit_id?: string | null
          cost_center_id?: string | null
          created_at?: string
          currency?: string
          current_stage_owner?: string | null
          declared_attachments?: string[]
          department_id?: string
          description?: string | null
          efd_qr_url?: string | null
          efd_receipt_no?: string | null
          efd_scanned_at?: string | null
          efd_verification_code?: string | null
          escalation_approved_at?: string | null
          escalation_required?: boolean
          expense_type?: Database["public"]["Enums"]["expense_type"]
          finance_approver_id?: string | null
          finance_checker_id?: string | null
          fx_rate?: number | null
          fx_remarks?: string | null
          hod_physical_signed_uploaded_at?: string | null
          hod_system_approved_at?: string | null
          hod_system_approved_by?: string | null
          id?: string
          invoice_date?: string
          invoice_no?: string
          net_amount?: number
          physical_copy_received_at?: string | null
          physical_copy_received_by?: string | null
          reference_date?: string | null
          reference_number?: string | null
          reference_type?: Database["public"]["Enums"]["reference_type"]
          reference_validity?: string | null
          reference_vendor_name?: string | null
          request_no?: string | null
          requester_id?: string
          return_reason?: string | null
          revision_round?: number
          status?: Database["public"]["Enums"]["invoice_status"]
          submission_sheet_no?: string | null
          tax_amount?: number
          updated_at?: string
          vat_rate?: number
          vat_registered_vendor?: boolean
          vendor_code?: string | null
          vendor_linked_at?: string | null
          vendor_linked_by?: string | null
          vendor_name_free_text?: string
          wht_amount?: number
          wht_applicable?: boolean
          wht_gl_code?: string | null
          wht_override_reason?: string | null
          wht_rate?: number
        }
        Relationships: [
          {
            foreignKeyName: "invoice_requests_business_unit_id_fkey"
            columns: ["business_unit_id"]
            isOneToOne: false
            referencedRelation: "business_units"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoice_requests_cost_center_id_fkey"
            columns: ["cost_center_id"]
            isOneToOne: false
            referencedRelation: "cost_centers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoice_requests_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoice_requests_requester_id_fkey"
            columns: ["requester_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoice_requests_vendor_code_fkey"
            columns: ["vendor_code"]
            isOneToOne: false
            referencedRelation: "vendors"
            referencedColumns: ["vendor_code"]
          },
          {
            foreignKeyName: "invoice_requests_wht_gl_code_fkey"
            columns: ["wht_gl_code"]
            isOneToOne: false
            referencedRelation: "gl_accounts"
            referencedColumns: ["gl_code"]
          },
        ]
      }
      payment_reconciliation: {
        Row: {
          accounting_system_reference: string | null
          candidates: Json | null
          date_tolerance_used: number | null
          id: string
          invoice_id: string
          match_status: Database["public"]["Enums"]["match_status"]
          matched_amount: number | null
          matched_at: string
          matched_by: string | null
          matched_date: string | null
          matched_vendor_code: string | null
          notes: string | null
          voucher_no: string | null
        }
        Insert: {
          accounting_system_reference?: string | null
          candidates?: Json | null
          date_tolerance_used?: number | null
          id?: string
          invoice_id: string
          match_status: Database["public"]["Enums"]["match_status"]
          matched_amount?: number | null
          matched_at?: string
          matched_by?: string | null
          matched_date?: string | null
          matched_vendor_code?: string | null
          notes?: string | null
          voucher_no?: string | null
        }
        Update: {
          accounting_system_reference?: string | null
          candidates?: Json | null
          date_tolerance_used?: number | null
          id?: string
          invoice_id?: string
          match_status?: Database["public"]["Enums"]["match_status"]
          matched_amount?: number | null
          matched_at?: string
          matched_by?: string | null
          matched_date?: string | null
          matched_vendor_code?: string | null
          notes?: string | null
          voucher_no?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "payment_reconciliation_invoice_id_fkey"
            columns: ["invoice_id"]
            isOneToOne: false
            referencedRelation: "invoice_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          active: boolean
          created_at: string
          department_id: string | null
          email: string
          full_name: string
          id: string
        }
        Insert: {
          active?: boolean
          created_at?: string
          department_id?: string | null
          email?: string
          full_name?: string
          id: string
        }
        Update: {
          active?: boolean
          created_at?: string
          department_id?: string | null
          email?: string
          full_name?: string
          id?: string
        }
        Relationships: [
          {
            foreignKeyName: "profiles_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      vendors: {
        Row: {
          active: boolean
          bank_details: string | null
          created_at: string
          tax_id: string | null
          vat_registered: boolean
          vendor_code: string
          vendor_name: string
          vrn: string | null
          wht_applicable: boolean
          wht_category: string | null
        }
        Insert: {
          active?: boolean
          bank_details?: string | null
          created_at?: string
          tax_id?: string | null
          vat_registered?: boolean
          vendor_code: string
          vendor_name: string
          vrn?: string | null
          wht_applicable?: boolean
          wht_category?: string | null
        }
        Update: {
          active?: boolean
          bank_details?: string | null
          created_at?: string
          tax_id?: string | null
          vat_registered?: boolean
          vendor_code?: string
          vendor_name?: string
          vrn?: string | null
          wht_applicable?: boolean
          wht_category?: string | null
        }
        Relationships: []
      }
      vouchers: {
        Row: {
          amount: number
          cost_center_id: string | null
          created_at: string
          dr_cr: string
          exported_flag: boolean
          gl_code: string | null
          id: string
          invoice_id: string
          line_no: number
          narration: string | null
          reference_number: string | null
          reference_type: Database["public"]["Enums"]["reference_type"] | null
          vendor_code: string | null
          voucher_no: string
          wht_amount: number | null
          wht_gl_code: string | null
          wht_rate: number | null
        }
        Insert: {
          amount: number
          cost_center_id?: string | null
          created_at?: string
          dr_cr: string
          exported_flag?: boolean
          gl_code?: string | null
          id?: string
          invoice_id: string
          line_no: number
          narration?: string | null
          reference_number?: string | null
          reference_type?: Database["public"]["Enums"]["reference_type"] | null
          vendor_code?: string | null
          voucher_no: string
          wht_amount?: number | null
          wht_gl_code?: string | null
          wht_rate?: number | null
        }
        Update: {
          amount?: number
          cost_center_id?: string | null
          created_at?: string
          dr_cr?: string
          exported_flag?: boolean
          gl_code?: string | null
          id?: string
          invoice_id?: string
          line_no?: number
          narration?: string | null
          reference_number?: string | null
          reference_type?: Database["public"]["Enums"]["reference_type"] | null
          vendor_code?: string | null
          voucher_no?: string
          wht_amount?: number | null
          wht_gl_code?: string | null
          wht_rate?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "vouchers_invoice_id_fkey"
            columns: ["invoice_id"]
            isOneToOne: false
            referencedRelation: "invoice_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      wht_rates: {
        Row: {
          created_at: string
          effective_from: string
          effective_to: string | null
          id: string
          rate_percent: number
          wht_category: string
        }
        Insert: {
          created_at?: string
          effective_from?: string
          effective_to?: string | null
          id?: string
          rate_percent: number
          wht_category: string
        }
        Update: {
          created_at?: string
          effective_from?: string
          effective_to?: string | null
          id?: string
          rate_percent?: number
          wht_category?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      approver_action: {
        Args: {
          p_action: string
          p_comments: string
          p_field_corrected: string
          p_id: string
        }
        Returns: string
      }
      can_view_invoice: { Args: { _invoice_id: string }; Returns: boolean }
      close_request: { Args: { p_id: string }; Returns: undefined }
      confirm_attachment_receipt: {
        Args: { p_confirmed: boolean; p_id: string; p_notes?: string }
        Returns: undefined
      }
      confirm_payment: {
        Args: {
          p_candidates: Json
          p_id: string
          p_matched_amount: number
          p_matched_date: string
          p_notes: string
          p_reference: string
          p_status: string
        }
        Returns: undefined
      }
      current_wht_rate: { Args: { _category: string }; Returns: number }
      finance_check_save: {
        Args: {
          p_budget_reference: string
          p_expense_type?: string
          p_id: string
          p_lines: Json
          p_override_reason: string
          p_vendor_code: string
          p_wht_amount: number
          p_wht_applicable: boolean
          p_wht_gl_code: string
          p_wht_rate: number
        }
        Returns: undefined
      }
      finance_forward: { Args: { p_id: string }; Returns: string }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      hod_action: {
        Args: { p_action: string; p_comments: string; p_id: string }
        Returns: undefined
      }
      is_admin: { Args: never; Returns: boolean }
      is_finance: { Args: never; Returns: boolean }
      log_audit: {
        Args: {
          _action: string
          _details: Json
          _entity: string
          _entity_id: string
        }
        Returns: undefined
      }
      mark_hod_physical: {
        Args: { p_file_name: string; p_file_url: string; p_id: string }
        Returns: undefined
      }
      mark_physical_received: { Args: { p_id: string }; Returns: undefined }
      mark_vouchers_exported: {
        Args: { p_voucher_nos: string[] }
        Returns: undefined
      }
      my_department: { Args: never; Returns: string }
      receive_physical_scan: { Args: { p_code: string }; Returns: string }
      submit_invoice: { Args: { p_id: string }; Returns: undefined }
    }
    Enums: {
      app_role:
        | "requester"
        | "hod"
        | "finance_checker"
        | "finance_approver"
        | "finance_staff"
        | "admin"
      attachment_type:
        | "scanned_invoice"
        | "hod_approval_sheet"
        | "submission_sheet"
        | "soa_upload"
        | "reference_doc"
        | "other"
        | "efd_receipt"
        | "grn_copy"
        | "email_confirmation"
        | "delivery_note"
        | "lpo_copy"
        | "contract_copy"
      expense_type: "expense" | "capex"
      gl_type: "expense" | "capex" | "wht_payable" | "vendor_ap"
      invoice_status:
        | "draft"
        | "submitted"
        | "hod_approved"
        | "finance_checked"
        | "finance_approved"
        | "voucher_generated"
        | "payment_request"
        | "payment_confirmed"
        | "returned"
        | "rejected"
        | "closed"
      match_status:
        | "strong_match"
        | "match_no_voucher_ref"
        | "multiple_candidates"
        | "mismatch"
        | "not_found"
        | "manually_resolved"
      reference_type: "lpo" | "agreement" | "direct"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: [
        "requester",
        "hod",
        "finance_checker",
        "finance_approver",
        "finance_staff",
        "admin",
      ],
      attachment_type: [
        "scanned_invoice",
        "hod_approval_sheet",
        "submission_sheet",
        "soa_upload",
        "reference_doc",
        "other",
        "efd_receipt",
        "grn_copy",
        "email_confirmation",
        "delivery_note",
        "lpo_copy",
        "contract_copy",
      ],
      expense_type: ["expense", "capex"],
      gl_type: ["expense", "capex", "wht_payable", "vendor_ap"],
      invoice_status: [
        "draft",
        "submitted",
        "hod_approved",
        "finance_checked",
        "finance_approved",
        "voucher_generated",
        "payment_request",
        "payment_confirmed",
        "returned",
        "rejected",
        "closed",
      ],
      match_status: [
        "strong_match",
        "match_no_voucher_ref",
        "multiple_candidates",
        "mismatch",
        "not_found",
        "manually_resolved",
      ],
      reference_type: ["lpo", "agreement", "direct"],
    },
  },
} as const

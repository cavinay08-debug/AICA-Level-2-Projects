import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export function useDepartments() {
  return useQuery({
    queryKey: ["departments"],
    queryFn: async () => {
      const { data, error } = await supabase.from("departments").select("*").order("name");
      if (error) throw error;
      return data;
    },
  });
}

export function useVendors() {
  return useQuery({
    queryKey: ["vendors"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("vendors")
        .select(
          "vendor_code, vendor_name, tax_id, wht_category, wht_applicable, active, created_at, vat_registered, vrn",
        )
        .order("vendor_name");
      if (error) throw error;
      return data;
    },
  });
}

export function useGlAccounts() {
  return useQuery({
    queryKey: ["gl_accounts"],
    queryFn: async () => {
      const { data, error } = await supabase.from("gl_accounts").select("*").order("gl_code");
      if (error) throw error;
      return data;
    },
  });
}

export function useBusinessUnits() {
  return useQuery({
    queryKey: ["business_units"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("business_units")
        .select("*")
        .order("code");
      if (error) throw error;
      return data;
    },
  });
}

export function useCostCenters() {
  return useQuery({
    queryKey: ["cost_centers"],
    queryFn: async () => {
      const { data, error } = await supabase.from("cost_centers").select("*").order("code");
      if (error) throw error;
      return data;
    },
  });
}


export function useWhtRates() {
  return useQuery({
    queryKey: ["wht_rates"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("wht_rates")
        .select("*")
        .order("wht_category")
        .order("effective_from", { ascending: false });
      if (error) throw error;
      return data;
    },
  });
}

export function useProfiles() {
  return useQuery({
    queryKey: ["profiles"],
    queryFn: async () => {
      const { data, error } = await supabase.from("profiles").select("*").order("full_name");
      if (error) throw error;
      return data;
    },
  });
}

export function useInvoices() {
  return useQuery({
    queryKey: ["invoices"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("invoice_requests")
        .select("*, departments(name), profiles:requester_id(full_name), vendors(vendor_name)")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });
}

export function useInvoice(id: string) {
  return useQuery({
    queryKey: ["invoice", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("invoice_requests")
        .select(
          "*, departments(name, approval_threshold), vendors(vendor_name, wht_category, wht_applicable), profiles:requester_id(full_name, email), business_units(code, name), cost_centers(code, name)",
        )
        .eq("id", id)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });
}

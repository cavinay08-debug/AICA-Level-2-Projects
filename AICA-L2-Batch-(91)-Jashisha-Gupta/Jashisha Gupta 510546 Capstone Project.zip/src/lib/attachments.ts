/** Document categories a user department can hand over with an invoice. */
export type AttachmentCategory = {
  key: string;
  /** enum value stored in attachments.type */
  dbType: string;
  label: string;
  hint: string;
};

export const ATTACHMENT_CATEGORIES: AttachmentCategory[] = [
  {
    key: "scanned_invoice",
    dbType: "scanned_invoice",
    label: "Invoice copy",
    hint: "The original supplier invoice — photo or PDF",
  },
  {
    key: "efd_receipt",
    dbType: "efd_receipt",
    label: "EFD receipt",
    hint: "TRA fiscal receipt (scan its QR above)",
  },
  {
    key: "grn_copy",
    dbType: "grn_copy",
    label: "GRN copy",
    hint: "Goods received note signed by stores",
  },
  {
    key: "delivery_note",
    dbType: "delivery_note",
    label: "Delivery note",
    hint: "Signed delivery / job completion note",
  },
  {
    key: "email_confirmation",
    dbType: "email_confirmation",
    label: "Email confirmation",
    hint: "Email approving the order, price or service",
  },
  {
    key: "lpo_copy",
    dbType: "lpo_copy",
    label: "LPO copy",
    hint: "Purchase order raised for this supply",
  },
  {
    key: "contract_copy",
    dbType: "contract_copy",
    label: "Contract / agreement",
    hint: "Signed agreement backing the invoice",
  },
  {
    key: "other",
    dbType: "other",
    label: "Other supporting document",
    hint: "Anything else Finance should see",
  },
];

export function categoryLabel(dbType: string) {
  return (
    ATTACHMENT_CATEGORIES.find((c) => c.dbType === dbType)?.label ??
    dbType.replace(/_/g, " ")
  );
}

export type InvoiceStatus =
  | "draft"
  | "submitted"
  | "hod_approved"
  | "finance_checked"
  | "finance_approved"
  | "voucher_generated"
  | "payment_request"
  | "payment_confirmed"
  | "returned"
  | "rejected"
  | "closed";

export const STATUS_LABEL: Record<InvoiceStatus, string> = {
  draft: "Draft",
  submitted: "Submitted — with HOD",
  hod_approved: "HOD Approved — Finance Check",
  finance_checked: "Finance Checked — Awaiting Approval",
  finance_approved: "Finance Approved",
  voucher_generated: "Voucher Generated",
  payment_request: "Payment Request",
  payment_confirmed: "Payment Confirmed",
  returned: "Returned for Correction",
  rejected: "Rejected",
  closed: "Closed / Paid",
};

export const PIPELINE: InvoiceStatus[] = [
  "draft",
  "submitted",
  "hod_approved",
  "finance_checked",
  "payment_request",
  "payment_confirmed",
  "closed",
];

export function statusClasses(s: InvoiceStatus) {
  switch (s) {
    case "draft":
      return "bg-muted text-muted-foreground";
    case "submitted":
      return "bg-info/15 text-info";
    case "hod_approved":
      return "bg-primary/15 text-primary";
    case "finance_checked":
      return "bg-accent/25 text-accent-foreground";
    case "payment_request":
      return "bg-warning/25 text-warning-foreground";
    case "payment_confirmed":
    case "closed":
      return "bg-success/15 text-success";
    case "returned":
      return "bg-warning/25 text-warning-foreground";
    case "rejected":
      return "bg-destructive/15 text-destructive";
    default:
      return "bg-secondary text-secondary-foreground";
  }
}

export const REFERENCE_LABEL: Record<string, string> = {
  lpo: "Against LPO",
  agreement: "Against Agreement/Contract",
  direct: "Direct (No LPO / No Agreement)",
};

export function money(v: number | string | null | undefined, currency = "TZS") {
  const n = Number(v ?? 0);
  return `${currency} ${n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export function daysSince(iso: string | null | undefined) {
  if (!iso) return 0;
  return Math.floor((Date.now() - new Date(iso).getTime()) / 86400000);
}

export function fmtDate(iso: string | null | undefined) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, {
    year: "numeric",
    month: "short",
    day: "2-digit",
  });
}

export function fmtDateTime(iso: string | null | undefined) {
  if (!iso) return "—";
  return new Date(iso).toLocaleString(undefined, {
    year: "numeric",
    month: "short",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

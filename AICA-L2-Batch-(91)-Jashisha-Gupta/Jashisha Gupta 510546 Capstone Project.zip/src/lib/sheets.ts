import QRCode from "qrcode";
import { fmtDate, fmtDateTime, money, REFERENCE_LABEL } from "./workflow";
import { ATTACHMENT_CATEGORIES } from "./attachments";

type Row = { label: string; value: string };

/** Short human-typable fallback code, used when the QR cannot be scanned. */
export function qrReferenceCode(inv: { request_no?: string | null; id: string }) {
  return (inv.request_no ?? `REQ-${inv.id.slice(0, 8)}`).toUpperCase();
}

async function qrBlock(payload: string, code: string, size = 96) {
  let img = "";
  try {
    const url = await QRCode.toDataURL(payload, { margin: 0, width: 240, errorCorrectionLevel: "M" });
    img = `<img src="${url}" alt="QR code" style="width:${size}px;height:${size}px;display:block" />`;
  } catch {
    img = `<div style="width:${size}px;height:${size}px;border:1px dashed #999"></div>`;
  }
  return `<div style="text-align:center">
    ${img}
    <div style="font:8px 'Courier New',monospace;margin-top:2px">SCAN AT FINANCE</div>
    <div style="font:bold 11px 'Courier New',monospace;letter-spacing:.5px">${code}</div>
  </div>`;
}

function barcode(text: string) {
  let seed = 0;
  for (let i = 0; i < text.length; i++) seed = (seed * 31 + text.charCodeAt(i)) % 100000;
  let bars = "";
  for (let i = 0; i < 40; i++) {
    seed = (seed * 1103515245 + 12345) % 2147483648;
    const w = (seed % 3) + 1;
    const dark = i % 2 === 0;
    bars += `<span style="display:inline-block;width:${w * 2}px;height:30px;background:${dark ? "#111" : "#fff"}"></span>`;
  }
  return `<div style="line-height:0">${bars}</div><div style="font:9px 'Courier New',monospace;letter-spacing:1px;margin-top:2px">${text}</div>`;
}

/** Two-column compact key/value grid (saves vertical space). */
function table(rows: Row[], cols = 2) {
  const cells = rows
    .map(
      (r) =>
        `<div class="kv"><span class="k">${r.label}</span><span class="v">${r.value ?? "—"}</span></div>`,
    )
    .join("");
  return `<div class="kvgrid" style="grid-template-columns:repeat(${cols},1fr)">${cells}</div>`;
}

const BASE_CSS = `
  @page { size: A4 portrait; margin: 8mm; }
  * { box-sizing: border-box; }
  body { font-family: Helvetica, Arial, sans-serif; color:#111; margin:0; padding:0; font-size:9.5px; -webkit-print-color-adjust:exact; print-color-adjust:exact; }
  #sheet { width:194mm; transform-origin: top left; }
  h1 { margin:0; font-size:15px; letter-spacing:.5px; }
  h3 { font-size:10px; margin:8px 0 3px; text-transform:uppercase; letter-spacing:.5px; }
  p { margin:6px 0; }
  table { width:100%; border-collapse:collapse; font-size:9px; page-break-inside:avoid; }
  th, td { border:1px solid #bbb; padding:3px 4px; text-align:left; vertical-align:top; }
  th { background:#eef1f4; font-size:8.5px; text-transform:uppercase; letter-spacing:.3px; }
  .kvgrid { display:grid; gap:0; border:1px solid #bbb; border-bottom:0; page-break-inside:avoid; }
  .kv { display:flex; border-bottom:1px solid #bbb; font-size:9px; }
  .kv .k { width:42%; background:#f4f6f8; font-weight:600; padding:3px 5px; border-right:1px solid #bbb; }
  .kv .v { flex:1; padding:3px 5px; }
  .box { border:1px solid #bbb; padding:6px 8px; page-break-inside:avoid; }
  .sign { display:flex; gap:14px; margin-top:18px; font-size:9px; }
  .sign > div { flex:1; border-top:1px solid #333; padding-top:3px; }
  .muted { color:#555; }
  .head { display:flex; justify-content:space-between; align-items:flex-start; border-bottom:2px solid #1f3b57; padding-bottom:6px; }
`;

/** Prints on a single A4 page: shrinks the whole sheet to fit if content overflows. */
const AUTOFIT = `
  (function(){
    var el = document.getElementById('sheet');
    var maxH = 281 * 96 / 25.4; // A4 height minus 8mm margins, in px
    function fit(){
      el.style.transform = 'scale(1)';
      var h = el.scrollHeight;
      if (h > maxH) {
        var s = Math.max(0.5, maxH / h);
        el.style.transform = 'scale(' + s + ')';
        document.body.style.height = (h * s) + 'px';
      }
    }
    fit();
    setTimeout(function(){ fit(); window.print(); }, 350);
  })();
`;

function watermarkLayer(text: string) {
  if (!text) return "";
  return `<div style="position:fixed;inset:0;pointer-events:none;z-index:9999;display:flex;align-items:center;justify-content:center">
    <div style="transform:rotate(-32deg);font:700 26px Helvetica,Arial,sans-serif;color:rgba(31,59,87,.12);white-space:nowrap;text-align:center;line-height:1.6">
      ${text}
    </div>
  </div>`;
}

/** Standard footer/watermark caption: who printed it and when. */
export function printedByStamp(name: string | null | undefined) {
  return `PRINTED BY ${(name ?? "—").toUpperCase()} · ${new Date().toLocaleString(undefined, {
    year: "numeric",
    month: "short",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  })}`;
}

function shell(title: string, body: string, watermark = "") {
  return `<!doctype html><html><head><meta charset="utf-8"><title>${title}</title>
  <style>${BASE_CSS}</style></head>
  <body>${watermarkLayer(watermark)}<div id="sheet">${body}</div>
  <script>window.onload=function(){${AUTOFIT}}</script>
  </body></html>`;
}

function open(html: string) {
  const w = window.open("", "_blank", "width=900,height=1100");
  if (!w) return false;
  w.document.write(html);
  w.document.close();
  return true;
}



function docsTable(declared: string[] | null | undefined, uploaded: { type: string; file_name: string | null }[] = []) {
  const list = declared?.length ? declared : [];
  if (!list.length) return `<p class="muted">No documents declared.</p>`;
  // Two side-by-side columns so long checklists stay on one page.
  const half = Math.ceil(list.length / 2);
  const cell = (k: string) => {
    const cat = ATTACHMENT_CATEGORIES.find((c) => c.key === k);
    const up = uploaded.filter((a) => a.type === (cat?.dbType ?? k));
    return `<tr><td>${cat?.label ?? k.replace(/_/g, " ")}</td>
      <td>${up.length ? up.map((u) => u.file_name ?? "file").join(", ") : "—"}</td>
      <td style="text-align:center;width:34px">&#9744;</td></tr>`;
  };
  const col = (items: string[]) =>
    `<table><tr><th>Document</th><th>In portal</th><th>Rcvd</th></tr>${items.map(cell).join("")}</table>`;
  if (list.length <= 4) return col(list);
  return `<div style="display:flex;gap:8px">
    <div style="flex:1">${col(list.slice(0, half))}</div>
    <div style="flex:1">${col(list.slice(half))}</div>
  </div>`;
}


// eslint-disable-next-line @typescript-eslint/no-explicit-any
type Inv = any;

/**
 * Request voucher printed automatically the moment a request is submitted.
 * Carries a diagonal watermark with who printed it and when.
 */
export async function printRequestVoucher(
  inv: Inv,
  extra: {
    department: string;
    requester: string;
    requesterEmail?: string | null;
    businessUnit?: string | null;
    costCenter?: string | null;
    printedBy?: string | null;
    attachments?: { type: string; file_name: string | null }[];
  },
) {
  const code = qrReferenceCode(inv);
  const payload =
    typeof window !== "undefined" ? `${window.location.origin}/requests/${inv.id}` : `REQ:${inv.id}`;
  const qr = await qrBlock(payload, code);
  const stamp = printedByStamp(extra.printedBy ?? extra.requester);
  const html = shell(
    `Invoice Request Voucher ${inv.request_no ?? ""}`,
    `
    <div class="head">
      <div><h1>${COMPANY_NAME}</h1>
      <div class="muted">${COMPANY_SUBTITLE}</div>
      <div style="margin-top:4px;font-size:12px;font-weight:700;letter-spacing:2px">INVOICE REQUEST VOUCHER</div>
      <div style="margin-top:4px">${barcode(inv.request_no ?? inv.id.slice(0, 8))}</div></div>
      <div style="text-align:right">${qr}</div>
    </div>
    <div class="box" style="margin-top:6px;display:flex;gap:12px">
      <div style="flex:1"><strong>Submitted by:</strong> ${extra.requester} · ${extra.requesterEmail ?? "—"}</div>
      <div style="flex:1"><strong>Department:</strong> ${extra.department}</div>
      <div style="flex:1"><strong>Submitted on:</strong> ${fmtDateTime(inv.created_at)}</div>
      <div style="flex:1"><strong>Request ID:</strong> ${inv.request_no ?? "—"}</div>
    </div>
    ${table([
      { label: "Business unit", value: extra.businessUnit ?? "—" },
      { label: "Cost center", value: extra.costCenter ?? "—" },
      { label: "Vendor", value: inv.vendor_name_free_text },
      { label: "Invoice No / Date", value: `${inv.invoice_no} / ${fmtDate(inv.invoice_date)}` },
      { label: "Amount", value: money(inv.amount, inv.currency) },
      { label: "Tax / VAT", value: money(inv.tax_amount, inv.currency) },
      { label: "Net Payable", value: money(inv.net_amount, inv.currency) },
      { label: "Reference Type", value: REFERENCE_LABEL[inv.reference_type] ?? inv.reference_type },
      { label: "Reference No", value: inv.reference_number ?? "—" },
      { label: "Description", value: inv.description ?? "—" },
    ])}
    <h3>Documents declared by the department</h3>
    ${docsTable(inv.declared_attachments, extra.attachments ?? [])}
    <div class="box" style="margin-top:10px">
      <div style="font-weight:700;margin-bottom:16px">HOD SIGN-OFF (record copy)</div>
      <div class="sign" style="margin-top:6px">
        <div>HOD Name &amp; Signature</div>
        <div>Date</div>
      </div>
    </div>
    <div style="margin-top:6px;font-size:7.5px;color:#777">${stamp} — approval is recorded in the portal; this print is a record copy only.</div>`,
    stamp,
  );
  return open(html);
}


export function printSubmissionSheet(
  inv: Inv,
  extra: {
    department: string;
    requester: string;
    vendorName: string;
    lines: { gl_code: string | null; cost_center: string | null; amount: number }[];
    hodApprovedBy: string;
    attachments?: { type: string; file_name: string | null }[];
  },
) {
  const html = shell(
    `Invoice Submission Sheet ${inv.submission_sheet_no ?? ""}`,
    `
    <div class="head">
      <div><h1>PHYSICAL INVOICE SUBMISSION SHEET</h1>
      <div class="muted">Staple this sheet to the original paper invoice</div></div>
      <div style="text-align:right">${barcode(inv.submission_sheet_no ?? inv.request_no ?? inv.id.slice(0, 8))}</div>
    </div>
    <div style="height:6px"></div>
    ${table([
      { label: "Tracking No", value: inv.submission_sheet_no ?? "—" },
      { label: "Request ID", value: inv.request_no ?? "—" },
      { label: "Department", value: extra.department },
      { label: "Requester", value: extra.requester },
      { label: "Vendor", value: `${extra.vendorName} (${inv.vendor_code ?? "—"})` },
      { label: "Invoice No / Date", value: `${inv.invoice_no} / ${fmtDate(inv.invoice_date)}` },
      { label: "Amount", value: money(inv.amount, inv.currency) },
      {
        label: "WHT",
        value: inv.wht_applicable
          ? `${inv.wht_rate}% — ${money(inv.wht_amount, inv.currency)}`
          : "Not applicable",
      },
      { label: "Reference", value: `${REFERENCE_LABEL[inv.reference_type]} ${inv.reference_number ?? ""}` },
      {
        label: "HOD Approval",
        value: `${extra.hodApprovedBy} — approved ${fmtDateTime(inv.hod_system_approved_at)}`,
      },
    ])}
    <h3>GL / Cost center allocation</h3>
    <table>
      <tr><th>GL Code</th><th>Cost Center</th><th style="text-align:right">Amount</th></tr>
      ${extra.lines
        .map(
          (l) =>
            `<tr><td>${l.gl_code ?? "—"}</td><td>${l.cost_center ?? "—"}</td><td style="text-align:right">${money(l.amount, inv.currency)}</td></tr>`,
        )
        .join("")}
    </table>
    <h3>Documents declared by the department</h3>
    ${docsTable(inv.declared_attachments, extra.attachments ?? [])}
    <div class="box" style="margin-top:10px">
      <div style="font-weight:700">CHECKLIST &amp; RECEIPT</div>
      <div class="sign">
        <div>Delivered by (name &amp; sign)</div>
        <div>Received by Finance (name &amp; sign)</div>
        <div>Date</div>
      </div>
    </div>`,

  );
  return open(html);
}

/** Organisation shown on printed accounting documents. */
export const COMPANY_NAME = "ABC LIMITED";
export const COMPANY_SUBTITLE = "Tanzania · Finance & Accounts Department";

function amountInWords(v: number, currency = "TZS") {
  const ones = ["zero","one","two","three","four","five","six","seven","eight","nine","ten","eleven","twelve","thirteen","fourteen","fifteen","sixteen","seventeen","eighteen","nineteen"];
  const tens = ["","","twenty","thirty","forty","fifty","sixty","seventy","eighty","ninety"];
  const chunk = (n: number): string => {
    if (n < 20) return ones[n] ?? "";
    if (n < 100) return `${tens[Math.floor(n / 10)]}${n % 10 ? "-" + ones[n % 10] : ""}`;
    return `${ones[Math.floor(n / 100)]} hundred${n % 100 ? " " + chunk(n % 100) : ""}`;
  };
  const scale = [
    [1_000_000_000, "billion"],
    [1_000_000, "million"],
    [1_000, "thousand"],
  ] as const;
  let n = Math.floor(Math.abs(v));
  const cents = Math.round((Math.abs(v) - n) * 100);
  let out = "";
  for (const [size, name] of scale) {
    if (n >= size) {
      out += `${chunk(Math.floor(n / size))} ${name} `;
      n %= size;
    }
  }
  if (n > 0 || !out) out += chunk(n);
  const words = out.trim().replace(/\s+/g, " ");
  return `${currency} ${words}${cents ? ` and ${chunk(cents)} cents` : ""} only`.toUpperCase();
}

export async function printVoucher(
  inv: Inv,
  rows: {
    line_no: number;
    gl_code: string | null;
    vendor_code: string | null;
    cost_center_id?: string | null;
    dr_cr: string;
    amount: number;
    narration: string | null;
    voucher_no?: string | null;
  }[],
  extra?: {
    department?: string;
    requester?: string;
    approvals?: { action: string; role: string; created_at: string; comments?: string | null }[];
    glName?: (code: string | null) => string;
    costCenter?: (id: string | null | undefined) => string;
    printedBy?: string | null;
  },
) {
  const stamp = printedByStamp(extra?.printedBy ?? extra?.requester);
  const dr = rows.filter((r) => r.dr_cr === "DR").reduce((s, r) => s + Number(r.amount), 0);
  const cr = rows.filter((r) => r.dr_cr === "CR").reduce((s, r) => s + Number(r.amount), 0);
  const voucherNo = rows[0]?.voucher_no ?? "—";
  const payload =
    typeof window !== "undefined" ? `${window.location.origin}/requests/${inv.id}` : `REQ:${inv.id}`;
  const qr = await qrBlock(payload, voucherNo);

  const trail = (extra?.approvals ?? [])
    .map(
      (a) =>
        `<tr><td style="text-transform:capitalize">${a.action.replace(/_/g, " ")}</td>
        <td style="text-transform:capitalize">${a.role.replace(/_/g, " ")}</td>
        <td>${fmtDateTime(a.created_at)}</td>
        <td>${a.comments ?? ""}</td></tr>`,
    )
    .join("");

  const html = shell(
    `Journal Voucher ${voucherNo}`,
    `
    <div style="display:flex;justify-content:space-between;align-items:flex-start;border:2px solid #1f3b57;padding:8px 10px">
      <div>
        <div style="font-size:15px;font-weight:800;letter-spacing:1px">${COMPANY_NAME}</div>
        <div class="muted">${COMPANY_SUBTITLE}</div>
        <div style="margin-top:6px;font-size:13px;font-weight:700;letter-spacing:2px">JOURNAL VOUCHER</div>
      </div>
      <div style="text-align:right">
        <div><strong>Voucher No:</strong> <span style="font-family:'Courier New',monospace">${voucherNo}</span></div>
        <div><strong>Date:</strong> ${fmtDate(new Date().toISOString())}</div>
        <div><strong>Currency:</strong> ${inv.currency}</div>
      </div>
      <div style="margin-left:10px">${qr}</div>
    </div>
    <div style="height:6px"></div>
    ${table([
      { label: "Request ID", value: inv.request_no ?? "—" },
      { label: "Department", value: extra?.department ?? "—" },
      { label: "Requester", value: extra?.requester ?? "—" },
      { label: "Vendor", value: `${inv.vendor_name_free_text} (${inv.vendor_code ?? "—"})` },
      { label: "Invoice No / Date", value: `${inv.invoice_no} / ${fmtDate(inv.invoice_date)}` },
      { label: "Reference", value: `${REFERENCE_LABEL[inv.reference_type] ?? ""} ${inv.reference_number ?? ""}` },
      { label: "Expense Type", value: String(inv.expense_type).toUpperCase() },
      {
        label: "Withholding Tax",
        value: inv.wht_applicable ? `${inv.wht_rate}% — ${money(inv.wht_amount, inv.currency)}` : "Not applicable",
      },
    ])}
    <h3>Accounting entries</h3>
    <table>
      <tr style="background:#1f3b57;color:#fff">
        <th style="background:#1f3b57;color:#fff;width:20px">#</th>
        <th style="background:#1f3b57;color:#fff">Account code</th>
        <th style="background:#1f3b57;color:#fff">Account name</th>
        <th style="background:#1f3b57;color:#fff">Cost center</th>
        <th style="background:#1f3b57;color:#fff;text-align:right">Debit</th>
        <th style="background:#1f3b57;color:#fff;text-align:right">Credit</th>
      </tr>
      ${rows
        .map(
          (r) =>
            `<tr><td>${r.line_no}</td>
            <td style="font-family:'Courier New',monospace">${r.gl_code ?? r.vendor_code ?? "—"}</td>
            <td>${r.gl_code ? (extra?.glName?.(r.gl_code) ?? "") : `Vendor payable — ${inv.vendor_name_free_text}`}${r.narration ? `<div style="color:#666;font-size:8px">${r.narration}</div>` : ""}</td>
            <td>${extra?.costCenter?.(r.cost_center_id) ?? "—"}</td>
            <td style="text-align:right">${r.dr_cr === "DR" ? money(r.amount, inv.currency) : ""}</td>
            <td style="text-align:right">${r.dr_cr === "CR" ? money(r.amount, inv.currency) : ""}</td></tr>`,
        )
        .join("")}
      <tr style="font-weight:700;background:#f4f6f8">
        <td colspan="4">TOTAL</td>
        <td style="text-align:right">${money(dr, inv.currency)}</td>
        <td style="text-align:right">${money(cr, inv.currency)}</td>
      </tr>
    </table>
    <div class="box" style="margin-top:4px">
      <strong>Amount in words:</strong> ${amountInWords(dr, inv.currency)}
    </div>
    <h3>Workflow history (also available by scanning the QR above)</h3>
    <table>
      <tr><th>Action</th><th>Role</th><th>When</th><th>Comments</th></tr>
      ${trail || `<tr><td colspan="4">No workflow activity recorded.</td></tr>`}
    </table>
    <div class="sign">
      <div>Prepared by (Finance Checker)</div>
      <div>Checked / Approved by (Finance Approver)</div>
      <div>Posted by</div>
      <div>Date</div>
    </div>
    <div style="margin-top:6px;font-size:7.5px;color:#777">System generated on final finance approval — immutable record. Scan the QR code to open the full workflow trail in the portal. ${stamp}</div>`,
    stamp,
  );
  return open(html);
}

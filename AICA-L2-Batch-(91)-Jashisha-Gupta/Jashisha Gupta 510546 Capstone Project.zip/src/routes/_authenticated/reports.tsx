import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { PageHeader } from "@/components/AppLayout";
import { supabase } from "@/integrations/supabase/client";
import { useInvoices, useProfiles } from "@/lib/queries";
import { daysSince, money, STATUS_LABEL, type InvoiceStatus } from "@/lib/workflow";

export const Route = createFileRoute("/_authenticated/reports")({
  head: () => ({
    meta: [
      { title: "Reports & KPIs | Invoice Workflow Portal" },
      { name: "description", content: "Cycle time, ageing, direct-invoice exposure and finance checker accuracy KPIs." },
      { property: "og:title", content: "Reports & KPIs | Invoice Workflow Portal" },
      { property: "og:description", content: "Workflow performance and checker accuracy analytics." },
    ],
  }),
  component: Reports,
});

function Reports() {
  const { data: invoices } = useInvoices();
  const { data: profiles } = useProfiles();

  const { data: corrections } = useQuery({
    queryKey: ["checker_corrections"],
    queryFn: async () => {
      const { data, error } = await supabase.from("checker_corrections").select("*");
      if (error) throw error;
      return data;
    },
  });

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const rows = (invoices ?? []) as any[];
  const active = rows.filter((r) => !["draft", "closed", "rejected"].includes(r.status));
  const direct = rows.filter((r) => r.reference_type === "direct");
  const avgAge = active.length
    ? Math.round(active.reduce((s, r) => s + daysSince(r.created_at), 0) / active.length)
    : 0;
  const totalValue = active.reduce((s, r) => s + Number(r.net_amount || r.amount), 0);

  const byStatus = Object.keys(STATUS_LABEL).map((k) => ({
    status: k as InvoiceStatus,
    count: rows.filter((r) => r.status === k).length,
    value: rows.filter((r) => r.status === k).reduce((s, r) => s + Number(r.amount), 0),
  }));

  const checkerStats = (profiles ?? [])
    .map((p) => {
      const handled = rows.filter((r) => r.finance_checker_id === p.id).length;
      const returned = (corrections ?? []).filter((c) => c.finance_checker_id === p.id).length;
      return {
        name: p.full_name || p.email,
        handled,
        returned,
        accuracy: handled ? Math.round(((handled - returned) / handled) * 100) : null,
      };
    })
    .filter((s) => s.handled > 0 || s.returned > 0)
    .sort((a, b) => (b.accuracy ?? 0) - (a.accuracy ?? 0));

  const fieldCounts = Object.entries(
    (corrections ?? []).reduce<Record<string, number>>((acc, c) => {
      acc[c.field_corrected] = (acc[c.field_corrected] ?? 0) + 1;
      return acc;
    }, {}),
  ).sort((a, b) => b[1] - a[1]);

  const ageBuckets = [
    { label: "0–3 days", test: (d: number) => d <= 3 },
    { label: "4–7 days", test: (d: number) => d > 3 && d <= 7 },
    { label: "8–14 days", test: (d: number) => d > 7 && d <= 14 },
    { label: "15+ days", test: (d: number) => d > 14 },
  ].map((b) => ({ label: b.label, count: active.filter((r) => b.test(daysSince(r.created_at))).length }));

  return (
    <>
      <PageHeader title="Reports & KPIs" subtitle="Workflow throughput, ageing and finance checker accuracy." />

      <div className="mb-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="Active in workflow" value={String(active.length)} hint={`${rows.length} total requests`} />
        <Stat label="Value in workflow" value={money(totalValue)} hint="Net payable, excluding closed" />
        <Stat label="Average age" value={`${avgAge} days`} hint="Since submission" />
        <Stat
          label="Direct invoices"
          value={`${rows.length ? Math.round((direct.length / rows.length) * 100) : 0}%`}
          hint={`${direct.length} without LPO or agreement`}
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="panel p-6">
          <h2 className="mb-3 text-sm font-semibold">Pipeline by stage</h2>
          <table className="w-full text-sm">
            <tbody className="divide-y">
              {byStatus
                .filter((s) => s.count > 0)
                .map((s) => (
                  <tr key={s.status}>
                    <td className="py-2">{STATUS_LABEL[s.status]}</td>
                    <td className="num py-2 text-right">{s.count}</td>
                    <td className="num py-2 text-right text-muted-foreground">{money(s.value)}</td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>

        <div className="panel p-6">
          <h2 className="mb-3 text-sm font-semibold">Ageing of open requests</h2>
          <div className="space-y-3">
            {ageBuckets.map((b) => {
              const pct = active.length ? (b.count / active.length) * 100 : 0;
              return (
                <div key={b.label}>
                  <div className="flex justify-between text-sm">
                    <span>{b.label}</span>
                    <span className="num text-muted-foreground">{b.count}</span>
                  </div>
                  <div className="mt-1 h-2 rounded-full bg-muted">
                    <div className="h-2 rounded-full bg-primary" style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="panel p-6">
          <h2 className="mb-3 text-sm font-semibold">Finance checker accuracy</h2>
          <table className="w-full text-sm">
            <thead className="text-left text-xs text-muted-foreground">
              <tr>
                <th className="pb-2">Checker</th>
                <th className="pb-2 text-right">Handled</th>
                <th className="pb-2 text-right">Returned</th>
                <th className="pb-2 text-right">Accuracy</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {checkerStats.length === 0 && (
                <tr>
                  <td colSpan={4} className="py-4 text-muted-foreground">
                    No checked invoices yet.
                  </td>
                </tr>
              )}
              {checkerStats.map((s) => (
                <tr key={s.name}>
                  <td className="py-2">{s.name}</td>
                  <td className="num py-2 text-right">{s.handled}</td>
                  <td className="num py-2 text-right">{s.returned}</td>
                  <td className="num py-2 text-right">{s.accuracy === null ? "—" : `${s.accuracy}%`}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="panel p-6">
          <h2 className="mb-3 text-sm font-semibold">Most corrected fields</h2>
          <ul className="space-y-2 text-sm">
            {fieldCounts.length === 0 && <li className="text-muted-foreground">No corrections logged.</li>}
            {fieldCounts.map(([f, n]) => (
              <li key={f} className="flex justify-between border-b pb-2 last:border-0">
                <span className="capitalize">{f.replace(/_/g, " ")}</span>
                <span className="num text-muted-foreground">{n}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </>
  );
}

function Stat({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <div className="panel p-5">
      <div className="text-xs uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className="num mt-1 text-2xl font-semibold">{value}</div>
      <div className="mt-1 text-xs text-muted-foreground">{hint}</div>
    </div>
  );
}

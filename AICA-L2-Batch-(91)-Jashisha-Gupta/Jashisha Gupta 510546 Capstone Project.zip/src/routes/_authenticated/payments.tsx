import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { PageHeader } from "@/components/AppLayout";
import { StatusBadge } from "@/components/StatusBadge";
import { supabase } from "@/integrations/supabase/client";
import { fmtDate, money, type InvoiceStatus } from "@/lib/workflow";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

export const Route = createFileRoute("/_authenticated/payments")({
  head: () => ({
    meta: [
      { title: "Payments & reconciliation | Invoice Workflow Portal" },
      { name: "description", content: "Match bank statement and accounting system payments against generated vouchers." },
      { property: "og:title", content: "Payments & reconciliation | Invoice Workflow Portal" },
      { property: "og:description", content: "Voucher-first matching with amount and date tolerance." },
    ],
  }),
  component: Payments,
});

type StmtRow = { reference: string; amount: number; date: string };

function parseCsv(text: string): StmtRow[] {
  return text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean)
    .map((l) => l.split(/[,;\t]/).map((c) => c.trim()))
    .filter((c) => c.length >= 3 && !isNaN(Number(c[1]?.replace(/[, ]/g, ""))))
    .map((c) => ({
      reference: c[0] ?? "",
      amount: Number((c[1] ?? "0").replace(/[, ]/g, "")),
      date: c[2] ?? "",
    }));
}

function Payments() {
  const qc = useQueryClient();
  const [raw, setRaw] = useState("");
  const [tolerance] = useState(3);
  const [busyId, setBusyId] = useState<string | null>(null);

  const { data: pending } = useQuery({
    queryKey: ["payment-queue"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("invoice_requests")
        .select("*, departments(name)")
        .in("status", ["payment_request", "voucher_generated", "finance_approved"])
        .order("updated_at");
      if (error) throw error;
      return data;
    },
  });

  const { data: vouchers } = useQuery({
    queryKey: ["all-vouchers"],
    queryFn: async () => {
      const { data, error } = await supabase.from("vouchers").select("voucher_no, invoice_id, amount, dr_cr, vendor_code");
      if (error) throw error;
      return data;
    },
  });

  const { data: recon } = useQuery({
    queryKey: ["reconciliation"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("payment_reconciliation")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(50);
      if (error) throw error;
      return data;
    },
  });

  const statement = useMemo(() => parseCsv(raw), [raw]);

  const voucherOf = (invoiceId: string) => (vouchers ?? []).find((v) => v.invoice_id === invoiceId);
  const payableOf = (invoiceId: string) =>
    (vouchers ?? [])
      .filter((v) => v.invoice_id === invoiceId && v.dr_cr === "CR" && v.vendor_code)
      .reduce((s, v) => s + Number(v.amount), 0);

  const matchFor = (invoiceId: string) => {
    const vno = voucherOf(invoiceId)?.voucher_no;
    const payable = payableOf(invoiceId);
    const byRef = statement.find((s) => vno && s.reference.toLowerCase().includes(vno.toLowerCase()));
    if (byRef) {
      return {
        row: byRef,
        status: Math.abs(byRef.amount - payable) < 0.01 ? "strong_match" : "amount_mismatch",
      } as const;
    }
    const byAmount = statement.find((s) => Math.abs(s.amount - payable) < 0.01);
    if (byAmount) return { row: byAmount, status: "match_no_voucher_ref" } as const;
    return { row: null, status: "no_match" } as const;
  };

  const confirm = async (invoiceId: string, status: string, row: StmtRow | null, notes: string) => {
    setBusyId(invoiceId);
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { error } = await (supabase.rpc as any)("confirm_payment", {
      p_id: invoiceId,
      p_status: status,
      p_reference: row?.reference ?? null,
      p_notes: notes,
      p_matched_amount: row?.amount ?? null,
      p_matched_date: row?.date || null,
      p_candidates: statement.slice(0, 20),
    });
    setBusyId(null);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Reconciliation recorded");
    qc.invalidateQueries({ queryKey: ["payment-queue"] });
    qc.invalidateQueries({ queryKey: ["reconciliation"] });
    qc.invalidateQueries({ queryKey: ["invoices"] });
  };

  const exportVouchers = () => {
    const rows = (pending ?? []).map((p) => voucherOf(p.id)?.voucher_no).filter(Boolean);
    if (!rows.length) {
      toast.error("Nothing to export");
      return;
    }
    const csv = ["voucher_no", ...rows].join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = "vouchers.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <>
      <PageHeader
        title="Payments & reconciliation"
        subtitle={`Voucher-first matching, then amount + date within ${tolerance} days. Nothing is auto-closed without a logged decision.`}
        action={
          <Button variant="outline" onClick={exportVouchers}>
            Export voucher list
          </Button>
        }
      />

      <div className="panel mb-6 space-y-3 p-6">
        <Label>Paste bank / accounting statement (reference, amount, date per line)</Label>
        <Textarea
          rows={5}
          placeholder={"JV-202601-0001, 1500000, 2026-01-18\nTRF/9921, 480000, 2026-01-20"}
          value={raw}
          onChange={(e) => setRaw(e.target.value)}
        />
        <div className="flex items-center gap-3">
          <Input
            type="file"
            accept=".csv,text/csv,text/plain"
            className="max-w-xs"
            onChange={async (e) => {
              const f = e.target.files?.[0];
              if (f) setRaw(await f.text());
            }}
          />
          <span className="text-xs text-muted-foreground">{statement.length} statement rows parsed</span>
        </div>
      </div>

      <div className="panel mb-6 overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="border-b bg-muted/50 text-left text-xs text-muted-foreground">
            <tr>
              <th className="px-4 py-3 font-medium">Request / Voucher</th>
              <th className="px-4 py-3 font-medium">Vendor</th>
              <th className="px-4 py-3 text-right font-medium">Payable</th>
              <th className="px-4 py-3 font-medium">Suggested match</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 text-right font-medium">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {(pending ?? []).length === 0 && (
              <tr>
                <td colSpan={6} className="px-4 py-10 text-center text-muted-foreground">
                  No vouchers awaiting payment confirmation.
                </td>
              </tr>
            )}
            {(pending ?? []).map((p) => {
              const m = matchFor(p.id);
              return (
                <tr key={p.id}>
                  <td className="px-4 py-3">
                    <Link to="/requests/$id" params={{ id: p.id }} className="num text-primary hover:underline">
                      {p.request_no}
                    </Link>
                    <div className="num text-xs text-muted-foreground">{voucherOf(p.id)?.voucher_no ?? "—"}</div>
                  </td>
                  <td className="px-4 py-3">
                    {p.vendor_name_free_text}
                    <div className="num text-xs text-muted-foreground">{p.vendor_code ?? "—"}</div>
                  </td>
                  <td className="num px-4 py-3 text-right">{money(payableOf(p.id), p.currency)}</td>
                  <td className="px-4 py-3 text-xs">
                    {m.row ? (
                      <>
                        <div className="num">{m.row.reference}</div>
                        <div className="text-muted-foreground">
                          {money(m.row.amount, p.currency)} · {fmtDate(m.row.date)}
                        </div>
                      </>
                    ) : (
                      <span className="text-muted-foreground">No candidate</span>
                    )}
                    <div className="mt-1 uppercase tracking-wide text-muted-foreground">
                      {m.status.replace(/_/g, " ")}
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <StatusBadge status={p.status as InvoiceStatus} />
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex justify-end gap-2">
                      <Button
                        size="sm"
                        disabled={!m.row || busyId === p.id}
                        onClick={() => confirm(p.id, m.status, m.row, "Auto-suggested match accepted")}
                      >
                        Confirm
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        disabled={busyId === p.id}
                        onClick={() =>
                          confirm(p.id, "manually_resolved", m.row, "Manually resolved by payment processing")
                        }
                      >
                        Resolve
                      </Button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="panel p-6">
        <h2 className="mb-3 text-sm font-semibold">Recent reconciliation log</h2>
        <ul className="space-y-2 text-sm">
          {(recon ?? []).length === 0 && <li className="text-muted-foreground">No entries yet.</li>}
          {(recon ?? []).map((r) => (
            <li key={r.id} className="flex flex-wrap justify-between gap-2 border-b pb-2 last:border-0">
              <span className="num">{r.voucher_no}</span>
              <span className="uppercase text-xs text-muted-foreground">{r.match_status.replace(/_/g, " ")}</span>
              <span className="num">{money(r.matched_amount ?? 0)}</span>
              <span className="text-xs text-muted-foreground">{fmtDate(r.matched_date)}</span>
            </li>
          ))}
        </ul>
      </div>
    </>
  );
}

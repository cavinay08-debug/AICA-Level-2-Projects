import { createFileRoute, useNavigate, useSearch } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";
import { QrCode } from "lucide-react";
import { PageHeader } from "@/components/AppLayout";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useBusinessUnits, useCostCenters, useDepartments } from "@/lib/queries";
import { printRequestVoucher } from "@/lib/sheets";
import { EfdQrScanner, type EfdScanResult } from "@/components/EfdQrScanner";
import { ATTACHMENT_CATEGORIES } from "@/lib/attachments";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export const Route = createFileRoute("/_authenticated/requests/new")({
  validateSearch: (s: Record<string, unknown>): { id?: string } =>
    s['id'] ? { id: String(s['id']) } : {},
  head: () => ({
    meta: [
      { title: "New invoice request | Invoice Workflow Portal" },
      { name: "description", content: "Raise an invoice request for your department with LPO, agreement or direct reference." },
      { property: "og:title", content: "New invoice request | Invoice Workflow Portal" },
      { property: "og:description", content: "Capture invoice details and attach the scanned copy." },
    ],
  }),
  component: NewRequest,
});

type Form = {
  department_id: string;
  business_unit_id: string;
  cost_center_id: string;
  vendor_name_free_text: string;
  invoice_no: string;
  invoice_date: string;
  currency: string;
  fx_rate: string;
  fx_remarks: string;
  amount: string;
  reference_type: "lpo" | "agreement" | "direct";
  reference_number: string;

  reference_vendor_name: string;
  reference_validity: string;
  description: string;
  vat_registered_vendor: boolean;
  vat_rate: string;
  amount_is_gross: boolean;
  efd_receipt_no: string;
  efd_verification_code: string;
  efd_qr_url: string;
  efd_scanned_at: string | null;
};

export const CURRENCIES = ["TZS", "USD", "EUR", "GBP", "KES", "UGX", "ZAR", "AED", "INR", "CNY", "JPY", "CHF"];

const EMPTY: Form = {
  department_id: "",
  business_unit_id: "",
  cost_center_id: "",
  vendor_name_free_text: "",
  invoice_no: "",
  invoice_date: new Date().toISOString().slice(0, 10),
  currency: "TZS",
  fx_rate: "",
  fx_remarks: "",
  amount: "",
  reference_type: "direct",
  reference_number: "",

  reference_vendor_name: "",
  reference_validity: "",
  description: "",
  vat_registered_vendor: false,
  vat_rate: "18",
  amount_is_gross: false,
  efd_receipt_no: "",
  efd_verification_code: "",
  efd_qr_url: "",
  efd_scanned_at: null,
};

/** Derives base (VAT-exclusive), VAT and gross from what the user typed. */
export function computeVat(input: {
  amount: number;
  vatRegistered: boolean;
  rate: number;
  amountIsGross: boolean;
}) {
  const r2 = (n: number) => Math.round(n * 100) / 100;
  if (!input.vatRegistered || input.rate <= 0) {
    return { base: r2(input.amount), vat: 0, gross: r2(input.amount) };
  }
  if (input.amountIsGross) {
    const base = input.amount / (1 + input.rate / 100);
    return { base: r2(base), vat: r2(input.amount - base), gross: r2(input.amount) };
  }
  const vat = (input.amount * input.rate) / 100;
  return { base: r2(input.amount), vat: r2(vat), gross: r2(input.amount + vat) };
}

function NewRequest() {
  const navigate = useNavigate();
  const { id } = useSearch({ from: "/_authenticated/requests/new" });
  const { user, profile } = useAuth();
  const { data: departments } = useDepartments();
  const { data: businessUnits } = useBusinessUnits();
  const { data: costCenters } = useCostCenters();
  const [f, setF] = useState<Form>(EMPTY);
  const [docs, setDocs] = useState<Record<string, File | null>>({});
  const [declared, setDeclared] = useState<string[]>(["scanned_invoice"]);

  const [busy, setBusy] = useState(false);
  const [scanOpen, setScanOpen] = useState(false);
  const [fxOpen, setFxOpen] = useState(false);
  const isForeign = f.currency !== "TZS";

  useEffect(() => {
    if (profile?.department_id && !f.department_id && !id) {
      setF((p) => ({ ...p, department_id: profile.department_id as string }));
    }
  }, [profile, f.department_id, id]);

  useEffect(() => {
    if (!id) return;
    supabase
      .from("invoice_requests")
      .select("*")
      .eq("id", id)
      .maybeSingle()
      .then(({ data }) => {
        if (!data) return;
        setF({
          department_id: data.department_id,
          business_unit_id: data.business_unit_id ?? "",
          cost_center_id: data.cost_center_id ?? "",
          vendor_name_free_text: data.vendor_name_free_text,
          invoice_no: data.invoice_no,
          invoice_date: data.invoice_date,
          currency: data.currency,
          fx_rate: data.fx_rate == null ? "" : String(data.fx_rate),
          fx_remarks: data.fx_remarks ?? "",
          amount: String(data.amount),
          
          reference_type: data.reference_type,
          reference_number: data.reference_number ?? "",
          reference_vendor_name: data.reference_vendor_name ?? "",
          reference_validity: data.reference_validity ?? "",
          description: data.description ?? "",
          vat_registered_vendor: data.vat_registered_vendor ?? false,
          vat_rate: String(data.vat_rate ?? 18),
          amount_is_gross: data.amount_is_gross ?? false,
          efd_receipt_no: data.efd_receipt_no ?? "",
          efd_verification_code: data.efd_verification_code ?? "",
          efd_qr_url: data.efd_qr_url ?? "",
          efd_scanned_at: data.efd_scanned_at ?? null,
        });
        if (data.declared_attachments?.length) setDeclared(data.declared_attachments);
      });
  }, [id]);

  const set = <K extends keyof Form>(k: K, v: Form[K]) => setF((p) => ({ ...p, [k]: v }));

  const vat = computeVat({
    amount: Number(f.amount || 0),
    vatRegistered: f.vat_registered_vendor,
    rate: Number(f.vat_rate || 0),
    amountIsGross: f.amount_is_gross,
  });
  const net = vat.gross;

  const onScan = useCallback((r: EfdScanResult) => {
    setF((p) => ({
      ...p,
      efd_receipt_no: r.receiptNo ?? p.efd_receipt_no,
      efd_verification_code: r.verificationCode ?? p.efd_verification_code,
      efd_qr_url: r.url ?? r.raw,
      efd_scanned_at: new Date().toISOString(),
      vat_registered_vendor: true,
      invoice_no: p.invoice_no || (r.receiptNo ?? ""),
    }));
    setDeclared((p) => (p.includes("efd_receipt") ? p : [...p, "efd_receipt"]));
    toast.success("EFD receipt captured");
  }, []);


  const save = async (thenSubmit: boolean) => {
    if (!user) return;
    if (!f.department_id || !f.vendor_name_free_text || !f.invoice_no || !f.amount) {
      toast.error("Department, vendor, invoice number and amount are required");
      return;
    }
    if (!f.business_unit_id || !f.cost_center_id) {
      toast.error("Business unit and cost center are required");
      return;
    }
    if (f.reference_type !== "direct" && !f.reference_number) {
      toast.error("A reference number is required for LPO / Agreement requests");
      return;
    }
    if (!declared.length) {
      toast.error("Tick at least one document you are submitting with this invoice");
      return;
    }
    if (isForeign && !f.fx_remarks.trim()) {
      setFxOpen(true);
      toast.error("Foreign currency remarks are mandatory");
      return;
    }
    setBusy(true);
    const payload = {
      requester_id: user.id,
      department_id: f.department_id,
      business_unit_id: f.business_unit_id,
      cost_center_id: f.cost_center_id,
      vendor_name_free_text: f.vendor_name_free_text,
      invoice_no: f.invoice_no,
      invoice_date: f.invoice_date,
      currency: f.currency,
      fx_rate: isForeign && f.fx_rate ? Number(f.fx_rate) : null,
      fx_remarks: isForeign ? f.fx_remarks.trim() : null,
      amount: vat.base,
      tax_amount: vat.vat,
      net_amount: vat.gross,
      reference_type: f.reference_type,
      reference_number: f.reference_number || null,
      declared_attachments: declared,
      reference_vendor_name: f.reference_vendor_name || null,
      reference_validity: f.reference_validity || null,
      description: f.description || null,
      vat_registered_vendor: f.vat_registered_vendor,
      vat_rate: f.vat_registered_vendor ? Number(f.vat_rate || 0) : 0,
      amount_is_gross: f.amount_is_gross,
      efd_receipt_no: f.efd_receipt_no || null,
      efd_verification_code: f.efd_verification_code || null,
      efd_qr_url: f.efd_qr_url || null,
      efd_scanned_at: f.efd_scanned_at,
    };

    let invoiceId = id;
    if (id) {
      const { error } = await supabase.from("invoice_requests").update(payload).eq("id", id);
      if (error) {
        setBusy(false);
        toast.error(error.message);
        return;
      }
    } else {
      const { data, error } = await supabase
        .from("invoice_requests")
        .insert({ ...payload, status: "draft" as const })
        .select("id")
        .single();
      if (error || !data) {
        setBusy(false);
        toast.error(error?.message ?? "Could not save draft");
        return;
      }
      invoiceId = data.id;
    }

    if (invoiceId) {
      for (const cat of ATTACHMENT_CATEGORIES) {
        const df = docs[cat.key];
        if (!df) continue;
        const path = `${invoiceId}/${cat.key}-${Date.now()}-${df.name}`;
        const { error: upErr } = await supabase.storage.from("invoice-docs").upload(path, df);
        if (upErr) {
          toast.error(`${cat.label} upload failed: ${upErr.message}`);
          continue;
        }
        await supabase.from("attachments").insert({
          invoice_id: invoiceId,
          file_url: path,
          file_name: df.name,
          type: cat.dbType as "other",
          uploaded_by: user.id,
        });
      }
    }

    if (thenSubmit && invoiceId) {
      const { error } = await supabase.rpc("submit_invoice", { p_id: invoiceId });
      if (error) {
        setBusy(false);
        toast.error(error.message);
        return;
      }
      toast.success("Sent to HOD for approval");
      const { data: saved } = await supabase
        .from("invoice_requests")
        .select("*")
        .eq("id", invoiceId)
        .maybeSingle();
      const { data: files } = await supabase
        .from("attachments")
        .select("type, file_name")
        .eq("invoice_id", invoiceId);
      if (saved) {
        const ok = await printRequestVoucher(saved, {
          department: (departments ?? []).find((d) => d.id === saved.department_id)?.name ?? "—",
          requester: profile?.full_name ?? user.email ?? "—",
          requesterEmail: profile?.email ?? user.email ?? null,
          businessUnit:
            (businessUnits ?? []).find((b) => b.id === saved.business_unit_id)?.name ?? null,
          costCenter:
            (costCenters ?? []).find((c) => c.id === saved.cost_center_id)?.name ?? null,
          printedBy: profile?.full_name ?? user.email ?? null,
          attachments: files ?? [],
        });
        if (!ok) toast.error("Allow pop-ups to print the request voucher automatically");
      }
    } else {
      toast.success("Draft saved");
    }
    setBusy(false);
    navigate({ to: "/requests/$id", params: { id: invoiceId as string } });
  };

  return (
    <>
      <PageHeader
        title={id ? "Edit invoice request" : "New invoice request"}
        subtitle="Drafts stay fully editable and are not tracked until you send them to your HOD."
      />

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="panel space-y-4 p-6 lg:col-span-2">
          <h2 className="text-sm font-semibold">Invoice details</h2>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label>Department</Label>
              <Select value={f.department_id} onValueChange={(v) => set("department_id", v)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select department" />
                </SelectTrigger>
                <SelectContent>
                  {(departments ?? []).map((d) => (
                    <SelectItem key={d.id} value={d.id}>
                      {d.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Business unit</Label>
              <Select value={f.business_unit_id} onValueChange={(v) => set("business_unit_id", v)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select business unit" />
                </SelectTrigger>
                <SelectContent>
                  {(businessUnits ?? []).filter((b) => b.active).map((b) => (
                    <SelectItem key={b.id} value={b.id}>
                      {b.code} — {b.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Cost center</Label>
              <Select value={f.cost_center_id} onValueChange={(v) => set("cost_center_id", v)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select cost center" />
                </SelectTrigger>
                <SelectContent>
                  {(costCenters ?? [])
                    .filter(
                      (c) =>
                        c.active &&
                        (!f.department_id || !c.department_id || c.department_id === f.department_id),
                    )
                    .map((c) => (
                      <SelectItem key={c.id} value={c.id}>
                        {c.code} — {c.name}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Vendor name</Label>
              <Input
                value={f.vendor_name_free_text}
                onChange={(e) => set("vendor_name_free_text", e.target.value)}
                placeholder="As printed on the invoice"
              />
            </div>
            <div className="space-y-2">
              <Label>Invoice number</Label>
              <Input value={f.invoice_no} onChange={(e) => set("invoice_no", e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Invoice date</Label>
              <Input type="date" value={f.invoice_date} onChange={(e) => set("invoice_date", e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Currency</Label>
              <Select
                value={f.currency}
                onValueChange={(v) => {
                  set("currency", v);
                  if (v !== "TZS") setFxOpen(true);
                }}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CURRENCIES.map((c) => (
                    <SelectItem key={c} value={c}>
                      {c}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>{f.amount_is_gross ? "Invoice total (VAT inclusive)" : "Amount (excl. VAT)"}</Label>
              <Input type="number" step="0.01" inputMode="decimal" value={f.amount} onChange={(e) => set("amount", e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>VAT amount (auto)</Label>
              <Input readOnly value={vat.vat.toFixed(2)} className="num bg-muted" />
            </div>
          </div>

          <div className="space-y-4 rounded-lg border p-4">
            <div className="flex items-center justify-between gap-4">
              <div>
                <Label>Vendor is VAT registered</Label>
                <p className="text-xs text-muted-foreground">
                  Turn off for non-VAT-registered vendors — VAT stays zero.
                </p>
              </div>
              <Switch
                checked={f.vat_registered_vendor}
                onCheckedChange={(v) => set("vat_registered_vendor", v)}
              />
            </div>
            {f.vat_registered_vendor && (
              <>
                <div className="flex items-center justify-between gap-4">
                  <div>
                    <Label>Amount entered includes VAT</Label>
                    <p className="text-xs text-muted-foreground">
                      Typical for EFD receipts, which print the VAT-inclusive total.
                    </p>
                  </div>
                  <Switch
                    checked={f.amount_is_gross}
                    onCheckedChange={(v) => set("amount_is_gross", v)}
                  />
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label>VAT rate (%)</Label>
                    <Input
                      type="number"
                      step="0.01"
                      inputMode="decimal"
                      value={f.vat_rate}
                      onChange={(e) => set("vat_rate", e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Taxable value (excl. VAT)</Label>
                    <Input readOnly value={vat.base.toFixed(2)} className="num bg-muted" />
                  </div>
                </div>
              </>
            )}
          </div>

          {isForeign && (
            <div className="space-y-4 rounded-lg border border-warning bg-warning/10 p-4">
              <div>
                <h3 className="text-sm font-semibold">Foreign currency invoice ({f.currency})</h3>
                <p className="text-xs text-muted-foreground">
                  Remarks are mandatory for any invoice not raised in TZS.
                </p>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>Exchange rate to TZS (optional)</Label>
                  <Input
                    type="number"
                    step="0.0001"
                    inputMode="decimal"
                    value={f.fx_rate}
                    onChange={(e) => set("fx_rate", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>TZS equivalent</Label>
                  <Input
                    readOnly
                    className="num bg-muted"
                    value={
                      f.fx_rate
                        ? (net * Number(f.fx_rate)).toLocaleString(undefined, { minimumFractionDigits: 2 })
                        : "—"
                    }
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Foreign currency remarks (mandatory)</Label>
                <Textarea
                  rows={3}
                  placeholder="Why is this invoice in foreign currency, rate source, contract clause, payment method…"
                  value={f.fx_remarks}
                  onChange={(e) => set("fx_remarks", e.target.value)}
                />
              </div>
            </div>
          )}


          <div className="space-y-4 rounded-lg border p-4">
            <div className="flex items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-semibold">EFD receipt (TRA)</h3>
                <p className="text-xs text-muted-foreground">
                  Scan the QR code on the fiscal receipt with the external QR scanner.
                </p>
              </div>
              <Button type="button" variant="outline" onClick={() => setScanOpen(true)}>
                <QrCode className="mr-2 size-4" /> Scan QR
              </Button>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>Receipt number</Label>
                <Input value={f.efd_receipt_no} onChange={(e) => set("efd_receipt_no", e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Verification code</Label>
                <Input
                  value={f.efd_verification_code}
                  onChange={(e) => set("efd_verification_code", e.target.value)}
                />
              </div>
            </div>
            {f.efd_qr_url && (
              <p className="break-all text-xs text-muted-foreground">Scanned link: {f.efd_qr_url}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label>Description / purpose</Label>
            <Textarea rows={3} value={f.description} onChange={(e) => set("description", e.target.value)} />
          </div>
        </div>

        <div className="space-y-6">

          <div className="panel space-y-4 p-6">
            <h2 className="text-sm font-semibold">Invoice reference</h2>
            <div className="space-y-2">
              <Label>Reference type</Label>
              <Select value={f.reference_type} onValueChange={(v) => set("reference_type", v as Form["reference_type"])}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="lpo">Against LPO</SelectItem>
                  <SelectItem value="agreement">Against Agreement / Contract</SelectItem>
                  <SelectItem value="direct">Direct (no LPO / no agreement)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {f.reference_type === "lpo" && (
              <>
                <div className="space-y-2">
                  <Label>LPO number</Label>
                  <Input value={f.reference_number} onChange={(e) => set("reference_number", e.target.value)} />
                </div>
              </>
            )}
            {f.reference_type === "agreement" && (
              <>
                <div className="space-y-2">
                  <Label>Agreement / contract reference</Label>
                  <Input value={f.reference_number} onChange={(e) => set("reference_number", e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label>Agreement vendor name</Label>
                  <Input
                    value={f.reference_vendor_name}
                    onChange={(e) => set("reference_vendor_name", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Validity period</Label>
                  <Input
                    placeholder="e.g. Jan 2026 – Dec 2026"
                    value={f.reference_validity}
                    onChange={(e) => set("reference_validity", e.target.value)}
                  />
                </div>
              </>
            )}
            {f.reference_type === "direct" && (
              <p className="rounded-md bg-warning/15 p-3 text-xs text-warning-foreground">
                Direct invoices carry no LPO or contract backing and are flagged for extra scrutiny at
                finance check.
              </p>
            )}
          </div>

          <div className="panel space-y-4 p-6">
            <h2 className="text-sm font-semibold">Documents you are submitting</h2>
            <p className="text-xs text-muted-foreground">
              Tick everything you will hand over to Finance. Attach a photo or file now if you have it — Finance
              checks this list against what they physically receive.
            </p>
            <div className="space-y-2">
              {ATTACHMENT_CATEGORIES.map((c) => {
                const on = declared.includes(c.key);
                const picked = docs[c.key];
                return (
                  <div
                    key={c.key}
                    className={`rounded-lg border p-3 ${on ? "border-primary/50 bg-primary/5" : ""}`}
                  >
                    <label className="flex cursor-pointer items-start gap-3">
                      <input
                        type="checkbox"
                        className="mt-1 size-4"
                        checked={on}
                        onChange={(e) =>
                          setDeclared((p) =>
                            e.target.checked ? [...p, c.key] : p.filter((x) => x !== c.key),
                          )
                        }
                      />
                      <span>
                        <span className="block text-sm font-medium">{c.label}</span>
                        <span className="block text-xs text-muted-foreground">{c.hint}</span>
                      </span>
                    </label>
                    {on && (
                      <div className="mt-3 flex flex-wrap items-center gap-2">
                        <label className="inline-flex cursor-pointer items-center gap-2 rounded-md border px-3 py-2 text-xs">
                          Choose file
                          <input
                            type="file"
                            accept="image/*,application/pdf"
                            className="hidden"
                            onChange={(e) =>
                              setDocs((p) => ({ ...p, [c.key]: e.target.files?.[0] ?? null }))
                            }
                          />
                        </label>
                        <span className="text-xs text-muted-foreground">
                          {picked ? picked.name : "Physical copy only"}
                        </span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
            <div className="rounded-md bg-muted p-3 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Taxable value</span>
                <span className="num">{vat.base.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">
                  VAT {f.vat_registered_vendor ? `@ ${f.vat_rate}%` : "(vendor not VAT registered)"}
                </span>
                <span className="num">{vat.vat.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
              </div>
              <div className="mt-1 flex justify-between border-t pt-1">
                <span className="text-muted-foreground">Net payable</span>
                <span className="num font-medium">
                  {f.currency} {net.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </span>
              </div>
            </div>

            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" disabled={busy} onClick={() => save(false)}>
                Save draft
              </Button>
              <Button className="flex-1" disabled={busy} onClick={() => save(true)}>
                Send to HOD
              </Button>
            </div>
          </div>
        </div>
      </div>

      <EfdQrScanner open={scanOpen} onOpenChange={setScanOpen} onResult={onScan} />

      <Dialog open={fxOpen} onOpenChange={setFxOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Foreign currency invoice ({f.currency})</DialogTitle>
            <DialogDescription>
              This invoice is not in TZS. Explain the reason, the rate source and how it will be settled — Finance
              cannot process it without these remarks.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <Label>Exchange rate to TZS (optional)</Label>
            <Input
              type="number"
              step="0.0001"
              inputMode="decimal"
              value={f.fx_rate}
              onChange={(e) => set("fx_rate", e.target.value)}
            />
            <Label>Remarks (mandatory)</Label>
            <Textarea
              rows={4}
              value={f.fx_remarks}
              onChange={(e) => set("fx_remarks", e.target.value)}
              placeholder="e.g. Contract priced in USD, TRA rate of the invoice date applied, paid by telegraphic transfer."
            />
          </div>
          <DialogFooter>
            <Button
              onClick={() => {
                if (!f.fx_remarks.trim()) {
                  toast.error("Remarks are mandatory for foreign currency invoices");
                  return;
                }
                setFxOpen(false);
              }}
            >
              Save remarks
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

    </>

  );
}

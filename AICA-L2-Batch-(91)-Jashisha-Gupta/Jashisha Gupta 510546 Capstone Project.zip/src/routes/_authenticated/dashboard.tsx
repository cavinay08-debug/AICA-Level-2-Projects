import { createFileRoute, Link } from "@tanstack/react-router";
import { AlertTriangle, Clock, FileCheck2, Wallet } from "lucide-react";
import { PageHeader } from "@/components/AppLayout";
import { StatusBadge } from "@/components/StatusBadge";
import { useAuth } from "@/hooks/useAuth";
import { useInvoices } from "@/lib/queries";
import { daysSince, fmtDate, money, type InvoiceStatus } from "@/lib/workflow";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard | Invoice Workflow Portal" },
      { name: "description", content: "Your invoice queues, pending approvals and ageing at a glance." },
      { property: "og:title", content: "Dashboard | Invoice Workflow Portal" },
      { property: "og:description", content: "Track where each invoice sits in the approval chain." },
    ],
  }),
  component: Dashboard,
});

type Row = {
  id: string;
  request_no: string | null;
  status: InvoiceStatus;
  amount: number;
  currency: string;
  invoice_no: string;
  invoice_date: string;
  vendor_name_free_text: string;
  updated_at: string;
  requester_id: string;
  hod_system_approved_at: string | null;
  hod_physical_signed_uploaded_at: string | null;
  departments?: { name: string } | null;
};

function Stat({
  label,
  value,
  icon: Icon,
  tone = "primary",
}: {
  label: string;
  value: string | number;
  icon: typeof Clock;
  tone?: "primary" | "warning" | "success" | "destructive";
}) {
  const tones: Record<string, string> = {
    primary: "bg-primary/10 text-primary",
    warning: "bg-warning/20 text-warning-foreground",
    success: "bg-success/10 text-success",
    destructive: "bg-destructive/10 text-destructive",
  };
  return (
    <div className="panel flex items-center gap-4 p-5">
      <div className={`rounded-lg p-2.5 ${tones[tone]}`}>
        <Icon className="h-5 w-5" />
      </div>
      <div>
        <div className="num text-2xl font-semibold">{value}</div>
        <div className="text-xs text-muted-foreground">{label}</div>
      </div>
    </div>
  );
}

function Queue({ title, rows, empty }: { title: string; rows: Row[]; empty: string }) {
  return (
    <div className="panel overflow-hidden">
      <div className="flex items-center justify-between border-b px-5 py-3">
        <h2 className="text-sm font-semibold">{title}</h2>
        <span className="num text-xs text-muted-foreground">{rows.length}</span>
      </div>
      {rows.length === 0 ? (
        <p className="px-5 py-8 text-center text-sm text-muted-foreground">{empty}</p>
      ) : (
        <div className="divide-y">
          {rows.slice(0, 8).map((r) => (
            <Link
              key={r.id}
              to="/requests/$id"
              params={{ id: r.id }}
              className="flex flex-wrap items-center justify-between gap-3 px-5 py-3 transition-colors hover:bg-muted/60"
            >
              <div className="min-w-0">
                <div className="flex items-center gap-2 text-sm font-medium">
                  <span className="num">{r.request_no ?? "Draft"}</span>
                  <span className="truncate text-muted-foreground">{r.vendor_name_free_text}</span>
                </div>
                <div className="mt-0.5 text-xs text-muted-foreground">
                  {r.departments?.name ?? "—"} • Inv {r.invoice_no} • {fmtDate(r.invoice_date)} •{" "}
                  {daysSince(r.updated_at)}d in stage
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span className="num text-sm">{money(r.amount, r.currency)}</span>
                <StatusBadge status={r.status} />
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

function Dashboard() {
  const { profile, has, user } = useAuth();
  const { data, isLoading } = useInvoices();
  const rows = (data ?? []) as unknown as Row[];

  const mine = rows.filter((r) => r.requester_id === user?.id);
  const hodQueue = rows.filter((r) => r.status === "submitted");
  const awaitingPhysical = rows.filter(
    (r) => r.hod_system_approved_at && !r.hod_physical_signed_uploaded_at,
  );
  const checkerQueue = rows.filter((r) => r.status === "hod_approved");
  const approverQueue = rows.filter((r) => r.status === "finance_checked");
  const paymentQueue = rows.filter((r) => r.status === "payment_request");
  const aging = rows.filter(
    (r) => !["closed", "payment_confirmed", "rejected", "draft"].includes(r.status) && daysSince(r.updated_at) > 5,
  );

  return (
    <>
      <PageHeader
        title={`Welcome${profile?.full_name ? `, ${profile.full_name.split(" ")[0]}` : ""}`}
        subtitle="Your queues and everything waiting on you right now."
        action={
          <Button asChild>
            <Link to="/requests/new">New invoice request</Link>
          </Button>
        }
      />

      <div className="mb-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="My requests in flight" value={mine.filter((r) => !["closed", "rejected"].includes(r.status)).length} icon={FileCheck2} />
        <Stat label="Awaiting my department HOD" value={hodQueue.length} icon={Clock} tone="warning" />
        <Stat label="In finance (check + approve)" value={checkerQueue.length + approverQueue.length} icon={Wallet} />
        <Stat label="Ageing over 5 days" value={aging.length} icon={AlertTriangle} tone="destructive" />
      </div>

      {isLoading ? (
        <p className="text-sm text-muted-foreground">Loading…</p>
      ) : (
        <div className="grid gap-6 xl:grid-cols-2">
          <Queue title="My submissions" rows={mine} empty="You have not raised any invoice requests yet." />
          {has("hod") && (
            <Queue
              title="Pending my approval (department)"
              rows={hodQueue}
              empty="Nothing waiting for your system approval."
            />
          )}
          {has("hod", "requester") && (
            <Queue
              title="Awaiting signed physical HOD sheet"
              rows={awaitingPhysical.filter((r) => has("hod") || r.requester_id === user?.id)}
              empty="No requests waiting on a signed sheet upload."
            />
          )}
          {has("finance_checker") && (
            <Queue title="Finance check queue" rows={checkerQueue} empty="No HOD-approved invoices to check." />
          )}
          {has("finance_approver") && (
            <Queue
              title="Pending final finance approval"
              rows={approverQueue}
              empty="No checked invoices awaiting approval."
            />
          )}
          {has("finance_staff", "admin") && (
            <Queue title="Payment request queue" rows={paymentQueue} empty="No vouchers awaiting payment confirmation." />
          )}
          {has("admin") && (
            <Queue title="Ageing — stuck over 5 days" rows={aging} empty="Nothing is ageing badly. Good." />
          )}
        </div>
      )}
    </>
  );
}

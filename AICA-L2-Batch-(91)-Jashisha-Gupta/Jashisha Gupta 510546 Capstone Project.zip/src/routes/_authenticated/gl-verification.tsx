import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { CheckCircle2, AlertTriangle, XCircle, HelpCircle, Upload, Trash2 } from "lucide-react";
import { PageHeader } from "@/components/AppLayout";
import { supabase } from "@/integrations/supabase/client";
import { money, fmtDate } from "@/lib/workflow";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/hooks/useAuth";

export const Route = createFileRoute("/_authenticated/gl-verification")({
  head: () => ({
    meta: [
      { title: "GL posting verification | Invoice Workflow Portal" },
      {
        name: "description",
        content:
          "Compare vouchers generated in the portal against the entries actually posted in the accounting system through the ODBC feed.",
      },
      { property: "og:title", content: "GL posting verification | Invoice Workflow Portal" },
      {
        property: "og:description",
        content: "Line-by-line match of portal vouchers versus accounting system GL postings.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: GlVerification,
});

type PostingRow = {
  id?: string;
  voucher_no: string | null;
  entry_date: string | null;
  gl_code: string | null;
  vendor_code: string | null;
  dr_cr: string | null;
  amount: number;
  narration: string | null;
  accounting_ref: string | null;
};

const HEADER_MAP: Record<string, keyof PostingRow> = {
  voucher: "voucher_no",
  voucher_no: "voucher_no",
  voucherno: "voucher_no",
  jv: "voucher_no",
  date: "entry_date",
  entry_date: "entry_date",
  posting_date: "entry_date",
  gl: "gl_code",
  gl_code: "gl_code",
  account: "gl_code",
  vendor: "vendor_code",
  vendor_code: "vendor_code",
  dr_cr: "dr_cr",
  drcr: "dr_cr",
  type: "dr_cr",
  amount: "amount",
  value: "amount",
  narration: "narration",
  description: "narration",
  ref: "accounting_ref",
  reference: "accounting_ref",
  accounting_ref: "accounting_ref",
};

function splitLine(l: string) {
  return l.split(/[,;\t|]/).map((c) => c.trim().replace(/^"|"$/g, ""));
}

function parseFeed(text: string): PostingRow[] {
  const lines = text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);
  if (!lines.length) return [];

  const first = splitLine(lines[0]!).map((h) => h.toLowerCase().replace(/\s+/g, "_"));
  const hasHeader = first.some((h) => HEADER_MAP[h]);
  const cols: (keyof PostingRow | null)[] = hasHeader
    ? first.map((h) => HEADER_MAP[h] ?? null)
    : ["voucher_no", "entry_date", "gl_code", "dr_cr", "amount", "vendor_code", "narration"];

  return lines
    .slice(hasHeader ? 1 : 0)
    .map((l) => {
      const cells = splitLine(l);
      const row: PostingRow = {
        voucher_no: null,
        entry_date: null,
        gl_code: null,
        vendor_code: null,
        dr_cr: "DR",
        amount: 0,
        narration: null,
        accounting_ref: null,
      };
      cols.forEach((key, i) => {
        if (!key) return;
        const raw = cells[i] ?? "";
        if (key === "amount") {
          const n = Number(raw.replace(/[, ]/g, ""));
          row.amount = isNaN(n) ? 0 : n;
        } else if (key === "dr_cr") {
          row.dr_cr = raw.toUpperCase().startsWith("C") ? "CR" : "DR";
        } else {
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          (row as any)[key] = raw || null;
        }
      });
      return row;
    })
    .filter((r) => r.voucher_no || r.gl_code || r.amount);
}

type MatchState = "matched" | "amount_diff" | "gl_diff" | "not_posted" | "extra";

const STATE_META: Record<MatchState, { label: string; cls: string; icon: typeof CheckCircle2 }> = {
  matched: { label: "Matched", cls: "bg-success/15 text-success", icon: CheckCircle2 },
  amount_diff: { label: "Amount difference", cls: "bg-warning/25 text-warning-foreground", icon: AlertTriangle },
  gl_diff: { label: "GL / side mismatch", cls: "bg-destructive/15 text-destructive", icon: XCircle },
  not_posted: { label: "Not posted yet", cls: "bg-muted text-muted-foreground", icon: HelpCircle },
  extra: { label: "Extra in accounting", cls: "bg-info/15 text-info", icon: AlertTriangle },
};

const key = (glCode: string | null, drCr: string | null) => `${(glCode ?? "").trim()}|${(drCr ?? "").toUpperCase()}`;

function GlVerification() {
  const qc = useQueryClient();
  const { has } = useAuth();
  const canImport = has("finance_checker", "finance_approver", "finance_staff", "admin");
  const [raw, setRaw] = useState("");
  const [busy, setBusy] = useState(false);
  const [filter, setFilter] = useState<MatchState | "all">("all");
  const [expanded, setExpanded] = useState<string | null>(null);

  const { data: vouchers } = useQuery({
    queryKey: ["verify-vouchers"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("vouchers")
        .select("*, invoice_requests(request_no, currency, vendor_name_free_text, status)")
        .order("voucher_no")
        .order("line_no");
      if (error) throw error;
      return data;
    },
  });

  const { data: postings } = useQuery({
    queryKey: ["gl-postings"],
    queryFn: async () => {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const { data, error } = await (supabase as any)
        .from("gl_postings")
        .select("*")
        .order("imported_at", { ascending: false })
        .limit(5000);
      if (error) throw error;
      return (data ?? []) as (PostingRow & { id: string; imported_at: string })[];
    },
  });

  const preview = useMemo(() => parseFeed(raw), [raw]);

  const groups = useMemo(() => {
    const byVoucher = new Map<
      string,
      {
        voucherNo: string;
        invoiceId: string;
        requestNo: string | null;
        vendor: string | null;
        currency: string;
        portal: PostingRow[];
        actual: PostingRow[];
      }
    >();

    for (const v of vouchers ?? []) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const inv = (v as any).invoice_requests;
      const g = byVoucher.get(v.voucher_no) ?? {
        voucherNo: v.voucher_no,
        invoiceId: v.invoice_id,
        requestNo: inv?.request_no ?? null,
        vendor: inv?.vendor_name_free_text ?? null,
        currency: inv?.currency ?? "TZS",
        portal: [] as PostingRow[],
        actual: [] as PostingRow[],
      };
      g.portal.push({
        voucher_no: v.voucher_no,
        entry_date: v.created_at?.slice(0, 10) ?? null,
        gl_code: v.gl_code,
        vendor_code: v.vendor_code,
        dr_cr: v.dr_cr,
        amount: Number(v.amount),
        narration: v.narration,
        accounting_ref: null,
      });
      byVoucher.set(v.voucher_no, g);
    }

    const orphans: PostingRow[] = [];
    for (const p of postings ?? []) {
      const g = p.voucher_no ? byVoucher.get(p.voucher_no) : undefined;
      if (g) g.actual.push(p);
      else orphans.push(p);
    }

    const rows = Array.from(byVoucher.values()).map((g) => {
      const portalTotal = g.portal.filter((l) => l.dr_cr === "DR").reduce((s, l) => s + l.amount, 0);
      const actualTotal = g.actual.filter((l) => l.dr_cr === "DR").reduce((s, l) => s + l.amount, 0);
      const diff = actualTotal - portalTotal;

      const pMap = new Map<string, number>();
      g.portal.forEach((l) => pMap.set(key(l.gl_code, l.dr_cr), (pMap.get(key(l.gl_code, l.dr_cr)) ?? 0) + l.amount));
      const aMap = new Map<string, number>();
      g.actual.forEach((l) => aMap.set(key(l.gl_code, l.dr_cr), (aMap.get(key(l.gl_code, l.dr_cr)) ?? 0) + l.amount));

      let state: MatchState;
      if (!g.actual.length) state = "not_posted";
      else {
        const allKeys = new Set([...pMap.keys(), ...aMap.keys()]);
        const glMismatch = Array.from(allKeys).some((k) => !pMap.has(k) || !aMap.has(k));
        const amountMismatch = Array.from(allKeys).some(
          (k) => Math.abs((pMap.get(k) ?? 0) - (aMap.get(k) ?? 0)) > 0.01,
        );
        state = glMismatch ? "gl_diff" : amountMismatch ? "amount_diff" : "matched";
      }

      const detail = Array.from(new Set([...pMap.keys(), ...aMap.keys()])).map((k) => {
        const [gl, side] = k.split("|");
        return {
          k,
          gl: gl || "—",
          side: side || "",
          portal: pMap.get(k) ?? null,
          actual: aMap.get(k) ?? null,
        };
      });

      return { ...g, portalTotal, actualTotal, diff, state, detail };
    });

    return { rows, orphans };
  }, [vouchers, postings]);

  const counts = useMemo(() => {
    const c: Record<MatchState, number> = {
      matched: 0,
      amount_diff: 0,
      gl_diff: 0,
      not_posted: 0,
      extra: groups.orphans.length,
    };
    groups.rows.forEach((r) => (c[r.state] += 1));
    return c;
  }, [groups]);

  const visible = filter === "all" ? groups.rows : groups.rows.filter((r) => r.state === filter);

  const importRows = async () => {
    if (!preview.length) {
      toast.error("Nothing to import — paste or upload the accounting extract first.");
      return;
    }
    setBusy(true);
    const batchId = crypto.randomUUID();
    const { data: auth } = await supabase.auth.getUser();
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { error } = await (supabase as any).from("gl_postings").insert(
      preview.map((r) => ({
        source: "manual",
        batch_id: batchId,
        voucher_no: r.voucher_no,
        entry_date: r.entry_date || null,
        gl_code: r.gl_code,
        vendor_code: r.vendor_code,
        dr_cr: r.dr_cr,
        amount: r.amount,
        narration: r.narration,
        accounting_ref: r.accounting_ref,
        imported_by: auth.user?.id ?? null,
      })),
    );
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(`${preview.length} accounting entries imported`);
    setRaw("");
    qc.invalidateQueries({ queryKey: ["gl-postings"] });
  };

  const clearAll = async () => {
    setBusy(true);
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { error } = await (supabase as any).from("gl_postings").delete().not("id", "is", null);
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Imported accounting data cleared");
    qc.invalidateQueries({ queryKey: ["gl-postings"] });
  };

  const exportExceptions = () => {
    const rows = groups.rows.filter((r) => r.state !== "matched");
    const csv = [
      "voucher_no,request_no,status,portal_total,accounting_total,difference",
      ...rows.map((r) =>
        [r.voucherNo, r.requestNo ?? "", r.state, r.portalTotal, r.actualTotal, r.diff].join(","),
      ),
    ].join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = "gl-verification-exceptions.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <>
      <PageHeader
        title="GL posting verification"
        subtitle="Compare every voucher generated here against the entries actually posted in the accounting system (ODBC feed), so junior-staff posting errors are caught before month end."
        action={
          <Button variant="outline" onClick={exportExceptions}>
            Export exceptions
          </Button>
        }
      />

      <div className="mb-6 grid gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {(Object.keys(STATE_META) as MatchState[]).map((s) => {
          const Icon = STATE_META[s].icon;
          return (
            <button
              key={s}
              onClick={() => setFilter(filter === s ? "all" : s)}
              className={`panel flex items-center gap-3 p-4 text-left transition ${
                filter === s ? "ring-2 ring-primary" : ""
              }`}
            >
              <span className={`rounded-md p-2 ${STATE_META[s].cls}`}>
                <Icon className="h-4 w-4" />
              </span>
              <span>
                <span className="num block text-xl font-semibold">{counts[s]}</span>
                <span className="text-xs text-muted-foreground">{STATE_META[s].label}</span>
              </span>
            </button>
          );
        })}
      </div>

      {canImport && (
        <div className="panel mb-6 space-y-3 p-6">
          <Label>Accounting system extract (ODBC export)</Label>
          <p className="text-xs text-muted-foreground">
            Columns: voucher_no, date, gl_code, dr_cr, amount, vendor_code, narration. A header row is detected
            automatically. The ODBC bridge can also push directly to{" "}
            <code className="num">POST /api/public/accounting-sync</code> with the header{" "}
            <code className="num">x-sync-key</code>.
          </p>
          <Textarea
            rows={5}
            placeholder={"voucher_no,date,gl_code,dr_cr,amount\nJV-202601-0001,2026-01-18,5100,DR,1500000\nJV-202601-0001,2026-01-18,2100,CR,1500000"}
            value={raw}
            onChange={(e) => setRaw(e.target.value)}
          />
          <div className="flex flex-wrap items-center gap-3">
            <Input
              type="file"
              accept=".csv,text/csv,text/plain"
              className="max-w-xs"
              onChange={async (e) => {
                const f = e.target.files?.[0];
                if (f) setRaw(await f.text());
              }}
            />
            <span className="text-xs text-muted-foreground">{preview.length} rows ready</span>
            <Button onClick={importRows} disabled={busy || !preview.length}>
              <Upload className="mr-2 h-4 w-4" /> Import entries
            </Button>
            <Button variant="outline" onClick={clearAll} disabled={busy}>
              <Trash2 className="mr-2 h-4 w-4" /> Clear imported data
            </Button>
            <span className="text-xs text-muted-foreground">{(postings ?? []).length} entries currently loaded</span>
          </div>
        </div>
      )}

      <div className="panel mb-6 overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="border-b bg-muted/50 text-left text-xs text-muted-foreground">
            <tr>
              <th className="px-4 py-3 font-medium">Voucher / Request</th>
              <th className="px-4 py-3 font-medium">Vendor</th>
              <th className="px-4 py-3 text-right font-medium">Portal (Dr)</th>
              <th className="px-4 py-3 text-right font-medium">Accounting (Dr)</th>
              <th className="px-4 py-3 text-right font-medium">Difference</th>
              <th className="px-4 py-3 font-medium">Result</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {visible.length === 0 && (
              <tr>
                <td colSpan={6} className="px-4 py-10 text-center text-muted-foreground">
                  No vouchers in this view. Generate vouchers and import the accounting extract to compare.
                </td>
              </tr>
            )}
            {visible.map((r) => {
              const meta = STATE_META[r.state];
              const open = expanded === r.voucherNo;
              return (
                <>
                  <tr
                    key={r.voucherNo}
                    className="cursor-pointer hover:bg-muted/40"
                    onClick={() => setExpanded(open ? null : r.voucherNo)}
                  >
                    <td className="px-4 py-3">
                      <div className="num font-medium">{r.voucherNo}</div>
                      <Link
                        to="/requests/$id"
                        params={{ id: r.invoiceId }}
                        className="num text-xs text-primary hover:underline"
                        onClick={(e) => e.stopPropagation()}
                      >
                        {r.requestNo ?? "view request"}
                      </Link>
                    </td>
                    <td className="px-4 py-3">{r.vendor ?? "—"}</td>
                    <td className="num px-4 py-3 text-right">{money(r.portalTotal, r.currency)}</td>
                    <td className="num px-4 py-3 text-right">
                      {r.actual.length ? money(r.actualTotal, r.currency) : "—"}
                    </td>
                    <td
                      className={`num px-4 py-3 text-right ${
                        Math.abs(r.diff) > 0.01 && r.actual.length ? "text-destructive" : ""
                      }`}
                    >
                      {r.actual.length ? money(r.diff, r.currency) : "—"}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`rounded-full px-2 py-1 text-xs font-medium ${meta.cls}`}>{meta.label}</span>
                    </td>
                  </tr>
                  {open && (
                    <tr key={`${r.voucherNo}-detail`} className="bg-muted/20">
                      <td colSpan={6} className="px-4 py-4">
                        <table className="w-full text-xs">
                          <thead className="text-muted-foreground">
                            <tr>
                              <th className="py-1 text-left font-medium">GL account</th>
                              <th className="py-1 text-left font-medium">Side</th>
                              <th className="py-1 text-right font-medium">Portal</th>
                              <th className="py-1 text-right font-medium">Accounting</th>
                              <th className="py-1 text-right font-medium">Difference</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y">
                            {r.detail.map((d) => {
                              const diff = (d.actual ?? 0) - (d.portal ?? 0);
                              return (
                                <tr key={d.k}>
                                  <td className="num py-1">{d.gl}</td>
                                  <td className="py-1">{d.side}</td>
                                  <td className="num py-1 text-right">
                                    {d.portal == null ? "— not in portal" : money(d.portal, r.currency)}
                                  </td>
                                  <td className="num py-1 text-right">
                                    {d.actual == null ? "— not posted" : money(d.actual, r.currency)}
                                  </td>
                                  <td
                                    className={`num py-1 text-right ${Math.abs(diff) > 0.01 ? "text-destructive" : ""}`}
                                  >
                                    {money(diff, r.currency)}
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </td>
                    </tr>
                  )}
                </>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="panel p-6">
        <h2 className="mb-3 text-sm font-semibold">
          Entries in accounting with no matching portal voucher ({groups.orphans.length})
        </h2>
        {groups.orphans.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            Every imported accounting entry belongs to a voucher generated in this portal.
          </p>
        ) : (
          <ul className="space-y-2 text-sm">
            {groups.orphans.slice(0, 100).map((o, i) => (
              <li key={o.id ?? i} className="flex flex-wrap justify-between gap-2 border-b pb-2 last:border-0">
                <span className="num">{o.voucher_no ?? "no voucher ref"}</span>
                <span className="num text-muted-foreground">{o.gl_code ?? "—"}</span>
                <span className="text-xs text-muted-foreground">{o.dr_cr}</span>
                <span className="num">{money(o.amount)}</span>
                <span className="text-xs text-muted-foreground">{fmtDate(o.entry_date)}</span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </>
  );
}

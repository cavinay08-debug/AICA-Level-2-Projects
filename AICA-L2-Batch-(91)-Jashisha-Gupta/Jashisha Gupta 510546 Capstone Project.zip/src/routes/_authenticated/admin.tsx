import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { PageHeader } from "@/components/AppLayout";
import { supabase } from "@/integrations/supabase/client";
import {
  useBusinessUnits,
  useCostCenters,
  useDepartments,
  useGlAccounts,
  useProfiles,
  useVendors,
  useWhtRates,
} from "@/lib/queries";
import type { AppRole } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Administration | Invoice Workflow Portal" },
      { name: "description", content: "Manage users, roles, departments, vendors, GL accounts, cost centers and WHT rates." },
      { property: "og:title", content: "Administration | Invoice Workflow Portal" },
      { property: "og:description", content: "Master data and role administration for the invoice portal." },
    ],
  }),
  component: Admin,
});

const ROLES: AppRole[] = ["requester", "hod", "finance_checker", "finance_approver", "finance_staff", "admin"];

function Admin() {
  return (
    <>
      <PageHeader title="Administration" subtitle="Roles and master data that drive the workflow and the accounting entries." />
      <Tabs defaultValue="users">
        <TabsList className="mb-5 flex-wrap">
          <TabsTrigger value="users">Users & roles</TabsTrigger>
          <TabsTrigger value="departments">Departments</TabsTrigger>
          <TabsTrigger value="vendors">Vendors</TabsTrigger>
          <TabsTrigger value="gl">GL accounts</TabsTrigger>
          <TabsTrigger value="cc">Cost centers</TabsTrigger>
          <TabsTrigger value="bu">Business units</TabsTrigger>
          <TabsTrigger value="wht">WHT rates</TabsTrigger>
        </TabsList>
        <TabsContent value="users">
          <Users />
        </TabsContent>
        <TabsContent value="departments">
          <Departments />
        </TabsContent>
        <TabsContent value="vendors">
          <Vendors />
        </TabsContent>
        <TabsContent value="gl">
          <GlAccounts />
        </TabsContent>
        <TabsContent value="cc">
          <CostCenters />
        </TabsContent>
        <TabsContent value="bu">
          <BusinessUnits />
        </TabsContent>
        <TabsContent value="wht">
          <Wht />
        </TabsContent>
      </Tabs>
    </>
  );
}

function useRoles() {
  return useQuery({
    queryKey: ["user_roles"],
    queryFn: async () => {
      const { data, error } = await supabase.from("user_roles").select("*");
      if (error) throw error;
      return data;
    },
  });
}

function Users() {
  const qc = useQueryClient();
  const { data: profiles } = useProfiles();
  const { data: roles } = useRoles();
  const { data: departments } = useDepartments();

  const toggle = async (userId: string, role: AppRole, on: boolean) => {
    const { error } = on
      ? await supabase.from("user_roles").insert({ user_id: userId, role })
      : await supabase.from("user_roles").delete().eq("user_id", userId).eq("role", role);
    if (error) { toast.error(error.message); return; }
    toast.success("Roles updated");
    qc.invalidateQueries({ queryKey: ["user_roles"] });
  };

  const setDept = async (userId: string, departmentId: string) => {
    const { error } = await supabase.from("profiles").update({ department_id: departmentId }).eq("id", userId);
    if (error) { toast.error(error.message); return; }
    toast.success("Department updated");
    qc.invalidateQueries({ queryKey: ["profiles"] });
  };

  return (
    <div className="panel overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="border-b bg-muted/50 text-left text-xs text-muted-foreground">
          <tr>
            <th className="px-4 py-3 font-medium">User</th>
            <th className="px-4 py-3 font-medium">Department</th>
            <th className="px-4 py-3 font-medium">Roles</th>
          </tr>
        </thead>
        <tbody className="divide-y">
          {(profiles ?? []).map((p) => (
            <tr key={p.id}>
              <td className="px-4 py-3">
                <div className="font-medium">{p.full_name || "—"}</div>
                <div className="text-xs text-muted-foreground">{p.email}</div>
              </td>
              <td className="px-4 py-3">
                <Select value={p.department_id ?? ""} onValueChange={(v) => setDept(p.id, v)}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Unassigned" />
                  </SelectTrigger>
                  <SelectContent>
                    {(departments ?? []).map((d) => (
                      <SelectItem key={d.id} value={d.id}>
                        {d.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </td>
              <td className="px-4 py-3">
                <div className="flex flex-wrap gap-1.5">
                  {ROLES.map((r) => {
                    const on = (roles ?? []).some((x) => x.user_id === p.id && x.role === r);
                    return (
                      <button
                        key={r}
                        onClick={() => toggle(p.id, r, !on)}
                        className={`rounded-full px-2.5 py-1 text-xs transition-colors ${
                          on ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-muted/70"
                        }`}
                      >
                        {r.replace(/_/g, " ")}
                      </button>
                    );
                  })}
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Departments() {
  const qc = useQueryClient();
  const { data } = useDepartments();
  const [name, setName] = useState("");
  const [code, setCode] = useState("");

  const add = async () => {
    if (!name || !code) { toast.error("Code and name are required"); return; }
    const { error } = await supabase.from("departments").insert({ name, code });
    if (error) { toast.error(error.message); return; }
    setName("");
    setCode("");
    qc.invalidateQueries({ queryKey: ["departments"] });
  };

  return (
    <div className="grid gap-6 lg:grid-cols-3">
      <div className="panel p-6 lg:col-span-2">
        <table className="w-full text-sm">
          <thead className="text-left text-xs text-muted-foreground">
            <tr>
              <th className="pb-2">Code</th>
              <th className="pb-2">Name</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {(data ?? []).map((d) => (
              <tr key={d.id}>
                <td className="num py-2">{d.code}</td>
                <td className="py-2">{d.name}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="panel space-y-3 p-6">
        <h2 className="text-sm font-semibold">Add department</h2>
        <div className="space-y-2">
          <Label>Code</Label>
          <Input value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} />
        </div>
        <div className="space-y-2">
          <Label>Name</Label>
          <Input value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <Button className="w-full" onClick={add}>
          Add
        </Button>
      </div>
    </div>
  );
}

function Vendors() {
  const qc = useQueryClient();
  const { data } = useVendors();
  const { data: whts } = useWhtRates();
  const [f, setF] = useState({ vendor_code: "", vendor_name: "", tin: "", wht_category: "" });

  const add = async () => {
    if (!f.vendor_code || !f.vendor_name) { toast.error("Vendor code and name are required"); return; }
    const { error } = await supabase.from("vendors").insert({
      vendor_code: f.vendor_code,
      vendor_name: f.vendor_name,
      tax_id: f.tin || null,
      wht_category: f.wht_category || null,
      wht_applicable: !!f.wht_category,
    });
    if (error) { toast.error(error.message); return; }
    setF({ vendor_code: "", vendor_name: "", tin: "", wht_category: "" });
    qc.invalidateQueries({ queryKey: ["vendors"] });
  };

  const categories = Array.from(new Set((whts ?? []).map((w) => w.wht_category)));

  return (
    <div className="grid gap-6 lg:grid-cols-3">
      <div className="panel overflow-x-auto p-6 lg:col-span-2">
        <table className="w-full text-sm">
          <thead className="text-left text-xs text-muted-foreground">
            <tr>
              <th className="pb-2">Code</th>
              <th className="pb-2">Name</th>
              <th className="pb-2">TIN</th>
              <th className="pb-2">WHT category</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {(data ?? []).map((v) => (
              <tr key={v.vendor_code}>
                <td className="num py-2">{v.vendor_code}</td>
                <td className="py-2">{v.vendor_name}</td>
                <td className="num py-2">{v.tax_id ?? "—"}</td>
                <td className="py-2">{v.wht_category ?? "Not applicable"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="panel space-y-3 p-6">
        <h2 className="text-sm font-semibold">Add vendor</h2>
        <div className="space-y-2">
          <Label>Vendor code</Label>
          <Input value={f.vendor_code} onChange={(e) => setF({ ...f, vendor_code: e.target.value.toUpperCase() })} />
        </div>
        <div className="space-y-2">
          <Label>Vendor name</Label>
          <Input value={f.vendor_name} onChange={(e) => setF({ ...f, vendor_name: e.target.value })} />
        </div>
        <div className="space-y-2">
          <Label>TIN</Label>
          <Input value={f.tin} onChange={(e) => setF({ ...f, tin: e.target.value })} />
        </div>
        <div className="space-y-2">
          <Label>WHT category</Label>
          <Select value={f.wht_category} onValueChange={(v) => setF({ ...f, wht_category: v })}>
            <SelectTrigger>
              <SelectValue placeholder="None" />
            </SelectTrigger>
            <SelectContent>
              {categories.map((c) => (
                <SelectItem key={c} value={c}>
                  {c}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <Button className="w-full" onClick={add}>
          Add
        </Button>
      </div>
    </div>
  );
}

function GlAccounts() {
  const qc = useQueryClient();
  const { data } = useGlAccounts();
  const [f, setF] = useState<{
    gl_code: string;
    gl_name: string;
    external_code: string;
    type: "expense" | "capex" | "vendor_ap" | "wht_payable";
  }>({
    gl_code: "",
    gl_name: "",
    external_code: "",
    type: "expense",
  });

  const add = async () => {
    if (!f.gl_code || !f.gl_name) { toast.error("GL code and name are required"); return; }
    const { error } = await supabase
      .from("gl_accounts")
      .insert({ ...f, external_code: f.external_code || null });
    if (error) { toast.error(error.message); return; }
    setF({ gl_code: "", gl_name: "", external_code: "", type: "expense" });
    qc.invalidateQueries({ queryKey: ["gl_accounts"] });
  };

  return (
    <div className="grid gap-6 lg:grid-cols-3">
      <div className="panel p-6 lg:col-span-2">
        <table className="w-full text-sm">
          <thead className="text-left text-xs text-muted-foreground">
            <tr>
              <th className="pb-2">GL code</th>
              <th className="pb-2">Name</th>
              <th className="pb-2">Type</th>
              <th className="pb-2">External code</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {(data ?? []).map((g) => (
              <tr key={g.gl_code}>
                <td className="num py-2">{g.gl_code}</td>
                <td className="py-2">{g.gl_name}</td>
                <td className="py-2 capitalize">{g.type.replace(/_/g, " ")}</td>
                <td className="num py-2">{g.external_code ?? "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="panel space-y-3 p-6">
        <h2 className="text-sm font-semibold">Add GL account</h2>
        <div className="space-y-2">
          <Label>GL code</Label>
          <Input value={f.gl_code} onChange={(e) => setF({ ...f, gl_code: e.target.value })} />
        </div>
        <div className="space-y-2">
          <Label>Name</Label>
          <Input value={f.gl_name} onChange={(e) => setF({ ...f, gl_name: e.target.value })} />
        </div>
        <div className="space-y-2">
          <Label>External / accounting system code</Label>
          <Input
            placeholder="Optional — used when linking to the accounting system"
            value={f.external_code}
            onChange={(e) => setF({ ...f, external_code: e.target.value })}
          />
        </div>
        <div className="space-y-2">
          <Label>Type</Label>
          <Select value={f.type} onValueChange={(v) => setF({ ...f, type: v as typeof f.type })}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="expense">Expense</SelectItem>
              <SelectItem value="capex">Capex</SelectItem>
              <SelectItem value="vendor_ap">Vendor payable</SelectItem>
              <SelectItem value="wht_payable">WHT payable</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button className="w-full" onClick={add}>
          Add
        </Button>
      </div>
    </div>
  );
}

function CostCenters() {
  const qc = useQueryClient();
  const { data } = useCostCenters();
  const { data: departments } = useDepartments();
  const { data: bus } = useBusinessUnits();
  const [f, setF] = useState({ code: "", name: "", department_id: "", business_unit_id: "", external_code: "" });

  const add = async () => {
    if (!f.code || !f.name) { toast.error("Code and name are required"); return; }
    const { error } = await supabase
      .from("cost_centers")
      .insert({
        code: f.code,
        name: f.name,
        department_id: f.department_id || null,
        business_unit_id: f.business_unit_id || null,
        external_code: f.external_code || null,
      });
    if (error) { toast.error(error.message); return; }
    setF({ code: "", name: "", department_id: "", business_unit_id: "", external_code: "" });
    qc.invalidateQueries({ queryKey: ["cost_centers"] });
  };

  return (
    <div className="grid gap-6 lg:grid-cols-3">
      <div className="panel p-6 lg:col-span-2">
        <table className="w-full text-sm">
          <thead className="text-left text-xs text-muted-foreground">
            <tr>
              <th className="pb-2">Code</th>
              <th className="pb-2">Name</th>
              <th className="pb-2">Department</th>
              <th className="pb-2">Business unit</th>
              <th className="pb-2">External code</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {(data ?? []).map((c) => (
              <tr key={c.id}>
                <td className="num py-2">{c.code}</td>
                <td className="py-2">{c.name}</td>
                <td className="py-2">
                  {(departments ?? []).find((d) => d.id === c.department_id)?.name ?? "—"}
                </td>
                <td className="py-2">{(bus ?? []).find((b) => b.id === c.business_unit_id)?.name ?? "—"}</td>
                <td className="num py-2">{c.external_code ?? "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="panel space-y-3 p-6">
        <h2 className="text-sm font-semibold">Add cost center</h2>
        <div className="space-y-2">
          <Label>Code</Label>
          <Input value={f.code} onChange={(e) => setF({ ...f, code: e.target.value.toUpperCase() })} />
        </div>
        <div className="space-y-2">
          <Label>Name</Label>
          <Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
        </div>
        <div className="space-y-2">
          <Label>Department</Label>
          <Select value={f.department_id} onValueChange={(v) => setF({ ...f, department_id: v })}>
            <SelectTrigger>
              <SelectValue placeholder="Optional" />
            </SelectTrigger>
            <SelectContent>
              {(departments ?? []).map((d) => (
                <SelectItem key={d.id} value={d.id}>
                  {d.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>Business unit</Label>
          <Select value={f.business_unit_id} onValueChange={(v) => setF({ ...f, business_unit_id: v })}>
            <SelectTrigger>
              <SelectValue placeholder="Optional" />
            </SelectTrigger>
            <SelectContent>
              {(bus ?? []).map((b) => (
                <SelectItem key={b.id} value={b.id}>
                  {b.code} — {b.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>External code</Label>
          <Input value={f.external_code} onChange={(e) => setF({ ...f, external_code: e.target.value })} />
        </div>
        <Button className="w-full" onClick={add}>
          Add
        </Button>
      </div>
    </div>
  );
}

function BusinessUnits() {
  const qc = useQueryClient();
  const { data } = useBusinessUnits();
  const [f, setF] = useState({ code: "", name: "", external_code: "" });

  const add = async () => {
    if (!f.code || !f.name) { toast.error("Code and name are required"); return; }
    const { error } = await supabase
      .from("business_units")
      .insert({ code: f.code, name: f.name, external_code: f.external_code || null });
    if (error) { toast.error(error.message); return; }
    setF({ code: "", name: "", external_code: "" });
    qc.invalidateQueries({ queryKey: ["business_units"] });
  };

  return (
    <div className="grid gap-6 lg:grid-cols-3">
      <div className="panel p-6 lg:col-span-2">
        <table className="w-full text-sm">
          <thead className="text-left text-xs text-muted-foreground">
            <tr>
              <th className="pb-2">Code</th>
              <th className="pb-2">Name</th>
              <th className="pb-2">External code</th>
              <th className="pb-2">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {(data ?? []).map((b) => (
              <tr key={b.id}>
                <td className="num py-2">{b.code}</td>
                <td className="py-2">{b.name}</td>
                <td className="num py-2">{b.external_code ?? "—"}</td>
                <td className="py-2">{b.active ? "Active" : "Inactive"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="panel space-y-3 p-6">
        <h2 className="text-sm font-semibold">Add business unit</h2>
        <div className="space-y-2">
          <Label>Code</Label>
          <Input value={f.code} onChange={(e) => setF({ ...f, code: e.target.value.toUpperCase() })} />
        </div>
        <div className="space-y-2">
          <Label>Name</Label>
          <Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
        </div>
        <div className="space-y-2">
          <Label>External / accounting system code</Label>
          <Input value={f.external_code} onChange={(e) => setF({ ...f, external_code: e.target.value })} />
        </div>
        <Button className="w-full" onClick={add}>
          Add
        </Button>
      </div>
    </div>
  );
}

function Wht() {
  const qc = useQueryClient();
  const { data } = useWhtRates();
  const [f, setF] = useState({ wht_category: "", rate_percent: "", effective_from: new Date().toISOString().slice(0, 10) });

  const add = async () => {
    if (!f.wht_category || !f.rate_percent) { toast.error("Category and rate are required"); return; }
    const { error } = await supabase.from("wht_rates").insert({
      wht_category: f.wht_category,
      rate_percent: Number(f.rate_percent),
      effective_from: f.effective_from,
    });
    if (error) { toast.error(error.message); return; }
    setF({ wht_category: "", rate_percent: "", effective_from: new Date().toISOString().slice(0, 10) });
    qc.invalidateQueries({ queryKey: ["wht_rates"] });
  };

  return (
    <div className="grid gap-6 lg:grid-cols-3">
      <div className="panel p-6 lg:col-span-2">
        <table className="w-full text-sm">
          <thead className="text-left text-xs text-muted-foreground">
            <tr>
              <th className="pb-2">Category</th>
              <th className="pb-2 text-right">Rate %</th>
              <th className="pb-2">Effective from</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {(data ?? []).map((w) => (
              <tr key={w.id}>
                <td className="py-2">{w.wht_category}</td>
                <td className="num py-2 text-right">{w.rate_percent}</td>
                <td className="num py-2">{w.effective_from}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="panel space-y-3 p-6">
        <h2 className="text-sm font-semibold">Add WHT rate</h2>
        <div className="space-y-2">
          <Label>Category</Label>
          <Input value={f.wht_category} onChange={(e) => setF({ ...f, wht_category: e.target.value })} />
        </div>
        <div className="space-y-2">
          <Label>Rate %</Label>
          <Input type="number" step="0.001" value={f.rate_percent} onChange={(e) => setF({ ...f, rate_percent: e.target.value })} />
        </div>
        <div className="space-y-2">
          <Label>Effective from</Label>
          <Input type="date" value={f.effective_from} onChange={(e) => setF({ ...f, effective_from: e.target.value })} />
        </div>
        <Button className="w-full" onClick={add}>
          Add
        </Button>
      </div>
    </div>
  );
}

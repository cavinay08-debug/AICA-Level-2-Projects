import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageHeader } from "@/components/AppLayout";
import { StatusBadge } from "@/components/StatusBadge";
import { useDepartments, useInvoices } from "@/lib/queries";
import { daysSince, fmtDate, money, REFERENCE_LABEL, STATUS_LABEL, type InvoiceStatus } from "@/lib/workflow";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export const Route = createFileRoute("/_authenticated/requests/")({
  head: () => ({
    meta: [
      { title: "Invoice requests | Invoice Workflow Portal" },
      { name: "description", content: "Search and filter invoice requests by status, department, vendor and reference type." },
      { property: "og:title", content: "Invoice requests | Invoice Workflow Portal" },
      { property: "og:description", content: "Full visibility of every invoice in the approval chain." },
    ],
  }),
  component: RequestsList,
});

function RequestsList() {
  const { data, isLoading } = useInvoices();
  const { data: departments } = useDepartments();
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("all");
  const [dept, setDept] = useState("all");
  const [ref, setRef] = useState("all");

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const rows = (data ?? []) as any[];

  const filtered = useMemo(
    () =>
      rows.filter((r) => {
        if (status !== "all" && r.status !== status) return false;
        if (dept !== "all" && r.department_id !== dept) return false;
        if (ref !== "all" && r.reference_type !== ref) return false;
        if (q) {
          const hay = `${r.request_no ?? ""} ${r.invoice_no} ${r.vendor_name_free_text} ${r.vendor_code ?? ""} ${r.reference_number ?? ""}`.toLowerCase();
          if (!hay.includes(q.toLowerCase())) return false;
        }
        return true;
      }),
    [rows, q, status, dept, ref],
  );

  return (
    <>
      <PageHeader
        title="Invoice requests"
        subtitle="Everything you are allowed to see, with live stage and ageing."
        action={
          <Button asChild>
            <Link to="/requests/new">New request</Link>
          </Button>
        }
      />

      <div className="panel mb-5 grid gap-3 p-4 md:grid-cols-4">
        <Input placeholder="Search request, invoice, vendor…" value={q} onChange={(e) => setQ(e.target.value)} />
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger>
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            {Object.entries(STATUS_LABEL).map(([k, v]) => (
              <SelectItem key={k} value={k}>
                {v}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={dept} onValueChange={setDept}>
          <SelectTrigger>
            <SelectValue placeholder="Department" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All departments</SelectItem>
            {(departments ?? []).map((d) => (
              <SelectItem key={d.id} value={d.id}>
                {d.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={ref} onValueChange={setRef}>
          <SelectTrigger>
            <SelectValue placeholder="Reference type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All reference types</SelectItem>
            <SelectItem value="lpo">Against LPO</SelectItem>
            <SelectItem value="agreement">Against Agreement</SelectItem>
            <SelectItem value="direct">Direct (no LPO)</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="panel overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="border-b bg-muted/50 text-left text-xs text-muted-foreground">
            <tr>
              <th className="px-4 py-3 font-medium">Request</th>
              <th className="px-4 py-3 font-medium">Vendor</th>
              <th className="px-4 py-3 font-medium">Department</th>
              <th className="px-4 py-3 font-medium">Reference</th>
              <th className="px-4 py-3 text-right font-medium">Amount</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 text-right font-medium">Age</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {isLoading && (
              <tr>
                <td colSpan={7} className="px-4 py-10 text-center text-muted-foreground">
                  Loading…
                </td>
              </tr>
            )}
            {!isLoading && filtered.length === 0 && (
              <tr>
                <td colSpan={7} className="px-4 py-10 text-center text-muted-foreground">
                  No requests match these filters.
                </td>
              </tr>
            )}
            {filtered.map((r) => (
              <tr key={r.id} className="transition-colors hover:bg-muted/40">
                <td className="px-4 py-3">
                  <Link to="/requests/$id" params={{ id: r.id }} className="num font-medium text-primary hover:underline">
                    {r.request_no ?? "DRAFT"}
                  </Link>
                  <div className="text-xs text-muted-foreground">
                    Inv {r.invoice_no} • {fmtDate(r.invoice_date)}
                  </div>
                </td>
                <td className="px-4 py-3">
                  {r.vendor_name_free_text}
                  {r.vendor_code && <span className="num ml-1 text-xs text-muted-foreground">({r.vendor_code})</span>}
                </td>
                <td className="px-4 py-3">{r.departments?.name ?? "—"}</td>
                <td className="px-4 py-3 text-xs">
                  {REFERENCE_LABEL[r.reference_type]}
                  {r.reference_number ? <div className="num text-muted-foreground">{r.reference_number}</div> : null}
                </td>
                <td className="num px-4 py-3 text-right">{money(r.amount, r.currency)}</td>
                <td className="px-4 py-3">
                  <StatusBadge status={r.status as InvoiceStatus} />
                </td>
                <td className="num px-4 py-3 text-right text-muted-foreground">{daysSince(r.updated_at)}d</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { PageHeader } from "@/components/AppLayout";
import { StatusBadge } from "@/components/StatusBadge";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useCostCenters, useGlAccounts, useInvoice, useVendors, useWhtRates } from "@/lib/queries";
import { QrCode } from "lucide-react";
import { GlAllocationGrid } from "@/components/GlAllocationGrid";
import { printVoucher, qrReferenceCode } from "@/lib/sheets";
import { RequestQrTicket } from "@/components/RequestQrTicket";
import { EfdQrScanner } from "@/components/EfdQrScanner";
import { ATTACHMENT_CATEGORIES, categoryLabel } from "@/lib/attachments";
import {
  fmtDate,
  fmtDateTime,
  money,
  REFERENCE_LABEL,
  STATUS_LABEL,
  type InvoiceStatus,
} from "@/lib/workflow";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export const Route = createFileRoute("/_authenticated/requests/$id")({
  head: () => ({
    meta: [
      { title: "Invoice request | Invoice Workflow Portal" },
      { name: "description", content: "Review an invoice request, its approval trail, GL allocation and generated voucher." },
      { property: "og:title", content: "Invoice request | Invoice Workflow Portal" },
      { property: "og:description", content: "Approve, check, allocate and reconcile a single invoice request." },
    ],
  }),
  component: RequestDetail,
});

type Line = { id?: string; gl_code: string; cost_center_id: string; amount: string; narration: string };

function RequestDetail() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { user, profile, has } = useAuth();
  const { data: inv, isLoading } = useInvoice(id);
  const { data: vendors } = useVendors();
  const { data: gls } = useGlAccounts();
  const { data: ccs } = useCostCenters();
  const { data: whtRates } = useWhtRates();
  const [busy, setBusy] = useState(false);

  const { data: approvals } = useQuery({
    queryKey: ["approvals", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("approvals")
        .select("*")
        .eq("invoice_id", id)
        .order("created_at");
      if (error) throw error;
      return data;
    },
  });

  const { data: attachments } = useQuery({
    queryKey: ["attachments", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("attachments")
        .select("*")
        .eq("invoice_id", id)
        .order("uploaded_at");
      if (error) throw error;
      return data;
    },
  });

  const { data: dbLines } = useQuery({
    queryKey: ["invoice_lines", id],
    queryFn: async () => {
      const { data, error } = await supabase.from("invoice_lines").select("*").eq("invoice_id", id);
      if (error) throw error;
      return data;
    },
  });

  const { data: voucherRows } = useQuery({
    queryKey: ["voucher", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("vouchers")
        .select("*")
        .eq("invoice_id", id)
        .order("line_no");
      if (error) throw error;
      return data;
    },
  });

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ["invoice", id] });
    qc.invalidateQueries({ queryKey: ["approvals", id] });
    qc.invalidateQueries({ queryKey: ["invoice_lines", id] });
    qc.invalidateQueries({ queryKey: ["voucher", id] });
    qc.invalidateQueries({ queryKey: ["attachments", id] });
    qc.invalidateQueries({ queryKey: ["invoices"] });
  };

  // ---- finance checker working state ----
  const [vendorCode, setVendorCode] = useState("");
  const [whtOn, setWhtOn] = useState(false);
  const [whtRate, setWhtRate] = useState("0");
  const [whtGl, setWhtGl] = useState("");
  const [override, setOverride] = useState("");
  
  const [lines, setLines] = useState<Line[]>([]);
  const [comment, setComment] = useState("");
  const [field, setField] = useState("gl_code");
  const [receiveOpen, setReceiveOpen] = useState(false);
  const [showAllGl, setShowAllGl] = useState(false);
  const [expenseType, setExpenseType] = useState<"expense" | "capex">("expense");
  const [receiptNotes, setReceiptNotes] = useState("");

  useEffect(() => {
    if (!inv) return;
    setVendorCode(inv.vendor_code ?? "");
    setWhtOn(inv.wht_applicable);
    setWhtRate(String(inv.wht_rate ?? 0));
    setWhtGl(inv.wht_gl_code ?? "");
    setOverride(inv.wht_override_reason ?? "");
    setExpenseType(inv.expense_type as "expense" | "capex");
  }, [inv]);

  useEffect(() => {
    if (!dbLines) return;
    setLines(
      dbLines.length
        ? dbLines.map((l) => ({
            id: l.id,
            gl_code: l.gl_code ?? "",
            cost_center_id: l.cost_center_id ?? "",
            amount: String(l.amount),
            narration: l.narration ?? "",
          }))
        : [
            {
              gl_code: "",
              cost_center_id: (inv?.cost_center_id as string) ?? "",
              amount: String(inv?.amount ?? ""),
              narration: "",
            },
          ],
    );
  }, [dbLines, inv]);

  const vendor = useMemo(
    () => (vendors ?? []).find((v) => v.vendor_code === vendorCode),
    [vendors, vendorCode],
  );

  useEffect(() => {
    if (!vendor || !whtRates) return;
    if (vendor.wht_applicable && vendor.wht_category) {
      const rate = whtRates.find((r) => r.wht_category === vendor.wht_category);
      if (rate) {
        setWhtOn(true);
        setWhtRate(String(rate.rate_percent));
        
      }
    }
  }, [vendor, whtRates]);

  if (isLoading) return <div className="p-8 text-muted-foreground">Loading request…</div>;
  if (!inv) return <div className="p-8 text-muted-foreground">Request not found or not visible to you.</div>;

  const status = inv.status as InvoiceStatus;
  const isOwner = inv.requester_id === user?.id;
  const isHod = has("hod") && profile?.department_id === inv.department_id;
  const isChecker = has("finance_checker");
  const isApprover = has("finance_approver");
  const isFinanceStaff = has("finance_staff") || has("admin");
  const glOptions = (gls ?? []).filter(
    (g) => showAllGl || g.type === expenseType,
  );
  const whtAmount = whtOn ? (Number(inv.amount) * Number(whtRate || 0)) / 100 : 0;
  const suggestedRate = vendor?.wht_category
    ? Number((whtRates ?? []).find((r) => r.wht_category === vendor.wht_category)?.rate_percent ?? 0)
    : 0;

  const glName = (code: string | null | undefined) =>
    (gls ?? []).find((g) => g.gl_code === code)?.gl_name ?? "";
  const ccName = (cid: string | null | undefined) =>
    (ccs ?? []).find((c) => c.id === cid)?.name ?? "—";
  const postedWht = Number(inv.wht_applicable ? inv.wht_amount : 0);
  const previewRows: { code: string; name: string; cc: string; dr: number; cr: number }[] = [
    ...(dbLines ?? []).map((l) => ({
      code: l.gl_code ?? "—",
      name: glName(l.gl_code),
      cc: ccName(l.cost_center_id),
      dr: Number(l.amount),
      cr: 0,
    })),
    {
      code: inv.vendor_code ?? "VENDOR",
      name: `Vendor payable — ${inv.vendor_name_free_text}`,
      cc: "—",
      dr: 0,
      cr: (dbLines ?? []).reduce((s, l) => s + Number(l.amount), 0) - postedWht,
    },
    ...(postedWht > 0
      ? [
          {
            code: inv.wht_gl_code ?? "WHT",
            name: glName(inv.wht_gl_code) || "Withholding tax payable",
            cc: "—",
            dr: 0,
            cr: postedWht,
          },
        ]
      : []),
  ];
  const previewBalanced =
    Math.abs(
      previewRows.reduce((s, r) => s + r.dr, 0) - previewRows.reduce((s, r) => s + r.cr, 0),
    ) < 0.01;

  const call = async (fn: string, args: Record<string, unknown>, ok: string) => {
    setBusy(true);
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { error } = await (supabase.rpc as any)(fn, args);
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return false;
    }
    toast.success(ok);
    refresh();
    return true;
  };

  const saveCheck = async () =>
    call(
      "finance_check_save",
      {
        p_id: id,
        p_vendor_code: vendorCode || null,
        p_wht_applicable: whtOn,
        p_wht_rate: Number(whtRate || 0),
        p_wht_amount: whtAmount,
        p_wht_gl_code: whtGl || null,
        p_override_reason: override || null,
        p_budget_reference: null,
        p_expense_type: expenseType,
        p_lines: lines
          .filter((l) => l.gl_code && Number(l.amount) > 0)
          .map((l) => ({
            gl_code: l.gl_code,
            cost_center_id: l.cost_center_id || null,
            amount: Number(l.amount),
            narration: l.narration || null,
          })),
      },
      "Finance check saved",
    );

  const openAttachment = async (path: string) => {
    const { data, error } = await supabase.storage.from("invoice-docs").createSignedUrl(path, 300);
    if (error || !data) {
      toast.error("Could not open file");
      return;
    }
    window.open(data.signedUrl, "_blank");
  };

  return (
    <>
      <PageHeader
        title={inv.request_no ?? "Draft request"}
        subtitle={`${inv.vendor_name_free_text} • Invoice ${inv.invoice_no} • ${fmtDate(inv.invoice_date)}`}
        action={
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" asChild>
              <Link to="/requests">Back to list</Link>
            </Button>
            {isOwner && (status === "draft" || status === "returned") && (
              <Button variant="outline" onClick={() => navigate({ to: "/requests/new", search: { id } })}>
                Edit
              </Button>
            )}
          </div>
        }
      />

      <div className="space-y-6">
        <div className="grid gap-6 lg:grid-cols-3">
          <div className="space-y-6 lg:col-span-2">
            <div className="panel p-6">
              <div className="mb-4 flex items-center justify-between">
                <h2 className="text-sm font-semibold">Request summary</h2>
                <StatusBadge status={status} />
              </div>
              <dl className="grid gap-x-6 gap-y-3 text-sm sm:grid-cols-2">
                <Field label="Department" value={inv.departments?.name ?? "—"} />
                <Field
                  label="Business unit"
                  value={inv.business_units ? `${inv.business_units.code} — ${inv.business_units.name}` : "—"}
                />
                <Field
                  label="Cost center"
                  value={inv.cost_centers ? `${inv.cost_centers.code} — ${inv.cost_centers.name}` : "—"}
                />
                <Field label="Expense type" value={inv.expense_type === "capex" ? "Capex" : "Expense"} />
                <Field label="Reference" value={REFERENCE_LABEL[inv.reference_type] ?? "—"} />
                <Field label="Reference no." value={inv.reference_number ?? "—"} />
                <Field label="Reference date" value={fmtDate(inv.reference_date)} />
                <Field label="Validity" value={inv.reference_validity ?? "—"} />
                <Field label="Amount" value={money(inv.amount, inv.currency)} />
                <Field label="Tax" value={money(inv.tax_amount, inv.currency)} />
                <Field label="Net payable" value={money(inv.net_amount, inv.currency)} />
                <Field label="Vendor code" value={inv.vendor_code ?? "Not linked"} />
                <Field label="WHT" value={inv.wht_applicable ? `${inv.wht_rate}% — ${money(inv.wht_amount, inv.currency)}` : "Not applicable"} />
                <Field label="Submission sheet" value={inv.submission_sheet_no ?? "—"} />
                {inv.currency !== "TZS" && (
                  <Field
                    label="FX rate to TZS"
                    value={inv.fx_rate ? String(inv.fx_rate) : "Not provided"}
                  />
                )}
              </dl>
              {inv.fx_remarks && (
                <p className="mt-4 rounded-md border border-warning bg-warning/10 p-3 text-sm">
                  <strong>Foreign currency ({inv.currency}) remarks:</strong> {inv.fx_remarks}
                </p>
              )}
              {inv.description && (
                <p className="mt-4 rounded-md bg-muted p-3 text-sm text-muted-foreground">{inv.description}</p>
              )}
              {inv.return_reason && (
                <p className="mt-4 rounded-md bg-warning/15 p-3 text-sm">
                  <strong>Returned:</strong> {inv.return_reason}
                </p>
              )}
            </div>

            {/* GL allocation view */}
            {(dbLines?.length ?? 0) > 0 && !(isChecker && status === "hod_approved") && (
              <div className="panel p-6">
                <h2 className="mb-3 text-sm font-semibold">GL allocation</h2>
                <table className="w-full text-sm">
                  <thead className="text-left text-xs text-muted-foreground">
                    <tr>
                      <th className="pb-2">GL code</th>
                      <th className="pb-2">Cost center</th>
                      <th className="pb-2 text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {(dbLines ?? []).map((l) => (
                      <tr key={l.id}>
                        <td className="py-2">
                          <div className="num">{l.gl_code}</div>
                          <div className="text-xs text-muted-foreground">
                            {(gls ?? []).find((g) => g.gl_code === l.gl_code)?.gl_name ?? ""}
                            {l.narration ? ` · ${l.narration}` : ""}
                          </div>
                        </td>
                        <td className="py-2">
                          {(ccs ?? []).find((c) => c.id === l.cost_center_id)?.name ?? "—"}
                        </td>
                        <td className="num py-2 text-right">{money(l.amount, inv.currency)}</td>
                      </tr>
                    ))}
                    <tr className="font-medium">
                      <td className="py-2" colSpan={2}>
                        Total allocated
                      </td>
                      <td className="num py-2 text-right">
                        {money(
                          (dbLines ?? []).reduce((s, l) => s + Number(l.amount), 0),
                          inv.currency,
                        )}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            )}

            {/* Proposed accounting entries — visible BEFORE final approval */}
            {(voucherRows?.length ?? 0) === 0 && (dbLines?.length ?? 0) > 0 && (
              <div className="panel p-6">
                <h2 className="mb-1 text-sm font-semibold">Proposed accounting entries (preview)</h2>
                <p className="mb-3 text-xs text-muted-foreground">
                  Exactly what will be posted once the Finance Approver approves. Nothing is committed yet.
                </p>
                <table className="w-full text-sm">
                  <thead className="text-left text-xs text-muted-foreground">
                    <tr>
                      <th className="pb-2">#</th>
                      <th className="pb-2">Account</th>
                      <th className="pb-2">Cost center</th>
                      <th className="pb-2 text-right">Debit</th>
                      <th className="pb-2 text-right">Credit</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {previewRows.map((r, i) => (
                      <tr key={i}>
                        <td className="num py-2">{i + 1}</td>
                        <td className="py-2">
                          <div className="num">{r.code}</div>
                          <div className="text-xs text-muted-foreground">{r.name}</div>
                        </td>
                        <td className="py-2">{r.cc}</td>
                        <td className="num py-2 text-right">{r.dr ? money(r.dr, inv.currency) : ""}</td>
                        <td className="num py-2 text-right">{r.cr ? money(r.cr, inv.currency) : ""}</td>
                      </tr>
                    ))}
                    <tr className="font-medium">
                      <td className="py-2" colSpan={3}>
                        Total
                      </td>
                      <td className="num py-2 text-right">
                        {money(previewRows.reduce((s, r) => s + r.dr, 0), inv.currency)}
                      </td>
                      <td className="num py-2 text-right">
                        {money(previewRows.reduce((s, r) => s + r.cr, 0), inv.currency)}
                      </td>
                    </tr>
                  </tbody>
                </table>
                {!previewBalanced && (
                  <p className="mt-3 rounded-md bg-warning/15 p-3 text-xs text-warning-foreground">
                    Debits and credits do not balance yet — the GL allocation must equal the invoice amount.
                  </p>
                )}
              </div>
            )}

            {/* Voucher */}
            {(voucherRows?.length ?? 0) > 0 && (
              <div className="panel p-6">
                <div className="mb-3 flex items-center justify-between">
                  <h2 className="text-sm font-semibold">
                    Journal voucher{" "}
                    <span className="num text-muted-foreground">{voucherRows?.[0]?.voucher_no}</span>
                  </h2>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() =>
                      void printVoucher(inv, voucherRows ?? [], {
                        department: inv.departments?.name ?? "—",
                        requester: inv.profiles?.full_name ?? "—",
                        approvals: approvals ?? [],
                        glName: (code) => (gls ?? []).find((g) => g.gl_code === code)?.gl_name ?? "",
                        costCenter: (cid) =>
                          (ccs ?? []).find((c) => c.id === cid)?.name ?? "—",
                        printedBy: profile?.full_name ?? null,
                      })
                    }
                  >
                    Print voucher
                  </Button>
                </div>
                <table className="w-full text-sm">
                  <thead className="text-left text-xs text-muted-foreground">
                    <tr>
                      <th className="pb-2">#</th>
                      <th className="pb-2">Account</th>
                      <th className="pb-2">Dr/Cr</th>
                      <th className="pb-2 text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {(voucherRows ?? []).map((r) => (
                      <tr key={r.id}>
                        <td className="num py-2">{r.line_no}</td>
                        <td className="num py-2">{r.gl_code ?? r.vendor_code}</td>
                        <td className="py-2">{r.dr_cr}</td>
                        <td className="num py-2 text-right">{money(r.amount, inv.currency)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* Approval trail */}
            <div className="panel p-6">
              <h2 className="mb-3 text-sm font-semibold">Approval trail</h2>
              <ol className="space-y-3">
                {(approvals ?? []).length === 0 && (
                  <li className="text-sm text-muted-foreground">No workflow activity yet.</li>
                )}
                {(approvals ?? []).map((a) => (
                  <li key={a.id} className="flex gap-3 text-sm">
                    <span className="mt-1 h-2 w-2 shrink-0 rounded-full bg-primary" />
                    <div>
                      <div className="font-medium capitalize">
                        {a.action.replace(/_/g, " ")} <span className="text-muted-foreground">· {a.role}</span>
                      </div>
                      <div className="text-xs text-muted-foreground">{fmtDateTime(a.created_at)}</div>
                      {a.comments && <p className="mt-1 text-muted-foreground">{a.comments}</p>}
                    </div>
                  </li>
                ))}
              </ol>
            </div>
          </div>

          {/* ---------------- action rail ---------------- */}
          <div className="space-y-6">
          <div className="panel p-6">
            <h2 className="mb-3 text-sm font-semibold">Declared documents</h2>
            <ul className="mb-4 space-y-1 text-sm">
              {(inv.declared_attachments ?? []).length === 0 && (
                <li className="text-muted-foreground">Nothing declared by the department.</li>
              )}
              {(inv.declared_attachments ?? []).map((k: string) => {
                const cat = ATTACHMENT_CATEGORIES.find((c) => c.key === k);
                const uploaded = (attachments ?? []).some((a) => a.type === (cat?.dbType ?? k));
                return (
                  <li key={k} className="flex items-center justify-between gap-2">
                    <span>{cat?.label ?? k.replace(/_/g, " ")}</span>
                    <span
                      className={`rounded-full px-2 py-0.5 text-xs ${uploaded ? "bg-success/15 text-success" : "bg-muted text-muted-foreground"}`}
                    >
                      {uploaded ? "Uploaded" : "Physical only"}
                    </span>
                  </li>
                );
              })}
            </ul>
            {inv.attachment_receipt_status && (
              <p
                className={`mb-3 rounded-md p-2 text-xs ${inv.attachment_receipt_status === "confirmed" ? "bg-success/10 text-success" : "bg-destructive/10 text-destructive"}`}
              >
                Documents {inv.attachment_receipt_status} {fmtDateTime(inv.attachment_receipt_at)}
                {inv.attachment_receipt_notes ? ` — ${inv.attachment_receipt_notes}` : ""}
              </p>
            )}
            <h2 className="mb-3 text-sm font-semibold">Uploaded files</h2>
            <ul className="space-y-2 text-sm">
              {(attachments ?? []).length === 0 && (
                <li className="text-muted-foreground">No documents uploaded.</li>
              )}
              {(attachments ?? []).map((a) => (
                <li key={a.id}>
                  <button
                    className="text-left text-primary hover:underline"
                    onClick={() => openAttachment(a.file_url)}
                  >
                    {a.file_name ?? a.file_url}
                  </button>
                  <span className="ml-2 text-xs text-muted-foreground">{categoryLabel(a.type)}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Requester */}
          {isOwner && (status === "draft" || status === "returned") && (
            <Panel title="Your action">
              <p className="text-sm text-muted-foreground">
                {status === "returned"
                  ? "This request came back for correction. Fix it and resubmit."
                  : "This draft is not yet in the workflow."}
              </p>
              <Button
                className="w-full"
                disabled={busy}
                onClick={() => call("submit_invoice", { p_id: id }, "Sent to HOD")}
              >
                Submit to HOD
              </Button>
            </Panel>
          )}

          {/* HOD */}
          {isHod && status === "submitted" && (
            <Panel title="HOD decision">
              <Textarea
                rows={3}
                placeholder="Comments (mandatory for return / reject)"
                value={comment}
                onChange={(e) => setComment(e.target.value)}
              />
              <div className="grid grid-cols-2 gap-2">
                <Button
                  disabled={busy}
                  onClick={() =>
                    call("hod_action", { p_id: id, p_action: "approve", p_comments: comment || null }, "Approved")
                  }
                >
                  Approve
                </Button>
                <Button
                  variant="outline"
                  disabled={busy}
                  onClick={() =>
                    call("hod_action", { p_id: id, p_action: "return", p_comments: comment }, "Returned")
                  }
                >
                  Return
                </Button>
                <Button
                  variant="destructive"
                  className="col-span-2"
                  disabled={busy}
                  onClick={() =>
                    call("hod_action", { p_id: id, p_action: "reject", p_comments: comment }, "Rejected")
                  }
                >
                  Reject
                </Button>
              </div>
            </Panel>
          )}

          {/* Finance checker */}
          {isChecker && status === "hod_approved" && (
            <Panel title="Finance check">
              <div className="space-y-2 rounded-md border bg-muted/30 p-3">
                <Label>Expense category (Opex / Capex)</Label>
                <p className="text-xs text-muted-foreground">
                  Set by Finance — it drives which GL accounts are offered below.
                </p>
                <Select value={expenseType} onValueChange={(v) => setExpenseType(v as "expense" | "capex")}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="expense">Opex — operating expense</SelectItem>
                    <SelectItem value="capex">Capex — capital expenditure</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {inv.attachment_receipt_status !== "confirmed" ? (
                <p className="rounded-md bg-warning/15 p-3 text-xs text-warning-foreground">
                  Scan the hardcopy QR below and confirm the declared documents first. Vendor code
                  linking and GL allocation unlock once the physical documents are confirmed.
                </p>
              ) : (
              <>
              <div className="space-y-2">
                <Label>Vendor code (mandatory)</Label>
                <Select value={vendorCode} onValueChange={setVendorCode}>
                  <SelectTrigger>
                    <SelectValue placeholder="Link an accounting vendor" />
                  </SelectTrigger>
                  <SelectContent>
                    {(vendors ?? []).map((v) => (
                      <SelectItem key={v.vendor_code} value={v.vendor_code}>
                        {v.vendor_code} — {v.vendor_name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>


              <div className="flex items-center justify-between rounded-md border p-3">
                <div>
                  <div className="text-sm font-medium">Withholding tax</div>
                  <div className="text-xs text-muted-foreground">
                    {vendor?.wht_category ? `Vendor category: ${vendor.wht_category} (${suggestedRate}%)` : "No vendor category"}
                  </div>
                </div>
                <Switch checked={whtOn} onCheckedChange={setWhtOn} />
              </div>

              {whtOn && (
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label>Rate %</Label>
                    <Input type="number" step="0.001" value={whtRate} onChange={(e) => setWhtRate(e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label>WHT GL</Label>
                    <Select value={whtGl} onValueChange={setWhtGl}>
                      <SelectTrigger>
                        <SelectValue placeholder="GL" />
                      </SelectTrigger>
                      <SelectContent>
                        {(gls ?? []).map((g) => (
                          <SelectItem key={g.gl_code} value={g.gl_code}>
                            {g.gl_code} — {g.gl_name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="sm:col-span-2 rounded-md bg-muted p-3 text-sm">
                    WHT amount <span className="num float-right">{money(whtAmount, inv.currency)}</span>
                  </div>
                </div>
              )}

              {Number(whtRate || 0) !== suggestedRate && (
                <div className="space-y-2">
                  <Label>Override reason (rate differs from vendor default)</Label>
                  <Textarea rows={2} value={override} onChange={(e) => setOverride(e.target.value)} />
                </div>
              )}

              <div className="grid grid-cols-2 gap-2">
                <Button variant="outline" disabled={busy} onClick={saveCheck}>
                  Save check
                </Button>
                <Button
                  disabled={busy}
                  onClick={async () => {
                    if (await saveCheck()) await call("finance_forward", { p_id: id }, "Forwarded to approver");
                  }}
                >
                  Forward
                </Button>
              </div>
              </>
              )}
            </Panel>
          )}


          {/* Hardcopy hand-over — QR based, no printing */}
          {["hod_approved", "finance_checked", "payment_request", "payment_confirmed", "closed"].includes(
            status,
          ) && (
            <Panel title="Hardcopy submission (QR)">
              {!inv.physical_copy_received_at ? (
                <>
                  <p className="text-sm text-muted-foreground">
                    Take the original invoice to Finance and show this QR code. Finance scans it to log receipt — no
                    sheet needs to be printed.
                  </p>
                  <RequestQrTicket code={qrReferenceCode(inv)} />
                  {(isFinanceStaff || isChecker || isApprover) && (
                    <>
                      <Button className="w-full" disabled={busy} onClick={() => setReceiveOpen(true)}>
                        <QrCode className="mr-2 size-4" /> Scan QR &amp; check documents
                      </Button>
                      <div className="rounded-md border p-3">
                        <div className="text-xs font-medium">Declared documents received?</div>
                        <ul className="mb-2 mt-1 text-xs text-muted-foreground">
                          {(inv.declared_attachments ?? []).map((k: string) => (
                            <li key={k}>• {ATTACHMENT_CATEGORIES.find((c) => c.key === k)?.label ?? k}</li>
                          ))}
                        </ul>
                        <Textarea
                          rows={2}
                          placeholder="Notes / which document is missing"
                          value={receiptNotes}
                          onChange={(e) => setReceiptNotes(e.target.value)}
                        />
                        <div className="mt-2 grid grid-cols-2 gap-2">
                          <Button
                            size="sm"
                            disabled={busy}
                            onClick={() =>
                              call(
                                "confirm_attachment_receipt",
                                { p_id: id, p_confirmed: true, p_notes: receiptNotes || null },
                                "Documents confirmed — request continues",
                              )
                            }
                          >
                            Confirm all received
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            disabled={busy}
                            onClick={() =>
                              call(
                                "confirm_attachment_receipt",
                                { p_id: id, p_confirmed: false, p_notes: receiptNotes },
                                "Returned to the department",
                              )
                            }
                          >
                            Reject submission
                          </Button>
                        </div>
                      </div>
                    </>
                  )}
                </>
              ) : (
                <p className="text-sm text-muted-foreground">
                  Physical copy received {fmtDateTime(inv.physical_copy_received_at)}
                </p>
              )}
            </Panel>
          )}

          {/* Finance approver */}
          {isApprover && status === "finance_checked" && (
            <Panel title="Final finance approval">
              <p className="text-sm text-muted-foreground">
                Approving generates the balanced accounting voucher. Returning logs a checker-accuracy correction.
              </p>
              <div className="space-y-2">
                <Label>Field corrected (on return)</Label>
                <Select value={field} onValueChange={setField}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="gl_code">GL code</SelectItem>
                    <SelectItem value="vendor_code">Vendor code</SelectItem>
                    <SelectItem value="wht_rate">WHT rate</SelectItem>
                    <SelectItem value="amount">Amount</SelectItem>
                    <SelectItem value="cost_center">Cost center</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Textarea
                rows={3}
                placeholder="Correction comment (mandatory when returning)"
                value={comment}
                onChange={(e) => setComment(e.target.value)}
              />
              <div className="grid grid-cols-2 gap-2">
                <Button
                  disabled={busy}
                  onClick={() =>
                    call(
                      "approver_action",
                      { p_id: id, p_action: "approve", p_comments: comment || null, p_field_corrected: null },
                      "Approved — voucher generated",
                    )
                  }
                >
                  Approve
                </Button>
                <Button
                  variant="outline"
                  disabled={busy}
                  onClick={() =>
                    call(
                      "approver_action",
                      { p_id: id, p_action: "return", p_comments: comment, p_field_corrected: field },
                      "Returned to checker",
                    )
                  }
                >
                  Return
                </Button>
              </div>
            </Panel>
          )}

          {status === "payment_confirmed" && isFinanceStaff && (
            <Panel title="Close request">
              <Button className="w-full" disabled={busy} onClick={() => call("close_request", { p_id: id }, "Request closed")}>
                Close request
              </Button>
            </Panel>
          )}

          <div className="panel p-6 text-xs text-muted-foreground">
            <div className="mb-1 font-medium text-foreground">Current stage</div>
            {STATUS_LABEL[status]} · updated {fmtDateTime(inv.updated_at)}
          </div>
        </div>
      </div>

      {isChecker && status === "hod_approved" && inv.attachment_receipt_status === "confirmed" && (
        <div className="panel p-0">
          <GlAllocationGrid
            lines={lines}
            setLines={setLines}
            glOptions={glOptions.map((g) => ({
              value: g.gl_code,
              label: `${g.gl_code} — ${g.gl_name}`,
              sub: g.type,
            }))}
            ccOptions={(ccs ?? []).map((c) => ({ value: c.id, label: `${c.code} — ${c.name}` }))}
            total={Number(inv.amount)}
            currency={inv.currency}
            showAllGl={showAllGl}
            setShowAllGl={setShowAllGl}
          />
        </div>
      )}
    </div>

      <EfdQrScanner
        open={receiveOpen}
        onOpenChange={setReceiveOpen}
        title="Scan hardcopy hand-over QR"
        description="Scan the QR shown by the user department to log receipt of the physical invoice."
        onResult={(r) => {
          setReceiveOpen(false);
          void call("receive_physical_scan", { p_code: r.raw }, "Hardcopy receipt logged");
        }}
      />
    </>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-xs uppercase tracking-wide text-muted-foreground">{label}</dt>
      <dd className="mt-0.5">{value}</dd>
    </div>
  );
}

function Panel({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="panel space-y-3 p-6">
      <h2 className="text-sm font-semibold">{title}</h2>
      {children}
    </div>
  );
}

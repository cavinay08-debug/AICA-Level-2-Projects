import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

const rowSchema = z.object({
  voucher_no: z.string().nullish(),
  entry_date: z.string().nullish(),
  gl_code: z.string().nullish(),
  vendor_code: z.string().nullish(),
  dr_cr: z.string().nullish(),
  amount: z.coerce.number(),
  narration: z.string().nullish(),
  accounting_ref: z.string().nullish(),
});

const bodySchema = z.object({
  replace: z.boolean().optional(),
  rows: z.array(rowSchema).max(5000),
});

export const Route = createFileRoute("/api/public/accounting-sync")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const key = process.env["ACCOUNTING_SYNC_KEY"];
        const provided = request.headers.get("x-sync-key");
        if (!key || provided !== key) {
          return new Response("Unauthorized", { status: 401 });
        }

        let parsed;
        try {
          parsed = bodySchema.parse(await request.json());
        } catch {
          return new Response(JSON.stringify({ error: "Invalid payload" }), {
            status: 400,
            headers: { "content-type": "application/json" },
          });
        }

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const batchId = crypto.randomUUID();

        if (parsed.replace) {
          await supabaseAdmin.from("gl_postings").delete().eq("source", "odbc");
        }

        const payload = parsed.rows.map((r) => ({
          source: "odbc",
          batch_id: batchId,
          voucher_no: r.voucher_no ?? null,
          entry_date: r.entry_date || null,
          gl_code: r.gl_code ?? null,
          vendor_code: r.vendor_code ?? null,
          dr_cr: (r.dr_cr ?? "").toUpperCase() === "CR" ? "CR" : "DR",
          amount: r.amount,
          narration: r.narration ?? null,
          accounting_ref: r.accounting_ref ?? null,
        }));

        const { error } = await supabaseAdmin.from("gl_postings").insert(payload);
        if (error) {
          return new Response(JSON.stringify({ error: error.message }), {
            status: 500,
            headers: { "content-type": "application/json" },
          });
        }

        return new Response(JSON.stringify({ ok: true, batch_id: batchId, inserted: payload.length }), {
          headers: { "content-type": "application/json" },
        });
      },
    },
  },
});

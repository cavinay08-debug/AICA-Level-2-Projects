import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  ssr: false,
  beforeLoad: () => {
    throw redirect({ to: "/dashboard" });
  },
  head: () => ({
    meta: [
      { title: "Invoice Submission & Workflow Portal" },
      {
        name: "description",
        content:
          "Raise, approve and track supplier invoices end-to-end with HOD approval, finance checking, WHT handling and audit-ready accounting vouchers.",
      },
      { property: "og:title", content: "Invoice Submission & Workflow Portal" },
      {
        property: "og:description",
        content: "Department-to-finance invoice workflow with vouchers, WHT and reconciliation.",
      },
    ],
  }),
  component: () => null,
});

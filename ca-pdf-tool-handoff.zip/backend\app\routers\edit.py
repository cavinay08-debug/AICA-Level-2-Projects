import json
import os
import uuid
from typing import List, Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.paths import storage_dir
from app.services import edit as svc
from app.services import pageedit as pageedit_svc
from app.services.audit import log_action

router = APIRouter(prefix="/api/edit", tags=["edit"])

STORAGE = os.path.join(storage_dir(), "tmp")
os.makedirs(STORAGE, exist_ok=True)


def _save_upload(f: UploadFile) -> str:
    path = os.path.join(STORAGE, f"{uuid.uuid4().hex}_{f.filename}")
    with open(path, "wb") as out:
        out.write(f.file.read())
    return path


def _parse_pages_optional(raw: str) -> Optional[List[int]]:
    """Blank -> None (meaning "all pages"). Accepts '1,3,5-8'."""
    raw = (raw or "").strip()
    if not raw:
        return None
    pages = []
    try:
        for chunk in raw.split(","):
            chunk = chunk.strip()
            if not chunk:
                continue
            if "-" in chunk:
                start, end = chunk.split("-")
                pages.extend(range(int(start.strip()), int(end.strip()) + 1))
            else:
                pages.append(int(chunk))
    except ValueError:
        raise HTTPException(400, "Couldn't read page numbers — use e.g. 1,3,5-8 or leave blank for all pages.")
    return pages or None


def _run(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs)
    except RuntimeError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        raise HTTPException(400, f"Couldn't process this file: {e}")


@router.post("/page-numbers")
async def page_numbers(file: UploadFile = File(...), position: str = Form("bottom-center"),
                        start_number: int = Form(1), fmt: str = Form("Page {n} of {total}"),
                        font_size: float = Form(10), pages: str = Form(""),
                        staff: str = Form("unknown"), db: Session = Depends(get_db)):
    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"pagenum_{uuid.uuid4().hex}.pdf")
    _run(svc.add_page_numbers, path, out_path, position, start_number, fmt, font_size, _parse_pages_optional(pages))
    log_action(db, staff, "PAGE_NUMBERS", "EDIT", detail=f"{file.filename}: {position}, start={start_number}")
    return FileResponse(out_path, filename="numbered.pdf", media_type="application/pdf")


@router.post("/bates")
async def bates(file: UploadFile = File(...), prefix: str = Form(""), start_number: int = Form(1),
                 digits: int = Form(6), position: str = Form("bottom-right"), pages: str = Form(""),
                 staff: str = Form("unknown"), db: Session = Depends(get_db)):
    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"bates_{uuid.uuid4().hex}.pdf")
    _run(svc.add_bates_numbering, path, out_path, prefix, start_number, digits, position, _parse_pages_optional(pages))
    log_action(db, staff, "BATES_NUMBERING", "EDIT", detail=f"{file.filename}: {prefix}{'#' * digits} from {start_number}")
    return FileResponse(out_path, filename="bates_stamped.pdf", media_type="application/pdf")


@router.post("/watermark")
async def watermark(file: UploadFile = File(...), text: str = Form(""),
                     image: Optional[UploadFile] = File(None), opacity: float = Form(0.3),
                     rotation: float = Form(45), font_size: float = Form(64),
                     color_hex: str = Form("#888888"), pages: str = Form(""),
                     staff: str = Form("unknown"), db: Session = Depends(get_db)):
    path = _save_upload(file)
    image_path = _save_upload(image) if image else ""
    out_path = os.path.join(STORAGE, f"watermark_{uuid.uuid4().hex}.pdf")
    _run(svc.add_watermark, path, out_path, text, image_path, opacity, rotation, font_size, color_hex,
         _parse_pages_optional(pages))
    log_action(db, staff, "WATERMARK", "EDIT", detail=f"{file.filename}: {'image' if image else text!r}")
    return FileResponse(out_path, filename="watermarked.pdf", media_type="application/pdf")


@router.post("/remove-watermark")
async def remove_watermark(file: UploadFile = File(...), search_text: str = Form(...), pages: str = Form(""),
                            staff: str = Form("unknown"), db: Session = Depends(get_db)):
    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"nowatermark_{uuid.uuid4().hex}.pdf")
    hits = _run(svc.remove_watermark_text, path, out_path, search_text, _parse_pages_optional(pages))
    log_action(db, staff, "REMOVE_WATERMARK", "EDIT", detail=f"{file.filename}: '{search_text}' x{hits}")
    return FileResponse(out_path, filename="watermark_removed.pdf", media_type="application/pdf",
                         headers={"X-Removed-Count": str(hits), "Access-Control-Expose-Headers": "X-Removed-Count"})


@router.post("/header-footer")
async def header_footer(file: UploadFile = File(...), header_text: str = Form(""), footer_text: str = Form(""),
                         font_size: float = Form(9), pages: str = Form(""),
                         staff: str = Form("unknown"), db: Session = Depends(get_db)):
    if not header_text.strip() and not footer_text.strip():
        raise HTTPException(400, "Enter a header and/or footer text.")
    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"headfoot_{uuid.uuid4().hex}.pdf")
    _run(svc.add_header_footer, path, out_path, header_text, footer_text, font_size, _parse_pages_optional(pages))
    log_action(db, staff, "HEADER_FOOTER", "EDIT", detail=file.filename)
    return FileResponse(out_path, filename="header_footer.pdf", media_type="application/pdf")


@router.post("/crop")
async def crop(file: UploadFile = File(...), top_mm: float = Form(0), bottom_mm: float = Form(0),
               left_mm: float = Form(0), right_mm: float = Form(0), pages: str = Form(""),
               staff: str = Form("unknown"), db: Session = Depends(get_db)):
    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"cropped_{uuid.uuid4().hex}.pdf")
    _run(svc.crop_pdf, path, out_path, top_mm, bottom_mm, left_mm, right_mm, _parse_pages_optional(pages))
    log_action(db, staff, "CROP", "EDIT", detail=f"{file.filename}: T{top_mm} B{bottom_mm} L{left_mm} R{right_mm}mm")
    return FileResponse(out_path, filename="cropped.pdf", media_type="application/pdf")


@router.post("/metadata/read")
async def metadata_read(file: UploadFile = File(...)):
    path = _save_upload(file)
    return _run(svc.get_metadata, path)


@router.post("/metadata/write")
async def metadata_write(file: UploadFile = File(...), title: str = Form(""), author: str = Form(""),
                          subject: str = Form(""), keywords: str = Form(""), creator: str = Form(""),
                          staff: str = Form("unknown"), db: Session = Depends(get_db)):
    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"metadata_{uuid.uuid4().hex}.pdf")
    meta = {"title": title, "author": author, "subject": subject, "keywords": keywords, "creator": creator}
    _run(svc.set_metadata, path, out_path, meta)
    log_action(db, staff, "EDIT_METADATA", "EDIT", detail=f"{file.filename}: author={author!r}, title={title!r}")
    return FileResponse(out_path, filename="metadata_updated.pdf", media_type="application/pdf")


@router.post("/page-content")
async def page_content(file: UploadFile = File(...), texts: str = Form("[]"), shapes: str = Form("[]"),
                        image_placements: str = Form("[]"), images: List[UploadFile] = File([]),
                        staff: str = Form("unknown"), db: Session = Depends(get_db)):
    """Adds new text, shapes and images onto a page — the "Edit Text/Images/Shapes"
    tool. `images` (the uploaded files) and `image_placements` (their positions)
    must be the same length and in the same order — placement i goes with file i."""
    try:
        text_list = json.loads(texts or "[]")
        shape_list = json.loads(shapes or "[]")
        placement_list = json.loads(image_placements or "[]")
    except json.JSONDecodeError:
        raise HTTPException(400, "Couldn't read the text/shape/image data.")
    if len(placement_list) != len(images):
        raise HTTPException(400, f"Got {len(images)} image file(s) but {len(placement_list)} placement(s) — "
                                  f"each image needs exactly one placement.")
    image_list = []
    for placement, img in zip(placement_list, images):
        image_list.append({**placement, "path": _save_upload(img)})

    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"pageedit_{uuid.uuid4().hex}.pdf")
    count = _run(pageedit_svc.edit_page_content, path, out_path, text_list, shape_list, image_list)
    log_action(db, staff, "EDIT_PAGE_CONTENT", "EDIT",
               detail=f"{file.filename}: {len(text_list)} text, {len(shape_list)} shape(s), {len(image_list)} image(s)")
    return FileResponse(out_path, filename="edited.pdf", media_type="application/pdf",
                         headers={"X-Elements-Added": str(count), "Access-Control-Expose-Headers": "X-Elements-Added"})

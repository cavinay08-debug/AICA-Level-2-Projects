"""
Sign module — Feature Category 7.
Draw/Upload Signature (place a saved signature image onto a page), Fill & Sign
(signature + free-text stamps at chosen points — useful when a document has no
real AcroForm fields, which is the common case for a scanned/printed form),
DSC/PKI Sign (PKCS#11 USB token via pyHanko), Request Signatures (tracked in the
DB, see routers/sign.py — no email is sent, this is a local-LAN checklist).

Placement coordinates throughout are PDF points (page.rect space: origin top-left,
y increasing downward) — the frontend converts on-screen rectangle drags into this
space using the DPI the page was rendered at (see /api/organize/render-page).
"""
import fitz  # PyMuPDF


def place_signature(input_path: str, output_path: str, image_path: str, placements: list) -> str:
    """placements: [{"page": int, "x0":.., "y0":.., "x1":.., "y1":..}, ...] in PDF points."""
    if not placements:
        raise RuntimeError("No signature placement was set — draw a box on the page first.")
    doc = fitz.open(input_path)
    for p in placements:
        pno = int(p["page"])
        if pno < 1 or pno > doc.page_count:
            continue
        rect = fitz.Rect(p["x0"], p["y0"], p["x1"], p["y1"])
        doc[pno - 1].insert_image(rect, filename=image_path, keep_proportion=True, overlay=True)
    doc.save(output_path)
    doc.close()
    return output_path


def fill_and_sign(input_path: str, output_path: str, image_path: str = "",
                   placements: list | None = None, text_stamps: list | None = None) -> str:
    """Combines a signature placement with free-text stamps (name, date, place, etc.)
    at chosen points — a practical "fill & sign" for documents without real form
    fields. text_stamps: [{"page":int, "x":.., "y":.., "text":.., "font_size":10}]."""
    if not placements and not text_stamps:
        raise RuntimeError("Add a signature placement and/or at least one text stamp.")
    doc = fitz.open(input_path)
    for p in (placements or []):
        pno = int(p["page"])
        if pno < 1 or pno > doc.page_count:
            continue
        rect = fitz.Rect(p["x0"], p["y0"], p["x1"], p["y1"])
        doc[pno - 1].insert_image(rect, filename=image_path, keep_proportion=True, overlay=True)
    for t in (text_stamps or []):
        pno = int(t["page"])
        if pno < 1 or pno > doc.page_count:
            continue
        doc[pno - 1].insert_text((t["x"], t["y"]), t.get("text", ""),
                                  fontsize=t.get("font_size", 10), fontname="helv", color=(0, 0, 0))
    doc.save(output_path)
    doc.close()
    return output_path


def dsc_sign_pdf(input_path: str, output_path: str, pkcs11_lib_path: str, user_pin: str,
                  token_label: str = "", cert_label: str = "", reason: str = "", location: str = "",
                  field_name: str = "Signature1") -> str:
    """Cryptographically signs the PDF with a physical DSC (USB PKCS#11 token) via pyHanko.

    NOT verified in this sandbox — there's no PKCS#11 token attached here. This needs a
    real run on the office machine with the token plugged in and its vendor driver (a
    .dll on Windows, e.g. from ePass2003/Watchdata/ProxKey) installed. `pkcs11_lib_path`
    is the path to that driver DLL.
    """
    if not pkcs11_lib_path:
        raise RuntimeError("Enter the path to your DSC token's PKCS#11 driver (a .dll file "
                            "from the token manufacturer, e.g. C:\\Windows\\System32\\eps2003csp11.dll).")
    try:
        from pyhanko.sign import PdfSignatureMetadata, sign_pdf
        from pyhanko.sign.pkcs11 import PKCS11Signer, open_pkcs11_session
        from pyhanko.pdf_utils.incremental_writer import IncrementalPdfFileWriter
    except ImportError:
        raise RuntimeError("pyHanko / python-pkcs11 aren't installed. Run "
                            "'pip install pyhanko pyhanko-certvalidator python-pkcs11' on this machine.")

    try:
        session = open_pkcs11_session(pkcs11_lib_path, token_label=token_label or None, user_pin=user_pin)
    except Exception as e:
        raise RuntimeError(f"Couldn't open the DSC token: {e}. Check the driver path, that the "
                            f"token is plugged in, and that the PIN is correct.")

    try:
        signer = PKCS11Signer(session, cert_label=cert_label or None)
        with open(input_path, "rb") as f:
            w = IncrementalPdfFileWriter(f)
            meta = PdfSignatureMetadata(field_name=field_name, reason=reason or None, location=location or None)
            with open(output_path, "wb") as out:
                sign_pdf(w, meta, signer=signer, output=out)
    except Exception as e:
        raise RuntimeError(f"DSC signing failed: {e}")
    finally:
        try:
            session.close()
        except Exception:
            pass
    return output_path

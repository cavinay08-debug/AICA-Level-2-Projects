import json
import os
import uuid

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.paths import storage_dir
from app.services import viewer as svc
from app.services.audit import log_action

router = APIRouter(prefix="/api/viewer", tags=["viewer"])

STORAGE = os.path.join(storage_dir(), "tmp")
os.makedirs(STORAGE, exist_ok=True)

# Set once at startup when the exe is launched with a PDF path (file association /
# "Open with"). Deliberately a single fixed path rather than an endpoint that accepts
# an arbitrary path — the server listens on the LAN, and a general "read any local
# file" endpoint would let anyone on the network read the server machine's disk.
_STARTUP_FILE: str | None = None


def set_startup_file(path: str | None):
    global _STARTUP_FILE
    if path and os.path.isfile(path) and path.lower().endswith(".pdf"):
        _STARTUP_FILE = os.path.abspath(path)
    else:
        _STARTUP_FILE = None


def _save_upload(f: UploadFile) -> str:
    path = os.path.join(STORAGE, f"{uuid.uuid4().hex}_{f.filename}")
    with open(path, "wb") as out:
        out.write(f.file.read())
    return path


def _run(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs)
    except RuntimeError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        raise HTTPException(400, f"Couldn't process this PDF: {e}")


@router.get("/startup-file")
async def startup_file():
    """Tells the UI whether the app was launched by double-clicking a PDF."""
    if not _STARTUP_FILE or not os.path.isfile(_STARTUP_FILE):
        return {"has_file": False}
    return {"has_file": True, "name": os.path.basename(_STARTUP_FILE),
            "size": os.path.getsize(_STARTUP_FILE)}


@router.get("/startup-file/content")
async def startup_file_content():
    """Serves ONLY the file the app was started with — no arbitrary paths accepted."""
    if not _STARTUP_FILE or not os.path.isfile(_STARTUP_FILE):
        raise HTTPException(404, "No startup file.")
    return FileResponse(_STARTUP_FILE, media_type="application/pdf",
                         filename=os.path.basename(_STARTUP_FILE))


@router.post("/outline")
async def outline(file: UploadFile = File(...)):
    path = _save_upload(file)
    return _run(svc.get_outline, path)


@router.post("/save-annotations")
async def save_annotations(file: UploadFile = File(...), highlights: str = Form("[]"),
                            inks: str = Form("[]"), notes: str = Form("[]"),
                            staff: str = Form("unknown"), db: Session = Depends(get_db)):
    try:
        h = json.loads(highlights or "[]")
        i = json.loads(inks or "[]")
        n = json.loads(notes or "[]")
    except json.JSONDecodeError:
        raise HTTPException(400, "Couldn't read the markup data.")
    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"annotated_{uuid.uuid4().hex}.pdf")
    count = _run(svc.burn_annotations, path, out_path, h, i, n)
    log_action(db, staff, "VIEWER_ANNOTATE", "VIEW", detail=f"{file.filename}: {count} markup item(s)")
    return FileResponse(out_path, filename="annotated.pdf", media_type="application/pdf",
                         headers={"X-Annotation-Count": str(count),
                                  "Access-Control-Expose-Headers": "X-Annotation-Count"})

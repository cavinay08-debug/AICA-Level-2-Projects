import json
import os
import uuid
import zipfile
from typing import List

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.paths import storage_dir
from app.services import batch as svc
from app.services.audit import log_action

router = APIRouter(prefix="/api/batch", tags=["batch"])

STORAGE = os.path.join(storage_dir(), "tmp")
os.makedirs(STORAGE, exist_ok=True)


def _save_upload(f: UploadFile, subdir: str) -> str:
    """Saves under its original filename (batch tools need real names for
    ZIP output and {original_name} rename patterns) — de-duplicates within
    the batch so two same-named uploads don't silently overwrite each other."""
    os.makedirs(subdir, exist_ok=True)
    base, ext = os.path.splitext(f.filename)
    candidate = f.filename
    n = 1
    while os.path.exists(os.path.join(subdir, candidate)):
        candidate = f"{base}({n}){ext}"
        n += 1
    path = os.path.join(subdir, candidate)
    with open(path, "wb") as out:
        out.write(f.file.read())
    return path


def _zip_dir(files: list, zip_path: str):
    """Writes (name, path) pairs into a zip, de-duplicating names so two files that
    render to the same output name (e.g. a rename pattern without {n}) don't
    silently clobber each other inside the archive."""
    used = set()
    with zipfile.ZipFile(zip_path, "w") as zf:
        for name, path in files:
            arcname = name
            base, ext = os.path.splitext(name)
            n = 1
            while arcname in used:
                arcname = f"{base}({n}){ext}"
                n += 1
            used.add(arcname)
            zf.write(path, arcname=arcname)


def _run(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs)
    except RuntimeError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        raise HTTPException(400, f"Couldn't process this: {e}")


@router.get("/operations")
async def operations():
    return svc.list_operations()


@router.post("/apply")
async def apply(files: List[UploadFile] = File(...), operation: str = Form(...), params: str = Form("{}"),
                 staff: str = Form("unknown"), db: Session = Depends(get_db)):
    try:
        param_map = json.loads(params) if params.strip() else {}
    except json.JSONDecodeError:
        raise HTTPException(400, "Couldn't read the operation parameters.")

    batch_dir = os.path.join(STORAGE, f"bulk_{uuid.uuid4().hex}")
    inputs = []
    for f in files:
        saved_path = _save_upload(f, os.path.join(batch_dir, "in"))
        inputs.append((os.path.basename(saved_path), saved_path))
    out_dir = os.path.join(batch_dir, "out")
    os.makedirs(out_dir, exist_ok=True)

    results, errors = _run(svc.bulk_apply, inputs, operation, param_map, out_dir)
    zip_path = os.path.join(STORAGE, f"bulk_result_{uuid.uuid4().hex}.zip")
    _zip_dir(results, zip_path)
    log_action(db, staff, "BULK_APPLY", "BATCH",
               detail=f"{operation} on {len(files)} file(s): {len(results)} ok, {len(errors)} failed")
    headers = {"X-Succeeded": str(len(results)), "X-Failed": str(len(errors)),
               "Access-Control-Expose-Headers": "X-Succeeded, X-Failed"}
    if errors:
        headers["X-Errors"] = json.dumps(errors)[:2000]
        headers["Access-Control-Expose-Headers"] += ", X-Errors"
    return FileResponse(zip_path, filename="bulk_result.zip", media_type="application/zip", headers=headers)


@router.post("/wizard")
async def wizard(files: List[UploadFile] = File(...), steps: str = Form(...),
                  staff: str = Form("unknown"), db: Session = Depends(get_db)):
    try:
        step_list = json.loads(steps)
        if not isinstance(step_list, list):
            raise ValueError
    except (json.JSONDecodeError, ValueError):
        raise HTTPException(400, "Couldn't read the wizard steps.")

    batch_dir = os.path.join(STORAGE, f"wizard_{uuid.uuid4().hex}")
    out_dir = os.path.join(batch_dir, "out")
    os.makedirs(out_dir, exist_ok=True)

    results, errors = [], []
    for f in files:
        in_path = _save_upload(f, os.path.join(batch_dir, "in"))
        out_name = os.path.basename(in_path)
        out_path = os.path.join(out_dir, out_name)
        try:
            svc.run_chain(in_path, out_path, step_list)
            results.append((out_name, out_path))
        except Exception as e:
            errors.append(f"{out_name}: {e}")

    if not results:
        raise HTTPException(400, "Every file failed: " + "; ".join(errors))

    zip_path = os.path.join(STORAGE, f"wizard_result_{uuid.uuid4().hex}.zip")
    _zip_dir(results, zip_path)
    log_action(db, staff, "ACTION_WIZARD", "BATCH",
               detail=f"{len(step_list)}-step chain on {len(files)} file(s): {len(results)} ok, {len(errors)} failed")
    headers = {"X-Succeeded": str(len(results)), "X-Failed": str(len(errors)),
               "Access-Control-Expose-Headers": "X-Succeeded, X-Failed"}
    if errors:
        headers["X-Errors"] = json.dumps(errors)[:2000]
        headers["Access-Control-Expose-Headers"] += ", X-Errors"
    return FileResponse(zip_path, filename="wizard_result.zip", media_type="application/zip", headers=headers)


@router.post("/auto-name")
async def auto_name(files: List[UploadFile] = File(...), pattern: str = Form(...),
                     client: str = Form(""), pan: str = Form(""), fy: str = Form(""),
                     staff: str = Form("unknown"), db: Session = Depends(get_db)):
    batch_dir = os.path.join(STORAGE, f"autoname_{uuid.uuid4().hex}")
    inputs = []
    for f in files:
        saved_path = _save_upload(f, os.path.join(batch_dir, "in"))
        inputs.append((os.path.basename(saved_path), saved_path))
    renamed = _run(svc.rename_files, inputs, pattern, {"client": client, "pan": pan, "fy": fy})
    zip_path = os.path.join(STORAGE, f"renamed_{uuid.uuid4().hex}.zip")
    _zip_dir(renamed, zip_path)
    log_action(db, staff, "AUTO_NAME", "BATCH", detail=f"{len(files)} file(s), pattern={pattern!r}")
    return FileResponse(zip_path, filename="renamed.zip", media_type="application/zip")


@router.post("/rename")
async def rename(files: List[UploadFile] = File(...), pattern: str = Form(...),
                  staff: str = Form("unknown"), db: Session = Depends(get_db)):
    batch_dir = os.path.join(STORAGE, f"rename_{uuid.uuid4().hex}")
    inputs = []
    for f in files:
        saved_path = _save_upload(f, os.path.join(batch_dir, "in"))
        inputs.append((os.path.basename(saved_path), saved_path))
    renamed = _run(svc.rename_files, inputs, pattern, {})
    zip_path = os.path.join(STORAGE, f"renamed_{uuid.uuid4().hex}.zip")
    _zip_dir(renamed, zip_path)
    log_action(db, staff, "BULK_RENAME", "BATCH", detail=f"{len(files)} file(s), pattern={pattern!r}")
    return FileResponse(zip_path, filename="renamed.zip", media_type="application/zip")

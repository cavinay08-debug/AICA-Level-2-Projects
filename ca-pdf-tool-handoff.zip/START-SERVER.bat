@echo off
REM ============================================================
REM  Office PDF - start the server
REM
REM  Double-click this file to run the tool. Keep the black
REM  window OPEN while staff are using it - closing that window
REM  stops the server and the tool goes offline for everyone.
REM
REM  To stop the server: close the window, or press Ctrl+C in it.
REM ============================================================

cd /d "%~dp0backend"

if not exist "venv\Scripts\python.exe" (
    echo.
    echo   [!] Python environment not found.
    echo.
    echo   Run these commands once, from this folder, then try again:
    echo       cd backend
    echo       python -m venv venv
    echo       venv\Scripts\python -m pip install -r requirements.txt
    echo.
    pause
    exit /b 1
)

echo.
echo  ============================================================
echo   Office PDF is starting...
echo  ============================================================
echo.
echo   On THIS computer, open:   http://localhost:8000
echo.
echo   From other office computers, open:  http://YOUR-IP:8000
echo   (Your IP addresses on this machine:)
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4 Address"') do echo        http:// %%a :8000
echo.
echo   KEEP THIS WINDOW OPEN while the tool is in use.
echo  ============================================================
echo.

venv\Scripts\python.exe -m uvicorn app.main:app --host 0.0.0.0 --port 8000

echo.
echo  Server has stopped. The tool is now offline.
pause

import os
import uuid
import json
import zipfile
import fitz
from fastapi import APIRouter, UploadFile, File, Form, Depends, HTTPException
from fastapi.responses import FileResponse, Response
from sqlalchemy.orm import Session
from typing import List

from app.core.database import get_db
from app.core.paths import storage_dir
from app.services import organize as svc
from app.services.audit import log_action

router = APIRouter(prefix="/api/organize", tags=["organize"])

STORAGE = os.path.join(storage_dir(), "tmp")
os.makedirs(STORAGE, exist_ok=True)


def _save_upload(f: UploadFile) -> str:
    path = os.path.join(STORAGE, f"{uuid.uuid4().hex}_{f.filename}")
    with open(path, "wb") as out:
        out.write(f.file.read())
    return path


def _run(fn, *args, **kwargs):
    """Turns a failure inside a service call into a clean, human-readable 400 instead
    of a raw 500 — e.g. a corrupt PDF, or a page number past the end of the file."""
    try:
        return fn(*args, **kwargs)
    except HTTPException:
        raise
    except RuntimeError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        raise HTTPException(400, f"Couldn't process this PDF: {e}. "
                                  f"If the file is damaged, try Repair PDF first.")


def _parse_page_list(raw: str, field_name: str = "pages") -> List[int]:
    """Accepts either JSON ('[1,2,5]') or plain comma-separated ('1,2,5').
    Always returns a flat list of ints. Raises a clean 400 on bad input."""
    raw = (raw or "").strip()
    if not raw:
        return []
    try:
        parsed = json.loads(raw)
        if isinstance(parsed, int):
            return [parsed]
        if isinstance(parsed, list):
            return [int(x) for x in parsed]
    except (json.JSONDecodeError, ValueError, TypeError):
        pass
    try:
        return [int(x.strip()) for x in raw.split(",") if x.strip()]
    except ValueError:
        raise HTTPException(400, f"Couldn't read '{field_name}': use page numbers separated by commas, e.g. 1,3,6")


def _parse_ranges(raw: str) -> List[tuple]:
    """Accepts JSON ('[[1,3],[4,6]]') or plain '1-3,4-6'. Returns list of (start,end) tuples."""
    raw = (raw or "").strip()
    if not raw:
        raise HTTPException(400, "Enter at least one page range, e.g. 1-3,4-6")
    try:
        parsed = json.loads(raw)
        if isinstance(parsed, list):
            return [tuple(r) for r in parsed]
    except (json.JSONDecodeError, ValueError, TypeError):
        pass
    try:
        ranges = []
        for chunk in raw.split(","):
            chunk = chunk.strip()
            if "-" in chunk:
                start, end = chunk.split("-")
                ranges.append((int(start.strip()), int(end.strip())))
            else:
                p = int(chunk)
                ranges.append((p, p))
        return ranges
    except ValueError:
        raise HTTPException(400, "Couldn't read page ranges: use format like 1-3,4-6")


@router.post("/page-count")
async def page_count(file: UploadFile = File(...)):
    """Used by the frontend to build drag-and-drop / chip page pickers."""
    path = _save_upload(file)
    try:
        with fitz.open(path) as doc:
            return {"pages": doc.page_count}
    except Exception:
        raise HTTPException(400, "Couldn't read this PDF — it may be corrupt. Try Repair PDF first.")


@router.post("/render-page")
async def render_page(file: UploadFile = File(...), page: int = Form(...), dpi: int = Form(120)):
    """Renders one page as a PNG — used by the on-screen page pickers for draw-a-box
    redaction (Security) and click-to-place signing (Sign). Returns the DPI used in a
    header so the frontend can convert screen pixels back to PDF points precisely."""
    path = _save_upload(file)
    try:
        png_bytes = svc.render_page_png(path, page, dpi)
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception:
        raise HTTPException(400, "Couldn't read this PDF — it may be corrupt. Try Repair PDF first.")
    used_dpi = max(60, min(int(dpi or 120), 300))
    return Response(content=png_bytes, media_type="image/png",
                     headers={"X-Render-Dpi": str(used_dpi), "Access-Control-Expose-Headers": "X-Render-Dpi"})


@router.post("/merge")
async def merge(files: List[UploadFile] = File(...), staff: str = Form("unknown"), db: Session = Depends(get_db)):
    paths = [_save_upload(f) for f in files]
    out_path = os.path.join(STORAGE, f"merged_{uuid.uuid4().hex}.pdf")
    _run(svc.merge_pdfs, paths, out_path)
    log_action(db, staff, "MERGE", "ORGANIZE", detail=f"{len(files)} files merged")
    return FileResponse(out_path, filename="merged.pdf", media_type="application/pdf")


@router.post("/split")
async def split(file: UploadFile = File(...), ranges: str = Form(...), staff: str = Form("unknown"),
                 db: Session = Depends(get_db)):
    """ranges: '1-3,4-6' or JSON '[[1,3],[4,6]]'. Returns a ZIP containing every part
    (a split always produces 2+ files, so a single PDF response isn't possible)."""
    path = _save_upload(file)
    range_list = _parse_ranges(ranges)
    outputs = _run(svc.split_pdf_by_ranges, path, range_list, STORAGE, uuid.uuid4().hex)
    zip_path = os.path.join(STORAGE, f"split_result_{uuid.uuid4().hex}.zip")
    with zipfile.ZipFile(zip_path, "w") as zf:
        for i, out in enumerate(outputs, start=1):
            zf.write(out, arcname=f"part_{i}.pdf")
    log_action(db, staff, "SPLIT", "ORGANIZE", detail=f"{file.filename} -> {len(outputs)} parts")
    return FileResponse(zip_path, filename="split_parts.zip", media_type="application/zip")


@router.get("/download/{filename}")
async def download(filename: str):
    return FileResponse(os.path.join(STORAGE, filename), filename=filename, media_type="application/pdf")


@router.post("/extract")
async def extract(file: UploadFile = File(...), pages: str = Form(...), staff: str = Form("unknown"),
                   db: Session = Depends(get_db)):
    """pages: '1,2,5' or JSON '[1,2,5]'"""
    path = _save_upload(file)
    page_list = _parse_page_list(pages, "pages to extract")
    out_path = os.path.join(STORAGE, f"extracted_{uuid.uuid4().hex}.pdf")
    _run(svc.extract_pages, path, page_list, out_path)
    log_action(db, staff, "EXTRACT_PAGES", "ORGANIZE", detail=f"{file.filename}: pages {page_list}")
    return FileResponse(out_path, filename="extracted.pdf", media_type="application/pdf")


@router.post("/delete-pages")
async def delete_pages(file: UploadFile = File(...), pages: str = Form(...), staff: str = Form("unknown"),
                        db: Session = Depends(get_db)):
    path = _save_upload(file)
    page_list = _parse_page_list(pages, "pages to delete")
    out_path = os.path.join(STORAGE, f"deleted_{uuid.uuid4().hex}.pdf")
    _run(svc.delete_pages, path, page_list, out_path)
    log_action(db, staff, "DELETE_PAGES", "ORGANIZE", detail=f"{file.filename}: removed {page_list}")
    return FileResponse(out_path, filename="pages_removed.pdf", media_type="application/pdf")


@router.post("/reorder")
async def reorder(file: UploadFile = File(...), new_order: str = Form(...), staff: str = Form("unknown"),
                   db: Session = Depends(get_db)):
    path = _save_upload(file)
    order_list = _parse_page_list(new_order, "new page order")
    out_path = os.path.join(STORAGE, f"reordered_{uuid.uuid4().hex}.pdf")
    _run(svc.reorder_pages, path, order_list, out_path)
    log_action(db, staff, "REORDER", "ORGANIZE", detail=f"{file.filename}: new order {order_list}")
    return FileResponse(out_path, filename="reordered.pdf", media_type="application/pdf")


@router.post("/rotate")
async def rotate(file: UploadFile = File(...), pages: str = Form("[]"), degrees: int = Form(...),
                  staff: str = Form("unknown"), db: Session = Depends(get_db)):
    path = _save_upload(file)
    page_list = _parse_page_list(pages, "pages to rotate")
    out_path = os.path.join(STORAGE, f"rotated_{uuid.uuid4().hex}.pdf")
    _run(svc.rotate_pages, path, page_list, degrees, out_path)
    log_action(db, staff, "ROTATE", "ORGANIZE", detail=f"{file.filename}: {degrees}deg on {page_list or 'all'}")
    return FileResponse(out_path, filename="rotated.pdf", media_type="application/pdf")


@router.post("/insert")
async def insert(base_file: UploadFile = File(...), insert_file: UploadFile = File(...), at_page: int = Form(...),
                  staff: str = Form("unknown"), db: Session = Depends(get_db)):
    base_path = _save_upload(base_file)
    ins_path = _save_upload(insert_file)
    out_path = os.path.join(STORAGE, f"inserted_{uuid.uuid4().hex}.pdf")
    _run(svc.insert_pages, base_path, ins_path, at_page, out_path)
    log_action(db, staff, "INSERT_PAGES", "ORGANIZE", detail=f"{insert_file.filename} into {base_file.filename} @ {at_page}")
    return FileResponse(out_path, filename="inserted.pdf", media_type="application/pdf")


@router.post("/combine-bookmarked")
async def combine_bookmarked(files: List[UploadFile] = File(...), labels: str = Form(...),
                              staff: str = Form("unknown"), db: Session = Depends(get_db)):
    """labels: JSON list of strings, same length/order as files, e.g. '["Financials","Bank Stmt"]'"""
    paths = [_save_upload(f) for f in files]
    try:
        label_list = json.loads(labels)
        if not isinstance(label_list, list):
            raise ValueError
    except (json.JSONDecodeError, ValueError):
        raise HTTPException(400, "Couldn't read labels — expected one label per file.")
    if len(label_list) != len(files):
        raise HTTPException(400, f"Got {len(files)} files but {len(label_list)} labels — need one label per file.")
    out_path = os.path.join(STORAGE, f"bundle_{uuid.uuid4().hex}.pdf")
    _run(svc.combine_with_bookmarks, paths, label_list, out_path)
    log_action(db, staff, "COMBINE_BOOKMARKED", "ORGANIZE", detail=f"{len(files)} annexures bundled")
    return FileResponse(out_path, filename="bundle_with_bookmarks.pdf", media_type="application/pdf")

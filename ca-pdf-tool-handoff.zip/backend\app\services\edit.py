"""
Edit module — Feature Category 5.
Page Numbers, Watermark, Header/Footer, Crop, Metadata, Bates Numbering.
Uses PyMuPDF (fitz) for all page-content stamping — no overlay/merge dance needed
since fitz can write text/images directly onto existing pages.

NOTE: "Edit Text/Images/Shapes" (freeform direct content editing) isn't implemented
here — it needs an interactive page canvas in the frontend (draw/select/move objects),
which is out of scope for the current no-build-step single-file UI. Everything else
in this category (the stamping/derived-content tools) is implemented.
"""
import os
import fitz  # PyMuPDF

MM = 2.8346456693  # points per millimeter


def _hex_to_rgb01(hex_color: str) -> tuple:
    hex_color = (hex_color or "").lstrip("#")
    if len(hex_color) != 6:
        hex_color = "888888"
    return (int(hex_color[0:2], 16) / 255, int(hex_color[2:4], 16) / 255, int(hex_color[4:6], 16) / 255)


def _stamp_text(page: "fitz.Page", text: str, position: str, font_size: float = 10, margin: float = 24):
    """Places a single line of text at one of 6 anchor positions on the page."""
    rect = page.rect
    tw = fitz.get_text_length(text, fontname="helv", fontsize=font_size)
    if "left" in position:
        x = margin
    elif "right" in position:
        x = rect.width - tw - margin
    else:
        x = (rect.width - tw) / 2
    y = margin if "top" in position else rect.height - margin
    page.insert_text((x, y), text, fontsize=font_size, fontname="helv", color=(0, 0, 0))


def _resolve_pages(doc: "fitz.Document", pages: list | None) -> list:
    return pages if pages else list(range(1, doc.page_count + 1))


# ---------------------------------------------------------------------------
def add_page_numbers(input_path: str, output_path: str, position: str = "bottom-center",
                      start_number: int = 1, fmt: str = "Page {n} of {total}",
                      font_size: float = 10, pages: list | None = None) -> str:
    doc = fitz.open(input_path)
    total = doc.page_count
    target_pages = _resolve_pages(doc, pages)
    for seq, pnum in enumerate(target_pages):
        if pnum < 1 or pnum > total:
            continue
        n = start_number + seq
        text = fmt.replace("{n}", str(n)).replace("{total}", str(total))
        _stamp_text(doc[pnum - 1], text, position, font_size)
    doc.save(output_path)
    doc.close()
    return output_path


def add_bates_numbering(input_path: str, output_path: str, prefix: str = "", start_number: int = 1,
                         digits: int = 6, position: str = "bottom-right", pages: list | None = None) -> str:
    """Sequential Bates stamps for filings/annexures, e.g. ABC-000001, ABC-000002 ..."""
    doc = fitz.open(input_path)
    total = doc.page_count
    target_pages = _resolve_pages(doc, pages)
    for seq, pnum in enumerate(target_pages):
        if pnum < 1 or pnum > total:
            continue
        n = start_number + seq
        label = f"{prefix}{str(n).zfill(digits)}"
        _stamp_text(doc[pnum - 1], label, position, font_size=9)
    doc.save(output_path)
    doc.close()
    return output_path


def add_watermark(input_path: str, output_path: str, text: str = "", image_path: str = "",
                   opacity: float = 0.3, rotation: float = 45, font_size: float = 64,
                   color_hex: str = "#888888", pages: list | None = None) -> str:
    if not text and not image_path:
        raise RuntimeError("Provide watermark text or an image.")
    doc = fitz.open(input_path)
    target_pages = _resolve_pages(doc, pages)
    color = _hex_to_rgb01(color_hex)
    opacity = max(0.05, min(opacity, 1.0))

    prepared_image_path = None
    if image_path:
        from PIL import Image
        img = Image.open(image_path).convert("RGBA")
        alpha = img.split()[3].point(lambda a: int(a * opacity))
        img.putalpha(alpha)
        prepared_image_path = image_path + "_wm.png"
        img.save(prepared_image_path)

    for pnum in target_pages:
        if pnum < 1 or pnum > doc.page_count:
            continue
        page = doc[pnum - 1]
        rect = page.rect
        if prepared_image_path:
            from PIL import Image
            iw, ih = Image.open(prepared_image_path).size
            box_w = rect.width * 0.5
            box_h = box_w * ih / iw
            box = fitz.Rect((rect.width - box_w) / 2, (rect.height - box_h) / 2,
                             (rect.width + box_w) / 2, (rect.height + box_h) / 2)
            page.insert_image(box, filename=prepared_image_path, overlay=True)
        else:
            tw = fitz.get_text_length(text, fontname="helv", fontsize=font_size)
            center = fitz.Point(rect.width / 2, rect.height / 2)
            point = fitz.Point(rect.width / 2 - tw / 2, rect.height / 2)
            mat = fitz.Matrix(1, 1).prerotate(rotation)
            page.insert_text(point, text, fontsize=font_size, fontname="helv", color=color,
                              fill_opacity=opacity, morph=(center, mat), overlay=True)

    doc.save(output_path)
    doc.close()
    if prepared_image_path and os.path.exists(prepared_image_path):
        os.remove(prepared_image_path)
    return output_path


def remove_watermark_text(input_path: str, output_path: str, search_text: str, pages: list | None = None) -> int:
    """Best-effort: finds and true-removes text matching `search_text` (e.g. 'DRAFT',
    'CONFIDENTIAL'). Works for text-based watermarks; image watermarks aren't detected."""
    if not search_text.strip():
        raise RuntimeError("Enter the watermark text to remove.")
    doc = fitz.open(input_path)
    target_pages = _resolve_pages(doc, pages)
    hits = 0
    for pnum in target_pages:
        if pnum < 1 or pnum > doc.page_count:
            continue
        page = doc[pnum - 1]
        rects = page.search_for(search_text)
        for r in rects:
            page.add_redact_annot(r)
            hits += 1
        if rects:
            page.apply_redactions()
    doc.save(output_path)
    doc.close()
    return hits


def add_header_footer(input_path: str, output_path: str, header_text: str = "", footer_text: str = "",
                       font_size: float = 9, pages: list | None = None) -> str:
    """header_text/footer_text may include {page} and {total} placeholders, e.g.
    'ABC & Co, Chartered Accountants | UDIN: 24123456AAAAAA1234 | Page {page} of {total}'."""
    doc = fitz.open(input_path)
    total = doc.page_count
    target_pages = _resolve_pages(doc, pages)
    for pnum in target_pages:
        if pnum < 1 or pnum > total:
            continue
        page = doc[pnum - 1]
        rect = page.rect
        if header_text:
            txt = header_text.replace("{page}", str(pnum)).replace("{total}", str(total))
            tw = fitz.get_text_length(txt, fontname="helv", fontsize=font_size)
            page.insert_text(((rect.width - tw) / 2, 22), txt, fontsize=font_size, fontname="helv", color=(0, 0, 0))
        if footer_text:
            txt = footer_text.replace("{page}", str(pnum)).replace("{total}", str(total))
            tw = fitz.get_text_length(txt, fontname="helv", fontsize=font_size)
            page.insert_text(((rect.width - tw) / 2, rect.height - 14), txt, fontsize=font_size, fontname="helv", color=(0, 0, 0))
    doc.save(output_path)
    doc.close()
    return output_path


def crop_pdf(input_path: str, output_path: str, top_mm: float = 0, bottom_mm: float = 0,
             left_mm: float = 0, right_mm: float = 0, pages: list | None = None) -> str:
    doc = fitz.open(input_path)
    target_pages = _resolve_pages(doc, pages)
    for pnum in target_pages:
        if pnum < 1 or pnum > doc.page_count:
            continue
        page = doc[pnum - 1]
        r = page.rect
        new_rect = fitz.Rect(r.x0 + left_mm * MM, r.y0 + top_mm * MM,
                              r.x1 - right_mm * MM, r.y1 - bottom_mm * MM)
        if new_rect.width <= 10 or new_rect.height <= 10:
            raise RuntimeError(f"Crop margins are too large for page {pnum} — nothing would remain.")
        page.set_cropbox(new_rect)
    doc.save(output_path)
    doc.close()
    return output_path


def get_metadata(input_path: str) -> dict:
    doc = fitz.open(input_path)
    md = dict(doc.metadata or {})
    md["page_count"] = doc.page_count
    doc.close()
    return md


def set_metadata(input_path: str, output_path: str, metadata: dict) -> str:
    allowed = {"title", "author", "subject", "keywords", "creator", "producer"}
    clean = {k: v for k, v in (metadata or {}).items() if k in allowed and v is not None}
    doc = fitz.open(input_path)
    doc.set_metadata(clean)
    doc.save(output_path)
    doc.close()
    return output_path

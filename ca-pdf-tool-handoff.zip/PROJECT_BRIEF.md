# Office PDF — Project Brief & Handoff

Paste this file into Claude Code (or reference it) to resume exactly where this
conversation left off.

## 1. What this is

A full-featured PDF management tool for a CA (Chartered Accountant) office.
**Local-only deployment** — one office machine runs the server, other staff access
it over the office LAN via browser. No cloud, no external hosting, no internet
dependency for core operation.

## 2. Confirmed requirements

- **Users**: Multiple staff in one CA office, same local network.
- **Deployment**: Local desktop/server only — explicitly NOT cloud-hosted.
- **DSC**: User has a physical Digital Signature Certificate (USB token) to test
  real PKI signing against — planned for Phase 4 via `pyHanko` (PKCS#11 support).
- **Frontend**: Written directly in code (not built via AI Studio) — single HTML
  file using React + Tailwind via CDN, no Node build step, so it's trivial to
  deploy alongside the Python backend.
- **Database**: SQLite (file-based, fits single-office local use).

## 3. Full feature list (12 categories, ~50 tools)

1. **Organize**: Merge, Split, Extract Pages, Delete Pages, Reorder Pages, Rotate,
   Insert Pages, Combine+Auto-Bookmark/TOC
2. **Optimize**: Compress (quality slider + target-size mode), Repair, OCR
   (multi-language incl. Hindi), Portal-Compliance Checker (IT/GST/MCA size limits)
3. **Convert to PDF**: Word/Excel/PPT→PDF, JPG→PDF, HTML→PDF, CSV→PDF, Scan→PDF
4. **Convert from PDF**: PDF→Word, PDF→Excel (structured tables), PDF→PPT,
   PDF→Images (batch/ZIP), PDF→PDF/A
5. **Edit**: Text/Image/Shape editing, Page Numbers, Watermark, Header/Footer
   (firm letterhead/UDIN), Crop, Metadata editor, Bates Numbering
6. **Security**: Password protect/remove, Permissions, Redact (true text removal),
   Pattern-based auto-redaction (PAN/Aadhaar/account numbers), Sanitize metadata
7. **Sign**: Draw/upload signature, Request signatures (multi-party), **DSC/PKI
   sign** (physical USB token via pyHanko), Fill & Sign
8. **Forms**: Create fillable forms, Auto-detect fields, Fill govt forms
   (ITR/GST/TDS), Export form data
9. **Compare & Review**: Compare two PDFs (diff), Annotate/comment, Track changes
10. **Batch/Automation**: Bulk apply any tool, Auto file naming (Client/PAN/FY),
    Action Wizard (chained ops), Bulk rename
11. **View & Navigate**: Inline viewer (zoom/thumbnails/search), Reader+Bookmarks
12. **CA-specific workflow**: Client Workspace (folders by Client/Matter/FY),
    Audit Trail Log, Accessibility check (PDF/UA), Portfolio/Package creator

## 4. Architecture decisions

- **Backend**: FastAPI (Python), serves both the REST API and the static frontend
  from one process — `uvicorn app.main:app --host 0.0.0.0 --port 8000`, staff open
  `http://<server-LAN-IP>:8000`.
- **Frontend**: Single `frontend/index.html` — React 18 + Tailwind, both via CDN,
  Babel standalone for JSX-in-browser (no build step). Talks to the backend via
  `fetch()` calls, same origin.
- **Database**: SQLite at `backend/storage/ca_pdf_tool.db`, SQLAlchemy ORM.
- **File processing library map** (all confirmed installable, no Python-native
  blocker found):

  | Category | Library |
  |---|---|
  | Organize (merge/split/reorder/rotate/bookmark) | `PyMuPDF` (fitz), `pypdf` |
  | Optimize (compress/repair) | `PyMuPDF`; Ghostscript (external binary) as future fallback |
  | OCR | `ocrmypdf` (wraps Tesseract) — needs system `tesseract-ocr` + lang packs |
  | Convert to PDF | LibreOffice headless (Office docs), `img2pdf`, `weasyprint` (HTML/CSV) |
  | Convert from PDF (Word/PPT) | `pdf2docx`, `python-pptx` |
  | Convert from PDF (Excel/tables) | `camelot-py`, `tabula-py`, `pdfplumber` |
  | PDF→Images / PDF/A | `PyMuPDF`, `pdf2image`; Ghostscript for PDF/A |
  | Edit / annotations / redaction | `PyMuPDF` (`add_redact_annot` does true removal) |
  | Watermark / page numbers / Bates | `reportlab` + `pypdf` overlay |
  | Security (password/permissions) | `pypdf` |
  | DSC/PKI signing | `pyHanko` (+ `pyhanko-certvalidator`), PKCS#11 for USB tokens |
  | Forms | `pypdf` AcroForm, `PyMuPDF` |
  | Compare | `PyMuPDF` render+diff, or `diff-pdf` CLI |
  | Batch/automation | native Python + `Celery` if async queue needed later |

  External (non-pip) dependencies needed on the server machine eventually:
  **Ghostscript**, **LibreOffice**, **Tesseract OCR + language packs**.

## 5. Visual design spec (must be followed exactly — user-specified, not default)

- Canvas: `slate-50` background, white (`#ffffff`) cards, 1px hairline borders
  (`slate-200`/`slate-100`), no heavy shadows.
- Category accent colors (badges use soft tint background + colored text):
  - **Indigo** — Organize
  - **Emerald** — Optimize
  - **Orange** — Convert
  - **Blue** — Edit
  - **Rose** — Security/Sign
- Typography: Inter (sans), bold headings in deep slate, uppercase tracked
  micro-labels for section headers.
- Layout: persistent left sidebar (category nav) + top header with search +
  4-column card grid, 12-16px rounded corners, subtle hover states where badge
  icons fill solid on hover.
- Footer-style status indicators (storage meter, LAN connection status) live in
  the sidebar footer, understated.

## 6. Current build status — remaining tools completed, real bug fixed, side-by-side compare (2026-08-07)

**Desktop app silent-failure bug — found from real user evidence, fixed (2026-08-07)**

User reported the desktop app still not working after the earlier fixes. This time
they'd left real evidence behind: a `office-pdf-crash.log` and a `storage/` folder
sitting in `SHARE-THIS-TO-OTHER-PCs/` showing the internal server had started
successfully (twice), but nothing was running afterward and no error was logged.
Root cause: `desktop_app.py`'s `main()` had **zero error handling** around
`webview.create_window()`/`webview.start()`. If that call throws — the most likely
reason being the machine doesn't have the **Microsoft Edge WebView2 Runtime**
installed (present by default on newer Windows 11, often missing on Windows 10) —
the process just exits. `--windowed` means no console, so there was no traceback,
no dialog, nothing.

Fixed by: (1) a pre-flight check (`_has_webview2_runtime()`) reading the same
registry keys the WebView2 installer itself writes, run *before* anything else
starts, with a specific actionable message box (download link included) if it's
missing; (2) wrapping the window-creation call in try/except regardless, logging
the traceback and showing a message box with the crash-log path, as a catch-all
for any other reason the window fails to open. Verified the detection function
correctly returns `True` on this dev machine (known-working) before rebuilding.

**Completed the last 3 "Coming soon" tools — the whole 12-category feature list is
now fully live:**
- **Edit Text/Images/Shapes** (`app/services/pageedit.py`) — adds new text, shapes
  (rectangle/circle/line) and images onto a page at chosen positions via the same
  PagePicker click/drag interaction used elsewhere. True in-place editing of
  *existing* text (rewriting content streams) is a different order of complexity
  and wasn't attempted — this matches what mainstream "edit a PDF" tools actually
  do. Frontend has a 5-way mode switch (Text/Rect/Circle/Line/Image) that changes
  both the input controls and the PagePicker's interaction mode (point for text,
  drag-a-box for everything else).
- **Accessibility Check** (`app/services/accessibility.py`) — a best-effort
  structural checklist (title set, language set, tagged, has bookmarks, all pages
  have extractable text, all fonts embedded), not a certified PDF/UA conformance
  test (that needs veraPDF, not bundled — same caveat as the PDF/A tool). **Caught
  a real false-positive while building this**: PyMuPDF reports `ext == "n/a"` for
  the 14 standard PDF fonts (Helvetica, Times, etc.) *by design* — they're never
  embedded because every PDF reader has them built in — so a naive "is it
  embedded" check would flag nearly every simple PDF as failing. Fixed by
  excluding the standard-14 (and common Windows aliases like Arial/Times New
  Roman) from the "unembedded" flag.
- **Portfolio / Package Creator** (`app/services/portfolio.py`) — bundles files of
  *any* type (PDF, Excel, Word, images…) into one PDF: a generated cover/index
  page listing what's inside, with each original file embedded verbatim via
  PyMuPDF's attachment API (`embfile_add`) so it opens in its native application
  from the PDF viewer's Attachments panel. Deliberately different from
  "Combine + Auto-Bookmark" (Organize), which merges PDF *pages* into one flowing
  document and only works on PDFs — a working-papers package needs the Excel file
  to stay an actual `.xlsx`.

**Compare Two PDFs — new "Side-by-side" output** (the other half of this request):
one **landscape** page per page-pair, old and new shown side by side using real
vector content (`show_pdf_page`, not a screenshot — stays crisp/searchable/
printable), with every region that actually changed **highlighted in yellow**
(semi-transparent fill, no border, sits over the real content rather than hiding
it) on both sides. Diff regions are found via a lightweight block-grid +
per-row-run-merge over a pixel-diff mask (no numpy/scipy dependency) — this keeps
the highlight boxes reasonably tight around what changed instead of one giant box
covering the whole page. Exposed as a third `format` option (alongside the
existing JSON summary and text-diff redline report) on the same
`/api/compare/pdfs` endpoint and the same tool card, not a new tool.

**Verified**: all 3 new tools + the compare enhancement covered by a dedicated
8-test suite with content-level assertions (not just status codes) — confirmed
actual landscape orientation, confirmed real yellow-highlight rectangles present
on the rendered page (inspected `page.get_drawings()` for the specific fill
color), confirmed identical files correctly produce zero diff pages, confirmed
the accessibility font check does NOT flag standard fonts, confirmed portfolio
attachments round-trip with correct names. Full 81-check regression audit still
clean, frontend↔backend contract cross-check still clean. Live in-browser:
clicked through every new tool card, confirmed the 5-way edit mode switch changes
its controls, confirmed the Side-by-side toggle shows its explanatory hint — no
console errors.

**Note on `storage/tmp/`**: found it had grown to 1000+ files during this session
— partly real user activity (confirmed via the audit log: real `staff1` entries
referencing real filenames), partly my own testing (my test scripts were only
setting `CA_PDF_TOOL_DB` to isolate the database, not `CA_PDF_TOOL_STORAGE` —
which `app/core/paths.py` already supports for exactly this, I just wasn't using
it). Fixed the test scripts to set both going forward. Left the existing
`storage/tmp/` untouched rather than guess which of the current files are safe
to delete; the existing 48-hour auto-sweep on server startup will clear old ones
on its own.

## 6prev2. Rename, desktop app, PDF viewer (2026-08-07, earlier this day)

**Rebrand + desktop app + PDF viewer (2026-08-07)**

User request: rename the app, and make it usable as a real desktop application
that can be set as the default PDF viewer, with View & Navigate's tools actually
built (was "Coming soon" since Phase 1).

- **Renamed** "CA Office PDF Tool" → **"Office PDF"** everywhere (HTML title,
  FastAPI title, all docs, all built artifacts). A logo was referenced but never
  actually arrived in any message — `frontend/logo.png` / `logo.ico` are a
  generated placeholder (dark rounded square, "PDF" text) so the build doesn't
  break. **Still need the real logo** — drop it in as `frontend/logo.png` +
  `frontend/logo.ico` and rebuild both exes to pick it up.
- **Removed the CDN dependency.** The frontend was loading React, ReactDOM,
  Babel-standalone, and Tailwind from `cdnjs`/`cdn.tailwindcss.com`, plus Google
  Fonts — meaning the "local-only, no internet dependency" tool actually broke
  with no internet. All vendored into `frontend/vendor/` (~5MB: react, react-dom,
  babel, tailwind, plus PDF.js + its worker for the new viewer) and referenced by
  relative path. Google Fonts replaced with system font stacks (Segoe UI /
  Inter / system-ui fallback chain) since shipping font files felt like overkill.
- **Built the PDF Viewer** (View & Navigate category, both cards now route to one
  full-screen reader): open, page nav, zoom (+/-/fit-width/fit-page), collapsible
  side panel (the user's specific ask) with three tabs — page thumbnails,
  bookmarks (from the PDF's real TOC via `PyMuPDF.get_toc()`), and full-text
  search (client-side via PDF.js `getTextContent()`, jump-to-hit). Markup tools:
  highlight (drag a box, 4 colors), freehand draw (color + pen width), sticky
  notes (click to place, prompt for text) — all rendered live via a canvas
  overlay, then "Save markup" burns them into a real PDF server-side
  (`app/services/viewer.py::burn_annotations`, downloads `<name>_marked.pdf`).
  Print uses a hidden iframe + the browser's native print dialog (real print,
  not a screenshot). "Open" and "Save as" are real file picker / download flows.
- **New backend**: `app/services/viewer.py`, `app/routers/viewer.py`
  (`/api/viewer/outline`, `/save-annotations`, `/startup-file`,
  `/startup-file/content` — the last two exist so double-clicking a PDF via file
  association can hand it to the viewer; deliberately a single fixed
  server-side path, not an endpoint that accepts an arbitrary path, since this
  server also listens on the LAN and a "read any local file" endpoint would let
  any office PC read the server machine's disk).
- **Desktop app**: new `backend/desktop_app.py` + `backend/build_desktop_exe.py`,
  built into `Office-PDF-Desktop.exe`. Runs the exact same FastAPI app headless
  in a background thread, displayed in a native window via `pywebview` (uses the
  Windows WebView2 runtime already present on modern Windows — no bundled
  Chromium). This is also the file-association target: launching it with a PDF
  path as argv[1] (what "Open with" does) opens straight into the viewer with
  that file loaded, via `set_startup_file()`.
- **"Set as default PDF viewer"** — a sidebar button that appears only when
  running inside the desktop shell (`window.pywebview` detection). Deliberately
  wired through pywebview's local-only `js_api` bridge, **not an HTTP endpoint**
  — this is a registry-writing action (HKEY_CURRENT_USER only, no admin needed;
  Windows blocks silently forcing a default, so it just makes the app show up by
  name in the right-click "Open with" list and the user still has to tick
  "Always use this app" themselves) and must never be reachable from a browser
  tab hitting the same backend over the LAN.
- **A real bug found and fixed while building the desktop exe**: `uvicorn.run()`
  called from a background thread inside a `--windowed` (no console) PyInstaller
  build crashed with `AttributeError: 'NoneType' object has no attribute
  'isatty'` — its default log formatter calls `sys.stdout.isatty()`, but a
  windowed/`pythonw` process has `sys.stdout is None` (not a null stream —
  actually `None`). Fixed two ways: (1) replace `sys.stdout`/`sys.stderr` with
  `io.StringIO()` at startup if they're `None`, since plenty of libraries assume
  a writable stream exists; (2) run uvicorn via an explicit `Config` +
  `Server().serve()` on our own event loop with `log_config=None` and signal
  handler installation skipped, rather than `uvicorn.run()`'s main-thread
  assumptions. Confirmed via a `office-pdf-crash.log` written next to the exe —
  windowed builds have no console, so without that the failure would have been
  completely silent (a window opens with a static title, then just... nothing).
- **Also found and fixed while auditing this pass**: `add_ink_annot()` in
  `viewer.py` rejected `fitz.Point` objects specifically (`"arg must be seq of
  seq of float pairs"`) despite `Point` being `point_like` everywhere else in
  PyMuPDF's API — fixed by passing plain `(x, y)` float tuples instead.
- **Verified**: full 81-check audit re-run clean after every change; static
  frontend↔backend contract cross-check clean; both exes tested standalone in
  clean folders with nothing else present — confirmed real (non-dialog) native
  window for the desktop app via `EnumWindows`/window-class inspection (not
  screenshottable in this environment), confirmed listening port + full API
  responses for both, confirmed real PDF operations (merge, page-count, outline)
  work end-to-end through the packaged server exe.
- **Not verified here — needs the user to spot-check live**: Print PDF (opens
  the OS print dialog via a hidden iframe; the flow is standard but print
  dialogs can't be driven or screenshotted in this environment) and the
  highlight/draw/note visual appearance while actively dragging (mechanically
  confirmed via the backend annotation tests and DOM state, but "does it look
  right while you're drawing" needs eyes on a real screen).

## 6prev. Prior status — all 5 phases complete; audited + packaged as .exe (2026-08-05)

**Standalone .exe packaging (2026-08-05)**

Built a single self-contained `CA-PDF-Tool.exe` (132 MB, PyInstaller --onefile) so the
tool can be set up on another office PC by copying **one file** — no Python, no pip, no
dependencies.

Important distinction that shapes this: most staff PCs need **nothing installed** —
they just browse to the server's address. The exe is only for a PC that should *run*
its own server. That's stated up front in `HOW-TO-INSTALL-ON-ANOTHER-PC.txt` so nobody
copies it to ten machines unnecessarily.

Key design point — **where data lives**. PyInstaller `--onefile` unpacks to a temp dir
that is deleted on exit, so anything written there would vanish silently. Added
`app/core/paths.py`, which splits:
  - `bundle_dir()` — read-only bundled assets (the frontend), temp when frozen
  - `data_dir()` / `storage_dir()` — the DB, signatures, sign-requests and tmp, always
    resolved **next to the .exe** so office data survives restarts
All nine routers and `database.py` now resolve paths through it rather than
`__file__`-relative guesses.

New files: `app/core/paths.py`, `run_server.py` (exe entry point — prints the LAN
addresses staff should open, warns not to close the window, auto-opens the browser),
`build_exe.py` (repeatable build), `HOW-TO-INSTALL-ON-ANOTHER-PC.txt`,
`START-SERVER.bat` (source-based launcher).

**Verified on the built exe, in a clean folder containing nothing but the exe:**
starts and serves the UI; all 67 endpoints present; no-cache headers active; creates
`storage/` beside itself; real PDF work succeeds through every bundled library —
merge, page render (PyMuPDF), compress, watermark (verified stamped), auto-redact
(verified PAN actually removed), CSV→PDF (reportlab), PDF→Word (pdf2docx),
PDF→Excel (pdfplumber+openpyxl), PDF→PPT (python-pptx), compare report, bulk apply
(zip verified). Then **stopped and restarted the exe and confirmed a created client
survived** — proving persistence is correct and not writing into the temp unpack dir.

Rebuild after code changes: `cd backend && venv\Scripts\python build_exe.py`

## 6-audit. Full-application audit (2026-08-05)

**Full-application audit (2026-08-05) — user reported "tool is not working properly".**

Root cause: **the server process was not running.** It had been started as a background
child of a dev shell, so it died silently when that session ended — no crash, no error,
the tool simply stopped answering. Everything else below was found while auditing.

Built an exhaustive automated audit (`81 checks` covering every one of the 67 endpoints
with real files and content-level assertions, not just status codes) plus a static
frontend↔backend contract cross-check. **Final state: 81/81 pass, contract CLEAN.**

Real bugs found and fixed:
1. **Server did not persist** → added `START-SERVER.bat` (double-click to run, with
   on-screen LAN IPs and a plain-English warning to keep the window open), and
   documented the "if the tool stops working" checklist in the README.
2. **OCR crashed with a raw `FileNotFoundError`** (unhandled) when ocrmypdf/Tesseract
   isn't installed, surfacing as an ugly 500. Now returns a clean 503 with install
   instructions, matching the LibreOffice/Ghostscript pattern. Also added a timeout
   and a specific message for "Tesseract not on PATH".
3. **The whole `optimize` router had no error handling at all** — any failure became a
   raw 500. Added the same `_run()` guard the other routers use.
4. **The `organize` router's service calls were unwrapped** — a corrupt PDF would throw
   a raw 500 instead of "Couldn't process this PDF… try Repair PDF first."
5. **Client Workspace was non-functional.** It was wired to a read-only list panel, so
   there was no way to create a client and it permanently read "Nothing here yet."
   Built a real `ClientWorkspacePanel` (add client → select → add matters, with
   PAN/GSTIN and FY). This was caught by the contract cross-check, not by clicking.
6. **Stale browser cache** — the recurring problem noted in earlier phases, and a
   likely contributor to "not working properly": the browser kept serving an old
   `index.html` even after updates. Fixed properly at the server: `/` and
   `/index.html` now send `no-store` headers. (Verified: confirmed the browser was
   showing a stale panel, then that the fix serves fresh content.)
7. **`storage/tmp/` grew without bound** — every upload and output stayed forever, which
   would eventually fill the office machine's disk. Added a startup sweep that deletes
   anything older than 48h (configurable via `CA_PDF_TOOL_TMP_HOURS`).
8. **Cosmetic but confusing**: compressing an already-optimised file reported
   "(-50% smaller)". Now says "X% larger — this file was already well optimised".

Also added: `CA_PDF_TOOL_DB` env override so test runs use a throwaway database. This
closes the process gap noted in the Phase 4 postmortem — audits no longer touch the
office DB at all.

Verified through the real UI (not just the API): file pick → page-count → chip grid →
Run → download, for Extract/Split/Rotate/Compress/Compliance/Page Numbers/Metadata;
drag-to-draw-a-box redaction; auto-redaction; Image→PDF; and the new Client Workspace
create-client-then-add-matter flow. One earlier "failure" of the draw-a-box feature
turned out to be the test firing mousedown/up in a single tick before React re-rendered
— with realistic drag timing it works correctly; noting it here so it isn't
re-investigated as a bug later.

**Still pending, unchanged (both need hardware/software this machine doesn't have):**
OCR real-run (needs Tesseract) and DSC/PKI signing (needs the physical USB token).

## 6-original. Phase-by-phase build status (kept for reference)

**Phase 5 additions (2026-08-05):**
- **Compare & Review**:
  - Compare Two PDFs — line-level diff (Python `difflib.SequenceMatcher` over each
    page's extracted text). Two output modes: a JSON summary (similarity %, lines
    added/removed, which pages changed) or a downloadable redline PDF report
    (reportlab, green=added/red=removed).
  - Track Changes View — page-by-page **visual** pixel diff (renders both versions
    at the same DPI, `PIL.ImageChops.difference`, highlights changed regions in red
    over a dimmed page). Complements the text diff — catches layout/image changes
    text extraction can't see (a moved stamp, a re-cropped scan). Only pages that
    actually differ are returned as a ZIP; if nothing differs, returns a plain
    message instead of an empty archive.
  - Annotate/Comment — sticky-note comments (click a point) and highlight boxes
    (drag a box) via `PagePicker`, same interaction pattern as Sign/Forms in Phase 4.
    **Hit and fixed a real PyMuPDF gotcha here**: `Page` objects hold a weak
    reference to their parent document, so re-fetching `doc[i]` fresh for every
    annotation lets the earlier wrapper get garbage-collected mid-use and breaks
    later `.update()` calls with a cryptic "weakly-referenced object no longer
    exists" error. Fixed by caching one page reference per page number and reusing
    it — documented with a comment in `compare.py` since it's a landmine other future
    annotation-heavy code could hit again.
- **Batch/Automation**:
  - Bulk Apply Tool — runs one operation across many files, ZIP of results. Built as
    a thin orchestration layer over a curated operation registry (compress, repair,
    sanitize, watermark, page numbers, rotate-all, password-protect) that calls the
    *already-tested* Phase 1-3 service functions directly — no logic duplicated.
  - Action Wizard — a chain of steps (from the same registry) applied in sequence to
    each file; output of step N feeds step N+1. The frontend step-builder lets you
    pick an operation, set its params, "+ Add step", repeat, then see the ordered
    chain with per-step remove buttons.
  - Auto File Naming / Bulk Rename — pattern-based renaming
    (`{client}_{pan}_{fy}_{n}` etc.), sharing one `rename_files()` engine; Auto
    Naming adds the Client/PAN/FY context fields, Bulk Rename is the bare pattern
    tool. Both guard against filename collisions two different ways: within a
    batch (two uploads with the same name — de-duplicated as `name(1).ext` before
    processing) and in the output (two files rendering to the same new name via a
    pattern without `{n}` — de-duplicated in the ZIP so one doesn't silently
    overwrite the other).
  - `GET /api/batch/operations` serves the operation registry (key, label, param
    specs) so the frontend never hardcodes the operation list — same pattern as
    `/api/security/patterns` from Phase 3.
- **Verified**: all 8 new endpoints exercised via `TestClient` with real files, then
  content-checked — line diff correctly identifies exactly the changed lines (tested
  against a draft/final pair with a deliberately altered revenue figure), the
  identical-files edge case correctly reports 100% similarity, visual diff correctly
  returns only the 2 pages that actually changed and correctly returns a "no
  differences" message for identical files, the redline PDF report contains both the
  old and new figures plus the similarity score, bulk watermark/wizard-chain outputs
  were opened and confirmed to actually contain the applied watermark/page-number
  text (not just "endpoint returned 200"), auto-name/rename ZIP filenames were
  checked entry-by-entry against the expected pattern substitution. Frontend
  re-verified live in-browser: Compare & Review and Batch/Automation both show all
  their tools "Ready", Bulk Apply's operation dropdown and dynamic param form
  populate live from the API, the Action Wizard step-builder was actually used to
  add a step and it appeared correctly in the ordered chain list, no console errors.
- **Process note**: kept up the DB-pollution discipline from the Phase 4 postmortem —
  noted the audit_log's max row ID before running any TestClient tests, then deleted
  every row above that ID after testing (verified each one was a `staff='tester'`
  row on a synthetic filename before deleting). Real `staff1` activity was
  untouched throughout.

## 6a. Phase 1 through 4 — original status (still true, kept for reference)

**Phase 4 additions (2026-08-05):**
- **Sign**:
  - Draw/Upload Signature ("quick_sign") — draw a freehand signature on an in-browser
    canvas, upload an image, or reuse a previously saved one, then drag a box on the
    rendered page (new `PagePicker` component) for where it goes. Optionally saves the
    signature to the DB (`signatures` table) for reuse next time.
  - Fill & Sign — same signature placement, plus free-text stamps (name/date/place)
    placed by clicking points on the rendered page.
  - Request Signatures — local-LAN tracked checklist (`signature_requests` table): a
    document + an ordered signer list, each signer marked "signed" from whichever
    office machine they're on. **No email is sent** — this is a shared-network
    checklist, not a DocuSign-style notification workflow; scoped that way because
    there's no external mail infra in this local-only deployment.
  - DSC/PKI Sign — real PKCS#11 signing via `pyhanko.sign.pkcs11.PKCS11Signer` +
    `sign_pdf`. **Not verified against real hardware** — there's no USB token in this
    sandbox. Code path was written directly against pyHanko's documented API and
    confirmed to fail *cleanly* (clear error message, not a crash) when pointed at a
    nonexistent driver path. Needs a real test once your token + vendor PKCS#11
    driver (a `.dll`) are available on the office machine.
- **Forms**: Auto-Detect Fields, Fill (general field-name → value filling — works for
  any AcroForm PDF including govt ITR/GST/TDS forms once you know their field names
  from Auto-Detect), Export Form Data (JSON view or downloadable CSV), Create
  Fillable Form (name a field, drag its box on the rendered page, repeat — supports
  text and checkbox field types). All via PyMuPDF's `Widget`/`page.widgets()` API.
- **Redact PDF got a new mode**: alongside the existing search-term redaction, there's
  now "Draw on page" — renders the page as an image, drag a box, true-removes
  whatever's under it (`PyMuPDF add_redact_annot`+`apply_redactions`, same
  true-removal mechanism as before, just area-selected instead of text-matched).
- **New shared infrastructure**:
  - `GET`-via-`POST` `/api/organize/render-page` — renders one PDF page to PNG at a
    given DPI, returns the DPI used in a response header. Backs every "click/drag on
    the page" interaction (redact-draw, signature/field placement).
  - `PagePicker` (frontend) — the reusable page-render + draw-box/click-point
    component. Coordinates are computed as a percentage of the rendered image (not
    raw pixels), converted to PDF point space via the DPI header, so it's
    resolution-independent. Used by Redact (draw mode), Quick Sign, Fill & Sign, and
    Create Fillable Form.
  - `SignaturePad` (frontend) — freehand canvas signature drawing, exports a PNG blob.
  - Two new DB tables: `signatures` (saved signature images) and `signature_requests`
    (multi-party signing checklist).
- **Not implemented / explicitly out of scope**: freeform coordinate-drag redaction
  existed already as a request — now built. What's *not* built: flattening filled
  form fields (they stay live/fillable, which is often preferable anyway), deleting a
  saved signature from the UI (the backend `DELETE /api/sign/signatures/{id}`
  endpoint exists and works, just no button wired to it yet).
- **Verified**: all 15 new endpoints exercised via `TestClient` with real files, then
  content-level checked — render-page PNG dimensions match the DPI math, redact-areas
  truly deletes text under the drawn box while leaving the rest of the page intact,
  signature placement actually embeds an image xref that wasn't there before,
  fill-and-sign has both the image and the text stamp, the full Forms lifecycle
  (create fields → detect → fill → export) round-trips correctly end to end, the
  signature-request workflow correctly flips to "completed" once every signer is
  marked. DSC signing confirmed to fail cleanly without hardware (not a real signing
  test). Frontend re-verified live in-browser: Sign and Forms both show all 4/4 tools
  "Ready", Redact PDF's new mode toggle renders and swaps correctly, DSC Sign's
  warning banner and full field set render, Create Fillable Form and Export Form
  Data render their tool-specific controls, no console errors throughout.
- **Important process note for future phases**: TestClient runs during development
  hit the *same* SQLite file the live server uses (`storage/ca_pdf_tool.db`) — there's
  no test/prod DB separation. Earlier in this phase, test data (fake signature
  requests, ~20 audit log rows under `staff='tester'`) briefly ended up mixed into
  the user's real database and had to be identified and removed by hand. Real user
  activity (staff `staff1`, real `GSTR3B_*.pdf` filenames) was left untouched — but
  next time, either add a DB path override for test runs, or clean up test rows
  immediately after each TestClient session, before moving on.

## 6b. Phase 1 + 2 + 3 — original status (still true, kept for reference)

**Phase 3 additions (2026-08-05):**
- **Edit** — 6 of 7 tools live: Add Page Numbers, Bates Numbering, Add/Remove
  Watermark (single tool, mode toggle — text or image watermark on add; best-effort
  true-text-removal on remove), Header/Footer (supports `{page}`/`{total}`
  placeholders — built for firm letterhead + UDIN lines), Crop PDF (per-side mm
  margins), Edit Metadata (title/author/subject/keywords/creator — prefilled from
  the file's existing metadata on selection). "Edit Text/Images/Shapes" (freeform
  content editing) stays "Coming soon" — it needs an interactive page canvas the
  current no-build-step single-file frontend doesn't have; out of scope until that
  changes.
- **Security** — all 6 tools live: Password Protect / Remove Password / Set
  Permissions (pypdf encryption, permission bit flags for print/copy/modify/
  annotate), Redact PDF (search-term based, **true removal** via PyMuPDF
  `add_redact_annot`+`apply_redactions`, not a visual overlay), Pattern
  Auto-Redaction (built-in PAN/GSTIN/Aadhaar/Mobile/Email/bank-account-number
  regexes + an optional custom regex, pattern list served from
  `GET /api/security/patterns` so the frontend never hardcodes it), Sanitize
  Document (strips metadata, XML metadata, embedded files).
  **Not implemented**: freeform coordinate/draw-a-box redaction — only
  search-term and pattern-based redaction, which covers the two brief items as
  specified but not "click and drag a redaction box anywhere."
- New files: `backend/app/services/edit.py`, `backend/app/services/security.py`,
  `backend/app/routers/edit.py`, `backend/app/routers/security.py`. `main.py` now
  includes both routers (44 endpoints total).
- Frontend: all 12 new tool cards flipped to "Ready" with real forms. Added shared
  components `PositionPicker` (6-anchor grid, reused by page numbers + Bates),
  `PagesField` (optional page-range text input, reused by ~8 tools), and
  `PermissionToggles` (print/copy/modify/annotate checkboxes, reused by Password
  Protect + Set Permissions).
- **Verified**: all 15 endpoints exercised via `TestClient` with real files, then
  **content-level verified** (not just status codes) — confirmed password
  protection actually encrypts (`reader.is_encrypted`), auto-redact truly deletes
  matched PAN/Aadhaar/GSTIN/mobile/email text (extracted text search returns
  `False` for all of them post-redaction) while leaving unrelated text intact,
  manual redact only touches the targeted page/term, Bates/page-number stamps
  contain the exact expected sequence, crop shrinks the page rect by the exact mm
  math, header/footer placeholder substitution works, metadata write/sanitize
  actually change/clear `doc.metadata`. Frontend re-verified live in-browser: Edit
  shows 6/7 Ready, Security shows 6/6 Ready, the Pattern Auto-Redaction modal's
  checklist is fetched live from the API (not hardcoded), the Watermark modal's
  Add/Remove toggle correctly swaps its fields, no console errors.
- **User has since tested live with real documents** — `storage/tmp/` shows a real
  GSTR-3B filing was uploaded and run through Redact successfully. That file was
  left untouched (it's the user's data, not test scaffolding) — clear
  `storage/tmp/` periodically per the README note when convenient.

## 6c. Phase 1 + 2 — original status (still true, kept for reference)

**Phase 2 additions (2026-08-05):**
- **Convert to PDF** — all 5 tools live: Word/Excel/PPT → PDF and HTML → PDF (both via
  LibreOffice headless, `soffice --headless --convert-to pdf`), CSV → PDF (pure-Python,
  `reportlab` bordered table — no external binary), JPG/Image → PDF and Scan → PDF
  (`img2pdf` with a Pillow fallback for awkward image modes).
- **Convert from PDF** — all 5 tools live: PDF → Word (`pdf2docx`), PDF → Excel
  (`pdfplumber` structured table extraction into one worksheet per table, with a
  plain-text-dump fallback if no tables are detected), PDF → PPT (each page rendered
  full-bleed onto one slide via PyMuPDF + `python-pptx`), PDF → JPG/PNG (batch, ZIP
  download, PyMuPDF render at selectable DPI), PDF → PDF/A (best-effort via
  Ghostscript's `pdfwrite` device — see note below).
- New files: `backend/app/services/convert.py`, `backend/app/routers/convert.py`.
  `main.py` now includes the `convert` router. `requirements.txt` gained
  `python-pptx`.
- Frontend: all 10 Convert tool cards flipped from "Coming soon" to "Ready" and wired
  with real forms (office/HTML/CSV/image pickers, PDF→Image format+DPI controls,
  PDF/A level selector). Image/Scan → PDF reuses the same drag-to-reorder chip list
  built for Merge, since multi-image page order matters the same way file order does.
- **Verified**: all 10 endpoints exercised end-to-end via FastAPI `TestClient` with
  real files — confirmed correct DOCX text, correct XLSX table cells (both the
  table-detected path and the text-fallback path), correct ZIP contents for
  PDF→Images, and valid multi-page output PDFs for Image→PDF/CSV→PDF. Missing
  LibreOffice/Ghostscript on the dev machine correctly produce a clean `503` with an
  install-it message rather than a crash. Frontend re-verified live in-browser
  (server + Browser pane) after the edit — Convert to/from PDF categories render all
  10 tools as "Ready", the CSV→PDF and PDF-picker modals open with the right fields,
  no console errors, other categories (Organize/Security/etc.) unaffected.
- **Not yet verified on real hardware**: LibreOffice- and Ghostscript-dependent paths
  (office_to_pdf/html_to_pdf/pdf_to_pdfa) only exercised via their clean-error path in
  this sandbox (neither binary is installed here). Once LibreOffice and Ghostscript
  are installed on the office machine, re-test Word/Excel/PPT→PDF, HTML→PDF, and
  PDF→PDF/A with real documents. Also worth noting: `pdf_to_pdfa`'s Ghostscript
  invocation is a best-effort structural conversion, not a certified PDF/A conformance
  check — validate output with veraPDF before relying on it for a compliance-critical
  filing.

## 6d. Phase 1 — original status (still true, kept for reference)

**Implemented and verified end-to-end:**
- Organize: Merge, Split (returns ZIP of parts), Extract, Delete Pages, Reorder,
  Rotate, Insert Pages, Combine+Bookmark — all tested via TestClient, all working.
- Optimize: Compress (quality mode + target-size mode with office-portal presets),
  Repair, Compliance Checker — tested, working. OCR wired but untested (needs
  `ocrmypdf` + Tesseract installed, which wasn't done in this sandboxed environment).
- CA Workflow: Client/Matter CRUD, Audit Trail log — tested, working.
- Every action writes to the Audit Trail (staff username, action, category, detail,
  timestamp).
- Frontend: full dashboard shell (sidebar/header/grid) per the design spec above,
  all 12 categories visible; only Organize+Optimize+Workspace tools are functionally
  wired — the rest render as "Coming soon" cards.

**UX iteration already done (based on real user testing):**
- Replaced raw "type JSON like `[1,2,5]`" inputs with:
  - Drag-and-drop chip reordering for **Merge** (file order) and **Reorder Pages**
    (page order) — native HTML5 drag events, no external library.
  - Tap-to-select page-number chip grids for **Extract / Delete / Rotate**
    (built from a real page count fetched via `/api/organize/page-count`).
  - Plain comma/range text for **Split** (`1-3,4-6`) instead of JSON.
  - One label input auto-generated per file for **Combine+Bookmark**.
  - Two distinct file pickers for **Insert Pages** (fixed a bug where a single
    multi-file input silently dropped the second file).
- Backend: all page-number/range parsing now accepts both JSON and plain
  comma/range syntax, and returns clean `400` errors with a human-readable message
  instead of crashing with a raw `500 Internal Server Error`. A global FastAPI
  exception handler was also added as a safety net.
- Compress: added a "Target file size" mode alongside the quality slider, with
  quick presets for Income Tax e-filing (5MB), GST Portal (5MB), MCA V3 (6MB),
  TRACES (5MB), WhatsApp (16MB), Email (25MB), or custom MB — backend does a
  step-down search through quality levels until the target is met.

**Known rough edges / things to double check when resuming:**
- OCR endpoint (`/api/optimize/ocr`) is implemented but never actually tested,
  since Tesseract isn't installed in the dev sandbox. Verify on the real office
  machine after installing `tesseract-ocr` + `tesseract-ocr-hin`.
- Compress's PyMuPDF-based image re-encoding is a reasonable first pass but not
  as aggressive as Ghostscript; consider adding a Ghostscript fallback path for
  harder compression targets in a later pass.
- No automated test suite yet — all verification so far was manual/scripted via
  `TestClient` in the sandbox, not a persisted pytest suite.
- The user hit a **stale browser cache** issue twice (old JSON-based UI kept
  showing after updates) — when resuming, be explicit that folder replacement
  must be a full delete+re-extract, not an overwrite, and a hard refresh
  (Ctrl+Shift+R) or fresh tab is required after every frontend change.

## 7. Phased roadmap (for what's next)

| Phase | Scope | Status |
|---|---|---|
| 1 | Backend skeleton, DB (Client/Matter/Audit), Organize, Optimize | ✅ Done, tested |
| 2 | Convert (to/from PDF) | ✅ Done, tested (LibreOffice/Ghostscript paths pending real-hardware retest) |
| 2b | OCR verification (needs Tesseract installed on office machine) | Not started |
| 3 | Edit + Security + Redaction | ✅ Done, tested (Edit Text/Images/Shapes intentionally deferred — needs a canvas UI) |
| 4 | Sign (DSC/PKI via pyHanko) + Forms | ✅ Done, tested (DSC/PKI signing pending real-token retest) |
| 5 | Compare + Batch/Automation | ✅ Done, tested |
| 6 | Polish pass on frontend — View & Navigate (Inline Viewer, Reader+Bookmarks) is the only category still "Coming soon"; general UI polish also still open | Not started |

## 8. Project structure (as of Phase 5)

```
ca-pdf-tool/
├── README.md                    # setup/run instructions for the office machine
├── backend/
│   ├── requirements.txt
│   ├── storage/                 # SQLite DB + tmp processing files; signatures/ + sign_requests/ subdirs persist, tmp/ is scratch
│   └── app/
│       ├── main.py               # FastAPI entrypoint, serves API + static frontend
│       ├── core/database.py      # SQLAlchemy engine/session (SQLite)
│       ├── models/db_models.py   # Staff, Client, Matter, FileRecord, AuditLog, Signature, SignatureRequest
│       ├── services/
│       │   ├── organize.py       # merge/split/extract/delete/reorder/rotate/insert/bookmark/render-page
│       │   ├── optimize.py       # compress/repair/OCR/compliance-check
│       │   ├── convert.py        # office/html/csv/image -> pdf; pdf -> word/excel/ppt/images/pdfa
│       │   ├── edit.py           # page numbers/bates/watermark/header-footer/crop/metadata
│       │   ├── security.py       # password/permissions/redact (text+area)/auto-redact/sanitize
│       │   ├── sign.py           # place-signature/fill-and-sign/dsc-sign
│       │   ├── forms.py          # detect/fill/export/create-fields (AcroForm widgets)
│       │   ├── compare.py        # text diff/redline report/visual diff/annotate
│       │   ├── batch.py          # operation registry, bulk apply, action-wizard chain, renaming
│       │   └── audit.py          # log_action() helper used by every router
│       └── routers/
│           ├── organize.py       # /api/organize/* endpoints (incl. render-page)
│           ├── optimize.py       # /api/optimize/* endpoints
│           ├── convert.py        # /api/convert/* endpoints
│           ├── edit.py           # /api/edit/* endpoints
│           ├── security.py       # /api/security/* endpoints (incl. redact-areas)
│           ├── sign.py           # /api/sign/* endpoints (signatures, place, dsc-sign, requests)
│           ├── forms.py          # /api/forms/* endpoints
│           ├── compare.py        # /api/compare/* endpoints
│           ├── batch.py          # /api/batch/* endpoints
│           └── workspace.py      # /api/workspace/* (clients, matters, audit-log)
└── frontend/
    └── index.html                 # entire UI — React+Tailwind via CDN, no build step
```

## 9. Suggested first message to Claude Code

> I'm continuing a CA-office PDF management tool. Read PROJECT_BRIEF.md for full
> context — Phase 1 (Organize + Optimize + Workspace) is done and tested. Please
> pick up at Phase 2: Convert to/from PDF, and verify OCR actually works once I've
> installed Tesseract. Keep the same architecture (FastAPI + SQLite + single-file
> React/Tailwind frontend, local-only deployment) and the same visual design spec
> in section 5 of the brief.

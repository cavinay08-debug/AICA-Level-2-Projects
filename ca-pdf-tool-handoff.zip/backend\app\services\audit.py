from sqlalchemy.orm import Session
from app.models.db_models import AuditLog


def log_action(db: Session, staff_username: str, action: str, tool_category: str,
                detail: str = "", file_id: int | None = None):
    entry = AuditLog(
        staff_username=staff_username or "unknown",
        action=action,
        tool_category=tool_category,
        detail=detail,
        file_id=file_id,
    )
    db.add(entry)
    db.commit()
    return entry

"""
Office PDF — Backend Entrypoint
Local desktop / office-LAN deployment only. No cloud, no external hosting.

Run with:
    uvicorn app.main:app --host 0.0.0.0 --port 8000

Then staff on the same office network open: http://<this-machine's-LAN-IP>:8000
(Find the LAN IP via `ipconfig` on Windows or `ifconfig`/`ip addr` on Linux/Mac.)
"""
import os
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse

from app.core.database import Base, engine
from app.core.paths import frontend_dir, storage_dir
from app.routers import (organize, optimize, workspace, convert, edit, security,
                          sign, forms, compare, batch, viewer)

# Create all tables on first run
Base.metadata.create_all(bind=engine)

app = FastAPI(title="Office PDF", version="0.7.0-complete")

# Office LAN only — CORS wide open here is fine since it never leaves the local network.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(organize.router)
app.include_router(optimize.router)
app.include_router(workspace.router)
app.include_router(convert.router)
app.include_router(edit.router)
app.include_router(security.router)
app.include_router(sign.router)
app.include_router(forms.router)
app.include_router(compare.router)
app.include_router(batch.router)
app.include_router(viewer.router)


@app.exception_handler(Exception)
async def friendly_error_handler(request: Request, exc: Exception):
    """Catch-all so staff see a plain message instead of a raw server trace."""
    return JSONResponse(status_code=500, content={"detail": f"Something went wrong: {exc}"})


TMP_DIR = os.path.join(storage_dir(), "tmp")
TMP_KEEP_HOURS = int(os.environ.get("CA_PDF_TOOL_TMP_HOURS", "48"))


@app.on_event("startup")
def purge_old_tmp_files():
    """Every upload and every generated file lands in storage/tmp and used to stay
    there forever — on a machine that runs for months that quietly fills the disk.
    Sweep anything older than TMP_KEEP_HOURS at startup (48h default, so a staff
    member's in-progress work from today is never touched). Set
    CA_PDF_TOOL_TMP_HOURS to change the window."""
    import shutil
    import time

    cutoff = time.time() - TMP_KEEP_HOURS * 3600
    removed = 0
    if not os.path.isdir(TMP_DIR):
        return
    for entry in os.scandir(TMP_DIR):
        try:
            if entry.stat().st_mtime >= cutoff:
                continue
            if entry.is_dir():
                shutil.rmtree(entry.path, ignore_errors=True)
            else:
                os.remove(entry.path)
            removed += 1
        except OSError:
            pass  # locked/in-use file — leave it, next restart will get it
    if removed:
        print(f"[startup] cleared {removed} temp item(s) older than {TMP_KEEP_HOURS}h from storage/tmp")

FRONTEND_DIR = frontend_dir()

# The whole UI lives in one index.html. Browsers cache that aggressively, which has
# repeatedly left staff looking at a stale build after an update and reporting
# "the tool is broken" — so serve it explicitly with no-store. It's a single local
# file on the office LAN; there's nothing to gain from caching it.
NO_CACHE = {
    "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
    "Pragma": "no-cache",
    "Expires": "0",
}


@app.get("/", include_in_schema=False)
async def serve_index():
    return FileResponse(os.path.join(FRONTEND_DIR, "index.html"),
                         media_type="text/html", headers=NO_CACHE)


@app.get("/index.html", include_in_schema=False)
async def serve_index_explicit():
    return await serve_index()


app.mount("/", StaticFiles(directory=FRONTEND_DIR, html=True), name="frontend")

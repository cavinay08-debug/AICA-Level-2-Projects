import os
import uuid
from fastapi import APIRouter, UploadFile, File, Form, Depends, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.paths import storage_dir
from app.services import optimize as svc
from app.services.audit import log_action

router = APIRouter(prefix="/api/optimize", tags=["optimize"])

STORAGE = os.path.join(storage_dir(), "tmp")
os.makedirs(STORAGE, exist_ok=True)


def _save_upload(f: UploadFile) -> str:
    path = os.path.join(STORAGE, f"{uuid.uuid4().hex}_{f.filename}")
    with open(path, "wb") as out:
        out.write(f.file.read())
    return path


def _run(fn, *args, **kwargs):
    """Turns known failure modes into clean HTTP errors instead of a raw 500 —
    missing external tool (ocrmypdf/Tesseract) -> 503, bad input -> 400."""
    try:
        return fn(*args, **kwargs)
    except RuntimeError as e:
        msg = str(e)
        status = 503 if ("isn't installed" in msg or "isn't available" in msg) else 400
        raise HTTPException(status, msg)
    except Exception as e:
        raise HTTPException(400, f"Couldn't process this file: {e}")


@router.post("/compress")
async def compress(file: UploadFile = File(...), quality: int = Form(60), staff: str = Form("unknown"),
                    db: Session = Depends(get_db)):
    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"compressed_{uuid.uuid4().hex}.pdf")
    _run(svc.compress_pdf, path, out_path, quality)
    before = os.path.getsize(path)
    after = os.path.getsize(out_path)
    log_action(db, staff, "COMPRESS", "OPTIMIZE",
               detail=f"{file.filename}: {before/1024:.0f}KB -> {after/1024:.0f}KB (q={quality})")
    return FileResponse(
        out_path, filename="compressed.pdf", media_type="application/pdf",
        headers={
            "X-Original-Size-KB": str(round(before / 1024, 1)),
            "X-Compressed-Size-KB": str(round(after / 1024, 1)),
            "Access-Control-Expose-Headers": "X-Original-Size-KB, X-Compressed-Size-KB",
        },
    )


@router.post("/compress-to-size")
async def compress_to_size(file: UploadFile = File(...), target_mb: float = Form(...),
                            staff: str = Form("unknown"), db: Session = Depends(get_db)):
    """Compress until the file fits under target_mb (or the lowest usable quality is reached)."""
    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"compressed_{uuid.uuid4().hex}.pdf")
    summary = _run(svc.compress_pdf_to_target, path, out_path, target_mb)
    log_action(db, staff, "COMPRESS_TO_SIZE", "OPTIMIZE",
               detail=f"{file.filename}: target {target_mb}MB -> {summary['final_size_mb']}MB "
                      f"(q={summary['achieved_quality']}, met={summary['target_met']})")
    return FileResponse(
        out_path, filename="compressed.pdf", media_type="application/pdf",
        headers={
            "X-Original-Size-MB": str(summary["original_size_mb"]),
            "X-Compressed-Size-MB": str(summary["final_size_mb"]),
            "X-Target-Met": str(summary["target_met"]),
            "Access-Control-Expose-Headers": "X-Original-Size-MB, X-Compressed-Size-MB, X-Target-Met",
        },
    )


@router.post("/repair")
async def repair(file: UploadFile = File(...), staff: str = Form("unknown"), db: Session = Depends(get_db)):
    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"repaired_{uuid.uuid4().hex}.pdf")
    _run(svc.repair_pdf, path, out_path)
    log_action(db, staff, "REPAIR", "OPTIMIZE", detail=file.filename)
    return FileResponse(out_path, filename="repaired.pdf", media_type="application/pdf")


@router.post("/ocr")
async def ocr(file: UploadFile = File(...), languages: str = Form("eng+hin"), staff: str = Form("unknown"),
              db: Session = Depends(get_db)):
    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"ocr_{uuid.uuid4().hex}.pdf")
    _run(svc.ocr_pdf, path, out_path, languages)
    log_action(db, staff, "OCR", "OPTIMIZE", detail=f"{file.filename} ({languages})")
    return FileResponse(out_path, filename="searchable.pdf", media_type="application/pdf")


@router.post("/compliance-check")
async def compliance_check(file: UploadFile = File(...), portal: str = Form("default"),
                            staff: str = Form("unknown"), db: Session = Depends(get_db)):
    path = _save_upload(file)
    result = _run(svc.check_portal_compliance, path, portal)
    log_action(db, staff, "COMPLIANCE_CHECK", "OPTIMIZE", detail=f"{file.filename}: {result['message']}")
    return result

import json
import os
import uuid
from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.paths import storage_dir
from app.models.db_models import Signature, SignatureRequest
from app.services import sign as svc
from app.services.audit import log_action

router = APIRouter(prefix="/api/sign", tags=["sign"])

STORAGE = os.path.join(storage_dir(), "tmp")
SIGNATURES_DIR = os.path.join(storage_dir(), "signatures")
REQUESTS_DIR = os.path.join(storage_dir(), "sign_requests")
os.makedirs(STORAGE, exist_ok=True)
os.makedirs(SIGNATURES_DIR, exist_ok=True)
os.makedirs(REQUESTS_DIR, exist_ok=True)


def _save_upload(f: UploadFile, directory: str = STORAGE) -> str:
    path = os.path.join(directory, f"{uuid.uuid4().hex}_{f.filename}")
    with open(path, "wb") as out:
        out.write(f.file.read())
    return path


def _run(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs)
    except RuntimeError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        raise HTTPException(400, f"Couldn't process this file: {e}")


def _parse_json_list(raw: str, field_name: str) -> list:
    try:
        parsed = json.loads(raw)
        if not isinstance(parsed, list):
            raise ValueError
        return parsed
    except (json.JSONDecodeError, ValueError, TypeError):
        raise HTTPException(400, f"Couldn't read {field_name} — expected a JSON list.")


# ---------------------------------------------------------------------------
# Saved signatures (draw once, reuse everywhere)
# ---------------------------------------------------------------------------
@router.post("/signatures")
async def save_signature(image: UploadFile = File(...), label: str = Form("My signature"),
                          staff: str = Form("unknown"), db: Session = Depends(get_db)):
    path = _save_upload(image, SIGNATURES_DIR)
    rec = Signature(staff_username=staff, label=label, image_path=path)
    db.add(rec)
    db.commit()
    db.refresh(rec)
    log_action(db, staff, "SAVE_SIGNATURE", "SIGN", detail=label)
    return {"id": rec.id, "label": rec.label, "staff_username": rec.staff_username}


@router.get("/signatures")
async def list_signatures(staff: Optional[str] = None, db: Session = Depends(get_db)):
    q = db.query(Signature)
    if staff:
        q = q.filter(Signature.staff_username == staff)
    return [{"id": s.id, "label": s.label, "staff_username": s.staff_username} for s in q.order_by(Signature.created_at.desc()).all()]


@router.get("/signatures/{sig_id}/image")
async def get_signature_image(sig_id: int, db: Session = Depends(get_db)):
    rec = db.query(Signature).filter(Signature.id == sig_id).first()
    if not rec or not os.path.exists(rec.image_path):
        raise HTTPException(404, "Signature not found.")
    return FileResponse(rec.image_path, media_type="image/png")


@router.delete("/signatures/{sig_id}")
async def delete_signature(sig_id: int, db: Session = Depends(get_db)):
    rec = db.query(Signature).filter(Signature.id == sig_id).first()
    if not rec:
        raise HTTPException(404, "Signature not found.")
    if os.path.exists(rec.image_path):
        os.remove(rec.image_path)
    db.delete(rec)
    db.commit()
    return {"deleted": sig_id}


# ---------------------------------------------------------------------------
# Placing a signature / fill & sign
# ---------------------------------------------------------------------------
@router.post("/place")
async def place(file: UploadFile = File(...), placements: str = Form(...),
                 signature_id: Optional[int] = Form(None), image: Optional[UploadFile] = File(None),
                 staff: str = Form("unknown"), db: Session = Depends(get_db)):
    placement_list = _parse_json_list(placements, "placements")
    if signature_id:
        rec = db.query(Signature).filter(Signature.id == signature_id).first()
        if not rec or not os.path.exists(rec.image_path):
            raise HTTPException(404, "Saved signature not found.")
        image_path = rec.image_path
    elif image:
        image_path = _save_upload(image)
    else:
        raise HTTPException(400, "Choose a saved signature or upload a signature image.")

    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"signed_{uuid.uuid4().hex}.pdf")
    _run(svc.place_signature, path, out_path, image_path, placement_list)
    log_action(db, staff, "PLACE_SIGNATURE", "SIGN", detail=f"{file.filename}: {len(placement_list)} placement(s)")
    return FileResponse(out_path, filename="signed.pdf", media_type="application/pdf")


@router.post("/fill-and-sign")
async def fill_and_sign(file: UploadFile = File(...), placements: str = Form("[]"),
                         text_stamps: str = Form("[]"), signature_id: Optional[int] = Form(None),
                         image: Optional[UploadFile] = File(None), staff: str = Form("unknown"),
                         db: Session = Depends(get_db)):
    placement_list = _parse_json_list(placements, "placements") if placements.strip() else []
    stamp_list = _parse_json_list(text_stamps, "text stamps") if text_stamps.strip() else []

    image_path = ""
    if signature_id:
        rec = db.query(Signature).filter(Signature.id == signature_id).first()
        if not rec or not os.path.exists(rec.image_path):
            raise HTTPException(404, "Saved signature not found.")
        image_path = rec.image_path
    elif image:
        image_path = _save_upload(image)

    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"filled_signed_{uuid.uuid4().hex}.pdf")
    _run(svc.fill_and_sign, path, out_path, image_path, placement_list, stamp_list)
    log_action(db, staff, "FILL_AND_SIGN", "SIGN",
               detail=f"{file.filename}: {len(placement_list)} sig, {len(stamp_list)} text stamp(s)")
    return FileResponse(out_path, filename="filled_signed.pdf", media_type="application/pdf")


@router.post("/dsc-sign")
async def dsc_sign(file: UploadFile = File(...), pkcs11_lib_path: str = Form(...), user_pin: str = Form(...),
                    token_label: str = Form(""), cert_label: str = Form(""), reason: str = Form(""),
                    location: str = Form(""), field_name: str = Form("Signature1"),
                    staff: str = Form("unknown"), db: Session = Depends(get_db)):
    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"dsc_signed_{uuid.uuid4().hex}.pdf")
    _run(svc.dsc_sign_pdf, path, out_path, pkcs11_lib_path, user_pin, token_label, cert_label,
         reason, location, field_name)
    log_action(db, staff, "DSC_SIGN", "SIGN", detail=f"{file.filename}: field={field_name}")
    return FileResponse(out_path, filename="dsc_signed.pdf", media_type="application/pdf")


# ---------------------------------------------------------------------------
# Signature requests — local-LAN tracked checklist, no email
# ---------------------------------------------------------------------------
@router.post("/requests")
async def create_request(file: UploadFile = File(...), signer_names: str = Form(...),
                          requested_by: str = Form("unknown"), db: Session = Depends(get_db)):
    names = [n.strip() for n in signer_names.split(",") if n.strip()]
    if not names:
        raise HTTPException(400, "Enter at least one signer name.")
    path = _save_upload(file, REQUESTS_DIR)
    signers = [{"name": n, "status": "pending", "signed_at": None} for n in names]
    rec = SignatureRequest(document_filename=file.filename, document_path=path,
                            requested_by=requested_by, signers=json.dumps(signers), status="pending")
    db.add(rec)
    db.commit()
    db.refresh(rec)
    log_action(db, requested_by, "CREATE_SIGN_REQUEST", "SIGN", detail=f"{file.filename}: signers={names}")
    return {"id": rec.id, "document_filename": rec.document_filename, "signers": signers, "status": rec.status}


@router.get("/requests")
async def list_requests(db: Session = Depends(get_db)):
    rows = db.query(SignatureRequest).order_by(SignatureRequest.created_at.desc()).all()
    return [{"id": r.id, "document_filename": r.document_filename, "requested_by": r.requested_by,
             "signers": json.loads(r.signers), "status": r.status,
             "created_at": r.created_at.isoformat() if r.created_at else None} for r in rows]


@router.get("/requests/{req_id}/document")
async def download_request_document(req_id: int, db: Session = Depends(get_db)):
    rec = db.query(SignatureRequest).filter(SignatureRequest.id == req_id).first()
    if not rec or not os.path.exists(rec.document_path):
        raise HTTPException(404, "Request or document not found.")
    return FileResponse(rec.document_path, filename=rec.document_filename, media_type="application/pdf")


@router.post("/requests/{req_id}/mark-signed")
async def mark_signed(req_id: int, signer_name: str = Form(...),
                       signed_file: Optional[UploadFile] = File(None), db: Session = Depends(get_db)):
    rec = db.query(SignatureRequest).filter(SignatureRequest.id == req_id).first()
    if not rec:
        raise HTTPException(404, "Signature request not found.")
    signers = json.loads(rec.signers)
    match = next((s for s in signers if s["name"] == signer_name), None)
    if not match:
        raise HTTPException(400, f"'{signer_name}' isn't on this request's signer list.")
    match["status"] = "signed"
    match["signed_at"] = datetime.utcnow().isoformat()
    rec.signers = json.dumps(signers)
    if signed_file:
        rec.document_path = _save_upload(signed_file, REQUESTS_DIR)
    if all(s["status"] == "signed" for s in signers):
        rec.status = "completed"
    db.commit()
    log_action(db, signer_name, "MARK_SIGNED", "SIGN", detail=f"request #{req_id}")
    return {"id": rec.id, "signers": signers, "status": rec.status}

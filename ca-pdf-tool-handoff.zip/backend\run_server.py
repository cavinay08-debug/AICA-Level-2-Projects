"""
Entry point for the packaged Office PDF .exe.

Double-clicking the exe runs this: it starts the web server, prints the addresses
staff should open, and keeps running until the window is closed.

Build with:  python build_exe.py
"""
import os
import socket
import sys
import webbrowser

PORT = int(os.environ.get("CA_PDF_TOOL_PORT", "8000"))


def lan_ips():
    """Best-effort list of this machine's LAN addresses, so staff know what to type."""
    ips = []
    try:
        # the address used to reach the outside world = the real LAN NIC
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ips.append(s.getsockname()[0])
        s.close()
    except Exception:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if not ip.startswith("127.") and ip not in ips:
                ips.append(ip)
    except Exception:
        pass
    return ips


def main():
    # Bundled builds must not inherit a stray dev DB path from the environment.
    os.environ.pop("CA_PDF_TOOL_DB", None)

    import uvicorn
    from app.core.paths import data_dir, storage_dir

    ips = lan_ips()
    bar = "=" * 62
    print(bar)
    print("  OFFICE PDF")
    print(bar)
    print()
    print("  On THIS computer:")
    print(f"      http://localhost:{PORT}")
    if ips:
        print()
        print("  From other computers on the office network:")
        for ip in ips:
            print(f"      http://{ip}:{PORT}")
    else:
        print()
        print("  (Could not detect a network address - run 'ipconfig' to find it.)")
    print()
    print(f"  Your data is stored in:  {os.path.join(data_dir(), 'storage')}")
    print("  Back that folder up regularly - it holds the database and signatures.")
    print()
    print(bar)
    print("  KEEP THIS WINDOW OPEN while staff are using the tool.")
    print("  Closing it stops the server for everyone.")
    print(bar)
    print()

    storage_dir()  # make sure the folder exists before the first request

    if os.environ.get("CA_PDF_TOOL_NO_BROWSER") != "1":
        try:
            webbrowser.open(f"http://localhost:{PORT}")
        except Exception:
            pass

    try:
        uvicorn.run("app.main:app", host="0.0.0.0", port=PORT, log_level="warning")
    except KeyboardInterrupt:
        pass
    except Exception as e:
        print()
        print(f"  [!] The server stopped with an error: {e}")
        if "address already in use" in str(e).lower() or "10048" in str(e):
            print(f"  [!] Port {PORT} is already in use - the tool may already be running.")
        print()
        input("  Press Enter to close...")
        sys.exit(1)


if __name__ == "__main__":
    main()

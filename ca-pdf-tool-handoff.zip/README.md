# Office PDF

Local-only. Either run it as a shared web server for the office LAN, or as your
own native desktop app (with file-association support — set it as your default
PDF viewer and double-click any PDF to open it). Nothing goes to the internet or
cloud — even the frontend's JS libraries are bundled locally, not loaded from a
CDN, so it keeps working with no internet connection at all.

## What's included so far

- **Organize**: Merge, Split, Extract Pages, Delete Pages, Reorder, Rotate, Insert Pages, Combine+Auto-Bookmark
- **Optimize**: Compress (quality slider), Repair, OCR (multi-language incl. Hindi), Portal Compliance Checker (IT/GST/MCA size limits)
- **Convert to PDF**: Word/Excel/PPT → PDF, HTML → PDF (both need LibreOffice), CSV → PDF, Image/Scan → PDF
- **Convert from PDF**: PDF → Word, PDF → Excel (structured tables), PDF → PPT, PDF → JPG/PNG (batch ZIP), PDF → PDF/A (needs Ghostscript)
- **Edit**: Add Page Numbers, Add/Remove Watermark, Header/Footer, Crop, Edit Metadata, Bates Numbering. ("Edit Text/Images/Shapes" is not built — needs an interactive canvas.)
- **Security**: Password Protect/Remove, Set Permissions, Redact — both search-text and draw-a-box-on-the-page (true text removal either way), Pattern Auto-Redaction (PAN/GSTIN/Aadhaar/Mobile/Email/bank account), Sanitize (strip hidden metadata)
- **Sign**: Draw/Upload Signature, Fill & Sign (signature + text stamps placed by clicking the rendered page), Request Signatures (local-LAN tracked checklist, no email), DSC/PKI Sign (needs your physical USB token + driver — not yet tested against real hardware)
- **Forms**: Auto-Detect Fields, Fill (general field-name → value filling, works for any AcroForm PDF incl. govt ITR/GST/TDS forms), Export Form Data (JSON or CSV), Create Fillable Form (drag a box on the page to add a field)
- **Compare & Review**: Compare Two PDFs (text diff summary or a downloadable redline PDF report), Track Changes View (visual page-by-page diff, highlights what actually moved/changed), Annotate/Comment (sticky notes + highlights placed by clicking/dragging on the page)
- **Batch/Automation**: Bulk Apply Tool (one operation across many files), Action Wizard (chain several operations in sequence), Auto File Naming (Client/PAN/FY pattern), Bulk Rename (pattern-based)
- **CA Workflow**: Client/Matter workspace, Audit Trail log
- **View & Navigate**: a full PDF viewer — open, page navigation, zoom/fit, a
  collapsible side panel (thumbnails / bookmarks / full-text search), highlight,
  freehand draw, sticky notes (all saved back into a real PDF), and print.

## One-time setup (on the office server machine)

1. Install Python 3.11+.
2. Install system dependencies (outside pip):
   - **Tesseract OCR** (+ Hindi/regional language packs): `tesseract-ocr`, `tesseract-ocr-hin` — needed for OCR (not yet verified on real hardware, see Phase 2b)
   - **LibreOffice** — needed for Word/Excel/PPT → PDF and HTML → PDF. Without it those
     two tools return a clear "LibreOffice isn't installed" error instead of crashing.
   - **Ghostscript** — needed for PDF → PDF/A. Same clean-error behavior if missing.
   Everything else (Convert to/from PDF's other tools, Organize, Optimize's
   compress/repair) is pure-pip and needs no system install.
3. From `backend/`:
   ```
   python -m venv venv
   venv\Scripts\activate        (Windows)   OR   source venv/bin/activate   (Mac/Linux)
   pip install -r requirements.txt
   ```

## Running it

There are two standalone .exe builds — no Python, no install, no dependencies
either way. Full details in `HOW-TO-INSTALL-ON-ANOTHER-PC.txt`.

**`Office-PDF-Desktop.exe`** — a real desktop app. Its own window, no browser
chrome. Can be set as your default PDF viewer (button in the sidebar), so
double-clicking any PDF opens it straight into the viewer. Rebuild with:
```
cd backend
venv\Scripts\python build_desktop_exe.py
```

**`CA-PDF-Tool.exe`** — runs the tool as a shared web server; other staff reach
it from their own browsers over the LAN. Put it in its own folder (e.g.
`C:\Office-PDF-Server\`) and double-click it — it creates a `storage\` folder
beside itself for the database and files. Rebuild with:
```
cd backend
venv\Scripts\python build_exe.py
```

**From source instead:** double-click **`START-SERVER.bat`** in this folder.

Keep the black window it opens **OPEN** while staff are using the tool — closing that
window stops the server and the tool goes offline for everyone. To stop it deliberately,
close the window or press Ctrl+C in it.

Or start it manually:
```
cd backend
venv\Scripts\python -m uvicorn app.main:app --host 0.0.0.0 --port 8000
```

### If the tool "stops working"

Nine times out of ten one of these two things has happened:

1. **The server isn't running.** Every page just fails to load / "can't reach this site".
   Fix: double-click `START-SERVER.bat` again. The server does not survive a reboot or
   the window being closed — see below to make it automatic.
2. **The browser is showing a cached copy of an old UI.** The server now sends
   no-cache headers to prevent this, but if you ever suspect it, press
   **Ctrl+Shift+R** (hard refresh) or open a fresh tab.

Find this machine's LAN IP:
- Windows: `ipconfig` → look for IPv4 Address
- Mac/Linux: `ifconfig` or `ip addr`

Every staff member then opens, from their own computer on the same office network:
```
http://<server-LAN-IP>:8000
```

To make this permanent (auto-start with Windows), wrap the uvicorn command in a
`.bat` file placed in the Startup folder, or use NSSM to run it as a Windows service.

## About the DSC (Digital Signature Certificate)

DSC/PKI signing is built (Security > Sign > DSC/PKI Sign) via `pyHanko`, which
supports PKCS#11 USB tokens — the same kind CAs use for ITR/GST/ROC filings. Plug
your physical DSC token into the server machine, install its vendor PKCS#11 driver
(a `.dll` file, e.g. from ePass2003, Watchdata, or ProxKey), then enter that driver's
path + your token PIN in the tool. **This hasn't been tested against a real token
yet** — it was built directly against pyHanko's documented API and confirmed to fail
cleanly (not crash) when pointed at a nonexistent driver, but the actual signing path
needs a real run once your token is plugged in here.

## Data & privacy

- SQLite database file lives at `backend/storage/ca_pdf_tool.db` — back this up regularly.
- Uploaded/processed files pass through `backend/storage/tmp/` — safe to clear periodically.
- Saved signatures (`backend/storage/signatures/`) and signature-request documents
  (`backend/storage/sign_requests/`) persist — these aren't scratch files, don't
  auto-clear them the way you would `tmp/`.
- `storage/tmp/` is now **cleaned automatically**: on every server start, anything
  older than 48 hours is deleted. Today's work is never touched. To change the
  window, set the `CA_PDF_TOOL_TMP_HOURS` environment variable before starting.
- No data leaves the office network at any point.

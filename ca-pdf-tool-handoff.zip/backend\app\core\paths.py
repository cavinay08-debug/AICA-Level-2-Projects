"""
Path resolution that works both from source and from a PyInstaller .exe.

When frozen with --onefile, PyInstaller unpacks the bundled code to a throwaway temp
folder (sys._MEIPASS) that is deleted on exit. Read-only assets (the frontend) live
there; anything the office needs to KEEP (the database, saved signatures, processed
files) must instead sit next to the .exe, or staff would silently lose their data
every time they closed the program.
"""
import os
import sys


def is_frozen() -> bool:
    return getattr(sys, "frozen", False)


def bundle_dir() -> str:
    """Read-only bundled assets (frontend/). PyInstaller's temp unpack dir when
    frozen; the project root when running from source."""
    if is_frozen():
        return getattr(sys, "_MEIPASS", os.path.dirname(sys.executable))
    # this file is backend/app/core/paths.py -> up 3 gives the ca-pdf-tool/ root,
    # which is where frontend/ lives alongside backend/
    return os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))


def data_dir() -> str:
    """Writable, PERSISTENT location for the DB and all stored files.
    Next to the .exe when frozen; backend/ when running from source."""
    if is_frozen():
        base = os.path.dirname(os.path.abspath(sys.executable))
    else:
        base = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
    return base


def storage_dir() -> str:
    path = os.environ.get("CA_PDF_TOOL_STORAGE") or os.path.join(data_dir(), "storage")
    os.makedirs(path, exist_ok=True)
    return path


def frontend_dir() -> str:
    """The single-file UI. Bundled into the exe, but allow an override so an office
    can hot-patch the UI next to the exe without a rebuild."""
    override = os.path.join(data_dir(), "frontend")
    if os.path.isfile(os.path.join(override, "index.html")):
        return override
    return os.path.join(bundle_dir(), "frontend")

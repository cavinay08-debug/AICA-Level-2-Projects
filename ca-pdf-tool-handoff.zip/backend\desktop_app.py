"""
Desktop-app entry point for Office PDF.

Unlike run_server.py (which opens the tool in the user's normal web browser),
this launches it in its OWN native window — the FastAPI/uvicorn server still runs
underneath, but headless in a background thread, so from the user's point of view
it's just a regular Windows application with no browser chrome, no address bar,
and no other browser tabs to get confused with.

This is also the file-association target: "Open with > Office PDF" / setting it as
the default PDF viewer runs this exe with the PDF's path as argv[1].

Build into an exe with:  python build_desktop_exe.py
"""
import io
import os
import sys
import threading
import time

PORT = int(os.environ.get("CA_PDF_TOOL_PORT", "8173"))  # high, unusual port: avoid clashing with the server .exe on 8000

# A --windowed / pythonw process has NO console, so sys.stdout and sys.stderr are
# literally None (not a null stream — actually None). Plenty of libraries assume
# they can always call sys.stdout.write(...) or sys.stdout.isatty() — uvicorn's
# default log formatter does exactly that and crashes with
# "AttributeError: 'NoneType' object has no attribute 'isatty'" the moment it
# tries to configure logging. Give them harmless no-op streams instead of None.
if sys.stdout is None:
    sys.stdout = io.StringIO()
if sys.stderr is None:
    sys.stderr = io.StringIO()


class DesktopApi:
    """Exposed to the frontend ONLY inside the desktop app window via pywebview's
    js_api bridge (window.pywebview.api.* — never an HTTP route). That distinction
    matters: this same backend also runs as a plain LAN server for other staff PCs,
    and a registry-writing action must never be reachable from a browser tab over
    the network, only from this specific local native window."""

    def register_pdf_handler(self):
        return _register_as_pdf_handler(show_box=False)

    def is_desktop(self):
        return True


def _register_as_pdf_handler(show_box=True):
    """Registers this exe as an available PDF opener for the current Windows user
    (HKEY_CURRENT_USER only — no admin rights needed, no elevation prompt).

    This does NOT silently make it the default — Windows has blocked apps from
    doing that since Windows 8 for security reasons. It only makes "Office PDF"
    show up by name in the right-click > Open With list, so the user can pick it
    and tick "Always use this app" themselves. That confirm step is the
    Windows-sanctioned way to set a per-user default; nothing here bypasses it."""
    import winreg

    exe = os.path.abspath(sys.executable)
    app_key = r"Software\Classes\Applications\Office-PDF-Desktop.exe"
    try:
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, app_key + r"\shell\open\command") as k:
            winreg.SetValue(k, "", winreg.REG_SZ, f'"{exe}" "%1"')
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, app_key) as k:
            winreg.SetValueEx(k, "FriendlyAppName", 0, winreg.REG_SZ, "Office PDF")
        # Also list it for the .pdf extension specifically via OpenWithList, so it
        # appears immediately without the user having to "browse for another app".
        ext_key = r"Software\Classes\.pdf\OpenWithList\Office-PDF-Desktop.exe"
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, ext_key):
            pass
        ok, msg = True, ("Office PDF is now registered.\n\n"
                          "To make it your default PDF viewer:\n"
                          "Right-click any PDF -> Open with -> Office PDF -> "
                          "tick 'Always use this app', then OK.")
    except OSError as e:
        ok, msg = False, f"Could not register: {e}"
    if show_box:
        # This build is --windowed (no console), so a message box is the only way
        # the user sees the result when triggered via --register from a shortcut.
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, msg, "Office PDF", 0x40 if ok else 0x10)
    return {"ok": ok, "message": msg}


def _pdf_path_from_argv() -> str | None:
    """When launched via 'Open with' or as the default PDF viewer, Windows passes
    the file path as the first argument."""
    for arg in sys.argv[1:]:
        if arg.lower().endswith(".pdf") and os.path.isfile(arg):
            return os.path.abspath(arg)
    return None


def _log_path():
    base = os.path.dirname(os.path.abspath(sys.executable if getattr(sys, "frozen", False) else __file__))
    return os.path.join(base, "office-pdf-crash.log")


def _run_server_thread():
    # This is a --windowed build (no console), so an exception here would
    # otherwise vanish silently and the window would just show a blank/error
    # page with no clue why. Write anything that goes wrong to a log file next
    # to the exe instead.
    #
    # Deliberately NOT using uvicorn.run() here: it assumes it owns the process's
    # main thread (installs SIGINT/SIGTERM handlers, manages the asyncio event
    # loop policy), which doesn't hold when it's started from a background thread
    # inside a frozen GUI app — the server can end up silently never binding its
    # port. Running Server.serve() on an explicit event loop we own is the
    # documented pattern for embedding uvicorn outside the main thread.
    try:
        import asyncio
        import uvicorn
        from app.main import app

        with open(_log_path(), "a", encoding="utf-8") as f:
            f.write(f"\n--- server thread starting on port {PORT} ---\n")

        # log_config=None: skip uvicorn's own dictConfig-based logging setup
        # entirely — we don't need console-formatted logs in a GUI app, and it's
        # one less thing that can assume a real console exists.
        config = uvicorn.Config(app, host="127.0.0.1", port=PORT, log_level="warning", log_config=None)
        server = uvicorn.Server(config)
        server.install_signal_handlers = lambda: None  # only valid on the main thread; skip entirely

        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(server.serve())
    except Exception:
        import traceback
        try:
            with open(_log_path(), "a", encoding="utf-8") as f:
                f.write(f"\n--- server thread crashed ---\n{traceback.format_exc()}\n")
        except Exception:
            pass


def _wait_for_server(timeout=20):
    import urllib.request
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{PORT}/", timeout=1)
            return True
        except Exception:
            time.sleep(0.25)
    return False


_WEBVIEW2_CLIENT_GUID = r"{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"


def _has_webview2_runtime() -> bool:
    """pywebview's Windows backend needs the Microsoft Edge WebView2 Runtime.
    Recent Windows 11 ships it pre-installed; plenty of Windows 10 machines (and
    locked-down office images) do not, and there's no in-box prompt to get it —
    pywebview just fails. Check the same registry keys the WebView2 installer
    itself writes, in the same order Microsoft's own detection sample does."""
    import winreg
    keys = [
        (winreg.HKEY_LOCAL_MACHINE, rf"SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{_WEBVIEW2_CLIENT_GUID}"),
        (winreg.HKEY_LOCAL_MACHINE, rf"SOFTWARE\Microsoft\EdgeUpdate\Clients\{_WEBVIEW2_CLIENT_GUID}"),
        (winreg.HKEY_CURRENT_USER, rf"SOFTWARE\Microsoft\EdgeUpdate\Clients\{_WEBVIEW2_CLIENT_GUID}"),
    ]
    for hive, path in keys:
        try:
            with winreg.OpenKey(hive, path) as k:
                version, _ = winreg.QueryValueEx(k, "pv")
                if version and version != "0.0.0.0":
                    return True
        except OSError:
            continue
    return False


def _fatal_box(text):
    try:
        with open(_log_path(), "a", encoding="utf-8") as f:
            f.write(f"\n--- fatal, showing message box ---\n{text}\n")
    except Exception:
        pass
    import ctypes
    ctypes.windll.user32.MessageBoxW(0, text, "Office PDF", 0x10)


def main():
    os.environ.pop("CA_PDF_TOOL_DB", None)

    if "--register" in sys.argv[1:]:
        _register_as_pdf_handler()
        return

    # Check this BEFORE starting anything else — it's the most common reason the
    # window never appears, and without this check the process previously just
    # exited silently with no error, no dialog, nothing in the crash log: the
    # server thread would start fine (and log that it did), but the un-wrapped
    # webview.create_window()/start() call below would throw and take the whole
    # process down with it, on a --windowed build with no console to show why.
    if not _has_webview2_runtime():
        _fatal_box(
            "Office PDF needs the Microsoft Edge WebView2 Runtime, which isn't "
            "installed on this PC.\n\n"
            "Most Windows 11 machines already have it. Many Windows 10 machines "
            "don't.\n\n"
            "Download the free \"Evergreen Bootstrapper\" from:\n"
            "https://developer.microsoft.com/microsoft-edge/webview2/\n\n"
            "then run this program again."
        )
        sys.exit(1)

    from app.routers.viewer import set_startup_file
    set_startup_file(_pdf_path_from_argv())

    t = threading.Thread(target=_run_server_thread, daemon=True)
    t.start()
    if not _wait_for_server():
        _fatal_box(
            "Office PDF could not start its internal server.\n\n"
            f"Port {PORT} may already be in use by another copy of this program."
        )
        sys.exit(1)

    icon_path = None
    for cand in (os.path.join(os.path.dirname(os.path.abspath(sys.executable)), "logo.ico"),
                 os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "frontend", "logo.ico")):
        if os.path.isfile(cand):
            icon_path = cand
            break

    try:
        import webview
        webview.create_window(
            "Office PDF",
            f"http://127.0.0.1:{PORT}/",
            width=1360, height=860, min_size=(900, 600),
            text_select=True, zoomable=True, confirm_close=False,
            js_api=DesktopApi(),
        )
        webview.start(icon=icon_path, private_mode=False)
    except Exception:
        import traceback
        tb = traceback.format_exc()
        try:
            with open(_log_path(), "a", encoding="utf-8") as f:
                f.write(f"\n--- window failed to open ---\n{tb}\n")
        except Exception:
            pass
        _fatal_box(
            "Office PDF's window failed to open.\n\n"
            "This is usually a missing or broken Microsoft Edge WebView2 Runtime "
            "install. Details were written to office-pdf-crash.log next to this "
            "program — please share that file if you need help.\n\n"
            f"{tb.strip().splitlines()[-1] if tb.strip() else ''}"
        )
        sys.exit(1)


if __name__ == "__main__":
    main()

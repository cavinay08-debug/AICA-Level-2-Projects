"""
Forms module — Feature Category 8.
Create Fillable Form (add AcroForm text/checkbox fields), Auto-Detect Fields
(read existing fields), Fill (general field-name -> value filling — works for
any AcroForm PDF, including govt ITR/GST/TDS forms once you know their field
names from Auto-Detect), Export Form Data.
"""
import fitz  # PyMuPDF

FIELD_TYPES = {
    "text": fitz.PDF_WIDGET_TYPE_TEXT,
    "checkbox": fitz.PDF_WIDGET_TYPE_CHECKBOX,
}


def detect_fields(input_path: str) -> list:
    doc = fitz.open(input_path)
    fields = []
    for pno in range(doc.page_count):
        page = doc[pno]
        for w in (page.widgets() or []):
            fields.append({
                "page": pno + 1,
                "name": w.field_name,
                "type": w.field_type_string,
                "value": w.field_value,
                "rect": [round(w.rect.x0, 1), round(w.rect.y0, 1), round(w.rect.x1, 1), round(w.rect.y1, 1)],
            })
    doc.close()
    return fields


def fill_fields(input_path: str, output_path: str, values: dict) -> int:
    doc = fitz.open(input_path)
    filled = 0
    for page in doc:
        for w in (page.widgets() or []):
            if w.field_name in values:
                w.field_value = values[w.field_name]
                w.update()
                filled += 1
    doc.save(output_path)
    doc.close()
    if filled == 0:
        raise RuntimeError("None of the field names you gave matched a field in this PDF. "
                            "Run Auto-Detect Fields first to see the exact names.")
    return filled


def export_field_data(input_path: str) -> dict:
    fields = detect_fields(input_path)
    return {f["name"]: f["value"] for f in fields if f["name"]}


def create_fields(input_path: str, output_path: str, fields: list) -> str:
    """fields: [{"page":int, "name":str, "type":"text"|"checkbox", "x0":.., "y0":.., "x1":.., "y1":..}]"""
    if not fields:
        raise RuntimeError("Add at least one field.")
    doc = fitz.open(input_path)
    for f in fields:
        pno = int(f["page"])
        if pno < 1 or pno > doc.page_count:
            continue
        if not f.get("name"):
            raise RuntimeError("Every field needs a name.")
        widget = fitz.Widget()
        widget.field_name = f["name"]
        widget.field_type = FIELD_TYPES.get(f.get("type", "text"), fitz.PDF_WIDGET_TYPE_TEXT)
        widget.rect = fitz.Rect(f["x0"], f["y0"], f["x1"], f["y1"])
        if widget.field_type == fitz.PDF_WIDGET_TYPE_TEXT:
            widget.text_fontsize = 10
        doc[pno - 1].add_widget(widget)
    doc.save(output_path)
    doc.close()
    return output_path

"""
Builds Office-PDF-Desktop.exe — the native desktop application (own window, no
browser chrome; this is also the file-association target for "Open with").

    cd backend
    venv\\Scripts\\python build_desktop_exe.py

Output: backend/dist/Office-PDF-Desktop.exe

This is separate from build_exe.py (the plain server .exe someone runs to host the
tool for the LAN). Both can be built from the same source tree; most single-user
setups only need this one.
"""
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
FRONTEND = os.path.abspath(os.path.join(HERE, "..", "frontend"))
NAME = "Office-PDF-Desktop"
ICON = os.path.join(FRONTEND, "logo.ico")

hidden = [
    "uvicorn.logging", "uvicorn.loops", "uvicorn.loops.auto", "uvicorn.loops.asyncio",
    "uvicorn.protocols", "uvicorn.protocols.http", "uvicorn.protocols.http.auto",
    "uvicorn.protocols.http.h11_impl", "uvicorn.protocols.websockets",
    "uvicorn.protocols.websockets.auto", "uvicorn.lifespan", "uvicorn.lifespan.on",
    "uvicorn.lifespan.off",
    "app.main", "app.core.paths", "app.core.database", "app.models.db_models",
    "app.routers.organize", "app.routers.optimize", "app.routers.workspace",
    "app.routers.convert", "app.routers.edit", "app.routers.security",
    "app.routers.sign", "app.routers.forms", "app.routers.compare", "app.routers.batch",
    "app.routers.viewer",
    "app.services.organize", "app.services.optimize", "app.services.convert",
    "app.services.edit", "app.services.security", "app.services.sign",
    "app.services.forms", "app.services.compare", "app.services.batch",
    "app.services.viewer", "app.services.audit",
    "fitz", "pymupdf", "pypdf", "reportlab", "PIL", "PIL.Image",
    "docx", "openpyxl", "pptx", "pdfplumber", "pdf2docx", "img2pdf",
    "sqlalchemy.dialects.sqlite", "sqlalchemy.sql.default_comparator",
    "email.mime.multipart", "email.mime.text",
    "webview", "webview.platforms.winforms", "webview.platforms.edgechromium",
    "clr_loader", "clr", "pythonnet",
]

collect_all = ["fastapi", "starlette", "uvicorn", "pydantic", "pydantic_core",
                "reportlab", "pdfplumber", "pdf2docx", "pptx", "docx", "openpyxl",
                "fitz", "pymupdf", "img2pdf", "pikepdf", "webview", "clr_loader", "pythonnet"]

cmd = [sys.executable, "-m", "PyInstaller", "--noconfirm", "--clean", "--onefile",
       "--name", NAME, "--windowed",  # no console window — this is a GUI app
       "--add-data", f"{FRONTEND}{os.pathsep}frontend",
       "--paths", HERE]

if os.path.isfile(ICON):
    cmd += ["--icon", ICON]

for h in hidden:
    cmd += ["--hidden-import", h]
for c in collect_all:
    cmd += ["--collect-all", c]
for x in ["tkinter", "matplotlib", "pytest", "httpx2", "IPython", "notebook"]:
    cmd += ["--exclude-module", x]

cmd += [os.path.join(HERE, "desktop_app.py")]

print("Building the desktop app… this takes a few minutes.\n")
r = subprocess.run(cmd, cwd=HERE)
if r.returncode != 0:
    print("\nBUILD FAILED")
    sys.exit(r.returncode)

out = os.path.join(HERE, "dist", NAME + ".exe")
if os.path.exists(out):
    size = os.path.getsize(out) / (1024 * 1024)
    print(f"\nBUILD OK -> {out}  ({size:.0f} MB)")
else:
    print("\nBuild reported success but the exe is missing.")
    sys.exit(1)

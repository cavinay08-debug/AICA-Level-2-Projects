"""
Batch/Automation module — Feature Category 10.
Bulk Apply (one operation across many files), Action Wizard (a chain of operations
applied in sequence — bulk-apply is just a 1-step wizard), Auto File Naming
(Client/PAN/FY convention), Bulk Rename (pattern-based).

The operation registry reuses the already-tested single-file service functions from
organize/optimize/edit/security rather than reimplementing anything — bulk/wizard is
purely an orchestration layer on top of them.
"""
import os
from datetime import date

from app.services import edit as edit_svc
from app.services import optimize as opt_svc
from app.services import organize as org_svc
from app.services import security as sec_svc


def _op_compress(inp, outp, params):
    opt_svc.compress_pdf(inp, outp, int(params.get("quality", 60)))


def _op_repair(inp, outp, params):
    opt_svc.repair_pdf(inp, outp)


def _op_sanitize(inp, outp, params):
    sec_svc.sanitize_pdf(inp, outp)


def _op_watermark(inp, outp, params):
    edit_svc.add_watermark(inp, outp, text=params.get("text", "DRAFT"),
                            opacity=float(params.get("opacity", 0.3)),
                            rotation=float(params.get("rotation", 45)))


def _op_page_numbers(inp, outp, params):
    edit_svc.add_page_numbers(inp, outp, position=params.get("position", "bottom-center"),
                               start_number=int(params.get("start_number", 1)),
                               fmt=params.get("fmt", "Page {n} of {total}"))


def _op_rotate(inp, outp, params):
    org_svc.rotate_pages(inp, [], int(params.get("degrees", 90)), outp)  # [] = all pages


def _op_add_password(inp, outp, params):
    if not params.get("user_password"):
        raise RuntimeError("add_password needs a 'user_password' parameter.")
    sec_svc.add_password(inp, outp, user_password=params["user_password"])


# key -> (label, function, param specs for the frontend to build a form)
OPERATIONS = {
    "compress": ("Compress", _op_compress, [{"name": "quality", "type": "number", "default": 60}]),
    "repair": ("Repair", _op_repair, []),
    "sanitize": ("Sanitize (strip metadata)", _op_sanitize, []),
    "watermark": ("Add Watermark", _op_watermark, [
        {"name": "text", "type": "text", "default": "DRAFT"},
        {"name": "opacity", "type": "number", "default": 0.3},
        {"name": "rotation", "type": "number", "default": 45},
    ]),
    "page_numbers": ("Add Page Numbers", _op_page_numbers, [
        {"name": "position", "type": "text", "default": "bottom-center"},
        {"name": "start_number", "type": "number", "default": 1},
        {"name": "fmt", "type": "text", "default": "Page {n} of {total}"},
    ]),
    "rotate": ("Rotate All Pages", _op_rotate, [{"name": "degrees", "type": "number", "default": 90}]),
    "add_password": ("Password Protect", _op_add_password, [{"name": "user_password", "type": "text", "default": ""}]),
}


def list_operations() -> list:
    return [{"key": k, "label": label, "params": params} for k, (label, _fn, params) in OPERATIONS.items()]


def run_chain(input_path: str, output_path: str, steps: list) -> str:
    """steps: [{"operation": str, "params": dict}, ...] applied in sequence to one file."""
    if not steps:
        raise RuntimeError("Add at least one step.")
    current = input_path
    intermediates = []
    for i, step in enumerate(steps):
        op_key = step.get("operation")
        if op_key not in OPERATIONS:
            raise RuntimeError(f"Unknown operation '{op_key}'. Valid: {', '.join(OPERATIONS)}")
        _label, fn, _params = OPERATIONS[op_key]
        next_path = output_path if i == len(steps) - 1 else f"{output_path}.step{i}.pdf"
        try:
            fn(current, next_path, step.get("params") or {})
        except RuntimeError:
            raise
        except Exception as e:
            raise RuntimeError(f"Step {i + 1} ({op_key}) failed: {e}")
        if current != input_path:
            intermediates.append(current)
        current = next_path
    for p in intermediates:
        try:
            os.remove(p)
        except OSError:
            pass
    return output_path


def bulk_apply(files: list, operation: str, params: dict, output_dir: str) -> list:
    """files: [(original_filename, input_path), ...]. Returns [(output_filename, output_path), ...]."""
    if operation not in OPERATIONS:
        raise RuntimeError(f"Unknown operation '{operation}'. Valid: {', '.join(OPERATIONS)}")
    _label, fn, _params = OPERATIONS[operation]
    results = []
    errors = []
    for fname, path in files:
        out_path = os.path.join(output_dir, fname)
        try:
            fn(path, out_path, params or {})
            results.append((fname, out_path))
        except Exception as e:
            errors.append(f"{fname}: {e}")
    if not results:
        raise RuntimeError("Every file failed: " + "; ".join(errors))
    return results, errors


VALID_PLACEHOLDERS = {"client", "pan", "fy", "original_name", "name", "ext", "n", "date"}


def rename_files(files: list, pattern: str, context: dict | None = None) -> list:
    """files: [(original_filename, path), ...]. Returns [(new_filename, path), ...] (files untouched,
    only names computed — the router does the actual copy/rename)."""
    if not pattern.strip():
        raise RuntimeError("Enter a naming pattern.")
    context = context or {}
    results = []
    for i, (fname, path) in enumerate(files, start=1):
        base, ext = os.path.splitext(fname)
        try:
            new_name = pattern.format(
                client=context.get("client", ""), pan=context.get("pan", ""), fy=context.get("fy", ""),
                original_name=fname, name=base, ext=ext.lstrip("."), n=i, date=date.today().isoformat(),
            )
        except KeyError as e:
            raise RuntimeError(f"Unknown placeholder {{{e.args[0]}}} — valid ones: {', '.join(sorted(VALID_PLACEHOLDERS))}")
        if ext and not new_name.lower().endswith(ext.lower()):
            new_name += ext
        results.append((new_name, path))
    return results

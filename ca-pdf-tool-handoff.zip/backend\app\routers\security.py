import json
import os
import uuid
from typing import List, Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.paths import storage_dir
from app.services import security as svc
from app.services.audit import log_action

router = APIRouter(prefix="/api/security", tags=["security"])

STORAGE = os.path.join(storage_dir(), "tmp")
os.makedirs(STORAGE, exist_ok=True)


def _save_upload(f: UploadFile) -> str:
    path = os.path.join(STORAGE, f"{uuid.uuid4().hex}_{f.filename}")
    with open(path, "wb") as out:
        out.write(f.file.read())
    return path


def _parse_pages_optional(raw: str) -> Optional[List[int]]:
    raw = (raw or "").strip()
    if not raw:
        return None
    pages = []
    try:
        for chunk in raw.split(","):
            chunk = chunk.strip()
            if not chunk:
                continue
            if "-" in chunk:
                start, end = chunk.split("-")
                pages.extend(range(int(start.strip()), int(end.strip()) + 1))
            else:
                pages.append(int(chunk))
    except ValueError:
        raise HTTPException(400, "Couldn't read page numbers — use e.g. 1,3,5-8 or leave blank for all pages.")
    return pages or None


def _parse_terms(raw: str) -> List[str]:
    """Accepts JSON list or a plain comma-separated list of words/phrases."""
    raw = (raw or "").strip()
    if not raw:
        return []
    try:
        parsed = json.loads(raw)
        if isinstance(parsed, list):
            return [str(x) for x in parsed]
    except (json.JSONDecodeError, ValueError, TypeError):
        pass
    return [t.strip() for t in raw.split(",") if t.strip()]


def _run(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs)
    except RuntimeError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        raise HTTPException(400, f"Couldn't process this file: {e}")


@router.get("/patterns")
async def patterns():
    """Lets the frontend build its auto-redaction checklist from the real pattern set."""
    return [{"key": k, "label": v["label"]} for k, v in svc.PATTERNS.items()]


@router.post("/add-password")
async def add_password(file: UploadFile = File(...), user_password: str = Form(...),
                        owner_password: str = Form(""), allow_printing: bool = Form(True),
                        allow_copy: bool = Form(True), allow_modify: bool = Form(True),
                        allow_annotate: bool = Form(True), staff: str = Form("unknown"),
                        db: Session = Depends(get_db)):
    if not user_password:
        raise HTTPException(400, "Enter a password to protect this PDF with.")
    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"protected_{uuid.uuid4().hex}.pdf")
    _run(svc.add_password, path, out_path, user_password, owner_password,
         allow_printing, allow_copy, allow_modify, allow_annotate)
    log_action(db, staff, "ADD_PASSWORD", "SECURITY", detail=file.filename)
    return FileResponse(out_path, filename="protected.pdf", media_type="application/pdf")


@router.post("/remove-password")
async def remove_password(file: UploadFile = File(...), password: str = Form(...),
                           staff: str = Form("unknown"), db: Session = Depends(get_db)):
    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"unlocked_{uuid.uuid4().hex}.pdf")
    _run(svc.remove_password, path, out_path, password)
    log_action(db, staff, "REMOVE_PASSWORD", "SECURITY", detail=file.filename)
    return FileResponse(out_path, filename="unlocked.pdf", media_type="application/pdf")


@router.post("/set-permissions")
async def set_permissions(file: UploadFile = File(...), owner_password: str = Form(...),
                           allow_printing: bool = Form(True), allow_copy: bool = Form(True),
                           allow_modify: bool = Form(True), allow_annotate: bool = Form(True),
                           staff: str = Form("unknown"), db: Session = Depends(get_db)):
    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"permissions_{uuid.uuid4().hex}.pdf")
    _run(svc.set_permissions, path, out_path, owner_password,
         allow_printing, allow_copy, allow_modify, allow_annotate)
    log_action(db, staff, "SET_PERMISSIONS", "SECURITY",
               detail=f"{file.filename}: print={allow_printing} copy={allow_copy} modify={allow_modify}")
    return FileResponse(out_path, filename="permissions_set.pdf", media_type="application/pdf")


@router.post("/redact")
async def redact(file: UploadFile = File(...), terms: str = Form(...), pages: str = Form(""),
                  staff: str = Form("unknown"), db: Session = Depends(get_db)):
    term_list = _parse_terms(terms)
    if not term_list:
        raise HTTPException(400, "Enter at least one word or phrase to redact.")
    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"redacted_{uuid.uuid4().hex}.pdf")
    hits = _run(svc.redact_text, path, out_path, term_list, _parse_pages_optional(pages))
    log_action(db, staff, "REDACT", "SECURITY", detail=f"{file.filename}: {term_list} -> {hits} removed")
    return FileResponse(out_path, filename="redacted.pdf", media_type="application/pdf",
                         headers={"X-Redaction-Count": str(hits), "Access-Control-Expose-Headers": "X-Redaction-Count"})


@router.post("/redact-areas")
async def redact_areas(file: UploadFile = File(...), areas: str = Form(...),
                        staff: str = Form("unknown"), db: Session = Depends(get_db)):
    """areas: JSON list of {"page":int,"x0":..,"y0":..,"x1":..,"y1":..} in PDF points,
    produced by the frontend's draw-a-box-on-the-page picker."""
    try:
        area_list = json.loads(areas)
        if not isinstance(area_list, list):
            raise ValueError
    except (json.JSONDecodeError, ValueError):
        raise HTTPException(400, "Couldn't read the redaction areas — draw at least one box on the page.")
    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"redacted_areas_{uuid.uuid4().hex}.pdf")
    hits = _run(svc.redact_areas, path, out_path, area_list)
    log_action(db, staff, "REDACT_AREAS", "SECURITY", detail=f"{file.filename}: {hits} area(s) removed")
    return FileResponse(out_path, filename="redacted.pdf", media_type="application/pdf",
                         headers={"X-Redaction-Count": str(hits), "Access-Control-Expose-Headers": "X-Redaction-Count"})


@router.post("/auto-redact")
async def auto_redact(file: UploadFile = File(...), pattern_keys: str = Form(...), custom_regex: str = Form(""),
                       pages: str = Form(""), staff: str = Form("unknown"), db: Session = Depends(get_db)):
    keys = [k.strip() for k in pattern_keys.split(",") if k.strip()]
    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"autoredact_{uuid.uuid4().hex}.pdf")
    counts = _run(svc.auto_redact, path, out_path, keys, custom_regex, _parse_pages_optional(pages))
    total = sum(counts.values())
    log_action(db, staff, "AUTO_REDACT", "SECURITY", detail=f"{file.filename}: {counts} ({total} total)")
    return FileResponse(out_path, filename="auto_redacted.pdf", media_type="application/pdf",
                         headers={"X-Redaction-Summary": json.dumps(counts),
                                  "Access-Control-Expose-Headers": "X-Redaction-Summary"})


@router.post("/sanitize")
async def sanitize(file: UploadFile = File(...), staff: str = Form("unknown"), db: Session = Depends(get_db)):
    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"sanitized_{uuid.uuid4().hex}.pdf")
    _run(svc.sanitize_pdf, path, out_path)
    log_action(db, staff, "SANITIZE", "SECURITY", detail=file.filename)
    return FileResponse(out_path, filename="sanitized.pdf", media_type="application/pdf")

"""
Viewer module — Feature Category 11 (View & Navigate).

Burns viewer-created markup into the PDF: highlights, freehand ink drawings and
sticky notes. Coordinates arrive in PDF point space (the frontend converts from
screen pixels using the render scale), so nothing here needs to know about zoom.

Reuses PyMuPDF's annotation API. Note the weak-reference gotcha documented in
compare.py: fetch each page once and reuse that reference for every annotation on
it, or later .update() calls fail with "weakly-referenced object no longer exists".
"""
import fitz  # PyMuPDF


def _hex_to_rgb01(hex_color: str) -> tuple:
    hex_color = (hex_color or "").lstrip("#")
    if len(hex_color) != 6:
        hex_color = "ffd400"
    return tuple(int(hex_color[i:i + 2], 16) / 255 for i in (0, 2, 4))


def burn_annotations(input_path: str, output_path: str, highlights: list | None = None,
                      inks: list | None = None, notes: list | None = None) -> int:
    """highlights: [{"page","x0","y0","x1","y1","color"}]
    inks:       [{"page","color","width","paths":[[[x,y],...], ...]}]
    notes:      [{"page","x","y","text"}]
    Returns the number of annotations written."""
    highlights = highlights or []
    inks = inks or []
    notes = notes or []
    if not (highlights or inks or notes):
        raise RuntimeError("Nothing to save — add a highlight, drawing or note first.")

    doc = fitz.open(input_path)
    pages = {}

    def page(pno):
        if pno not in pages:
            pages[pno] = doc[pno - 1]
        return pages[pno]

    count = 0
    for h in highlights:
        pno = int(h.get("page", 0))
        if pno < 1 or pno > doc.page_count:
            continue
        rect = fitz.Rect(h["x0"], h["y0"], h["x1"], h["y1"])
        annot = page(pno).add_highlight_annot(rect)
        colour = _hex_to_rgb01(h.get("color", "#ffd400"))
        try:
            annot.set_colors(stroke=colour)
        except Exception:
            pass
        annot.update()
        count += 1

    for ink in inks:
        pno = int(ink.get("page", 0))
        if pno < 1 or pno > doc.page_count:
            continue
        # add_ink_annot wants plain (x, y) pairs — passing fitz.Point objects raises
        # "arg must be seq of seq of float pairs" despite Point being point_like
        # everywhere else in the API.
        strokes = [[(float(pt[0]), float(pt[1])) for pt in path]
                    for path in ink.get("paths", []) if len(path) >= 2]
        if not strokes:
            continue
        annot = page(pno).add_ink_annot(strokes)
        annot.set_border(width=float(ink.get("width", 2)))
        try:
            annot.set_colors(stroke=_hex_to_rgb01(ink.get("color", "#e11d48")))
        except Exception:
            pass
        annot.update()
        count += 1

    for n in notes:
        pno = int(n.get("page", 0))
        if pno < 1 or pno > doc.page_count:
            continue
        annot = page(pno).add_text_annot((n["x"], n["y"]), n.get("text", ""))
        annot.set_info(content=n.get("text", ""))
        annot.update()
        count += 1

    doc.save(output_path)
    doc.close()
    return count


def get_outline(input_path: str) -> list:
    """Bookmarks/TOC for the viewer's Bookmarks panel."""
    with fitz.open(input_path) as doc:
        toc = doc.get_toc() or []
    return [{"level": t[0], "title": t[1], "page": t[2]} for t in toc]

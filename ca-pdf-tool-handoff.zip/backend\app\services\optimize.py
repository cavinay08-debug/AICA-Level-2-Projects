"""
Optimize module — Feature Category 2.
Compress (quality slider via image downsampling), Repair, OCR, Portal-Compliance size check.

NOTE: OCR requires the `ocrmypdf` CLI (wraps Tesseract) and the `tesseract-ocr` system
package plus language packs (e.g. tesseract-ocr-hin for Hindi) to be installed on the
office server machine. Compression uses PyMuPDF's built-in deflate + optional image
downsampling; for maximum compression, install Ghostscript and call it as a fallback.
"""
import subprocess
import fitz  # PyMuPDF
import os

# Common Indian govt portal upload limits (MB) — extend as needed
PORTAL_LIMITS_MB = {
    "income_tax_efiling": 5,
    "gst_portal": 5,
    "mca_v3": 6,
    "traces": 5,
    "default": 10,
}


def compress_pdf(input_path: str, output_path: str, quality: int = 60) -> str:
    """quality: 1-100 slider. Lower = smaller file, more image degradation.
    Re-encodes embedded images at reduced quality/DPI and rewrites with garbage collection."""
    doc = fitz.open(input_path)
    img_quality = max(10, min(quality, 95))
    for page in doc:
        for img in page.get_images(full=True):
            xref = img[0]
            try:
                base_image = doc.extract_image(xref)
                pix = fitz.Pixmap(doc, xref)
                if pix.n - pix.alpha >= 4:  # CMYK -> RGB safety
                    pix = fitz.Pixmap(fitz.csRGB, pix)
                img_bytes = pix.tobytes("jpeg", jpg_quality=img_quality)
                doc.update_stream(xref, img_bytes)
            except Exception:
                continue  # non-image xref or unsupported; skip safely
    doc.save(output_path, garbage=4, deflate=True, clean=True)
    doc.close()
    return output_path


# Quick presets for "compress until it fits somewhere" — office-relevant targets
COMPRESSION_TARGETS_MB = {
    "income_tax_efiling": 5,
    "gst_portal": 5,
    "mca_v3": 6,
    "traces": 5,
    "email_attachment": 25,
    "whatsapp": 16,
}


def compress_pdf_to_target(input_path: str, output_path: str, target_mb: float) -> dict:
    """Binary-search-style step down through quality levels until the file fits
    under target_mb, or we hit the lowest usable quality. Returns a summary dict."""
    target_bytes = target_mb * 1024 * 1024
    original_size = os.path.getsize(input_path)

    if original_size <= target_bytes:
        # Already fits — still run a light pass for consistency, don't over-compress needlessly
        compress_pdf(input_path, output_path, quality=90)
        return {
            "achieved_quality": 90,
            "original_size_mb": round(original_size / (1024 * 1024), 2),
            "final_size_mb": round(os.path.getsize(output_path) / (1024 * 1024), 2),
            "target_met": True,
        }

    best_path = None
    best_quality = None
    for quality in range(85, 9, -10):  # 85, 75, ... 15
        trial_path = output_path + f".q{quality}.tmp"
        compress_pdf(input_path, trial_path, quality)
        size = os.path.getsize(trial_path)
        if best_path:
            os.remove(best_path)
        best_path, best_quality = trial_path, quality
        if size <= target_bytes:
            break

    os.replace(best_path, output_path)
    final_size = os.path.getsize(output_path)
    return {
        "achieved_quality": best_quality,
        "original_size_mb": round(original_size / (1024 * 1024), 2),
        "final_size_mb": round(final_size / (1024 * 1024), 2),
        "target_met": final_size <= target_bytes,
    }


def repair_pdf(input_path: str, output_path: str) -> str:
    """Attempts structural repair by re-writing the file via PyMuPDF's parser,
    which tolerates many forms of corruption (bad xref tables, broken streams)."""
    doc = fitz.open(input_path)
    doc.save(output_path, garbage=4, deflate=True, clean=True)
    doc.close()
    return output_path


def ocr_pdf(input_path: str, output_path: str, languages: str = "eng+hin") -> str:
    """Runs ocrmypdf to produce a searchable PDF. `languages` uses Tesseract codes,
    e.g. 'eng+hin' for English + Hindi, add 'eng+hin+guj+mar' etc. as language packs are installed.

    ocrmypdf is an external CLI (it wraps Tesseract) — if it isn't installed, raise the
    same kind of clean "install this" message the LibreOffice/Ghostscript paths use,
    rather than letting a raw FileNotFoundError escape as a 500."""
    cmd = ["ocrmypdf", "--language", languages, "--skip-text", input_path, output_path]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    except FileNotFoundError:
        raise RuntimeError(
            "OCR isn't available on this machine — ocrmypdf and Tesseract aren't installed. "
            "Install Tesseract OCR (plus the language packs you need, e.g. tesseract-ocr-hin "
            "for Hindi) and run 'pip install ocrmypdf', then try again."
        )
    except subprocess.TimeoutExpired:
        raise RuntimeError("OCR timed out — the file may be very large or heavily scanned.")
    if result.returncode != 0:
        stderr = (result.stderr or "").strip()
        if "tesseract" in stderr.lower() and "not" in stderr.lower():
            raise RuntimeError(
                "OCR failed because Tesseract isn't installed or isn't on PATH. "
                f"Install Tesseract OCR and try again. Details: {stderr[:300]}"
            )
        raise RuntimeError(f"OCR failed: {stderr[:500]}")
    return output_path


def check_portal_compliance(file_path: str, portal: str = "default") -> dict:
    size_mb = os.path.getsize(file_path) / (1024 * 1024)
    limit = PORTAL_LIMITS_MB.get(portal, PORTAL_LIMITS_MB["default"])
    return {
        "file_size_mb": round(size_mb, 2),
        "portal": portal,
        "limit_mb": limit,
        "compliant": size_mb <= limit,
        "message": (
            f"OK — under {limit}MB limit for {portal}."
            if size_mb <= limit
            else f"Exceeds {portal} limit of {limit}MB by {round(size_mb - limit, 2)}MB. Compress before upload."
        ),
    }

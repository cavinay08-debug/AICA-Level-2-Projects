"""
Security module — Feature Category 6.
Password protect/remove, Permissions, Redact (true text removal),
Pattern-based auto-redaction (PAN/Aadhaar/GSTIN/etc.), Sanitize metadata.

Redaction uses PyMuPDF's add_redact_annot + apply_redactions, which actually
strips the underlying text/image content under the box (not just a visual overlay).
"""
import re

import fitz  # PyMuPDF


# ---------------------------------------------------------------------------
# Common Indian-office identifier patterns for auto-redaction.
# ---------------------------------------------------------------------------
PATTERNS = {
    "pan": {"label": "PAN (Income Tax)", "regex": r"\b[A-Z]{5}[0-9]{4}[A-Z]\b"},
    "gstin": {"label": "GSTIN", "regex": r"\b\d{2}[A-Z]{5}\d{4}[A-Z]\d[Zz][A-Z0-9]\b"},
    "aadhaar": {"label": "Aadhaar Number", "regex": r"\b\d{4}\s\d{4}\s\d{4}\b|\b\d{12}\b"},
    "mobile": {"label": "Mobile Number", "regex": r"\b[6-9]\d{9}\b"},
    "email": {"label": "Email Address", "regex": r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"},
    "bank_account": {"label": "Bank Account Number (9-18 digits)", "regex": r"\b\d{9,18}\b"},
}


def _resolve_pages(doc: "fitz.Document", pages: list | None) -> list:
    return pages if pages else list(range(1, doc.page_count + 1))


# ---------------------------------------------------------------------------
# Password / permissions
# ---------------------------------------------------------------------------
def add_password(input_path: str, output_path: str, user_password: str = "", owner_password: str = "",
                  allow_printing: bool = True, allow_copy: bool = True,
                  allow_modify: bool = True, allow_annotate: bool = True) -> str:
    from pypdf import PdfReader, PdfWriter
    from pypdf.constants import UserAccessPermissions as P

    reader = PdfReader(input_path)
    writer = PdfWriter()
    for page in reader.pages:
        writer.add_page(page)

    perm = P(0)
    if allow_printing:
        perm |= P.PRINT | P.PRINT_TO_REPRESENTATION
    if allow_copy:
        perm |= P.EXTRACT | P.EXTRACT_TEXT_AND_GRAPHICS
    if allow_modify:
        perm |= P.MODIFY
    if allow_annotate:
        perm |= P.ADD_OR_MODIFY | P.FILL_FORM_FIELDS

    writer.encrypt(user_password=user_password or "", owner_password=owner_password or user_password or None,
                    permissions_flag=perm)
    with open(output_path, "wb") as f:
        writer.write(f)
    return output_path


def set_permissions(input_path: str, output_path: str, owner_password: str,
                     allow_printing: bool = True, allow_copy: bool = True,
                     allow_modify: bool = True, allow_annotate: bool = True) -> str:
    """Opens with no password, but readers that honor the permission flags will
    restrict print/copy/modify/annotate as configured — needs an owner password
    so the restriction can later be lifted by whoever set it."""
    if not owner_password:
        raise RuntimeError("An owner password is required to set permissions.")
    return add_password(input_path, output_path, user_password="", owner_password=owner_password,
                         allow_printing=allow_printing, allow_copy=allow_copy,
                         allow_modify=allow_modify, allow_annotate=allow_annotate)


def remove_password(input_path: str, output_path: str, password: str) -> str:
    from pypdf import PdfReader, PdfWriter

    reader = PdfReader(input_path)
    if reader.is_encrypted:
        ok = reader.decrypt(password or "")
        if not ok:
            raise RuntimeError("Incorrect password — couldn't unlock this PDF.")
    writer = PdfWriter()
    for page in reader.pages:
        writer.add_page(page)
    with open(output_path, "wb") as f:
        writer.write(f)
    return output_path


# ---------------------------------------------------------------------------
# Redaction
# ---------------------------------------------------------------------------
def redact_text(input_path: str, output_path: str, terms: list, pages: list | None = None) -> int:
    """True removal (not just a black box) of every occurrence of each search term."""
    terms = [t.strip() for t in terms if t and t.strip()]
    if not terms:
        raise RuntimeError("Enter at least one word or phrase to redact.")
    doc = fitz.open(input_path)
    target_pages = _resolve_pages(doc, pages)
    total_hits = 0
    for pnum in target_pages:
        if pnum < 1 or pnum > doc.page_count:
            continue
        page = doc[pnum - 1]
        hits_this_page = 0
        for term in terms:
            for r in page.search_for(term):
                page.add_redact_annot(r, fill=(0, 0, 0))
                hits_this_page += 1
        if hits_this_page:
            page.apply_redactions()
        total_hits += hits_this_page
    doc.save(output_path)
    doc.close()
    return total_hits


def redact_areas(input_path: str, output_path: str, areas: list) -> int:
    """True removal of specific on-page rectangles (PDF point space) — backs the
    "draw a box on the page" redaction mode. areas: [{"page":int,"x0":..,"y0":..,"x1":..,"y1":..}]."""
    if not areas:
        raise RuntimeError("No redaction areas were provided — draw at least one box on the page.")
    doc = fitz.open(input_path)
    by_page = {}
    for a in areas:
        by_page.setdefault(int(a["page"]), []).append(a)
    hits = 0
    for pno, area_list in by_page.items():
        if pno < 1 or pno > doc.page_count:
            continue
        page = doc[pno - 1]
        for a in area_list:
            rect = fitz.Rect(a["x0"], a["y0"], a["x1"], a["y1"])
            page.add_redact_annot(rect, fill=(0, 0, 0))
            hits += 1
        page.apply_redactions()
    doc.save(output_path)
    doc.close()
    return hits


def auto_redact(input_path: str, output_path: str, pattern_keys: list,
                 custom_regex: str = "", pages: list | None = None) -> dict:
    """Scans extracted page text for known identifier patterns (or a custom regex)
    and true-redacts every match. Returns a per-pattern match count for the audit log."""
    compiled = []
    for key in pattern_keys or []:
        if key in PATTERNS:
            compiled.append((key, re.compile(PATTERNS[key]["regex"])))
    if custom_regex and custom_regex.strip():
        try:
            compiled.append(("custom", re.compile(custom_regex.strip())))
        except re.error as e:
            raise RuntimeError(f"Invalid custom pattern: {e}")
    if not compiled:
        raise RuntimeError("Choose at least one pattern (PAN, Aadhaar, etc.) or provide a custom pattern.")

    doc = fitz.open(input_path)
    target_pages = _resolve_pages(doc, pages)
    counts = {key: 0 for key, _ in compiled}

    for pnum in target_pages:
        if pnum < 1 or pnum > doc.page_count:
            continue
        page = doc[pnum - 1]
        text = page.get_text()
        seen_this_page = set()
        hits_this_page = 0
        for key, rx in compiled:
            for m in rx.finditer(text):
                match_str = m.group(0)
                dedupe_key = (key, match_str)
                if dedupe_key in seen_this_page:
                    continue
                seen_this_page.add(dedupe_key)
                rects = page.search_for(match_str)
                if rects:
                    for r in rects:
                        page.add_redact_annot(r, fill=(0, 0, 0))
                    counts[key] += 1
                    hits_this_page += 1
        if hits_this_page:
            page.apply_redactions()

    doc.save(output_path)
    doc.close()
    return counts


def sanitize_pdf(input_path: str, output_path: str) -> str:
    """Strips document metadata, XML metadata, and embedded files/attachments —
    useful before sending a working paper outside the firm."""
    doc = fitz.open(input_path)
    doc.set_metadata({})
    try:
        doc.del_xml_metadata()
    except Exception:
        pass
    try:
        for name in list(doc.embfile_names()):
            doc.embfile_del(name)
    except Exception:
        pass
    doc.save(output_path, garbage=4, deflate=True, clean=True)
    doc.close()
    return output_path

"""
Builds the single-file Office PDF .exe.

    cd backend
    venv\\Scripts\\python build_exe.py

Output: backend/dist/CA-PDF-Tool.exe  (share this one file)

Notes on the tricky parts:
 - uvicorn/fastapi load a lot of things dynamically, so their submodules have to be
   collected explicitly or the exe starts and immediately dies on an import error.
 - the frontend (index.html) is bundled as data and read via app.core.paths.
 - the DB, signatures and processed files deliberately live NEXT TO the exe, not
   inside the temp unpack dir, so nothing is lost when the program closes.
"""
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
FRONTEND = os.path.abspath(os.path.join(HERE, "..", "frontend"))
NAME = "CA-PDF-Tool"

hidden = [
    "uvicorn.logging", "uvicorn.loops", "uvicorn.loops.auto", "uvicorn.loops.asyncio",
    "uvicorn.protocols", "uvicorn.protocols.http", "uvicorn.protocols.http.auto",
    "uvicorn.protocols.http.h11_impl", "uvicorn.protocols.websockets",
    "uvicorn.protocols.websockets.auto", "uvicorn.lifespan", "uvicorn.lifespan.on",
    "uvicorn.lifespan.off",
    "app.main", "app.core.paths", "app.core.database", "app.models.db_models",
    "app.routers.organize", "app.routers.optimize", "app.routers.workspace",
    "app.routers.convert", "app.routers.edit", "app.routers.security",
    "app.routers.sign", "app.routers.forms", "app.routers.compare", "app.routers.batch",
    "app.services.organize", "app.services.optimize", "app.services.convert",
    "app.services.edit", "app.services.security", "app.services.sign",
    "app.services.forms", "app.services.compare", "app.services.batch",
    "app.services.audit",
    "fitz", "pymupdf", "pypdf", "reportlab", "PIL", "PIL.Image",
    "docx", "openpyxl", "pptx", "pdfplumber", "pdf2docx", "img2pdf",
    "sqlalchemy.dialects.sqlite", "sqlalchemy.sql.default_comparator",
    "email.mime.multipart", "email.mime.text",
]

collect_all = ["fastapi", "starlette", "uvicorn", "pydantic", "pydantic_core",
                "reportlab", "pdfplumber", "pdf2docx", "pptx", "docx", "openpyxl",
                "fitz", "pymupdf", "img2pdf", "pikepdf"]

cmd = [sys.executable, "-m", "PyInstaller", "--noconfirm", "--clean", "--onefile",
       "--name", NAME, "--console",
       "--add-data", f"{FRONTEND}{os.pathsep}frontend",
       "--paths", HERE]

for h in hidden:
    cmd += ["--hidden-import", h]
for c in collect_all:
    cmd += ["--collect-all", c]

# these are dev/test-only and drag in huge or broken trees
for x in ["tkinter", "matplotlib", "pytest", "httpx2", "IPython", "notebook"]:
    cmd += ["--exclude-module", x]

cmd += [os.path.join(HERE, "run_server.py")]

print("Building… this takes a few minutes.\n")
print(" ".join(cmd[:8]), "…\n")
r = subprocess.run(cmd, cwd=HERE)
if r.returncode != 0:
    print("\nBUILD FAILED")
    sys.exit(r.returncode)

out = os.path.join(HERE, "dist", NAME + ".exe")
if os.path.exists(out):
    size = os.path.getsize(out) / (1024 * 1024)
    print(f"\nBUILD OK -> {out}  ({size:.0f} MB)")
else:
    print("\nBuild reported success but the exe is missing.")
    sys.exit(1)

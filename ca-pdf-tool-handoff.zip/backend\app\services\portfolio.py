"""
Portfolio / Package Creator module — "CA Workflow" category.

Bundles several working papers of ANY type (PDF, Excel, Word, images, etc.) into
one PDF: a cover/index page listing what's inside, plus each original file
embedded verbatim as an attachment (PyMuPDF's embedded-file API) — so the
recipient gets one file to save/email, and can still open each source document
in its native application from inside a PDF viewer that supports attachments
(Acrobat's "Attachments" pane, or Extract in most viewers).

This is deliberately not the same as "Combine + Auto-Bookmark" (Organize
category), which merges PDF *pages* into one flowing document — that only works
for PDFs. A portfolio keeps every file intact and native, which matters for a
working-papers package where the Excel file needs to stay an actual .xlsx.
"""
import os

import fitz  # PyMuPDF


def create_portfolio(input_paths: list, labels: list, output_path: str,
                      title: str = "Document Package") -> str:
    if not input_paths:
        raise RuntimeError("Add at least one file to bundle.")
    if len(labels) != len(input_paths):
        raise RuntimeError("Each file needs exactly one label.")

    doc = fitz.open()
    page = doc.new_page()
    rect = page.rect
    y = 72
    page.insert_text((72, y), title, fontsize=20, fontname="helv", color=(0.05, 0.09, 0.16))
    y += 30
    page.insert_text((72, y), f"{len(input_paths)} file(s) — see the Attachments panel in your PDF viewer "
                               f"to open each original file.", fontsize=10, color=(0.4, 0.45, 0.5))
    y += 30
    page.draw_line((72, y), (rect.width - 72, y), color=(0.85, 0.87, 0.9), width=1)
    y += 20

    for path, label in zip(input_paths, labels):
        if y > rect.height - 72:
            page = doc.new_page()
            y = 72
        size_kb = os.path.getsize(path) / 1024
        ext = os.path.splitext(path)[1].lstrip(".").upper() or "FILE"
        page.insert_text((72, y), f"• {label}", fontsize=12, fontname="helv", color=(0.05, 0.09, 0.16))
        page.insert_text((90, y + 15), f"{ext} · {size_kb:.0f} KB", fontsize=9, color=(0.5, 0.55, 0.6))
        y += 34

    used_names = set()
    for path, label in zip(input_paths, labels):
        with open(path, "rb") as f:
            data = f.read()
        fname = os.path.basename(path)
        embed_name = (label.strip()[:180] or fname) or "file"
        candidate, n = embed_name, 1
        while candidate in used_names:  # embfile_add requires a unique name per attachment
            n += 1
            candidate = f"{embed_name} ({n})"
        used_names.add(candidate)
        doc.embfile_add(candidate, data, filename=fname, desc=label)

    doc.save(output_path)
    doc.close()
    return output_path

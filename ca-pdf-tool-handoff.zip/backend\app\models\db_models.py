"""
Core DB models for the CA-office PDF tool.
- Staff: simple local login (office network only, no external auth needed)
- Client / Matter: workspace organization (Feature 12: Client Workspace)
- FileRecord: every file processed, tracked for naming convention + workspace browsing
- AuditLog: who did what, when (Feature 12: Audit Trail Log)
"""
from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from app.core.database import Base


class Staff(Base):
    __tablename__ = "staff"
    id = Column(Integer, primary_key=True)
    name = Column(String(120), nullable=False)
    username = Column(String(80), unique=True, nullable=False)
    role = Column(String(40), default="staff")  # staff / partner / admin
    created_at = Column(DateTime, default=datetime.utcnow)


class Client(Base):
    __tablename__ = "clients"
    id = Column(Integer, primary_key=True)
    name = Column(String(200), nullable=False)
    pan = Column(String(20), nullable=True)
    gstin = Column(String(20), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    matters = relationship("Matter", back_populates="client")


class Matter(Base):
    __tablename__ = "matters"
    id = Column(Integer, primary_key=True)
    client_id = Column(Integer, ForeignKey("clients.id"), nullable=False)
    title = Column(String(200), nullable=False)  # e.g. "Tax Audit", "GST Filing", "ITAT Appeal"
    financial_year = Column(String(10), nullable=False)  # e.g. "2025-26"
    created_at = Column(DateTime, default=datetime.utcnow)
    client = relationship("Client", back_populates="matters")
    files = relationship("FileRecord", back_populates="matter")


class FileRecord(Base):
    __tablename__ = "files"
    id = Column(Integer, primary_key=True)
    matter_id = Column(Integer, ForeignKey("matters.id"), nullable=True)
    filename = Column(String(300), nullable=False)
    filepath = Column(String(500), nullable=False)
    size_bytes = Column(Integer, default=0)
    created_by = Column(String(80), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    matter = relationship("Matter", back_populates="files")


class AuditLog(Base):
    __tablename__ = "audit_log"
    id = Column(Integer, primary_key=True)
    staff_username = Column(String(80), nullable=False)
    action = Column(String(80), nullable=False)      # e.g. "MERGE", "SIGN", "REDACT"
    tool_category = Column(String(40), nullable=False)  # e.g. "ORGANIZE", "SECURITY"
    detail = Column(Text, nullable=True)              # e.g. filenames involved
    file_id = Column(Integer, ForeignKey("files.id"), nullable=True)
    timestamp = Column(DateTime, default=datetime.utcnow)


class Signature(Base):
    """A staff member's saved signature (drawn or uploaded), reusable across documents
    instead of re-drawing/re-uploading every time — Feature 7: Draw/Upload Signature."""
    __tablename__ = "signatures"
    id = Column(Integer, primary_key=True)
    staff_username = Column(String(80), nullable=False)
    label = Column(String(120), default="My signature")
    image_path = Column(String(500), nullable=False)  # PNG with transparent background, stored under storage/signatures/
    created_at = Column(DateTime, default=datetime.utcnow)


class SignatureRequest(Base):
    """Tracks a multi-party signature round for a document — Feature 7: Request Signatures.
    Local-LAN scope: no email/notifications are sent; staff check this list and sign in turn
    from whichever office machine they're on."""
    __tablename__ = "signature_requests"
    id = Column(Integer, primary_key=True)
    document_filename = Column(String(300), nullable=False)
    document_path = Column(String(500), nullable=False)   # current version — advances as each signer signs
    requested_by = Column(String(80), nullable=False)
    signers = Column(Text, nullable=False)  # JSON list: [{"name": "...", "status": "pending"|"signed", "signed_at": "..."}]
    status = Column(String(20), default="pending")  # "pending" | "completed"
    created_at = Column(DateTime, default=datetime.utcnow)

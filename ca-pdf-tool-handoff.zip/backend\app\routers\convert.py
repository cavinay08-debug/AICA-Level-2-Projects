import os
import uuid
import zipfile
from typing import List

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.paths import storage_dir
from app.services import convert as svc
from app.services.audit import log_action

router = APIRouter(prefix="/api/convert", tags=["convert"])

STORAGE = os.path.join(storage_dir(), "tmp")
os.makedirs(STORAGE, exist_ok=True)

OFFICE_EXTS = {".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx"}
HTML_EXTS = {".html", ".htm"}


def _save_upload(f: UploadFile) -> str:
    path = os.path.join(STORAGE, f"{uuid.uuid4().hex}_{f.filename}")
    with open(path, "wb") as out:
        out.write(f.file.read())
    return path


def _run(fn, *args, **kwargs):
    """Runs a convert.py service function, turning known failure modes into clean
    HTTP errors instead of a raw 500 (missing external tool -> 503, bad input -> 400)."""
    try:
        return fn(*args, **kwargs)
    except RuntimeError as e:
        msg = str(e)
        status = 503 if ("isn't installed" in msg or "not found" in msg) else 400
        raise HTTPException(status, msg)
    except Exception as e:
        raise HTTPException(400, f"Conversion failed: {e}")


# ---------------------------------------------------------------------------
# Convert TO PDF
# ---------------------------------------------------------------------------
@router.post("/office-to-pdf")
async def office_to_pdf(file: UploadFile = File(...), staff: str = Form("unknown"),
                         db: Session = Depends(get_db)):
    ext = os.path.splitext(file.filename or "")[1].lower()
    if ext not in OFFICE_EXTS:
        raise HTTPException(400, f"Unsupported file type '{ext}'. Use Word, Excel or PowerPoint files.")
    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"office2pdf_{uuid.uuid4().hex}.pdf")
    _run(svc.office_to_pdf, path, out_path)
    log_action(db, staff, "OFFICE_TO_PDF", "CONVERT_TO", detail=file.filename)
    return FileResponse(out_path, filename="converted.pdf", media_type="application/pdf")


@router.post("/html-to-pdf")
async def html_to_pdf(file: UploadFile = File(...), staff: str = Form("unknown"),
                       db: Session = Depends(get_db)):
    ext = os.path.splitext(file.filename or "")[1].lower()
    if ext not in HTML_EXTS:
        raise HTTPException(400, f"Unsupported file type '{ext}'. Use an .html or .htm file.")
    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"html2pdf_{uuid.uuid4().hex}.pdf")
    _run(svc.html_to_pdf, path, out_path)
    log_action(db, staff, "HTML_TO_PDF", "CONVERT_TO", detail=file.filename)
    return FileResponse(out_path, filename="converted.pdf", media_type="application/pdf")


@router.post("/csv-to-pdf")
async def csv_to_pdf(file: UploadFile = File(...), title: str = Form(""), staff: str = Form("unknown"),
                      db: Session = Depends(get_db)):
    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"csv2pdf_{uuid.uuid4().hex}.pdf")
    _run(svc.csv_to_pdf, path, out_path, title)
    log_action(db, staff, "CSV_TO_PDF", "CONVERT_TO", detail=file.filename)
    return FileResponse(out_path, filename="converted.pdf", media_type="application/pdf")


@router.post("/image-to-pdf")
async def image_to_pdf(files: List[UploadFile] = File(...), staff: str = Form("unknown"),
                        db: Session = Depends(get_db)):
    paths = [_save_upload(f) for f in files]
    out_path = os.path.join(STORAGE, f"img2pdf_{uuid.uuid4().hex}.pdf")
    _run(svc.images_to_pdf, paths, out_path)
    log_action(db, staff, "IMAGE_TO_PDF", "CONVERT_TO", detail=f"{len(files)} image(s)")
    return FileResponse(out_path, filename="converted.pdf", media_type="application/pdf")


@router.post("/scan-to-pdf")
async def scan_to_pdf(files: List[UploadFile] = File(...), staff: str = Form("unknown"),
                       db: Session = Depends(get_db)):
    """Same pipeline as image-to-pdf; kept as a distinct endpoint/audit action since
    it's the mobile-scan capture flow rather than a general image import."""
    paths = [_save_upload(f) for f in files]
    out_path = os.path.join(STORAGE, f"scan2pdf_{uuid.uuid4().hex}.pdf")
    _run(svc.images_to_pdf, paths, out_path)
    log_action(db, staff, "SCAN_TO_PDF", "CONVERT_TO", detail=f"{len(files)} page(s)")
    return FileResponse(out_path, filename="scanned.pdf", media_type="application/pdf")


# ---------------------------------------------------------------------------
# Convert FROM PDF
# ---------------------------------------------------------------------------
@router.post("/pdf-to-word")
async def pdf_to_word(file: UploadFile = File(...), staff: str = Form("unknown"),
                       db: Session = Depends(get_db)):
    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"pdf2docx_{uuid.uuid4().hex}.docx")
    _run(svc.pdf_to_docx, path, out_path)
    log_action(db, staff, "PDF_TO_WORD", "CONVERT_FROM", detail=file.filename)
    return FileResponse(out_path, filename="converted.docx",
                         media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document")


@router.post("/pdf-to-excel")
async def pdf_to_excel(file: UploadFile = File(...), staff: str = Form("unknown"),
                        db: Session = Depends(get_db)):
    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"pdf2xlsx_{uuid.uuid4().hex}.xlsx")
    _run(svc.pdf_to_xlsx, path, out_path)
    log_action(db, staff, "PDF_TO_EXCEL", "CONVERT_FROM", detail=file.filename)
    return FileResponse(out_path, filename="converted.xlsx",
                         media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@router.post("/pdf-to-ppt")
async def pdf_to_ppt(file: UploadFile = File(...), staff: str = Form("unknown"),
                      db: Session = Depends(get_db)):
    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"pdf2pptx_{uuid.uuid4().hex}.pptx")
    _run(svc.pdf_to_pptx, path, out_path)
    log_action(db, staff, "PDF_TO_PPT", "CONVERT_FROM", detail=file.filename)
    return FileResponse(out_path, filename="converted.pptx",
                         media_type="application/vnd.openxmlformats-officedocument.presentationml.presentation")


@router.post("/pdf-to-images")
async def pdf_to_images(file: UploadFile = File(...), fmt: str = Form("png"), dpi: int = Form(150),
                         staff: str = Form("unknown"), db: Session = Depends(get_db)):
    path = _save_upload(file)
    out_dir = os.path.join(STORAGE, f"pdf2img_{uuid.uuid4().hex}")
    os.makedirs(out_dir, exist_ok=True)
    image_paths = _run(svc.pdf_to_images, path, out_dir, fmt, dpi)
    zip_path = os.path.join(STORAGE, f"pdf2img_{uuid.uuid4().hex}.zip")
    with zipfile.ZipFile(zip_path, "w") as zf:
        for p in image_paths:
            zf.write(p, arcname=os.path.basename(p))
    log_action(db, staff, "PDF_TO_IMAGES", "CONVERT_FROM",
               detail=f"{file.filename}: {len(image_paths)} page(s) @ {dpi}dpi {fmt}")
    return FileResponse(zip_path, filename="pages.zip", media_type="application/zip")


@router.post("/pdf-to-pdfa")
async def pdf_to_pdfa(file: UploadFile = File(...), level: str = Form("2b"), staff: str = Form("unknown"),
                       db: Session = Depends(get_db)):
    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"pdfa_{uuid.uuid4().hex}.pdf")
    _run(svc.pdf_to_pdfa, path, out_path, level)
    log_action(db, staff, "PDF_TO_PDFA", "CONVERT_FROM", detail=f"{file.filename}: PDF/A-{level}")
    return FileResponse(out_path, filename="archival.pdf", media_type="application/pdf")

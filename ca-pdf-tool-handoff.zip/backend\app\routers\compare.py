import json
import os
import uuid
import zipfile

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.paths import storage_dir
from app.services import compare as svc
from app.services.audit import log_action

router = APIRouter(prefix="/api/compare", tags=["compare"])

STORAGE = os.path.join(storage_dir(), "tmp")
os.makedirs(STORAGE, exist_ok=True)


def _save_upload(f: UploadFile) -> str:
    path = os.path.join(STORAGE, f"{uuid.uuid4().hex}_{f.filename}")
    with open(path, "wb") as out:
        out.write(f.file.read())
    return path


def _run(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs)
    except RuntimeError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        raise HTTPException(400, f"Couldn't process this file: {e}")


@router.post("/pdfs")
async def compare_pdfs(file_a: UploadFile = File(...), file_b: UploadFile = File(...),
                        format: str = Form("json"), label_a: str = Form("Draft"), label_b: str = Form("Final"),
                        staff: str = Form("unknown"), db: Session = Depends(get_db)):
    path_a = _save_upload(file_a)
    path_b = _save_upload(file_b)
    if format == "side_by_side":
        out_path = os.path.join(STORAGE, f"compare_sbs_{uuid.uuid4().hex}.pdf")
        summary = _run(svc.side_by_side_report, path_a, path_b, out_path, label_a, label_b)
        log_action(db, staff, "COMPARE_PDFS", "COMPARE",
                   detail=f"{file_a.filename} vs {file_b.filename} (side-by-side): "
                          f"{summary['pages_with_differences']}/{summary['pages']} page(s) differ")
        return FileResponse(out_path, filename="comparison_side_by_side.pdf", media_type="application/pdf",
                             headers={"X-Pages-With-Differences": str(summary["pages_with_differences"]),
                                      "X-Total-Pages": str(summary["pages"]),
                                      "Access-Control-Expose-Headers": "X-Pages-With-Differences, X-Total-Pages"})
    if format == "pdf":
        out_path = os.path.join(STORAGE, f"compare_report_{uuid.uuid4().hex}.pdf")
        _run(svc.compare_pdfs_report, path_a, path_b, out_path, label_a, label_b)
        log_action(db, staff, "COMPARE_PDFS", "COMPARE", detail=f"{file_a.filename} vs {file_b.filename} (report)")
        return FileResponse(out_path, filename="comparison_report.pdf", media_type="application/pdf")
    result = _run(svc.compare_pdfs, path_a, path_b)
    log_action(db, staff, "COMPARE_PDFS", "COMPARE",
               detail=f"{file_a.filename} vs {file_b.filename}: {result['similarity_pct']}% similar")
    return result


@router.post("/visual")
async def visual_diff(file_a: UploadFile = File(...), file_b: UploadFile = File(...), dpi: int = Form(100),
                       staff: str = Form("unknown"), db: Session = Depends(get_db)):
    path_a = _save_upload(file_a)
    path_b = _save_upload(file_b)
    out_dir = os.path.join(STORAGE, f"visualdiff_{uuid.uuid4().hex}")
    os.makedirs(out_dir, exist_ok=True)
    images = _run(svc.visual_diff, path_a, path_b, out_dir, dpi)
    log_action(db, staff, "VISUAL_DIFF", "COMPARE", detail=f"{file_a.filename} vs {file_b.filename}: {len(images)} page(s) differ")
    if not images:
        return {"message": "No visual differences found on any page.", "pages_differing": 0}
    zip_path = os.path.join(STORAGE, f"visualdiff_{uuid.uuid4().hex}.zip")
    with zipfile.ZipFile(zip_path, "w") as zf:
        for p in images:
            zf.write(p, arcname=os.path.basename(p))
    return FileResponse(zip_path, filename="visual_diff.zip", media_type="application/zip")


@router.post("/annotate")
async def annotate(file: UploadFile = File(...), comments: str = Form("[]"), highlights: str = Form("[]"),
                    staff: str = Form("unknown"), db: Session = Depends(get_db)):
    try:
        comment_list = json.loads(comments) if comments.strip() else []
        highlight_list = json.loads(highlights) if highlights.strip() else []
    except json.JSONDecodeError:
        raise HTTPException(400, "Couldn't read the comments/highlights.")
    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"annotated_{uuid.uuid4().hex}.pdf")
    count = _run(svc.add_annotations, path, out_path, comment_list, highlight_list)
    log_action(db, staff, "ANNOTATE", "COMPARE", detail=f"{file.filename}: {count} annotation(s)")
    return FileResponse(out_path, filename="annotated.pdf", media_type="application/pdf")

"""
Compare & Review module — Feature Category 9.
Compare Two PDFs (line-level text diff + a downloadable redline report),
Track Changes View (page-by-page visual pixel diff, for scanned/layout docs where
text extraction won't catch a moved image or a shifted table), Annotate/Comment
(sticky-note comments + highlight boxes placed by clicking/dragging on the page,
reusing the same PagePicker interaction as Sign/Forms in Phase 4).
"""
import difflib
import io
import os

import fitz  # PyMuPDF


def _page_texts(path: str) -> list:
    with fitz.open(path) as doc:
        return [doc[i].get_text() for i in range(doc.page_count)]


def _diff_block_boxes(delta, block: int = 18, min_avg: float = 18.0) -> list:
    """Groups a pixel-diff mask into a small set of rectangles (image-pixel space)
    instead of one box per differing pixel or one giant box around everything —
    a simple block-grid + per-row run-merge, no numpy/scipy dependency."""
    from PIL import ImageStat

    w, h = delta.size
    cols, rows = (w + block - 1) // block, (h + block - 1) // block
    changed = [[False] * cols for _ in range(rows)]
    for ry in range(rows):
        y0, y1 = ry * block, min(ry * block + block, h)
        for rx in range(cols):
            x0, x1 = rx * block, min(rx * block + block, w)
            if ImageStat.Stat(delta.crop((x0, y0, x1, y1))).mean[0] > min_avg:
                changed[ry][rx] = True

    boxes = []
    for ry in range(rows):
        rx = 0
        while rx < cols:
            if changed[ry][rx]:
                start = rx
                while rx < cols and changed[ry][rx]:
                    rx += 1
                boxes.append((start * block, ry * block, min(rx * block, w), min(ry * block + block, h)))
            else:
                rx += 1
    return boxes


def side_by_side_report(path_a: str, path_b: str, output_path: str,
                         label_a: str = "Old", label_b: str = "New", dpi: int = 100) -> dict:
    """One landscape page per page-pair: the old and new page shown side by side
    (real vector content via show_pdf_page, not a screenshot), with a yellow
    highlighter box over every region that actually changed between them."""
    import io as _io

    from PIL import Image, ImageChops

    doc_a, doc_b = fitz.open(path_a), fitz.open(path_b)
    max_pages = max(doc_a.page_count, doc_b.page_count)
    if max_pages == 0:
        doc_a.close(); doc_b.close()
        raise RuntimeError("Both files are empty.")

    TARGET_H, MARGIN, GAP, TOP = 700, 40, 24, 70
    FALLBACK_ASPECT = 842 / 595  # A4 portrait height/width, used only if a page is entirely missing on one side
    zoom = dpi / 72
    mat = fitz.Matrix(zoom, zoom)

    out = fitz.open()
    pages_with_diff = 0

    for i in range(max_pages):
        has_a, has_b = i < doc_a.page_count, i < doc_b.page_count
        wa = (doc_a[i].rect.width * (TARGET_H / doc_a[i].rect.height)) if has_a else TARGET_H / FALLBACK_ASPECT
        wb = (doc_b[i].rect.width * (TARGET_H / doc_b[i].rect.height)) if has_b else TARGET_H / FALLBACK_ASPECT

        page_w, page_h = MARGIN * 2 + wa + GAP + wb, TOP + TARGET_H + MARGIN
        op = out.new_page(width=page_w, height=page_h)
        op.insert_text((MARGIN, 30), f"Page {i + 1} comparison", fontsize=13, fontname="helv", color=(0.05, 0.09, 0.16))

        rect_a = fitz.Rect(MARGIN, TOP, MARGIN + wa, TOP + TARGET_H)
        rect_b = fitz.Rect(MARGIN + wa + GAP, TOP, MARGIN + wa + GAP + wb, TOP + TARGET_H)
        op.insert_text((rect_a.x0, TOP - 8), label_a + ("" if has_a else "  (page not present)"),
                        fontsize=10, color=(0.4, 0.45, 0.5))
        op.insert_text((rect_b.x0, TOP - 8), label_b + ("" if has_b else "  (page not present)"),
                        fontsize=10, color=(0.4, 0.45, 0.5))
        op.draw_rect(rect_a, color=(0.85, 0.87, 0.9), width=1)
        op.draw_rect(rect_b, color=(0.85, 0.87, 0.9), width=1)

        if has_a:
            op.show_pdf_page(rect_a, doc_a, i)
        else:
            op.insert_textbox(rect_a, f"This page does not exist in {label_a}.", fontsize=11,
                               color=(0.6, 0.6, 0.6), align=1)
        if has_b:
            op.show_pdf_page(rect_b, doc_b, i)
        else:
            op.insert_textbox(rect_b, f"This page does not exist in {label_b}.", fontsize=11,
                               color=(0.6, 0.6, 0.6), align=1)

        if has_a and has_b:
            pix_a = doc_a[i].get_pixmap(matrix=mat)
            pix_b = doc_b[i].get_pixmap(matrix=mat)
            img_a = Image.open(_io.BytesIO(pix_a.tobytes("png"))).convert("RGB")
            img_b = Image.open(_io.BytesIO(pix_b.tobytes("png"))).convert("RGB")
            img_b_aligned = img_b.resize(img_a.size) if img_a.size != img_b.size else img_b
            delta = ImageChops.difference(img_a, img_b_aligned).convert("L")
            if delta.getbbox() is not None:
                pages_with_diff += 1
                img_w, img_h = img_a.size
                for (bx0, by0, bx1, by1) in _diff_block_boxes(delta):
                    nx0, ny0, nx1, ny1 = bx0 / img_w, by0 / img_h, bx1 / img_w, by1 / img_h
                    ha = fitz.Rect(rect_a.x0 + nx0 * rect_a.width, rect_a.y0 + ny0 * rect_a.height,
                                    rect_a.x0 + nx1 * rect_a.width, rect_a.y0 + ny1 * rect_a.height)
                    hb = fitz.Rect(rect_b.x0 + nx0 * rect_b.width, rect_b.y0 + ny0 * rect_b.height,
                                    rect_b.x0 + nx1 * rect_b.width, rect_b.y0 + ny1 * rect_b.height)
                    # yellow highlighter: fill only, no border, semi-transparent — sits over the
                    # real vector content placed above by show_pdf_page rather than hiding it
                    op.draw_rect(ha, color=None, fill=(1, 0.87, 0.2), fill_opacity=0.4, width=0)
                    op.draw_rect(hb, color=None, fill=(1, 0.87, 0.2), fill_opacity=0.4, width=0)
        elif has_a != has_b:
            pages_with_diff += 1

    doc_a.close()
    doc_b.close()
    out.save(output_path)
    out.close()
    return {"pages": max_pages, "pages_with_differences": pages_with_diff}


def compare_pdfs(path_a: str, path_b: str) -> dict:
    """Line-level diff per page (SequenceMatcher over each page's extracted text).
    If the two files have different page counts, extra pages are diffed against ''
    (i.e. shown as fully added/removed)."""
    pages_a = _page_texts(path_a)
    pages_b = _page_texts(path_b)
    max_pages = max(len(pages_a), len(pages_b))

    diff_by_page = []
    total_added = total_removed = 0
    for i in range(max_pages):
        text_a = pages_a[i] if i < len(pages_a) else ""
        text_b = pages_b[i] if i < len(pages_b) else ""
        lines_a = text_a.splitlines()
        lines_b = text_b.splitlines()
        sm = difflib.SequenceMatcher(None, lines_a, lines_b)
        added, removed = [], []
        for tag, i1, i2, j1, j2 in sm.get_opcodes():
            if tag == "insert":
                added.extend(lines_b[j1:j2])
            elif tag == "delete":
                removed.extend(lines_a[i1:i2])
            elif tag == "replace":
                removed.extend(lines_a[i1:i2])
                added.extend(lines_b[j1:j2])
        if added or removed:
            diff_by_page.append({"page": i + 1, "added": added, "removed": removed})
        total_added += len(added)
        total_removed += len(removed)

    full_a, full_b = "\n".join(pages_a), "\n".join(pages_b)
    similarity = difflib.SequenceMatcher(None, full_a, full_b).ratio() if (full_a or full_b) else 1.0

    return {
        "pages_a": len(pages_a),
        "pages_b": len(pages_b),
        "identical": total_added == 0 and total_removed == 0 and len(pages_a) == len(pages_b),
        "similarity_pct": round(similarity * 100, 1),
        "total_lines_added": total_added,
        "total_lines_removed": total_removed,
        "pages_with_changes": [p["page"] for p in diff_by_page],
        "diff_by_page": diff_by_page,
    }


def compare_pdfs_report(path_a: str, path_b: str, output_path: str,
                         label_a: str = "Draft", label_b: str = "Final") -> str:
    """Renders the diff from compare_pdfs() as a readable redline PDF —
    green = added (in B, not A), red/strikethrough = removed (in A, not B)."""
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    diff = compare_pdfs(path_a, path_b)
    styles = getSampleStyleSheet()
    elements = [
        Paragraph(f"Comparison Report — {label_a} vs {label_b}", styles["Title"]),
        Spacer(1, 6),
    ]
    summary_rows = [
        ["Pages", f"{diff['pages_a']} vs {diff['pages_b']}"],
        ["Similarity", f"{diff['similarity_pct']}%"],
        ["Lines added", str(diff["total_lines_added"])],
        ["Lines removed", str(diff["total_lines_removed"])],
        ["Pages with changes", ", ".join(str(p) for p in diff["pages_with_changes"]) or "None"],
    ]
    t = Table(summary_rows, colWidths=[120, 320])
    t.setStyle(TableStyle([
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#cbd5e1")),
        ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#f1f5f9")),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    elements.append(t)
    elements.append(Spacer(1, 14))

    if diff["identical"]:
        elements.append(Paragraph("No differences found — the two files are textually identical.", styles["Normal"]))
    else:
        line_style = styles["Code"]
        line_style.fontSize = 8
        line_style.leading = 10
        for pd in diff["diff_by_page"]:
            elements.append(Paragraph(f"Page {pd['page']}", styles["Heading3"]))
            for line in pd["removed"]:
                elements.append(Paragraph(f'<font color="#be123c">− {_escape(line)}</font>', line_style))
            for line in pd["added"]:
                elements.append(Paragraph(f'<font color="#047857">+ {_escape(line)}</font>', line_style))
            elements.append(Spacer(1, 8))

    doc = SimpleDocTemplate(output_path, pagesize=A4, topMargin=18 * mm, bottomMargin=15 * mm,
                             leftMargin=15 * mm, rightMargin=15 * mm)
    doc.build(elements)
    return output_path


def _escape(s: str) -> str:
    return (s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;") or "&nbsp;"


def visual_diff(path_a: str, path_b: str, output_dir: str, dpi: int = 100) -> list:
    """Renders each page pair to images and highlights pixel-level differences in red.
    Only pages that actually differ are returned. Good for catching layout/image
    changes that text-diff can't see (a moved stamp, a shifted table, a scan re-crop)."""
    from PIL import Image, ImageChops

    with fitz.open(path_a) as da, fitz.open(path_b) as db:
        max_pages = max(da.page_count, db.page_count)
        zoom = dpi / 72
        mat = fitz.Matrix(zoom, zoom)
        outputs = []
        for i in range(max_pages):
            has_a = i < da.page_count
            has_b = i < db.page_count
            if not has_a or not has_b:
                # page only exists on one side — always flag it as a difference
                src_doc, idx = (da, i) if has_a else (db, i)
                pix = src_doc[idx].get_pixmap(matrix=mat)
                img = Image.open(io.BytesIO(pix.tobytes("png"))).convert("RGB")
                out_path = os.path.join(output_dir, f"page_{i + 1:03d}_diff.png")
                img.save(out_path)
                outputs.append(out_path)
                continue

            pix_a = da[i].get_pixmap(matrix=mat)
            pix_b = db[i].get_pixmap(matrix=mat)
            img_a = Image.open(io.BytesIO(pix_a.tobytes("png"))).convert("RGB")
            img_b = Image.open(io.BytesIO(pix_b.tobytes("png"))).convert("RGB")
            if img_a.size != img_b.size:
                img_b = img_b.resize(img_a.size)

            delta = ImageChops.difference(img_a, img_b).convert("L")
            if delta.getbbox() is None:
                continue  # identical page, skip

            # Highlight changed pixels in red over a dimmed version of the "after" page
            mask = delta.point(lambda p: 255 if p > 25 else 0)
            red_layer = Image.new("RGB", img_b.size, (220, 38, 38))
            dimmed = Image.blend(img_b, Image.new("RGB", img_b.size, (255, 255, 255)), 0.35)
            highlighted = Image.composite(red_layer, dimmed, mask)

            out_path = os.path.join(output_dir, f"page_{i + 1:03d}_diff.png")
            highlighted.save(out_path)
            outputs.append(out_path)
    return outputs


def add_annotations(input_path: str, output_path: str, comments: list | None = None,
                     highlights: list | None = None) -> int:
    """comments: [{"page":int,"x":..,"y":..,"text":..}] -> sticky-note popup annotations.
    highlights: [{"page":int,"x0":..,"y0":..,"x1":..,"y1":..,"text":..(optional)}] -> highlight boxes.

    NOTE: PyMuPDF Page objects hold a weak reference to their parent — re-fetching
    `doc[i]` fresh for every annotation lets the earlier wrapper get garbage
    collected mid-use and breaks later `.update()` calls with a cryptic
    "weakly-referenced object no longer exists" error. Fetch each page once and
    reuse that reference for every annotation on it."""
    if not comments and not highlights:
        raise RuntimeError("Add at least one comment or highlight.")
    doc = fitz.open(input_path)
    pages = {}  # page_number(1-indexed) -> cached fitz.Page reference

    def _page(pno):
        if pno not in pages:
            pages[pno] = doc[pno - 1]
        return pages[pno]

    count = 0
    for c in (comments or []):
        pno = int(c["page"])
        if pno < 1 or pno > doc.page_count:
            continue
        annot = _page(pno).add_text_annot((c["x"], c["y"]), c.get("text", ""))
        annot.set_info(content=c.get("text", ""))
        annot.update()
        count += 1
    for h in (highlights or []):
        pno = int(h["page"])
        if pno < 1 or pno > doc.page_count:
            continue
        rect = fitz.Rect(h["x0"], h["y0"], h["x1"], h["y1"])
        annot = _page(pno).add_highlight_annot(rect)
        if h.get("text"):
            annot.set_info(content=h["text"])
        annot.update()
        count += 1
    doc.save(output_path)
    doc.close()
    return count

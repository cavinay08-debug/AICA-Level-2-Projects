"""
SQLite database engine + session.
Local-only deployment: DB file lives on the office server machine, never leaves the LAN.
"""
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

from app.core.paths import storage_dir

# CA_PDF_TOOL_DB lets a test run point at a throwaway DB instead of the office one.
# Normal operation ignores it and uses <storage>/ca_pdf_tool.db — which, in the .exe
# build, sits next to the executable so it survives restarts.
DB_PATH = os.environ.get("CA_PDF_TOOL_DB") or os.path.join(storage_dir(), "ca_pdf_tool.db")
DB_PATH = os.path.abspath(DB_PATH)
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

engine = create_engine(f"sqlite:///{DB_PATH}", connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

"""
Accessibility Check module — "CA Workflow" category's PDF/UA compliance check.

This is a best-effort automated checklist, not a certified PDF/UA conformance
test — that needs a dedicated validator (veraPDF) which isn't bundled here (same
caveat already noted for the PDF/A conversion tool). It catches the structural
basics that are cheap to check directly with PyMuPDF and that most real-world
"is this PDF accessible" complaints boil down to: a title, a declared language,
tagged structure, embedded fonts, and text that's actually extractable (not a
flat scanned image with no OCR layer).
"""
import fitz  # PyMuPDF


def check_accessibility(input_path: str) -> dict:
    doc = fitz.open(input_path)
    checks = []

    def add(name, passed, detail):
        checks.append({"check": name, "passed": bool(passed), "detail": detail})

    meta = doc.metadata or {}
    title = (meta.get("title") or "").strip()
    add("Document has a title", bool(title),
        f"Title: {title!r}" if title else "No title set — screen readers announce the filename instead.")

    try:
        cat_xref = doc.pdf_catalog()
        lang = doc.xref_get_key(cat_xref, "Lang")
    except Exception:
        cat_xref, lang = None, None
    has_lang = bool(lang and lang[0] != "null" and lang[1].strip("()"))
    add("Document language is set", has_lang,
        "Found a /Lang entry." if has_lang else "No /Lang entry — screen readers may guess the wrong language.")

    is_tagged = False
    try:
        mark_info = doc.xref_get_key(cat_xref, "MarkInfo")
        is_tagged = mark_info[0] != "null" and "true" in (mark_info[1] or "").lower()
    except Exception:
        pass
    add("Document is tagged", is_tagged,
        "Has a /MarkInfo Marked=true entry." if is_tagged
        else "Not tagged — screen readers can't determine reading order or roles (headings, tables, etc.).")

    toc = doc.get_toc() or []
    add("Has bookmarks/outline", bool(toc),
        f"{len(toc)} bookmark(s)." if toc else "No bookmarks — fine for a short document, helpful for long ones.")

    pages_with_text = 0
    pages_without_text = []
    for i in range(doc.page_count):
        if (doc[i].get_text() or "").strip():
            pages_with_text += 1
        else:
            pages_without_text.append(i + 1)
    all_have_text = not pages_without_text
    add("All pages have extractable text", all_have_text,
        "Every page has real text." if all_have_text
        else f"{len(pages_without_text)} page(s) have no extractable text "
             f"(likely scanned images) — page(s) {pages_without_text[:15]}"
             f"{'…' if len(pages_without_text) > 15 else ''}. Run OCR first.")

    # The 14 standard PDF fonts (plus common Windows aliases for them) are never
    # embedded by design — every PDF reader has them built in — so ext == "n/a"
    # for one of these is normal, not an accessibility problem. Only flag ext ==
    # "n/a" for anything else, which means a real font is missing its font file.
    _STANDARD_FONTS = {
        "times-roman", "times-bold", "times-italic", "times-bolditalic",
        "helvetica", "helvetica-bold", "helvetica-oblique", "helvetica-boldoblique",
        "courier", "courier-bold", "courier-oblique", "courier-boldoblique",
        "symbol", "zapfdingbats", "arial", "arial-bold", "arial,bold", "arialmt",
        "timesnewroman", "couriernew",
    }
    unembedded = []
    seen_fonts = {}
    for i in range(doc.page_count):
        for f in doc.get_page_fonts(i):
            xref, ext, ftype, basefont, name, encoding, *_rest = f
            if xref not in seen_fonts:
                seen_fonts[xref] = basefont
                clean_name = basefont.split("+")[-1].lower()  # strip a subset prefix like "ABCDEF+"
                is_standard = clean_name in _STANDARD_FONTS
                if ext == "n/a" and not is_standard:
                    unembedded.append(basefont)
    all_embedded = not unembedded
    add("All fonts are embedded", all_embedded,
        "Every font used is embedded." if all_embedded
        else f"{len(unembedded)} non-embedded font(s): {', '.join(sorted(set(unembedded))[:10])}"
             " — text may render with substitute fonts on other machines.")

    page_count = doc.page_count
    doc.close()

    passed_count = sum(1 for c in checks if c["passed"])
    return {
        "page_count": page_count,
        "checks": checks,
        "passed": passed_count,
        "total": len(checks),
        "summary": f"{passed_count}/{len(checks)} checks passed.",
        "note": "Best-effort structural checklist, not a certified PDF/UA conformance test.",
    }

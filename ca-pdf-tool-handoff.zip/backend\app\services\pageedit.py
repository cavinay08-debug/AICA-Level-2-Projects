"""
Page Editor module — Feature Category 5's "Edit Text/Images/Shapes".

True in-place editing of existing PDF text (rewriting content streams token by
token) is a different order of complexity and isn't attempted here. What this
gives instead — and what every mainstream "edit a PDF" tool actually does — is
adding new text, images and shapes onto the page at chosen positions, using the
same click/drag PagePicker interaction already used for signatures and redaction.
"""
import fitz  # PyMuPDF


def _hex_to_rgb01(hex_color: str) -> tuple:
    hex_color = (hex_color or "").lstrip("#")
    if len(hex_color) != 6:
        hex_color = "0f172a"
    return tuple(int(hex_color[i:i + 2], 16) / 255 for i in (0, 2, 4))


def edit_page_content(input_path: str, output_path: str, texts: list | None = None,
                       shapes: list | None = None, images: list | None = None) -> int:
    """texts:  [{"page","x","y","text","font_size","color"}]
    shapes: [{"page","type":"rect"|"line"|"circle","x0","y0","x1","y1","color","width","fill"(optional hex)}]
    images: [{"page","x0","y0","x1","y1","path"}] — path is a server-side saved upload,
            set by the router (one uploaded file per placement).
    Returns the number of elements added."""
    texts, shapes, images = texts or [], shapes or [], images or []
    if not (texts or shapes or images):
        raise RuntimeError("Add at least one text box, shape or image first.")

    doc = fitz.open(input_path)
    pages = {}

    def page(pno):
        if pno not in pages:
            pages[pno] = doc[pno - 1]
        return pages[pno]

    count = 0
    for t in texts:
        pno = int(t.get("page", 0))
        if pno < 1 or pno > doc.page_count or not (t.get("text") or "").strip():
            continue
        page(pno).insert_text((t["x"], t["y"]), t["text"], fontsize=float(t.get("font_size", 12)),
                               fontname="helv", color=_hex_to_rgb01(t.get("color", "#0f172a")))
        count += 1

    for s in shapes:
        pno = int(s.get("page", 0))
        if pno < 1 or pno > doc.page_count:
            continue
        rect = fitz.Rect(s["x0"], s["y0"], s["x1"], s["y1"])
        color = _hex_to_rgb01(s.get("color", "#0f172a"))
        width = float(s.get("width", 2))
        fill = _hex_to_rgb01(s["fill"]) if s.get("fill") else None
        kind = s.get("type", "rect")
        p = page(pno)
        if kind == "rect":
            p.draw_rect(rect, color=color, fill=fill, width=width)
        elif kind == "circle":
            p.draw_oval(rect, color=color, fill=fill, width=width)
        elif kind == "line":
            p.draw_line((rect.x0, rect.y0), (rect.x1, rect.y1), color=color, width=width)
        else:
            continue
        count += 1

    for im in images:
        pno = int(im.get("page", 0))
        if pno < 1 or pno > doc.page_count or not im.get("path"):
            continue
        rect = fitz.Rect(im["x0"], im["y0"], im["x1"], im["y1"])
        page(pno).insert_image(rect, filename=im["path"], keep_proportion=True, overlay=True)
        count += 1

    doc.save(output_path)
    doc.close()
    return count

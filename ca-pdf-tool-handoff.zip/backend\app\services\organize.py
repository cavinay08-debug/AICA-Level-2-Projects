"""
Organize module — Feature Category 1.
Merge, Split, Extract, Delete, Reorder, Rotate, Insert, Bookmark/TOC.
Uses PyMuPDF (fitz) for all page-level operations.
"""
import fitz  # PyMuPDF
from typing import List, Tuple


def merge_pdfs(input_paths: List[str], output_path: str) -> str:
    result = fitz.open()
    for p in input_paths:
        with fitz.open(p) as src:
            result.insert_pdf(src)
    result.save(output_path)
    result.close()
    return output_path


def split_pdf_by_ranges(input_path: str, ranges: List[Tuple[int, int]], output_dir: str, base_name: str) -> List[str]:
    """ranges: list of (start_page, end_page) 1-indexed inclusive."""
    outputs = []
    with fitz.open(input_path) as src:
        for idx, (start, end) in enumerate(ranges, start=1):
            out = fitz.open()
            out.insert_pdf(src, from_page=start - 1, to_page=end - 1)
            out_path = f"{output_dir}/{base_name}_part{idx}.pdf"
            out.save(out_path)
            out.close()
            outputs.append(out_path)
    return outputs


def extract_pages(input_path: str, page_numbers: List[int], output_path: str) -> str:
    """page_numbers: 1-indexed list, order preserved as given (supports reordering too)."""
    with fitz.open(input_path) as src:
        out = fitz.open()
        for p in page_numbers:
            out.insert_pdf(src, from_page=p - 1, to_page=p - 1)
        out.save(output_path)
        out.close()
    return output_path


def delete_pages(input_path: str, page_numbers_to_delete: List[int], output_path: str) -> str:
    with fitz.open(input_path) as doc:
        zero_indexed = sorted([p - 1 for p in page_numbers_to_delete], reverse=True)
        for p in zero_indexed:
            doc.delete_page(p)
        doc.save(output_path)
    return output_path


def reorder_pages(input_path: str, new_order: List[int], output_path: str) -> str:
    """new_order: 1-indexed list describing the new page sequence, e.g. [3,1,2]."""
    return extract_pages(input_path, new_order, output_path)


def rotate_pages(input_path: str, page_numbers: List[int], degrees: int, output_path: str) -> str:
    """degrees must be 90, 180, or 270."""
    with fitz.open(input_path) as doc:
        target_pages = page_numbers or list(range(1, doc.page_count + 1))
        for p in target_pages:
            page = doc[p - 1]
            page.set_rotation((page.rotation + degrees) % 360)
        doc.save(output_path)
    return output_path


def insert_pages(base_path: str, insert_path: str, at_page: int, output_path: str) -> str:
    """Insert all pages of insert_path into base_path, before page `at_page` (1-indexed)."""
    with fitz.open(base_path) as base, fitz.open(insert_path) as ins:
        base.insert_pdf(ins, start_at=at_page - 1)
        base.save(output_path)
    return output_path


def render_page_png(input_path: str, page_number: int, dpi: int = 120) -> bytes:
    """Renders one page to PNG bytes — backs the on-screen page pickers used for
    draw-a-box redaction and click-to-place signing. 1-indexed page_number."""
    dpi = max(60, min(int(dpi or 120), 300))
    with fitz.open(input_path) as doc:
        if page_number < 1 or page_number > doc.page_count:
            raise ValueError(f"Page {page_number} doesn't exist — this PDF has {doc.page_count} page(s).")
        page = doc[page_number - 1]
        zoom = dpi / 72
        pix = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom))
        return pix.tobytes("png")


def combine_with_bookmarks(input_paths: List[str], labels: List[str], output_path: str) -> str:
    """Merge multiple PDFs and auto-generate a bookmark/TOC entry per source file.
    Ideal for CA annexure bundling (e.g. Financials, Bank Statements, Confirmations)."""
    result = fitz.open()
    toc = []
    page_cursor = 0
    for path, label in zip(input_paths, labels):
        with fitz.open(path) as src:
            result.insert_pdf(src)
            toc.append([1, label, page_cursor + 1])  # level 1 bookmark at first page of this doc
            page_cursor += src.page_count
    result.set_toc(toc)
    result.save(output_path)
    result.close()
    return output_path

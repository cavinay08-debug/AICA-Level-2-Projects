import json
import os
import uuid

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import List, Optional

from app.core.database import get_db
from app.core.paths import storage_dir
from app.models.db_models import Client, Matter, AuditLog
from app.services import accessibility as accessibility_svc
from app.services import portfolio as portfolio_svc
from app.services.audit import log_action

router = APIRouter(prefix="/api/workspace", tags=["workspace"])

STORAGE = os.path.join(storage_dir(), "tmp")
os.makedirs(STORAGE, exist_ok=True)


def _save_upload(f: UploadFile) -> str:
    path = os.path.join(STORAGE, f"{uuid.uuid4().hex}_{f.filename}")
    with open(path, "wb") as out:
        out.write(f.file.read())
    return path


def _run(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs)
    except RuntimeError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        raise HTTPException(400, f"Couldn't process this: {e}")


class ClientIn(BaseModel):
    name: str
    pan: Optional[str] = None
    gstin: Optional[str] = None


class MatterIn(BaseModel):
    client_id: int
    title: str
    financial_year: str


@router.post("/clients")
def create_client(payload: ClientIn, db: Session = Depends(get_db)):
    c = Client(name=payload.name, pan=payload.pan, gstin=payload.gstin)
    db.add(c)
    db.commit()
    db.refresh(c)
    return c


@router.get("/clients")
def list_clients(db: Session = Depends(get_db)):
    return db.query(Client).all()


@router.post("/matters")
def create_matter(payload: MatterIn, db: Session = Depends(get_db)):
    m = Matter(client_id=payload.client_id, title=payload.title, financial_year=payload.financial_year)
    db.add(m)
    db.commit()
    db.refresh(m)
    return m


@router.get("/clients/{client_id}/matters")
def list_matters(client_id: int, db: Session = Depends(get_db)):
    return db.query(Matter).filter(Matter.client_id == client_id).all()


@router.get("/audit-log")
def audit_log(limit: int = 200, db: Session = Depends(get_db)):
    rows = db.query(AuditLog).order_by(AuditLog.timestamp.desc()).limit(limit).all()
    return rows


@router.post("/accessibility-check")
async def accessibility_check(file: UploadFile = File(...), staff: str = Form("unknown"),
                               db: Session = Depends(get_db)):
    path = _save_upload(file)
    result = _run(accessibility_svc.check_accessibility, path)
    log_action(db, staff, "ACCESSIBILITY_CHECK", "WORKSPACE", detail=f"{file.filename}: {result['summary']}")
    return result


@router.post("/portfolio")
async def create_portfolio(files: List[UploadFile] = File(...), labels: str = Form(...),
                            title: str = Form("Document Package"), staff: str = Form("unknown"),
                            db: Session = Depends(get_db)):
    try:
        label_list = json.loads(labels)
        if not isinstance(label_list, list):
            raise ValueError
    except (json.JSONDecodeError, ValueError):
        raise HTTPException(400, "Couldn't read the file labels — expected one label per file.")
    if len(label_list) != len(files):
        raise HTTPException(400, f"Got {len(files)} file(s) but {len(label_list)} label(s) — need one label per file.")
    paths = [_save_upload(f) for f in files]
    out_path = os.path.join(STORAGE, f"portfolio_{uuid.uuid4().hex}.pdf")
    _run(portfolio_svc.create_portfolio, paths, label_list, out_path, title)
    log_action(db, staff, "CREATE_PORTFOLIO", "WORKSPACE", detail=f"{len(files)} file(s): {title!r}")
    return FileResponse(out_path, filename="portfolio.pdf", media_type="application/pdf")

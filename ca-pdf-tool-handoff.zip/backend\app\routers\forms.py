import json
import os
import uuid

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, Response
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.paths import storage_dir
from app.services import forms as svc
from app.services.audit import log_action

router = APIRouter(prefix="/api/forms", tags=["forms"])

STORAGE = os.path.join(storage_dir(), "tmp")
os.makedirs(STORAGE, exist_ok=True)


def _save_upload(f: UploadFile) -> str:
    path = os.path.join(STORAGE, f"{uuid.uuid4().hex}_{f.filename}")
    with open(path, "wb") as out:
        out.write(f.file.read())
    return path


def _run(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs)
    except RuntimeError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        raise HTTPException(400, f"Couldn't process this file: {e}")


@router.post("/detect")
async def detect(file: UploadFile = File(...)):
    path = _save_upload(file)
    return _run(svc.detect_fields, path)


@router.post("/fill")
async def fill(file: UploadFile = File(...), values: str = Form(...),
               staff: str = Form("unknown"), db: Session = Depends(get_db)):
    try:
        value_map = json.loads(values)
        if not isinstance(value_map, dict):
            raise ValueError
    except (json.JSONDecodeError, ValueError):
        raise HTTPException(400, "Couldn't read field values — expected a JSON object of name -> value.")
    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"filled_{uuid.uuid4().hex}.pdf")
    count = _run(svc.fill_fields, path, out_path, value_map)
    log_action(db, staff, "FILL_FORM", "FORMS", detail=f"{file.filename}: {count} field(s) filled")
    return FileResponse(out_path, filename="filled.pdf", media_type="application/pdf",
                         headers={"X-Fields-Filled": str(count), "Access-Control-Expose-Headers": "X-Fields-Filled"})


@router.post("/export")
async def export(file: UploadFile = File(...), fmt: str = Form("json")):
    path = _save_upload(file)
    data = _run(svc.export_field_data, path)
    if fmt == "csv":
        import csv
        import io
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["field_name", "value"])
        for k, v in data.items():
            w.writerow([k, v])
        return Response(content=buf.getvalue(), media_type="text/csv",
                         headers={"Content-Disposition": "attachment; filename=form_data.csv"})
    return data


@router.post("/create-fields")
async def create_fields(file: UploadFile = File(...), fields: str = Form(...),
                         staff: str = Form("unknown"), db: Session = Depends(get_db)):
    try:
        field_list = json.loads(fields)
        if not isinstance(field_list, list):
            raise ValueError
    except (json.JSONDecodeError, ValueError):
        raise HTTPException(400, "Couldn't read the field definitions.")
    path = _save_upload(file)
    out_path = os.path.join(STORAGE, f"formfields_{uuid.uuid4().hex}.pdf")
    _run(svc.create_fields, path, out_path, field_list)
    log_action(db, staff, "CREATE_FORM_FIELDS", "FORMS", detail=f"{file.filename}: {len(field_list)} field(s) added")
    return FileResponse(out_path, filename="form_with_fields.pdf", media_type="application/pdf")

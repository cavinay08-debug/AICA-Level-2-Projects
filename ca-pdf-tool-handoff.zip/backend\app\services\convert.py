"""
Convert module — Feature Categories 3 & 4.
Convert TO PDF: Word/Excel/PPT, Images, HTML, CSV, Scans.
Convert FROM PDF: Word, Excel (structured tables), PPT, Images, PDF/A.

External (non-pip) dependencies used here, must be installed on the office
server machine (see README):
  - LibreOffice  -> office_to_pdf() / html_to_pdf()   (Word/Excel/PPT/HTML -> PDF)
  - Ghostscript  -> pdf_to_pdfa()                     (archival PDF/A conversion)
Everything else (img2pdf, reportlab, pdf2docx, pdfplumber, openpyxl, python-pptx,
PyMuPDF) is pure-pip and needs no extra install.
"""
import csv
import glob
import io
import os
import shutil
import subprocess

import fitz  # PyMuPDF


# ---------------------------------------------------------------------------
# External binary discovery — checked lazily so Phase 1 features never care
# whether LibreOffice/Ghostscript are installed.
# ---------------------------------------------------------------------------
def _find_soffice() -> str | None:
    candidates = [
        shutil.which("soffice"),
        shutil.which("soffice.exe"),
        r"C:\Program Files\LibreOffice\program\soffice.exe",
        r"C:\Program Files (x86)\LibreOffice\program\soffice.exe",
        "/usr/bin/soffice",
        "/usr/bin/libreoffice",
        "/Applications/LibreOffice.app/Contents/MacOS/soffice",
    ]
    for c in candidates:
        if c and os.path.exists(c):
            return c
    return None


def _find_ghostscript() -> str | None:
    candidates = [
        shutil.which("gswin64c"),
        shutil.which("gswin64c.exe"),
        shutil.which("gswin32c"),
        shutil.which("gs"),
    ]
    for c in candidates:
        if c and os.path.exists(c):
            return c
    for pattern in (r"C:\Program Files\gs\gs*\bin\gswin64c.exe",
                     r"C:\Program Files (x86)\gs\gs*\bin\gswin32c.exe"):
        matches = sorted(glob.glob(pattern))
        if matches:
            return matches[-1]
    return None


# ---------------------------------------------------------------------------
# Convert TO PDF
# ---------------------------------------------------------------------------
def office_to_pdf(input_path: str, output_path: str) -> str:
    """Word/Excel/PPT (.doc/.docx/.xls/.xlsx/.ppt/.pptx) -> PDF via LibreOffice headless.
    Also handles HTML (see html_to_pdf, which reuses this)."""
    soffice = _find_soffice()
    if not soffice:
        raise RuntimeError(
            "LibreOffice isn't installed on this machine. Install LibreOffice to "
            "enable Word/Excel/PPT/HTML to PDF conversion, then try again."
        )
    outdir = os.path.dirname(output_path)
    cmd = [soffice, "--headless", "--norestore", "--convert-to", "pdf", "--outdir", outdir, input_path]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
    if result.returncode != 0:
        raise RuntimeError(f"Conversion failed: {result.stderr.strip() or result.stdout.strip()}")
    produced = os.path.join(outdir, os.path.splitext(os.path.basename(input_path))[0] + ".pdf")
    if not os.path.exists(produced):
        raise RuntimeError("LibreOffice ran but no PDF was produced — the source file may be corrupt.")
    if os.path.abspath(produced) != os.path.abspath(output_path):
        os.replace(produced, output_path)
    return output_path


def html_to_pdf(input_path: str, output_path: str) -> str:
    """HTML -> PDF via LibreOffice headless (handles local CSS reasonably well)."""
    return office_to_pdf(input_path, output_path)


def csv_to_pdf(input_path: str, output_path: str, title: str = "") -> str:
    """CSV -> PDF as a clean bordered table — suited to working papers/computations.
    Pure-Python (reportlab), no external binary needed."""
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    with open(input_path, newline="", encoding="utf-8-sig") as f:
        rows = list(csv.reader(f))
    if not rows:
        raise RuntimeError("This CSV file is empty.")

    styles = getSampleStyleSheet()
    cell_style = styles["BodyText"]
    cell_style.fontSize = 8
    cell_style.leading = 10

    n_cols = max(len(r) for r in rows)
    page_size = landscape(A4) if n_cols > 6 else A4
    doc = SimpleDocTemplate(output_path, pagesize=page_size,
                             topMargin=18 * mm, bottomMargin=15 * mm,
                             leftMargin=12 * mm, rightMargin=12 * mm)

    elements = []
    if title:
        elements.append(Paragraph(title, styles["Heading2"]))
        elements.append(Spacer(1, 8))

    table_data = [[Paragraph(str(cell), cell_style) for cell in row] for row in rows]
    table = Table(table_data, repeatRows=1)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1e293b")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#cbd5e1")),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f8fafc")]),
    ]))
    elements.append(table)
    doc.build(elements)
    return output_path


def images_to_pdf(image_paths: list[str], output_path: str) -> str:
    """One or more images (JPG/PNG, e.g. camera captures of scanned pages) -> single PDF,
    one page per image, in the given order."""
    try:
        import img2pdf
        with open(output_path, "wb") as f:
            f.write(img2pdf.convert(image_paths))
    except Exception:
        # Fallback for image modes img2pdf dislikes (CMYK JPEG, palette PNG, etc.)
        from PIL import Image
        imgs = [Image.open(p).convert("RGB") for p in image_paths]
        imgs[0].save(output_path, save_all=True, append_images=imgs[1:])
    return output_path


# ---------------------------------------------------------------------------
# Convert FROM PDF
# ---------------------------------------------------------------------------
def pdf_to_docx(input_path: str, output_path: str) -> str:
    from pdf2docx import Converter
    cv = Converter(input_path)
    try:
        cv.convert(output_path)
    finally:
        cv.close()
    return output_path


def pdf_to_xlsx(input_path: str, output_path: str) -> str:
    """Structured table extraction (pdfplumber, pure-Python, no Ghostscript needed).
    One worksheet per detected table. If no tables are found anywhere in the file,
    falls back to a plain-text dump per page so the user still gets something usable."""
    import pdfplumber
    from openpyxl import Workbook

    wb = Workbook()
    wb.remove(wb.active)
    found_any = False

    with pdfplumber.open(input_path) as pdf:
        for page_no, page in enumerate(pdf.pages, start=1):
            for t_idx, table in enumerate(page.extract_tables(), start=1):
                found_any = True
                ws = wb.create_sheet(title=f"Page{page_no}_T{t_idx}"[:31])
                for row in table:
                    ws.append([c if c is not None else "" for c in row])

        if not found_any:
            ws = wb.create_sheet(title="Text")
            for page_no, page in enumerate(pdf.pages, start=1):
                ws.append([f"--- Page {page_no} ---"])
                for line in (page.extract_text() or "").splitlines():
                    ws.append([line])

    wb.save(output_path)
    return output_path


def pdf_to_pptx(input_path: str, output_path: str, dpi: int = 150) -> str:
    """Each PDF page becomes one full-bleed slide image — reliable, layout-faithful,
    good enough for "slide-ready export" of already-designed pages."""
    from pptx import Presentation
    from pptx.util import Emu

    doc = fitz.open(input_path)
    if doc.page_count == 0:
        doc.close()
        raise RuntimeError("This PDF has no pages.")

    first_rect = doc[0].rect
    ratio = first_rect.height / first_rect.width if first_rect.width else 0.5625

    prs = Presentation()
    prs.slide_width = Emu(int(13.333 * 914400))
    prs.slide_height = Emu(int(13.333 * ratio * 914400))
    blank_layout = prs.slide_layouts[6]

    zoom = dpi / 72
    mat = fitz.Matrix(zoom, zoom)
    for page in doc:
        pix = page.get_pixmap(matrix=mat)
        img_stream = io.BytesIO(pix.tobytes("png"))
        slide = prs.slides.add_slide(blank_layout)
        slide.shapes.add_picture(img_stream, 0, 0, width=prs.slide_width, height=prs.slide_height)
    doc.close()
    prs.save(output_path)
    return output_path


def pdf_to_images(input_path: str, output_dir: str, fmt: str = "png", dpi: int = 150) -> list[str]:
    """Renders every page to an image file. Returns the list of output paths (caller zips them)."""
    fmt = (fmt or "png").lower()
    ext = "jpg" if fmt in ("jpg", "jpeg") else "png"
    dpi = max(72, min(int(dpi or 150), 600))

    doc = fitz.open(input_path)
    zoom = dpi / 72
    mat = fitz.Matrix(zoom, zoom)
    paths = []
    for i in range(doc.page_count):
        pix = doc[i].get_pixmap(matrix=mat)
        out_path = os.path.join(output_dir, f"page_{i + 1:03d}.{ext}")
        if ext == "jpg":
            with open(out_path, "wb") as f:
                f.write(pix.tobytes("jpeg", jpg_quality=90))
        else:
            pix.save(out_path)
        paths.append(out_path)
    doc.close()
    return paths


def pdf_to_pdfa(input_path: str, output_path: str, level: str = "2b") -> str:
    """Best-effort archival PDF/A conversion via Ghostscript's pdfwrite device.
    Note: this produces a PDF/A-compliant *structure* for statutory retention use;
    for formal PDF/A conformance certification, validate the output with a tool
    like veraPDF before relying on it for a compliance-critical filing."""
    gs = _find_ghostscript()
    if not gs:
        raise RuntimeError(
            "Ghostscript isn't installed on this machine. Install Ghostscript to "
            "enable PDF/A conversion, then try again."
        )
    level_num = "1" if level.startswith("1") else "3" if level.startswith("3") else "2"
    cmd = [
        gs, "-dPDFA=" + level_num, "-dBATCH", "-dNOPAUSE", "-dNOOUTERSAVE",
        "-sColorConversionStrategy=RGB", "-sDEVICE=pdfwrite",
        "-dPDFACompatibilityPolicy=1", f"-sOutputFile={output_path}", input_path,
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
    if result.returncode != 0 or not os.path.exists(output_path):
        raise RuntimeError(f"PDF/A conversion failed: {result.stderr.strip() or result.stdout.strip()}")
    return output_path

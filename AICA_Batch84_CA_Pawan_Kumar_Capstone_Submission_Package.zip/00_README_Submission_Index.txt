AICA BATCH 84 - CAPSTONE SUBMISSION PACKAGE
Submitted by: CA PAWAN KUMAR
Project: Universal GST Invoice Manager
Organisation branding: SPH & Associates, Chartered Accountants

CONTENTS
01 Project Summary (DOCX)
02 Master Development Prompt (TXT)
03 Enhancement Prompt History (TXT)
04 Executable HTML Application
05 Google Apps Script Backend
06 Dummy Party Master (CSV)
07 Dummy HSN/SAC Master (CSV)
08 Combined Dummy Data (JSON)
09 Deployment & User Guide (DOCX)
10 Test Cases & Expected Results (DOCX)
11A Example Goods Tax Invoice (PDF)
11B Example Service Tax Invoice (PDF)
12 Capstone Presentation (PPTX)
13 Capstone Presentation (PDF)

IMPORTANT
- All sample names/identifiers in the supplied dataset are fictional/dummy and intended only for academic demonstration.
- HSN/SAC classifications and configured rates are sample values and must be independently verified for live use.
- The HTML file can run locally for demo/localStorage use. Google Sheets persistence requires deployment of the supplied Apps Script backend and connection of the /exec URL in the Storage tab.

© 2026 SPH & Associates. All rights reserved.

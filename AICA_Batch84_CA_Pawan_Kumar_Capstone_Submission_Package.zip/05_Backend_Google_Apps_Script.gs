/**
 * SPH Universal GST Invoice Manager - Google Sheets backend (Sample Edition)
 * Created by SPH & Associates, Chartered Accountants
 * © 2026 SPH & Associates. All rights reserved.
 *
 * SETUP
 * 1. Create/open a Google Sheet -> Extensions -> Apps Script.
 * 2. Paste this file.
 * 3. Run setupSheets() once to create the four database sheets.
 * 4. Run resetAndSeedSampleData() ONCE if you want a clean sample database.
 *    WARNING: this deletes existing rows from Parties, GSTCodes, Invoices and InvoiceItems.
 * 5. Deploy as Web App and paste the /exec URL into the HTML app.
 */
const SHEETS={
 Parties:['id','name','address','role','registered','gstin','pan','state','stateCode','cin','prefix','updatedAt'],
 GSTCodes:['id','type','code','name','narration','uqc','gst','updatedAt'],
 Invoices:['id','sellerId','sellerName','fy','sequence','invoiceNo','invoiceDate','paymentTerms','buyerId','buyerName','buyerAddress','buyerGstin','buyerPan','buyerState','buyerStateCode','pos','posCode','taxType','rcm','reference','commonNarration','notes','taxable','cgst','sgst','igst','total','documentType','createdAt'],
 InvoiceItems:['id','invoiceId','lineNo','type','codeId','hsnSac','description','narration','qty','uqc','rate','gstRate','taxable','cgst','sgst','igst','total']
};

const SAMPLE_PARTIES=[
 ['p01','Aarav Buildtech Private Limited','Plot 21, Okhla Industrial Estate, Phase III, New Delhi-110020','Both','Yes','07AAAAA1111A1Z1','AAAAA1111A','Delhi','07','U45200DL2020PTC000001','AB/{FY}/'],
 ['p02','Bharat Cement Traders','18, Sector 18, Gurugram, Haryana-122015','Both','Yes','06BBBBB2222B1Z2','BBBBB2222B','Haryana','06','','BCT/{FY}/'],
 ['p03','Capital Steel & Infra LLP','B-44, Sahibabad Industrial Area, Ghaziabad, Uttar Pradesh-201010','Both','Yes','09CCCCC3333C1Z3','CCCCC3333C','Uttar Pradesh','09','AAX-0001','CSI/{FY}/'],
 ['p04','Delhi Stone Aggregates','Khasra 112, Alipur, Delhi-110036','Both','Yes','07DDDDD4444D1Z4','DDDDD4444D','Delhi','07','','DSA/{FY}/'],
 ['p05','Elite Realty Services Private Limited','C-9, Vasant Kunj, New Delhi-110070','Both','Yes','07EEEEE5555E1Z5','EEEEE5555E','Delhi','07','U70100DL2021PTC000005','ERS/{FY}/'],
 ['p06','Frontier Civil Works','SCO 14, Sector 17, Faridabad, Haryana-121002','Both','Yes','06FFFFF6666F1Z6','FFFFF6666F','Haryana','06','','FCW/{FY}/'],
 ['p07','Greenline Construction Solutions LLP','D-82, Sector 63, Noida, Uttar Pradesh-201301','Both','Yes','09GGGGG7777G1Z7','GGGGG7777G','Uttar Pradesh','09','AAY-0007','GCS/{FY}/'],
 ['p08','Rohit Mehra','Flat 302, Maple Residency, Saket, New Delhi-110017','Buyer','No','','','Delhi','07','','{FY}/'],
 ['p09','Neha Kapoor','House 48, DLF Phase II, Gurugram, Haryana-122002','Buyer','No','','','Haryana','06','','{FY}/'],
 ['p10','Arjun Singh','Villa 9, Sector 50, Noida, Uttar Pradesh-201301','Buyer','No','','','Uttar Pradesh','09','','{FY}/']
];

const SAMPLE_CODES=[
 ['sample_code_1','Goods','2523','Portland cement and similar hydraulic cements','Supply of cement / hydraulic cement as per purchase order or delivery challan.','BAG',28],
 ['sample_code_2','Goods','7214','Bars and rods of iron or non-alloy steel (TMT / reinforcement steel)','Supply of reinforcement steel / TMT bars as per order and actual weight.','KGS',18],
 ['sample_code_3','Goods','2517','Pebbles, gravel, broken or crushed stone used as concrete aggregate','Supply of stone aggregate / crushed stone as per order and weighment.','MT',5],
 ['sample_code_4','Goods','69041000','Ceramic building bricks','Supply of building bricks as per order / delivery challan.','NOS',12],
 ['sample_code_5','Service','997222','Real estate agency services on a fee or commission basis','Brokerage / real estate agency services rendered as per agreed terms.','NA',18],
 ['sample_code_6','Service','995419','Other construction services of residential buildings','Construction services rendered as per work order / contract and certified work.','NA',18],
 ['sample_code_7','Service','995429','General construction services of other civil engineering works n.e.c.','Civil / general construction services rendered as per work order / contract.','NA',18]
];

function setupSheets(){
 const ss=SpreadsheetApp.getActiveSpreadsheet();
 Object.entries(SHEETS).forEach(([n,h])=>{
   let sh=ss.getSheetByName(n); if(!sh) sh=ss.insertSheet(n);
   if(sh.getLastRow()===0) sh.getRange(1,1,1,h.length).setValues([h]);
   sh.setFrozenRows(1); sh.getRange(1,1,1,h.length).setFontWeight('bold');
 });
 return 'Sheets ready';
}

function resetAndSeedSampleData(){
 setupSheets();
 const ss=SpreadsheetApp.getActiveSpreadsheet();
 Object.entries(SHEETS).forEach(([n,h])=>{
   const sh=ss.getSheetByName(n);
   sh.clearContents();
   sh.getRange(1,1,1,h.length).setValues([h]).setFontWeight('bold');
   sh.setFrozenRows(1);
 });
 const now=new Date().toISOString();
 SAMPLE_PARTIES.forEach(r=>append_('Parties',{id:r[0],name:r[1],address:r[2],role:r[3],registered:r[4],gstin:r[5],pan:r[6],state:r[7],stateCode:r[8],cin:r[9],prefix:r[10],updatedAt:now}));
 SAMPLE_CODES.forEach(r=>append_('GSTCodes',{id:r[0],type:r[1],code:r[2],name:r[3],narration:r[4],uqc:r[5],gst:r[6],updatedAt:now}));
 return 'Existing data deleted; sample data loaded.';
}

function doGet(e){
 try{
   setupSheets();
   const a=e.parameter.action||'bootstrap';
   if(a==='bootstrap') return json_({ok:true,parties:readSheet_('Parties'),gstCodes:readSheet_('GSTCodes'),invoices:readSheet_('Invoices'),invoiceItems:readSheet_('InvoiceItems')});
   if(a==='nextInvoice'){
     const sellerId=e.parameter.sellerId,fy=e.parameter.fy;
     const s=readSheet_('Parties').find(x=>String(x.id)===String(sellerId));
     if(!s) throw new Error('Seller not found');
     const seq=nextSeq_(sellerId,fy),prefix=String(s.prefix||'{FY}/');
     return json_({ok:true,sequence:seq,invoiceNo:prefix.replace(/\{FY\}/g,fy)+String(seq).padStart(3,'0')});
   }
   return json_({ok:false,error:'Unknown action'});
 }catch(err){return json_({ok:false,error:String(err.message||err)})}
}

function doPost(e){
 try{
   setupSheets();
   const b=JSON.parse(e.postData.contents||'{}'),a=b.action,d=b.data||{};
   if(a==='resetSampleData') { resetAndSeedSampleData(); return json_({ok:true,message:'Sample data loaded'}); }
   if(a==='saveParty'){d.updatedAt=new Date().toISOString();upsert_('Parties',d);return json_({ok:true})}
   if(a==='saveCode'){d.updatedAt=new Date().toISOString();upsert_('GSTCodes',d);return json_({ok:true})}
   if(a==='saveInvoice'){
     const lock=LockService.getScriptLock(); lock.waitLock(20000);
     try{
       const s=readSheet_('Parties').find(x=>String(x.id)===String(d.sellerId));
       if(!s) throw new Error('Seller not found');
       if(!(String(s.role)==='Seller'||String(s.role)==='Both')) throw new Error('Selected party is not enabled as seller');
       const seq=nextSeq_(d.sellerId,d.fy),prefix=String(s.prefix||'{FY}/'),invNo=prefix.replace(/\{FY\}/g,d.fy)+String(seq).padStart(3,'0');
       d.sequence=seq; d.invoiceNo=invNo; d.id=d.id||Utilities.getUuid(); d.createdAt=d.createdAt||new Date().toISOString();
       const reg=String(s.registered).toLowerCase()==='yes';
       if(!reg){d.documentType='Invoice';d.taxType='none';d.cgst=0;d.sgst=0;d.igst=0;d.total=Number(d.taxable)||0;}else d.documentType='Tax Invoice';
       append_('Invoices',d);
       const items=Array.isArray(d.items)?d.items:[];
       items.forEach((it,n)=>{
         const taxable=(Number(it.qty)||0)*(Number(it.rate)||0),gst=reg?(Number(it.gstRate)||0):0,cgst=reg&&d.taxType==='intra'?taxable*gst/200:0,sgst=cgst,igst=reg&&d.taxType==='inter'?taxable*gst/100:0;
         append_('InvoiceItems',{...it,id:it.id||Utilities.getUuid(),invoiceId:d.id,lineNo:n+1,gstRate:gst,taxable,cgst,sgst,igst,total:taxable+cgst+sgst+igst});
       });
       return json_({ok:true,id:d.id,sequence:seq,invoiceNo:invNo,documentType:d.documentType});
     }finally{lock.releaseLock()}
   }
   return json_({ok:false,error:'Unknown action'});
 }catch(err){return json_({ok:false,error:String(err.message||err)})}
}

function nextSeq_(sellerId,fy){const nums=readSheet_('Invoices').filter(x=>String(x.sellerId)===String(sellerId)&&String(x.fy)===String(fy)).map(x=>Number(x.sequence)||0);return Math.max(0,...nums)+1}
function readAny_(sh){if(!sh||sh.getLastRow()<2)return[];const v=sh.getDataRange().getValues(),h=v.shift().map(String);return v.filter(r=>r.some(x=>x!==''&&x!==null)).map(r=>{const o={};h.forEach((k,i)=>o[k]=r[i] instanceof Date?r[i].toISOString():r[i]);return o})}
function readSheet_(n){return readAny_(SpreadsheetApp.getActiveSpreadsheet().getSheetByName(n))}
function upsert_(n,o){const sh=SpreadsheetApp.getActiveSpreadsheet().getSheetByName(n),h=SHEETS[n],v=sh.getDataRange().getValues();let row=-1;for(let i=1;i<v.length;i++)if(String(v[i][0])===String(o.id)){row=i+1;break}const d=h.map(k=>o[k]??'');if(row>0)sh.getRange(row,1,1,h.length).setValues([d]);else sh.appendRow(d)}
function append_(n,o){const sh=SpreadsheetApp.getActiveSpreadsheet().getSheetByName(n),h=SHEETS[n];sh.appendRow(h.map(k=>o[k]??''))}
function json_(o){return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON)}

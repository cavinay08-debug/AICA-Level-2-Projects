import React, { useState } from 'react';
import { Sparkles, Search, MapPin, ArrowRight, ShieldCheck, Compass, Flame, Umbrella, Mountain, Castle, Heart, Utensils } from 'lucide-react';
import { CATEGORIES_LIST } from '../data/destinations';

interface HeroSectionProps {
  onSearchSubmit: (query: string) => void;
  onSelectCategory: (category: string) => void;
  selectedCategory: string;
  onOpenAIPlanner: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onSearchSubmit,
  onSelectCategory,
  selectedCategory,
  onOpenAIPlanner
}) => {
  const [query, setQuery] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      onSearchSubmit(query.trim());
    }
  };

  const getCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case 'Flame':
        return <Flame className="w-4 h-4 text-orange-500" />;
      case 'Umbrella':
        return <Umbrella className="w-4 h-4 text-blue-500" />;
      case 'Mountain':
        return <Mountain className="w-4 h-4 text-emerald-500" />;
      case 'Castle':
        return <Castle className="w-4 h-4 text-amber-500" />;
      case 'Compass':
        return <Compass className="w-4 h-4 text-indigo-500" />;
      case 'Heart':
        return <Heart className="w-4 h-4 text-rose-500" />;
      case 'Utensils':
        return <Utensils className="w-4 h-4 text-yellow-500" />;
      default:
        return <Sparkles className="w-4 h-4 text-orange-500" />;
    }
  };

  return (
    <div className="relative overflow-hidden bg-white/5 backdrop-blur-2xl text-white rounded-3xl my-4 mx-2 sm:mx-6 shadow-2xl border border-white/10">
      
      {/* Background Hero Image with Overlays */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1477587458883-47145ed94245?q=80&w=2000&auto=format&fit=crop"
          alt="India Travel Banner"
          className="w-full h-full object-cover object-center opacity-25 scale-105 transform hover:scale-100 transition-transform duration-1000"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a14] via-[#0a0a14]/80 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0a0a14]/90 via-indigo-950/40 to-transparent" />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-6 py-16 sm:py-20 lg:py-24 text-center">
        
        {/* Top Tagline Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 backdrop-blur-xl border border-white/20 text-indigo-300 text-xs font-bold uppercase tracking-widest mb-6 shadow-lg shadow-indigo-500/10">
          <Sparkles className="w-3.5 h-3.5 text-indigo-400 animate-spin" style={{ animationDuration: '4s' }} />
          <span>Plan • Budget • Explore • Experience</span>
        </div>

        {/* Main Title */}
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight text-white leading-none mb-6">
          Discover Extraordinary <br className="hidden sm:inline" />
          <span className="text-indigo-400">Incredible India</span> with AI
        </h1>

        <p className="max-w-2xl mx-auto text-base sm:text-lg text-white/70 font-normal leading-relaxed mb-8">
          Intelligent day-wise itineraries, budget estimators, YouTube travel guides, weather insights, and instant PDF exports tailored for your dream Indian journey.
        </p>

        {/* Search Bar Form */}
        <form onSubmit={handleSubmit} className="max-w-3xl mx-auto mb-8">
          <div className="relative flex items-center p-2 rounded-2xl bg-white/5 backdrop-blur-2xl border border-white/15 shadow-2xl focus-within:border-indigo-500/80 transition-all">
            <div className="pl-4 pr-2 text-white/40">
              <MapPin className="w-5 h-5 text-indigo-400" />
            </div>
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Where do you want to go? (e.g. Jaipur, Goa, Leh, Kerala, Manali)..."
              className="w-full bg-transparent text-white placeholder-white/35 text-sm sm:text-base focus:outline-none py-3"
            />
            <button
              type="submit"
              className="flex items-center gap-2 px-6 py-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm shadow-lg shadow-indigo-600/30 transition-all shrink-0 cursor-pointer"
            >
              <Search className="w-4 h-4" />
              <span className="hidden sm:inline">Search</span>
            </button>
          </div>
        </form>

        {/* AI Trip Planner CTA & Stats */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-10">
          <button
            onClick={onOpenAIPlanner}
            className="w-full sm:w-auto flex items-center justify-center gap-3 px-8 py-4 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-base shadow-xl shadow-indigo-600/35 transform hover:-translate-y-0.5 active:translate-y-0 transition-all cursor-pointer border border-white/20"
          >
            <Sparkles className="w-5 h-5 text-indigo-200 fill-indigo-200" />
            <span>Generate Custom AI Itinerary</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>

        {/* Category Pills */}
        <div className="pt-6 border-t border-white/10">
          <p className="text-xs font-semibold text-white/50 uppercase tracking-widest mb-4">
            Popular Travel Categories
          </p>
          <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3">
            {CATEGORIES_LIST.map((cat) => {
              const isSelected = selectedCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => onSelectCategory(cat.id)}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all backdrop-blur-md ${
                    isSelected
                      ? 'bg-indigo-600 text-white border border-indigo-400 shadow-lg shadow-indigo-600/30 scale-105'
                      : 'bg-white/5 hover:bg-white/15 text-white/70 border border-white/10'
                  }`}
                >
                  {getCategoryIcon(cat.icon)}
                  <span>{cat.name}</span>
                </button>
              );
            })}
          </div>
        </div>

      </div>
    </div>
  );
};

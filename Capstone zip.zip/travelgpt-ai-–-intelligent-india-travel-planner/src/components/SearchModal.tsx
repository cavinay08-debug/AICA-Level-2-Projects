import React, { useState, useEffect } from 'react';
import { Search, X, MapPin, Compass, ArrowRight, History, Sparkles } from 'lucide-react';
import { DESTINATIONS } from '../data/destinations';
import { Destination } from '../types';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectDestination: (dest: Destination) => void;
  recentSearches: string[];
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  onSelectDestination,
  recentSearches
}) => {
  const [query, setQuery] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const filtered = query.trim()
    ? DESTINATIONS.filter(
        (d) =>
          d.name.toLowerCase().includes(query.toLowerCase()) ||
          d.state.toLowerCase().includes(query.toLowerCase()) ||
          d.category.some((c) => c.toLowerCase().includes(query.toLowerCase())) ||
          d.overview.toLowerCase().includes(query.toLowerCase())
      )
    : DESTINATIONS.slice(0, 6);

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4 bg-black/70 backdrop-blur-xl animate-fadeIn">
      <div className="bg-[#0f0f1e]/90 backdrop-blur-2xl rounded-3xl border border-white/15 shadow-2xl max-w-2xl w-full overflow-hidden space-y-4 p-4 sm:p-6 text-white">
        
        {/* Search Header Input */}
        <div className="relative flex items-center p-2 rounded-2xl bg-white/10 border border-white/15 backdrop-blur-md">
          <Search className="w-5 h-5 text-indigo-300 ml-3 mr-2" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search destination, state, beaches, temples, food..."
            className="w-full bg-transparent text-white placeholder-white/40 text-sm focus:outline-none py-2"
            autoFocus
          />
          {query && (
            <button onClick={() => setQuery('')} className="p-1 text-white/50 hover:text-white transition">
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="ml-2 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 border border-white/10 text-white/80 text-xs font-bold transition cursor-pointer"
          >
            ESC
          </button>
        </div>

        {/* Results / List */}
        <div className="max-h-96 overflow-y-auto space-y-2 pr-1">
          {filtered.length > 0 ? (
            filtered.map((dest) => (
              <div
                key={dest.id}
                onClick={() => {
                  onSelectDestination(dest);
                  onClose();
                }}
                className="group flex items-center justify-between p-3 rounded-2xl bg-white/5 hover:bg-indigo-600/20 border border-white/10 hover:border-indigo-400/30 transition cursor-pointer backdrop-blur-md"
              >
                <div className="flex items-center gap-3">
                  <img
                    src={dest.image}
                    alt={dest.name}
                    className="w-12 h-12 rounded-xl object-cover shrink-0 border border-white/10"
                  />
                  <div>
                    <h4 className="font-extrabold text-sm text-white group-hover:text-indigo-300 transition">
                      {dest.name}
                    </h4>
                    <span className="text-xs text-white/60">
                      {dest.state} • {dest.region} India
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[10px] font-bold">
                    ★ {dest.rating}
                  </span>
                  <ArrowRight className="w-4 h-4 text-white/40 group-hover:text-indigo-300 transition" />
                </div>
              </div>
            ))
          ) : (
            <div className="py-8 text-center text-white/50 text-xs">
              No destinations matching "{query}" found.
            </div>
          )}
        </div>

      </div>
    </div>
  );
};

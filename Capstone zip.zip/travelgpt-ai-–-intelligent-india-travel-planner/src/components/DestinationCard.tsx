import React from 'react';
import { Star, MapPin, Heart, Sparkles, ArrowRight, Sun } from 'lucide-react';
import { Destination } from '../types';

interface DestinationCardProps {
  destination: Destination;
  isFavorite: boolean;
  onToggleFavorite: (id: string, e: React.MouseEvent) => void;
  onSelectDestination: (destination: Destination) => void;
  onOpenAIPlannerForDest: (destinationName: string) => void;
}

export const DestinationCard: React.FC<DestinationCardProps> = ({
  destination,
  isFavorite,
  onToggleFavorite,
  onSelectDestination,
  onOpenAIPlannerForDest
}) => {
  return (
    <div
      onClick={() => onSelectDestination(destination)}
      className="group relative flex flex-col bg-white/5 hover:bg-white/10 backdrop-blur-xl rounded-3xl overflow-hidden border border-white/10 hover:border-white/25 shadow-xl hover:shadow-2xl hover:shadow-indigo-500/10 transition-all duration-300 transform hover:-translate-y-1 cursor-pointer text-white"
    >
      
      {/* Image Container */}
      <div className="relative h-60 w-full overflow-hidden bg-black/40">
        <img
          src={destination.image}
          alt={destination.name}
          className="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-700 ease-out"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a14] via-transparent to-black/30" />

        {/* Favorite Heart Button */}
        <button
          onClick={(e) => onToggleFavorite(destination.id, e)}
          className="absolute top-4 right-4 p-2.5 rounded-full bg-black/40 backdrop-blur-xl hover:bg-white/20 text-white hover:text-rose-400 transition-all border border-white/15 z-10"
          aria-label="Favorite"
        >
          <Heart className={`w-4 h-4 transition-all ${isFavorite ? 'fill-rose-500 text-rose-500 scale-110' : ''}`} />
        </button>

        {/* Region & State Badge */}
        <div className="absolute top-4 left-4 flex flex-wrap gap-1.5">
          <span className="px-2.5 py-1 rounded-full bg-black/50 backdrop-blur-md border border-white/15 text-white text-[10px] font-bold tracking-wider uppercase">
            {destination.state}
          </span>
          <span className="px-2.5 py-1 rounded-full bg-indigo-600/80 backdrop-blur-md text-white text-[10px] font-bold tracking-wider uppercase border border-indigo-400/30">
            {destination.region}
          </span>
        </div>

        {/* Bottom Image Overlay Details */}
        <div className="absolute bottom-3 left-4 right-4 flex items-end justify-between text-white">
          <div>
            <h3 className="text-2xl font-black tracking-tight text-white drop-shadow-md">
              {destination.name}
            </h3>
            <p className="text-xs text-white/80 font-medium line-clamp-1">
              {destination.tagline}
            </p>
          </div>
          <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-white/20 backdrop-blur-md text-yellow-300 font-bold text-xs border border-white/25 shadow-md shrink-0">
            <Star className="w-3.5 h-3.5 fill-yellow-400 text-yellow-400" />
            <span>{destination.rating}</span>
          </div>
        </div>
      </div>

      {/* Card Content Body */}
      <div className="flex-1 p-5 flex flex-col justify-between">
        
        {/* Overview Snippet */}
        <div>
          <p className="text-xs text-white/60 line-clamp-2 leading-relaxed mb-4">
            {destination.overview}
          </p>

          {/* Category Chips */}
          <div className="flex flex-wrap gap-1.5 mb-4">
            {destination.category.slice(0, 3).map((cat, i) => (
              <span
                key={i}
                className="px-2 py-0.5 rounded-md bg-white/5 border border-white/10 text-white/70 text-[10px] font-medium"
              >
                {cat}
              </span>
            ))}
          </div>

          {/* Quick Best Season Indicator */}
          <div className="flex items-center gap-2 text-xs text-white/60 mb-4 bg-white/5 p-2.5 rounded-2xl border border-white/10 backdrop-blur-md">
            <Sun className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="truncate">
              Best Time: <strong className="text-amber-300">{destination.bestTimeToVisit.split('(')[0]}</strong>
            </span>
          </div>
        </div>

        {/* Card Action Buttons */}
        <div className="flex items-center gap-2 pt-3 border-t border-white/10">
          <button
            onClick={() => onSelectDestination(destination)}
            className="flex-1 py-2.5 px-3 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold transition border border-white/15 flex items-center justify-center gap-1.5 backdrop-blur-md"
          >
            <span>Explore</span>
            <ArrowRight className="w-3.5 h-3.5 text-white/50" />
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              onOpenAIPlannerForDest(destination.name);
            }}
            className="flex-1 py-2.5 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition shadow-md shadow-indigo-600/30 flex items-center justify-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Itinerary</span>
          </button>
        </div>

      </div>
    </div>
  );
};

import React, { useState } from 'react';
import {
  ArrowLeft, Star, Heart, MapPin, Sparkles, Clock, Ticket, ShieldCheck, Info,
  Sun, Compass, Utensils, ShoppingBag, Bus, Play, CheckCircle2, ChevronRight,
  Cloud, Calendar, DollarSign, Hotel as HotelIcon, Share2, Layers, AlertCircle, PhoneCall, ExternalLink
} from 'lucide-react';
import { Destination, Attraction, Hotel, FoodItem, YouTubeVideo, TransportOption, NearbyDestination, AttractionCategory } from '../types';
import { ATTRACTIONS_DATA, HOTELS_DATA, FOOD_ITEMS, YOUTUBE_VIDEOS, NEARBY_DESTINATIONS, TRANSPORT_OPTIONS } from '../data/destinations';

interface DestinationDetailProps {
  destination: Destination;
  onBack: () => void;
  isFavorite: boolean;
  onToggleFavorite: (id: string) => void;
  onOpenAIPlannerForDest: (destinationName: string) => void;
  onSelectNearby: (destinationName: string) => void;
}

export const DestinationDetail: React.FC<DestinationDetailProps> = ({
  destination,
  onBack,
  isFavorite,
  onToggleFavorite,
  onOpenAIPlannerForDest,
  onSelectNearby
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'attractions' | 'videos' | 'hotels' | 'food' | 'shopping' | 'transport' | 'nearby' | 'map' | 'checklist'>('overview');
  
  // Filters
  const [attractionFilter, setAttractionFilter] = useState<string>('All');
  const [hotelFilter, setHotelFilter] = useState<'All' | 'Budget' | 'Mid Range' | 'Luxury'>('All');
  const [foodVegOnly, setFoodVegOnly] = useState<boolean>(false);
  const [selectedVideo, setSelectedVideo] = useState<YouTubeVideo | null>(null);

  // Filtered lists
  const destAttractions = ATTRACTIONS_DATA.filter((a) => a.destinationId === destination.id);
  const filteredAttractions = attractionFilter === 'All'
    ? destAttractions
    : destAttractions.filter((a) => a.category === attractionFilter);

  const destHotels = HOTELS_DATA.filter((h) => h.destinationId === destination.id);
  const filteredHotels = hotelFilter === 'All'
    ? destHotels
    : destHotels.filter((h) => h.category === hotelFilter);

  const destFood = FOOD_ITEMS.filter((f) => f.destinationId === destination.id);
  const filteredFood = foodVegOnly ? destFood.filter((f) => f.isVeg) : destFood;

  const destVideos = YOUTUBE_VIDEOS.filter((v) => v.videoId); // Get destination YouTube videos or mock list
  const nearbyPlaces = NEARBY_DESTINATIONS[destination.id] || NEARBY_DESTINATIONS['goa'];
  const transportList = TRANSPORT_OPTIONS[destination.id] || TRANSPORT_OPTIONS['goa'];

  // Map Iframe URL
  const googleMapEmbedUrl = `https://maps.google.com/maps?q=${encodeURIComponent(destination.name + ', India')}&t=&z=12&ie=UTF8&iwloc=&output=embed`;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8 animate-fadeIn text-white">
      
      {/* Top Navigation Bar */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/15 text-white font-bold text-sm backdrop-blur-md transition shadow-xs cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Explore</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onToggleFavorite(destination.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold border transition backdrop-blur-md cursor-pointer ${
              isFavorite
                ? 'bg-rose-500/20 border-rose-500/40 text-rose-300'
                : 'bg-white/10 border-white/15 text-white hover:bg-white/20'
            }`}
          >
            <Heart className={`w-4 h-4 ${isFavorite ? 'fill-rose-500 text-rose-500' : ''}`} />
            <span>{isFavorite ? 'Saved' : 'Save Destination'}</span>
          </button>

          <button
            onClick={() => onOpenAIPlannerForDest(destination.name)}
            className="flex items-center gap-2 px-5 py-2 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm shadow-lg shadow-indigo-600/30 active:scale-95 transition cursor-pointer"
          >
            <Sparkles className="w-4 h-4" />
            <span>Generate AI Itinerary</span>
          </button>
        </div>
      </div>

      {/* Hero Detail Header */}
      <div className="relative rounded-3xl overflow-hidden bg-white/5 backdrop-blur-2xl text-white shadow-2xl border border-white/10">
        <div className="relative h-80 sm:h-96 w-full">
          <img
            src={destination.heroImage}
            alt={destination.name}
            className="w-full h-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a14] via-[#0a0a14]/60 to-black/20" />

          {/* Hero Badges */}
          <div className="absolute top-6 left-6 flex flex-wrap gap-2">
            <span className="px-3 py-1 rounded-full bg-indigo-600/80 backdrop-blur-md border border-indigo-400/30 text-white font-bold text-xs uppercase tracking-wider shadow-md">
              {destination.state} • {destination.region} India
            </span>
            <div className="flex items-center gap-1 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-yellow-300 border border-white/25 font-bold text-xs shadow-md">
              <Star className="w-3.5 h-3.5 fill-yellow-400 text-yellow-400" />
              <span>{destination.rating} ({destination.reviewsCount.toLocaleString()} reviews)</span>
            </div>
          </div>

          {/* Title & Tagline */}
          <div className="absolute bottom-6 left-6 right-6 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <h1 className="text-4xl sm:text-5xl font-black tracking-tight text-white mb-2">
                {destination.name}
              </h1>
              <p className="text-base sm:text-lg text-indigo-200 font-medium italic">
                "{destination.tagline}"
              </p>
            </div>

            <button
              onClick={() => onOpenAIPlannerForDest(destination.name)}
              className="flex items-center gap-2 px-6 py-3 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm shadow-xl transition shrink-0 cursor-pointer border border-white/20"
            >
              <Sparkles className="w-4 h-4 text-indigo-200" />
              <span>Plan {destination.name} with AI</span>
            </button>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 border-b border-white/10 no-scrollbar">
        {[
          { id: 'overview', label: 'Overview & Info', icon: Info },
          { id: 'attractions', label: 'Attractions & Gems', icon: Compass },
          { id: 'videos', label: 'Watch Videos', icon: Play, badge: 'YouTube' },
          { id: 'hotels', label: 'Hotels & Stay', icon: HotelIcon },
          { id: 'food', label: 'Food Guide', icon: Utensils },
          { id: 'shopping', label: 'Shopping', icon: ShoppingBag },
          { id: 'transport', label: 'Transport', icon: Bus },
          { id: 'nearby', label: 'Nearby Places', icon: MapPin },
          { id: 'map', label: 'Google Map', icon: MapPin }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm whitespace-nowrap transition-all backdrop-blur-md cursor-pointer ${
                isActive
                  ? 'bg-indigo-600 text-white border border-indigo-400 shadow-lg shadow-indigo-600/30'
                  : 'bg-white/5 text-white/70 hover:bg-white/15 hover:text-white border border-white/10'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
              {tab.badge && (
                <span className="px-1.5 py-0.2 text-[9px] font-extrabold rounded bg-red-600 text-white uppercase">
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* TAB CONTENT 1: OVERVIEW & INFO */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Main Info Column */}
          <div className="lg:col-span-2 space-y-8">
            
            {/* Overview Card */}
            <div className="p-6 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 shadow-xl space-y-4">
              <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
                <Info className="w-5 h-5 text-indigo-400" />
                <span>Destination Overview</span>
              </h2>
              <p className="text-white/80 text-sm leading-relaxed font-normal">
                {destination.overview}
              </p>

              <div className="pt-4 border-t border-white/10 space-y-2">
                <h3 className="text-sm font-bold text-white">Historical Significance</h3>
                <p className="text-white/60 text-xs leading-relaxed">
                  {destination.history}
                </p>
              </div>
            </div>

            {/* Weather & Climate Breakdown */}
            <div className="p-6 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 shadow-xl space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
                  <Sun className="w-5 h-5 text-amber-400" />
                  <span>Weather & Climate</span>
                </h2>
                <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-bold backdrop-blur-md">
                  Current: {destination.weather.currentTemp}
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 rounded-2xl bg-white/5 border border-white/10 text-center">
                  <span className="text-[10px] font-bold text-white/40 uppercase">Condition</span>
                  <p className="text-xs font-bold text-white mt-1">{destination.weather.condition}</p>
                </div>
                <div className="p-3 rounded-2xl bg-white/5 border border-white/10 text-center">
                  <span className="text-[10px] font-bold text-white/40 uppercase">Humidity</span>
                  <p className="text-xs font-bold text-white mt-1">{destination.weather.humidity}</p>
                </div>
                <div className="p-3 rounded-2xl bg-white/5 border border-white/10 text-center">
                  <span className="text-[10px] font-bold text-white/40 uppercase">Rain Chance</span>
                  <p className="text-xs font-bold text-white mt-1">{destination.weather.rainProbability}</p>
                </div>
                <div className="p-3 rounded-2xl bg-white/5 border border-white/10 text-center">
                  <span className="text-[10px] font-bold text-white/40 uppercase">Best Season</span>
                  <p className="text-xs font-bold text-amber-300 mt-1">{destination.weather.bestSeason}</p>
                </div>
              </div>

              {/* Monthly breakdown */}
              <div className="pt-2 space-y-2">
                <span className="text-xs font-bold text-white/50 uppercase tracking-wider">Monthly Visitors Guide</span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {destination.weather.monthlyOverview.map((m, idx) => (
                    <div key={idx} className="p-2.5 rounded-xl bg-white/5 border border-white/10 text-xs">
                      <div className="font-bold text-white">{m.month}</div>
                      <div className="text-[11px] text-white/50">{m.temp}</div>
                      <span className={`inline-block mt-1 px-2 py-0.5 rounded text-[9px] font-extrabold uppercase ${
                        m.status === 'Ideal' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' :
                        m.status === 'Moderate' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' :
                        'bg-white/10 text-white/50 border border-white/10'
                      }`}>
                        {m.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Culture, Customs & Tips */}
            <div className="p-6 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 shadow-xl space-y-6">
              <div>
                <h3 className="text-base font-extrabold text-white mb-2">Culture & Tradition</h3>
                <p className="text-white/70 text-xs leading-relaxed">
                  {destination.culture}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-white/10">
                <div>
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>Safety Tips</span>
                  </h4>
                  <ul className="space-y-1.5 text-xs text-white/70">
                    {destination.safetyTips.map((tip, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="text-emerald-400 font-bold">•</span>
                        <span>{tip}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <Compass className="w-4 h-4 text-indigo-400" />
                    <span>Travel Insider Tips</span>
                  </h4>
                  <ul className="space-y-1.5 text-xs text-white/70">
                    {destination.travelTips.map((tip, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="text-indigo-400 font-bold">•</span>
                        <span>{tip}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

          </div>

          {/* Sidebar Info Cards */}
          <div className="space-y-6">
            
            {/* Timings & Entry Fees Card */}
            <div className="p-6 rounded-3xl bg-indigo-600/30 backdrop-blur-xl border border-indigo-500/40 text-white shadow-xl space-y-4">
              <h3 className="text-lg font-extrabold flex items-center gap-2 text-indigo-200">
                <Clock className="w-5 h-5 text-indigo-300" />
                <span>Timings & Entry Fees</span>
              </h3>

              <div className="space-y-3 text-xs">
                <div>
                  <span className="font-bold opacity-80 uppercase text-[10px] text-indigo-200 block">Opening & Closing Timings</span>
                  <p className="font-medium mt-0.5 text-white">{destination.openingClosingTimings}</p>
                </div>

                <div className="pt-2 border-t border-indigo-400/20">
                  <span className="font-bold opacity-80 uppercase text-[10px] text-indigo-200 block">Entry Fees & Passes</span>
                  <p className="font-medium mt-0.5 text-white">{destination.entryFees}</p>
                </div>
              </div>

              <button
                onClick={() => onOpenAIPlannerForDest(destination.name)}
                className="w-full py-3 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs shadow-lg transition mt-2 cursor-pointer border border-white/20"
              >
                Create Custom AI Itinerary
              </button>
            </div>

            {/* Practical Quick Facts */}
            <div className="p-6 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 shadow-xl space-y-4 text-xs">
              <h3 className="text-base font-extrabold text-white">Quick Practical Facts</h3>
              
              <div className="space-y-3 text-white/70">
                <div className="flex justify-between pb-2 border-b border-white/10">
                  <span className="font-semibold">Languages Spoken:</span>
                  <span className="font-bold text-white">{destination.languages.join(', ')}</span>
                </div>
                <div className="flex justify-between pb-2 border-b border-white/10">
                  <span className="font-semibold">Currency:</span>
                  <span className="font-bold text-white">{destination.currency}</span>
                </div>
                <div className="flex justify-between pb-2 border-b border-white/10">
                  <span className="font-semibold">State Capital / District:</span>
                  <span className="font-bold text-white">{destination.state}</span>
                </div>
              </div>

              <div className="pt-2">
                <span className="font-bold text-white block mb-2">Emergency Contacts:</span>
                <div className="space-y-1.5">
                  {destination.emergencyContacts.map((c, i) => (
                    <div key={i} className="flex justify-between items-center p-2 rounded-xl bg-white/5 border border-white/10">
                      <span className="text-white/60">{c.service}</span>
                      <span className="font-bold text-indigo-400">{c.number}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

          </div>

        </div>
      )}

      {/* TAB CONTENT 2: ATTRACTIONS & HIDDEN GEMS */}
      {activeTab === 'attractions' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-2xl font-black text-white">
                Attractions & Hidden Gems in {destination.name}
              </h2>
              <p className="text-xs text-white/60">
                Explore famous places, temples, beaches, historical forts, and secret local spots.
              </p>
            </div>

            {/* Category Filter Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
              {['All', 'Top Attractions', 'Hidden Gems', 'Adventure Activities', 'Temples', 'Historical Places', 'Beaches', 'Nightlife'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setAttractionFilter(cat)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition backdrop-blur-md cursor-pointer ${
                    attractionFilter === cat
                      ? 'bg-indigo-600 text-white border border-indigo-400'
                      : 'bg-white/5 text-white/70 hover:bg-white/15 hover:text-white border border-white/10'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredAttractions.length > 0 ? (
              filteredAttractions.map((attraction) => (
                <div
                  key={attraction.id}
                  className="bg-white/5 backdrop-blur-xl rounded-3xl overflow-hidden border border-white/10 shadow-xl hover:border-white/20 transition-all"
                >
                  <div className="relative h-48 w-full overflow-hidden">
                    <img
                      src={attraction.image}
                      alt={attraction.name}
                      className="w-full h-full object-cover"
                    />
                    <span className="absolute top-3 left-3 px-2.5 py-1 rounded-lg bg-black/60 backdrop-blur-md text-white font-bold text-[10px] uppercase">
                      {attraction.category}
                    </span>
                  </div>

                  <div className="p-5 space-y-3">
                    <h3 className="text-lg font-bold text-white">
                      {attraction.name}
                    </h3>
                    <p className="text-xs text-white/70 line-clamp-2 leading-relaxed">
                      {attraction.description}
                    </p>

                    <div className="pt-2 border-t border-white/10 space-y-1.5 text-xs text-white/60">
                      <div className="flex justify-between">
                        <span>Duration:</span>
                        <strong className="text-white">{attraction.duration}</strong>
                      </div>
                      <div className="flex justify-between">
                        <span>Entry Fee:</span>
                        <strong className="text-white">{attraction.entryFee}</strong>
                      </div>
                      <div className="flex justify-between">
                        <span>Timings:</span>
                        <strong className="text-white">{attraction.timing}</strong>
                      </div>
                    </div>

                    <div className="p-2.5 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-medium">
                      💡 <strong>Highlight:</strong> {attraction.highlight}
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="col-span-full py-12 text-center text-white/50">
                No attractions found for category "{attractionFilter}".
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB CONTENT 3: WATCH BEFORE YOU TRAVEL (YOUTUBE TRAVEL VIDEOS) */}
      {activeTab === 'videos' && (
        <div className="space-y-6">
          <div className="p-6 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-600/30 text-red-300 font-bold text-xs uppercase mb-2 border border-red-500/30">
                <Play className="w-3.5 h-3.5 fill-red-400 text-red-400" />
                <span>Watch Before You Travel</span>
              </div>
              <h2 className="text-2xl font-black">
                {destination.name} YouTube Travel & Food Guides
              </h2>
              <p className="text-xs text-white/60 mt-1">
                Visual travel guides, street food tours, budget tips, and 3-day itineraries.
              </p>
            </div>
          </div>

          {/* Video Player Modal or Embedded Viewer */}
          {selectedVideo && (
            <div className="p-4 rounded-3xl bg-white/10 backdrop-blur-2xl border border-white/20 shadow-2xl space-y-3">
              <div className="flex items-center justify-between text-white">
                <h3 className="font-bold text-base">{selectedVideo.title}</h3>
                <button
                  onClick={() => setSelectedVideo(null)}
                  className="px-3 py-1 rounded-lg bg-white/15 text-white text-xs hover:bg-white/25 cursor-pointer"
                >
                  Close Player
                </button>
              </div>
              <div className="relative pt-[56.25%] w-full rounded-2xl overflow-hidden bg-black">
                <iframe
                  className="absolute top-0 left-0 w-full h-full"
                  src={`https://www.youtube.com/embed/${selectedVideo.videoId}?autoplay=1`}
                  title={selectedVideo.title}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              </div>
            </div>
          )}

          {/* Videos Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {destVideos.map((video) => (
              <div
                key={video.id}
                onClick={() => setSelectedVideo(video)}
                className="group relative bg-white/5 backdrop-blur-xl rounded-3xl overflow-hidden border border-white/10 shadow-xl hover:border-white/20 transition cursor-pointer"
              >
                <div className="relative h-48 w-full overflow-hidden bg-black/40">
                  <img
                    src={video.thumbnail}
                    alt={video.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                  />
                  <div className="absolute inset-0 bg-black/30 group-hover:bg-black/10 transition" />

                  {/* Play Button Overlay */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-12 h-12 rounded-full bg-red-600 text-white flex items-center justify-center shadow-lg group-hover:scale-110 transition">
                      <Play className="w-5 h-5 fill-white ml-0.5" />
                    </div>
                  </div>

                  <span className="absolute bottom-3 right-3 px-2 py-0.5 rounded bg-black/80 text-white text-[10px] font-bold">
                    {video.duration}
                  </span>
                  <span className="absolute top-3 left-3 px-2.5 py-1 rounded-lg bg-red-600 text-white text-[10px] font-bold uppercase">
                    {video.category}
                  </span>
                </div>

                <div className="p-4 space-y-2">
                  <h4 className="font-bold text-sm text-white line-clamp-2 leading-snug">
                    {video.title}
                  </h4>
                  <div className="flex items-center justify-between text-xs text-white/50">
                    <span>{video.channel}</span>
                    <span>{video.views} views</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB CONTENT 4: HOTELS */}
      {activeTab === 'hotels' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-2xl font-black text-white">
                Recommended Stays in {destination.name}
              </h2>
              <p className="text-xs text-white/60">
                Handpicked Budget Hostels, Heritage Homestays & Luxury Resorts.
              </p>
            </div>

            <div className="flex items-center gap-2">
              {(['All', 'Budget', 'Mid Range', 'Luxury'] as const).map((tier) => (
                <button
                  key={tier}
                  onClick={() => setHotelFilter(tier)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer backdrop-blur-md ${
                    hotelFilter === tier
                      ? 'bg-indigo-600 text-white border border-indigo-400'
                      : 'bg-white/5 text-white/70 hover:bg-white/15 hover:text-white border border-white/10'
                  }`}
                >
                  {tier}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {filteredHotels.map((hotel) => (
              <div
                key={hotel.id}
                className="bg-white/5 backdrop-blur-xl rounded-3xl overflow-hidden border border-white/10 shadow-xl space-y-4 p-5 flex flex-col justify-between"
              >
                <div>
                  <div className="relative h-44 rounded-2xl overflow-hidden mb-4">
                    <img src={hotel.image} alt={hotel.name} className="w-full h-full object-cover" />
                    <span className="absolute top-3 left-3 px-2.5 py-1 rounded-lg bg-black/60 text-white text-[10px] font-bold uppercase backdrop-blur-md">
                      {hotel.category}
                    </span>
                    <div className="absolute bottom-3 right-3 flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white/20 text-yellow-300 backdrop-blur-md text-xs font-bold border border-white/20">
                      <Star className="w-3.5 h-3.5 fill-yellow-400 text-yellow-400" />
                      <span>{hotel.rating}</span>
                    </div>
                  </div>

                  <h3 className="text-lg font-bold text-white mb-1">
                    {hotel.name}
                  </h3>
                  <p className="text-xs text-white/60 mb-3 flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                    <span>{hotel.location}</span>
                  </p>

                  <div className="text-base font-extrabold text-indigo-300 mb-3">
                    {hotel.pricePerNight} <span className="text-xs font-normal text-white/50">/ night</span>
                  </div>

                  <div className="flex flex-wrap gap-1 mb-3">
                    {hotel.amenities.map((amenity, i) => (
                      <span key={i} className="px-2 py-0.5 rounded bg-white/10 text-[10px] text-white/80 font-medium border border-white/5">
                        {amenity}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="p-3 rounded-2xl bg-amber-500/10 text-amber-200 text-xs italic border border-amber-500/20 backdrop-blur-md">
                  📌 {hotel.bookingHint}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB CONTENT 5: FOOD GUIDE */}
      {activeTab === 'food' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-2xl font-black text-white">
                {destination.name} Culinary & Food Guide
              </h2>
              <p className="text-xs text-white/60">
                Must-try local dishes, famous street food stalls, and top rated restaurants.
              </p>
            </div>

            <label className="flex items-center gap-2 px-3 py-2 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 font-bold text-xs cursor-pointer backdrop-blur-md">
              <input
                type="checkbox"
                checked={foodVegOnly}
                onChange={(e) => setFoodVegOnly(e.target.checked)}
                className="accent-emerald-500 rounded"
              />
              <span>Pure Vegetarian Options Only</span>
            </label>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredFood.map((item) => (
              <div
                key={item.id}
                className="p-5 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 shadow-xl flex flex-col sm:flex-row gap-5"
              >
                <div className="w-full sm:w-36 h-36 rounded-2xl overflow-hidden shrink-0">
                  <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                </div>

                <div className="space-y-2 flex-1">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-base text-white">
                      {item.name}
                    </h3>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      item.isVeg ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                    }`}>
                      {item.isVeg ? '🟢 Pure Veg' : '🔴 Non-Veg'}
                    </span>
                  </div>

                  <p className="text-xs text-white/70 leading-relaxed">
                    {item.description}
                  </p>

                  <div className="text-xs font-bold text-indigo-300">
                    Price Range: {item.priceRange}
                  </div>

                  <div className="text-xs text-white/60">
                    <strong>Best Places to Eat:</strong> {item.recommendedPlaces.join(', ')}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB CONTENT 6: SHOPPING */}
      {activeTab === 'shopping' && (
        <div className="p-6 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 shadow-xl space-y-6">
          <h2 className="text-2xl font-black text-white">
            Shopping & Markets in {destination.name}
          </h2>
          <p className="text-xs text-white/70 leading-relaxed">
            Discover local handicrafts, textiles, spices, jewelry, and famous traditional street markets.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-3">
              <h3 className="font-bold text-base text-indigo-300">
                What to Buy & Famous Specialties
              </h3>
              <ul className="space-y-2 text-xs text-white/80">
                <li className="flex items-start gap-2">
                  <span className="text-indigo-400 font-bold">•</span>
                  <span>Handcrafted souvenirs, traditional art pieces, and local textiles.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-indigo-400 font-bold">•</span>
                  <span>Organic local spices, tea, coffee beans, and traditional sweets.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-indigo-400 font-bold">•</span>
                  <span>Artisanal leather footwear, brass statues, and silver jewelry.</span>
                </li>
              </ul>
            </div>

            <div className="p-5 rounded-2xl bg-amber-500/10 border border-amber-500/20 space-y-3 backdrop-blur-md">
              <h3 className="font-bold text-base text-amber-300">
                Bargaining & Market Tips
              </h3>
              <ul className="space-y-2 text-xs text-amber-200/80">
                <li>• Always compare prices across multiple vendors in street markets.</li>
                <li>• Bargain politely—starting at 60-70% of initial quoted price.</li>
                <li>• Carry cash in small denominations as local vendors prefer cash.</li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT 7: TRANSPORT */}
      {activeTab === 'transport' && (
        <div className="space-y-6">
          <h2 className="text-2xl font-black text-white">
            How to Reach & Local Transport in {destination.name}
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {transportList.map((t, idx) => (
              <div
                key={idx}
                className="p-6 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 shadow-xl space-y-3"
              >
                <div className="flex items-center gap-3">
                  <div className="p-3 rounded-2xl bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 font-bold">
                    <Bus className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-base text-white">{t.mode}</h3>
                    <span className="text-xs text-white/50">{t.frequency}</span>
                  </div>
                </div>

                <p className="text-xs text-white/70 leading-relaxed">
                  {t.description}
                </p>

                <div className="pt-2 border-t border-white/10 space-y-1 text-xs">
                  <div className="flex justify-between">
                    <span className="text-white/50">Travel Time:</span>
                    <strong className="text-white">{t.travelTime}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/50">Approx Cost:</span>
                    <strong className="text-indigo-300 font-bold">{t.approximateCost}</strong>
                  </div>
                </div>

                <div className="p-2.5 rounded-xl bg-white/5 border border-white/10 text-[11px] text-white/70">
                  💡 <strong>Tip:</strong> {t.tips}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB CONTENT 8: NEARBY DESTINATIONS */}
      {activeTab === 'nearby' && (
        <div className="space-y-6">
          <h2 className="text-2xl font-black text-white">
            Nearby Places to Explore from {destination.name}
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {nearbyPlaces.map((near) => (
              <div
                key={near.id}
                className="group p-4 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 shadow-xl space-y-3 hover:border-white/20 transition"
              >
                <div className="relative h-36 rounded-2xl overflow-hidden">
                  <img src={near.image} alt={near.name} className="w-full h-full object-cover group-hover:scale-105 transition" />
                  <span className="absolute top-2 right-2 px-2 py-0.5 rounded bg-black/60 text-white font-bold text-[10px] backdrop-blur-md">
                    {near.distance}
                  </span>
                </div>

                <h3 className="font-extrabold text-base text-white">
                  {near.name}
                </h3>
                <p className="text-xs text-white/60 line-clamp-2">
                  {near.highlight}
                </p>

                <div className="pt-2 flex items-center justify-between text-xs text-white/50 border-t border-white/10">
                  <span>Time: {near.travelTime}</span>
                  <button
                    onClick={() => onSelectNearby(near.name)}
                    className="text-indigo-300 font-bold flex items-center gap-1 hover:underline cursor-pointer"
                  >
                    <span>View</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB CONTENT 9: GOOGLE MAP */}
      {activeTab === 'map' && (
        <div className="p-6 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-black text-white">
                Google Map & Location: {destination.name}
              </h2>
              <p className="text-xs text-white/50">
                Coordinates: {destination.coordinates.lat}° N, {destination.coordinates.lng}° E
              </p>
            </div>
            <a
              href={`https://www.google.com/maps/search/?api=1&query=${destination.coordinates.lat},${destination.coordinates.lng}`}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-2 shadow-md transition"
            >
              <span>Open in Google Maps</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>

          <div className="h-96 w-full rounded-2xl overflow-hidden border border-white/10 shadow-inner">
            <iframe
              title={`${destination.name} Map`}
              width="100%"
              height="100%"
              frameBorder="0"
              scrolling="no"
              marginHeight={0}
              marginWidth={0}
              src={googleMapEmbedUrl}
            />
          </div>
        </div>
      )}

    </div>
  );
};

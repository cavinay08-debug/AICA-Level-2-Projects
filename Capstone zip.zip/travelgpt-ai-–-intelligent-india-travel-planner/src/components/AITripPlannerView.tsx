import React, { useState } from 'react';
import { Sparkles, Calendar, User, DollarSign, Send, Save, Download, Clock, MapPin, CheckCircle2, RefreshCw, AlertCircle, Utensils, Bus, Hotel as HotelIcon } from 'lucide-react';
import { DESTINATIONS } from '../data/destinations';
import { TripPlan } from '../types';
import { exportItineraryPDF } from '../utils/pdfExporter';

interface AITripPlannerViewProps {
  initialDestination?: string;
  onSaveTrip: (trip: TripPlan) => void;
}

export const AITripPlannerView: React.FC<AITripPlannerViewProps> = ({
  initialDestination = 'Goa',
  onSaveTrip
}) => {
  const [destinationName, setDestinationName] = useState(initialDestination);
  const [numberOfDays, setNumberOfDays] = useState<number>(3);
  const [travelType, setTravelType] = useState<'Solo' | 'Family' | 'Friends' | 'Honeymoon' | 'Pilgrimage' | 'Adventure' | 'Luxury' | 'Budget'>('Solo');
  const [budgetTier, setBudgetTier] = useState<'Budget' | 'Standard' | 'Luxury'>('Standard');
  const [specialRequests, setSpecialRequests] = useState('');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [generatedPlan, setGeneratedPlan] = useState<TripPlan | null>(null);
  const [isSaved, setIsSaved] = useState(false);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!destinationName) return;

    setLoading(true);
    setError(null);
    setIsSaved(false);

    try {
      const response = await fetch('/api/gemini/itinerary', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          destinationName,
          numberOfDays,
          travelType,
          budgetTier,
          specialRequests
        })
      });

      const data = await response.json();

      if (data.success && data.plan) {
        const fullTrip: TripPlan = {
          id: 'trip_' + Date.now(),
          title: data.plan.title || `${numberOfDays}-Day ${destinationName} ${travelType} Trip`,
          destinationId: destinationName.toLowerCase().replaceAll(/\s+/g, '-'),
          destinationName,
          numberOfDays,
          travelType,
          budgetTier,
          itinerary: data.plan.itinerary || [],
          totalBudget: data.plan.totalBudget || {
            accommodation: 3000,
            food: 2000,
            transport: 1500,
            entryTickets: 800,
            shopping: 1000,
            miscellaneous: 500,
            total: 8800
          },
          packingChecklist: [
            {
              category: 'Essential Clothing',
              items: [
                { id: 'p1', text: 'Breathable cotton outfits', packed: false },
                { id: 'p2', text: 'Comfortable walking shoes', packed: false }
              ]
            },
            {
              category: 'Documents & Electronics',
              items: [
                { id: 'p3', text: 'Government ID card & e-Tickets', packed: false },
                { id: 'p4', text: 'Power bank & phone chargers', packed: false }
              ]
            }
          ],
          createdAt: new Date().toISOString()
        };

        setGeneratedPlan(fullTrip);
      } else {
        throw new Error(data.message || 'Failed to generate itinerary');
      }
    } catch (err: any) {
      console.error('Itinerary generation error:', err);
      setError(err.message || 'Network error while generating AI itinerary.');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = () => {
    if (generatedPlan) {
      onSaveTrip(generatedPlan);
      setIsSaved(true);
    }
  };

  const handleExportPDF = () => {
    if (generatedPlan) {
      const destObj = DESTINATIONS.find((d) => d.name.toLowerCase() === destinationName.toLowerCase());
      exportItineraryPDF(generatedPlan, destObj);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8 animate-fadeIn text-white">
      
      {/* Header Banner */}
      <div className="p-8 rounded-3xl bg-white/5 backdrop-blur-2xl text-white shadow-2xl relative overflow-hidden border border-white/10">
        <div className="relative z-10 max-w-3xl space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-indigo-500/20 text-indigo-300 font-bold text-xs uppercase tracking-wider border border-indigo-500/30 backdrop-blur-md">
            <Sparkles className="w-3.5 h-3.5 text-indigo-300" />
            <span>Powered by Gemini AI</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black tracking-tight text-white">
            Intelligent AI Travel Itinerary Generator
          </h1>
          <p className="text-sm text-white/70 font-normal leading-relaxed">
            Specify your destination, number of days, travel style, and budget tier. Our Gemini AI will craft an authentic day-by-day plan with morning, afternoon, evening activities, local food, transport, and budget estimations.
          </p>
        </div>
      </div>

      {/* Form & Config Card */}
      <div className="p-6 sm:p-8 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 shadow-xl space-y-6">
        <form onSubmit={handleGenerate} className="space-y-6">
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            
            {/* Destination Dropdown / Input */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-white/80 uppercase tracking-wider">
                Select Destination
              </label>
              <select
                value={destinationName}
                onChange={(e) => setDestinationName(e.target.value)}
                className="w-full p-3.5 rounded-2xl bg-white/10 border border-white/15 text-white font-bold text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer"
              >
                {DESTINATIONS.map((d) => (
                  <option key={d.id} value={d.name} className="bg-slate-900 text-white">
                    {d.name} ({d.state})
                  </option>
                ))}
              </select>
            </div>

            {/* Days Picker (1, 2, 3, 4, 5, 7, 10, 15) */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-white/80 uppercase tracking-wider">
                Number of Days
              </label>
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
                {[1, 2, 3, 4, 5, 7, 10, 15].map((d) => (
                  <button
                    key={d}
                    type="button"
                    onClick={() => setNumberOfDays(d)}
                    className={`px-3 py-2.5 rounded-xl font-bold text-xs transition cursor-pointer backdrop-blur-md ${
                      numberOfDays === d
                        ? 'bg-indigo-600 text-white border border-indigo-400 shadow-md shadow-indigo-600/30'
                        : 'bg-white/5 text-white/70 hover:bg-white/15 hover:text-white border border-white/10'
                    }`}
                  >
                    {d}D
                  </button>
                ))}
              </div>
            </div>

            {/* Travel Type */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-white/80 uppercase tracking-wider">
                Travel Type
              </label>
              <select
                value={travelType}
                onChange={(e) => setTravelType(e.target.value as any)}
                className="w-full p-3.5 rounded-2xl bg-white/10 border border-white/15 text-white font-bold text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer"
              >
                <option value="Solo" className="bg-slate-900 text-white">Solo Traveler</option>
                <option value="Family" className="bg-slate-900 text-white">Family Vacation</option>
                <option value="Friends" className="bg-slate-900 text-white">Friends Group</option>
                <option value="Honeymoon" className="bg-slate-900 text-white">Honeymoon / Romantic</option>
                <option value="Pilgrimage" className="bg-slate-900 text-white">Pilgrimage / Yatra</option>
                <option value="Adventure" className="bg-slate-900 text-white">Adventure & Treks</option>
                <option value="Luxury" className="bg-slate-900 text-white">Luxury & Comfort</option>
                <option value="Budget" className="bg-slate-900 text-white">Backpacker / Budget</option>
              </select>
            </div>

            {/* Budget Tier */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-white/80 uppercase tracking-wider">
                Budget Tier
              </label>
              <div className="grid grid-cols-3 gap-1.5">
                {(['Budget', 'Standard', 'Luxury'] as const).map((b) => (
                  <button
                    key={b}
                    type="button"
                    onClick={() => setBudgetTier(b)}
                    className={`py-3 rounded-xl font-bold text-xs transition cursor-pointer backdrop-blur-md ${
                      budgetTier === b
                        ? 'bg-indigo-600 text-white border border-indigo-400 shadow-md shadow-indigo-600/30'
                        : 'bg-white/5 text-white/70 hover:bg-white/15 hover:text-white border border-white/10'
                    }`}
                  >
                    {b}
                  </button>
                ))}
              </div>
            </div>

          </div>

          {/* Special Requests / Custom Preferences */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-white/80 uppercase tracking-wider">
              Custom Requests / Preferences (Optional)
            </label>
            <input
              type="text"
              value={specialRequests}
              onChange={(e) => setSpecialRequests(e.target.value)}
              placeholder="e.g. Include vegetarian food spots, early morning temple darshan, sunset views, and local handicraft markets..."
              className="w-full p-3.5 rounded-2xl bg-white/10 border border-white/15 text-white placeholder-white/40 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 backdrop-blur-md"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-4 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white font-black text-base shadow-xl shadow-indigo-600/30 flex items-center justify-center gap-3 transition cursor-pointer border border-indigo-400/30 disabled:opacity-60"
          >
            {loading ? (
              <>
                <RefreshCw className="w-5 h-5 animate-spin" />
                <span>Crafting Your Custom AI Travel Itinerary...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5 text-indigo-200" />
                <span>Generate {destinationName} Itinerary with Gemini AI</span>
              </>
            )}
          </button>
        </form>
      </div>

      {/* Loading Indicator */}
      {loading && (
        <div className="p-12 text-center rounded-3xl bg-white/5 backdrop-blur-2xl border border-white/10 shadow-2xl space-y-4">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-indigo-600/40 border border-indigo-400/40 p-0.5 animate-bounce">
            <div className="w-full h-full bg-[#0a0a14] rounded-[14px] flex items-center justify-center">
              <Sparkles className="w-8 h-8 text-indigo-400 animate-spin" style={{ animationDuration: '3s' }} />
            </div>
          </div>
          <h3 className="text-xl font-black text-white">
            Gemini AI is designing your {numberOfDays}-Day {destinationName} trip...
          </h3>
          <p className="text-xs text-white/60 max-w-md mx-auto">
            Analyzing local attractions, authentic restaurants, optimal travel logistics, and estimated costs.
          </p>
        </div>
      )}

      {/* Error Banner */}
      {error && (
        <div className="p-4 rounded-2xl bg-rose-500/20 border border-rose-500/30 text-rose-300 backdrop-blur-md flex items-center gap-3 text-sm font-semibold">
          <AlertCircle className="w-5 h-5 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* GENERATED ITINERARY DISPLAY */}
      {generatedPlan && !loading && (
        <div className="space-y-8 animate-fadeIn">
          
          {/* Action Header Banner */}
          <div className="p-6 rounded-3xl bg-white/5 backdrop-blur-2xl border border-white/10 text-white flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
            <div>
              <span className="px-3 py-1 rounded-full bg-indigo-600 text-white font-extrabold text-[10px] uppercase tracking-wider border border-indigo-400/30">
                AI Generated Itinerary
              </span>
              <h2 className="text-2xl font-black mt-1">{generatedPlan.title}</h2>
              <p className="text-xs text-white/70">
                {generatedPlan.numberOfDays} Days • {generatedPlan.travelType} Style • {generatedPlan.budgetTier} Budget
              </p>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              <button
                onClick={handleSave}
                disabled={isSaved}
                className={`flex items-center gap-2 px-5 py-3 rounded-full font-bold text-xs transition shadow-md ${
                  isSaved
                    ? 'bg-emerald-600/40 border border-emerald-500/40 text-emerald-300 cursor-default'
                    : 'bg-indigo-600 hover:bg-indigo-500 text-white cursor-pointer border border-indigo-400/30'
                }`}
              >
                {isSaved ? <CheckCircle2 className="w-4 h-4" /> : <Save className="w-4 h-4" />}
                <span>{isSaved ? 'Saved to Database' : 'Save Trip'}</span>
              </button>

              <button
                onClick={handleExportPDF}
                className="flex items-center gap-2 px-5 py-3 rounded-full bg-white/10 hover:bg-white/20 border border-white/15 text-white font-bold text-xs transition shadow-md cursor-pointer backdrop-blur-md"
              >
                <Download className="w-4 h-4 text-indigo-300" />
                <span>Export PDF</span>
              </button>
            </div>
          </div>

          {/* Day-Wise Cards */}
          <div className="space-y-6">
            <h3 className="text-2xl font-black text-white">
              Day-by-Day Schedule
            </h3>

            {generatedPlan.itinerary.map((day) => (
              <div
                key={day.day}
                className="p-6 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 shadow-xl space-y-6"
              >
                <div className="flex items-center justify-between border-b border-white/10 pb-4">
                  <div className="flex items-center gap-3">
                    <span className="w-10 h-10 rounded-2xl bg-indigo-600 text-white font-black text-sm flex items-center justify-center shadow-md border border-indigo-400/30">
                      D{day.day}
                    </span>
                    <div>
                      <h4 className="text-lg font-extrabold text-white">
                        {day.title}
                      </h4>
                      <span className="text-xs text-indigo-300 font-bold">
                        Theme: {day.theme}
                      </span>
                    </div>
                  </div>

                  {day.approxBudget && (
                    <div className="text-right">
                      <span className="text-[10px] font-bold text-white/50 uppercase block">Est. Day Cost</span>
                      <strong className="text-sm font-black text-white">
                        ₹{day.approxBudget.total?.toLocaleString('en-IN') || 0}
                      </strong>
                    </div>
                  )}
                </div>

                {/* Morning, Afternoon, Evening Cards */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                  
                  <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 backdrop-blur-md space-y-1.5">
                    <span className="font-extrabold text-amber-300 uppercase tracking-wider block">
                      🌅 Morning
                    </span>
                    <p className="text-white/80 leading-relaxed font-medium">
                      {day.morning}
                    </p>
                  </div>

                  <div className="p-4 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 backdrop-blur-md space-y-1.5">
                    <span className="font-extrabold text-indigo-300 uppercase tracking-wider block">
                      ☀️ Afternoon
                    </span>
                    <p className="text-white/80 leading-relaxed font-medium">
                      {day.afternoon}
                    </p>
                  </div>

                  <div className="p-4 rounded-2xl bg-purple-500/10 border border-purple-500/20 backdrop-blur-md space-y-1.5">
                    <span className="font-extrabold text-purple-300 uppercase tracking-wider block">
                      🌆 Evening
                    </span>
                    <p className="text-white/80 leading-relaxed font-medium">
                      {day.evening}
                    </p>
                  </div>

                </div>

                {/* Logistics Footer */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 text-xs">
                  <div className="flex items-center gap-2 p-3 rounded-xl bg-white/5 border border-white/10">
                    <Utensils className="w-4 h-4 text-amber-400 shrink-0" />
                    <span className="truncate"><strong>Food:</strong> {day.food}</span>
                  </div>
                  <div className="flex items-center gap-2 p-3 rounded-xl bg-white/5 border border-white/10">
                    <Bus className="w-4 h-4 text-indigo-400 shrink-0" />
                    <span className="truncate"><strong>Travel:</strong> {day.travel}</span>
                  </div>
                  <div className="flex items-center gap-2 p-3 rounded-xl bg-white/5 border border-white/10">
                    <HotelIcon className="w-4 h-4 text-purple-400 shrink-0" />
                    <span className="truncate"><strong>Stay:</strong> {day.stay}</span>
                  </div>
                </div>

              </div>
            ))}
          </div>

          {/* Budget Total Summary Card */}
          <div className="p-6 rounded-3xl bg-white/5 backdrop-blur-2xl border border-white/10 text-white shadow-xl space-y-4">
            <h3 className="text-xl font-black flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-amber-300" />
              <span>Estimated Budget Summary</span>
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10">
                <span className="text-[10px] text-white/50 uppercase font-bold block">Stay</span>
                <strong className="text-sm">₹{generatedPlan.totalBudget.accommodation.toLocaleString('en-IN')}</strong>
              </div>
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10">
                <span className="text-[10px] text-white/50 uppercase font-bold block">Food</span>
                <strong className="text-sm">₹{generatedPlan.totalBudget.food.toLocaleString('en-IN')}</strong>
              </div>
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10">
                <span className="text-[10px] text-white/50 uppercase font-bold block">Transport</span>
                <strong className="text-sm">₹{generatedPlan.totalBudget.transport.toLocaleString('en-IN')}</strong>
              </div>
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10">
                <span className="text-[10px] text-white/50 uppercase font-bold block">Entry Tickets</span>
                <strong className="text-sm">₹{generatedPlan.totalBudget.entryTickets.toLocaleString('en-IN')}</strong>
              </div>
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10">
                <span className="text-[10px] text-white/50 uppercase font-bold block">Shopping</span>
                <strong className="text-sm">₹{generatedPlan.totalBudget.shopping.toLocaleString('en-IN')}</strong>
              </div>
              <div className="p-3 rounded-2xl bg-indigo-600 border border-indigo-400/40 text-white">
                <span className="text-[10px] uppercase font-bold block opacity-90">Total Est.</span>
                <strong className="text-base font-black">₹{generatedPlan.totalBudget.total.toLocaleString('en-IN')}</strong>
              </div>
            </div>
          </div>

        </div>
      )}

    </div>
  );
};

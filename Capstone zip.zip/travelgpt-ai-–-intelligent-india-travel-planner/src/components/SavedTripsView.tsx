import React, { useState } from 'react';
import { Calendar, Trash2, Download, Eye, MapPin, DollarSign, Sparkles, AlertCircle, X } from 'lucide-react';
import { TripPlan } from '../types';
import { exportItineraryPDF } from '../utils/pdfExporter';
import { DESTINATIONS } from '../data/destinations';

interface SavedTripsViewProps {
  trips: TripPlan[];
  onDeleteTrip: (id: string) => void;
  onOpenAIPlanner: () => void;
}

export const SavedTripsView: React.FC<SavedTripsViewProps> = ({
  trips,
  onDeleteTrip,
  onOpenAIPlanner
}) => {
  const [selectedTripModal, setSelectedTripModal] = useState<TripPlan | null>(null);

  const handleExportPDF = (trip: TripPlan, e: React.MouseEvent) => {
    e.stopPropagation();
    const destObj = DESTINATIONS.find((d) => d.name.toLowerCase() === trip.destinationName.toLowerCase());
    exportItineraryPDF(trip, destObj);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8 animate-fadeIn text-white">
      
      {/* Header Banner */}
      <div className="p-8 rounded-3xl bg-white/5 backdrop-blur-2xl text-white shadow-2xl relative overflow-hidden border border-white/10 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-indigo-500/20 text-indigo-300 font-bold text-xs uppercase tracking-wider border border-indigo-500/30 backdrop-blur-md">
            <Calendar className="w-3.5 h-3.5 text-indigo-300" />
            <span>Saved Travel Plans</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black tracking-tight text-white">
            Your Saved Travel Itineraries
          </h1>
          <p className="text-sm text-white/70 font-normal">
            Access your saved AI itineraries, view day-wise schedules, and export ready-to-print PDFs anytime.
          </p>
        </div>

        <button
          onClick={onOpenAIPlanner}
          className="px-6 py-3.5 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 border border-indigo-400/30 flex items-center gap-2 shrink-0 cursor-pointer transition"
        >
          <Sparkles className="w-4 h-4 text-indigo-200" />
          <span>Plan New AI Trip</span>
        </button>
      </div>

      {/* Trips Grid */}
      {trips.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {trips.map((trip) => (
            <div
              key={trip.id}
              onClick={() => setSelectedTripModal(trip)}
              className="group p-6 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 shadow-xl hover:border-white/20 transition flex flex-col justify-between space-y-4 cursor-pointer"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 text-[10px] font-extrabold uppercase backdrop-blur-md">
                    {trip.destinationName}
                  </span>
                  <span className="text-[10px] text-white/40 font-medium">
                    {trip.createdAt ? new Date(trip.createdAt).toLocaleDateString('en-IN') : 'Saved'}
                  </span>
                </div>

                <h3 className="text-lg font-black text-white line-clamp-2">
                  {trip.title}
                </h3>

                <div className="flex items-center gap-4 text-xs text-white/60 font-semibold pt-1">
                  <span>{trip.numberOfDays} Days</span>
                  <span>•</span>
                  <span>{trip.travelType}</span>
                  <span>•</span>
                  <span>{trip.budgetTier} Budget</span>
                </div>

                <div className="p-3 rounded-2xl bg-white/5 border border-white/10 flex justify-between items-center text-xs backdrop-blur-md">
                  <span className="text-white/60">Est. Total Budget:</span>
                  <strong className="text-indigo-300 font-black">
                    ₹{trip.totalBudget?.total?.toLocaleString('en-IN') || 'N/A'}
                  </strong>
                </div>
              </div>

              <div className="pt-3 border-t border-white/10 flex items-center justify-between gap-2">
                <button
                  onClick={() => setSelectedTripModal(trip)}
                  className="flex-1 py-2 px-3 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Eye className="w-3.5 h-3.5 text-white/70" />
                  <span>View Itinerary</span>
                </button>

                <button
                  onClick={(e) => handleExportPDF(trip, e)}
                  className="p-2.5 rounded-xl bg-indigo-500/20 hover:bg-indigo-600 border border-indigo-500/30 text-indigo-200 hover:text-white text-xs font-bold transition cursor-pointer"
                  title="Export PDF"
                >
                  <Download className="w-4 h-4" />
                </button>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    if (confirm('Are you sure you want to delete this saved trip?')) {
                      onDeleteTrip(trip.id);
                    }
                  }}
                  className="p-2.5 rounded-xl bg-rose-500/20 hover:bg-rose-600 border border-rose-500/30 text-rose-300 hover:text-white text-xs font-bold transition cursor-pointer"
                  title="Delete Trip"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="p-12 text-center rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 shadow-xl space-y-4">
          <Calendar className="w-12 h-12 mx-auto text-white/40" />
          <h3 className="text-xl font-bold text-white">
            No Saved Trips Yet
          </h3>
          <p className="text-xs text-white/60 max-w-sm mx-auto">
            Generate custom AI itineraries using the AI Trip Planner and save them here for easy offline reference and PDF export.
          </p>
          <button
            onClick={onOpenAIPlanner}
            className="px-6 py-3 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition border border-indigo-400/30 cursor-pointer shadow-lg shadow-indigo-600/30"
          >
            Create Your First AI Itinerary
          </button>
        </div>
      )}

      {/* TRIP DETAIL MODAL */}
      {selectedTripModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xl animate-fadeIn">
          <div className="bg-[#0f0f1e]/90 backdrop-blur-2xl rounded-3xl border border-white/15 shadow-2xl max-w-3xl w-full max-h-[85vh] overflow-y-auto p-6 space-y-6 text-white">
            
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div>
                <span className="px-2.5 py-0.5 rounded-full bg-indigo-600 text-white font-bold text-[10px] uppercase border border-indigo-400/30">
                  {selectedTripModal.destinationName}
                </span>
                <h2 className="text-xl font-black text-white mt-1">
                  {selectedTripModal.title}
                </h2>
              </div>

              <button
                onClick={() => setSelectedTripModal(null)}
                className="p-2 rounded-xl text-white/60 hover:text-white hover:bg-white/10 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              {selectedTripModal.itinerary.map((day) => (
                <div key={day.day} className="p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md space-y-2 text-xs">
                  <div className="font-extrabold text-white text-sm">
                    Day {day.day}: {day.title}
                  </div>
                  <p className="text-white/80"><strong>Morning:</strong> {day.morning}</p>
                  <p className="text-white/80"><strong>Afternoon:</strong> {day.afternoon}</p>
                  <p className="text-white/80"><strong>Evening:</strong> {day.evening}</p>
                  <p className="text-indigo-300"><strong>Food & Local Spot:</strong> {day.food}</p>
                </div>
              ))}
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t border-white/10">
              <button
                onClick={(e) => handleExportPDF(selectedTripModal, e)}
                className="px-5 py-2.5 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-indigo-600/30 cursor-pointer border border-indigo-400/30 transition"
              >
                <Download className="w-4 h-4" />
                <span>Export PDF</span>
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};

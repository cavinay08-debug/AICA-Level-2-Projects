import React, { useState } from 'react';
import { Sparkles, MapPin, Calendar, Heart, MessageSquare, Search, Menu, X, Sun, Moon, Compass, Wallet } from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  savedTripsCount: number;
  favoritesCount: number;
  onOpenSearch: () => void;
  onOpenChat: () => void;
  darkMode: boolean;
  setDarkMode: (val: boolean | ((prev: boolean) => boolean)) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  savedTripsCount,
  favoritesCount,
  onOpenSearch,
  onOpenChat,
  darkMode,
  setDarkMode
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'explore', label: 'Explore', icon: Compass },
    { id: 'ai-planner', label: 'AI Trip Planner', icon: Sparkles, badge: 'AI Powered' },
    { id: 'destinations', label: 'Destinations', icon: MapPin },
    { id: 'budget-calculator', label: 'Budget Planner', icon: Wallet },
    { id: 'saved-trips', label: 'Saved Trips', icon: Calendar, count: savedTripsCount }
  ];

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-xl bg-black/30 border-b border-white/10 text-white transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('explore')}>
            <div className="w-10 h-10 rounded-2xl bg-indigo-600 flex items-center justify-center shadow-lg shadow-indigo-500/20 border border-white/20">
              <Sparkles className="w-5 h-5 text-indigo-200 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-xl tracking-tight text-white">
                  TravelGPT <span className="text-indigo-400">AI</span>
                </span>
                <span className="px-2 py-0.5 text-[10px] font-bold uppercase tracking-widest rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 backdrop-blur-md">
                  AI
                </span>
              </div>
              <p className="text-[10px] font-medium text-white/50 -mt-0.5">
                Intelligent India Travel Planner
              </p>
            </div>
          </div>

          {/* Search Trigger Bar */}
          <button
            onClick={onOpenSearch}
            className="hidden md:flex items-center gap-3 px-4 py-2 text-sm text-white/60 bg-white/5 hover:bg-white/10 border border-white/10 rounded-full transition-all w-64 lg:w-80 backdrop-blur-md shadow-inner"
          >
            <Search className="w-4 h-4 text-white/40" />
            <span className="flex-1 text-left font-normal truncate placeholder-white/30">Search Jaipur, Manali, Kerala...</span>
            <kbd className="hidden sm:inline-block px-2 py-0.5 text-[10px] font-semibold text-white/60 bg-white/10 border border-white/15 rounded-md shadow-sm">
              ⌘K
            </kbd>
          </button>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center gap-1.5">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`relative flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all backdrop-blur-md ${
                    isActive
                      ? 'bg-white/15 text-white border border-white/25 shadow-lg shadow-indigo-500/10'
                      : 'text-white/60 hover:text-white hover:bg-white/10'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-indigo-400' : 'text-white/40'}`} />
                  <span>{item.label}</span>
                  {item.badge && (
                    <span className="px-1.5 py-0.2 text-[9px] font-bold rounded-full bg-indigo-600 text-white shadow-xs">
                      {item.badge}
                    </span>
                  )}
                  {typeof item.count === 'number' && item.count > 0 && (
                    <span className="px-1.5 py-0.2 text-[10px] font-bold rounded-full bg-indigo-500 text-white">
                      {item.count}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Action Buttons */}
          <div className="flex items-center gap-2">
            
            {/* Search mobile */}
            <button
              onClick={onOpenSearch}
              className="md:hidden p-2 rounded-xl text-white/70 hover:bg-white/10 transition"
              aria-label="Search"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* AI Assistant FAB in navbar */}
            <button
              onClick={onOpenChat}
              className="flex items-center gap-2 px-4 py-2 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition-all shadow-lg shadow-indigo-600/30 active:scale-95"
            >
              <MessageSquare className="w-4 h-4" />
              <span className="hidden sm:inline">AI Assistant</span>
            </button>

            {/* Mobile menu button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-xl text-white/70 hover:bg-white/10 transition"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-b border-white/10 bg-black/60 backdrop-blur-2xl px-4 pt-2 pb-4 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-sm font-semibold transition ${
                  isActive
                    ? 'bg-white/15 text-white border border-white/20'
                    : 'text-white/70 hover:bg-white/10'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-5 h-5 ${isActive ? 'text-indigo-400' : 'text-white/40'}`} />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-indigo-600 text-white">
                    {item.badge}
                  </span>
                )}
                {typeof item.count === 'number' && item.count > 0 && (
                  <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-indigo-500 text-white">
                    {item.count}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      )}
    </header>
  );
};

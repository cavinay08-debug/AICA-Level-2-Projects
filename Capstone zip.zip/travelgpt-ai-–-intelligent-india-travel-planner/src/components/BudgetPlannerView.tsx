import React, { useState } from 'react';
import { Wallet, DollarSign, Calculator, Users, Calendar, ArrowRight, Check } from 'lucide-react';
import { DESTINATIONS } from '../data/destinations';

export const BudgetPlannerView: React.FC = () => {
  const [selectedDest, setSelectedDest] = useState('Goa');
  const [days, setDays] = useState(4);
  const [travelers, setTravelers] = useState(2);
  const [tier, setTier] = useState<'Budget' | 'Standard' | 'Luxury'>('Standard');

  // Sliders per day per person
  const baseRates = {
    Budget: { stay: 800, food: 500, transport: 300, entry: 150, shopping: 200, misc: 100 },
    Standard: { stay: 2500, food: 1200, transport: 800, entry: 300, shopping: 500, misc: 250 },
    Luxury: { stay: 8000, food: 3500, transport: 2500, entry: 800, shopping: 2000, misc: 1000 }
  };

  const rate = baseRates[tier];

  const accommodationTotal = rate.stay * days * Math.ceil(travelers / 2); // Assume double occupancy
  const foodTotal = rate.food * days * travelers;
  const transportTotal = rate.transport * days * travelers;
  const entryTotal = rate.entry * days * travelers;
  const shoppingTotal = rate.shopping * travelers;
  const miscTotal = rate.misc * days * travelers;

  const grandTotal = accommodationTotal + foodTotal + transportTotal + entryTotal + shoppingTotal + miscTotal;
  const perPersonTotal = Math.round(grandTotal / travelers);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8 animate-fadeIn text-white">
      
      {/* Header Banner */}
      <div className="p-8 rounded-3xl bg-white/5 backdrop-blur-2xl text-white shadow-2xl relative overflow-hidden border border-white/10">
        <div className="relative z-10 max-w-3xl space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-indigo-500/20 text-indigo-300 font-bold text-xs uppercase tracking-wider border border-indigo-500/30 backdrop-blur-md">
            <Wallet className="w-3.5 h-3.5 text-indigo-300" />
            <span>Interactive Cost Calculator</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black tracking-tight text-white">
            India Travel Budget Planner
          </h1>
          <p className="text-sm text-white/70 font-normal leading-relaxed">
            Estimate your total travel expense breakdown for accommodation, food, local transport, entry tickets, shopping, and contingency across Budget, Standard, and Luxury tiers.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Input Settings Form */}
        <div className="lg:col-span-2 p-6 sm:p-8 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 shadow-xl space-y-6">
          <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
            <Calculator className="w-5 h-5 text-indigo-400" />
            <span>Configure Trip Parameters</span>
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            
            {/* Destination */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-white/80 uppercase tracking-wider">
                Destination
              </label>
              <select
                value={selectedDest}
                onChange={(e) => setSelectedDest(e.target.value)}
                className="w-full p-3.5 rounded-2xl bg-white/10 border border-white/15 text-white font-bold text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer"
              >
                {DESTINATIONS.map((d) => (
                  <option key={d.id} value={d.name} className="bg-slate-900 text-white">
                    {d.name} ({d.state})
                  </option>
                ))}
              </select>
            </div>

            {/* Travel Tier */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-white/80 uppercase tracking-wider">
                Budget Tier
              </label>
              <div className="grid grid-cols-3 gap-1.5">
                {(['Budget', 'Standard', 'Luxury'] as const).map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setTier(t)}
                    className={`py-3 rounded-xl font-bold text-xs transition cursor-pointer backdrop-blur-md ${
                      tier === t
                        ? 'bg-indigo-600 text-white border border-indigo-400 shadow-md shadow-indigo-600/30'
                        : 'bg-white/5 text-white/70 hover:bg-white/15 hover:text-white border border-white/10'
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            {/* Days Slider */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs font-bold text-white/80 uppercase tracking-wider">
                <span>Trip Duration</span>
                <span className="text-indigo-300 font-extrabold">{days} Days</span>
              </div>
              <input
                type="range"
                min={1}
                max={15}
                value={days}
                onChange={(e) => setDays(parseInt(e.target.value))}
                className="w-full accent-indigo-500 cursor-pointer"
              />
            </div>

            {/* Travelers Count */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs font-bold text-white/80 uppercase tracking-wider">
                <span>Travelers Count</span>
                <span className="text-indigo-300 font-extrabold">{travelers} Person(s)</span>
              </div>
              <input
                type="range"
                min={1}
                max={10}
                value={travelers}
                onChange={(e) => setTravelers(parseInt(e.target.value))}
                className="w-full accent-indigo-500 cursor-pointer"
              />
            </div>

          </div>

          {/* Breakdown Items List */}
          <div className="pt-6 border-t border-white/10 space-y-4">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              Itemized Cost Breakdown ({days} Days, {travelers} Traveler{travelers > 1 ? 's' : ''})
            </h3>

            <div className="space-y-3 text-xs">
              
              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 flex justify-between items-center backdrop-blur-md">
                <div>
                  <strong className="text-white block text-sm">Accommodation / Hotels</strong>
                  <span className="text-white/60">₹{rate.stay}/night (approx {Math.ceil(travelers / 2)} rooms)</span>
                </div>
                <strong className="text-sm font-black text-white">₹{accommodationTotal.toLocaleString('en-IN')}</strong>
              </div>

              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 flex justify-between items-center backdrop-blur-md">
                <div>
                  <strong className="text-white block text-sm">Food & Dining</strong>
                  <span className="text-white/60">₹{rate.food}/person/day</span>
                </div>
                <strong className="text-sm font-black text-white">₹{foodTotal.toLocaleString('en-IN')}</strong>
              </div>

              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 flex justify-between items-center backdrop-blur-md">
                <div>
                  <strong className="text-white block text-sm">Local Transport & Fuel</strong>
                  <span className="text-white/60">₹{rate.transport}/person/day</span>
                </div>
                <strong className="text-sm font-black text-white">₹{transportTotal.toLocaleString('en-IN')}</strong>
              </div>

              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 flex justify-between items-center backdrop-blur-md">
                <div>
                  <strong className="text-white block text-sm">Entry Tickets & Activities</strong>
                  <span className="text-white/60">₹{rate.entry}/person/day</span>
                </div>
                <strong className="text-sm font-black text-white">₹{entryTotal.toLocaleString('en-IN')}</strong>
              </div>

              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 flex justify-between items-center backdrop-blur-md">
                <div>
                  <strong className="text-white block text-sm">Shopping & Souvenirs</strong>
                  <span className="text-white/60">₹{rate.shopping}/person</span>
                </div>
                <strong className="text-sm font-black text-white">₹{shoppingTotal.toLocaleString('en-IN')}</strong>
              </div>

              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 flex justify-between items-center backdrop-blur-md">
                <div>
                  <strong className="text-white block text-sm">Miscellaneous & Contingency</strong>
                  <span className="text-white/60">₹{rate.misc}/person/day</span>
                </div>
                <strong className="text-sm font-black text-white">₹{miscTotal.toLocaleString('en-IN')}</strong>
              </div>

            </div>
          </div>

        </div>

        {/* Total Cost Display Summary Card */}
        <div className="space-y-6">
          <div className="p-8 rounded-3xl bg-white/10 backdrop-blur-2xl border border-white/20 text-white shadow-2xl space-y-6">
            <div>
              <span className="text-xs font-black uppercase tracking-wider text-indigo-300 block">Total Estimated Budget</span>
              <h2 className="text-4xl font-black tracking-tight mt-1 text-white">
                ₹{grandTotal.toLocaleString('en-IN')}
              </h2>
              <p className="text-xs font-bold mt-1 text-white/80">
                ₹{perPersonTotal.toLocaleString('en-IN')} per person
              </p>
            </div>

            <div className="space-y-3 pt-4 border-t border-white/10 text-xs font-bold">
              <div className="flex justify-between">
                <span className="text-white/60">Destination:</span>
                <span>{selectedDest}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/60">Duration:</span>
                <span>{days} Days</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/60">Travelers:</span>
                <span>{travelers} Person(s)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/60">Comfort Tier:</span>
                <span>{tier}</span>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 text-white text-xs space-y-2 backdrop-blur-md">
              <span className="font-bold text-indigo-300 block">💡 Budgeting Tip</span>
              <p className="text-white/70 leading-relaxed font-normal">
                {tier === 'Budget' ? 'Consider booking hostel dorms and using state transport buses to save up to 40%.' :
                 tier === 'Standard' ? 'Pre-book top attractions online to avoid long queues and extra ticket charges.' :
                 'Luxury stays often include complimentary airport transfers and private guided monument tours.'}
              </p>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};

/**
 * TravelGPT AI - Types & Interfaces
 */

export interface Coordinates {
  lat: number;
  lng: number;
}

export interface WeatherInfo {
  currentTemp: string;
  condition: string;
  humidity: string;
  rainProbability: string;
  bestSeason: string;
  monthlyOverview: { month: string; temp: string; status: 'Ideal' | 'Moderate' | 'Off-Season' | string }[];
}

export interface Destination {
  id: string;
  name: string;
  tagline: string;
  state: string;
  region: 'North' | 'South' | 'East' | 'West' | 'Central' | 'Northeast' | 'Islands';
  category: ('Spiritual' | 'Adventure' | 'Honeymoon' | 'Beaches' | 'Hill Stations' | 'Cultural' | 'Heritage' | 'Wildlife')[];
  rating: number;
  reviewsCount: number;
  image: string;
  heroImage: string;
  overview: string;
  history: string;
  bestTimeToVisit: string;
  weather: WeatherInfo;
  climate: string;
  languages: string[];
  culture: string;
  localCustoms: string[];
  currency: string;
  safetyTips: string[];
  travelTips: string[];
  openingClosingTimings: string;
  entryFees: string;
  coordinates: Coordinates;
  popularFor: string[];
  emergencyContacts: { service: string; number: string }[];
}

export type AttractionCategory =
  | 'Top Attractions'
  | 'Hidden Gems'
  | 'Nearby Places'
  | 'Adventure Activities'
  | 'Museums'
  | 'Temples'
  | 'Historical Places'
  | 'Beaches'
  | 'Waterfalls'
  | 'Wildlife'
  | 'Shopping Areas'
  | 'Nightlife'
  | 'Hill Stations'
  | string;

export interface Attraction {
  id: string;
  destinationId: string;
  name: string;
  category: AttractionCategory;
  image: string;
  description: string;
  duration: string;
  entryFee: string;
  timing: string;
  highlight: string;
  coordinates?: Coordinates;
}

export interface Hotel {
  id: string;
  destinationId: string;
  name: string;
  category: 'Budget' | 'Mid Range' | 'Luxury';
  pricePerNight: string;
  rating: number;
  image: string;
  location: string;
  amenities: string[];
  bookingHint: string;
}

export interface FoodItem {
  id: string;
  destinationId: string;
  name: string;
  category: 'Must Try Foods' | 'Best Restaurants' | 'Street Food' | 'Local Specialities';
  isVeg: boolean;
  description: string;
  priceRange: string;
  recommendedPlaces: string[];
  image: string;
}

export interface ShoppingItem {
  id: string;
  destinationId: string;
  name: string;
  famousMarkets: string[];
  famousProducts: string[];
  estimatedPrices: string;
  image: string;
  description: string;
}

export interface TransportOption {
  mode: 'Flight' | 'Train' | 'Bus' | 'Taxi' | 'Metro' | 'Local Transport';
  description: string;
  travelTime: string;
  approximateCost: string;
  frequency: string;
  tips: string;
}

export interface NearbyDestination {
  id: string;
  name: string;
  distance: string;
  travelTime: string;
  highlight: string;
  category: string;
  image: string;
}

export type YouTubeCategory =
  | 'Travel Guide'
  | 'Food Guide'
  | 'Things To Do'
  | 'Hidden Places'
  | '3 Day Itinerary'
  | 'Budget Travel'
  | 'Luxury Travel'
  | 'Adventure';

export interface YouTubeVideo {
  id: string;
  videoId: string;
  title: string;
  channel: string;
  category: YouTubeCategory;
  thumbnail: string;
  duration: string;
  views: string;
}

export interface BudgetBreakdown {
  accommodation: number;
  food: number;
  transport: number;
  entryTickets: number;
  shopping: number;
  miscellaneous: number;
  total: number;
}

export interface DayItinerary {
  day: number;
  title: string;
  theme: string;
  morning: string;
  afternoon: string;
  evening: string;
  food: string;
  travel: string;
  stay: string;
  approxBudget: BudgetBreakdown;
}

export interface TripPlan {
  id: string;
  title: string;
  destinationId: string;
  destinationName: string;
  numberOfDays: number;
  travelType: 'Solo' | 'Family' | 'Friends' | 'Honeymoon' | 'Pilgrimage' | 'Adventure' | 'Luxury' | 'Budget';
  budgetTier: 'Budget' | 'Standard' | 'Luxury';
  itinerary: DayItinerary[];
  totalBudget: BudgetBreakdown;
  packingChecklist: {
    category: string;
    items: { id: string; text: string; packed: boolean }[];
  }[];
  createdAt: string;
  notes?: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  groundingSources?: { title: string; uri: string }[];
}

export interface SearchRecord {
  id: string;
  query: string;
  timestamp: string;
}

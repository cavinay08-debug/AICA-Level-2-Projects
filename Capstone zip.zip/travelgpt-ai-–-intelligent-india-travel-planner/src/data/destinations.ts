import { Destination, Attraction, Hotel, FoodItem, ShoppingItem, TransportOption, NearbyDestination, YouTubeVideo } from '../types';

export const DESTINATIONS: Destination[] = [
  {
    id: 'goa',
    name: 'Goa',
    tagline: 'Sun, Sand, Seafood & Portuguese Heritage',
    state: 'Goa',
    region: 'West',
    category: ['Beaches', 'Honeymoon', 'Adventure', 'Cultural'],
    rating: 4.8,
    reviewsCount: 14200,
    image: 'https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?q=80&w=1200&auto=format&fit=crop',
    heroImage: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?q=80&w=1600&auto=format&fit=crop',
    overview: 'Goa is India’s coastal paradise, renowned for its golden sandy palm-fringed beaches, vibrant nightlife, Portuguese colonial architecture, UNESCO heritage churches, and delicious seafood curry.',
    history: 'Ruled by the Portuguese for over 450 years until 1961, Goa blends Latin culture with Indian traditions, visible in its mansions, Latin Quarter (Fontainhas), and baroque churches.',
    bestTimeToVisit: 'November to February (Pleasant weather, beach shacks, sunburn festivals)',
    weather: {
      currentTemp: '29°C',
      condition: 'Sunny & Coastal Breeze',
      humidity: '72%',
      rainProbability: '10%',
      bestSeason: 'Winter (Nov - Feb)',
      monthlyOverview: [
        { month: 'Jan - Feb', temp: '20°C - 30°C', status: 'Ideal' },
        { month: 'Mar - May', temp: '26°C - 35°C', status: 'Moderate' },
        { month: 'Jun - Sep', temp: '24°C - 30°C', status: 'Off-Season' },
        { month: 'Oct - Dec', temp: '22°C - 32°C', status: 'Ideal' }
      ]
    },
    climate: 'Tropical monsoon climate with hot summers, heavy monsoon rains, and pleasant cool winters.',
    languages: ['Konkani', 'English', 'Hindi', 'Marathi'],
    culture: 'Susegad lifestyle—a relaxed attitude toward life—coupled with rich music, carnival celebrations, and warm coastal hospitality.',
    localCustoms: ['Respect beach flags & lifeguard instructions', 'Dress modestly when visiting historic churches', 'Bargain politely at flea markets'],
    currency: 'INR (Indian Rupee - ₹)',
    safetyTips: ['Do not swim under red flag conditions', 'Always hire authorized taxi aggregators or rent scooters with helmet', 'Keep emergency contacts saved'],
    travelTips: ['Rent a two-wheeler for convenient beach hopping', 'Try local feni drinks and fresh fish thali', 'Visit South Goa for serene empty beaches and North Goa for nightlife'],
    openingClosingTimings: 'Beaches & Shacks: 7:00 AM - 1:00 AM | Forts & Heritage Sites: 9:00 AM - 5:30 PM',
    entryFees: 'Most beaches are free. Fort Aguada: ₹25 | Dudhsagar Waterfalls jeep: ₹500/person | Casino cruises: ₹2,000 - ₹5,000',
    coordinates: { lat: 15.2993, lng: 74.124 },
    popularFor: ['Baga Beach', 'Fontainhas Latin Quarter', 'Dudhsagar Waterfalls', 'Aguada Fort', 'Water Sports', 'Cruises'],
    emergencyContacts: [
      { service: 'Police', number: '112 / 100' },
      { service: 'Tourist Helpline', number: '1364' },
      { service: 'Ambulance', number: '108' }
    ]
  },
  {
    id: 'jaipur',
    name: 'Jaipur',
    tagline: 'The Royal Pink City of Forts & Palaces',
    state: 'Rajasthan',
    region: 'North',
    category: ['Heritage', 'Cultural', 'Honeymoon'],
    rating: 4.9,
    reviewsCount: 18900,
    image: 'https://images.unsplash.com/photo-1477587458883-47145ed94245?q=80&w=1200&auto=format&fit=crop',
    heroImage: 'https://images.unsplash.com/photo-1599661046289-e31897846e41?q=80&w=1600&auto=format&fit=crop',
    overview: 'Jaipur, the capital of Rajasthan, forms part of the Golden Triangle. Famous for its pink-painted buildings, grand hill forts, regal palaces, bustling bazaars, and rich Rajputana gastronomy.',
    history: 'Founded in 1727 by Maharaja Sawai Jai Singh II, Jaipur was designed according to Shilpa Shastra. In 1876, the city was painted pink to welcome the Prince of Wales.',
    bestTimeToVisit: 'October to March (Cool, crisp winter ideal for sightseeing and royal heritage tours)',
    weather: {
      currentTemp: '24°C',
      condition: 'Clear Blue Skies',
      humidity: '45%',
      rainProbability: '0%',
      bestSeason: 'Winter (Oct - Mar)',
      monthlyOverview: [
        { month: 'Jan - Feb', temp: '10°C - 24°C', status: 'Ideal' },
        { month: 'Mar - May', temp: '25°C - 42°C', status: 'Off-Season' },
        { month: 'Jun - Sep', temp: '26°C - 36°C', status: 'Moderate' },
        { month: 'Oct - Dec', temp: '15°C - 28°C', status: 'Ideal' }
      ]
    },
    climate: 'Semi-arid desert climate with hot summers and pleasantly cool winters.',
    languages: ['Rajasthani', 'Hindi', 'English'],
    culture: 'Vibrant folk dance (Ghoomar), puppet shows, block-printing textiles, and royal hospitality.',
    localCustoms: ['Remove footwear before entering temples', 'Remove hat/glasses when taking photos inside royal residences', 'Greet locals with "Khamma Ghani"'],
    currency: 'INR (Indian Rupee - ₹)',
    safetyTips: ['Beware of unauthorized guides offering "free" gem tours', 'Use prepaid auto-rickshaws or app cabs', 'Stay hydrated during noon walks'],
    travelTips: ['Buy the Jaipur Composite Entry Ticket for 8 major attractions', 'Visit Amer Fort early at 8:00 AM to avoid crowds', 'Taste Pyaz Kachori at Rawat Mishtan Bhandar'],
    openingClosingTimings: 'Forts & Museums: 9:00 AM - 5:00 PM | Night Tourism at Amer: 6:30 PM - 9:00 PM',
    entryFees: 'Amer Fort: ₹100 (Indian), ₹500 (Foreigner) | City Palace: ₹300 | Hawa Mahal: ₹50',
    coordinates: { lat: 26.9124, lng: 75.7873 },
    popularFor: ['Hawa Mahal', 'Amer Fort', 'City Palace', 'Jantar Mantar', 'Bapu Bazaar', 'Chokhi Dhani'],
    emergencyContacts: [
      { service: 'Police', number: '112' },
      { service: 'Tourist Police', number: '0141-2602330' },
      { service: 'Ambulance', number: '108' }
    ]
  },
  {
    id: 'manali',
    name: 'Manali',
    tagline: 'Snow Capped Peaks & Himalayan Adventure',
    state: 'Himachal Pradesh',
    region: 'North',
    category: ['Hill Stations', 'Adventure', 'Honeymoon'],
    rating: 4.7,
    reviewsCount: 16400,
    image: 'https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?q=80&w=1200&auto=format&fit=crop',
    heroImage: 'https://images.unsplash.com/photo-1581793745862-99fde7fa73d2?q=80&w=1600&auto=format&fit=crop',
    overview: 'Nestled on the banks of the Beas River, Manali is a premier Himalayan hill station offering snow sports, Solang Valley adventures, Rohtang Pass drives, pine forests, and chill cafe culture in Old Manali.',
    history: 'Named after the Hindu lawgiver Sage Manu. Legend holds that Sage Manu stepped off his ark here to recreate human life after the great deluge.',
    bestTimeToVisit: 'October to June (Snow sports in Dec-Feb, lush pine green valleys in April-June)',
    weather: {
      currentTemp: '12°C',
      condition: 'Crisp Alpine Breeze',
      humidity: '55%',
      rainProbability: '15%',
      bestSeason: 'Year Round (Dec-Feb for Snow)',
      monthlyOverview: [
        { month: 'Jan - Feb', temp: '-5°C - 8°C', status: 'Ideal' },
        { month: 'Mar - Jun', temp: '10°C - 25°C', status: 'Ideal' },
        { month: 'Jul - Sep', temp: '12°C - 22°C', status: 'Off-Season' },
        { month: 'Oct - Dec', temp: '2°C - 15°C', status: 'Ideal' }
      ]
    },
    climate: 'Sub-tropical highland climate with cold snowy winters and mild summers.',
    languages: ['Pahari', 'Hindi', 'English'],
    culture: 'Himachali traditions, wooden pagodas, local shawls, and vibrant wooden architecture.',
    localCustoms: ['Do not litter in eco-sensitive mountain zones', 'Dress in layers as temperatures drop sharply after sunset', 'Respect local temple rules at Hadimba Temple'],
    currency: 'INR (Indian Rupee - ₹)',
    safetyTips: ['Check Rohtang Pass permit status beforehand', 'Do not venture near river currents in monsoon', 'Carry motion sickness medication for winding roads'],
    travelTips: ['Rent snow suits & boots at certified shops near Solang', 'Explore Old Manali for live acoustic music and Israeli/Continental cafes', 'Drive through Atal Tunnel to Lahaul Valley'],
    openingClosingTimings: 'Hadimba Temple: 8:00 AM - 6:00 PM | Solang Valley: 9:00 AM - 6:00 PM',
    entryFees: 'Rohtang Pass NGT Permit: ₹550 per vehicle | Hadimba Temple: Free | Solang Ropeway: ₹700',
    coordinates: { lat: 32.2432, lng: 77.1892 },
    popularFor: ['Solang Valley', 'Atal Tunnel', 'Rohtang Pass', 'Hadimba Temple', 'Old Manali Cafes', 'River Rafting'],
    emergencyContacts: [
      { service: 'Police', number: '112' },
      { service: 'Mountain Rescue', number: '01902-252212' },
      { service: 'Ambulance', number: '108' }
    ]
  },
  {
    id: 'leh',
    name: 'Leh Ladakh',
    tagline: 'Land of High Passes & Cosmic Monasteries',
    state: 'Ladakh',
    region: 'North',
    category: ['Adventure', 'Spiritual', 'Heritage'],
    rating: 4.9,
    reviewsCount: 11200,
    image: 'https://images.unsplash.com/photo-1581793745862-99fde7fa73d2?q=80&w=1200&auto=format&fit=crop',
    heroImage: 'https://images.unsplash.com/photo-1548013146-72479768bada?q=80&w=1600&auto=format&fit=crop',
    overview: 'Leh Ladakh is a breathtaking cold high-altitude desert known for surreal turquoise lakes like Pangong Tso, Khardung La pass, double-humped camel rides in Nubra Valley, and cliffside Tibetan Buddhist monasteries.',
    history: 'Leh was an important stopover on trade routes along the Indus Valley between India, Tibet, China, and Kashmir. It features the 17th-century Leh Palace built by King Sengge Namgyal.',
    bestTimeToVisit: 'May to September (Roads open, pleasant weather, Hemis monastery festival)',
    weather: {
      currentTemp: '16°C',
      condition: 'Clear Intense Sun',
      humidity: '30%',
      rainProbability: '0%',
      bestSeason: 'Summer (May - Sep)',
      monthlyOverview: [
        { month: 'Jan - Mar', temp: '-15°C - 2°C', status: 'Off-Season' },
        { month: 'Apr - May', temp: '5°C - 15°C', status: 'Moderate' },
        { month: 'Jun - Aug', temp: '12°C - 25°C', status: 'Ideal' },
        { month: 'Sep - Dec', temp: '-5°C - 12°C', status: 'Moderate' }
      ]
    },
    climate: 'Cold desert climate with low oxygen, high UV intensity, and freezing winters.',
    languages: ['Ladakhi', 'Tibetan', 'Hindi', 'English'],
    culture: 'Sino-Tibetan Buddhist culture with prayer wheels, colourful prayer flags, thangka paintings, and monastic mask dances.',
    localCustoms: ['Walk clockwise around chortens and monasteries', 'Crucial 24-48 hours acclimatization upon landing in Leh', 'Obtain Inner Line Permits (ILP) for Pangong & Nubra'],
    currency: 'INR (Indian Rupee - ₹)',
    safetyTips: ['Do not skip acclimatization resting day', 'Carry Diamox (altitude sickness pill) and oxygen cylinder if needed', 'Carry extra cash as ATMs in remote valleys are scarce'],
    travelTips: ['Rent a RE Himalayan motorbike for iconic road trip', 'Drink plenty of water and butter tea (Gur Gur Chai)', 'Gaze at the Milky Way in Hanle Dark Sky Reserve'],
    openingClosingTimings: 'Monasteries: 6:00 AM - 6:00 PM | Leh Palace: 8:00 AM - 5:00 PM',
    entryFees: 'Ladakh Environment Fee / Inner Line Permit: ₹500 - ₹600 | Monastery entries: ₹30 - ₹50',
    coordinates: { lat: 34.1526, lng: 77.5771 },
    popularFor: ['Pangong Tso Lake', 'Nubra Valley', 'Khardung La Pass', 'Shanti Stupa', 'Thiksey Monastery', 'Magnetic Hill'],
    emergencyContacts: [
      { service: 'Police', number: '112' },
      { service: 'SNM Hospital Leh', number: '01982-252014' },
      { service: 'Army Helpline', number: '100' }
    ]
  },
  {
    id: 'udaipur',
    name: 'Udaipur',
    tagline: 'City of Lakes & Romantic Palaces',
    state: 'Rajasthan',
    region: 'North',
    category: ['Honeymoon', 'Heritage', 'Cultural'],
    rating: 4.9,
    reviewsCount: 15300,
    image: 'https://images.unsplash.com/photo-1615836245337-f5b9b2303f10?q=80&w=1200&auto=format&fit=crop',
    heroImage: 'https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?q=80&w=1600&auto=format&fit=crop',
    overview: 'Known as the Venice of the East, Udaipur is surrounded by the Aravalli Hills and tranquil blue lakes like Lake Pichola. Marvel at floating marble palaces, heritage havelis, and sunset boat cruises.',
    history: 'Founded in 1558 by Maharana Udai Singh II as the new capital of the Mewar Kingdom following the siege of Chittorgarh.',
    bestTimeToVisit: 'September to March (Pleasant breeze over lakes, cultural festivals)',
    weather: {
      currentTemp: '26°C',
      condition: 'Sunny Lake Breeze',
      humidity: '50%',
      rainProbability: '0%',
      bestSeason: 'Winter (Oct - Mar)',
      monthlyOverview: [
        { month: 'Jan - Feb', temp: '10°C - 25°C', status: 'Ideal' },
        { month: 'Mar - May', temp: '25°C - 40°C', status: 'Off-Season' },
        { month: 'Jun - Sep', temp: '22°C - 32°C', status: 'Moderate' },
        { month: 'Oct - Dec', temp: '14°C - 28°C', status: 'Ideal' }
      ]
    },
    climate: 'Tropical climate with hot dry summers and mild comfortable winters.',
    languages: ['Mewari', 'Hindi', 'English'],
    culture: 'Mewari royalty, miniature paintings, puppet performances at Bagore Ki Haveli, and royal weddings.',
    localCustoms: ['Dress respectfully in the old city temples', 'Enjoy lakeview rooftop dinners without loud noise late night'],
    currency: 'INR (Indian Rupee - ₹)',
    safetyTips: ['Ensure boat rides have valid life jackets', 'Agree on auto-rickshaw fares before embarking', 'Keep phone charged for sunset photography'],
    travelTips: ['Take a sunset boat ride from Rameshwar Ghat to Jagmandir Island', 'Watch Dharohar Folk Dance at Bagore Ki Haveli at 7 PM', 'Visit Monsoon Palace (Sajjangarh) for panoramic views'],
    openingClosingTimings: 'City Palace Museum: 9:00 AM - 5:30 PM | Lake Pichola Boats: 9:00 AM - 6:00 PM',
    entryFees: 'City Palace Museum: ₹300 | Sunset Boat Ride: ₹800 - ₹1,000 | Saheliyon Ki Bari: ₹20',
    coordinates: { lat: 24.5854, lng: 73.7125 },
    popularFor: ['City Palace', 'Lake Pichola', 'Jag Mandir', 'Taj Lake Palace', 'Saheliyon Ki Bari', 'Bagore Ki Haveli'],
    emergencyContacts: [
      { service: 'Police', number: '112' },
      { service: 'Tourist Helpline', number: '0294-2411535' },
      { service: 'Ambulance', number: '108' }
    ]
  },
  {
    id: 'kerala',
    name: 'Kerala',
    tagline: 'God’s Own Country – Backwaters, Tea Gardens & Ayurveda',
    state: 'Kerala',
    region: 'South',
    category: ['Honeymoon', 'Hill Stations', 'Cultural', 'Beaches'],
    rating: 4.9,
    reviewsCount: 22100,
    image: 'https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?q=80&w=1200&auto=format&fit=crop',
    heroImage: 'https://images.unsplash.com/photo-1593693397690-362cb9666fc2?q=80&w=1600&auto=format&fit=crop',
    overview: 'Kerala offers palm-lined backwaters in Alleppey, emerald tea plantations in Munnar, wildlife in Thekkady, pristine beaches in Varkala, Kathakali dance art, and traditional Panchakarma Ayurveda treatments.',
    history: 'A historic spice hub frequented by Phoenicians, Romans, Arabs, and Chinese since 3000 BCE. Vasco da Gama first landed in Calicut in 1498.',
    bestTimeToVisit: 'September to March (Backwaters cruising, pleasant cool Munnar hills)',
    weather: {
      currentTemp: '28°C',
      condition: 'Humid Coastal Sunshine',
      humidity: '78%',
      rainProbability: '20%',
      bestSeason: 'Winter (Sep - Mar)',
      monthlyOverview: [
        { month: 'Jan - Mar', temp: '22°C - 32°C', status: 'Ideal' },
        { month: 'Apr - May', temp: '25°C - 36°C', status: 'Moderate' },
        { month: 'Jun - Aug', temp: '22°C - 29°C', status: 'Off-Season' },
        { month: 'Sep - Dec', temp: '20°C - 30°C', status: 'Ideal' }
      ]
    },
    climate: 'Tropical wet climate with two monsoon seasons (Southwest & Northeast).',
    languages: ['Malayalam', 'English', 'Hindi'],
    culture: 'Kathakali classical dance, Kalaripayattu martial arts, Snake Boat races (Nehru Trophy), and Sadya feasts served on banana leaves.',
    localCustoms: ['Dhoti/Saree requirement for traditional temples like Guruvayur', 'Remove footwear outside homes and sacred places'],
    currency: 'INR (Indian Rupee - ₹)',
    safetyTips: ['Check weather advisories during monsoon boat rides', 'Book Ayurveda treatments only at certified Ayush centres'],
    travelTips: ['Rent an overnight luxury houseboat in Alleppey backwaters', 'Watch Kalaripayattu live show in Munnar/Thekkady', 'Drink fresh tender coconut water'],
    openingClosingTimings: 'Munnar Tea Gardens: 9:00 AM - 5:00 PM | Alleppey Houseboats check-in: 12:00 PM',
    entryFees: 'Eravikulam National Park: ₹200 | Alleppey Houseboat (1 Night): ₹8,000 - ₹20,000',
    coordinates: { lat: 9.4981, lng: 76.3388 },
    popularFor: ['Alleppey Backwaters', 'Munnar Tea Estate', 'Thekkady Periyar Lake', 'Varkala Cliff Beach', 'Kochi Fort'],
    emergencyContacts: [
      { service: 'Police', number: '112' },
      { service: 'Kerala Tourism', number: '1800-425-4747' },
      { service: 'Ambulance', number: '108' }
    ]
  },
  {
    id: 'ayodhya',
    name: 'Ayodhya',
    tagline: 'Sacred City of Shri Ram & Heritage Ghats',
    state: 'Uttar Pradesh',
    region: 'North',
    category: ['Spiritual', 'Heritage', 'Cultural'],
    rating: 4.9,
    reviewsCount: 24500,
    image: 'https://images.unsplash.com/photo-1627894483216-2138af692e32?q=80&w=1200&auto=format&fit=crop',
    heroImage: 'https://images.unsplash.com/photo-1627894483216-2138af692e32?q=80&w=1600&auto=format&fit=crop',
    overview: 'Ayodhya is the revered birthplace of Lord Rama on the banks of the sacred Saryu River. Home to the magnificent Shri Ram Janmabhoomi Mandir, Hanuman Garhi, and illuminated Saryu Aarti ghats.',
    history: 'One of the seven sacred cities (Sapta Puri) of Hinduism, celebrated in the ancient epic Ramayana as the capital of the Ikshvaku dynasty.',
    bestTimeToVisit: 'October to March (Deepotsav festival, pleasant winter pilgrimage weather)',
    weather: {
      currentTemp: '22°C',
      condition: 'Pleasant & Spiritual Breeze',
      humidity: '52%',
      rainProbability: '0%',
      bestSeason: 'Winter (Oct - Mar)',
      monthlyOverview: [
        { month: 'Jan - Feb', temp: '8°C - 22°C', status: 'Ideal' },
        { month: 'Mar - May', temp: '22°C - 40°C', status: 'Moderate' },
        { month: 'Jun - Sep', temp: '25°C - 35°C', status: 'Off-Season' },
        { month: 'Oct - Dec', temp: '12°C - 26°C', status: 'Ideal' }
      ]
    },
    climate: 'Humid subtropical climate with chilly winters and hot dry summer months.',
    languages: ['Awadhi', 'Hindi', 'Sanskrit'],
    culture: 'Deep spiritual reverence, Ram Leela performances, lighting millions of diyas during Diwali (Deepotsav record).',
    localCustoms: ['Dress conservatively in traditional attire', 'Electronic devices/bags prohibited inside Ram Mandir inner sanctum', 'Attend Saryu Aarti at sunset'],
    currency: 'INR (Indian Rupee - ₹)',
    safetyTips: ['Use designated locker facilities at temple entrances', 'Beware of playful monkeys around Hanuman Garhi temple'],
    travelTips: ['Book Sugam Darshan e-pass online for hassle-free Ram Mandir visit', 'Taste authentic Ram Ghat Peda and local sweets', 'Take electric auto for eco-friendly city transit'],
    openingClosingTimings: 'Shri Ram Mandir Darshan: 6:30 AM - 12:00 PM & 2:00 PM - 10:00 PM | Saryu Aarti: 6:30 PM',
    entryFees: 'Ram Mandir Darshan: Free (E-Pass available) | Saryu River Boat Ride: ₹100 - ₹200',
    coordinates: { lat: 26.7922, lng: 82.1998 },
    popularFor: ['Shri Ram Janmabhoomi Mandir', 'Hanuman Garhi', 'Kanak Bhawan', 'Saryu Ghat Aarti', 'Ram ki Paidi'],
    emergencyContacts: [
      { service: 'Police', number: '112' },
      { service: 'Temple Control Room', number: '05278-297001' },
      { service: 'Ambulance', number: '108' }
    ]
  },
  {
    id: 'varanasi',
    name: 'Varanasi',
    tagline: 'World’s Oldest Living City & Spiritual Ghats',
    state: 'Uttar Pradesh',
    region: 'North',
    category: ['Spiritual', 'Cultural', 'Heritage'],
    rating: 4.8,
    reviewsCount: 19800,
    image: 'https://images.unsplash.com/photo-1561361513-2d000a50f0dc?q=80&w=1200&auto=format&fit=crop',
    heroImage: 'https://images.unsplash.com/photo-1571536802807-30451e3955d8?q=80&w=1600&auto=format&fit=crop',
    overview: 'Varanasi (Kashi) is one of the world’s oldest continuously inhabited cities. Famous for the cosmic Ganga Aarti at Dashashwamedh Ghat, Kashi Vishwanath Corridor, sunrise boat rides, and silk sarees.',
    history: 'Dating back over 3,000 years, Varanasi is the spiritual capital of India where Lord Shiva resides according to Hindu cosmology.',
    bestTimeToVisit: 'October to March (Dev Deepawali, cool winter morning boat rides)',
    weather: {
      currentTemp: '23°C',
      condition: 'Foggy Morning Mist',
      humidity: '60%',
      rainProbability: '0%',
      bestSeason: 'Winter (Oct - Mar)',
      monthlyOverview: [
        { month: 'Jan - Feb', temp: '9°C - 23°C', status: 'Ideal' },
        { month: 'Mar - May', temp: '22°C - 42°C', status: 'Off-Season' },
        { month: 'Jun - Sep', temp: '26°C - 35°C', status: 'Moderate' },
        { month: 'Oct - Dec', temp: '14°C - 28°C', status: 'Ideal' }
      ]
    },
    climate: 'Humid subtropical climate with dramatic temperature variations.',
    languages: ['Bhojpuri', 'Hindi', 'Sanskrit', 'English'],
    culture: 'Classical Hindustani music (Benares Gharana), Banarasi silk weaving, classical philosophy, and sacred cremation rituals at Manikarnika Ghat.',
    localCustoms: ['No photography allowed at Manikarnika Ghat out of respect for grieving families', 'Walk silently in narrow galis'],
    currency: 'INR (Indian Rupee - ₹)',
    safetyTips: ['Negotiate boat ride price before boarding', 'Keep wallets safe in crowded market alleys'],
    travelTips: ['Hire a wooden boat at Subah-e-Banaras (5:30 AM sunrise at Assi Ghat)', 'Eat Malaiyyo winter sweet milk froth in Kachori Gali', 'Visit Sarnath where Buddha gave his first sermon'],
    openingClosingTimings: 'Kashi Vishwanath Temple: 3:00 AM - 11:00 PM | Ganga Aarti: 6:30 PM every evening',
    entryFees: 'Vishwanath Temple: Free (Sugam Darshan ₹300) | Sunrise Ganga Boat Ride: ₹300 - ₹800',
    coordinates: { lat: 25.3176, lng: 82.9739 },
    popularFor: ['Ganga Aarti at Dashashwamedh Ghat', 'Kashi Vishwanath Corridor', 'Assi Ghat', 'Sarnath', 'Banarasi Sarees'],
    emergencyContacts: [
      { service: 'Police', number: '112' },
      { service: 'Tourist Police', number: '9454404382' },
      { service: 'Ambulance', number: '108' }
    ]
  },
  {
    id: 'rishikesh',
    name: 'Rishikesh',
    tagline: 'Yoga Capital of the World & Ganges Rafting',
    state: 'Uttarakhand',
    region: 'North',
    category: ['Spiritual', 'Adventure', 'Hill Stations'],
    rating: 4.8,
    reviewsCount: 14700,
    image: 'https://images.unsplash.com/photo-1598970434795-0c54fe7c0648?q=80&w=1200&auto=format&fit=crop',
    heroImage: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?q=80&w=1600&auto=format&fit=crop',
    overview: 'Rishikesh, located in the Himalayan foothills along the crystal emerald Ganges, is the Yoga Capital of the World. Renowned for white-water rafting, bungee jumping, Laxman Jhula, Beatles Ashram, and evening Triveni Aarti.',
    history: 'Revered since ancient times as the gateway to the Char Dham pilgrimage. Gained international fame in 1968 when The Beatles stayed at Maharishi Mahesh Yogi’s ashram.',
    bestTimeToVisit: 'September to November & February to May (Best for River Rafting & Yoga retreats)',
    weather: {
      currentTemp: '20°C',
      condition: 'Fresh River Mountain Air',
      humidity: '48%',
      rainProbability: '5%',
      bestSeason: 'Autumn & Spring',
      monthlyOverview: [
        { month: 'Jan - Feb', temp: '6°C - 20°C', status: 'Moderate' },
        { month: 'Mar - May', temp: '18°C - 35°C', status: 'Ideal' },
        { month: 'Jun - Aug', temp: '22°C - 32°C', status: 'Off-Season (Rafting Closed)' },
        { month: 'Sep - Dec', temp: '10°C - 26°C', status: 'Ideal' }
      ]
    },
    climate: 'Humid subtropical climate with cool mountain breezes.',
    languages: ['Garhwali', 'Hindi', 'English'],
    culture: 'Pure vegetarian diet (alcohol strictly banned), ashram meditation, yoga certification, and bohemian cafe lifestyle.',
    localCustoms: ['Rishikesh is a dry and strictly vegetarian holy town', 'Wear lifejackets during river sports'],
    currency: 'INR (Indian Rupee - ₹)',
    safetyTips: ['Do not swim in deep Ganga river currents', 'Choose certified rafting operators with qualified guides'],
    travelTips: ['Book 16 km Rafting from Shivpuri to Laxman Jhula', 'Visit Beatles Ashram for street art and tranquil vibes', 'Try Ayurvedic herbal teas at Little Buddha Cafe'],
    openingClosingTimings: 'Beatles Ashram: 9:00 AM - 4:00 PM | Triveni Ghat Ganga Aarti: 6:00 PM',
    entryFees: 'Beatles Ashram: ₹150 | White Water Rafting 16 km: ₹1,000 - ₹1,500 | Bungee Jump: ₹3,800',
    coordinates: { lat: 30.0869, lng: 78.2676 },
    popularFor: ['White Water Rafting', 'Laxman Jhula & Ram Jhula', 'Beatles Ashram', 'Triveni Ghat Aarti', 'Bungee Jumping'],
    emergencyContacts: [
      { service: 'Police', number: '112' },
      { service: 'Rafting Association', number: '0135-2430209' },
      { service: 'Ambulance', number: '108' }
    ]
  },
  {
    id: 'mahabaleshwar',
    name: 'Mahabaleshwar',
    tagline: 'Strawberry Valleys & Western Ghats Viewpoints',
    state: 'Maharashtra',
    region: 'West',
    category: ['Hill Stations', 'Honeymoon', 'Adventure'],
    rating: 4.6,
    reviewsCount: 9800,
    image: 'https://images.unsplash.com/photo-1582510003544-4d00b7f74220?q=80&w=1200&auto=format&fit=crop',
    heroImage: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=1600&auto=format&fit=crop',
    overview: 'Mahabaleshwar is a green hill station in the Sahyadri range of Maharashtra, famous for strawberry farms, Venna Lake boating, Arthur Seat viewpoint, Pratapgad Fort, and fresh berry cream desserts.',
    history: 'Served as the summer capital of the Bombay Presidency during British colonial rule. Origin of the sacred Krishna River.',
    bestTimeToVisit: 'October to June (Strawberry harvest in Dec-Mar, lush waterfall scenery)',
    weather: {
      currentTemp: '21°C',
      condition: 'Cool Foggy Mist',
      humidity: '65%',
      rainProbability: '10%',
      bestSeason: 'Winter & Spring',
      monthlyOverview: [
        { month: 'Jan - Mar', temp: '12°C - 28°C', status: 'Ideal' },
        { month: 'Apr - May', temp: '18°C - 32°C', status: 'Ideal' },
        { month: 'Jun - Sep', temp: '16°C - 22°C', status: 'Off-Season (Heavy Rains)' },
        { month: 'Oct - Dec', temp: '10°C - 25°C', status: 'Ideal' }
      ]
    },
    climate: 'Subtropical highland climate with dense mist and torrent monsoon rains.',
    languages: ['Marathi', 'Hindi', 'English'],
    culture: 'Parsi bakeries, Mapro garden tours, strawberry picking, and equestrian rides around Venna Lake.',
    localCustoms: ['Support local strawberry farmers', 'Keep monkeys at bay near Wilson Point'],
    currency: 'INR (Indian Rupee - ₹)',
    safetyTips: ['Drive cautiously on foggy ghat bends', 'Avoid steep edges at Arthur’s Seat'],
    travelTips: ['Visit Mapro Garden for unlimited strawberry cream and wood-fired pizza', 'Boat on Venna Lake during late afternoon', 'Trek to Pratapgad Fort'],
    openingClosingTimings: 'Venna Lake Boating: 9:00 AM - 7:00 PM | Mapro Garden: 8:00 AM - 10:00 PM',
    entryFees: 'Venna Lake Boat: ₹300 - ₹600 | Mapro Garden: Free Entry | Pratapgad Fort: Free',
    coordinates: { lat: 17.9252, lng: 73.6582 },
    popularFor: ['Mapro Garden', 'Venna Lake', 'Arthur Seat', 'Pratapgad Fort', 'Strawberry Farms', 'Lingmala Waterfall'],
    emergencyContacts: [
      { service: 'Police', number: '112' },
      { service: 'Municipal Helpline', number: '02168-260228' },
      { service: 'Ambulance', number: '108' }
    ]
  },
  {
    id: 'coorg',
    name: 'Coorg (Madikeri)',
    tagline: 'Scotland of India – Coffee Plantations & Misty Hills',
    state: 'Karnataka',
    region: 'South',
    category: ['Hill Stations', 'Honeymoon', 'Wildlife', 'Adventure'],
    rating: 4.7,
    reviewsCount: 12400,
    image: 'https://images.unsplash.com/photo-1588097281266-310cead47879?q=80&w=1200&auto=format&fit=crop',
    heroImage: 'https://images.unsplash.com/photo-1588097281266-310cead47879?q=80&w=1600&auto=format&fit=crop',
    overview: 'Coorg (Kodagu) is Karnataka’s famous coffee hill station. Featuring endless coffee & spice estates, Abbey Falls, Dubare Elephant Camp, Namdroling Tibetan Monastery (Golden Temple), and spicy Pandi Curry.',
    history: 'Inhabited by the brave Kodava warrior martial community who have distinct cultural attire and customs separate from mainstream Karnataka.',
    bestTimeToVisit: 'October to June (Aromatic white coffee blossom flowers in March-April)',
    weather: {
      currentTemp: '22°C',
      condition: 'Misty Coffee Aroma Breeze',
      humidity: '70%',
      rainProbability: '10%',
      bestSeason: 'Oct - May',
      monthlyOverview: [
        { month: 'Jan - Mar', temp: '14°C - 28°C', status: 'Ideal' },
        { month: 'Apr - May', temp: '18°C - 33°C', status: 'Ideal' },
        { month: 'Jun - Sep', temp: '18°C - 24°C', status: 'Off-Season (Monsoon)' },
        { month: 'Oct - Dec', temp: '12°C - 26°C', status: 'Ideal' }
      ]
    },
    climate: 'Tropical highland climate with high rainfall during South-West monsoons.',
    languages: ['Kodava', 'Kannada', 'English', 'Hindi'],
    culture: 'Kodava martial heritage, weapon worship (Kailpodh festival), and traditional coffee estate homestays.',
    localCustoms: ['Respect Kodava cultural homestays', 'Do not feed wild elephants at Dubare Camp'],
    currency: 'INR (Indian Rupee - ₹)',
    safetyTips: ['Do not stray into dark coffee estates without guide', 'Be careful around slippery moss on Abbey Falls rocks'],
    travelTips: ['Stay in an authentic coffee plantation estate homestay', 'Buy pure dark chocolate, fresh pepper, and Arabica coffee beans', 'Bathe elephants at Dubare Camp early morning at 9:00 AM'],
    openingClosingTimings: 'Namdroling Golden Temple: 9:00 AM - 6:00 PM | Abbey Falls: 9:00 AM - 5:00 PM',
    entryFees: 'Abbey Falls: ₹15 | Dubare Elephant Camp entry: ₹100 | Coffee Estate Tour: ₹300 - ₹500',
    coordinates: { lat: 12.4244, lng: 75.7382 },
    popularFor: ['Abbey Falls', 'Namdroling Golden Temple Bylakuppe', 'Dubare Elephant Camp', 'Raja Seat', 'Coffee Plantation Trails'],
    emergencyContacts: [
      { service: 'Police', number: '112' },
      { service: 'Madikeri Hospital', number: '08272-225333' },
      { service: 'Ambulance', number: '108' }
    ]
  },
  {
    id: 'darjeeling',
    name: 'Darjeeling',
    tagline: 'Queen of the Hills – Kanchenjunga Views & Toy Train',
    state: 'West Bengal',
    region: 'East',
    category: ['Hill Stations', 'Honeymoon', 'Heritage', 'Adventure'],
    rating: 4.7,
    reviewsCount: 13100,
    image: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?q=80&w=1200&auto=format&fit=crop',
    heroImage: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?q=80&w=1600&auto=format&fit=crop',
    overview: 'Darjeeling is world-famous for its aromatic tea, UNESCO Himalayan Toy Train, Tiger Hill golden sunrise views over Mount Kanchenjunga (world’s 3rd highest peak), and Ghoom Monastery.',
    history: 'Developed as a sanatorium by the British East India Company in the 1840s, famous for Dr. Campbell introducing tea bushes from China.',
    bestTimeToVisit: 'March to May & October to December (Crystal clear skies for mountain views)',
    weather: {
      currentTemp: '14°C',
      condition: 'Crisp Sunshine & Tea Scent',
      humidity: '58%',
      rainProbability: '10%',
      bestSeason: 'Spring & Autumn',
      monthlyOverview: [
        { month: 'Jan - Feb', temp: '2°C - 11°C', status: 'Moderate' },
        { month: 'Mar - May', temp: '10°C - 19°C', status: 'Ideal' },
        { month: 'Jun - Sep', temp: '13°C - 20°C', status: 'Off-Season (Monsoon Fog)' },
        { month: 'Oct - Dec', temp: '5°C - 15°C', status: 'Ideal' }
      ]
    },
    climate: 'Subtropical highland climate with freezing winter months and misty wet monsoons.',
    languages: ['Nepali', 'Bengali', 'English', 'Hindi'],
    culture: 'Gorkha traditions, Tibetan momos & thukpa, colonial bakeries (Keventer’s & Glenary’s).',
    localCustoms: ['Wake up at 3:30 AM for Tiger Hill sunrise', 'Try First Flush Darjeeling Tea brewed in porcelain pots'],
    currency: 'INR (Indian Rupee - ₹)',
    safetyTips: ['Wear thermal jackets for Tiger Hill at dawn', 'Book Toy Train ticket weeks in advance on IRCTC'],
    travelTips: ['Have breakfast on the open balcony of Keventer’s', 'Ride the Darjeeling Ropeway over rolling green tea gardens', 'Visit Himalayan Mountaineering Institute & Zoo to see Red Pandas'],
    openingClosingTimings: 'Tiger Hill: 4:00 AM - 6:00 AM | Happy Valley Tea Estate: 8:00 AM - 4:00 PM',
    entryFees: 'Himalayan Zoo & HMI: ₹110 | Toy Train Joyride (Steam): ₹1,500 | Ropeway: ₹260',
    coordinates: { lat: 27.041, lng: 88.2663 },
    popularFor: ['Tiger Hill Sunrise', 'UNESCO Toy Train', 'Batasia Loop', 'Happy Valley Tea Estate', 'Glenary Bakery & Cafe'],
    emergencyContacts: [
      { service: 'Police', number: '112' },
      { service: 'District Hospital', number: '0354-2252131' },
      { service: 'Ambulance', number: '108' }
    ]
  },
  {
    id: 'andaman',
    name: 'Andaman & Nicobar Islands',
    tagline: 'Emerald Waters, Radhanagar Beach & Coral Reef Scuba',
    state: 'Andaman & Nicobar Islands',
    region: 'Islands',
    category: ['Beaches', 'Honeymoon', 'Adventure', 'Heritage'],
    rating: 4.9,
    reviewsCount: 11500,
    image: 'https://images.unsplash.com/photo-1589394815804-964ed0be2eb5?q=80&w=1200&auto=format&fit=crop',
    heroImage: 'https://images.unsplash.com/photo-1589394815804-964ed0be2eb5?q=80&w=1600&auto=format&fit=crop',
    overview: 'An island paradise in the Bay of Bengal. Home to Radhanagar Beach (Asia’s best beach on Havelock Island), underwater scuba diving at Elephant Beach, bioluminescent night kayaking, and historic Cellular Jail in Port Blair.',
    history: 'Cellular Jail (Kala Pani) was used by British colonialists to exile Indian freedom fighters like Veer Savarkar.',
    bestTimeToVisit: 'October to May (Calm turquoise seas, ideal for scuba diving & snorkeling)',
    weather: {
      currentTemp: '30°C',
      condition: 'Tropical Island Sunshine',
      humidity: '75%',
      rainProbability: '5%',
      bestSeason: 'Oct - May',
      monthlyOverview: [
        { month: 'Jan - Mar', temp: '23°C - 30°C', status: 'Ideal' },
        { month: 'Apr - May', temp: '25°C - 32°C', status: 'Ideal' },
        { month: 'Jun - Sep', temp: '24°C - 29°C', status: 'Off-Season (High Waves)' },
        { month: 'Oct - Dec', temp: '22°C - 30°C', status: 'Ideal' }
      ]
    },
    climate: 'Tropical ocean climate with warm sunshine and gentle sea breezes.',
    languages: ['Bengali', 'Hindi', 'Tamil', 'English'],
    culture: 'Indigenous tribal heritage (Jarawa/Sentinelese protection zones) mixed with Bengali and South Indian island settlement traditions.',
    localCustoms: ['Strictly forbidden to take photos or contact Jarawa indigenous tribes', 'Do not touch or destroy marine coral reefs'],
    currency: 'INR (Indian Rupee - ₹)',
    safetyTips: ['Scuba dive only with PADI certified dive centers', 'Book inter-island ferries (Makruzz/Green Ocean) in advance'],
    travelTips: ['Watch sunset at Radhanagar Beach Beach No. 7', 'Try Sea Walking or Scuba at Elephant Beach', 'Watch Light & Sound show at Cellular Jail'],
    openingClosingTimings: 'Cellular Jail: 9:00 AM - 5:00 PM | Light & Sound Show: 6:00 PM & 7:15 PM',
    entryFees: 'Cellular Jail Entry: ₹30 | Light & Sound Show: ₹150 | Scuba Diving: ₹3,500 - ₹5,000',
    coordinates: { lat: 11.6234, lng: 92.7265 },
    popularFor: ['Radhanagar Beach Havelock', 'Cellular Jail Port Blair', 'Elephant Beach Scuba', 'Neil Island Natural Bridge', 'Baratang Limestone Caves'],
    emergencyContacts: [
      { service: 'Police', number: '112 / 100' },
      { service: 'Tourist Information', number: '03192-232694' },
      { service: 'Ambulance', number: '102 / 108' }
    ]
  },
  {
    id: 'kedarnath',
    name: 'Kedarnath',
    tagline: 'Sacred Jyotirlinga Shrine in Garhwal Himalayas',
    state: 'Uttarakhand',
    region: 'North',
    category: ['Spiritual', 'Adventure', 'Heritage'],
    rating: 4.95,
    reviewsCount: 28900,
    image: 'https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?q=80&w=1200&auto=format&fit=crop',
    heroImage: 'https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?q=80&w=1600&auto=format&fit=crop',
    overview: 'Kedarnath is one of the highest and most sacred 12 Jyotirlinga shrines of Lord Shiva, located at 3,583 meters altitude near the Mandakini River. Demands a 16 km mountain trek from Gaurikund surrounded by snow peaks.',
    history: 'Believed to have been initially built by the Pandavas and revived by Adi Shankaracharya in the 8th century CE.',
    bestTimeToVisit: 'May to June & September to October (Temple opens May on Akshaya Tritiya & closes Diwali)',
    weather: {
      currentTemp: '8°C',
      condition: 'Freezing Mountain Air',
      humidity: '40%',
      rainProbability: '10%',
      bestSeason: 'May-Jun & Sep-Oct',
      monthlyOverview: [
        { month: 'Jan - Apr', temp: '-10°C - 0°C', status: 'Off-Season (Temple Closed)' },
        { month: 'May - Jun', temp: '5°C - 18°C', status: 'Ideal' },
        { month: 'Jul - Aug', temp: '8°C - 15°C', status: 'Off-Season (Landslides)' },
        { month: 'Sep - Nov', temp: '-2°C - 12°C', status: 'Ideal' }
      ]
    },
    climate: 'Alpine climate with extremely cold temperatures and sudden mountain weather shifts.',
    languages: ['Garhwali', 'Hindi', 'Sanskrit'],
    culture: 'Deep Himalayan Shiva devotion, sound of Har Har Mahadev reverberating across snowy peaks, and sacred Vedic chants.',
    localCustoms: ['Register on Uttarakhand Char Dham Yatra portal mandatory', 'Maintain holiness & cleanliness on trek path'],
    currency: 'INR (Indian Rupee - ₹)',
    safetyTips: ['Obtain medical fitness certificate before 16 km trek', 'Carry heavy woolen thermals, rain ponchos, and comfortable trekking shoes', 'Book IRCTC Helicopter service only on official site'],
    travelTips: ['Start 16 km Gaurikund trek at 4:00 AM', 'Hire pony/palki or book helicopter if unable to trek', 'Attend early morning 5:00 AM Shiva Abhishekam'],
    openingClosingTimings: 'Temple Darshan: 5:00 AM - 1:30 PM & 5:00 PM - 8:30 PM (Closed Nov to April due to heavy snow)',
    entryFees: 'Temple Entry: Free | Helicopter round trip (Phata/Sersi): ₹5,500 - ₹8,000 | Pony ride: ₹2,500',
    coordinates: { lat: 30.7352, lng: 79.0669 },
    popularFor: ['Kedarnath Temple', 'Bhairavnath Temple', 'Gandhi Sarovar', 'Gaurikund Trek', 'Vasuki Tal'],
    emergencyContacts: [
      { service: 'Police', number: '112' },
      { service: 'Char Dham Control Room', number: '1364' },
      { service: 'Disaster Helpline', number: '1070' }
    ]
  },
  {
    id: 'somnath',
    name: 'Somnath',
    tagline: 'First Among Twelve Sacred Jyotirlinga Shrines',
    state: 'Gujarat',
    region: 'West',
    category: ['Spiritual', 'Heritage', 'Beaches'],
    rating: 4.8,
    reviewsCount: 10800,
    image: 'https://images.unsplash.com/photo-1609831108347-c60312896703?q=80&w=1200&auto=format&fit=crop',
    heroImage: 'https://images.unsplash.com/photo-1609831108347-c60312896703?q=80&w=1600&auto=format&fit=crop',
    overview: 'Located on the Arabian Sea coast, Somnath is the "Shrine Eternal", revered as the first of the 12 Jyotirlinga shrines. Features imposing Chalukya architectural grandeur, sound & light laser show, and sea waves.',
    history: 'Rebuilt seven times throughout history, standing as an indestructible symbol of faith. Re-constructed in 1951 led by Sardar Vallabhbhai Patel.',
    bestTimeToVisit: 'October to March (Maha Shivratri festival, pleasant coastal weather)',
    weather: {
      currentTemp: '27°C',
      condition: 'Sunny Sea Breeze',
      humidity: '65%',
      rainProbability: '0%',
      bestSeason: 'Winter (Oct - Mar)',
      monthlyOverview: [
        { month: 'Jan - Feb', temp: '15°C - 28°C', status: 'Ideal' },
        { month: 'Mar - May', temp: '24°C - 36°C', status: 'Moderate' },
        { month: 'Jun - Sep', temp: '25°C - 32°C', status: 'Moderate' },
        { month: 'Oct - Dec', temp: '18°C - 30°C', status: 'Ideal' }
      ]
    },
    climate: 'Tropical coastal climate with pleasant sea winds in winter.',
    languages: ['Gujarati', 'Hindi', 'English'],
    culture: 'Devotion to Lord Shiva, Gujarati thali culinary heritage, Baan Stambh arrow pillar history.',
    localCustoms: ['Electronic items & mobile phones prohibited inside main temple premises (deposit at free counters)'],
    currency: 'INR (Indian Rupee - ₹)',
    safetyTips: ['Be careful near high tide waves at Somnath beach', 'Utilize Somnath Trust VIP/E-Darshan passes'],
    travelTips: ['Watch 8:00 PM "Jay Somnath" Sound & Light laser show on the temple walls by the ocean', 'Visit Triveni Sangam (confluence of Hiran, Kapila & Saraswati rivers)'],
    openingClosingTimings: 'Temple Darshan: 6:00 AM - 10:00 PM | Aarti timings: 7:00 AM, 12:00 PM, 7:00 PM | Light Show: 8:00 PM',
    entryFees: 'Somnath Temple Entry: Free | Sound & Light Show: ₹30',
    coordinates: { lat: 20.888, lng: 70.4012 },
    popularFor: ['Somnath Temple', 'Triveni Sangam', 'Bhalka Tirth', 'Somnath Beach Promenade', 'Light and Sound Show'],
    emergencyContacts: [
      { service: 'Police', number: '112' },
      { service: 'Somnath Trust Office', number: '02876-231212' },
      { service: 'Ambulance', number: '108' }
    ]
  },
  {
    id: 'dwarka',
    name: 'Dwarka',
    tagline: 'Kingdom of Lord Krishna & Char Dham Pilgrimage',
    state: 'Gujarat',
    region: 'West',
    category: ['Spiritual', 'Heritage', 'Beaches'],
    rating: 4.85,
    reviewsCount: 12100,
    image: 'https://images.unsplash.com/photo-1609831108347-c60312896703?q=80&w=1200&auto=format&fit=crop',
    heroImage: 'https://images.unsplash.com/photo-1609831108347-c60312896703?q=80&w=1600&auto=format&fit=crop',
    overview: 'Dwarka is one of the four sacred Char Dham pilgrimage sites of India and the ancient kingdom of Lord Krishna. Highlights include the 5-story Dwarkadhish Temple (Jagat Mandir), Sudama Setu cable bridge, and Bet Dwarka island.',
    history: 'Submerged ancient legendary city described in Mahabharata. Archaeological excavations off Dwarka coast have revealed submerged structures dating back thousands of years.',
    bestTimeToVisit: 'October to March (Janmashtami celebrations in August-September are legendary)',
    weather: {
      currentTemp: '26°C',
      condition: 'Clear Coastal Breeze',
      humidity: '62%',
      rainProbability: '0%',
      bestSeason: 'Winter (Oct - Mar)',
      monthlyOverview: [
        { month: 'Jan - Feb', temp: '14°C - 27°C', status: 'Ideal' },
        { month: 'Mar - May', temp: '22°C - 35°C', status: 'Moderate' },
        { month: 'Jun - Sep', temp: '25°C - 31°C', status: 'Moderate' },
        { month: 'Oct - Dec', temp: '16°C - 29°C', status: 'Ideal' }
      ]
    },
    climate: 'Arid coastal climate moderated by the Arabian Sea.',
    languages: ['Gujarati', 'Hindi', 'English'],
    culture: 'Krishna Bhakti culture, flag changing ceremony (Dhwajajorohan) 5 times a day atop 52-yard temple spire.',
    localCustoms: ['No mobile phones or electronic gadgets inside Jagat Mandir', 'Observe traditional attire'],
    currency: 'INR (Indian Rupee - ₹)',
    safetyTips: ['Check ferry timings to Bet Dwarka during high tide', 'Carry hat and sunglasses for island excursions'],
    travelTips: ['Cross Sudama Setu suspension bridge over Gomti River', 'Take boat to Bet Dwarka island to visit Lord Krishna’s original residence', 'Watch dolphins near Okha coast'],
    openingClosingTimings: 'Dwarkadhish Temple: 6:30 AM - 1:00 PM & 5:00 PM - 9:30 PM',
    entryFees: 'Dwarkadhish Temple Entry: Free | Bet Dwarka Ferry Ride: ₹30 | Sudama Setu Bridge: ₹10',
    coordinates: { lat: 22.2394, lng: 68.9678 },
    popularFor: ['Dwarkadhish Temple', 'Bet Dwarka Island', 'Nageshwar Jyotirlinga', 'Rukmini Devi Temple', 'Sudama Setu Bridge'],
    emergencyContacts: [
      { service: 'Police', number: '112' },
      { service: 'Dwarka Tourism Cell', number: '02892-234132' },
      { service: 'Ambulance', number: '108' }
    ]
  }
];

export const ATTRACTIONS_DATA: Attraction[] = [
  // Goa Attractions
  {
    id: 'goa-1',
    destinationId: 'goa',
    name: 'Baga & Calangute Beach',
    category: 'Top Attractions',
    image: 'https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?q=80&w=800&auto=format&fit=crop',
    description: 'The energetic heart of North Goa featuring water sports, beach shacks, golden sand, and vibrant nightlife.',
    duration: '3 - 4 Hours',
    entryFee: 'Free Entry (Water sports ₹500 - ₹2000)',
    timing: '6:00 AM - 12:00 AM',
    highlight: 'Parasailing, Jet Ski & Fresh Calamari Shacks'
  },
  {
    id: 'goa-2',
    destinationId: 'goa',
    name: 'Fontainhas Latin Quarter',
    category: 'Hidden Gems',
    image: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?q=80&w=800&auto=format&fit=crop',
    description: 'A charming UNESCO heritage quarter in Panaji lined with brightly painted pastel Portuguese villas, narrow cobblestone streets, and boutique art cafes.',
    duration: '2 Hours',
    entryFee: 'Free',
    timing: '24 Hours',
    highlight: 'Heritage Walking Photography & Portuguese Bakeries'
  },
  {
    id: 'goa-3',
    destinationId: 'goa',
    name: 'Dudhsagar Waterfalls',
    category: 'Waterfalls',
    image: 'https://images.unsplash.com/photo-1582510003544-4d00b7f74220?q=80&w=800&auto=format&fit=crop',
    description: 'A majestic 4-tiered waterfall cascading down 310 meters through Bhagwan Mahavir Wildlife Sanctuary resembling a sea of milk.',
    duration: '5 Hours',
    entryFee: '₹500 Jeep Safari + ₹100 Life Jacket',
    timing: '9:00 AM - 4:00 PM',
    highlight: 'Jeep Jungle Trek & Swimming in Natural Pool'
  },
  {
    id: 'goa-4',
    destinationId: 'goa',
    name: 'Aguada Fort & Lighthouse',
    category: 'Historical Places',
    image: 'https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?q=80&w=800&auto=format&fit=crop',
    description: 'A 17th-century Portuguese fortress standing at the confluence of the Mandovi River and Arabian Sea with a 4-story lighthouse.',
    duration: '2 Hours',
    entryFee: '₹25 (Indian), ₹300 (Foreigner)',
    timing: '9:00 AM - 6:00 PM',
    highlight: 'Panoramic Ocean Sunset Views'
  },
  {
    id: 'goa-5',
    destinationId: 'goa',
    name: 'Tito’s Lane & Clubbing',
    category: 'Nightlife',
    image: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?q=80&w=800&auto=format&fit=crop',
    description: 'The famous nightlife alley in Baga lined with iconic clubs like Club Tito’s, Mambo’s, and live music lounges.',
    duration: '4 Hours',
    entryFee: 'Cover charge ₹1,500 - ₹3,000 for couples',
    timing: '8:00 PM - 4:00 AM',
    highlight: 'EDM, Commercial Pop & Cocktail Bars'
  },

  // Jaipur Attractions
  {
    id: 'jaipur-1',
    destinationId: 'jaipur',
    name: 'Amer (Amber) Fort',
    category: 'Top Attractions',
    image: 'https://images.unsplash.com/photo-1599661046289-e31897846e41?q=80&w=800&auto=format&fit=crop',
    description: 'A grand hill fort overlooking Maota Lake known for artistic Hindu and Mughal elements, Sheesh Mahal (Mirror Palace), and royal courtyards.',
    duration: '3 Hours',
    entryFee: '₹100 (Indian), ₹500 (Foreigner)',
    timing: '8:00 AM - 5:30 PM & Night 6:30 PM - 9:00 PM',
    highlight: 'Sheesh Mahal & Night Light Show'
  },
  {
    id: 'jaipur-2',
    destinationId: 'jaipur',
    name: 'Hawa Mahal (Palace of Winds)',
    category: 'Top Attractions',
    image: 'https://images.unsplash.com/photo-1477587458883-47145ed94245?q=80&w=800&auto=format&fit=crop',
    description: 'Iconic 5-story pink sandstone palace with 953 intricate jharokhas (latticed windows) built so royal ladies could observe street festivals unseen.',
    duration: '1.5 Hours',
    entryFee: '₹50 (Indian), ₹200 (Foreigner)',
    timing: '9:00 AM - 5:00 PM',
    highlight: 'Rooftop Cafe Views across the street'
  },
  {
    id: 'jaipur-3',
    destinationId: 'jaipur',
    name: 'Panna Meena ka Kund',
    category: 'Hidden Gems',
    image: 'https://images.unsplash.com/photo-1599661046289-e31897846e41?q=80&w=800&auto=format&fit=crop',
    description: 'An ancient 16th-century symmetrical stepwell near Amer Fort featuring criss-cross geometrical stairs.',
    duration: '45 Mins',
    entryFee: 'Free',
    timing: '7:00 AM - 6:00 PM',
    highlight: 'Geometric Stepwell Architectural Photography'
  },
  {
    id: 'jaipur-4',
    destinationId: 'jaipur',
    name: 'Bapu & Johari Bazaar',
    category: 'Shopping Areas',
    image: 'https://images.unsplash.com/photo-1582510003544-4d00b7f74220?q=80&w=800&auto=format&fit=crop',
    description: 'Vibrant old city markets famous for Jaipuri razai quilts, Kundan gemstone jewelry, Bandhani textiles, and Mojari leather footwear.',
    duration: '3 Hours',
    entryFee: 'Free',
    timing: '10:30 AM - 9:00 PM',
    highlight: 'Jewelry, Blue Pottery & Handicrafts'
  },

  // Manali Attractions
  {
    id: 'manali-1',
    destinationId: 'manali',
    name: 'Solang Valley Adventure Hub',
    category: 'Adventure Activities',
    image: 'https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?q=80&w=800&auto=format&fit=crop',
    description: 'A paradise valley surrounded by glaciers and snow slopes offering paragliding, zorbing, quad biking, and winter skiing.',
    duration: '4 Hours',
    entryFee: 'Ropeway ₹700 | Paragliding ₹2000 - ₹3500',
    timing: '9:00 AM - 6:00 PM',
    highlight: 'Tandem Paragliding over snowy mountain forest'
  },
  {
    id: 'manali-2',
    destinationId: 'manali',
    name: 'Hadimba Wooden Temple',
    category: 'Temples',
    image: 'https://images.unsplash.com/photo-1581793745862-99fde7fa73d2?q=80&w=800&auto=format&fit=crop',
    description: 'A unique 16th-century 4-tiered wooden pagoda temple located amidst towering ancient Dhungri Deodar pine trees.',
    duration: '1.5 Hours',
    entryFee: 'Free',
    timing: '8:00 AM - 6:00 PM',
    highlight: 'Wooden Carvings & Yak Rides'
  },

  // Leh Ladakh Attractions
  {
    id: 'leh-1',
    destinationId: 'leh',
    name: 'Pangong Tso Turquoise Lake',
    category: 'Top Attractions',
    image: 'https://images.unsplash.com/photo-1548013146-72479768bada?q=80&w=800&auto=format&fit=crop',
    description: 'High-altitude endorheic salt lake at 4,225m altitude extending from India into Tibet, famous for changing colors from sapphire blue to emerald green.',
    duration: 'Full Day Excursion',
    entryFee: 'Included in ILP (₹500)',
    timing: 'Daylight hours',
    highlight: 'Color-shifting lake waters & 3-Idiots movie point'
  },
  {
    id: 'leh-2',
    destinationId: 'leh',
    name: 'Nubra Valley & Hunder Sand Dunes',
    category: 'Adventure Activities',
    image: 'https://images.unsplash.com/photo-1581793745862-99fde7fa73d2?q=80&w=800&auto=format&fit=crop',
    description: 'Cold desert valley between Karakoram and Ladakh ranges known for Bactrian double-humped camel rides on white sand dunes.',
    duration: 'Overnight Trip',
    entryFee: 'Camel Ride ₹500 - ₹800',
    timing: '7:00 AM - 7:00 PM',
    highlight: 'Bactrian Double Humped Camel Ride'
  },

  // Udaipur Attractions
  {
    id: 'udaipur-1',
    destinationId: 'udaipur',
    name: 'City Palace Complex',
    category: 'Top Attractions',
    image: 'https://images.unsplash.com/photo-1615836245337-f5b9b2303f10?q=80&w=800&auto=format&fit=crop',
    description: 'Rajasthan’s largest royal palace complex overlooking Lake Pichola, featuring grand courtyards, mirror work, peacock mosaic rooms, and royal armor.',
    duration: '3 Hours',
    entryFee: '₹300 (Adults)',
    timing: '9:00 AM - 5:30 PM',
    highlight: 'Peacock Courtyard (Mor Chowk) & Crystal Gallery'
  },
  {
    id: 'udaipur-2',
    destinationId: 'udaipur',
    name: 'Lake Pichola & Jagmandir',
    category: 'Top Attractions',
    image: 'https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?q=80&w=800&auto=format&fit=crop',
    description: 'An picturesque artificial fresh water lake featuring boat trips past Taj Lake Palace to Jagmandir island palace.',
    duration: '2 Hours',
    entryFee: 'Boat Ride ₹400 - ₹800',
    timing: '9:00 AM - 6:00 PM',
    highlight: 'Sunset Boat Cruise & Island Dining'
  },

  // Kerala Attractions
  {
    id: 'kerala-1',
    destinationId: 'kerala',
    name: 'Alleppey Backwaters Cruise',
    category: 'Top Attractions',
    image: 'https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?q=80&w=800&auto=format&fit=crop',
    description: 'Glide through serene coconut-fringed palm canals, duck paddocks, and paddy fields on traditional Kettuvallam houseboats.',
    duration: 'Overnight / 4 Hours Shikara',
    entryFee: 'Shikara ₹1200/hr | Houseboat ₹8,000 - ₹20,000',
    timing: '12:00 PM - 5:00 PM (Overnight)',
    highlight: 'Traditional Karimeen Fry Served on Houseboat'
  },
  {
    id: 'kerala-2',
    destinationId: 'kerala',
    name: 'Munnar Tea Estates & Mattupetty',
    category: 'Hill Stations',
    image: 'https://images.unsplash.com/photo-1593693397690-362cb9666fc2?q=80&w=800&auto=format&fit=crop',
    description: 'Rolling velvet green tea plantations 1,600 meters above sea level, featuring tea museum tours, echo point, and Eravikulam Nilgiri Tahr sanctuary.',
    duration: 'Full Day',
    entryFee: 'Eravikulam National Park ₹200',
    timing: '8:00 AM - 4:30 PM',
    highlight: 'Fresh Tea Tasting & Mountain Mist Views'
  },

  // Ayodhya Attractions
  {
    id: 'ayodhya-1',
    destinationId: 'ayodhya',
    name: 'Shri Ram Janmabhoomi Mandir',
    category: 'Top Attractions',
    image: 'https://images.unsplash.com/photo-1627894483216-2138af692e32?q=80&w=800&auto=format&fit=crop',
    description: 'The monumental Nagara-style stone temple constructed at the sacred birthplace of Lord Rama.',
    duration: '2 - 3 Hours',
    entryFee: 'Free (Sugam Darshan E-Pass available)',
    timing: '6:30 AM - 12:00 PM & 2:00 PM - 10:00 PM',
    highlight: 'Ram Lalla Virajman Idol & Marble Carvings'
  },
  {
    id: 'ayodhya-2',
    destinationId: 'ayodhya',
    name: 'Hanuman Garhi Temple',
    category: 'Temples',
    image: 'https://images.unsplash.com/photo-1627894483216-2138af692e32?q=80&w=800&auto=format&fit=crop',
    description: 'A 10th-century hilltop temple accessed by 76 steps dedicated to Lord Hanuman who guards the city of Ayodhya.',
    duration: '1 Hour',
    entryFee: 'Free',
    timing: '5:00 AM - 10:00 PM',
    highlight: 'Sacred Evening Aarti & Panoramic Views'
  },
  {
    id: 'ayodhya-3',
    destinationId: 'ayodhya',
    name: 'Saryu River Ghats & Evening Aarti',
    category: 'Top Attractions',
    image: 'https://images.unsplash.com/photo-1627894483216-2138af692e32?q=80&w=800&auto=format&fit=crop',
    description: 'Revered river ghats where thousands gather every evening for solemn multi-tiered lamp Aarti and devotional chants.',
    duration: '1.5 Hours',
    entryFee: 'Free (Boat rides ₹100 - ₹200)',
    timing: '6:00 PM - 7:30 PM',
    highlight: 'Ganga/Saryu Aarti & Diya Floating'
  }
];

export const HOTELS_DATA: Hotel[] = [
  // Goa Hotels
  {
    id: 'goa-h1',
    destinationId: 'goa',
    name: 'Zostel Goa (Anjuna)',
    category: 'Budget',
    pricePerNight: '₹800 - ₹1,500',
    rating: 4.6,
    image: 'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?q=80&w=800&auto=format&fit=crop',
    location: 'Anjuna Beach, North Goa',
    amenities: ['Free WiFi', 'Swimming Pool', 'Social Common Room', 'Cafe', 'AC Dorms'],
    bookingHint: 'Ideal for backpackers, solo travelers, and digital nomads.'
  },
  {
    id: 'goa-h2',
    destinationId: 'goa',
    name: 'Hard Rock Hotel Goa',
    category: 'Mid Range',
    pricePerNight: '₹4,500 - ₹8,000',
    rating: 4.7,
    image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?q=80&w=800&auto=format&fit=crop',
    location: 'Calangute, North Goa',
    amenities: ['Lagoon Pool', 'Live Music Lounge', 'Spa', 'Fitness Centre', 'Restaurant'],
    bookingHint: 'Great for energetic families and music lovers.'
  },
  {
    id: 'goa-h3',
    destinationId: 'goa',
    name: 'The Leela Goa',
    category: 'Luxury',
    pricePerNight: '₹18,000 - ₹35,000',
    rating: 4.9,
    image: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?q=80&w=800&auto=format&fit=crop',
    location: 'Mobor Beach, South Goa',
    amenities: ['Private Beach', 'Golf Course', 'Lagoons & Villas', 'Ayurveda Spa', 'Fine Dining'],
    bookingHint: 'Ultra-luxurious beach sanctuary for honeymoons and high-end stays.'
  },

  // Jaipur Hotels
  {
    id: 'jaipur-h1',
    destinationId: 'jaipur',
    name: 'Moustache Hostel Jaipur',
    category: 'Budget',
    pricePerNight: '₹600 - ₹1,200',
    rating: 4.5,
    image: 'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?q=80&w=800&auto=format&fit=crop',
    location: 'MI Road, Near Railway Station',
    amenities: ['Rooftop Pool', 'Fort View Cafe', 'Free WiFi', 'Cultural Walks'],
    bookingHint: 'Budget traveler favorite with vibrant rooftop.'
  },
  {
    id: 'jaipur-h2',
    destinationId: 'jaipur',
    name: 'Shahpura House Heritage Hotel',
    category: 'Mid Range',
    pricePerNight: '₹5,000 - ₹9,000',
    rating: 4.8,
    image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?q=80&w=800&auto=format&fit=crop',
    location: 'Bani Park, Jaipur',
    amenities: ['Royal Fresco Suites', 'Pool', 'Puppet Shows', 'Rooftop Dining'],
    bookingHint: 'Traditional Rajputana heritage haveli feel at accessible price.'
  },
  {
    id: 'jaipur-h3',
    destinationId: 'jaipur',
    name: 'Rambagh Palace (Taj Hotels)',
    category: 'Luxury',
    pricePerNight: '₹45,000 - ₹90,000',
    rating: 4.95,
    image: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?q=80&w=800&auto=format&fit=crop',
    location: 'Bhawani Singh Road, Jaipur',
    amenities: ['Former Royal Palace Grounds', 'Peacock Gardens', 'Jharokha Dining', 'Butler Service'],
    bookingHint: 'Voted world’s #1 hotel by TripAdvisor Travellers Choice.'
  }
];

export const FOOD_ITEMS: FoodItem[] = [
  // Goa Food
  {
    id: 'goa-f1',
    destinationId: 'goa',
    name: 'Goan Fish Thali',
    category: 'Must Try Foods',
    isVeg: false,
    description: 'Classic meal featuring kingfish/pomfret fry, coconut fish curry, sol kadi, clams, rice, and kokum gravy.',
    priceRange: '₹200 - ₹450',
    recommendedPlaces: ['Ritz Classic Panaji', 'Anantashram', 'Fisherman’s Wharf'],
    image: 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?q=80&w=800&auto=format&fit=crop'
  },
  {
    id: 'goa-f2',
    destinationId: 'goa',
    name: 'Bebinca & Dodol',
    category: 'Local Specialities',
    isVeg: true,
    description: 'Traditional multi-layered Goan Portuguese dessert made with coconut milk, egg yolk, ghee, and flour.',
    priceRange: '₹150 - ₹300',
    recommendedPlaces: ['Infanteria Bakery Calangute', 'Confeitaria 31 De Janeiro'],
    image: 'https://images.unsplash.com/photo-1587314168485-3236d6710814?q=80&w=800&auto=format&fit=crop'
  },

  // Jaipur Food
  {
    id: 'jaipur-f1',
    destinationId: 'jaipur',
    name: 'Dal Baati Churma',
    category: 'Must Try Foods',
    isVeg: true,
    description: 'The quintessential Rajasthani dish consisting of baked wheat baati drenched in pure ghee, Panchmel dal, and sweet churma.',
    priceRange: '₹250 - ₹600',
    recommendedPlaces: ['Chokhi Dhani', 'Thali House MI Road', 'LMB Johari Bazaar'],
    image: 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?q=80&w=800&auto=format&fit=crop'
  },
  {
    id: 'jaipur-f2',
    destinationId: 'jaipur',
    name: 'Pyaz Kachori & Ghewar',
    category: 'Street Food',
    isVeg: true,
    description: 'Crispy fried onion kachori served with tamarind chutney followed by honeycomb disk Ghewar sweet.',
    priceRange: '₹40 - ₹120',
    recommendedPlaces: ['Rawat Mishtan Bhandar', 'Sodhani Sweets'],
    image: 'https://images.unsplash.com/photo-1587314168485-3236d6710814?q=80&w=800&auto=format&fit=crop'
  }
];

export const YOUTUBE_VIDEOS: YouTubeVideo[] = [
  // Goa Videos
  {
    id: 'goa-v1',
    videoId: 'q1y3b8X8x-M',
    title: 'GOA TRAVEL GUIDE 2026: Best Places, Budget & Nightlife',
    channel: 'India Travel Vlogs',
    category: 'Travel Guide',
    thumbnail: 'https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?q=80&w=600&auto=format&fit=crop',
    duration: '18:42',
    views: '1.2M'
  },
  {
    id: 'goa-v2',
    videoId: 'x3T5yJ2m0aQ',
    title: 'Goan Street Food Tour - Best Fish Thali & Sol Kadi!',
    channel: 'Foodie Trails India',
    category: 'Food Guide',
    thumbnail: 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?q=80&w=600&auto=format&fit=crop',
    duration: '14:15',
    views: '850K'
  },
  {
    id: 'goa-v3',
    videoId: '9bZkp7q19f0',
    title: 'Top 10 Hidden Places in South Goa You Never Knew Existed',
    channel: 'Unexplored India',
    category: 'Hidden Places',
    thumbnail: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?q=80&w=600&auto=format&fit=crop',
    duration: '12:08',
    views: '620K'
  },

  // Jaipur Videos
  {
    id: 'jaipur-v1',
    videoId: 'd3k9P1q7Z8A',
    title: 'JAIPUR 3 DAY ITINERARY: Complete Royal Tour under ₹5000',
    channel: 'Nomadic Bharat',
    category: '3 Day Itinerary',
    thumbnail: 'https://images.unsplash.com/photo-1477587458883-47145ed94245?q=80&w=600&auto=format&fit=crop',
    duration: '22:10',
    views: '2.1M'
  },
  {
    id: 'jaipur-v2',
    videoId: 'p8Y2M4x9W01',
    title: 'Exploring Amer Fort & Hawa Mahal - Pink City Travel Guide',
    channel: 'Heritage India',
    category: 'Things To Do',
    thumbnail: 'https://images.unsplash.com/photo-1599661046289-e31897846e41?q=80&w=600&auto=format&fit=crop',
    duration: '16:30',
    views: '940K'
  }
];

export const NEARBY_DESTINATIONS: Record<string, NearbyDestination[]> = {
  goa: [
    {
      id: 'gokarna',
      name: 'Gokarna',
      distance: '134 km',
      travelTime: '3 Hours',
      highlight: 'Om Beach, Kudle Beach & Mahabaleshwar Shiva Temple',
      category: 'Beaches & Spiritual',
      image: 'https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?q=80&w=600&auto=format&fit=crop'
    },
    {
      id: 'dudhsagar',
      name: 'Dudhsagar Falls',
      distance: '60 km',
      travelTime: '1.5 Hours',
      highlight: 'Milky 4-tiered waterfall & forest jeep safari',
      category: 'Waterfalls',
      image: 'https://images.unsplash.com/photo-1582510003544-4d00b7f74220?q=80&w=600&auto=format&fit=crop'
    },
    {
      id: 'amboli',
      name: 'Amboli Ghat',
      distance: '90 km',
      travelTime: '2 Hours',
      highlight: 'Misty Western Ghats, waterfalls & ecological trails',
      category: 'Hill Station',
      image: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=600&auto=format&fit=crop'
    },
    {
      id: 'karwar',
      name: 'Karwar Coast',
      distance: '85 km',
      travelTime: '2 Hours',
      highlight: 'Tagore Beach, Warship Museum & Kali River estuary',
      category: 'Coastal Town',
      image: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?q=80&w=600&auto=format&fit=crop'
    }
  ],
  jaipur: [
    {
      id: 'pushkar',
      name: 'Pushkar & Ajmer',
      distance: '145 km',
      travelTime: '2.5 Hours',
      highlight: 'Brahma Temple, Sacred Pushkar Lake & Ajmer Sharif Dargah',
      category: 'Spiritual',
      image: 'https://images.unsplash.com/photo-1599661046289-e31897846e41?q=80&w=600&auto=format&fit=crop'
    },
    {
      id: 'ranthambore',
      name: 'Ranthambore Tiger Reserve',
      distance: '160 km',
      travelTime: '3.5 Hours',
      highlight: 'Royal Bengal Tiger Jungle Jeep Safari & Ranthambore Fort',
      category: 'Wildlife',
      image: 'https://images.unsplash.com/photo-1561731216-c3a4d99437d5?q=80&w=600&auto=format&fit=crop'
    },
    {
      id: 'bhangarh',
      name: 'Bhangarh Fort & Abhaneri',
      distance: '85 km',
      travelTime: '2 Hours',
      highlight: 'Haunted 17th Century Fort ruins & Chand Baori stepwell',
      category: 'Heritage & Mystery',
      image: 'https://images.unsplash.com/photo-1477587458883-47145ed94245?q=80&w=600&auto=format&fit=crop'
    }
  ]
};

export const TRANSPORT_OPTIONS: Record<string, TransportOption[]> = {
  goa: [
    {
      mode: 'Flight',
      description: 'Dabolim Airport (GOI) in South Goa & Manohar International Airport (GOX) in MOPA North Goa.',
      travelTime: '1 - 2.5 hrs from major Indian cities',
      approximateCost: '₹3,000 - ₹7,000',
      frequency: '50+ Flights daily',
      tips: 'Book Mopa Airport (GOX) if staying in Baga/Anjuna/Arambol.'
    },
    {
      mode: 'Train',
      description: 'Madgaon (MAO) & Thivim (THVM) Railway stations connected via Konkan Railway.',
      travelTime: '8 - 12 hrs from Mumbai/Bengaluru',
      approximateCost: '₹400 - ₹1,800',
      frequency: '15+ Daily Express trains',
      tips: 'Konkan Railway scenic route through tunnels is spectacular during monsoons.'
    },
    {
      mode: 'Local Transport',
      description: 'Self-drive rental cars, Activa scooters, and Goa Miles app cabs.',
      travelTime: 'Instant rental',
      approximateCost: 'Scooter: ₹350 - ₹500/day | Car: ₹1,500 - ₹3,000/day',
      frequency: 'Available everywhere',
      tips: 'Carry valid driving license and helmet at all times.'
    }
  ],
  jaipur: [
    {
      mode: 'Flight',
      description: 'Jaipur International Airport (JAI) at Sanganer.',
      travelTime: '1 hr from Delhi, 2 hrs from Mumbai',
      approximateCost: '₹2,500 - ₹5,500',
      frequency: 'Direct daily flights',
      tips: 'Airport is just 12 km from city center.'
    },
    {
      mode: 'Train',
      description: 'Jaipur Junction (JP) - Vande Bharat Express from Delhi.',
      travelTime: '3.5 hrs from Delhi',
      approximateCost: '₹600 - ₹1,400',
      frequency: 'Hourly trains from Delhi/Agra',
      tips: 'Take early morning Delhi-Jaipur Vande Bharat for quick 4-hour travel.'
    },
    {
      mode: 'Metro',
      description: 'Jaipur Metro Rail connects Mansarovar to Chandpole in Pink City.',
      travelTime: '15 Mins',
      approximateCost: '₹10 - ₹20',
      frequency: 'Every 10 minutes',
      tips: 'Great for bypassing old city traffic jams.'
    }
  ]
};

export const CATEGORIES_LIST = [
  { id: 'all', name: 'All Destinations', icon: 'Sparkles' },
  { id: 'Spiritual', name: 'Spiritual & Yatra', icon: 'Flame' },
  { id: 'Beaches', name: 'Beaches & Coastal', icon: 'Umbrella' },
  { id: 'Hill Stations', name: 'Hill Stations & Snow', icon: 'Mountain' },
  { id: 'Heritage', name: 'Heritage & Forts', icon: 'Castle' },
  { id: 'Adventure', name: 'Adventure & Trekking', icon: 'Compass' },
  { id: 'Honeymoon', name: 'Honeymoon & Romantic', icon: 'Heart' },
  { id: 'Cultural', name: 'Cultural & Food', icon: 'Utensils' }
];

import { jsPDF } from 'jspdf';
import { TripPlan, Destination } from '../types';

export const exportItineraryPDF = (trip: TripPlan, destination?: Destination) => {
  const doc = new jsPDF({
    orientation: 'p',
    unit: 'mm',
    format: 'a4'
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 15;
  let y = margin;

  // Primary Colors
  const primaryColor: [number, number, number] = [234, 88, 12]; // Orange-600
  const secondaryColor: [number, number, number] = [30, 41, 59]; // Slate-800
  const lightBg: [number, number, number] = [248, 250, 252]; // Slate-50

  const checkPageBreak = (neededHeight: number) => {
    if (y + neededHeight > pageHeight - margin) {
      doc.addPage();
      y = margin;
    }
  };

  // Header Banner
  doc.setFillColor(...primaryColor);
  doc.rect(0, 0, pageWidth, 28, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.text('TravelGPT AI', margin, 12);

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text('Plan • Budget • Explore • Experience', margin, 18);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text(`TRIP ITINERARY: ${trip.destinationName.toUpperCase()}`, pageWidth - margin, 12, { align: 'right' });
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.text(`Generated on ${new Date().toLocaleDateString('en-IN')}`, pageWidth - margin, 18, { align: 'right' });

  y = 36;

  // Trip Overview Card
  doc.setFillColor(...lightBg);
  doc.roundedRect(margin, y, pageWidth - margin * 2, 28, 3, 3, 'F');

  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(margin, y, pageWidth - margin * 2, 28, 3, 3, 'S');

  doc.setTextColor(...secondaryColor);
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text(trip.title, margin + 5, y + 8);

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text(`Destination: ${trip.destinationName}`, margin + 5, y + 15);
  doc.text(`Duration: ${trip.numberOfDays} Days`, margin + 65, y + 15);
  doc.text(`Travel Style: ${trip.travelType}`, margin + 115, y + 15);

  doc.text(`Budget Tier: ${trip.budgetTier}`, margin + 5, y + 22);
  doc.text(`Est. Total Budget: ₹${trip.totalBudget?.total?.toLocaleString('en-IN') || 'N/A'}`, margin + 65, y + 22);

  y += 36;

  // Day-wise Itinerary
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...primaryColor);
  doc.text('DAY-BY-DAY ITINERARY', margin, y);
  y += 6;

  trip.itinerary.forEach((dayItem) => {
    checkPageBreak(50);

    // Day Header
    doc.setFillColor(234, 88, 12);
    doc.rect(margin, y, 22, 7, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(9);
    doc.setFont('helvetica', 'bold');
    doc.text(`DAY ${dayItem.day}`, margin + 3, y + 5);

    doc.setTextColor(...secondaryColor);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text(dayItem.title, margin + 26, y + 5);

    y += 10;

    doc.setFontSize(8.5);
    doc.setFont('helvetica', 'normal');

    const schedule = [
      { label: 'Morning:', text: dayItem.morning },
      { label: 'Afternoon:', text: dayItem.afternoon },
      { label: 'Evening:', text: dayItem.evening },
      { label: 'Food & Dining:', text: dayItem.food },
      { label: 'Transport:', text: dayItem.travel },
      { label: 'Night Stay:', text: dayItem.stay }
    ];

    schedule.forEach((s) => {
      checkPageBreak(12);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(234, 88, 12);
      doc.text(s.label, margin + 5, y);

      doc.setFont('helvetica', 'normal');
      doc.setTextColor(51, 65, 85);
      const splitLines = doc.splitTextToSize(s.text || 'N/A', pageWidth - margin * 2 - 35);
      doc.text(splitLines, margin + 32, y);

      y += splitLines.length * 4.2 + 1;
    });

    if (dayItem.approxBudget) {
      checkPageBreak(10);
      doc.setFont('helvetica', 'italic');
      doc.setTextColor(100, 116, 139);
      doc.text(`Estimated Day ${dayItem.day} Cost: ₹${dayItem.approxBudget.total?.toLocaleString('en-IN') || 0}`, margin + 5, y);
      y += 6;
    }

    doc.setDrawColor(226, 232, 240);
    doc.line(margin, y, pageWidth - margin, y);
    y += 6;
  });

  // Budget Breakdown Table
  checkPageBreak(50);
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...primaryColor);
  doc.text('ESTIMATED BUDGET BREAKDOWN', margin, y);
  y += 6;

  doc.setFillColor(241, 245, 249);
  doc.rect(margin, y, pageWidth - margin * 2, 7, 'F');
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...secondaryColor);
  doc.text('Expense Category', margin + 5, y + 5);
  doc.text('Estimated Cost (INR)', pageWidth - margin - 5, y + 5, { align: 'right' });
  y += 8;

  const budgetItems = [
    { name: 'Accommodation', cost: trip.totalBudget?.accommodation || 0 },
    { name: 'Food & Dining', cost: trip.totalBudget?.food || 0 },
    { name: 'Transport & Fuel', cost: trip.totalBudget?.transport || 0 },
    { name: 'Entry Tickets & Activities', cost: trip.totalBudget?.entryTickets || 0 },
    { name: 'Shopping & Souvenirs', cost: trip.totalBudget?.shopping || 0 },
    { name: 'Miscellaneous & Contingency', cost: trip.totalBudget?.miscellaneous || 0 }
  ];

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);

  budgetItems.forEach((b) => {
    checkPageBreak(8);
    doc.text(b.name, margin + 5, y);
    doc.text(`₹${b.cost.toLocaleString('en-IN')}`, pageWidth - margin - 5, y, { align: 'right' });
    y += 5;
  });

  doc.setDrawColor(203, 213, 225);
  doc.line(margin, y, pageWidth - margin, y);
  y += 4;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(...primaryColor);
  doc.text('GRAND TOTAL ESTIMATED BUDGET', margin + 5, y);
  doc.text(`₹${(trip.totalBudget?.total || 0).toLocaleString('en-IN')}`, pageWidth - margin - 5, y, { align: 'right' });
  y += 12;

  // Emergency Contacts section
  checkPageBreak(35);
  doc.setFillColor(254, 242, 242);
  doc.roundedRect(margin, y, pageWidth - margin * 2, 25, 2, 2, 'F');
  doc.setDrawColor(252, 165, 165);
  doc.roundedRect(margin, y, pageWidth - margin * 2, 25, 2, 2, 'S');

  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(185, 28, 28);
  doc.text('EMERGENCY CONTACTS IN INDIA', margin + 5, y + 6);

  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(51, 65, 85);
  doc.text('• National Police Helpline: 112 / 100', margin + 5, y + 12);
  doc.text('• Medical Ambulance: 108', margin + 70, y + 12);
  doc.text('• Tourist Helpline: 1364', margin + 125, y + 12);

  if (destination?.emergencyContacts) {
    const customContacts = destination.emergencyContacts.map((c) => `${c.service}: ${c.number}`).join(' | ');
    doc.text(`• Local ${trip.destinationName} Helplines: ${customContacts}`, margin + 5, y + 18);
  } else {
    doc.text('• Disaster Management Helpline: 1070', margin + 5, y + 18);
  }

  // Footer
  const totalPages = (doc as any).internal.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFontSize(7.5);
    doc.setTextColor(148, 163, 184);
    doc.text('TravelGPT AI – Intelligent India Travel Planner | https://ai.studio', margin, pageHeight - 8);
    doc.text(`Page ${i} of ${totalPages}`, pageWidth - margin, pageHeight - 8, { align: 'right' });
  }

  // Save File
  doc.save(`${trip.destinationName.replaceAll(/\s+/g, '_')}_Itinerary_TravelGPT.pdf`);
};

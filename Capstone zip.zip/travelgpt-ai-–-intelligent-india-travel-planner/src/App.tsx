import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { DestinationCard } from './components/DestinationCard';
import { DestinationDetail } from './components/DestinationDetail';
import { AITripPlannerView } from './components/AITripPlannerView';
import { BudgetPlannerView } from './components/BudgetPlannerView';
import { SavedTripsView } from './components/SavedTripsView';
import { AIChatDrawer } from './components/AIChatDrawer';
import { SearchModal } from './components/SearchModal';
import { DESTINATIONS } from './data/destinations';
import { Destination, TripPlan } from './types';
import { Sparkles, MapPin, Heart, Compass, ShieldCheck, PhoneCall, ExternalLink, ArrowRight } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('explore');
  const [selectedDestination, setSelectedDestination] = useState<Destination | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  
  const [savedTrips, setSavedTrips] = useState<TripPlan[]>([]);
  const [favorites, setFavorites] = useState<string[]>(['goa', 'jaipur']);
  
  const [searchModalOpen, setSearchModalOpen] = useState(false);
  const [chatDrawerOpen, setChatDrawerOpen] = useState(false);
  const [darkMode, setDarkMode] = useState<boolean>(true);
  const [plannerInitialDest, setPlannerInitialDest] = useState<string>('Goa');

  // Sync dark mode class on document element
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Load Trips & Favorites from Backend
  useEffect(() => {
    fetch('/api/trips')
      .then((res) => res.json())
      .then((data) => {
        if (data.trips) setSavedTrips(data.trips);
      })
      .catch((err) => console.error('Failed to load trips:', err));

    fetch('/api/favorites')
      .then((res) => res.json())
      .then((data) => {
        if (data.favorites) setFavorites(data.favorites);
      })
      .catch((err) => console.error('Failed to load favorites:', err));
  }, []);

  // Toggle Favorite Handler
  const handleToggleFavorite = async (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    try {
      const res = await fetch('/api/favorites/toggle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ destinationId: id })
      });
      const data = await res.json();
      if (data.favorites) {
        setFavorites(data.favorites);
      }
    } catch (err) {
      console.error('Toggle favorite error:', err);
    }
  };

  // Save Trip Handler
  const handleSaveTrip = async (newTrip: TripPlan) => {
    try {
      const res = await fetch('/api/trips', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newTrip)
      });
      const data = await res.json();
      if (data.trip) {
        setSavedTrips((prev) => [data.trip, ...prev]);
      }
    } catch (err) {
      console.error('Save trip error:', err);
      setSavedTrips((prev) => [newTrip, ...prev]);
    }
  };

  // Delete Trip Handler
  const handleDeleteTrip = async (id: string) => {
    try {
      await fetch(`/api/trips/${id}`, { method: 'DELETE' });
      setSavedTrips((prev) => prev.filter((t) => t.id !== id));
    } catch (err) {
      console.error('Delete trip error:', err);
    }
  };

  // Navigation Handlers
  const handleOpenAIPlannerForDest = (destinationName: string) => {
    setPlannerInitialDest(destinationName);
    setSelectedDestination(null);
    setActiveTab('ai-planner');
  };

  const handleSelectNearbyDestination = (destName: string) => {
    const found = DESTINATIONS.find((d) => d.name.toLowerCase() === destName.toLowerCase());
    if (found) {
      setSelectedDestination(found);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      setPlannerInitialDest(destName);
      setActiveTab('ai-planner');
    }
  };

  // Filtered Destinations for Explore / Destinations Grid
  const filteredDestinations = DESTINATIONS.filter((d) => {
    if (selectedCategory === 'All') return true;
    return d.category.includes(selectedCategory as any);
  });

  return (
    <div className="min-h-screen bg-[#0a0a14] text-white transition-colors flex flex-col font-sans selection:bg-indigo-500/30">
      
      {/* Global Header Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setSelectedDestination(null);
          setActiveTab(tab);
        }}
        savedTripsCount={savedTrips.length}
        favoritesCount={favorites.length}
        onOpenSearch={() => setSearchModalOpen(true)}
        onOpenChat={() => setChatDrawerOpen(true)}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
      />

      {/* Main App Content Viewport */}
      <main className="flex-1 pb-16">
        
        {/* VIEW 1: DESTINATION DETAIL PAGE */}
        {selectedDestination ? (
          <DestinationDetail
            destination={selectedDestination}
            onBack={() => setSelectedDestination(null)}
            isFavorite={favorites.includes(selectedDestination.id)}
            onToggleFavorite={(id) => handleToggleFavorite(id)}
            onOpenAIPlannerForDest={handleOpenAIPlannerForDest}
            onSelectNearby={handleSelectNearbyDestination}
          />
        ) : (
          <>
            {/* VIEW 2: EXPLORE (LANDING HOME) */}
            {activeTab === 'explore' && (
              <div className="space-y-12">
                <HeroSection
                  onSearchSubmit={(q) => {
                    const match = DESTINATIONS.find(
                      (d) => d.name.toLowerCase().includes(q.toLowerCase()) || d.state.toLowerCase().includes(q.toLowerCase())
                    );
                    if (match) {
                      setSelectedDestination(match);
                    } else {
                      setSearchModalOpen(true);
                    }
                  }}
                  onSelectCategory={setSelectedCategory}
                  selectedCategory={selectedCategory}
                  onOpenAIPlanner={() => setActiveTab('ai-planner')}
                />

                {/* Destinations Showcase Grid */}
                <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
                  <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
                    <div>
                      <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 backdrop-blur-md font-extrabold text-xs uppercase tracking-wider mb-2">
                        <Compass className="w-3.5 h-3.5 text-indigo-400" />
                        <span>Featured Travel Destinations</span>
                      </div>
                      <h2 className="text-3xl font-black text-white tracking-tight">
                        Explore Incredible <span className="text-indigo-400">India</span>
                      </h2>
                    </div>

                    <button
                      onClick={() => setActiveTab('destinations')}
                      className="text-xs font-bold text-indigo-400 hover:text-indigo-300 transition-colors flex items-center gap-1"
                    >
                      <span>View All {DESTINATIONS.length} Destinations</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredDestinations.map((dest) => (
                      <DestinationCard
                        key={dest.id}
                        destination={dest}
                        isFavorite={favorites.includes(dest.id)}
                        onToggleFavorite={handleToggleFavorite}
                        onSelectDestination={(d) => setSelectedDestination(d)}
                        onOpenAIPlannerForDest={handleOpenAIPlannerForDest}
                      />
                    ))}
                  </div>
                </section>
              </div>
            )}

            {/* VIEW 3: DESTINATIONS CATALOG */}
            {activeTab === 'destinations' && (
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8 animate-fadeIn">
                <div className="p-8 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 text-white shadow-2xl space-y-2">
                  <span className="px-3 py-1 rounded-full bg-indigo-600/40 text-indigo-300 border border-indigo-500/30 text-[10px] font-extrabold uppercase tracking-widest backdrop-blur-md">
                    Destinations Catalog
                  </span>
                  <h1 className="text-3xl font-black">All Destinations in <span className="text-indigo-400">India</span></h1>
                  <p className="text-xs text-white/60">
                    Handcrafted guides covering top attractions, heritage spots, spiritual yatras, and beach getaways.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {DESTINATIONS.map((dest) => (
                    <DestinationCard
                      key={dest.id}
                      destination={dest}
                      isFavorite={favorites.includes(dest.id)}
                      onToggleFavorite={handleToggleFavorite}
                      onSelectDestination={(d) => setSelectedDestination(d)}
                      onOpenAIPlannerForDest={handleOpenAIPlannerForDest}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* VIEW 4: AI TRIP PLANNER */}
            {activeTab === 'ai-planner' && (
              <AITripPlannerView
                initialDestination={plannerInitialDest}
                onSaveTrip={handleSaveTrip}
              />
            )}

            {/* VIEW 5: BUDGET PLANNER */}
            {activeTab === 'budget-calculator' && <BudgetPlannerView />}

            {/* VIEW 6: SAVED TRIPS */}
            {activeTab === 'saved-trips' && (
              <SavedTripsView
                trips={savedTrips}
                onDeleteTrip={handleDeleteTrip}
                onOpenAIPlanner={() => setActiveTab('ai-planner')}
              />
            )}
          </>
        )}

      </main>

      {/* Floating AI Chat Drawer */}
      <AIChatDrawer
        isOpen={chatDrawerOpen}
        onClose={() => setChatDrawerOpen(false)}
      />

      {/* Quick Cmd+K Search Modal */}
      <SearchModal
        isOpen={searchModalOpen}
        onClose={() => setSearchModalOpen(false)}
        onSelectDestination={(d) => setSelectedDestination(d)}
        recentSearches={[]}
      />

      {/* Global Footer */}
      <footer className="bg-black/40 backdrop-blur-xl text-white/50 border-t border-white/10 text-xs py-10 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-indigo-400" />
            <span className="font-extrabold text-white">TravelGPT <span className="text-indigo-400">AI</span></span>
            <span>– Intelligent India Travel Planner</span>
          </div>

          <p className="text-white/40">
            Powered by Gemini AI • Plan • Budget • Explore • Experience
          </p>
        </div>
      </footer>

    </div>
  );
}

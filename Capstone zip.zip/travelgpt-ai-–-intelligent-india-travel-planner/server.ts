import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// Ensure data directory exists for persistent storage
const DATA_DIR = path.join(process.cwd(), 'data');
const STORE_FILE = path.join(DATA_DIR, 'travel_store.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

interface StoreSchema {
  savedTrips: any[];
  favorites: string[];
  recentSearches: { id: string; query: string; timestamp: string }[];
}

const getStore = (): StoreSchema => {
  try {
    if (fs.existsSync(STORE_FILE)) {
      const data = fs.readFileSync(STORE_FILE, 'utf-8');
      return JSON.parse(data);
    }
  } catch (err) {
    console.error('Error reading store file:', err);
  }
  return {
    savedTrips: [],
    favorites: ['goa', 'jaipur'],
    recentSearches: [
      { id: '1', query: 'Goa beaches', timestamp: new Date().toISOString() },
      { id: '2', query: 'Jaipur royal palaces', timestamp: new Date().toISOString() }
    ]
  };
};

const saveStore = (store: StoreSchema) => {
  try {
    fs.writeFileSync(STORE_FILE, JSON.stringify(store, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing store file:', err);
  }
};

// Initialize Gemini Client
const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    console.warn('GEMINI_API_KEY is missing from environment variables.');
  }
  return new GoogleGenAI({
    apiKey: apiKey || '',
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build'
      }
    }
  });
};

// ==========================================
// API ROUTES
// ==========================================

// Health Check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'TravelGPT AI Backend', timestamp: new Date().toISOString() });
});

// GET Saved Trips
app.get('/api/trips', (req, res) => {
  const store = getStore();
  res.json({ trips: store.savedTrips });
});

// POST Save New Trip
app.post('/api/trips', (req, res) => {
  const store = getStore();
  const newTrip = {
    id: 'trip_' + Date.now(),
    createdAt: new Date().toISOString(),
    ...req.body
  };
  store.savedTrips.unshift(newTrip);
  saveStore(store);
  res.json({ success: true, trip: newTrip });
});

// PUT Edit Saved Trip
app.put('/api/trips/:id', (req, res) => {
  const { id } = req.params;
  const store = getStore();
  const index = store.savedTrips.findIndex((t) => t.id === id);
  if (index !== -1) {
    store.savedTrips[index] = { ...store.savedTrips[index], ...req.body };
    saveStore(store);
    return res.json({ success: true, trip: store.savedTrips[index] });
  }
  res.status(404).json({ error: 'Trip not found' });
});

// DELETE Saved Trip
app.delete('/api/trips/:id', (req, res) => {
  const { id } = req.params;
  const store = getStore();
  store.savedTrips = store.savedTrips.filter((t) => t.id !== id);
  saveStore(store);
  res.json({ success: true, id });
});

// GET Favorites
app.get('/api/favorites', (req, res) => {
  const store = getStore();
  res.json({ favorites: store.favorites });
});

// POST Toggle Favorite
app.post('/api/favorites/toggle', (req, res) => {
  const { destinationId } = req.body;
  if (!destinationId) {
    return res.status(400).json({ error: 'Destination ID required' });
  }
  const store = getStore();
  const index = store.favorites.indexOf(destinationId);
  let isFavorite = false;
  if (index !== -1) {
    store.favorites.splice(index, 1);
  } else {
    store.favorites.push(destinationId);
    isFavorite = true;
  }
  saveStore(store);
  res.json({ success: true, favorites: store.favorites, isFavorite });
});

// GET Recent Searches
app.get('/api/searches', (req, res) => {
  const store = getStore();
  res.json({ searches: store.recentSearches });
});

// POST Add Search
app.post('/api/searches', (req, res) => {
  const { query } = req.body;
  if (!query || !query.trim()) {
    return res.status(400).json({ error: 'Query required' });
  }
  const store = getStore();
  const filtered = store.recentSearches.filter((s) => s.query.toLowerCase() !== query.toLowerCase().trim());
  filtered.unshift({
    id: 'search_' + Date.now(),
    query: query.trim(),
    timestamp: new Date().toISOString()
  });
  store.recentSearches = filtered.slice(0, 10);
  saveStore(store);
  res.json({ searches: store.recentSearches });
});

// ==========================================
// GEMINI AI ENDPOINTS & FALLBACK GENERATORS
// ==========================================

// Helper to build a comprehensive fallback itinerary when AI quota (429) or offline limits are reached
function generateFallbackItinerary(destinationName: string, daysCount: number, travelType: string, budgetTier: string) {
  const days = Math.max(1, Math.min(daysCount || 3, 10));
  const mult = budgetTier === 'Luxury' ? 2.8 : budgetTier === 'Budget' ? 0.6 : 1.0;

  const baseAccom = Math.round(3500 * mult);
  const baseFood = Math.round(1500 * mult);
  const baseTransport = Math.round(1000 * mult);
  const baseTickets = Math.round(600 * mult);
  const baseShopping = Math.round(1200 * mult);
  const baseMisc = Math.round(700 * mult);

  const itineraryDays = [];
  const highlightsMap: Record<string, string[]> = {
    morning: [
      `Morning visit to the most famous landmark in ${destinationName}, followed by a quiet heritage walk.`,
      `Sunrise view point visit in ${destinationName}, followed by a warm traditional breakfast at a popular local spot.`,
      `Exploration of historical monuments and architectural wonders around central ${destinationName}.`
    ],
    afternoon: [
      `Savor an authentic local thali lunch, then visit artisan handicraft centers and museums in ${destinationName}.`,
      `Relaxing cafe stop and regional culinary tasting in the bustling heart of ${destinationName}.`,
      `Guided cultural tour around the old city quarters, visiting local temples and historic bazaars.`
    ],
    evening: [
      `Sunset promenade stroll, local street food food-walk trying regional signature snacks, and vibrant evening bazaar shopping.`,
      `Scenic evening viewpoint, peaceful lakeside/beachside leisure, followed by dinner at a highly rated local restaurant.`,
      `Cultural performance or sound-and-light show, concluding with dinner at an authentic heritage dining spot.`
    ]
  };

  for (let i = 1; i <= days; i++) {
    const dayBudget = {
      accommodation: baseAccom,
      food: baseFood,
      transport: baseTransport,
      entryTickets: baseTickets,
      shopping: baseShopping,
      miscellaneous: baseMisc,
      total: baseAccom + baseFood + baseTransport + baseTickets + baseShopping + baseMisc
    };

    itineraryDays.push({
      day: i,
      title: `Day ${i}: Exploring ${destinationName} Highlights & Culture`,
      theme: `Immersion in the culture, landmarks, and authentic flavors of ${destinationName}`,
      morning: highlightsMap.morning[(i - 1) % highlightsMap.morning.length],
      afternoon: highlightsMap.afternoon[(i - 1) % highlightsMap.afternoon.length],
      evening: highlightsMap.evening[(i - 1) % highlightsMap.evening.length],
      food: `Try local delicacies of ${destinationName}: regional specialties, street food chaat, and local chai.`,
      travel: `Local transport via auto-rickshaw or private cab (approx 20-30 mins between major spots).`,
      stay: `Central boutique hotel or cozy heritage stay in ${destinationName}.`,
      approxBudget: dayBudget
    });
  }

  const totalBudget = {
    accommodation: baseAccom * days,
    food: baseFood * days,
    transport: baseTransport * days,
    entryTickets: baseTickets * days,
    shopping: baseShopping * days,
    miscellaneous: baseMisc * days,
    total: (baseAccom + baseFood + baseTransport + baseTickets + baseShopping + baseMisc) * days
  };

  return {
    title: `${days}-Day Ultimate ${destinationName} ${travelType || 'Travel'} Experience`,
    numberOfDays: days,
    travelType: travelType || 'Solo',
    budgetTier: budgetTier || 'Standard',
    totalBudget,
    itinerary: itineraryDays
  };
}

// Fallback response generator for chat
function generateFallbackChatResponse(message: string): string {
  const lower = message.toLowerCase();
  
  if (lower.includes('budget') || lower.includes('cost') || lower.includes('price')) {
    return `### 💰 Travel Budget Guidance for India
- **Budget Tier**: ₹1,500 – ₹2,500 per day (Hostels, street food, state buses/trains).
- **Standard Tier**: ₹3,500 – ₹7,000 per day (3-star hotels, mid-range dining, auto/cabs).
- **Luxury Tier**: ₹10,000+ per day (Heritage resorts, fine dining, private chauffeur).

*Tip: Booking train tickets via IRCTC and hotels at least 3 weeks in advance yields the best prices.*`;
  }

  if (lower.includes('pack') || lower.includes('cloth') || lower.includes('wear')) {
    return `### 🧳 Smart Packing Essentials for Travel in India
1. **Clothing**: Lightweight, breathable cotton clothes. Modest wear for temples and religious sites (covering shoulders and knees).
2. **Footwear**: Comfortable walking shoes or sturdy sandals that are easy to slip off outside temples.
3. **Essentials**: Sunscreen, sunglasses, power bank, reusable water bottle, and basic first-aid/medication.
4. **Monsoon/Winter**: Waterproof jacket/umbrella for monsoon (June–Sept) or light jacket for hill stations & northern winters.`;
  }

  return `### 🌴 TravelGPT Recommendations
Thank you for reaching out! Here are top recommendations for exploring India:

- **Top Destinations**: Rajasthan (Jaipur/Udaipur) for heritage, Goa or Kerala for beaches & backwaters, Himachal/Uttarakhand for mountains, and Varanasi for cultural spiritual depth.
- **Best Season**: October to March offers pleasant weather across most regions.
- **Safety & Connectivity**: Get a local SIM card (Airtel/Jio), keep Google Maps downloaded offline, and use registered ride-hailing apps like Uber or Ola.

*Feel free to ask about specific cities, local food recommendations, or itinerary suggestions!*`;
}

// Fallback packing checklist generator
function generateFallbackPackingList(destinationName: string, season: string, durationDays: number) {
  return [
    {
      category: 'Clothing & Footwear',
      items: [
        { text: `Comfortable breathable cotton outfits (${durationDays || 3} sets)`, packed: false },
        { text: 'Light jacket or shawl for cool evenings', packed: false },
        { text: 'Comfortable walking shoes & slip-on sandals', packed: false },
        { text: 'Socks (3-4 pairs)', packed: false }
      ]
    },
    {
      category: 'Toiletries & Personal Care',
      items: [
        { text: 'SPF 50+ Sunscreen & lip balm', packed: false },
        { text: 'Insect repellent spray/cream', packed: false },
        { text: 'Travel size shampoo, body wash & toothpaste', packed: false },
        { text: 'Hand sanitizer & wet wipes', packed: false }
      ]
    },
    {
      category: 'Electronics & Gadgets',
      items: [
        { text: 'Smartphone & fast charger', packed: false },
        { text: '10,000mAh Power bank', packed: false },
        { text: 'Noise-canceling earphones/headphones', packed: false },
        { text: 'Multi-plug travel adapter', packed: false }
      ]
    },
    {
      category: 'Documents & Money',
      items: [
        { text: 'Government ID proof (Aadhaar / Passport / Driving License)', packed: false },
        { text: 'Cash in small denominations (₹100, ₹200, ₹500 notes)', packed: false },
        { text: 'UPI Apps (GPay / PhonePe / Paytm) set up', packed: false },
        { text: 'Digital copies of hotel and transport bookings', packed: false }
      ]
    },
    {
      category: 'Special & Medical Kit',
      items: [
        { text: 'Personal prescription medicines', packed: false },
        { text: 'ORSL / Electral rehydration packets', packed: false },
        { text: 'Basic first aid (Band-Aids, pain relievers, digestive tabs)', packed: false },
        { text: 'Reusable water bottle with filter', packed: false }
      ]
    }
  ];
}

// Helper function to call Gemini with retries and model fallbacks for 503/429 errors
async function generateGeminiWithRetry(ai: GoogleGenAI, options: any) {
  const primaryModel = options.model || 'gemini-3.5-flash';
  // Try requested model first, then fallbacks
  const modelsToTry = Array.from(new Set([primaryModel, 'gemini-3.5-flash', 'gemini-3.1-pro-preview', 'gemini-3.1-flash-lite', 'gemini-3.6-flash']));
  let lastError: any = null;

  for (const modelCandidate of modelsToTry) {
    try {
      const callOptions = { ...options, model: modelCandidate };
      const response = await ai.models.generateContent(callOptions);
      if (response && (response.text || response.candidates)) {
        return response;
      }
    } catch (err: any) {
      lastError = err;
      const isQuotaOrLimit = err?.status === 429 || err?.code === 429 ||
                             err?.message?.includes('429') || err?.message?.includes('quota') ||
                             err?.message?.includes('RESOURCE_EXHAUSTED') || err?.message?.includes('rate-limit');
      
      console.log(`[AI Engine] Model ${modelCandidate} status: ${isQuotaOrLimit ? 'Quota limit reached' : 'Service unavailable'}`);
      
      if (!isQuotaOrLimit) {
        // Retry once after brief pause for 503/transient network glitches
        try {
          await new Promise((resolve) => setTimeout(resolve, 1000));
          const response = await ai.models.generateContent({ ...options, model: modelCandidate });
          if (response && (response.text || response.candidates)) {
            return response;
          }
        } catch (retryErr: any) {
          lastError = retryErr;
        }
      }
    }
  }

  throw lastError;
}

// 1. AI Itinerary Generation
app.post('/api/gemini/itinerary', async (req, res) => {
  const { destinationName, numberOfDays, travelType, budgetTier, specialRequests } = req.body;

  if (!destinationName) {
    return res.status(400).json({ error: 'destinationName is required' });
  }

  const days = parseInt(numberOfDays) || 3;

  try {
    const ai = getGeminiClient();

    const prompt = `You are TravelGPT, India's premier AI Travel Planner.
Create a detailed, highly authentic ${days}-day travel itinerary for visiting ${destinationName}, India.
Trip Context:
- Number of Days: ${days}
- Travel Style: ${travelType || 'Solo'}
- Budget Level: ${budgetTier || 'Standard'}
- Custom Notes / Preferences: ${specialRequests || 'Focus on top highlights, authentic food, hidden gems, and smooth travel logistics.'}

Return a valid JSON object matching this schema:
{
  "title": "Unforgettable ${days}-Day ${destinationName} ${travelType || ''} Experience",
  "numberOfDays": ${days},
  "travelType": "${travelType || 'Solo'}",
  "budgetTier": "${budgetTier || 'Standard'}",
  "totalBudget": {
    "accommodation": number,
    "food": number,
    "transport": number,
    "entryTickets": number,
    "shopping": number,
    "miscellaneous": number,
    "total": number
  },
  "itinerary": [
    {
      "day": number,
      "title": "Day Title & Theme",
      "theme": "Core theme of the day",
      "morning": "Detailed morning activity, timings, and place names",
      "afternoon": "Detailed afternoon activity, lunch spot, and experience",
      "evening": "Detailed evening activity, sunset spot, or night market",
      "food": "Specific local dishes to try and recommended restaurant/cafe names",
      "travel": "Logistics & local transport mode (auto/cab/scooter) with travel times",
      "stay": "Recommended hotel/area for night stay",
      "approxBudget": {
        "accommodation": number,
        "food": number,
        "transport": number,
        "entryTickets": number,
        "shopping": number,
        "miscellaneous": number,
        "total": number
      }
    }
  ]
}

Ensure all prices are in INR (Indian Rupees - ₹) appropriate for a ${budgetTier || 'Standard'} budget in ${destinationName}. Provide genuine local spots, authentic cuisine, and practical timing.`;

    const response = await generateGeminiWithRetry(ai, {
      model: 'gemini-3.1-pro-preview',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        temperature: 0.7,
        tools: [{ googleSearch: {} }]
      }
    });

    const jsonText = response.text || '{}';
    const parsedData = JSON.parse(jsonText);

    return res.json({ success: true, plan: parsedData });
  } catch (err: any) {
    console.log('[AI Engine] Serving curated offline travel itinerary.');
    // Serve rich fallback itinerary instead of breaking UI or returning raw 429
    const fallbackPlan = generateFallbackItinerary(destinationName, days, travelType, budgetTier);
    return res.json({ success: true, plan: fallbackPlan, isFallback: true });
  }
});

// 2. AI Travel Chatbot
app.post('/api/gemini/chat', async (req, res) => {
  const { message, history } = req.body;

  if (!message) {
    return res.status(400).json({ error: 'Message is required' });
  }

  try {
    const ai = getGeminiClient();

    const systemInstruction = `You are TravelGPT AI Assistant, an expert, enthusiastic, and highly knowledgeable India travel guide.
Answer user questions regarding Indian travel destinations, itineraries, weather, clothing, food, safety, local customs, transport, budget estimations, and hidden gems.
Be warm, professional, highly informative, and use bullet points or formatted sections where applicable. Keep responses structured and concise.
Whenever prices are mentioned, use INR (₹).`;

    const contents: any[] = [];
    if (Array.isArray(history)) {
      history.forEach((h: any) => {
        contents.push({
          role: h.sender === 'user' ? 'user' : 'model',
          parts: [{ text: h.text }]
        });
      });
    }
    contents.push({ role: 'user', parts: [{ text: message }] });

    const response = await generateGeminiWithRetry(ai, {
      model: 'gemini-3.5-flash',
      contents: contents,
      config: {
        systemInstruction,
        temperature: 0.7,
        tools: [{ googleSearch: {} }]
      }
    });

    return res.json({
      success: true,
      reply: response.text || "I'm sorry, I couldn't process that request right now."
    });
  } catch (err: any) {
    console.log('[AI Engine] Serving curated travel chat response.');
    const fallbackReply = generateFallbackChatResponse(message);
    return res.json({
      success: true,
      reply: fallbackReply,
      isFallback: true
    });
  }
});

// 3. AI Packing Checklist Generator
app.post('/api/gemini/packing', async (req, res) => {
  const { destinationName, season, durationDays, travelType } = req.body;

  try {
    const ai = getGeminiClient();

    const prompt = `Generate a comprehensive travel packing checklist for a ${durationDays || 3}-day trip to ${destinationName || 'India'} during the ${season || 'Winter'} season for a ${travelType || 'Solo'} trip.
Return JSON format:
{
  "checklist": [
    {
      "category": "Category Name (e.g., Clothing & Footwear, Toiletries & Medical, Electronics & Chargers, Important Documents, Season Special)",
      "items": [
        { "text": "Item description", "packed": false }
      ]
    }
  ]
}
`;

    const response = await generateGeminiWithRetry(ai, {
      model: 'gemini-3.1-flash-lite',
      contents: prompt,
      config: {
        responseMimeType: 'application/json'
      }
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json({ success: true, checklist: parsed.checklist || [] });
  } catch (err: any) {
    console.log('[AI Engine] Serving curated travel packing list.');
    const fallbackList = generateFallbackPackingList(destinationName, season, durationDays);
    return res.json({ success: true, checklist: fallbackList, isFallback: true });
  }
});

// ==========================================
// VITE / STATIC SERVING
// ==========================================

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 TravelGPT AI Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();

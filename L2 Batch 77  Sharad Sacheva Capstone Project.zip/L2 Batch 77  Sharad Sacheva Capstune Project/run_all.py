import subprocess
import sys

scripts = [
    "1.SplitCustomer.py",
    "2.ProcessDump.py",
    "3.Interest.py",
    "4.Summary.py",
    "5.Consolidated.py",
    "6.Dashboard.py"
]

for script in scripts:
    print(f"\n==============================")
    print(f"Running: {script}")
    print(f"==============================\n")

    result = subprocess.run([sys.executable, script])

    if result.returncode != 0:
        print(f"❌ Error in {script}. Stopping execution.")
        break

print("\n✅ All scripts executed successfully.")